from typing import Dict
from typing import Optional
from typing import Union

from mojo_opset.utils.logging import get_logger
from mojo_opset.utils.platform import get_platform

from .function import MojoFunction
from .operator import MojoOperator

logger = get_logger(__name__)

PLATFORM_BACKEND_PRIORITY = {
    "npu": ["ttx", "torch_npu", "torch", "xops"],
    "ilu": ["ixformer", "ttx", "torch"],
    "mlu": ["ttx", "torch"],
    "meta_device": ["torch"],
}

# All known backend name prefixes (used for registration validation).
BACKEND_PRIORITY_LIST = PLATFORM_BACKEND_PRIORITY[get_platform()]

BACKEND_PRIORITY_MAP = {
    "torchnpu": "torch_npu"
}  ## Avoid the issue of failed identification of underscore "_" in the torch_npu backend name


def _normalize_backend_name(backend_name: Optional[str] = None) -> Optional[str]:
    if backend_name is None:
        return None

    normalized_backend_name = backend_name.strip().lower()
    return BACKEND_PRIORITY_MAP.get(normalized_backend_name, normalized_backend_name)


class MojoBackendRegistry:
    def __init__(self, core_op_cls: Union[MojoOperator, MojoFunction]):
        assert core_op_cls.__name__.startswith("Mojo"), (
            f"Operator {core_op_cls.__name__} who is a subclass of MojoOperator, class name must start with Mojo."
        )
        self._core_op_cls = core_op_cls
        self._operator_name = core_op_cls.__name__[4:]
        self._registry: Dict[str, Union[MojoOperator, MojoFunction]] = {}

    def get_core_op_cls(self):
        return self._core_op_cls

    def register(self, cls: Union[MojoOperator, MojoFunction]):
        idx = cls.__name__.find(self._operator_name)
        assert idx != -1, (
            f"Operator {cls.__name__} who be a subclass of {self._core_op_cls.__name__} must "
            f"contain {self._operator_name} in its name."
        )
        impl_backend_name = _normalize_backend_name(cls.__name__[:idx])

        curr_platform = get_platform()

        # Hard code for some special cases
        assert impl_backend_name != "mojo", "should not register base backend"

        if impl_backend_name == "analysis":
            return

        # in case of backend class name mistake
        if impl_backend_name not in BACKEND_PRIORITY_LIST:
            for target_backend in BACKEND_PRIORITY_LIST:
                if impl_backend_name.startswith(target_backend):
                    raise NameError(
                        f"Operator {cls.__name__} backend[{impl_backend_name}] is not supported, "
                        f"are you wish to named {target_backend.upper()}{self._operator_name} ?"
                    )
            raise AssertionError(
                f"Operator {cls.__name__} backend[{impl_backend_name}] is not supported for platform[{curr_platform}], "
                f"please choose from {BACKEND_PRIORITY_LIST}."
            )

        if curr_platform in cls.supported_platforms_list:
            logger.debug(
                f"Register {cls.__name__} as {self._core_op_cls.__name__} implementation with backend[{impl_backend_name}]"
            )

            if impl_backend_name in [x[0] for x in self._registry]:
                raise ValueError(
                    f"Operator {self._core_op_cls.__name__} backend[{impl_backend_name}] has been registered"
                )

            self._registry[impl_backend_name] = cls
            cls._backend = impl_backend_name
            self.sort()
        else:
            logger.warning(f"Operator {cls.__name__} is not supported on {curr_platform} platform.")

    def get(
        self, backend_name: str = None, *, strict: bool = False
    ) -> Union[MojoOperator, MojoFunction]:
        # Since the selection of `backend_name` is not deterministic, the import order
        # may lead to missing registrations. To avoid this, we first ensure that all
        # backends are fully registered before accessing or executing the registry
        # of a specific backend.
        backend_name = _normalize_backend_name(backend_name)

        if (backend_name is None) or (backend_name not in self._registry.keys()):  # get first class
            if strict and backend_name is not None:
                raise KeyError(
                    f"{self._operator_name} backend {backend_name!r} is not registered; "
                    f"available: {list(self._registry)}"
                )

            assert len(self._registry) > 0, f"{self._operator_name} does not implement any backend."
            fallback = list(self._registry.values())[0]
            logger.debug(
                "Backend '%s' is not registered, falling back to %s.",
                backend_name or "<default>",
                fallback.__name__,
            )
            return fallback

        return self._registry[backend_name]

    def registered_backends(self) -> tuple[str, ...]:
        """Return backend names registered for the current platform in priority order."""
        return tuple(self._registry)

    def sort(self):
        def _prio_key(item):
            name = item[0]
            return BACKEND_PRIORITY_LIST.index(name) if name in BACKEND_PRIORITY_LIST else len(BACKEND_PRIORITY_LIST)

        self._registry = dict(sorted(self._registry.items(), key=_prio_key))

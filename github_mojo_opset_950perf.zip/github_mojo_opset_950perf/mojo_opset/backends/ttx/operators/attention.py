from typing import Optional

import torch

from mojo_opset.backends.ttx.kernels import paged_attention_prefill, paged_attention_prefill_prepare
from mojo_opset.backends.ttx.kernels import paged_attention_prefill_with_kv_dequant
from mojo_opset.backends.ttx.kernels import paged_attention_decode
from mojo_opset.backends.ttx.kernels import paged_attention_decode_with_kv_dequant
from mojo_opset.backends.ttx.kernels import sdpa_infer
from mojo_opset.backends.ttx.kernels import swa_paged_prefill
from mojo_opset.backends.ttx.kernels import swa_paged_prefill_with_kv_dequant
from mojo_opset.backends.ttx.kernels import swa_paged_decode
from mojo_opset.backends.ttx.kernels import swa_paged_decode_quant
from mojo_opset.backends.ttx.kernels import swa_infer
from mojo_opset.core import MojoPagedPrefillGQA
from mojo_opset.core import MojoPagedDecodeGQA
from mojo_opset.core import MojoSdpa
from mojo_opset.core import MojoPagedPrefillSWA
from mojo_opset.core import MojoPagedDecodeSWA
from mojo_opset.core import MojoSWA
from mojo_opset.core.operators.attention import assert_paged_decode_contract
from mojo_opset.core.operators.attention import assert_paged_prefill_contract
from mojo_opset.experimental import MojoPagedDecodeGQAWithKVDequant
from mojo_opset.experimental import MojoPagedDecodeSWAWithKVDequant
from mojo_opset.experimental import MojoPagedPrefillGQAWithKVDequant
from mojo_opset.experimental import MojoPagedPrefillSWAWithKVDequant
from mojo_opset.experimental import MojoPagedDecodeNstepSWA
from mojo_opset.utils.platform import get_platform


class TTXPagedPrefillGQA(MojoPagedPrefillGQA):
    supported_platforms_list = ["npu", "ilu", "mlu"]

    def __init__(
        self,
        is_causal: bool = True,
        gqa_layout: str = "AABB",
    ):
        super().__init__(is_causal, gqa_layout)
        self.meta_task_b = None
        self.meta_task_q_block = None
        self.meta_task_q_head = None
        self.meta_core_task_offsets = None

    def prepare_metadata(
        self,
        cu_q_lens: torch.Tensor,
        cu_total_seq_lens: torch.Tensor,
        num_q_heads: int,
        num_kv_heads: int,
        page_size: int,
    ):
        assert get_platform() == "npu"
        from mojo_opset.backends.ttx.kernels.npu.utils import is_910
        if is_910():
            return
        total_seq_lens = (
            cu_q_lens[1:] - cu_q_lens[:-1]
            if cu_total_seq_lens is None
            else cu_total_seq_lens[1:] - cu_total_seq_lens[:-1]
        )

        (
            self.meta_task_b,
            self.meta_task_q_block,
            self.meta_task_q_head,
            self.meta_core_task_offsets
        )= paged_attention_prefill_prepare(
            cu_q_lens,
            total_seq_lens,
            num_q_heads,
            num_kv_heads,
            self.gqa_layout == "ABAB",
            page_size,
        )

    def forward(
        self,
        query: torch.Tensor,
        key_cache: torch.Tensor,
        value_cache: torch.Tensor,
        cu_q_lens: torch.Tensor,
        block_tables: torch.Tensor,
        softmax_scale: Optional[float] = None,
        cu_total_seq_lens: Optional[torch.Tensor] = None,
        mask: Optional[torch.Tensor] = None,
        max_q_len: Optional[int] = None,
        max_total_seq_len: Optional[int] = None,
    ):
        assert_paged_prefill_contract(cu_q_lens, block_tables, cu_total_seq_lens)

        assert self.is_causal, (
            f"[TTXPagedPrefillGQA] TTX only support causal attention, but got is_causal={self.is_causal}"
        )
        assert mask is None, f"[TTXPagedPrefillGQA] TTX does not support mask, but got mask={mask}"
        total_seq_lens = (
            cu_q_lens[1:] - cu_q_lens[:-1]
            if cu_total_seq_lens is None
            else cu_total_seq_lens[1:] - cu_total_seq_lens[:-1]
        )
        # max_q_len / max_total_seq_len / kwargs: core·Ixformer API compatibility.
        if get_platform() == "npu":
            output = paged_attention_prefill(
                q=query,
                key_cache=key_cache,
                value_cache=value_cache,
                cu_q_lens=cu_q_lens,
                seqlens_kv=total_seq_lens,
                block_tables=block_tables,
                gqa_interleave=self.gqa_layout == "ABAB",
                task_b=self.meta_task_b,
                task_q_block=self.meta_task_q_block,
                task_q_head=self.meta_task_q_head,
                core_task_offsets=self.meta_core_task_offsets,
                softmax_scale=softmax_scale,
                max_q_len=max_q_len,
                max_total_seq_len=max_total_seq_len,
            )
        else:
            output = paged_attention_prefill(
                q=query,
                key_cache=key_cache,
                value_cache=value_cache,
                cu_q_lens=cu_q_lens,
                seqlens_kv=total_seq_lens,
                block_tables=block_tables,
                gqa_interleave=self.gqa_layout == "ABAB",
                softmax_scale=softmax_scale,
                max_q_len=max_q_len,
                max_total_seq_len=max_total_seq_len,
            )

        return output


class TTXPagedPrefillGQAWithKVDequant(MojoPagedPrefillGQAWithKVDequant):
    """Triton paged prefill attention with int8 KV cache on ILU."""

    supported_platforms_list = ["ilu"]

    def forward(
        self,
        query: torch.Tensor,
        query_scale: Optional[torch.Tensor],
        key_cache: torch.Tensor,
        key_scale: torch.Tensor,
        value_cache: torch.Tensor,
        value_scale: torch.Tensor,
        cu_q_lens: torch.Tensor,
        block_tables: torch.Tensor,
        softmax_scale: Optional[float] = None,
        cu_total_seq_lens: Optional[torch.Tensor] = None,
        mask: Optional[torch.Tensor] = None,
        max_q_len: Optional[int] = None,
        max_total_seq_len: Optional[int] = None,
    ) -> torch.Tensor:
        assert query_scale is None, "[TTXPagedPrefillGQAWithKVDequant] quantized query is not supported"
        assert cu_q_lens.dtype == torch.int32
        assert block_tables.dtype == torch.int32
        assert self.is_causal, (
            f"[TTXPagedPrefillGQAWithKVDequant] only supports causal attention, got is_causal={self.is_causal}"
        )
        assert mask is None, (
            f"[TTXPagedPrefillGQAWithKVDequant] does not support mask"
        )

        seqlens_kv = (
            cu_q_lens[1:] - cu_q_lens[:-1]
            if cu_total_seq_lens is None
            else cu_total_seq_lens[1:] - cu_total_seq_lens[:-1]
        )

        num_q_heads = query.shape[1]
        num_kv_heads = key_cache.shape[1]

        if num_q_heads != num_kv_heads:
            if self.gqa_layout == "AABB":
                k_qscale_expanded = key_scale.repeat_interleave(num_q_heads // num_kv_heads, dim=0)
                v_qscale_expanded = value_scale.repeat_interleave(num_q_heads // num_kv_heads, dim=0)
            else:
                k_qscale_expanded = key_scale.repeat((num_q_heads // num_kv_heads, 1))
                v_qscale_expanded = value_scale.repeat((num_q_heads // num_kv_heads, 1))
        else:
            k_qscale_expanded = key_scale
            v_qscale_expanded = value_scale

        output = paged_attention_prefill_with_kv_dequant(
            q=query,
            key_cache=key_cache,
            k_qscale=k_qscale_expanded,
            value_cache=value_cache,
            v_qscale=v_qscale_expanded,
            cu_seqlens_q=cu_q_lens,
            seqlens_kv=seqlens_kv,
            block_tables=block_tables,
            gqa_interleave=self.gqa_layout == "ABAB",
            softmax_scale=softmax_scale,
            max_seqlen_q=max_q_len,
            max_seqlen_k=max_total_seq_len,
        )

        return output


class TTXPagedDecodeGQA(MojoPagedDecodeGQA):
    supported_platforms_list = ["npu", "ilu", "mlu"]

    def forward(
        self,
        query: torch.Tensor,
        key_cache: torch.Tensor,
        value_cache: torch.Tensor,
        total_seq_lens: torch.Tensor,
        block_tables: torch.Tensor,
        softmax_scale: Optional[float] = None,
        cu_q_lens: Optional[torch.Tensor] = None,
        mask: Optional[torch.Tensor] = None,
        *,
        max_total_seq_len: Optional[int] = None,
    ):
        assert_paged_decode_contract(block_tables, total_seq_lens)
        assert self.is_causal, (
            f"[TTXPagedDecodeGQA] TTX only support causal attention, but got is_causal={self.is_causal}"
        )
        assert mask is None, f"[TTXPagedDecodeGQA] TTX does not support mask, but got mask={mask}"
        assert cu_q_lens is None, "varlen is not supported"

        output = paged_attention_decode(
            q=query,
            key_cache=key_cache,
            value_cache=value_cache,
            seqlens=total_seq_lens,
            block_tables=block_tables,
            gqa_interleave=self.gqa_layout == "ABAB",
            softmax_scale=softmax_scale,
        )

        return output


class TTXPagedDecodeGQAWithKVDequant(MojoPagedDecodeGQAWithKVDequant):
    supported_platforms_list = ["ilu"]

    def forward(
        self,
        query: torch.Tensor,
        query_scale: Optional[torch.Tensor],
        key_cache: torch.Tensor,
        key_scale: torch.Tensor,
        value_cache: torch.Tensor,
        value_scale: torch.Tensor,
        total_seq_lens: torch.Tensor,
        block_tables: torch.Tensor,
        softmax_scale: Optional[float] = None,
        mask: Optional[torch.Tensor] = None,
        *,
        max_total_seq_len: Optional[int] = None,
    ) -> torch.Tensor:
        assert_paged_decode_contract(block_tables, total_seq_lens)
        assert self.is_causal, (
            f"[TTXPagedDecodeGQAWithKVDequant] TTX only support causal attention, but got is_causal={self.is_causal}"
        )
        assert mask is None, f"[TTXPagedDecodeGQAWithKVDequant] TTX does not support mask, but got mask={mask}"

        output = paged_attention_decode_with_kv_dequant(
            q=query,
            query_scale=query_scale,
            key_cache=key_cache,
            key_scale=key_scale,
            value_cache=value_cache,
            value_scale=value_scale,
            seqlens=total_seq_lens,
            block_tables=block_tables,
            gqa_interleave=self.gqa_layout == "ABAB",
            compute_dtype=self.compute_dtype,
            softmax_scale=softmax_scale,
        )

        return output


class TTXSdpa(MojoSdpa):
    supported_platforms_list = ["npu", "ilu"]

    def forward(
        self,
        query: torch.Tensor,
        key: torch.Tensor,
        value: torch.Tensor,
        attn_mask: Optional[torch.Tensor] = None,
    ):
        output = sdpa_infer(
            q=query,
            k=key,
            v=value,
            mask=attn_mask,
            scale=self.scale,
            enable_gqa=self.enable_gqa,
        )
        return output

class TTXPagedPrefillSWA(MojoPagedPrefillSWA):
    supported_platforms_list = ["npu", "mlu", "ilu"]

    def forward(
        self,
        q: torch.Tensor,  # [total_q_len, n_q_heads, head_dim]
        k_cache: torch.Tensor,  # [total_k_len, n_kv_heads, head_dim]
        v_cache: torch.Tensor,  # [total_k_len, n_kv_heads, head_dim]
        cu_q_lens: torch.Tensor,  # [bsz + 1]
        block_table: torch.Tensor,  # [bsz, num_kv_blocks]
        softmax_scale: Optional[float] = None,
        cu_total_seq_lens: Optional[torch.Tensor] = None,  # [bsz + 1]
        *,
        max_q_len: Optional[int] = None,
        max_total_seq_len: Optional[int] = None,
    ) -> torch.Tensor:
        assert_paged_prefill_contract(cu_q_lens, block_table, cu_total_seq_lens)
        total_seq_lens = (
            cu_q_lens[1:] - cu_q_lens[:-1]
            if cu_total_seq_lens is None
            else cu_total_seq_lens[1:] - cu_total_seq_lens[:-1]
        )

        o = swa_paged_prefill(
            q,
            k_cache,
            v_cache,
            cu_q_lens,
            total_seq_lens,
            block_table,
            self.is_causal,
            self.local_window_size,
            self.global_window_size,
            softmax_scale,
            self.gqa_interleave,
        )
        return o


class TTXPagedPrefillSWAWithKVDequant(MojoPagedPrefillSWAWithKVDequant):
    """Triton paged prefill SWA attention with int8 KV cache on ILU."""

    supported_platforms_list = ["ilu"]

    def forward(
        self,
        query: torch.Tensor,
        query_scale: Optional[torch.Tensor],
        key_cache: torch.Tensor,
        key_scale: torch.Tensor,
        value_cache: torch.Tensor,
        value_scale: torch.Tensor,
        cu_q_lens: torch.Tensor,
        block_table: torch.Tensor,
        softmax_scale: Optional[float] = None,
        cu_total_seq_lens: Optional[torch.Tensor] = None,
        max_q_len: Optional[int] = None,
        max_total_seq_len: Optional[int] = None,
    ) -> torch.Tensor:
        assert query_scale is None, "[TTXPagedPrefillSWAWithKVDequant] quantized query is not supported"
        assert_paged_prefill_contract(cu_q_lens, block_table, cu_total_seq_lens)

        seqlens_kv = (
            cu_q_lens[1:] - cu_q_lens[:-1]
            if cu_total_seq_lens is None
            else cu_total_seq_lens[1:] - cu_total_seq_lens[:-1]
        )

        num_q_heads = query.shape[1]
        num_kv_heads = key_cache.shape[1]
        if num_q_heads != num_kv_heads:
            if self.gqa_interleave:
                k_qscale_expanded = key_scale.repeat((num_q_heads // num_kv_heads, 1))
                v_qscale_expanded = value_scale.repeat((num_q_heads // num_kv_heads, 1))
            else:
                k_qscale_expanded = key_scale.repeat_interleave(num_q_heads // num_kv_heads, dim=0)
                v_qscale_expanded = value_scale.repeat_interleave(num_q_heads // num_kv_heads, dim=0)
        else:
            k_qscale_expanded = key_scale
            v_qscale_expanded = value_scale

        o = swa_paged_prefill_with_kv_dequant(
            q=query,
            key_cache=key_cache,
            k_qscale=k_qscale_expanded,
            value_cache=value_cache,
            v_qscale=v_qscale_expanded,
            cu_seqlens_q=cu_q_lens,
            seqlens_kv=seqlens_kv,
            block_tables=block_table,
            is_causal=self.is_causal,
            local_window_size=self.local_window_size,
            global_window_size=self.global_window_size,
            softmax_scale=softmax_scale,
            gqa_interleave=self.gqa_interleave,
            compute_dtype=self.compute_dtype,
        )
        return o


class TTXPagedDecodeSWA(MojoPagedDecodeSWA):
    supported_platforms_list = ["npu", "mlu", "ilu"]

    def forward(
        self,
        q: torch.Tensor,  # [bsz, n_q_heads, head_dim]
        k_cache: torch.Tensor,  # [n_pages, n_kv_heads, page_size, head_dim]
        v_cache: torch.Tensor,  # [n_pages, n_kv_heads, page_size, head_dim]
        total_seq_lens: torch.Tensor,  # [bsz]
        block_table: torch.Tensor,  # [bsz, max_num_blocks]
        softmax_scale: Optional[float] = None,
        *,
        max_total_seq_len: Optional[int] = None,
    ) -> torch.Tensor:
        # Note: is_causal = False should never happen
        assert_paged_decode_contract(block_table, total_seq_lens)
        o = swa_paged_decode(
            q,
            k_cache,
            v_cache,
            total_seq_lens,
            block_table,
            self.local_window_size,
            self.global_window_size,
            self.gqa_interleave,
            softmax_scale,
        )

        return o

class TTXPagedDecodeSWAWithKVDequant(MojoPagedDecodeSWAWithKVDequant):
    supported_platforms_list = ["ilu"]

    def forward(
        self,
        query: torch.Tensor,
        query_scale: Optional[torch.Tensor],
        key_cache: torch.Tensor,
        key_scale: torch.Tensor,
        value_cache: torch.Tensor,
        value_scale: torch.Tensor,
        total_seq_lens: torch.Tensor,
        block_table: torch.Tensor,
        softmax_scale: Optional[float] = None,
        *,
        max_total_seq_len: Optional[int] = None,
    ) -> torch.Tensor:
        assert query_scale is None, "[TTXPagedDecodeSWAWithKVDequant] quantized query is not supported"
        assert total_seq_lens.dtype == torch.int32
        assert block_table.dtype == torch.int32
        assert_paged_decode_contract(block_table, total_seq_lens)
        o = swa_paged_decode_quant(
            query,
            key_cache,
            key_scale,
            value_cache,
            value_scale,
            total_seq_lens,
            block_table,
            self.local_window_size,
            self.global_window_size,
            self.gqa_interleave,
            softmax_scale,
        )
        return o


class TTXSWA(MojoSWA):
    supported_platforms_list = ["npu", "ilu"]

    def forward(
        self,
        q: torch.Tensor,  # [total_q_len, n_q_heads, head_dim]
        k: torch.Tensor,  # [total_k_len, n_kv_heads, head_dim]
        v: torch.Tensor,  # [total_k_len, n_kv_heads, head_dim]
        cu_q_lens: torch.Tensor,  # [bsz + 1]
        cu_total_seq_lens: torch.Tensor,  # [bsz + 1]
        softmax_scale: Optional[float] = None,
    ) -> torch.Tensor:
        assert cu_q_lens.dtype == torch.int32
        assert cu_total_seq_lens.dtype == torch.int32
        o = swa_infer(
            q,
            k,
            v,
            cu_q_lens,
            cu_total_seq_lens,
            self.is_causal,
            self.local_window_size,
            self.global_window_size,
            softmax_scale,
            self.gqa_interleave,
        )
        return o


class TTXPagedDecodeNstepSWA(MojoPagedDecodeNstepSWA):
    supported_platforms_list = ["mlu"]

    def forward(
        self,
        q: torch.Tensor,  # [bsz, seq_len, n_q_heads, head_dim]
        k_cache: torch.Tensor,  # [n_pages, n_kv_heads, page_size, head_dim]
        v_cache: torch.Tensor,  # [n_pages, n_kv_heads, page_size, head_dim]
        total_seq_lens: torch.Tensor,  # [bsz]
        block_table: torch.Tensor,  # [bsz, max_num_blocks]
        softmax_scale: Optional[float] = None,
        *,
        max_total_seq_len: Optional[int] = None,
    ) -> torch.Tensor:
        assert_paged_decode_contract(block_table, total_seq_lens)
        o = swa_paged_decode(
            q,
            k_cache,
            v_cache,
            total_seq_lens,
            block_table,
            self.local_window_size,
            self.global_window_size,
            self.gqa_interleave,
            softmax_scale,
        )

        return o

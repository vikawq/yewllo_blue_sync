import torch

from mojo_opset.backends.ttx.kernels import dynamic_quant
from mojo_opset.backends.ttx.kernels import static_quant
from mojo_opset.backends.ttx.kernels import dequant
from mojo_opset.core import MojoDequant
from mojo_opset.core import MojoDynamicQuant
from mojo_opset.core import MojoMoEDynamicQuant
from mojo_opset.core import MojoStaticQuant


class TTXStaticQuant(MojoStaticQuant):

    def forward(self, input: torch.Tensor) -> torch.Tensor:
        return static_quant(input, self.scale, self.q_min, self.q_max), self.scale


class TTXDequant(MojoDequant):
    supported_platforms_list = ["npu", "ilu"]

    def forward(
        self,
        input: torch.Tensor,
        scale: torch.Tensor,
    ) -> torch.Tensor:
        return dequant(input, scale, self.output_dtype)

class TTXDynamicQuant(MojoDynamicQuant):
    supported_platforms_list = ["npu", "ilu"]

    def forward(
        self,
        input: torch.Tensor,
    ):
        return dynamic_quant(input, self.inv_smooth_scale)


class TTXMoEDynamicQuant(MojoMoEDynamicQuant):
    supported_platforms_list = ["npu", "ilu"]

    def forward(
        self,
        input: torch.Tensor,
        token_count: torch.Tensor,
    ):
        input_fp = input.float() * self.inv_smooth_scale.float().repeat_interleave(token_count, dim=0)
        return dynamic_quant(input_fp, None)

import importlib
import os

from typing import Optional
from typing import Tuple

import torch

from mojo_opset.utils.platform import get_platform

platform = get_platform()


try:
    ttx_backend_module = importlib.import_module(f".{platform}", package=__name__)
except ImportError as e:
    raise RuntimeError(f"Unsupported Triton Platform '{platform}': {e}") from e


def _get_kernel_impl(ttx_backend_module, kernel_name):
    def _not_impl(*args, **kwargs):
        raise NotImplementedError(f"Kernel '{kernel_name}' not implemented for platform '{platform}'.")

    return getattr(ttx_backend_module, kernel_name, _not_impl)


causal_conv1d_fwd_impl = _get_kernel_impl(ttx_backend_module, "causal_conv1d_fwd_impl")
causal_conv1d_bwd_impl = _get_kernel_impl(ttx_backend_module, "causal_conv1d_bwd_impl")
causal_conv1d_update_bdt_impl = _get_kernel_impl(ttx_backend_module, "causal_conv1d_update_bdt_impl")

gelu_fwd_impl = _get_kernel_impl(ttx_backend_module, "gelu_fwd_impl")
gelu_bwd_impl = _get_kernel_impl(ttx_backend_module, "gelu_bwd_impl")

silu_fwd_impl = _get_kernel_impl(ttx_backend_module, "silu_fwd_impl")
silu_bwd_impl = _get_kernel_impl(ttx_backend_module, "silu_bwd_impl")

dynamic_quant_impl = _get_kernel_impl(ttx_backend_module, "dynamic_quant_impl")
static_quant_impl = _get_kernel_impl(ttx_backend_module, "static_quant_impl")
lightning_indexer_impl = _get_kernel_impl(ttx_backend_module, "lightning_indexer_impl")
dequant_impl = _get_kernel_impl(ttx_backend_module, "dequant_impl")

rot_pos_embed_impl = _get_kernel_impl(ttx_backend_module, "rot_pos_embed_impl")
rope_fwd_impl = _get_kernel_impl(ttx_backend_module, "rope_fwd_impl")
rope_bwd_impl = _get_kernel_impl(ttx_backend_module, "rope_bwd_impl")
mrope_fwd_impl = _get_kernel_impl(ttx_backend_module, "mrope_fwd_impl")

vision_rot_pos_embed_impl = _get_kernel_impl(ttx_backend_module, "vision_rot_pos_embed_impl")
vision_rope_apply_impl = _get_kernel_impl(ttx_backend_module, "vision_rope_apply_impl")

vision_rot_pos_embed_impl = _get_kernel_impl(ttx_backend_module, "vision_rot_pos_embed_impl")
vision_rope_apply_impl = _get_kernel_impl(ttx_backend_module, "vision_rope_apply_impl")

swiglu_fwd_impl = _get_kernel_impl(ttx_backend_module, "swiglu_fwd_impl")
swiglu_bwd_impl = _get_kernel_impl(ttx_backend_module, "swiglu_bwd_impl")

rmsnorm_fwd_impl = _get_kernel_impl(ttx_backend_module, "rmsnorm_fwd_impl")
rmsnorm_bwd_impl = _get_kernel_impl(ttx_backend_module, "rmsnorm_bwd_impl")
rmsnorm_infer_impl = _get_kernel_impl(ttx_backend_module, "rmsnorm_infer_impl")
layernorm_infer_impl = _get_kernel_impl(ttx_backend_module, "layernorm_infer_impl")
layernorm_bwd_impl = _get_kernel_impl(ttx_backend_module, "layernorm_bwd_impl")
layernorm_fwd_impl = _get_kernel_impl(ttx_backend_module, "layernorm_fwd_impl")
fused_add_rmsnorm_infer_impl = _get_kernel_impl(ttx_backend_module, "fused_add_rmsnorm_infer_impl")
fused_add_layernorm_infer_impl = _get_kernel_impl(ttx_backend_module, "fused_add_layernorm_infer_impl")

paged_attention_prefill_impl = _get_kernel_impl(ttx_backend_module, "paged_attention_prefill_impl")
paged_attention_prefill_prepare = _get_kernel_impl(ttx_backend_module, "paged_attention_prefill_prepare")
paged_attention_prefill_with_kv_dequant_impl = _get_kernel_impl(ttx_backend_module, "paged_attention_prefill_with_kv_dequant_impl")
paged_attention_decode_impl = _get_kernel_impl(ttx_backend_module, "paged_attention_decode_impl")
paged_attention_decode_with_kv_dequant_impl = _get_kernel_impl(ttx_backend_module, "paged_attention_decode_with_kv_dequant_impl")

fused_linear_cross_entropy_fwd_impl = _get_kernel_impl(ttx_backend_module, "fused_linear_cross_entropy_fwd_impl")
fused_linear_cross_entropy_bwd_impl = _get_kernel_impl(ttx_backend_module, "fused_linear_cross_entropy_bwd_impl")
fused_linear_cross_entropy_1d_fwd_impl = _get_kernel_impl(ttx_backend_module, "fused_linear_cross_entropy_1d_fwd_impl")
fused_linear_cross_entropy_1d_bwd_impl = _get_kernel_impl(ttx_backend_module, "fused_linear_cross_entropy_1d_bwd_impl")

sdpa_infer_impl = _get_kernel_impl(ttx_backend_module, "sdpa_infer_impl")
sdpa_fwd_impl = _get_kernel_impl(ttx_backend_module, "sdpa_fwd_impl")
sdpa_bwd_impl = _get_kernel_impl(ttx_backend_module, "sdpa_bwd_impl")

swa_paged_prefill_impl = _get_kernel_impl(ttx_backend_module, "swa_paged_prefill_impl")
swa_paged_prefill_with_kv_dequant_impl = _get_kernel_impl(ttx_backend_module, "swa_paged_prefill_with_kv_dequant_impl")
swa_paged_decode_impl = _get_kernel_impl(ttx_backend_module, "swa_paged_decode_impl")
swa_paged_decode_quant_impl = _get_kernel_impl(ttx_backend_module, "swa_paged_decode_quant_impl")
swa_infer_impl = _get_kernel_impl(ttx_backend_module, "swa_infer_impl")
swa_fwd_impl = _get_kernel_impl(ttx_backend_module, "swa_fwd_impl")
swa_bwd_impl = _get_kernel_impl(ttx_backend_module, "swa_bwd_impl")

diffusion_attention_fwd_impl = _get_kernel_impl(ttx_backend_module, "diffusion_attention_fwd_impl")
diffusion_attention_bwd_impl = _get_kernel_impl(ttx_backend_module, "diffusion_attention_bwd_impl")

flex_attention_fwd_impl = _get_kernel_impl(ttx_backend_module, "flex_attention_fwd_impl")
flex_attention_bwd_impl = _get_kernel_impl(ttx_backend_module, "flex_attention_bwd_impl")

m_grouped_matmul_impl = _get_kernel_impl(ttx_backend_module, "m_grouped_matmul_impl")
m_grouped_matmul_capturable_impl = _get_kernel_impl(ttx_backend_module, "m_grouped_matmul_capturable_impl")
k_grouped_matmul_impl = _get_kernel_impl(ttx_backend_module, "k_grouped_matmul_impl")

moe_gating_impl = _get_kernel_impl(ttx_backend_module, "moe_gating_impl")
moe_dispatch_impl = _get_kernel_impl(ttx_backend_module, "moe_dispatch_impl")
moe_experts_impl = _get_kernel_impl(ttx_backend_module, "moe_experts_impl")
moe_combine_impl = _get_kernel_impl(ttx_backend_module, "moe_combine_impl")
quant_moe_experts_impl = _get_kernel_impl(ttx_backend_module, "quant_moe_experts_impl")
quant_batch_gemm_reduce_sum_impl = _get_kernel_impl(ttx_backend_module, "quant_batch_gemm_reduce_sum_impl")

int8_gemm_dequant_impl = _get_kernel_impl(ttx_backend_module, "int8_gemm_dequant_impl")
prepare_b_impl = _get_kernel_impl(ttx_backend_module, "prepare_b_impl")

store_paged_kv_impl = _get_kernel_impl(ttx_backend_module, "store_paged_kv_impl")

store_label_cache_infer_impl = _get_kernel_impl(ttx_backend_module, "store_label_cache_infer_impl")

fused_penalties_temp_impl = _get_kernel_impl(ttx_backend_module, "fused_penalties_temp_impl")
relative_embedding_fwd_impl = _get_kernel_impl(ttx_backend_module, "relative_embedding_fwd_impl")
linear_fwd_impl = _get_kernel_impl(ttx_backend_module, "linear_fwd_impl")
join_prob_reject_sampling_impl = _get_kernel_impl(ttx_backend_module, "join_prob_reject_sampling_impl")
reject_sampling_impl = _get_kernel_impl(ttx_backend_module, "reject_sampling_impl")
top_p_filter_impl = _get_kernel_impl(ttx_backend_module, "top_p_filter_impl")
top_p_sampling_impl = _get_kernel_impl(ttx_backend_module, "top_p_sampling_impl")
top_k_sampling_impl = _get_kernel_impl(ttx_backend_module, "top_k_sampling_impl")

group_rmsnorm_impl = _get_kernel_impl(ttx_backend_module, "group_rmsnorm_impl")

# Over-Encoding (OE)
embedding_nf4_dequant_impl = _get_kernel_impl(ttx_backend_module, "embedding_nf4_dequant_impl")
n_gram_decode_impl = _get_kernel_impl(ttx_backend_module, "n_gram_decode_impl")
n_gram_prefill_impl = _get_kernel_impl(ttx_backend_module, "n_gram_prefill_impl")
over_encoding_decode_impl = _get_kernel_impl(ttx_backend_module, "over_encoding_decode_impl")

allgather_gemm_impl = _get_kernel_impl(ttx_backend_module, "allgather_gemm_impl")
allgather_gemm_peer_mem_size = _get_kernel_impl(ttx_backend_module, "allgather_gemm_peer_mem_size")
gemm_allreduce_impl = _get_kernel_impl(ttx_backend_module, "gemm_allreduce_impl")
gemm_allreduce_peer_mem_size = _get_kernel_impl(ttx_backend_module, "gemm_allreduce_peer_mem_size")
gemm_reduce_scatter_impl = _get_kernel_impl(ttx_backend_module, "gemm_reduce_scatter_impl")
gemm_reduce_scatter_peer_mem_size = _get_kernel_impl(ttx_backend_module, "gemm_reduce_scatter_peer_mem_size")

if os.getenv("MOJO_RUN_MODE", "EAGER") == "COMPILE":
    assert torch.version.__version__ >= "2.7.0", "Work with torch.compile request your torch version >= 2.7.0"

    # =====================================
    # Register GELU
    # =====================================

    @torch.library.custom_op("ttx::gelu", mutates_args={})
    def gelu_fwd(x: torch.Tensor) -> torch.Tensor:
        return gelu_fwd_impl(x)

    @gelu_fwd.register_fake
    def gelu_fwd_fake(x: torch.tensor) -> torch.Tensor:
        return torch.empty_like(x)

    @torch.library.custom_op("ttx::gelu_bwd", mutates_args={})
    def gelu_bwd(
        dy: torch.Tensor,
        x: torch.Tensor,
    ) -> torch.Tensor:
        return gelu_bwd_impl(dy, x)

    @gelu_bwd.register_fake
    def gelu_bwd_fake(
        dy: torch.Tensor,
        x: torch.Tensor,
    ) -> torch.Tensor:
        return torch.empty_like(dy)

    # =====================================
    # Register SiLU
    # =====================================

    @torch.library.custom_op("ttx::silu", mutates_args={})
    def silu_fwd(x: torch.Tensor) -> torch.Tensor:
        return silu_fwd_impl(x)

    @silu_fwd.register_fake
    def silu_fwd_fake(x: torch.Tensor) -> torch.Tensor:
        return torch.empty_like(x)

    @torch.library.custom_op("ttx::silu_bwd", mutates_args={})
    def silu_bwd(
        dy: torch.Tensor,
        x: torch.Tensor,
    ) -> torch.Tensor:
        return silu_bwd_impl(dy, x)

    @silu_bwd.register_fake
    def silu_bwd_fake(
        dy: torch.Tensor,
        x: torch.Tensor,
    ) -> torch.Tensor:
        return torch.empty_like(dy)

    # ====================================
    # Register SwiGLU
    # ====================================

    @torch.library.custom_op("ttx::swiglu", mutates_args={})
    def swiglu_fwd(
        a: torch.Tensor,
        b: torch.Tensor,
    ) -> torch.Tensor:
        return swiglu_fwd_impl(a, b)

    @swiglu_fwd.register_fake
    def swiglu_fwd_fake(
        a: torch.Tensor,
        b: torch.Tensor,
    ) -> torch.Tensor:
        return torch.empty_like(a)

    @torch.library.custom_op("ttx::swiglu_bwd", mutates_args={})
    def swiglu_bwd(
        dc: torch.Tensor,
        a: torch.Tensor,
        b: torch.Tensor,
    ) -> Tuple[torch.Tensor, torch.Tensor]:
        return swiglu_bwd_impl(dc, a, b)

    @swiglu_bwd.register_fake
    def swiglu_bwd_fake(
        dc: torch.Tensor,
        a: torch.Tensor,
        b: torch.Tensor,
    ) -> Tuple[torch.Tensor, torch.Tensor]:
        return torch.empty_like(dc), torch.empty_like(dc)

    # ====================================
    # Register lightning_indexer
    # ====================================

    @torch.library.custom_op("ttx::lightning_indexer", mutates_args={})
    def lightning_indexer(
        query: torch.Tensor,
        query_scale: torch.Tensor,
        key: torch.Tensor,
        key_scale: Optional[torch.Tensor] = None,
    ) -> torch.Tensor:
        return lightning_indexer_impl(query, query_scale, key, key_scale)

    @lightning_indexer.register_fake
    def lightning_indexer_fake(
        query: torch.Tensor,
        query_scale: torch.Tensor,
        key: torch.Tensor,
        key_scale: Optional[torch.Tensor] = None,
    ) -> torch.Tensor:
        batch_size, q_seq_len, _, _ = query.shape
        k_seq_len = key.shape[1]
        return torch.empty(batch_size, q_seq_len, k_seq_len, dtype=torch.float32, device=query.device)

    # ====================================
    # Register Attention
    # ====================================

    @torch.library.custom_op("ttx::paged_attention_prefill", mutates_args={})
    def paged_attention_prefill(
        q: torch.Tensor,
        key_cache: torch.Tensor,
        value_cache: torch.Tensor,
        cu_q_lens: torch.Tensor,
        seqlens_kv: torch.Tensor,
        block_tables: torch.Tensor,
        gqa_interleave: bool,
        task_b: Optional[torch.Tensor] = None,
        task_q_block: Optional[torch.Tensor] = None,
        task_q_head: Optional[torch.Tensor] = None,
        core_task_offsets: Optional[torch.Tensor] = None,
        softmax_scale: Optional[float] = None,
        max_q_len: Optional[int] = None,
        max_total_seq_len: Optional[int] = None,
    ) -> torch.Tensor:
        if get_platform() == "npu":
            return paged_attention_prefill_impl(
                q, key_cache, value_cache, cu_q_lens, seqlens_kv, block_tables, gqa_interleave,
                task_b=task_b,
                task_q_block=task_q_block,
                task_q_head=task_q_head,
                core_task_offsets=core_task_offsets,
                softmax_scale=softmax_scale,
                max_q_len=max_q_len,
                max_total_seq_len=max_total_seq_len,

            )
        else:
            return paged_attention_prefill_impl(
                q, key_cache, value_cache, cu_q_lens, seqlens_kv, block_tables, gqa_interleave,
                softmax_scale=softmax_scale,
                max_q_len=max_q_len,
                max_total_seq_len=max_total_seq_len,
            )

    @paged_attention_prefill.register_fake
    def paged_attention_prefill_fake(
        q: torch.Tensor,
        key_cache: torch.Tensor,
        value_cache: torch.Tensor,
        cu_q_lens: torch.Tensor,
        seqlens_kv: torch.Tensor,
        block_tables: torch.Tensor,
        gqa_interleave: bool,
        task_b: Optional[torch.Tensor] = None,
        task_q_block: Optional[torch.Tensor] = None,
        task_q_head: Optional[torch.Tensor] = None,
        core_task_offsets: Optional[torch.Tensor] = None,
        softmax_scale: Optional[float] = None,
        max_q_len: Optional[int] = None,
        max_total_seq_len: Optional[int] = None,
    ) -> torch.Tensor:
        return torch.empty_like(q)

    @torch.library.custom_op("ttx::paged_attention_prefill_with_kv_dequant", mutates_args={})
    def paged_attention_prefill_with_kv_dequant(
        q: torch.Tensor,
        key_cache: torch.Tensor,
        k_qscale: torch.Tensor,
        value_cache: torch.Tensor,
        v_qscale: torch.Tensor,
        cu_seqlens_q: torch.Tensor,
        seqlens_kv: torch.Tensor,
        block_tables: torch.Tensor,
        gqa_interleave: bool,
        softmax_scale: Optional[float] = None,
        max_seqlen_q: Optional[int] = None,
        max_seqlen_k: Optional[int] = None,
    ) -> torch.Tensor:
        return paged_attention_prefill_with_kv_dequant_impl(
            q, key_cache, k_qscale, value_cache, v_qscale,
            cu_seqlens_q, seqlens_kv, block_tables, gqa_interleave, softmax_scale,
            max_seqlen_q=max_seqlen_q,
            max_seqlen_k=max_seqlen_k,
        )

    @paged_attention_prefill_with_kv_dequant.register_fake
    def paged_attention_prefill_with_kv_dequant_fake(
        q: torch.Tensor,
        key_cache: torch.Tensor,
        k_qscale: torch.Tensor,
        value_cache: torch.Tensor,
        v_qscale: torch.Tensor,
        cu_seqlens_q: torch.Tensor,
        seqlens_kv: torch.Tensor,
        block_tables: torch.Tensor,
        gqa_interleave: bool,
        task_b: Optional[torch.Tensor] = None,
        task_q_block: Optional[torch.Tensor] = None,
        task_q_head: Optional[torch.Tensor] = None,
        core_task_offsets: Optional[torch.Tensor] = None,
        softmax_scale: Optional[float] = None,
        max_seqlen_q: Optional[int] = None,
        max_seqlen_k: Optional[int] = None,
    ) -> torch.Tensor:
        return torch.empty_like(q)

    @torch.library.custom_op("ttx::paged_attention_decode", mutates_args={})
    def paged_attention_decode(
        q: torch.Tensor,
        key_cache: torch.Tensor,
        value_cache: torch.Tensor,
        seqlens: torch.Tensor,
        block_tables: torch.Tensor,
        gqa_interleave: bool,
        softmax_scale: Optional[float] = None,
    ) -> torch.Tensor:
        return paged_attention_decode_impl(
            q, key_cache, value_cache, seqlens, block_tables, gqa_interleave, softmax_scale
        )

    @paged_attention_decode.register_fake
    def paged_attention_decode_fake(
        q: torch.Tensor,
        key_cache: torch.Tensor,
        value_cache: torch.Tensor,
        seqlens: torch.Tensor,
        block_tables: torch.Tensor,
        gqa_interleave: bool,
        softmax_scale: Optional[float] = None,
    ) -> torch.Tensor:
        return torch.empty_like(q)

    # ====================================
    # Register Rope
    # ====================================
    @torch.library.custom_op("ttx::rot_pos_embed", mutates_args={})
    def rot_pos_embed(
        x: torch.Tensor,
        cos: torch.Tensor,
        sin: torch.Tensor,
        cu_q_lens: Optional[torch.Tensor] = None,
        seqlens_kv: Optional[torch.Tensor] = None,
        position_ids: Optional[torch.Tensor] = None,
    ) -> Tuple[torch.Tensor, torch.Tensor]:
        return rot_pos_embed_impl(x, cos, sin, cu_q_lens, seqlens_kv, position_ids)

    @rot_pos_embed.register_fake
    def rot_pos_embed_fake(
        x: torch.Tensor,
        cos: torch.Tensor,
        sin: torch.Tensor,
        cu_q_lens: Optional[torch.Tensor] = None,
        seqlens_kv: Optional[torch.Tensor] = None,
        position_ids: Optional[torch.Tensor] = None,
    ) -> Tuple[torch.Tensor, torch.Tensor]:
        if cu_q_lens is None and position_ids is None:
            # padded prefill scenario
            seq_dim = x.shape[1]
        else:
            seq_dim = x.shape[0]
        rope_dim = cos.shape[-1]
        return torch.empty((seq_dim, rope_dim), device=x.device, dtype=torch.float32), torch.empty((seq_dim, rope_dim), device=x.device, dtype=torch.float32)

    @torch.library.custom_op("ttx::rope", mutates_args={})
    def rope_fwd(
        q: torch.Tensor,
        k: torch.Tensor,
        cos: torch.Tensor,
        sin: torch.Tensor,
        head_first: bool = True,
        keep_cos_sin_dtype: bool = False,
    ) -> Tuple[torch.Tensor, torch.Tensor]:
        return rope_fwd_impl(q, k, cos, sin, head_first, keep_cos_sin_dtype)

    @rope_fwd.register_fake
    def rope_fwd_fake(
        q: torch.Tensor,
        k: torch.Tensor,
        cos: torch.Tensor,
        sin: torch.Tensor,
        head_first: bool = True,
        keep_cos_sin_dtype: bool = False,
    ) -> Tuple[torch.Tensor, torch.Tensor]:
        return torch.empty_like(q), torch.empty_like(k)

    @torch.library.custom_op("ttx::rope_bwd", mutates_args={})
    def rope_bwd(
        dq: torch.Tensor,
        dk: torch.Tensor,
        cos: torch.Tensor,
        sin: torch.Tensor,
        head_first: bool = True,
    ) -> Tuple[torch.Tensor, torch.Tensor]:
        return rope_bwd_impl(dq, dk, cos, sin, head_first)

    @rope_bwd.register_fake
    def rope_bwd_fake(
        dq: torch.Tensor,
        dk: torch.Tensor,
        cos: torch.Tensor,
        sin: torch.Tensor,
        head_first: bool = True,
    ) -> Tuple[torch.Tensor, torch.Tensor]:
        return torch.empty_like(dq), torch.empty_like(dk)

    # ====================================
    # Register Quant
    # ====================================

    @torch.library.custom_op("ttx::dynamic_quant", mutates_args={})
    def dynamic_quant(
        input_tensor: torch.Tensor,
        scale_tensor: Optional[torch.Tensor],
    ) -> Tuple[torch.Tensor, torch.Tensor]:
        return dynamic_quant_impl(input_tensor, scale_tensor)

    @dynamic_quant.register_fake
    def dynamic_quant_fake(
        input_tensor: torch.Tensor,
        scale_tensor: Optional[torch.Tensor],
    ) -> Tuple[torch.Tensor, torch.Tensor]:
        return (
            torch.empty_like(input_tensor, dtype=torch.int8),
            torch.empty((*input_tensor.shape[:-1], 1), dtype=torch.float32, device=input_tensor.device),
        )

    @torch.library.custom_op("ttx::static_quant", mutates_args={})
    def static_quant(
        input_tensor: torch.Tensor,
        scale: torch.Tensor,
        q_min: int = -128,
        q_max: int = 127,
    ) -> torch.Tensor:
        return static_quant_impl(input_tensor, scale, q_min, q_max)

    @static_quant.register_fake
    def static_quant_fake(
        input_tensor: torch.Tensor,
        scale: torch.Tensor,
        q_min: int = -128,
        q_max: int = 127,
    ) -> torch.Tensor:
        return torch.empty_like(input_tensor, dtype=torch.int8)

    @torch.library.custom_op("ttx::dequant", mutates_args={})
    def dequant(
        input_tensor: torch.Tensor,
        scale: torch.Tensor,
        output_dtype: torch.dtype,
    ) -> torch.Tensor:
        return dequant_impl(input_tensor, scale, output_dtype)

    @dequant.register_fake
    def dequant_fake(
        input_tensor: torch.Tensor,
        scale: torch.Tensor,
        output_dtype: torch.dtype,
    ) -> torch.Tensor:
        return torch.empty_like(input_tensor, dtype=output_dtype)

    # ====================================
    # Register rmsnorm
    # ====================================

    @torch.library.custom_op("ttx::rmsnorm_infer", mutates_args={})
    def rmsnorm_infer(
        x: torch.Tensor,
        w: torch.Tensor,
        eps: float,
    ) -> torch.Tensor:
        return rmsnorm_infer_impl(x, w, eps)

    @rmsnorm_infer.register_fake
    def rmsnorm_infer_fake(
        x: torch.Tensor,
        w: torch.Tensor,
        eps: float,
    ) -> torch.Tensor:
        return torch.empty_like(x)

    @torch.library.custom_op("ttx::rmsnorm_fwd", mutates_args={})
    def rmsnorm_fwd(
        X: torch.Tensor,
        W: torch.Tensor,
        eps: float,
        offset: float,
        casting_mode_int: int,
    ) -> Tuple[torch.Tensor, torch.Tensor]:
        return rmsnorm_fwd_impl(X, W, eps, offset, casting_mode_int)

    @rmsnorm_fwd.register_fake
    def rmsnorm_fwd_fake(
        X: torch.Tensor,
        W: torch.Tensor,
        eps: float,
        offset: float,
        casting_mode_int: int,
    ) -> Tuple[torch.Tensor, torch.Tensor]:
        Y = torch.empty_like(X)
        X_2d = X.reshape(-1, X.shape[-1])

        rstd_dtype = torch.float32 if casting_mode_int in (0, 1) else X.dtype  # fp32 @llama or @gemma
        RSTD = torch.empty(X_2d.shape[0], dtype=rstd_dtype, device=X.device)
        return Y, RSTD

    @torch.library.custom_op("ttx::rmsnorm_bwd", mutates_args={})
    def rmsnorm_bwd(
        dY: torch.Tensor,
        X: torch.Tensor,
        W: torch.Tensor,
        RSTD: torch.Tensor,
        offset: float,
        casting_mode_int: int,
        X_dtype: torch.dtype,
    ) -> Tuple[torch.Tensor, torch.Tensor]:
        return rmsnorm_bwd_impl(dY, X, W, RSTD, offset, casting_mode_int, X_dtype)

    @rmsnorm_bwd.register_fake
    def rmsnorm_bwd_fake(
        dY: torch.Tensor,
        X: torch.Tensor,
        W: torch.Tensor,
        RSTD: torch.Tensor,
        offset: float,
        casting_mode_int: int,
        X_dtype: torch.dtype,
    ) -> Tuple[torch.Tensor, torch.Tensor]:
        dX = torch.empty_like(X)
        dW = torch.empty(dY.shape[-1], dtype=W.dtype, device=W.device)
        return dX, dW

    # ====================================
    # Register fused_linear_cross_entropy
    # ====================================

    @torch.library.custom_op("ttx::fused_linear_cross_entropy", mutates_args={})
    def fused_linear_cross_entropy_fwd(
        _input: torch.Tensor,
        weight: torch.Tensor,
        target: torch.Tensor,
        ce_weight: Optional[torch.Tensor] = None,
        bias: Optional[torch.Tensor] = None,
        ignore_index: int = -100,
        lse_square_scale: float = 0.0,
        label_smoothing: float = 0.0,
        reduction: str = "mean",
        softcap: Optional[float] = None,
        return_z_loss: bool = False,
        accum_dtype: Optional[torch.dtype] = None,
    ) -> Tuple[torch.Tensor, torch.Tensor, torch.Tensor, torch.Tensor, torch.Tensor]:
        return fused_linear_cross_entropy_fwd_impl(
            _input,
            weight,
            target,
            ce_weight,
            bias,
            ignore_index,
            lse_square_scale,
            label_smoothing,
            reduction,
            softcap,
            return_z_loss,
            accum_dtype,
        )

    @fused_linear_cross_entropy_fwd.register_fake
    def fused_linear_cross_entropy_fwd_fake(
        _input: torch.Tensor,
        weight: torch.Tensor,
        target: torch.Tensor,
        ce_weight: Optional[torch.Tensor] = None,
        bias: Optional[torch.Tensor] = None,
        ignore_index: int = -100,
        lse_square_scale: float = 0.0,
        label_smoothing: float = 0.0,
        reduction: str = "mean",
        softcap: Optional[float] = None,
        return_z_loss: bool = False,
        accum_dtype: Optional[torch.dtype] = None,
    ) -> Tuple[torch.Tensor, torch.Tensor, torch.Tensor, torch.Tensor, torch.Tensor]:
        loss = torch.empty((), dtype=torch.float32, device=_input.device)

        z_loss = None
        if return_z_loss:
            z_loss = torch.empty((), dtype=_input.dtype, device=_input.device)

        grad_input = torch.empty_like(_input)

        grad_weight = None
        if weight.requires_grad:
            grad_weight = torch.empty_like(weight)

        grad_bias = None
        if bias is not None:
            grad_bias = torch.empty_like(bias)

        return loss, z_loss, grad_input, grad_weight, grad_bias

    # NOTE: Since custom_op does not support input/output aliasing, we register the
    # operator manually using torch.library.impl.
    fused_linear_cross_entropy_bwd_schema = (
        "(Tensor grad_output, Tensor(a!) grad_input, "
        "Tensor(a!)? grad_weight=None, Tensor(a!)? grad_bias=None) -> "
        "(Tensor(a) grad_input, Tensor(a)? grad_weight, Tensor(a)? grad_bias)"
    )
    torch.library.define("ttx::fused_linear_cross_entropy_bwd", fused_linear_cross_entropy_bwd_schema)

    @torch.library.impl("ttx::fused_linear_cross_entropy_bwd", "default")
    def _fused_linear_cross_entropy_bwd(
        grad_output: torch.Tensor,
        grad_input: torch.Tensor,
        grad_weight: Optional[torch.Tensor] = None,
        grad_bias: Optional[torch.Tensor] = None,
    ) -> Tuple[torch.Tensor, torch.Tensor, torch.Tensor]:
        return fused_linear_cross_entropy_bwd_impl(grad_output, grad_input, grad_weight, grad_bias)

    @torch.library.register_fake("ttx::fused_linear_cross_entropy_bwd")
    def fused_linear_cross_entropy_bwd_meta(
        grad_output: torch.Tensor,
        grad_input: torch.Tensor,
        grad_weight: Optional[torch.Tensor] = None,
        grad_bias: Optional[torch.Tensor] = None,
    ) -> Tuple[torch.Tensor, torch.Tensor, torch.Tensor]:
        return grad_input, grad_weight, grad_bias

    fused_linear_cross_entropy_bwd = torch.ops.ttx.fused_linear_cross_entropy_bwd

    @torch.library.custom_op("ttx::fused_linear_cross_entropy_1d", mutates_args={})
    def fused_linear_cross_entropy_1d_fwd(
        _input: torch.Tensor,
        weight: torch.Tensor,
        target: torch.Tensor,
        ce_weight: Optional[torch.Tensor] = None,
        bias: Optional[torch.Tensor] = None,
        ignore_index: int = -100,
        lse_square_scale: float = 0.0,
        label_smoothing: float = 0.0,
        softcap: Optional[float] = None,
        return_z_loss: bool = False,
    ) -> Tuple[torch.Tensor, torch.Tensor]:
        return fused_linear_cross_entropy_1d_fwd_impl(
            _input,
            weight,
            target,
            ce_weight,
            bias,
            ignore_index,
            lse_square_scale,
            label_smoothing,
            softcap,
            return_z_loss,
        )

    @fused_linear_cross_entropy_1d_fwd.register_fake
    def fused_linear_cross_entropy_1d_fwd_fake(
        _input: torch.Tensor,
        weight: torch.Tensor,
        target: torch.Tensor,
        ce_weight: Optional[torch.Tensor] = None,
        bias: Optional[torch.Tensor] = None,
        ignore_index: int = -100,
        lse_square_scale: float = 0.0,
        label_smoothing: float = 0.0,
        softcap: Optional[float] = None,
        return_z_loss: bool = False,
    ) -> Tuple[torch.Tensor, torch.Tensor]:
        loss = torch.empty((_input.shape[0],), dtype=torch.float32, device=_input.device)

        z_loss = None
        if return_z_loss:
            z_loss = torch.empty((_input.shape[0],), dtype=_input.dtype, device=_input.device)

        return loss, z_loss

    @torch.library.custom_op("ttx::fused_linear_cross_entropy_1d_bwd", mutates_args={})
    def fused_linear_cross_entropy_1d_bwd(
        grad_output: torch.Tensor,
        _input: torch.Tensor,
        weight: torch.Tensor,
        target: torch.Tensor,
        ce_weight: Optional[torch.Tensor] = None,
        bias: Optional[torch.Tensor] = None,
        ignore_index: int = -100,
        lse_square_scale: float = 0.0,
        label_smoothing: float = 0.0,
        softcap: Optional[float] = None,
        accum_dtype: Optional[torch.dtype] = None,
    ) -> Tuple[torch.Tensor, torch.Tensor, torch.Tensor]:
        return fused_linear_cross_entropy_1d_bwd_impl(
            grad_output,
            _input,
            weight,
            target,
            ce_weight,
            bias,
            ignore_index,
            lse_square_scale,
            label_smoothing,
            softcap,
            accum_dtype,
        )

    @fused_linear_cross_entropy_1d_bwd.register_fake
    def fused_linear_cross_entropy_1d_bwd_fake(
        grad_output: torch.Tensor,
        _input: torch.Tensor,
        weight: torch.Tensor,
        target: torch.Tensor,
        ce_weight: Optional[torch.Tensor] = None,
        bias: Optional[torch.Tensor] = None,
        ignore_index: int = -100,
        lse_square_scale: float = 0.0,
        label_smoothing: float = 0.0,
        softcap: Optional[float] = None,
        accum_dtype: Optional[torch.dtype] = None,
    ) -> Tuple[torch.Tensor, torch.Tensor, torch.Tensor, torch.Tensor, torch.Tensor]:
        grad_input = torch.empty_like(_input)

        grad_weight = None
        if weight is not None:
            grad_weight = torch.empty_like(weight)

        grad_bias = None
        if bias is not None:
            grad_bias = torch.empty_like(bias)

        return grad_input, grad_weight, grad_bias

    # ====================================
    # Register Group gemm
    # ====================================

    @torch.library.custom_op("ttx::m_grouped_matmul", mutates_args={})
    def m_grouped_matmul(
        A: torch.Tensor,
        B: torch.Tensor,
        C: torch.Tensor,
        size_per_group: torch.Tensor,
        num_groups: int,
        M: int,
        N: int,
        K: int,
        strideBN: int,
        strideBK: int,
        trans_b: bool = False,
    ) -> torch.Tensor:
        return m_grouped_matmul_impl(
            A,
            B,
            C,
            size_per_group,
            num_groups,
            M,
            N,
            K,
            strideBN,
            strideBK,
            trans_b,
        )

    @m_grouped_matmul.register_fake
    def m_grouped_matmul_fake(
        A: torch.Tensor,
        B: torch.Tensor,
        C: torch.Tensor,
        size_per_group: torch.Tensor,
        num_groups: int,
        M: int,
        N: int,
        K: int,
        strideBN: int,
        strideBK: int,
        trans_b: bool = False,
    ) -> torch.Tensor:
        return torch.empty_like(C)

    @torch.library.custom_op("ttx::m_grouped_matmul_capturable", mutates_args={})
    def m_grouped_matmul_capturable(
        A: torch.Tensor,
        B: torch.Tensor,
        C: torch.Tensor,
        size_per_group: torch.Tensor,
        num_groups: int,
        M: int,
        N: int,
        K: int,
        strideBN: int,
        strideBK: int,
        trans_b: bool = False,
    ) -> torch.Tensor:
        return m_grouped_matmul_capturable_impl(
            A,
            B,
            C,
            size_per_group,
            num_groups,
            M,
            N,
            K,
            strideBN,
            strideBK,
            trans_b,
        )

    @m_grouped_matmul_capturable.register_fake
    def m_grouped_matmul_capturable_fake(
        A: torch.Tensor,
        B: torch.Tensor,
        C: torch.Tensor,
        size_per_group: torch.Tensor,
        num_groups: int,
        M: int,
        N: int,
        K: int,
        strideBN: int,
        strideBK: int,
        trans_b: bool = False,
    ) -> torch.Tensor:
        return torch.empty_like(C)

    @torch.library.custom_op("ttx::k_grouped_matmul", mutates_args={})
    def k_grouped_matmul(
        A: torch.Tensor,
        B: torch.Tensor,
        C: torch.Tensor,
        size_per_group: torch.Tensor,
        num_groups: int,
        M: int,
        N: int,
    ) -> torch.Tensor:
        return k_grouped_matmul_impl(
            A,
            B,
            C,
            size_per_group,
            num_groups,
            M,
            N,
        )

    @k_grouped_matmul.register_fake
    def k_grouped_matmul_fake(
        A: torch.Tensor,
        B: torch.Tensor,
        C: torch.Tensor,
        size_per_group: torch.Tensor,
        num_groups: int,
        M: int,
        N: int,
    ) -> torch.Tensor:
        return torch.empty_like(C)

    # ====================================
    # Register int8 gemm dequant
    # ====================================
    @torch.library.custom_op("ttx::int8_gemm_dequant", mutates_args={})
    def int8_gemm_dequant(
        a: torch.Tensor,
        b: torch.Tensor,
        input_scale: torch.Tensor,
        weight_scale: torch.Tensor,
        bias: torch.Tensor,
        M: int,
        N: int,
        output_dtype: torch.dtype,
    ) -> torch.Tensor:
        return int8_gemm_dequant_impl(
            a,
            b,
            input_scale,
            weight_scale,
            bias,
            M,
            N,
            output_dtype,
        )

    @int8_gemm_dequant.register_fake
    def int8_gemm_dequant_fake(
        a: torch.Tensor,
        b: torch.Tensor,
        input_scale: torch.Tensor,
        weight_scale: torch.Tensor,
        bias: torch.Tensor,
        M: int,
        N: int,
        output_dtype: torch.dtype,
    ) -> torch.Tensor:
        return torch.zeros((M, N), dtype=output_dtype, device=a.device)

    @torch.library.custom_op("ttx::prepare_b", mutates_args={})
    def prepare_b(
        b: torch.Tensor,
    ) -> torch.Tensor:
        return prepare_b_impl(
            b,
        )

    @prepare_b.register_fake
    def prepare_b_fake(
        b: torch.Tensor,
    ) -> torch.Tensor:
        return torch.empty_like(b.T)

    # ====================================
    # Register Store KV
    # ====================================

    @torch.library.custom_op("ttx::store_paged_kv", mutates_args={})
    def store_paged_kv(
        key_states: torch.Tensor,
        value_states: torch.Tensor,
        key_cache: torch.Tensor,
        value_cache: torch.Tensor,
        chunk_metadata: torch.Tensor,
    ) -> Tuple[torch.Tensor, torch.Tensor]:
        return store_paged_kv_impl(
            key_states,
            value_states,
            key_cache,
            value_cache,
            chunk_metadata,
        )

    @store_paged_kv.register_fake
    def store_paged_kv_fake(
        key_states: torch.Tensor,
        value_states: torch.Tensor,
        key_cache: torch.Tensor,
        value_cache: torch.Tensor,
        chunk_metadata: torch.Tensor,
    ) -> Tuple[torch.Tensor, torch.Tensor]:
        return torch.empty_like(key_cache), torch.empty_like(value_cache)

    # TODO(zhangjihang): Support compile mode
    sdpa_infer = sdpa_infer_impl
    paged_attention_decode_with_kv_dequant = paged_attention_decode_with_kv_dequant_impl
    swa_paged_prefill = swa_paged_prefill_impl
    swa_paged_prefill_with_kv_dequant = swa_paged_prefill_with_kv_dequant_impl
    swa_paged_decode = swa_paged_decode_impl
    swa_paged_decode_quant = swa_paged_decode_quant_impl
    swa_infer = swa_infer_impl
    swa_fwd = swa_fwd_impl
    swa_bwd = swa_bwd_impl
    group_rmsnorm = group_rmsnorm_impl
    embedding_nf4_dequant = embedding_nf4_dequant_impl
    n_gram_decode = n_gram_decode_impl
    n_gram_prefill = n_gram_prefill_impl
    over_encoding_decode = over_encoding_decode_impl
    allgather_gemm = allgather_gemm_impl
    gemm_allreduce = gemm_allreduce_impl
    gemm_reduce_scatter = gemm_reduce_scatter_impl

else:
    causal_conv1d_fwd = causal_conv1d_fwd_impl
    causal_conv1d_bwd = causal_conv1d_bwd_impl
    causal_conv1d_update_bdt = causal_conv1d_update_bdt_impl
    gelu_fwd = gelu_fwd_impl
    gelu_bwd = gelu_bwd_impl
    silu_fwd = silu_fwd_impl
    silu_bwd = silu_bwd_impl
    swiglu_fwd = swiglu_fwd_impl
    swiglu_bwd = swiglu_bwd_impl
    paged_attention_prefill = paged_attention_prefill_impl
    paged_attention_prefill_with_kv_dequant = paged_attention_prefill_with_kv_dequant_impl
    paged_attention_decode = paged_attention_decode_impl
    paged_attention_decode_with_kv_dequant = paged_attention_decode_with_kv_dequant_impl
    rot_pos_embed = rot_pos_embed_impl
    rope_fwd = rope_fwd_impl
    rope_bwd = rope_bwd_impl
    vision_rot_pos_embed = vision_rot_pos_embed_impl
    vision_rope_apply = vision_rope_apply_impl
    rmsnorm_fwd = rmsnorm_fwd_impl
    rmsnorm_bwd = rmsnorm_bwd_impl
    rmsnorm_infer = rmsnorm_infer_impl
    layernorm_fwd = layernorm_fwd_impl
    layernorm_bwd = layernorm_bwd_impl
    layernorm_infer = layernorm_infer_impl
    fused_add_rmsnorm_infer = fused_add_rmsnorm_infer_impl
    fused_add_layernorm_infer = fused_add_layernorm_infer_impl
    fused_linear_cross_entropy_fwd = fused_linear_cross_entropy_fwd_impl
    fused_linear_cross_entropy_bwd = fused_linear_cross_entropy_bwd_impl
    fused_linear_cross_entropy_1d_fwd = fused_linear_cross_entropy_1d_fwd_impl
    fused_linear_cross_entropy_1d_bwd = fused_linear_cross_entropy_1d_bwd_impl
    sdpa_infer = sdpa_infer_impl
    sdpa_fwd = sdpa_fwd_impl
    sdpa_bwd = sdpa_bwd_impl
    swa_paged_prefill = swa_paged_prefill_impl
    swa_paged_prefill_with_kv_dequant = swa_paged_prefill_with_kv_dequant_impl
    swa_paged_decode = swa_paged_decode_impl
    swa_paged_decode_quant = swa_paged_decode_quant_impl
    swa_infer = swa_infer_impl
    swa_fwd = swa_fwd_impl
    swa_bwd = swa_bwd_impl
    diffusion_attention_fwd = diffusion_attention_fwd_impl
    diffusion_attention_bwd = diffusion_attention_bwd_impl
    flex_attention_fwd = flex_attention_fwd_impl
    flex_attention_bwd = flex_attention_bwd_impl
    m_grouped_matmul = m_grouped_matmul_impl
    m_grouped_matmul_capturable = m_grouped_matmul_capturable_impl
    k_grouped_matmul = k_grouped_matmul_impl
    moe_gating = moe_gating_impl
    moe_dispatch = moe_dispatch_impl
    moe_experts = moe_experts_impl
    moe_combine = moe_combine_impl
    quant_moe_experts = quant_moe_experts_impl
    int8_gemm_dequant = int8_gemm_dequant_impl
    prepare_b = prepare_b_impl
    store_paged_kv = store_paged_kv_impl
    store_label_cache_infer = store_label_cache_infer_impl
    fused_penalties_temp = fused_penalties_temp_impl
    join_prob_reject_sampling = join_prob_reject_sampling_impl
    reject_sampling = reject_sampling_impl
    top_p_filter = top_p_filter_impl
    top_p_sampling = top_p_sampling_impl
    top_k_sampling = top_k_sampling_impl
    dynamic_quant = dynamic_quant_impl
    static_quant = static_quant_impl
    dequant = dequant_impl
    lightning_indexer = lightning_indexer_impl
    group_rmsnorm = group_rmsnorm_impl
    embedding_nf4_dequant = embedding_nf4_dequant_impl
    n_gram_decode = n_gram_decode_impl
    n_gram_prefill = n_gram_prefill_impl
    over_encoding_decode = over_encoding_decode_impl
    allgather_gemm = allgather_gemm_impl
    gemm_allreduce = gemm_allreduce_impl
    gemm_reduce_scatter = gemm_reduce_scatter_impl

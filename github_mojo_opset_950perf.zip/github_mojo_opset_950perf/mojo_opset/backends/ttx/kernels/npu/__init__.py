from . import _dispatch  # noqa: F401  populates sys.modules with per-SoC dispatched kernels

from .convolution import causal_conv1d_bwd_impl
from .convolution import causal_conv1d_fwd_impl
from .convolution import causal_conv1d_update_bdt_impl
from .diffution_attention import diffusion_attention_bwd_impl
from .diffution_attention import diffusion_attention_fwd_impl
from .flex_attention import flex_attention_bwd_impl
from .flex_attention import flex_attention_fwd_impl
from .flex_attention import _build_packed_block_mask_streaming
from .flex_attention import create_block_mask_patched
from .flex_attention import triton_create_mask
from .flex_attention import MASK_BLOCK_SIZE
from .flash_attention import paged_attention_decode_impl
from .flash_attention import paged_attention_prefill_impl
from .flash_attention import paged_attention_prefill_prepare
from .fused_add_layernorm import fused_add_layernorm_infer_impl
from .fused_add_rmsnorm import fused_add_rmsnorm_infer_impl
from .group_rmsnorm import group_rmsnorm_impl
from .fused_linear_cross_entropy import fused_linear_cross_entropy_1d_bwd_impl
from .fused_linear_cross_entropy import fused_linear_cross_entropy_1d_fwd_impl
from .fused_linear_cross_entropy import fused_linear_cross_entropy_bwd_impl
from .fused_linear_cross_entropy import fused_linear_cross_entropy_fwd_impl
from .gelu import gelu_bwd_impl
from .gelu import gelu_fwd_impl
from .group_gemm import k_grouped_matmul_impl
from .group_gemm import m_grouped_matmul_impl
from .kv_cache import store_paged_kv_impl
from .layernorm import layernorm_bwd_impl
from .layernorm import layernorm_fwd_impl
from .layernorm import layernorm_infer_impl
from .lightning_indexer import lightning_indexer_impl
from .quant import dynamic_quant_impl
from .quant import static_quant_impl
from .quant import dequant_impl
from .rmsnorm import rmsnorm_bwd_impl
from .rmsnorm import rmsnorm_fwd_impl
from .rmsnorm import rmsnorm_infer_impl
from .rope import rot_pos_embed_impl
from .rope import rope_bwd_impl
from .rope import rope_fwd_impl
from .vision_rope import vision_rope_apply_impl
from .vision_rope import vision_rot_pos_embed_impl
from .mrope import mrope_fwd_impl
from .sample import fused_penalties_temp_impl
from .sample import join_prob_reject_sampling_impl
from .sample import reject_sampling_impl
from .sample import top_k_sampling_impl
from .sample import top_p_filter_impl
from .sample import top_p_sampling_impl
from .sdpa import sdpa_bwd_impl
from .sdpa import sdpa_fwd_impl
from .sdpa import sdpa_infer_impl
from .silu import silu_bwd_impl
from .silu import silu_fwd_impl
from .store_lowrank import store_label_cache_infer_impl
from .swa import swa_bwd_impl
from .swa import swa_fwd_impl
from .swa import swa_infer_impl
from .swa import swa_paged_decode_impl
from .swa import swa_paged_prefill_impl
from .swiglu import swiglu_bwd_impl
from .swiglu import swiglu_fwd_impl
from .int8_gemm import int8_gemm_dequant_impl, prepare_b_impl

# triton-dist based comm kernels (requires triton_dist + shmem packages)
allgather_gemm_impl = None
allgather_gemm_peer_mem_size = None
gemm_allreduce_impl = None
gemm_allreduce_peer_mem_size = None
gemm_reduce_scatter_impl = None
gemm_reduce_scatter_peer_mem_size = None
try:
    import triton_dist  # noqa: F401 — gate on the actual optional dependency
    from .allgather_gemm import allgather_gemm_impl, allgather_gemm_peer_mem_size
    from .gemm_allreduce import gemm_allreduce_impl, gemm_allreduce_peer_mem_size
    from .gemm_reduce_scatter import gemm_reduce_scatter_impl, gemm_reduce_scatter_peer_mem_size
except ImportError:
    import logging
    logging.getLogger(__name__).debug("triton_dist not available, comm kernels disabled")

# Over-Encoding (OE)
from .over_encoding.embedding import embedding_nf4_dequant_impl
from .over_encoding.fused_over_encoding import over_encoding_decode_impl
from .over_encoding.n_gram import n_gram_decode_impl
from .over_encoding.n_gram import n_gram_prefill_impl

__all__ = [
    "causal_conv1d_update_bdt_impl",
    "causal_conv1d_fwd_impl",
    "causal_conv1d_bwd_impl",
    "paged_attention_decode_impl",
    "paged_attention_prefill_impl",
    "paged_attention_prefill_prepare",
    "fused_linear_cross_entropy_bwd_impl",
    "fused_linear_cross_entropy_fwd_impl",
    "fused_linear_cross_entropy_1d_bwd_impl",
    "fused_linear_cross_entropy_1d_fwd_impl",
    "gelu_bwd_impl",
    "gelu_fwd_impl",
    "rmsnorm_bwd_impl",
    "rmsnorm_fwd_impl",
    "rmsnorm_infer_impl",
    "group_rmsnorm_impl",
    "layernorm_infer_impl",
    "layernorm_bwd_impl",
    "layernorm_fwd_impl",
    "fused_add_rmsnorm_infer_impl",
    "fused_add_layernorm_infer_impl",
    "rot_pos_embed_impl",
    "rope_bwd_impl",
    "rope_fwd_impl",
    "vision_rope_apply_impl",
    "vision_rot_pos_embed_impl",
    "mrope_fwd_impl",
    "silu_bwd_impl",
    "silu_fwd_impl",
    "swiglu_bwd_impl",
    "swiglu_fwd_impl",
    "sdpa_infer_impl",
    "sdpa_fwd_impl",
    "sdpa_bwd_impl",
    "lightning_indexer_impl",
    "dynamic_quant_impl",
    "static_quant_impl",
    "dequant_impl",
    "diffusion_attention_fwd_impl",
    "diffusion_attention_bwd_impl",
    "flex_attention_fwd_impl",
    "flex_attention_bwd_impl",
    "_build_packed_block_mask_streaming",
    "create_block_mask_patched",
    "triton_create_mask",
    "MASK_BLOCK_SIZE",
    "m_grouped_matmul_impl",
    "k_grouped_matmul_impl",
    "store_paged_kv_impl",
    "store_label_cache_infer_impl",
    "fused_penalties_temp_impl",
    "join_prob_reject_sampling_impl",
    "reject_sampling_impl",
    "top_p_filter_impl",
    "top_p_sampling_impl",
    "top_k_sampling_impl",
    "swa_paged_prefill_impl",
    "swa_paged_decode_impl",
    "swa_infer_impl",
    "swa_fwd_impl",
    "swa_bwd_impl",
    "embedding_nf4_dequant_impl",
    "n_gram_decode_impl",
    "n_gram_prefill_impl",
    "over_encoding_decode_impl",
    "allgather_gemm_impl",
    "gemm_allreduce_impl",
    "gemm_reduce_scatter_impl",
    "int8_gemm_dequant_impl", 
    "prepare_b_impl",
]

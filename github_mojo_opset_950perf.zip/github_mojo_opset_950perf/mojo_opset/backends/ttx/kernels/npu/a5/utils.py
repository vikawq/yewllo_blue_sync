from functools import lru_cache

import triton
import triton.language as tl

try:
    from triton.runtime.libentry import libentry
except ImportError:

    def libentry():
        """No-op fallback when triton.runtime.libentry is unavailable."""
        def _decorator(fn):
            return fn

        return _decorator

VEC_ALIGN_BYTES = 256
SRAM_ALIGN_BYTES = 32


@lru_cache(maxsize=1)
def get_num_cores(op_type="vector"):
    assert op_type in ["vector", "cube", "mix"], f"op_type {op_type} must in ['vector', 'cube', 'mix']."
    return (
        triton.runtime.driver.active.utils.get_device_properties("npu")["num_vectorcore"]
        if op_type == "vector"
        else triton.runtime.driver.active.utils.get_device_properties("npu")["num_aicore"]
    )
    
def is_910() -> bool:
    target=triton.runtime.driver.active.get_current_target()
    return "Ascend910" in target.arch

# npu triton only
exp = tl.exp
exp2 = tl.math.exp2
log = tl.log
log2 = tl.log2
gather = tl.gather

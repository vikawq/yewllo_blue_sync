# Vidur 仓库公开数据详析

> 审计对象：`microsoft/vidur` current main，commit `8383d2935bc62723a212090baa9f98ada206fc14`  
> 审计日期：2026-08-13  
> 本地只读副本：`D:\workspaces\trace\vidur_repro\vidur`  
> 范围：仓库内全部 53 个 CSV、当前 predictor 的读取/过滤/特征/缓存路径，以及 CSV 与论文实验的可复现关系。

## 1. 结论先行

1. **公开数据足以支持“固定 device/model/TP/backend、已采样 shape 域内”的分段学习，但不支持任意 OOD 外推。** 标准 attention 网格在其设计域内相当密集，单点重复测量的中位数通常稳定；与此同时，曲线存在平台、非单调区和明显跳变。随机森林适合拟合这种分段关系，但“可学习”应被限定为同一运行制度（regime）内插值。
2. **仓库不是论文实验数据的完整快照。** current main 的三条 workload 是 Arxiv、Splitwise code、Splitwise conversation；论文配置引用的 Chat-1M、BWB 等文件不在仓库。Splitwise trace 和 Llama-3 profile 还是论文发布后加入的。因此可以审计当前代码和数据，但不能据此逐项复现论文 workload 结果。
3. **53 个 CSV 共 1,436,810 行、275.31 MB。** 其中 compute 40 个/1,217,254 行，workload 3 个/56,442 行；`profiling/network` 下 10 个/163,114 行，但其中 136,750 行其实是误放的 A40 attention compute profile，真正标准 collective 只有 26,364 行。
4. **数据的主体不是端到端请求观测，而是 operator/collective 微基准。** learner 使用各 operator 的 `median`，按 MLP、prefill attention、decode attention、all-reduce、send/recv 分别建模，再由仿真器组合。CPU overhead CSV 完全缺失且默认跳过，因此调度、采样、输入准备、输出处理和 Ray 通信开销默认为 0。
5. **数据并不“平滑”，但多数点的测量噪声不大。** attention 的行内 CV p95 通常约 0.94%–2.76%；H100 MLP 投影的尾部 CV p95 可到 8.53%–11.37%。attention 中位数全部量化到 1 μs 网格，MLP 全部量化到 0.5 μs 网格，因此微小算子的巨大相对误差经常只是计时分辨率效应。
6. **shape 细微变化确实可能带来大跳变。** 例如 H100/Qwen-72B/TP1 的 `mlp_down_proj` 从 512 到 520 token，工作量代理仅增 1.56%，中位时延却由 0.2310 ms 增至 0.6525 ms（+182.47%）。这支持“边界/制度感知”的模型，而不是强制单调或全局光滑模型。
7. **当前训练评估容易高估泛化。** loader 只删除完整重复行，不按 shape 聚合；compute 数据仍有 28,744 个重复 shape 组。当前 10-fold CV 按行拆分，邻近网格和同 shape 可能同时进入训练与验证；代码又没有独立 test，并最终记录训练集 score。这个数字不能代表新 shape、边界邻域或 OOD 精度。
8. **存在会直接影响模拟正确性的契约缺陷。** A40 没有 all-reduce 文件；A100 Llama-3-8B attention 只覆盖 TP1/4；旧 attention 的 KV 最大 4032，却默认生成 4096 lookup；Orca 可用最大 4K 的旧 MLP 数据静默预测到 524K token；lookup cache 的 hash 没有完整包含训练数据、树状态、attention 文件和 KV 粒度。
9. **对昇腾 NPU，最合理的效仿不是照搬 GPU 的 shape→time 回归，而是把编译/tiling/搬运/流水制度显式化。** 推荐“regime 分类器 + regime 内回归/查表 + OOD 拒绝/补采”，并在疑似边界两侧做自适应密采，保留 compiler/kernel/tiling/cache/搬运路径元数据。

## 2. 审计口径与可复现边界

### 2.1 数据版本

本报告固定到 current-main commit `8383d29`。Git 历史显示：

- Llama-3 A100 profiles 于 2024-07-24 加入；
- Splitwise code/conversation traces 于 2024-08-16 加入；
- 它们都晚于 MLSys 2024 论文对应的代码/数据时点。

因此本报告中的“作者仓库数据”特指当前公开仓库资产，不把后来增加的数据冒充论文提交时的数据。

### 2.2 方法

- 枚举并完整读取全部 CSV，统计 schema、行列数、字节数、空值、无穷值、完整重复行、shape 重复、数值范围与哈希。
- compute 比较只在同 model、TP、backend、operator、精确 shape 的交集上进行。
- 单调性先在相同曲线条件内聚合同 shape，再沿单轴比较相邻点；同时报告绝对量和相对量。
- network change-point 候选要求：消息至少 64 KiB、相邻 size 比不超过 1.25、绝对时延变化至少 0.005 ms 且超过相邻观测标准差合成值的 3 倍，并满足上跳至少 25%或下跳至少 20%。它们只是复测候选，不是已经确认的 NCCL 算法边界。
- 跨 GPU speedup 是当前数据集的经验比值；CSV 缺少 driver/CUDA/PyTorch/backend build/频率/功耗/采集日期等 manifest，不能把差异完全归因于硬件。

## 3. 数据资产全景

| 类别 | CSV | 行数 | 字节 | 可删除完整重复行 | 主要用途/问题 |
|---|---:|---:|---:|---:|---|
| Compute | 40 | 1,217,254 | 238,768,309 | 3,108 | 20 attention + 20 MLP；predictor 的主要训练数据 |
| Network 路径下 | 10 | 163,114 | 35,054,125 | 479 | 其中 136,750 行是误放的 A40 attention；标准 collective 仅 26,364 行 |
| Workload | 3 | 56,442 | 1,490,301 | 469 | 请求长度与两条 arrival trace；不等于论文完整 workload 集 |
| **合计** | **53** | **1,436,810** | **275,312,735** | **4,056** | 9 种 schema |

质量概览：

- 22 个文件含完整重复行；9 个 network 文件带无业务含义的 `Unnamed: 0` 索引列。
- 共 7,512,480 个空单元格，绝大多数来自旧 attention schema 对非当前 phase 的结构性留空，并非同等严重的测量失败。
- 未发现全空列、数值无穷或负时延。
- CSV 没有统一数据字典、run ID、replicate ID、采集时间、软件栈版本、温度/频率或原始逐次样本；只能看到 min/max/mean/median/std 聚合值。

## 4. Workload 数据

### 4.1 三条 trace 的统计

| Trace | 请求数 | prefill p50 / p90 / p99 | decode p50 / p90 / p99 | total p50 / p90 / p99 / max | total > 4096 | 到达信息 |
|---|---:|---|---|---|---:|---|
| Arxiv summarization | 28,257 | 2730 / 3702 / 3933 | 167 / 372 / 3271 | 2992 / 3907 / 4077 / 4096 | 0% | 无 arrival timestamp |
| Splitwise code | 8,819 | 1469 / 5188 / 7436 | 13 / 55 / 251 | 1493 / 5208 / 7462 / 7841 | 14.253% | 3435.95 s，均值 2.566 QPS |
| Splitwise conversation | 19,366 | 1020 / 2735 / 4142 | 129 / 424 / 601 | 1412 / 2820 / 4259 / 14,089 | 8.324% | 3501.72 s，均值 5.530 QPS |

进一步观察：

- Arxiv 的 total 被限制到 4096，prefill 与 decode 的 Pearson 相关为 -0.463；decode 有明显长尾，top 1% 请求贡献约 12.33% 的 decode token。
- Splitwise code 是极端 prefill-heavy：prefill/decode 比值中位数约 91.81；prefill=7435–7437 形成明显封顶堆积。
- Splitwise conversation 的 prefill/decode 比值中位数约 3.58，更接近对话负载，但最大 total 达 14,089。
- 按 `(prefill, decode)` 看，Arxiv 有 934 行处于重复 shape，code 为 1,437 行，conversation 为 8,186 行。Arxiv 还有 469 行完整重复；另两条带 arrival 的 trace 没有完整重复。
- code/conv 的 arrival timestamp 严格递增，没有非正 inter-arrival；中位 inter-arrival 分别约 63.8 ms 和 118.4 ms。

### 4.2 4K 配置与 trace 变换

默认 `prediction_max_tokens_per_request=4096` 时，原始请求落在域内的比例为：Arxiv 100%、code 85.75%、conversation 91.68%。共有 2,869 条 code/conv 请求超过 4K。

这不仅是“丢掉尾部”这么简单：

- trace replay 路径在总长度超限时优先从 prefill 扣除超额，尽量保留 decode；
- length generator 路径按比例缩短输入/输出；
- 两种生成器面对同一原始 trace，会产生不同的有效 workload 分布。

因此报告模拟结果时必须同时记录：原始 trace、最大 context、使用的 generator、截断请求数，以及截断前后的长度分布。

### 4.3 与论文复现的差距

- current main 没有论文配置所需的 `lmsys_chat_1m_conversation_stats_llama2_tokenizer.csv` 和 `bwb_stats_llama2_tokenizer_filtered_v2.csv`。
- 默认 trace-length 配置还引用缺失的 ShareGPT 8K 文件；默认 interval 配置引用缺失的 Azure Functions 文件。
- 仓库三个现有 trace 都没有 interval loader 所要求的 `arrival_time` schema。

结论是：当前仓库可运行 Splitwise replay 或对现有长度分布做分析，但不能仅凭现有 CSV 原样复现论文的 Chat-1M/Arxiv-4K/BWB-4K 对比。

## 5. Compute profiling 数据

### 5.1 规模与 schema

| GPU | 类型 | 文件/模型 | 行数 | 唯一 shape（逐文件求和） | 重复 shape 组 | 可删除完整重复行 |
|---|---|---:|---:|---:|---:|---:|
| A100 | attention | 8 / 8 | 493,579 | 480,979 | 12,450 | 1,153 |
| A100 | MLP | 8 / 8 | 9,129 | 9,047 | 82 | 0 |
| A40 | attention | 6 / 6 | 351,792 | 343,632 | 8,064 | 405 |
| A40 | MLP | 6 / 6 | 5,481 | 5,439 | 42 | 0 |
| H100 | attention | 6 / 6 | 351,792 | 343,632 | 8,064 | 1,550 |
| H100 | MLP | 6 / 6 | 5,481 | 5,439 | 42 | 0 |

共 4 套 compute schema：

1. 18 个旧 attention 文件：31 列，FlashAttention，`max_model_len=4096`，没有 `attn_kv_cache_save`；loader 会把该 target 补成 0。
2. 2 个 A100 Llama-3 attention 文件：36 列，FlashInfer，`max_model_len=16384`，带 KV-cache-save；非当前 phase 的 target 使用 0，而不是旧 schema 的空值。
3. 17 个标准 MLP 文件：包含 post-attention norm。
4. 3 个 Phi-2 MLP 文件：按模型结构没有 post-attention norm。

`attention_backend` 和 `max_model_len` 被写入 CSV，却没有作为 learner 的显式特征或 loader 过滤条件；当前每个文件内部只有一个 backend，暂时没有混合，但数据契约无法防止未来误混。

### 5.2 shape 网格与覆盖

旧数据的主要网格：

- MLP：TP1/2/4/8；每 TP 259 个唯一 `num_tokens`，覆盖 1–4096，大 shape 步长逐渐变大，2048/4096 等段边界重复。
- Decode attention：每 TP 是 128 个 batch × 79 个 KV 点，共 10,112 个唯一 shape；KV 从 32 起，最大 4032。
- Prefill attention：在 `prefill + KV <= 4096` 的采样约束内，每 TP 4,206 个唯一 shape；最小 prefill chunk 为 64。
- Llama-3 MLP：每 TP 451 个唯一点，1–32768；中位步长 32、最大步长 256。
- Llama-3 attention：A100/FlashInfer，batch 可到 512、prefill 可到 16384、KV 可到 16320；显存过滤与 TP 强相关。

域内网格完整不等于没有空洞：旧 attention 的 prefill 1–63、decode KV 0–31 没有实测；默认 lookup 仍会生成 KV=0 和 KV=4096 等点，这些是边界常数预测/外推，不是插值。大 shape 的步长也越来越粗，无法观察 `x±1` 触发的 kernel/tiling 边界。

### 5.3 重复、异常与测量噪声

- Compute 中有 3,108 行可删除的完整重复，另有 28,744 个重复 shape 组。重复主要来自分段网格边界和 full-prefill/chunked-prefill 构造重叠，并不等价于独立复测。
- Loader 只执行整行 `drop_duplicates()`；同 shape 但统计值不同的行仍作为独立训练样本，使这些边界 shape 获得额外权重。
- 唯一硬异常是 A100/Qwen-72B/TP1 decode 的 16 行：`median=0`，但 mean 为 0.0154–0.2114 ms、max 最高 0.529 ms。当前代码会直接把 0 当 label；对 MAPE 而言也会产生不稳定语义，应重测或剔除。
- attention 的 2,394,310 个正中位数全部在 1 μs 网格；MLP 的 200,127 个正中位数全部在 0.5 μs 网格，其中约 88%–90% 又落在整数 μs 网格。对 0.001–0.01 ms 算子必须同时看绝对 μs 差，不能只看百分比。

行内重复测量的代表性 CV p95（文件中位数）如下：

| Operator | A100 | A40 | H100 |
|---|---:|---:|---:|
| `attn_decode` | 2.144% | 0.941% | 2.761% |
| `attn_prefill` | 2.218% | 2.727% | 2.547% |
| `attn_pre_proj` | 2.556% | 2.076% | 11.371% |
| `mlp_up_proj` | 2.097% | 2.114% | 8.528% |
| `mlp_down_proj` | 2.666% | 2.047% | 8.527% |

这说明大部分 attention 点的 median 相当稳定；H100 MLP 的尾部显著更不稳定，需独立复测。这里的重复次数是单行内部 5/20 次采样，而重复 shape 行往往只是网格构造重叠，两者不能混为一谈。

### 5.4 非单调与跳变

以相邻点时延下降超过 5% 为例：

| 轴 | A100 | A40 | H100 |
|---|---:|---:|---:|
| Decode：沿 batch | 0.887% | 0.314% | 1.439% |
| Decode：沿 KV | 0.677% | 0.343% | 1.109% |
| Prefill：沿 chunk | 1.480% | 1.945% | 2.381% |
| Prefill：沿 KV | 4.771% | 5.685% | 5.899% |

非单调不是自动的数据错误：并行度、tile、搬运、cache、调度和计时量化都可能让更大 shape 更快。真正值得复测的是“变化远大于观测噪声、工作量变化很小、且边界附近可重复”的点。

代表性强跳变：

- H100/Qwen-72B/TP1 `mlp_down_proj`：512→520 token，0.2310→0.6525 ms，+182.47%。
- A40/Qwen-72B/TP1 同算子：256→264 token，1.043→2.919 ms，+179.87%。
- 2 的幂边界附近的偏差在多组 prefill KV 曲线中富集，但采样步长也恰在这些位置改变，故只能称“量化/网格效应候选”，不能直接断言是 kernel 切换。

### 5.5 跨 GPU 与 TP

严格使用相同 model/TP/backend/operator/精确 shape 的交集后，6 个共同模型的 cell 中位 speedup 中位数为：

| 比较 | Decode | Prefill | Attention pre-proj | Attention post-proj | MLP up | MLP down |
|---|---:|---:|---:|---:|---:|---:|
| A40 → A100 | 2.583× | 1.849× | 1.969× | 1.994× | 2.015× | 2.015× |
| A100 → H100 | 1.690× | 1.497× | 2.800× | 2.865× | 2.827× | 2.923× |

差异明显依赖 operator，说明不能用单一“硬件倍率”缩放全部算子。`emb` 在 A40→A100 上甚至多数 shape 显示 A100 更慢；该列又不进入当前 ExecutionTime，反而像是软件/实现/采集环境不一致的提示。

Compute-only TP scaling 看起来较好，例如 A100 `mlp_up_proj` 的 TP2/4/8 中位 speedup 约 2.013×/4.036×/8.016×；但 attention 的效率更低，例如 A100 decode TP2/4/8 约 1.796×/3.248×/5.614×。这些数字不含 collective、同步、CPU、pipeline bubble 和调度，不能作为端到端 TP 扩展率。

## 6. Network profiling 数据

### 6.1 标准数据范围

真正标准的 all-reduce/send-recv 数据共 26,364 行：

- 多数曲线有 993 个唯一 message size，覆盖 2 KiB–64 MiB；分段网格在 16 MiB 边界重复。
- A100 pairwise all-reduce 例外，覆盖到约 511.5 MiB。
- 所有标准文件只保留 rank 0；当前 benchmark 每点只有 3 次 active 测量。因此不能观察 rank 不对称和尾延迟。
- 9 个文件包含 `Unnamed: 0`；重复 network key 全位于 16 MiB 分段边界。

### 6.2 吞吐与拓扑差异

以下为 payload-equivalent bandwidth 的 p95，不是 NCCL 官方 `busbw`，也不是厂商峰值：

| 数据组 | p95 payload BW |
|---|---:|
| A100 DGX AR，w2/dpn2（节点内） | 153.18 GB/s |
| A100 DGX AR，w2/dpn1（跨节点） | 5.86 GB/s |
| A100 DGX AR，w4/dpn4 / w4/dpn2 | 110.61 / 7.04 GB/s |
| A100 DGX AR，w8/dpn8 / w8/dpn4 | 96.01 / 12.17 GB/s |
| H100 DGX AR，w2 / w4 / w8 节点内 | 269.90 / 209.80 / 189.11 GB/s |
| A100 pairwise AR，w2 / w4 | 194.66 / 15.79 GB/s |
| H100 pairwise AR，w2 / w4 | 187.66 / 32.30 GB/s |

拓扑/worker 数对网络曲线的影响远大于简单 device 标签；它们必须成为模型契约的一部分。

### 6.3 数据异常与代码不可达性

- `a40_pairwise_nvlink/attention.csv` 有 136,750 行、50 列，是旧 attention compute profile，当前代码没有路径会消费它；同时该目录没有 `all_reduce.csv`，A40 TP>1 默认会在文件打开阶段失败。
- A100 DGX all-reduce 含 `(workers, devices_per_node)` 为 `(2,1)/(2,2)/(4,2)/(4,4)/(8,4)/(8,8)/(16,8)` 的曲线。当前 loader 强制 `num_workers == TP && devices_per_node == TP`，所以 3,976 行跨节点曲线永久不可达，TP16 也因不存在 `(16,16)` 而不可用。
- H100 DGX all-reduce 只有节点内 w2/w4/w8；没有跨节点或 w16 数据。
- H100 与 A100 pairwise `send_recv.csv` 字节级完全相同，缺少 provenance 无法判断是复用、占位还是独立测量恰好相同，不能据此声称两种硬件网络性能一致。
- A40 目录名是 pairwise NVLink，但记录的 `max_devices_per_node=8`；命名和拓扑元数据应统一验证。

### 6.4 抖动与候选边界

CV > 20% 的点包括：A100 DGX AR 174/6958、A100 pairwise AR 65/4496、H100 DGX AR 155/2982、H100 pairwise AR 36/1988；各 send/recv 文件也有 12–85/1988 个高抖动点。

联合绝对变化、相对变化和 3×观测噪声阈值后，共得到 284 个局部跳变/非单调候选。比如约 395–403 KiB 附近，部分 A100/H100 曲线出现 0.013→0.063 ms 或 0.010→0.043 ms 的上跳。没有 NCCL debug log、算法/协议 ID 和密集复测前，这些只能用来指导补采。

## 7. 当前 learner 到底消费了什么

### 7.1 标签与特征

当前 sklearn predictor 的核心逻辑是：

- 对每个 operator 单独取 CSV 的 `median` 作为 target；min/max/mean/std 不进入训练，也不作为样本权重。
- MLP/投影/norm/rope/add 等主要以 `num_tokens` 为输入。
- Decode attention 使用 `[batch_size, kv_cache_size]`。
- Prefill attention 使用 `[kv_cache_size, prefill_chunk_size²]`。
- all-reduce/send-recv 把 bytes 换算成 token 后学习一维曲线。
- 默认随机森林 grid 为 `n_estimators=[250,500,750]`、`max_depth=[8,16,32]`、`min_samples_split=[2,5,10]`，以自定义 MAPE 做 10-fold GridSearchCV。

运行时还会施加额外的人为规则：

- MLP 总 token 向上取整到 8 的倍数。
- Decode 将 batch 内 KV 先求平均，再向上取整到 64 的倍数。
- Prefill 将每请求 KV 向上取整到 64，再对 KV 求和、对 chunk 的平方和开根聚合。
- GQA 多请求 attention 统一乘约 1.1 的经验修正。
- KV-cache-save 用精确 token；旧 schema 缺列时则被训练成常数 0。

所以“预测一个 batch”并不是直接学习完整 batch 的真实联合执行时间，而是把 batch 投影到少数聚合特征后查表。

### 7.2 没被使用或被弱化的信息

- CSV 虽保存每点 min/max/mean/median/std，模型只吃 median；无法表达 aleatoric uncertainty。
- `attention_backend`、`max_model_len` 不作为特征/过滤条件。
- `attn_input_reshape` 在公开 compute 数据里没有有效学习信号；reshape/output reshape 等字段也没有进入最终 ExecutionTime 组合。
- `emb` 被测量但不进入当前 ExecutionTime。
- CPU overhead 文件为 0 个，默认全部置零。
- 网络 CSV 的 cross-node 曲线因过滤条件不可达。

## 8. 数据契约与运行风险

### 8.1 覆盖矩阵

- 配置注册的 27 个 model×device 组合中，7 个完全没有 compute 文件：InternLM2-20B 在三种设备上均缺，两个 Llama-3 模型在 A40/H100 上均缺。
- A100 Llama-3-8B 的 MLP 有 TP1/2/4/8，但 attention 只有 TP1/4，所以可用 compute TP 仍只有 1/4。
- 所有 attention profile 只覆盖 block size 16。
- Compute 有 TP8 并不意味着端到端 TP8 可用；pairwise all-reduce 可能只支持 TP2/4，A40 更完全缺 AR。
- `device` 与 `network_device` 独立配置，代码允许 A100 compute + H100 network 这类物理上未验证的组合，没有一致性校验。

### 8.2 外推与查表失败

- 旧 attention 最大 KV=4032，但默认 lookup 会生成 4096；RF 在边界外只能返回叶节点常数。
- 旧 MLP 最大 token=4096；在 Orca scheduler 下，lookup 上限可能是 `4096×128=524,288`，形成两个数量级的静默外推。
- 超过生成 lookup 的实际 batch/shape 没有 clamp 或 fallback，会直接 `KeyError`。
- scheduler 的 batch cap 与 predictor 的 max batch 没有耦合验证。

### 8.3 缓存正确性

- 训练模型 cache hash 包含 dataframe；但 prediction lookup cache 使用拟合 estimator 的字符串表示，通常只反映超参，不包含树状态或训练数据。
- predictor 的 `to_dict()` 没包含 `attention_input_file` 和 `kv_cache_prediction_granularity` 等关键输入。
- 因此 CSV、模型或粒度变化后，存在静默复用旧 prediction lookup 的风险。运行严格实验时应使用 `no_cache` 或修复 hash 契约，并把数据文件哈希、代码 commit、超参和软件环境写入 manifest。

## 9. “可学习”应如何定义

### 9.1 当前数据支持的命题

在固定 GPU、模型结构、TP、attention backend、软件栈和采集状态下，对已覆盖 shape 域：

- 重复测量的 median 多数稳定；
- attention 网格足够密，MLP 一维曲线也覆盖主要 token 范围；
- 非线性、平台和离散跳变可以由树模型分段逼近；
- 因而适合做 same-regime、in-domain 插值。

### 9.2 当前数据不支持的命题

不能由这些 CSV 推出：

- 未见过的 compiler、kernel、tiling、attention backend 或设备仍共享同一函数；
- 4K 数据可以可靠外推到 16K/524K；
- 随机行 CV 的低误差等价于新 shape、连续空区间或边界邻域的误差；
- compute-only TP speedup 等于端到端扩展率；
- operator median 相加能完整覆盖 CPU、搬运、并发、通信重叠和流水线开销。

更准确的说法是：**时延函数是“分段可学习”的；分段边界本身必须被识别、观测和版本化。**

## 10. 对昇腾 NPU 的落地建议

NPU 的 shape 变化可能同时触发图编译、tiling、workspace、DMA 搬运、核函数选择、流水并行或融合变化。建议把这些离散状态视为一等信息，而不是藏在一个全局连续函数里。

### 10.1 数据契约

每条样本至少记录：

- 硬件：NPU 型号、卡/节点拓扑、频率/功耗模式、固件；
- 软件：CANN/torch_npu/框架/算子库/编译器 commit 与关键 flag；
- 图与 kernel：graph hash、kernel/tiling ID、workspace、融合/拆分方案、stream 数；
- Shape：原始维度、padding/对齐后维度、dtype/layout、batch/sequence/KV/TP；
- 搬运：H2D/D2D/片上搬运字节、路径和是否重叠；
- 状态：cold compile、warm cache、compile-cache hit、独立进程/run/replicate ID；
- 标签：compile time、host launch、搬运、kernel、同步、端到端分别记录，保留逐次样本而非只存五元统计。

### 10.2 采样策略

1. 先做粗网格覆盖生产域，并按线上 workload 分布加权。
2. 计算相邻点的绝对跳变、相对跳变和噪声标准化跳变。
3. 对候选边界补采 `x±1`、对齐块 `x±tile`、2 的幂两侧、常见 batch/sequence/KV 组合。
4. 每个 shape 至少区分 warm 重复与多个独立进程/独立编译的重复；高抖动点提高重复数。
5. 保留没被线上 workload 高频覆盖但可能触发大制度切换的 guardrail 点。

### 10.3 建模结构

推荐三级结构：

1. **Regime 分类**：预测/读取 compiler、kernel、tiling、搬运路径和 cache 状态。
2. **Regime 内回归**：小维度可用查表/分段树/GBDT；有足够数据再用更复杂模型。不要强制全局单调。
3. **不确定性与 OOD**：报告与最近训练点距离、叶节点样本量、重复测量方差；越界或低置信度时拒绝预测并触发补采，而不是静默叶节点常数外推。

如果运行时拿不到 tiling/kernel ID，可把它们作为训练时的 latent regime 标签：先离线聚类/分类边界，再用 shape 预测 regime；但必须单独评估 regime 分类错误，因为跨 regime 的误差远大于 regime 内回归误差。

### 10.4 评估切分

至少同时报告：

- `Group holdout`：同 shape 的所有重复必须在同一 fold；
- `Contiguous-block holdout`：整段 token/KV/batch 区间留出；
- `Boundary-neighborhood holdout`：专门留出 tiling/kernel 切换两侧；
- `OOD holdout`：新 compiler、backend、TP、拓扑或设备；
- `Workload-weighted`：按真实请求分布计算端到端误差。

指标同时给出 MAE（μs/ms）、相对误差、p95/p99、边界误差和 regime 分类准确率。对接近 0 的算子不要单独依赖 MAPE。

## 11. 数据质量修复优先级

| 优先级 | 动作 | 原因 |
|---|---|---|
| P0 | 重测/剔除 A100 Qwen-72B TP1 的 16 个 zero-median decode 点 | 直接制造 0 ms 标签并破坏 MAPE 语义 |
| P0 | 修复 prediction lookup cache hash | 数据或模型变化后可能静默使用旧预测 |
| P1 | 按 shape 聚合或保留 replicate ID；CV 按 shape 分组 | 避免重复 shape 权重偏置与 train/validation 泄漏 |
| P1 | 给所有 profile 增加环境与采集 manifest | 当前无法区分硬件、软件、温度和版本影响 |
| P1 | 修复 all-reduce 跨节点过滤与 A40 缺文件 | 已有 3,976 行跨节点数据不可达，A40 TP>1 失败 |
| P1 | 禁止超出 profile 域静默外推 | 4K→524K 的叶常数不是可信预测 |
| P1 | 重测 H100 MLP 高抖动点与 284 个 network 候选边界 | 判断真实 regime change 与测量噪声 |
| P2 | 补齐 CPU overhead、rank/tail、Llama-3 跨 GPU 与 TP 缺口 | 扩大端到端可解释范围 |
| P2 | 补回论文 workload 或发布准确版本清单 | 支持论文实验的可复现性 |

## 12. 本地可复查产物

- 总扫描与汇总：`D:\workspaces\trace\vidur_data_analysis\main`
- Compute 详析：`D:\workspaces\trace\vidur_data_analysis\compute_agent\COMPUTE_ANALYSIS.md`
- Network/workload 详析：`D:\workspaces\trace\vidur_data_analysis\network_workload_agent\NETWORK_WORKLOAD_ANALYSIS.md`
- 代码/数据契约审计：`D:\workspaces\trace\vidur_data_analysis\contract_agent\DATA_CONTRACT_ANALYSIS.md`
- 全部结构化 CSV/JSON 与可重跑脚本均位于上述目录；官方仓库在分析后保持 clean。

本报告的统计是对 current-main 公开资产的描述性审计，不替代作者论文中的精度结果，也不把候选跳变解释成已经证实的微架构因果。要得到因果结论，需要带 kernel/tiling/compiler/NCCL 协议信息的定向复测。

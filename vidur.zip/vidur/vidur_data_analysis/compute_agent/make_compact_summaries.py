"""Build compact, report-ready summaries from analyze_compute_profiles.py outputs."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
import pandas as pd


MAIN_OPS = {
    "attn_decode",
    "attn_prefill",
    "attn_pre_proj",
    "attn_post_proj",
    "mlp_up_proj",
    "mlp_down_proj",
}


def weighted_percentile(values: pd.Series, weights: pd.Series, p: float) -> float:
    order = np.argsort(values.to_numpy(dtype=float))
    x = values.to_numpy(dtype=float)[order]
    w = weights.to_numpy(dtype=float)[order]
    return float(x[np.searchsorted(np.cumsum(w), p * w.sum(), side="left")])


def write(df: pd.DataFrame, path: Path) -> None:
    df.to_csv(path, index=False)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--artifacts", type=Path, required=True)
    args = parser.parse_args()
    root = args.artifacts.resolve()

    inv = pd.read_csv(root / "file_inventory.csv")
    asset = (
        inv.groupby(["gpu", "kind"], as_index=False)
        .agg(
            files=("relative_path", "nunique"),
            models=("model", "nunique"),
            rows=("rows", "sum"),
            bytes=("bytes", "sum"),
            unique_shapes=("unique_shapes", "sum"),
            repeated_shape_groups=("repeated_shape_groups", "sum"),
            exact_duplicate_rows_removable=("exact_duplicate_rows_removable", "sum"),
        )
    )
    write(asset, root / "compact_asset_summary.csv")

    quant = pd.read_csv(root / "timing_quantization.csv")
    quant_grouped = []
    for (gpu, kind), part in quant.groupby(["gpu", "kind"]):
        n = part["positive_count"].sum()
        quant_grouped.append(
            {
                "gpu": gpu,
                "kind": kind,
                "positive_medians": int(n),
                "integer_microsecond_grid_fraction": float((part["integer_microsecond_grid_fraction"] * part["positive_count"]).sum() / n),
                "half_microsecond_grid_fraction": float((part["half_microsecond_grid_fraction"] * part["positive_count"]).sum() / n),
                "min_positive_ms": float(part["min_positive_ms"].min()),
            }
        )
    write(pd.DataFrame(quant_grouped), root / "compact_timing_quantization.csv")

    jitter = pd.read_csv(root / "within_row_jitter.csv")
    jitter = jitter[jitter["operator"].isin(MAIN_OPS)]
    compact_jitter = (
        jitter.groupby(["gpu", "operator"], as_index=False)
        .agg(
            models=("model", "nunique"),
            rows=("rows_with_stats", "sum"),
            file_cv_p50_median=("cv_pct_p50", "median"),
            file_cv_p95_median=("cv_pct_p95", "median"),
            file_cv_p95_max=("cv_pct_p95", "max"),
            file_range_p95_median=("range_over_median_pct_p95", "median"),
        )
    )
    write(compact_jitter, root / "compact_within_row_jitter.csv")

    mono = pd.read_csv(root / "monotonicity_summary.csv")
    compact_mono_rows = []
    for keys, part in mono.groupby(["gpu", "kind", "phase", "operator", "axis"], dropna=False):
        gpu, kind, phase, operator, axis = keys
        pairs = part["adjacent_pairs"].sum()
        compact_mono_rows.append(
            {
                "gpu": gpu,
                "kind": kind,
                "phase": phase,
                "operator": operator,
                "axis": axis,
                "files": int(part["relative_path"].nunique()),
                "curve_summaries": int(len(part)),
                "adjacent_pairs": int(pairs),
                "decrease_gt_2pct_fraction": float(part["decrease_gt_2pct"].sum() / pairs),
                "decrease_gt_5pct_fraction": float(part["decrease_gt_5pct"].sum() / pairs),
                "decrease_gt_10pct_fraction": float(part["decrease_gt_10pct"].sum() / pairs),
                "unchanged_exact_fraction": float(part["unchanged_exact"].sum() / pairs),
                "increase_gt_5pct_fraction": float(part["increase_gt_5pct"].sum() / pairs),
                "largest_decrease_pct": float(part["largest_decrease_pct"].max()),
                "largest_increase_pct": float(part["largest_increase_pct"].max()),
                "weighted_runtime_ratio_p50_approx": weighted_percentile(part["runtime_ratio_p50"], part["adjacent_pairs"], 0.5),
                "weighted_abs_log_excess_p95_approx": weighted_percentile(part["abs_log_excess_p95"], part["adjacent_pairs"], 0.5),
            }
        )
    compact_mono = pd.DataFrame(compact_mono_rows)
    write(compact_mono, root / "compact_monotonicity.csv")

    speed = pd.read_csv(root / "cross_gpu_speedup_summary.csv")
    speed = speed[speed["operator"].isin(MAIN_OPS | {"mlp_act"})]
    speed_rows = []
    for keys, part in speed.groupby(["from_gpu", "to_gpu", "kind", "operator"]):
        fg, tg, kind, op = keys
        speed_rows.append(
            {
                "from_gpu": fg,
                "to_gpu": tg,
                "kind": kind,
                "operator": op,
                "models": int(part["model"].nunique()),
                "tp_cells": int(len(part)),
                "common_shapes_sum": int(part["common_shapes"].sum()),
                "cell_speedup_p50_median": float(part["speedup_p50"].median()),
                "cell_speedup_p50_min": float(part["speedup_p50"].min()),
                "cell_speedup_p50_max": float(part["speedup_p50"].max()),
                "weighted_fraction_to_gpu_slower": float((part["fraction_to_gpu_slower"] * part["common_shapes"]).sum() / part["common_shapes"].sum()),
            }
        )
    write(pd.DataFrame(speed_rows), root / "compact_cross_gpu_speedup.csv")

    tp = pd.read_csv(root / "tp_compute_scaling_summary.csv")
    tp = tp[tp["operator"].isin(MAIN_OPS | {"mlp_act"})]
    tp_rows = []
    for keys, part in tp.groupby(["gpu", "kind", "operator", "tp"]):
        gpu, kind, op, tp_value = keys
        tp_rows.append(
            {
                "gpu": gpu,
                "kind": kind,
                "operator": op,
                "tp": int(tp_value),
                "models": int(part["model"].nunique()),
                "cells": int(len(part)),
                "common_shapes_sum": int(part["common_shapes"].sum()),
                "cell_compute_speedup_p50_median": float(part["compute_speedup_p50"].median()),
                "cell_compute_speedup_p50_min": float(part["compute_speedup_p50"].min()),
                "cell_compute_speedup_p50_max": float(part["compute_speedup_p50"].max()),
                "cell_parallel_efficiency_p50_median": float(part["parallel_efficiency_p50"].median()),
                "weighted_fraction_slower_than_tp1": float((part["fraction_slower_than_tp1"] * part["common_shapes"]).sum() / part["common_shapes"].sum()),
            }
        )
    write(pd.DataFrame(tp_rows), root / "compact_tp_compute_scaling.csv")

    report = {
        "assets": asset.to_dict("records"),
        "timing_quantization": quant_grouped,
        "note": "Compact summaries aggregate per-file/per-model cells; medians of medians are descriptive, not pooled raw-sample estimates.",
    }
    (root / "compact_summary.json").write_text(json.dumps(report, indent=2), encoding="utf-8")


if __name__ == "__main__":
    main()

"""Read-only audit of all Vidur compute profiling CSV files.

Outputs compact CSV/JSON artifacts outside the official repository.  The
script never writes below --input-root.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import math
import platform
import re
import time
from collections import Counter, defaultdict
from pathlib import Path
from typing import Iterable

import numpy as np
import pandas as pd
import sklearn


STAT_RE = re.compile(r"^time_stats\.(?P<op>.+)\.(?P<stat>min|max|mean|median|std)$")
BOUNDARIES = (8, 16, 32, 64, 128, 256, 512, 1024)


def q(values: Iterable[float], percentile: float) -> float | None:
    arr = np.asarray(list(values), dtype=float)
    arr = arr[np.isfinite(arr)]
    return float(np.percentile(arr, percentile)) if len(arr) else None


def safe_float(value: object) -> float | None:
    if value is None or pd.isna(value):
        return None
    return float(value)


def file_meta(root: Path, path: Path) -> tuple[str, str, str, str]:
    rel = path.relative_to(root)
    parts = rel.parts
    if len(parts) != 4:
        raise ValueError(f"Unexpected path layout: {rel}")
    gpu, org, model_leaf, filename = parts
    return str(rel), gpu, f"{org}/{model_leaf}", path.stem


def operator_columns(columns: Iterable[str]) -> dict[str, dict[str, str]]:
    result: dict[str, dict[str, str]] = defaultdict(dict)
    for col in columns:
        match = STAT_RE.match(col)
        if match:
            result[match.group("op")][match.group("stat")] = col
    return dict(result)


def shape_keys(kind: str, columns: Iterable[str]) -> list[str]:
    columns = set(columns)
    if kind == "mlp":
        expected = [
            "n_head",
            "n_kv_head",
            "n_embd",
            "n_expanded_embd",
            "vocab_size",
            "use_gated_mlp",
            "num_tokens",
            "num_tensor_parallel_workers",
        ]
    else:
        expected = [
            "n_embd",
            "n_q_head",
            "n_kv_head",
            "block_size",
            "num_tensor_parallel_workers",
            "max_model_len",
            "batch_size",
            "prefill_chunk_size",
            "kv_cache_size",
            "is_prefill",
            "attention_backend",
        ]
    return [col for col in expected if col in columns]


def aggregate_duplicate_shape_quality(
    df: pd.DataFrame,
    keys: list[str],
    ops: dict[str, dict[str, str]],
    context: dict[str, object],
) -> tuple[list[dict[str, object]], list[dict[str, object]]]:
    group_sizes = df.groupby(keys, dropna=False).size()
    repeated_index = group_sizes[group_sizes > 1].index
    summary: list[dict[str, object]] = []
    top: list[dict[str, object]] = []
    for op, stats in ops.items():
        median_col = stats.get("median")
        if not median_col or len(repeated_index) == 0:
            continue
        grouped = df.groupby(keys, dropna=False)[median_col].agg(["count", "mean", "std", "min", "max"])
        grouped = grouped[grouped["count"] > 1].copy()
        if grouped.empty:
            continue
        grouped["cv_pct"] = grouped["std"] / grouped["mean"].abs() * 100
        grouped["range_pct"] = (grouped["max"] - grouped["min"]) / grouped["mean"].abs() * 100
        valid = grouped.replace([np.inf, -np.inf], np.nan)
        summary.append(
            {
                **context,
                "operator": op,
                "repeat_groups_with_target": int(len(grouped)),
                "repeat_rows_with_target": int(grouped["count"].sum()),
                "duplicate_shape_cv_pct_p50": q(valid["cv_pct"].dropna(), 50),
                "duplicate_shape_cv_pct_p95": q(valid["cv_pct"].dropna(), 95),
                "duplicate_shape_cv_pct_max": safe_float(valid["cv_pct"].max()),
                "duplicate_shape_range_pct_p95": q(valid["range_pct"].dropna(), 95),
                "duplicate_shape_range_pct_max": safe_float(valid["range_pct"].max()),
            }
        )
        for idx, row in valid.sort_values("range_pct", ascending=False).head(10).iterrows():
            key_values = idx if isinstance(idx, tuple) else (idx,)
            top.append(
                {
                    **context,
                    "operator": op,
                    **dict(zip(keys, key_values)),
                    "count": int(row["count"]),
                    "median_mean": safe_float(row["mean"]),
                    "median_min": safe_float(row["min"]),
                    "median_max": safe_float(row["max"]),
                    "cv_pct": safe_float(row["cv_pct"]),
                    "range_pct": safe_float(row["range_pct"]),
                }
            )
    return summary, top


def audit_file(
    root: Path, path: Path
) -> tuple[
    dict[str, object],
    list[dict[str, object]],
    list[dict[str, object]],
    list[dict[str, object]],
    list[dict[str, object]],
]:
    rel, gpu, model, kind = file_meta(root, path)
    df = pd.read_csv(path)
    columns = list(df.columns)
    ops = operator_columns(columns)
    keys = shape_keys(kind, columns)
    schema_hash = hashlib.md5("||".join(columns).encode()).hexdigest()[:8]
    exact_duplicate_mask = df.duplicated(keep=False)
    shape_sizes = df.groupby(keys, dropna=False).size()
    repeated_shapes = shape_sizes[shape_sizes > 1]
    key_null_rows = int(df[keys].isna().any(axis=1).sum())
    invariant_counts: Counter[str] = Counter()

    if kind == "attention":
        inconsistent_phase = df["is_prefill"].astype(bool) != df["prefill_chunk_size"].gt(0)
        invariant_counts["attention_is_prefill_vs_chunk"] = int(inconsistent_phase.sum())
        decode_col = "time_stats.attn_decode.median"
        prefill_col = "time_stats.attn_prefill.median"
        decode_rows = ~df["is_prefill"].astype(bool)
        prefill_rows = ~decode_rows
        if decode_col in df:
            invariant_counts["decode_target_missing_on_decode"] = int(df.loc[decode_rows, decode_col].isna().sum())
            invariant_counts["decode_target_present_on_prefill"] = int(df.loc[prefill_rows, decode_col].notna().sum())
        if prefill_col in df:
            invariant_counts["prefill_target_missing_on_prefill"] = int(df.loc[prefill_rows, prefill_col].isna().sum())
            invariant_counts["prefill_target_present_on_decode"] = int(df.loc[decode_rows, prefill_col].notna().sum())

    missing_rows: list[dict[str, object]] = []
    jitter_rows: list[dict[str, object]] = []
    for op, stats in ops.items():
        stats_cols = list(stats.values())
        present_mask = df[stats_cols].notna().any(axis=1)
        incomplete = present_mask & df[stats_cols].isna().any(axis=1)
        invariant_counts[f"{op}:incomplete_stats"] = int(incomplete.sum())
        for stat, col in stats.items():
            numeric = pd.to_numeric(df[col], errors="coerce")
            invariant_counts[f"{op}:{stat}_negative"] = int((numeric < 0).sum())
        if all(stat in stats for stat in ("min", "mean", "median", "max", "std")):
            mn, mean, med, mx, std = (df[stats[s]] for s in ("min", "mean", "median", "max", "std"))
            valid = mn.notna() & mean.notna() & med.notna() & mx.notna() & std.notna()
            tol = 1e-9
            invariant_counts[f"{op}:zero_median_positive_mean"] = int((valid & med.eq(0) & mean.gt(0)).sum())
            invariant_counts[f"{op}:min_gt_mean"] = int((valid & (mn > mean + tol)).sum())
            invariant_counts[f"{op}:mean_gt_max"] = int((valid & (mean > mx + tol)).sum())
            invariant_counts[f"{op}:min_gt_median"] = int((valid & (mn > med + tol)).sum())
            invariant_counts[f"{op}:median_gt_max"] = int((valid & (med > mx + tol)).sum())
            positive_mean = valid & mean.abs().gt(0)
            cv = std[positive_mean] / mean[positive_mean].abs() * 100
            positive_median = valid & med.abs().gt(0)
            range_pct = (mx[positive_median] - mn[positive_median]) / med[positive_median].abs() * 100
            jitter_rows.append(
                {
                    "relative_path": rel,
                    "gpu": gpu,
                    "model": model,
                    "kind": kind,
                    "operator": op,
                    "rows_with_stats": int(valid.sum()),
                    "zero_median_rows": int((valid & med.eq(0)).sum()),
                    "cv_pct_p50": q(cv, 50),
                    "cv_pct_p90": q(cv, 90),
                    "cv_pct_p95": q(cv, 95),
                    "cv_pct_p99": q(cv, 99),
                    "cv_pct_max": safe_float(cv.max()),
                    "range_over_median_pct_p95": q(range_pct, 95),
                    "range_over_median_pct_max": safe_float(range_pct.max()),
                }
            )
        for stat, col in stats.items():
            missing_rows.append(
                {
                    "relative_path": rel,
                    "gpu": gpu,
                    "model": model,
                    "kind": kind,
                    "operator": op,
                    "stat": stat,
                    "column": col,
                    "rows": int(len(df)),
                    "missing": int(df[col].isna().sum()),
                    "missing_fraction": float(df[col].isna().mean()),
                    "zero_nonmissing": int((df[col].fillna(np.nan) == 0).sum()),
                }
            )

    violation_rows = [
        {
            "relative_path": rel,
            "gpu": gpu,
            "model": model,
            "kind": kind,
            "category": "schema_semantics" if "_present_on_" in check else "hard_invariant",
            "check": check,
            "count": int(count),
        }
        for check, count in invariant_counts.items()
        if count
    ]
    context = {"relative_path": rel, "gpu": gpu, "model": model, "kind": kind}
    dup_summary, dup_top = aggregate_duplicate_shape_quality(df, keys, ops, context)
    inventory = {
        **context,
        "bytes": int(path.stat().st_size),
        "rows": int(len(df)),
        "columns": int(len(columns)),
        "schema_hash": schema_hash,
        "operator_count": int(len(ops)),
        "shape_key_count": int(len(keys)),
        "key_null_rows": key_null_rows,
        "exact_duplicate_rows_all_copies": int(exact_duplicate_mask.sum()),
        "exact_duplicate_rows_removable": int(df.duplicated().sum()),
        "unique_shapes": int(len(shape_sizes)),
        "repeated_shape_groups": int(len(repeated_shapes)),
        "rows_in_repeated_shapes": int(repeated_shapes.sum()),
        "max_rows_per_shape": int(shape_sizes.max()),
    }
    return inventory, missing_rows, jitter_rows, violation_rows, dup_summary + dup_top


def runtime_summaries(root: Path, path: Path) -> list[dict[str, object]]:
    rel, gpu, model, kind = file_meta(root, path)
    df = pd.read_csv(path)
    ops = operator_columns(df.columns)
    rows: list[dict[str, object]] = []
    group_cols = ["num_tensor_parallel_workers"]
    if kind == "attention":
        group_cols += ["is_prefill", "attention_backend"]
    for group_key, part in df.groupby(group_cols, dropna=False):
        group_key = group_key if isinstance(group_key, tuple) else (group_key,)
        group_values = dict(zip(group_cols, group_key))
        for op, stats in ops.items():
            median_col = stats.get("median")
            if not median_col:
                continue
            values = part[median_col].dropna()
            if values.empty:
                continue
            rows.append(
                {
                    "relative_path": rel,
                    "gpu": gpu,
                    "model": model,
                    "kind": kind,
                    **group_values,
                    "operator": op,
                    "samples": int(len(values)),
                    "runtime_min": float(values.min()),
                    "runtime_p10": q(values, 10),
                    "runtime_p50": q(values, 50),
                    "runtime_p90": q(values, 90),
                    "runtime_p95": q(values, 95),
                    "runtime_p99": q(values, 99),
                    "runtime_max": float(values.max()),
                }
            )
    return rows


def timing_quantization_summaries(root: Path, path: Path) -> list[dict[str, object]]:
    """Audit the observable resolution of stored median timings.

    CUDA/Kineto durations are recorded in milliseconds. Attention medians come
    from five active samples, while MLP medians generally come from 20 traced
    operator instances; consequently 1 us and 0.5 us grids are expected.
    """
    rel, gpu, model, kind = file_meta(root, path)
    df = pd.read_csv(path)
    rows: list[dict[str, object]] = []
    for op, stats in operator_columns(df.columns).items():
        median_col = stats.get("median")
        if not median_col:
            continue
        values = pd.to_numeric(df[median_col], errors="coerce").dropna().to_numpy(dtype=float)
        positive = values[values > 0]
        if not len(values):
            continue
        rows.append(
            {
                "relative_path": rel,
                "gpu": gpu,
                "model": model,
                "kind": kind,
                "operator": op,
                "nonmissing": int(len(values)),
                "zero_count": int((values == 0).sum()),
                "positive_count": int(len(positive)),
                "min_positive_ms": float(positive.min()) if len(positive) else None,
                "integer_microsecond_grid_fraction": float(np.isclose(positive * 1000, np.round(positive * 1000), atol=1e-8).mean()) if len(positive) else None,
                "half_microsecond_grid_fraction": float(np.isclose(positive * 2000, np.round(positive * 2000), atol=1e-8).mean()) if len(positive) else None,
                "unique_positive_medians": int(len(np.unique(positive))),
            }
        )
    return rows


def step_stats(values: Iterable[float]) -> dict[str, object]:
    arr = np.sort(np.unique(np.asarray(list(values), dtype=float)))
    diffs = np.diff(arr)
    if not len(diffs):
        return {
            "axis_unique": int(len(arr)),
            "axis_min": safe_float(arr.min()) if len(arr) else None,
            "axis_max": safe_float(arr.max()) if len(arr) else None,
            "step_min": None,
            "step_median": None,
            "step_mode": None,
            "step_max": None,
            "largest_gap_left": None,
            "largest_gap_right": None,
        }
    rounded = np.round(diffs, 9)
    mode = Counter(rounded).most_common(1)[0][0]
    idx = int(np.argmax(diffs))
    return {
        "axis_unique": int(len(arr)),
        "axis_min": float(arr.min()),
        "axis_max": float(arr.max()),
        "step_min": float(diffs.min()),
        "step_median": float(np.median(diffs)),
        "step_mode": float(mode),
        "step_max": float(diffs.max()),
        "largest_gap_left": float(arr[idx]),
        "largest_gap_right": float(arr[idx + 1]),
    }


def coverage_summaries(root: Path, path: Path) -> tuple[list[dict[str, object]], list[dict[str, object]]]:
    rel, gpu, model, kind = file_meta(root, path)
    df = pd.read_csv(path).drop_duplicates()
    coverage: list[dict[str, object]] = []
    steps: list[dict[str, object]] = []
    if kind == "mlp":
        for tp, part in df.groupby("num_tensor_parallel_workers"):
            stats = step_stats(part["num_tokens"])
            coverage.append(
                {
                    "relative_path": rel,
                    "gpu": gpu,
                    "model": model,
                    "kind": kind,
                    "tp": int(tp),
                    "phase": "token",
                    "rows": int(len(part)),
                    "unique_shapes": int(part[shape_keys(kind, part.columns)].drop_duplicates().shape[0]),
                    **stats,
                    "axis": "num_tokens",
                    "cartesian_candidates": int(stats["axis_unique"]),
                    "coverage_fraction": 1.0,
                }
            )
            unique_steps = pd.Series(np.diff(np.sort(part["num_tokens"].unique()))).value_counts().sort_index()
            for step, count in unique_steps.items():
                steps.append({"relative_path": rel, "gpu": gpu, "model": model, "kind": kind, "tp": int(tp), "phase": "token", "axis": "num_tokens", "step": float(step), "count": int(count)})
        return coverage, steps

    group_cols = ["num_tensor_parallel_workers", "attention_backend", "max_model_len", "is_prefill"]
    for group_key, part in df.groupby(group_cols, dropna=False):
        tp, backend, max_len, is_prefill = group_key
        phase = "prefill" if bool(is_prefill) else "decode"
        if phase == "decode":
            axes = ["batch_size", "kv_cache_size"]
            observed = part[axes].drop_duplicates()
            candidates = int(part["batch_size"].nunique() * part["kv_cache_size"].nunique())
            valid_candidates = candidates
            axis_for_summary = "kv_cache_size"
        else:
            axes = ["batch_size", "prefill_chunk_size", "kv_cache_size"]
            observed = part[axes].drop_duplicates()
            batches = np.sort(part["batch_size"].unique())
            prefills = np.sort(part["prefill_chunk_size"].unique())
            kvs = np.sort(part["kv_cache_size"].unique())
            candidates = int(len(batches) * len(prefills) * len(kvs))
            valid_candidates = int(
                len(batches)
                * sum(1 for p in prefills for kv in kvs if p + kv <= max_len)
            )
            axis_for_summary = "prefill_chunk_size"
        base = {
            "relative_path": rel,
            "gpu": gpu,
            "model": model,
            "kind": kind,
            "tp": int(tp),
            "phase": phase,
            "attention_backend": backend,
            "max_model_len": int(max_len),
            "rows": int(len(part)),
            "unique_shapes": int(len(observed)),
            "batch_size_unique": int(part["batch_size"].nunique()),
            "batch_size_min": int(part["batch_size"].min()),
            "batch_size_max": int(part["batch_size"].max()),
            "kv_cache_size_unique": int(part["kv_cache_size"].nunique()),
            "kv_cache_size_min": int(part["kv_cache_size"].min()),
            "kv_cache_size_max": int(part["kv_cache_size"].max()),
            "prefill_chunk_size_unique": int(part["prefill_chunk_size"].nunique()),
            "prefill_chunk_size_min": int(part["prefill_chunk_size"].min()),
            "prefill_chunk_size_max": int(part["prefill_chunk_size"].max()),
            "cartesian_candidates": candidates,
            "valid_candidates_observed_axes": valid_candidates,
            "coverage_fraction": float(len(observed) / candidates) if candidates else None,
            "valid_coverage_fraction": float(len(observed) / valid_candidates) if valid_candidates else None,
            "axis": axis_for_summary,
            **step_stats(part[axis_for_summary]),
        }
        coverage.append(base)
        for axis in axes:
            unique_steps = pd.Series(np.diff(np.sort(part[axis].unique()))).value_counts().sort_index()
            for step, count in unique_steps.items():
                steps.append({"relative_path": rel, "gpu": gpu, "model": model, "kind": kind, "tp": int(tp), "phase": phase, "attention_backend": backend, "axis": axis, "step": float(step), "count": int(count)})
    return coverage, steps


def adjacent_pairs(
    frame: pd.DataFrame,
    group_cols: list[str],
    x_col: str,
    y_col: str,
    work_fn,
    context: dict[str, object],
    axis: str,
) -> tuple[dict[str, object] | None, list[dict[str, object]], list[dict[str, object]]]:
    pair_records: list[dict[str, object]] = []
    boundary_records: list[dict[str, object]] = []
    curve_count = 0
    for group_key, part in frame.groupby(group_cols, dropna=False) if group_cols else [((), frame)]:
        grouped = part.groupby(x_col, as_index=False)[y_col].median().dropna().sort_values(x_col)
        if len(grouped) < 2:
            continue
        curve_count += 1
        group_key = group_key if isinstance(group_key, tuple) else (group_key,)
        group_values = dict(zip(group_cols, group_key))
        xs = grouped[x_col].to_numpy(dtype=float)
        ys = grouped[y_col].to_numpy(dtype=float)
        for i in range(1, len(grouped)):
            x0, x1, y0, y1 = xs[i - 1], xs[i], ys[i - 1], ys[i]
            if y0 <= 0 or y1 < 0:
                continue
            runtime_ratio = y1 / y0
            w0 = work_fn(x0, group_values)
            w1 = work_fn(x1, group_values)
            work_ratio = w1 / w0 if w0 > 0 and w1 > 0 else np.nan
            excess_ratio = runtime_ratio / work_ratio if np.isfinite(work_ratio) and work_ratio > 0 else np.nan
            rec = {
                **context,
                "axis": axis,
                **group_values,
                "x_prev": x0,
                "x_curr": x1,
                "x_step": x1 - x0,
                "runtime_prev": y0,
                "runtime_curr": y1,
                "runtime_ratio": runtime_ratio,
                "runtime_delta_ms": y1 - y0,
                "runtime_change_pct": (runtime_ratio - 1) * 100,
                "work_ratio": safe_float(work_ratio),
                "excess_ratio": safe_float(excess_ratio),
                "abs_log_excess": float(abs(math.log(excess_ratio))) if np.isfinite(excess_ratio) and excess_ratio > 0 else None,
            }
            pair_records.append(rec)
    if not pair_records:
        return None, [], boundary_records
    pairs = pd.DataFrame(pair_records)
    valid_excess = pairs.dropna(subset=["abs_log_excess"])
    for boundary in BOUNDARIES:
        on = valid_excess.loc[valid_excess["x_curr"].mod(boundary).eq(0), "abs_log_excess"]
        off = valid_excess.loc[~valid_excess["x_curr"].mod(boundary).eq(0), "abs_log_excess"]
        if len(on) == 0 or len(off) == 0:
            continue
        on_med, off_med = float(on.median()), float(off.median())
        boundary_records.append(
            {
                **context,
                "axis": axis,
                "boundary": boundary,
                "n_on": int(len(on)),
                "n_off": int(len(off)),
                "median_abs_log_excess_on": on_med,
                "median_abs_log_excess_off": off_med,
                "boundary_enrichment_ratio": on_med / off_med if off_med > 0 else None,
            }
        )
    ratios = pairs["runtime_ratio"].replace([np.inf, -np.inf], np.nan).dropna()
    decreases = (ratios < 1).sum()
    summary = {
        **context,
        "axis": axis,
        "curves": int(curve_count),
        "adjacent_pairs": int(len(ratios)),
        "decrease_any": int(decreases),
        "decrease_gt_2pct": int((ratios < 0.98).sum()),
        "decrease_gt_5pct": int((ratios < 0.95).sum()),
        "decrease_gt_10pct": int((ratios < 0.90).sum()),
        "decrease_gt_5pct_fraction": float((ratios < 0.95).mean()),
        "unchanged_exact": int(np.isclose(ratios, 1.0, atol=1e-12, rtol=0).sum()),
        "unchanged_exact_fraction": float(np.isclose(ratios, 1.0, atol=1e-12, rtol=0).mean()),
        "increase_gt_5pct": int((ratios > 1.05).sum()),
        "increase_gt_5pct_fraction": float((ratios > 1.05).mean()),
        "largest_decrease_pct": float((1 - ratios.min()) * 100),
        "largest_increase_pct": float((ratios.max() - 1) * 100),
        "abs_runtime_delta_ms_p50": q(pairs["runtime_delta_ms"].abs(), 50),
        "abs_runtime_delta_ms_p95": q(pairs["runtime_delta_ms"].abs(), 95),
        "runtime_ratio_p50": q(ratios, 50),
        "runtime_ratio_p95": q(ratios, 95),
        "abs_log_excess_p50": q(pairs["abs_log_excess"].dropna(), 50),
        "abs_log_excess_p95": q(pairs["abs_log_excess"].dropna(), 95),
        "abs_log_excess_max": safe_float(pairs["abs_log_excess"].max()),
    }
    top = pairs.sort_values(["abs_log_excess", "runtime_change_pct"], ascending=False).head(25).to_dict("records")
    return summary, top, boundary_records


def curve_analysis(root: Path, path: Path) -> tuple[list[dict[str, object]], list[dict[str, object]], list[dict[str, object]]]:
    rel, gpu, model, kind = file_meta(root, path)
    df = pd.read_csv(path).drop_duplicates()
    ops = operator_columns(df.columns)
    summaries: list[dict[str, object]] = []
    top: list[dict[str, object]] = []
    boundaries: list[dict[str, object]] = []
    if kind == "mlp":
        for tp, part in df.groupby("num_tensor_parallel_workers"):
            for op, stats in ops.items():
                y_col = stats.get("median")
                if not y_col or part[y_col].notna().sum() < 2:
                    continue
                context = {"relative_path": rel, "gpu": gpu, "model": model, "kind": kind, "tp": int(tp), "phase": "token", "operator": op}
                summary, jumps, boundary = adjacent_pairs(part, [], "num_tokens", y_col, lambda x, _: x, context, "num_tokens")
                if summary:
                    summaries.append(summary)
                top.extend(jumps)
                boundaries.extend(boundary)
        return summaries, top, boundaries

    for (tp, backend, is_prefill), part in df.groupby(["num_tensor_parallel_workers", "attention_backend", "is_prefill"], dropna=False):
        phase = "prefill" if bool(is_prefill) else "decode"
        target_op = "attn_prefill" if phase == "prefill" else "attn_decode"
        if target_op not in ops or not ops[target_op].get("median"):
            continue
        y_col = ops[target_op]["median"]
        context = {"relative_path": rel, "gpu": gpu, "model": model, "kind": kind, "tp": int(tp), "phase": phase, "attention_backend": backend, "operator": target_op}
        if phase == "decode":
            specs = [
                (["batch_size"], "kv_cache_size", lambda x, g: max(x, 1) * max(float(g["batch_size"]), 1), "kv_cache_size"),
                (["kv_cache_size"], "batch_size", lambda x, g: max(x, 1) * max(float(g["kv_cache_size"]), 1), "batch_size"),
            ]
        else:
            specs = [
                (["batch_size", "kv_cache_size"], "prefill_chunk_size", lambda x, g: max(x, 1) * (max(x, 1) + max(float(g["kv_cache_size"]), 0)), "prefill_chunk_size"),
                (["batch_size", "prefill_chunk_size"], "kv_cache_size", lambda x, g: max(float(g["prefill_chunk_size"]), 1) * (max(float(g["prefill_chunk_size"]), 1) + max(x, 0)), "kv_cache_size"),
            ]
        for groups, x_col, work_fn, axis in specs:
            summary, jumps, boundary = adjacent_pairs(part, groups, x_col, y_col, work_fn, context, axis)
            if summary:
                summaries.append(summary)
            top.extend(jumps)
            boundaries.extend(boundary)
    return summaries, top, boundaries


def summarize_boundaries(records: list[dict[str, object]]) -> pd.DataFrame:
    return pd.DataFrame(records)


def comparable_frame(path: Path, kind: str, operator: str) -> tuple[pd.DataFrame, list[str]]:
    header = pd.read_csv(path, nrows=0).columns
    target = f"time_stats.{operator}.median"
    if target not in header:
        return pd.DataFrame(), []
    keys = shape_keys(kind, header)
    df = pd.read_csv(path, usecols=keys + [target]).dropna(subset=[target])
    grouped = df.groupby(keys, dropna=False, as_index=False)[target].median()
    return grouped, keys


def cross_gpu_speedups(root: Path, files: list[Path]) -> tuple[pd.DataFrame, pd.DataFrame]:
    path_map: dict[tuple[str, str, str], Path] = {}
    models_by_kind: dict[str, set[str]] = defaultdict(set)
    for path in files:
        _, gpu, model, kind = file_meta(root, path)
        path_map[(gpu, model, kind)] = path
        models_by_kind[kind].add(model)
    detail_rows: list[pd.DataFrame] = []
    summary_rows: list[dict[str, object]] = []
    pairs = [("a40", "a100"), ("a100", "h100"), ("a40", "h100")]
    for kind, models in models_by_kind.items():
        for model in sorted(models):
            if not all((gpu, model, kind) in path_map for gpu in ("a40", "a100", "h100")):
                continue
            headers = {gpu: pd.read_csv(path_map[(gpu, model, kind)], nrows=0).columns for gpu in ("a40", "a100", "h100")}
            common_ops = set(operator_columns(headers["a40"])) & set(operator_columns(headers["a100"])) & set(operator_columns(headers["h100"]))
            if kind == "attention":
                common_ops &= {"attn_decode", "attn_prefill", "attn_input_reshape", "attn_output_reshape"}
            for op in sorted(common_ops):
                frames: dict[str, pd.DataFrame] = {}
                common_keys: list[str] | None = None
                for gpu in ("a40", "a100", "h100"):
                    frame, keys = comparable_frame(path_map[(gpu, model, kind)], kind, op)
                    if frame.empty:
                        break
                    common_keys = keys if common_keys is None else [key for key in common_keys if key in keys]
                    frames[gpu] = frame
                if len(frames) != 3 or not common_keys:
                    continue
                target = f"time_stats.{op}.median"
                for from_gpu, to_gpu in pairs:
                    left = frames[from_gpu][common_keys + [target]].rename(columns={target: "runtime_from"})
                    right = frames[to_gpu][common_keys + [target]].rename(columns={target: "runtime_to"})
                    merged = left.merge(right, on=common_keys, how="inner")
                    merged = merged[(merged["runtime_from"] > 0) & (merged["runtime_to"] > 0)].copy()
                    if merged.empty:
                        continue
                    merged["speedup_from_over_to"] = merged["runtime_from"] / merged["runtime_to"]
                    merged.insert(0, "kind", kind)
                    merged.insert(0, "operator", op)
                    merged.insert(0, "model", model)
                    merged.insert(0, "to_gpu", to_gpu)
                    merged.insert(0, "from_gpu", from_gpu)
                    for tp, tp_part in merged.groupby("num_tensor_parallel_workers", dropna=False):
                        values = tp_part["speedup_from_over_to"]
                        summary_rows.append({"from_gpu": from_gpu, "to_gpu": to_gpu, "model": model, "operator": op, "kind": kind, "num_tensor_parallel_workers": tp, "common_shapes": int(len(values)), "speedup_min": float(values.min()), "speedup_p10": q(values, 10), "speedup_p50": q(values, 50), "speedup_p90": q(values, 90), "speedup_p95": q(values, 95), "speedup_max": float(values.max()), "fraction_to_gpu_slower": float((values < 1).mean())})
                        # Keep only extreme exact-shape examples, not every joined row.
                        ordered = tp_part.sort_values("speedup_from_over_to")
                        samples = pd.concat([ordered.head(10), ordered.tail(10)]).drop_duplicates()
                        detail_rows.append(samples)
    detail = pd.concat(detail_rows, ignore_index=True, sort=False) if detail_rows else pd.DataFrame()
    return detail, pd.DataFrame(summary_rows)


def tp_scaling(root: Path, files: list[Path]) -> pd.DataFrame:
    rows: list[dict[str, object]] = []
    for path in files:
        rel, gpu, model, kind = file_meta(root, path)
        header = pd.read_csv(path, nrows=0).columns
        ops = operator_columns(header)
        if kind == "attention":
            op_names = sorted(set(ops) & {"attn_decode", "attn_prefill"})
        else:
            op_names = sorted(ops)
        for op in op_names:
            target = f"time_stats.{op}.median"
            keys = shape_keys(kind, header)
            tp_col = "num_tensor_parallel_workers"
            join_keys = [key for key in keys if key != tp_col]
            df = pd.read_csv(path, usecols=keys + [target]).dropna(subset=[target])
            grouped = df.groupby(keys, dropna=False, as_index=False)[target].median()
            base = grouped[grouped[tp_col] == 1][join_keys + [target]].rename(columns={target: "runtime_tp1"})
            for tp in (2, 4, 8):
                other = grouped[grouped[tp_col] == tp][join_keys + [target]].rename(columns={target: "runtime_tp"})
                merged = base.merge(other, on=join_keys, how="inner")
                merged = merged[(merged["runtime_tp1"] > 0) & (merged["runtime_tp"] > 0)]
                if merged.empty:
                    continue
                speedup = merged["runtime_tp1"] / merged["runtime_tp"]
                rows.append({"relative_path": rel, "gpu": gpu, "model": model, "kind": kind, "operator": op, "tp": tp, "common_shapes": int(len(speedup)), "compute_speedup_p10": q(speedup, 10), "compute_speedup_p50": q(speedup, 50), "compute_speedup_p90": q(speedup, 90), "compute_speedup_max": float(speedup.max()), "fraction_slower_than_tp1": float((speedup < 1).mean()), "parallel_efficiency_p50": float(np.median(speedup) / tp)})
    return pd.DataFrame(rows)


def write_frame(frame: pd.DataFrame, path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    frame.to_csv(path, index=False)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--input-root", type=Path, required=True)
    parser.add_argument("--output-dir", type=Path, required=True)
    args = parser.parse_args()
    input_root = args.input_root.resolve()
    output_dir = args.output_dir.resolve()
    output_dir.mkdir(parents=True, exist_ok=True)
    if input_root in output_dir.parents or input_root == output_dir:
        raise ValueError("Output directory must be outside the official compute input root")

    started = time.perf_counter()
    files = sorted(input_root.rglob("*.csv"))
    inventory_rows: list[dict[str, object]] = []
    missing_rows: list[dict[str, object]] = []
    jitter_rows: list[dict[str, object]] = []
    violation_rows: list[dict[str, object]] = []
    duplicate_rows: list[dict[str, object]] = []
    runtime_rows: list[dict[str, object]] = []
    coverage_rows: list[dict[str, object]] = []
    step_rows: list[dict[str, object]] = []
    monotonic_rows: list[dict[str, object]] = []
    jump_rows: list[dict[str, object]] = []
    boundary_rows: list[dict[str, object]] = []
    quantization_rows: list[dict[str, object]] = []
    schemas: dict[str, dict[str, object]] = {}

    for path in files:
        inventory, missing, jitter, violations, duplicates = audit_file(input_root, path)
        inventory_rows.append(inventory)
        missing_rows.extend(missing)
        jitter_rows.extend(jitter)
        violation_rows.extend(violations)
        duplicate_rows.extend(duplicates)
        runtime_rows.extend(runtime_summaries(input_root, path))
        quantization_rows.extend(timing_quantization_summaries(input_root, path))
        coverage, steps = coverage_summaries(input_root, path)
        coverage_rows.extend(coverage)
        step_rows.extend(steps)
        monotonic, jumps, boundaries = curve_analysis(input_root, path)
        monotonic_rows.extend(monotonic)
        jump_rows.extend(jumps)
        boundary_rows.extend(boundaries)
        header = list(pd.read_csv(path, nrows=0).columns)
        schema_hash = hashlib.md5("||".join(header).encode()).hexdigest()[:8]
        schemas.setdefault(schema_hash, {"column_count": len(header), "columns": header, "files": []})["files"].append(str(path.relative_to(input_root)))

    inventory_df = pd.DataFrame(inventory_rows)
    missing_df = pd.DataFrame(missing_rows)
    jitter_df = pd.DataFrame(jitter_rows)
    violations_df = pd.DataFrame(violation_rows)
    duplicates_df = pd.DataFrame(duplicate_rows)
    runtime_df = pd.DataFrame(runtime_rows)
    coverage_df = pd.DataFrame(coverage_rows)
    steps_df = pd.DataFrame(step_rows)
    monotonic_df = pd.DataFrame(monotonic_rows)
    jumps_df = pd.DataFrame(jump_rows)
    boundary_df = summarize_boundaries(boundary_rows)
    quantization_df = pd.DataFrame(quantization_rows)
    speedup_detail, speedup_summary = cross_gpu_speedups(input_root, files)
    tp_scaling_df = tp_scaling(input_root, files)

    write_frame(inventory_df, output_dir / "file_inventory.csv")
    write_frame(missing_df, output_dir / "column_missingness.csv")
    write_frame(jitter_df, output_dir / "within_row_jitter.csv")
    write_frame(violations_df, output_dir / "invariant_violations.csv")
    write_frame(duplicates_df, output_dir / "duplicate_shape_quality.csv")
    write_frame(runtime_df, output_dir / "operator_runtime_summary.csv")
    write_frame(coverage_df, output_dir / "shape_coverage.csv")
    write_frame(steps_df, output_dir / "sampling_steps.csv")
    write_frame(monotonic_df, output_dir / "monotonicity_summary.csv")
    write_frame(jumps_df, output_dir / "top_local_jumps.csv")
    write_frame(boundary_df, output_dir / "boundary_quantization_summary.csv")
    write_frame(quantization_df, output_dir / "timing_quantization.csv")
    write_frame(speedup_detail, output_dir / "cross_gpu_speedup_detail.csv")
    write_frame(speedup_summary, output_dir / "cross_gpu_speedup_summary.csv")
    write_frame(tp_scaling_df, output_dir / "tp_compute_scaling_summary.csv")
    (output_dir / "schemas.json").write_text(json.dumps(schemas, indent=2), encoding="utf-8")

    summary = {
        "note": "Read-only supplemental audit of Vidur current-main compute profiles",
        "input_root": str(input_root),
        "output_dir": str(output_dir),
        "python": platform.python_version(),
        "pandas": pd.__version__,
        "sklearn": sklearn.__version__,
        "files": int(len(files)),
        "bytes": int(inventory_df["bytes"].sum()),
        "rows": int(inventory_df["rows"].sum()),
        "schemas": int(len(schemas)),
        "files_by_gpu": inventory_df.groupby("gpu").size().to_dict(),
        "rows_by_gpu": inventory_df.groupby("gpu")["rows"].sum().to_dict(),
        "files_by_kind": inventory_df.groupby("kind").size().to_dict(),
        "rows_by_kind": inventory_df.groupby("kind")["rows"].sum().to_dict(),
        "exact_duplicate_rows_all_copies": int(inventory_df["exact_duplicate_rows_all_copies"].sum()),
        "exact_duplicate_rows_removable": int(inventory_df["exact_duplicate_rows_removable"].sum()),
        "repeated_shape_groups": int(inventory_df["repeated_shape_groups"].sum()),
        "rows_in_repeated_shapes": int(inventory_df["rows_in_repeated_shapes"].sum()),
        "key_null_rows": int(inventory_df["key_null_rows"].sum()),
        "nonzero_invariant_checks": int(len(violations_df)),
        "hard_invariant_checks": int((violations_df.get("category", pd.Series(dtype=str)) == "hard_invariant").sum()),
        "schema_semantic_checks": int((violations_df.get("category", pd.Series(dtype=str)) == "schema_semantics").sum()),
        "elapsed_seconds": round(time.perf_counter() - started, 6),
        "method": {
            "monotonic_violation": "adjacent median runtime decrease; thresholds 2%, 5%, 10%",
            "attention_prefill_work_proxy": "p * (p + kv)",
            "attention_decode_work_proxy": "batch * max(kv, 1)",
            "quantization_boundary": "compare abs(log(runtime_ratio/work_ratio)) when x_curr is/is not divisible by boundary",
            "cross_gpu_speedup": "median runtime on identical model, TP, backend and exact shape; from_gpu/to_gpu",
        },
    }
    (output_dir / "audit_summary.json").write_text(json.dumps(summary, indent=2), encoding="utf-8")
    print(json.dumps(summary, indent=2))


if __name__ == "__main__":
    main()

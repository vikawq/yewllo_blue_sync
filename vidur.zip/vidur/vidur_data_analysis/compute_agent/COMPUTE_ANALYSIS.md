# Vidur compute profiling CSV 只读审计

## 结论先行

本报告只分析当前本地仓库（commit `8383d2935bc62723a212090baa9f98ada206fc14`）中
`data/profiling/compute/**/*.csv` 的公开数据；它不是论文同期数据的重新采集，也没有把本文的附加统计冒充为 Vidur 论文结果。官方目录全程只读，脚本、日志和所有中间表都写在 `D:\workspaces\trace\vidur_data_analysis\compute_agent`。

最重要的定量结论如下。

1. 共 **40 个 CSV、238,768,309 bytes、1,217,254 行**；attention 20 文件/1,197,163 行，MLP 20 文件/20,091 行。A100 有 16 文件/502,708 行；A40、H100 各 12 文件/357,273 行。
2. 数据存在 **4 套 schema**：旧 attention 31 列（18 文件）、Llama3 attention 36 列（2 文件，多 `attn_kv_cache_save`）、标准 MLP 58 列（17 文件）、Phi-2 MLP 53 列（3 文件，按模型设计无 post-attention norm）。因此“所有模型同一 operator 集”这一假设不成立。
3. shape key 无缺失，未发现负时间、`min/mean/median/max` 次序错误、不完整五元统计或 prefill 标志与 chunk 大小矛盾。唯一硬异常是 **A100/Qwen-72B/TP1 decode 的 16 行 `attn_decode.median=0`，但 mean=0.0154--0.2114 ms、max 最高 0.529 ms**；这些点会制造 100% 局部下降，必须重测或剔除。
4. 有 **3,108 行可删除的逐列完全重复行**（所有复制行合计 6,171）；另有 28,744 个重复 shape 组、57,830 行落在重复 shape 中。它们主要不是随机复测，而是采样器边界重叠（例如 1024 同时属于相邻网格段，以及 prefill 的 chunk/full-prefill 构造重叠），因此不能把重复数直接解释为重复实验次数。
5. 同 shape 重复值仍可提供噪声线索：`attn_decode` 13,602 组，文件内组 CV 的中位数之中位数 **0.291%**、p95 之中位数 **1.866%**；`attn_prefill` 19,362 组，对应 **0.466% / 2.969%**。MLP 四个主投影各 166 组，组 CV p95 的文件中位数约 **1.30%--1.72%**。`attn_kv_cache_save` 的重复组 CV p95 中位数为 **12.726%**，但不少绝对值很小。
6. 单行内的 5/20 次采样抖动：A100/A40/H100 的 `attn_decode` 文件级 CV p95 中位数分别 **2.144% / 0.941% / 2.761%**；`attn_prefill` 为 **2.218% / 2.727% / 2.547%**。H100 MLP 投影的尾部噪声明显更高：`attn_pre_proj`、`mlp_up_proj`、`mlp_down_proj` 的 CV p95 文件中位数分别 **11.371% / 8.528% / 8.527%**，而 A100 分别 **2.556% / 2.097% / 2.666%**。
7. 存储值有明显量化：**2,394,310 个正 attention median 全部落在 1 us 网格**；**200,127 个正 MLP median 全部落在 0.5 us 网格**（其中 88.37% 落在整数 us）。所以 0.001--0.01 ms 小算子的百分比抖动、平台期和跳变很大一部分是计时分辨率效应，必须同时报告绝对误差。
8. 6 个共同模型（CodeLlama-34B、InternLM-20B、Llama2-70B/7B、Phi-2、Qwen-72B）在三种 GPU 上具有同 schema/shape 网格。旧 attention 每 TP 的 decode 为 **128 batch × 79 KV = 10,112 个唯一 shape，覆盖率 100%**；prefill 在观测轴与 `prefill+KV<=4096` 约束下为 **4,206 个唯一 shape，覆盖率 100%**。
9. 旧 MLP 每 TP 有 **259 个唯一 token 点，1--4096**；主步长 8，2048 后最大步长 32。Llama3 MLP 每 TP 有 **451 个唯一点，1--32768**，中位步长 32、最大 256。所有网格都是越往大 shape 越稀，无法验证相邻 `x±1` 的微架构断点。
10. 标准 attention prefill 最小 chunk 为 **64**，因此 1--63 token 是训练空洞；标准 decode 最小 KV 为 32。若预测器在这些范围生成点，只能依赖树模型的区间常数/边界外推，不能称为实测插值。
11. Llama3 attention 仅有 A100/FlashInfer/max_model_len=16384，不能与旧模型的 FlashAttention/4096 数据作干净的“模型代际”或跨 GPU比较。其 prefill 每 TP 2,371 个唯一 shape，相对观测轴笛卡尔积仅 **3.701%**，但这基本对应当前采样器“KV 为 chunk 的整数倍 + full-prefill”设计，不是随机丢数。decode 则受显存过滤：70B 的 TP1/2/4/8 覆盖候选网格 **91.58%/96.42%/99.87%/100%**；8B 只有 TP1/4，覆盖 **69.67%/93.28%**。
12. 相邻点并不严格单调。以 `runtime` 比前一点下降超过 5% 为阈值：A100/A40/H100 decode 沿 batch 的比例为 **0.887%/0.314%/1.439%**，沿 KV 为 **0.677%/0.343%/1.109%**；prefill 沿 chunk 为 **1.480%/1.945%/2.381%**，沿 KV 为 **4.771%/5.685%/5.899%**。这证明曲线存在平台、噪声和局部 regime change；但单调性不是物理硬约束，不能把每次下降都标为坏数据。
13. 局部跳变可很大且具有工程意义：例如 H100/Qwen-72B/TP1 `mlp_down_proj` 从 token 512 到 520，work proxy 仅增 **1.56%**，median 从 **0.2310 到 0.6525 ms（+182.47%）**；A40/Qwen-72B/TP1 同算子 256 到 264 从 **1.043 到 2.919 ms（+179.87%）**。这类点支持在 NPU 上使用分段/边界感知学习，而非强制光滑函数。
14. 用 `abs(log(runtime_ratio/work_ratio))` 检查 8--1024 倍数边界时，最稳定的信号出现在 prefill 的 KV：在 H100 的 24 个 model/TP cell 中，KV 到达 128/256/512 倍数的边界偏差中位富集比分别 **1.563/1.401/1.341，24/24 cell 均 >1**；A100 对应 **1.353/1.267/1.217，27/30 cell >1**。但采样步长本身也在这些边界改变，因此这是“候选量化/网格效应”，不是已识别的 kernel 因果。
15. 仅按相同 model、TP、backend、精确 shape 比较，6 个共同模型各 24 个 model×TP cell 的中位 speedup 之中位数：A40→A100 为 decode **2.583×**、prefill **1.849×**、四个主 MLP 投影约 **1.969--2.015×**；A100→H100 为 decode **1.690×**、prefill **1.497×**、四个主投影约 **2.800--2.923×**。TP 的 compute-only 中位扩展也很高（例如 A100 `mlp_up_proj` TP2/4/8 为 **2.013×/4.036×/8.016×**），但这里没有通信、调度、CPU 或整层同步，**绝不能当端到端 TP speedup**。

## 资产、字段与缺失语义

| GPU | 类型 | 文件 | 模型 | 行数 | 唯一 shape（逐文件求和） | 可删除完全重复行 |
|---|---:|---:|---:|---:|---:|---:|
| A100 | attention | 8 | 8 | 493,579 | 480,979 | 1,153 |
| A100 | MLP | 8 | 8 | 9,129 | 9,047 | 0 |
| A40 | attention | 6 | 6 | 351,792 | 343,632 | 405 |
| A40 | MLP | 6 | 6 | 5,481 | 5,439 | 0 |
| H100 | attention | 6 | 6 | 351,792 | 343,632 | 1,550 |
| H100 | MLP | 6 | 6 | 5,481 | 5,439 | 0 |

attention 的 `attn_decode`/`attn_prefill` 旧 schema 中，非本 phase 的列为空是结构性缺失，不是测量失败。Llama3 schema 则把非本 phase 的 target 写成 0，并新增 `attn_kv_cache_save`；审计表把这四项标成 `schema_semantics`，未算硬错误。`attn_input_reshape` 在所有 1,197,163 行的五个统计量均为 0；它在当前数据中没有学习信号。Phi-2 缺少 post-attention layernorm 也是模型结构语义。

## 曲线、网格和空洞

单调性分析先对完全相同的曲线条件聚合重复 shape 的 median，再按一个轴排序比较相邻点：

- MLP：固定 GPU/model/TP/operator，沿 `num_tokens`。
- decode：固定 GPU/model/TP/backend/batch，沿 KV；或固定 KV，沿 batch。
- prefill：固定 GPU/model/TP/backend/KV，沿 chunk；或固定 chunk，沿 KV。
- 报告任何下降以及下降超过 2%、5%、10%；正文使用 5% 阈值。
- work proxy 仅用于定位超额跳变：MLP=`tokens`，decode=`batch×KV`，prefill=`p×(p+KV)`。它不是精确 FLOP/bytes 模型。

采样网格的主要风险不是观测轴内随机缺行，而是：小 prefill 空洞；大 shape 采样渐稀；边界两侧缺少 `x±1`；Llama3 decode 的显存截断与 TP 强相关；Llama3 只在 A100；以及旧/新 attention backend 和 target schema 不同。对昇腾 NPU，最值得补采的是编译/搬运/tiling 边界两侧的邻域点、冷/热编译拆分、每 shape 多次独立进程/独立编译重复，并将 kernel/tiling ID、workspace、搬运路径、编译 cache hit、流水并行策略作为离散特征或 regime 标签。

## 可比与不可比

可比：同 GPU、同 model、同 TP、同 backend、同 operator、同精确 shape 的重复或邻点；跨 GPU 时必须保留同 model/TP/backend/operator/精确 shape。正文跨 GPU表严格采用该交集。

不可直接比较：不同 model 的绝对延迟；Llama3 FlashInfer 与旧 FlashAttention；不同 max_model_len/shape 域；受显存过滤后的 TP 网格总体分布；Llama3 `kv_cache_save` 与旧 schema 的“缺列/加载时补 0”；Phi-2 无 postnorm 与其他模型；以及任何 compute-only TP 比率与端到端吞吐/延迟。CSV 没有驱动、CUDA、PyTorch、Sarathi、时钟/功耗、具体 GPU SKU/显存、主机或采集日期元数据，因此跨 GPU比率只能描述这份数据，不能归因于纯硬件峰值。

## 数据质量优先级

1. **P0：**重测/剔除 A100 Qwen-72B TP1 的 16 个 zero-median positive-mean decode 点；训练前不要把它们当 0 ms 标签。
2. **P1：**按 shape 聚合重复行或保留 replicate ID；当前完全重复和构造性重叠会让随机 CV 给部分边界 shape 额外权重，并导致 train/test 泄漏。
3. **P1：**为数据集加入环境 manifest 与采集 run/worker/seed/时间戳；否则无法区分 GPU、软件版本、worker 或热状态的影响。
4. **P1：**对高抖动 H100 MLP 和 `kv_cache_save` 独立复测，并报告绝对 us 与相对 CV；小算子的百分比不能单独使用。
5. **P1：**评估学习器时使用整 shape/group holdout、连续区间 holdout、边界邻域 holdout和 OOD TP/backend holdout；不要随机拆重复行。

## 复现方法与产物

环境：Windows PowerShell；Python 3.12.13；pandas 3.0.5；scikit-learn 1.9.0。一次完整只读扫描约 76--79 秒。

```powershell
& 'D:\workspaces\trace\vidur_repro\.venv\Scripts\python.exe' `
  'D:\workspaces\trace\vidur_data_analysis\compute_agent\analyze_compute_profiles.py' `
  --input-root 'D:\workspaces\trace\vidur_repro\vidur\data\profiling\compute' `
  --output-dir 'D:\workspaces\trace\vidur_data_analysis\compute_agent\artifacts'

& 'D:\workspaces\trace\vidur_repro\.venv\Scripts\python.exe' `
  'D:\workspaces\trace\vidur_data_analysis\compute_agent\make_compact_summaries.py' `
  --artifacts 'D:\workspaces\trace\vidur_data_analysis\compute_agent\artifacts'
```

关键产物：

- `artifacts/audit_summary.json`：总资产、版本和方法摘要。
- `artifacts/file_inventory.csv`、`schemas.json`、`column_missingness.csv`、`invariant_violations.csv`：完整审计。
- `artifacts/shape_coverage.csv`、`sampling_steps.csv`：每 GPU/model/TP/phase 的 shape 域和步长。
- `artifacts/operator_runtime_summary.csv`：每 GPU/model/TP/phase/operator 的 min/p10/p50/p90/p95/p99/max（ms）。
- `artifacts/within_row_jitter.csv`、`duplicate_shape_quality.csv`、`timing_quantization.csv`：采样抖动、同 shape 差异和时间量化。
- `artifacts/monotonicity_summary.csv`、`top_local_jumps.csv`、`boundary_quantization_summary.csv`：单调性、局部跳变和候选边界效应。
- `artifacts/cross_gpu_speedup_summary.csv`、`cross_gpu_speedup_detail.csv`、`tp_compute_scaling_summary.csv`：严格 shape 交集的跨 GPU 与 compute-only TP 比率。
- `artifacts/compact_*.csv`：上述结果的报告级结构化汇总。

所有百分比和 speedup 均为描述性统计。跨 GPU/TP compact 表的“cell 中位数之中位数”用于避免大 shape 网格单纯按行数支配结论；原始 per-model/per-TP 结果保留在非 compact CSV 中。

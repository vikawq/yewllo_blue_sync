"""Audit Vidur repository CSVs against the current-main consumer contract.

This script is intentionally read-only with respect to the Vidur checkout.  It
writes only machine-readable audit artifacts next to this file.
"""

from __future__ import annotations

import csv
import json
import subprocess
import sys
from pathlib import Path

import numpy as np
import pandas as pd


EXPECTED_COMMIT = "8383d2935bc62723a212090baa9f98ada206fc14"
REPO = Path(__file__).resolve().parents[2] / "vidur_repro" / "vidur"
OUT = Path(__file__).resolve().parent


MODEL_SPECS = {
    "codellama/CodeLlama-34b-Instruct-hf": {
        "n_head": 64,
        "n_kv_head": 8,
        "n_embd": 8192,
        "n_expanded_embd": 22016,
        "vocab_size": 32768,
        "use_gated_mlp": True,
        "no_tensor_parallel": False,
    },
    "meta-llama/Llama-2-7b-hf": {
        "n_head": 32,
        "n_kv_head": 32,
        "n_embd": 4096,
        "n_expanded_embd": 11008,
        "vocab_size": 32768,
        "use_gated_mlp": True,
        "no_tensor_parallel": False,
    },
    "meta-llama/Llama-2-70b-hf": {
        "n_head": 64,
        "n_kv_head": 8,
        "n_embd": 8192,
        "n_expanded_embd": 28672,
        "vocab_size": 32768,
        "use_gated_mlp": True,
        "no_tensor_parallel": False,
    },
    "meta-llama/Meta-Llama-3-8B": {
        "n_head": 32,
        "n_kv_head": 8,
        "n_embd": 4096,
        "n_expanded_embd": 14336,
        "vocab_size": 128256,
        "use_gated_mlp": True,
        "no_tensor_parallel": False,
    },
    "meta-llama/Meta-Llama-3-70B": {
        "n_head": 64,
        "n_kv_head": 8,
        "n_embd": 8192,
        "n_expanded_embd": 28672,
        "vocab_size": 128256,
        "use_gated_mlp": True,
        "no_tensor_parallel": False,
    },
    "internlm/internlm-20b": {
        "n_head": 40,
        "n_kv_head": 40,
        "n_embd": 5120,
        "n_expanded_embd": 13824,
        "vocab_size": 103168,
        "use_gated_mlp": True,
        "no_tensor_parallel": False,
    },
    "internlm/internlm2-20b": {
        "n_head": 48,
        "n_kv_head": 8,
        "n_embd": 6144,
        "n_expanded_embd": 16384,
        "vocab_size": 92544,
        "use_gated_mlp": True,
        "no_tensor_parallel": False,
    },
    "microsoft/phi-2": {
        "n_head": 32,
        "n_kv_head": 32,
        "n_embd": 2560,
        "n_expanded_embd": 10240,
        "vocab_size": 51200,
        "use_gated_mlp": False,
        "no_tensor_parallel": True,
    },
    "Qwen/Qwen-72B": {
        "n_head": 64,
        "n_kv_head": 64,
        "n_embd": 8192,
        "n_expanded_embd": 24576,
        "vocab_size": 152064,
        "use_gated_mlp": True,
        "no_tensor_parallel": False,
    },
}

MLP_FILTER = [
    "n_head",
    "n_kv_head",
    "n_embd",
    "n_expanded_embd",
    "use_gated_mlp",
    "vocab_size",
    "num_tensor_parallel_workers",
]
MLP_REQUIRED_TARGETS = [
    "time_stats.attn_pre_proj.median",
    "time_stats.attn_post_proj.median",
    "time_stats.mlp_up_proj.median",
    "time_stats.mlp_down_proj.median",
    "time_stats.mlp_act.median",
    "time_stats.attn_rope.median",
]
MLP_OPTIONAL_ZERO = [
    "time_stats.input_layernorm.median",
    "time_stats.post_attention_layernorm.median",
    "time_stats.add.median",
]
MLP_REQUIRED = MLP_FILTER + ["num_tokens"] + MLP_REQUIRED_TARGETS

ATTENTION_FILTER = [
    "n_embd",
    "n_q_head",
    "n_kv_head",
    "block_size",
    "num_tensor_parallel_workers",
]
ATTENTION_REQUIRED = ATTENTION_FILTER + [
    "batch_size",
    "prefill_chunk_size",
    "kv_cache_size",
    "time_stats.attn_prefill.median",
    "time_stats.attn_decode.median",
]
ATTENTION_OPTIONAL_ZERO = ["time_stats.attn_kv_cache_save.median"]

ALL_REDUCE_REQUIRED = [
    "num_workers",
    "devices_per_node",
    "collective",
    "size",
    "time_stats.all_reduce.median",
]
SEND_RECV_REQUIRED = [
    "devices_per_node",
    "collective",
    "size",
    "time_stats.send_recv.median",
]
CPU_REQUIRED = [
    "model_name",
    "tensor_parallel_degree",
    "batch_size",
    "schedule_median",
    "sampler_e2e_median",
    "prepare_inputs_e2e_median",
    "process_model_outputs_median",
    "ray_comm_time_mean",
]

NODE_SIZES = {
    "a40_pairwise_nvlink": 8,
    "a100_pairwise_nvlink": 4,
    "h100_pairwise_nvlink": 4,
    "a100_dgx": 8,
    "h100_dgx": 8,
}


def js(value) -> str:
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"))


def write_csv(path: Path, rows: list[dict]) -> None:
    if not rows:
        return
    keys: list[str] = []
    for row in rows:
        for key in row:
            if key not in keys:
                keys.append(key)
    with path.open("w", newline="", encoding="utf-8-sig") as f:
        writer = csv.DictWriter(f, fieldnames=keys, extrasaction="ignore")
        writer.writeheader()
        writer.writerows(rows)


def classify(path: Path) -> str:
    rel = path.relative_to(REPO).as_posix()
    if "/compute/" in rel and path.name == "mlp.csv":
        return "compute_mlp"
    if "/compute/" in rel and path.name == "attention.csv":
        return "compute_attention"
    if "/network/" in rel and path.name == "all_reduce.csv":
        return "network_all_reduce"
    if "/network/" in rel and path.name == "send_recv.csv":
        return "network_send_recv"
    if "/network/" in rel and path.name == "attention.csv":
        return "orphan_network_attention"
    if "/cpu_overhead/" in rel:
        return "cpu_overhead"
    if "/processed_traces/" in rel:
        return "processed_trace"
    return "unknown"


def minmax(df: pd.DataFrame, column: str):
    if column not in df or len(df) == 0:
        return None
    return [float(df[column].min()), float(df[column].max())]


def audit_inventory() -> list[dict]:
    rows: list[dict] = []
    for path in sorted((REPO / "data").rglob("*.csv")):
        rel = path.relative_to(REPO).as_posix()
        kind = classify(path)
        raw = pd.read_csv(path)
        dedup = raw.drop_duplicates()
        required: list[str] = []
        optional: list[str] = []
        consumer = ""
        contract_key_extra = 0
        active_target_nulls = 0
        active_target_zeros = 0
        feature_ranges: dict = {}
        notes: list[str] = []

        if kind == "compute_mlp":
            required, optional = MLP_REQUIRED, MLP_OPTIONAL_ZERO
            consumer = "SklearnExecutionTimePredictor._load_compute_df/_train_compute_models"
            keys = [c for c in MLP_FILTER + ["num_tokens"] if c in dedup]
            if keys:
                contract_key_extra = len(dedup) - len(dedup.drop_duplicates(keys))
            targets = [c for c in MLP_REQUIRED_TARGETS if c in dedup]
            active_target_nulls = int(dedup[targets].isna().sum().sum()) if targets else 0
            active_target_zeros = int((dedup[targets] == 0).sum().sum()) if targets else 0
            feature_ranges = {
                "num_tokens": minmax(dedup, "num_tokens"),
                "tp": sorted(int(x) for x in dedup["num_tensor_parallel_workers"].unique()),
            }
        elif kind == "compute_attention":
            required, optional = ATTENTION_REQUIRED, ATTENTION_OPTIONAL_ZERO
            consumer = "SklearnExecutionTimePredictor._load_attention_df/_train_attention_layer_models"
            pre = dedup[dedup["prefill_chunk_size"] != 0]
            dec = dedup[dedup["prefill_chunk_size"] == 0]
            pre_keys = ATTENTION_FILTER + ["kv_cache_size", "prefill_chunk_size"]
            dec_keys = ATTENTION_FILTER + ["batch_size", "kv_cache_size"]
            contract_key_extra = (
                len(pre) - len(pre.drop_duplicates(pre_keys))
                + len(dec) - len(dec.drop_duplicates(dec_keys))
            )
            active_target_nulls = int(
                pre["time_stats.attn_prefill.median"].isna().sum()
                + dec["time_stats.attn_decode.median"].isna().sum()
            )
            active_target_zeros = int(
                (pre["time_stats.attn_prefill.median"] == 0).sum()
                + (dec["time_stats.attn_decode.median"] == 0).sum()
            )
            feature_ranges = {
                "batch_size": minmax(dedup, "batch_size"),
                "prefill_chunk_size": minmax(dedup, "prefill_chunk_size"),
                "kv_cache_size": minmax(dedup, "kv_cache_size"),
                "block_size": sorted(int(x) for x in dedup["block_size"].unique()),
                "tp": sorted(int(x) for x in dedup["num_tensor_parallel_workers"].unique()),
                "backend": sorted(str(x) for x in dedup.get("attention_backend", pd.Series(dtype=str)).dropna().unique()),
            }
            if "is_prefill" in dedup:
                mismatch = int(((dedup["prefill_chunk_size"] > 0) != dedup["is_prefill"].astype(bool)).sum())
                if mismatch:
                    notes.append(f"is_prefill inconsistent rows={mismatch}")
        elif kind == "network_all_reduce":
            required = ALL_REDUCE_REQUIRED
            consumer = "SklearnExecutionTimePredictor._load_all_reduce_df"
            keys = ["collective", "num_workers", "devices_per_node", "size"]
            contract_key_extra = len(dedup) - len(dedup.drop_duplicates(keys))
            active_target_nulls = int(dedup["time_stats.all_reduce.median"].isna().sum())
            active_target_zeros = int((dedup["time_stats.all_reduce.median"] == 0).sum())
            feature_ranges = {
                "size_bytes": minmax(dedup, "size"),
                "worker_device_pairs": [
                    [int(a), int(b)]
                    for a, b in dedup[["num_workers", "devices_per_node"]]
                    .drop_duplicates()
                    .sort_values(["num_workers", "devices_per_node"])
                    .itertuples(index=False, name=None)
                ],
            }
        elif kind == "network_send_recv":
            required = SEND_RECV_REQUIRED
            consumer = "SklearnExecutionTimePredictor._load_send_recv_df"
            keys = ["collective", "devices_per_node", "size"]
            contract_key_extra = len(dedup) - len(dedup.drop_duplicates(keys))
            active_target_nulls = int(dedup["time_stats.send_recv.median"].isna().sum())
            active_target_zeros = int((dedup["time_stats.send_recv.median"] == 0).sum())
            feature_ranges = {
                "size_bytes": minmax(dedup, "size"),
                "devices_per_node": sorted(int(x) for x in dedup["devices_per_node"].unique()),
            }
        elif kind == "orphan_network_attention":
            consumer = "none in commit"
            notes.append("No current path template or source reference consumes this file")
        elif kind == "cpu_overhead":
            required = CPU_REQUIRED
            consumer = "SklearnExecutionTimePredictor._load_cpu_overhead_df"
        elif kind == "processed_trace":
            length_ok = {"num_prefill_tokens", "num_decode_tokens"}.issubset(raw.columns)
            replay_ok = {"arrived_at", "num_prefill_tokens", "num_decode_tokens"}.issubset(raw.columns)
            interval_ok = {"arrival_time"}.issubset(raw.columns)
            consumer = ";".join(
                name
                for name, ok in [
                    ("TraceRequestLengthGenerator", length_ok),
                    ("TraceReplayRequestGenerator", replay_ok),
                    ("TraceRequestIntervalGenerator", interval_ok),
                ]
                if ok
            )
            required = ["num_prefill_tokens", "num_decode_tokens"]
            notes.append(
                f"length_compatible={length_ok};replay_compatible={replay_ok};interval_compatible={interval_ok}"
            )
            if "arrived_at" in raw:
                notes.append(f"arrival_monotonic={raw['arrived_at'].is_monotonic_increasing}")
            feature_ranges = {
                c: minmax(raw, c)
                for c in ["arrived_at", "num_prefill_tokens", "num_decode_tokens"]
                if c in raw
            }

        missing_required = sorted(set(required) - set(raw.columns))
        missing_optional = sorted(set(optional) - set(raw.columns))
        rows.append(
            {
                "path": rel,
                "category": kind,
                "consumer": consumer,
                "bytes": path.stat().st_size,
                "rows_raw": len(raw),
                "exact_duplicate_rows": int(raw.duplicated().sum()),
                "rows_after_drop_duplicates": len(dedup),
                "columns": len(raw.columns),
                "schema_ok_required": len(missing_required) == 0,
                "missing_required": js(missing_required),
                "missing_optional_zero_filled": js(missing_optional),
                "contract_key_extra_rows_after_exact_dedup": contract_key_extra,
                "active_target_nulls": active_target_nulls,
                "active_target_zeros": active_target_zeros,
                "feature_ranges": js(feature_ranges),
                "notes": ";".join(notes),
            }
        )
    return rows


def filter_mlp(df: pd.DataFrame, spec: dict, tp: int) -> pd.DataFrame:
    return df[
        (df["n_head"] == spec["n_head"])
        & (df["n_kv_head"] == spec["n_kv_head"])
        & (df["n_embd"] == spec["n_embd"])
        & (df["n_expanded_embd"] == spec["n_expanded_embd"])
        & (df["use_gated_mlp"] == spec["use_gated_mlp"])
        & (df["vocab_size"] == spec["vocab_size"])
        & (df["num_tensor_parallel_workers"] == tp)
    ]


def filter_attention(df: pd.DataFrame, spec: dict, tp: int, block_size: int = 16) -> pd.DataFrame:
    return df[
        (df["n_embd"] == spec["n_embd"])
        & (df["n_q_head"] == spec["n_head"])
        & (df["n_kv_head"] == spec["n_kv_head"])
        & (df["block_size"] == block_size)
        & (df["num_tensor_parallel_workers"] == tp)
    ]


def audit_compute_coverage() -> list[dict]:
    rows: list[dict] = []
    for device in ["a40", "a100", "h100"]:
        for model, spec in MODEL_SPECS.items():
            base = REPO / "data" / "profiling" / "compute" / device / model
            mlp_path, att_path = base / "mlp.csv", base / "attention.csv"
            mlp = pd.read_csv(mlp_path).drop_duplicates() if mlp_path.exists() else None
            att = pd.read_csv(att_path).drop_duplicates() if att_path.exists() else None
            mlp_rows_by_tp: dict[int, int] = {}
            att_rows_by_tp: dict[int, int] = {}
            for tp in [1, 2, 4, 8, 16]:
                if mlp is not None:
                    mlp_rows_by_tp[tp] = len(filter_mlp(mlp, spec, tp))
                if att is not None:
                    att_rows_by_tp[tp] = len(filter_attention(att, spec, tp))
            usable = [
                tp
                for tp in [1, 2, 4, 8, 16]
                if mlp_rows_by_tp.get(tp, 0) > 0 and att_rows_by_tp.get(tp, 0) > 0
            ]
            rows.append(
                {
                    "device": device,
                    "model": model,
                    "mlp_exists": mlp_path.exists(),
                    "attention_exists": att_path.exists(),
                    "mlp_rows_by_tp_after_filters": js(mlp_rows_by_tp),
                    "attention_rows_by_tp_after_filters_block16": js(att_rows_by_tp),
                    "usable_compute_tp": js(usable),
                    "declared_no_tensor_parallel": spec["no_tensor_parallel"],
                    "mlp_num_tokens_max": int(mlp["num_tokens"].max()) if mlp is not None else None,
                    "attention_batch_max": int(att["batch_size"].max()) if att is not None else None,
                    "attention_prefill_max": int(att["prefill_chunk_size"].max()) if att is not None else None,
                    "attention_kv_max": int(att["kv_cache_size"].max()) if att is not None else None,
                    "attention_block_sizes": js(sorted(int(x) for x in att["block_size"].unique())) if att is not None else "[]",
                    "attention_backends": js(sorted(str(x) for x in att.get("attention_backend", pd.Series(dtype=str)).dropna().unique())) if att is not None else "[]",
                    "default_mlp_4096_covered": bool(mlp is not None and mlp["num_tokens"].max() >= 4096),
                    "default_decode_batch_128_covered": bool(att is not None and att["batch_size"].max() >= 128),
                    "default_prefill_4096_covered": bool(att is not None and att["prefill_chunk_size"].max() >= 4096),
                    "default_decode_kv_4096_observed": bool(att is not None and (att["kv_cache_size"] == 4096).any()),
                }
            )
    return rows


def audit_network() -> list[dict]:
    rows: list[dict] = []
    base = REPO / "data" / "profiling" / "network"
    for topology, node_size in NODE_SIZES.items():
        folder = base / topology
        ar_path = folder / "all_reduce.csv"
        sr_path = folder / "send_recv.csv"
        ar = pd.read_csv(ar_path).drop_duplicates() if ar_path.exists() else None
        sr = pd.read_csv(sr_path).drop_duplicates() if sr_path.exists() else None
        selected: dict[int, int] = {}
        selected_indices: set[int] = set()
        if ar is not None:
            for tp in [2, 4, 8, 16]:
                mask = (
                    (ar["num_workers"] == tp)
                    & (ar["devices_per_node"] == tp)
                    & (ar["collective"] == "all_reduce")
                )
                selected[tp] = int(mask.sum())
                selected_indices.update(ar.index[mask].tolist())
        rows.append(
            {
                "network_device": topology,
                "node_devices": node_size,
                "all_reduce_file_exists": ar_path.exists(),
                "send_recv_file_exists": sr_path.exists(),
                "all_reduce_rows_after_dedup": len(ar) if ar is not None else 0,
                "all_reduce_rows_selected_by_tp": js(selected),
                "all_reduce_rows_unreachable_by_current_filter": (len(ar) - len(selected_indices)) if ar is not None else 0,
                "all_reduce_worker_device_pairs": js(
                    [
                        [int(a), int(b)]
                        for a, b in ar[["num_workers", "devices_per_node"]]
                        .drop_duplicates()
                        .sort_values(["num_workers", "devices_per_node"])
                        .itertuples(index=False, name=None)
                    ]
                ) if ar is not None else "[]",
                "send_recv_rows_after_dedup": len(sr) if sr is not None else 0,
                "send_recv_intra_devices_per_node_2_rows": int((sr["devices_per_node"] == 2).sum()) if sr is not None else 0,
                "send_recv_inter_devices_per_node_1_rows": int((sr["devices_per_node"] == 1).sum()) if sr is not None else 0,
                "unexpected_attention_csv": (folder / "attention.csv").exists(),
            }
        )
    return rows


def audit_trace_compatibility() -> list[dict]:
    rows: list[dict] = []
    for path in sorted((REPO / "data" / "processed_traces").glob("*.csv")):
        df = pd.read_csv(path)
        total = df["num_prefill_tokens"] + df["num_decode_tokens"]
        rows.append(
            {
                "path": path.relative_to(REPO).as_posix(),
                "rows": len(df),
                "exact_duplicate_rows_retained_by_trace_loaders": int(df.duplicated().sum()),
                "length_generator_compatible": {"num_prefill_tokens", "num_decode_tokens"}.issubset(df.columns),
                "replay_generator_compatible": {"arrived_at", "num_prefill_tokens", "num_decode_tokens"}.issubset(df.columns),
                "interval_generator_compatible": "arrival_time" in df.columns,
                "total_tokens_max": int(total.max()),
                "rows_over_default_max_tokens_4096": int((total > 4096).sum()),
                "arrived_at_monotonic": bool(df["arrived_at"].is_monotonic_increasing) if "arrived_at" in df else None,
                "null_cells": int(df.isna().sum().sum()),
            }
        )
    return rows


def main() -> None:
    commit = subprocess.check_output(
        ["git", "rev-parse", "HEAD"], cwd=REPO, text=True
    ).strip()
    if commit != EXPECTED_COMMIT:
        raise SystemExit(f"Refusing audit: expected {EXPECTED_COMMIT}, got {commit}")

    inventory = audit_inventory()
    coverage = audit_compute_coverage()
    network = audit_network()
    traces = audit_trace_compatibility()

    write_csv(OUT / "csv_inventory.csv", inventory)
    write_csv(OUT / "compute_coverage_matrix.csv", coverage)
    write_csv(OUT / "network_reachability.csv", network)
    write_csv(OUT / "trace_compatibility.csv", traces)

    totals = {
        "files": len(inventory),
        "bytes": sum(int(x["bytes"]) for x in inventory),
        "rows_raw": sum(int(x["rows_raw"]) for x in inventory),
        "exact_duplicate_rows": sum(int(x["exact_duplicate_rows"]) for x in inventory),
        "profiling_files": sum(x["path"].startswith("data/profiling/") for x in inventory),
        "profiling_rows_raw": sum(int(x["rows_raw"]) for x in inventory if x["path"].startswith("data/profiling/")),
        "trace_files": sum(x["path"].startswith("data/processed_traces/") for x in inventory),
        "orphan_network_attention_rows": next(
            int(x["rows_raw"]) for x in inventory if x["category"] == "orphan_network_attention"
        ),
        "cpu_overhead_files": sum(x["category"] == "cpu_overhead" for x in inventory),
    }
    contracts = {
        "compute_mlp": {
            "required": MLP_REQUIRED,
            "optional_missing_or_nan_filled_with_zero": MLP_OPTIONAL_ZERO,
            "feature_by_model": {name: ["num_tokens"] for name in [
                "attn_pre_proj", "attn_post_proj", "mlp_up_proj", "mlp_down_proj",
                "mlp_act", "input_layernorm", "post_attention_layernorm", "attn_rope", "add"
            ]},
        },
        "compute_attention": {
            "required": ATTENTION_REQUIRED,
            "optional_missing_or_nan_filled_with_zero": ATTENTION_OPTIONAL_ZERO,
            "derived": {
                "num_tokens": "max(prefill_chunk_size,batch_size)",
                "is_decode": "prefill_chunk_size == 0",
                "prefill_chunk_size_squared": "prefill_chunk_size ** 2",
            },
            "features": {
                "attn_kv_cache_save": ["num_tokens"],
                "attn_prefill": ["kv_cache_size", "prefill_chunk_size_squared"],
                "attn_decode": ["batch_size", "kv_cache_size"],
            },
        },
        "all_reduce": {
            "required": ALL_REDUCE_REQUIRED,
            "filter": "num_workers == TP and devices_per_node == TP and collective == all_reduce",
            "derived_num_tokens": "size / embedding_dim / 2",
        },
        "send_recv": {
            "required": SEND_RECV_REQUIRED,
            "filter": "collective == send_recv and devices_per_node == (1 if world_size > node_devices else 2)",
            "derived_num_tokens": "size / embedding_dim / 2",
        },
        "cpu_overhead": {
            "required": CPU_REQUIRED,
            "filter": "model_name == config model and tensor_parallel_degree == TP",
            "feature": ["batch_size"],
            "default_enabled": False,
        },
        "trace_length": {"required": ["num_prefill_tokens", "num_decode_tokens"]},
        "trace_replay": {"required": ["arrived_at", "num_prefill_tokens", "num_decode_tokens"]},
        "trace_interval": {"required": ["arrival_time"]},
    }
    summary = {
        "audited_commit": commit,
        "repo": str(REPO),
        "totals": totals,
        "predictor_defaults": {
            "block_size": 16,
            "prediction_max_tokens_per_request": 4096,
            "prediction_max_prefill_chunk_size": 4096,
            "prediction_max_batch_size": 128,
            "kv_cache_prediction_granularity": 64,
            "skip_cpu_overhead_modeling": True,
            "compute_total_tokens_rounding": "ceil to multiple of 8",
            "decode_and_prefill_kv_rounding": "ceil to multiple of 64",
        },
        "contracts": contracts,
        "material_counts": {
            "supported_model_configs": len(MODEL_SPECS),
            "model_device_rows_missing_both_compute_files": sum(
                not x["mlp_exists"] and not x["attention_exists"] for x in coverage
            ),
            "network_topologies_missing_all_reduce": sum(
                not x["all_reduce_file_exists"] for x in network
            ),
            "all_reduce_rows_unreachable_by_current_filter": sum(
                x["all_reduce_rows_unreachable_by_current_filter"] for x in network
            ),
            "processed_trace_files_interval_compatible": sum(
                x["interval_generator_compatible"] for x in traces
            ),
        },
    }
    (OUT / "contract_summary.json").write_text(
        json.dumps(summary, ensure_ascii=False, indent=2), encoding="utf-8"
    )

    print(json.dumps(summary, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()

# Vidur current-main CSV 数据契约与可达性审计

## 0. 审计对象与结论

- 官方仓库本地副本：`D:\workspaces\trace\vidur_repro\vidur`
- 固定提交：`8383d2935bc62723a212090baa9f98ada206fc14`
- 审计方式：静态读取 current-main loader、配置、模型注册表和请求生成器；逐个解析仓库中 53 个 CSV；按代码中的真实过滤表达式重放筛选。没有修改官方仓库。
- 可复算脚本：[`audit_data_contract.py`](./audit_data_contract.py)

核心结论：现有数据对于论文主路径中的若干 A100/H100、block size 16、TP1/2/4 配置是结构一致且可消费的；但“仓库里存在文件”远不等于“current-main 可以使用”。最重要的断点有：A40 缺少 `all_reduce.csv`、CPU overhead 数据完全缺失、7 个模型—设备组合没有 compute 数据、A100 DGX 的 3,976 行多节点 all-reduce 数据被过滤规则永久排除，以及查找表缓存和预测域没有可靠的数据版本/OOD 保护。

## 1. 数据全景

| 范围 | 文件数 | 原始行数 | exact duplicate | 大小 |
|---|---:|---:|---:|---:|
| 全部 `data/**/*.csv` | 53 | 1,436,810 | 4,056 | 275,312,735 B |
| profiling | 50 | 1,380,368 | 3,587 | 273,822,434 B |
| compute | 40 | 1,217,254 | 3,108 | 238,768,309 B |
| network | 10 | 163,114 | 479 | 35,054,125 B |
| processed traces | 3 | 56,442 | 469 | 1,490,301 B |

结构化明细见：

- [`csv_inventory.csv`](./csv_inventory.csv)：53 个 CSV 的 schema、行数、重复、有效目标异常及特征范围。
- [`compute_coverage_matrix.csv`](./compute_coverage_matrix.csv)：9 个模型 × 3 种设备的路径和 TP 可用性。
- [`network_reachability.csv`](./network_reachability.csv)：每种拓扑的 all-reduce/send-recv 实际可达行。
- [`trace_compatibility.csv`](./trace_compatibility.csv)：三类 trace loader 与仓库数据的兼容性。
- [`contract_summary.json`](./contract_summary.json)：机器可读契约、默认取整规则和总计。
- [`findings.csv`](./findings.csv)：16 项问题及证据。

## 2. CSV 如何真正进入模拟器

current-main 的执行链不是“直接查询 CSV”，而是：

1. 用 `{DEVICE}`、`{MODEL}`、`{NETWORK_DEVICE}` 展开五类输入路径（`sklearn_execution_time_predictor.py:87-103`）。
2. `pd.read_csv` 后仅调用完整行级 `drop_duplicates()`（`105-107, 143-145, 198-201`）。
3. 按模型维度、TP、block size、拓扑等过滤。
4. 构造 1–2 维派生特征。
5. 每个 target 单独训练 RF/多项式模型。
6. 初始化时把配置范围内的所有预测预生成成 Python dictionary。
7. 运行时将 batch shape 取整后直接访问 dictionary；没有落表时调用 estimator 的 fallback，也没有 OOD 检测。

这里的“median”有两层容易混淆：CSV 每行的 `time_stats.*.median` 已是 profiler 在该次 profile 内部多次迭代的中位数；loader 不会再对相同 shape 的多行做 median。它只删除所有列完全相等的行。

## 3. 各类数据契约

### 3.1 `compute/{DEVICE}/{MODEL}/mlp.csv`

默认路径：`./data/profiling/compute/{DEVICE}/{MODEL}/mlp.csv`。

过滤键：

```text
n_head == model.num_q_heads
n_kv_head == model.num_kv_heads
n_embd == model.embedding_dim
n_expanded_embd == model.mlp_hidden_dim
use_gated_mlp == model.use_gated_mlp
vocab_size == model.vocab_size
num_tensor_parallel_workers == TP
```

每个模型均只使用 `num_tokens` 一个特征，预测以下 median：

| 目标 | 缺列/NaN行为 |
|---|---|
| `attn_pre_proj`, `attn_post_proj` | 必须存在 |
| `mlp_up_proj`, `mlp_down_proj`, `mlp_act` | 必须存在 |
| `attn_rope` | 必须存在 |
| `input_layernorm`, `post_attention_layernorm`, `add` | 缺列或 NaN 被静默写成 0 |

`time_stats.emb.*` 以及所有 target 的 min/max/mean/std 均不消费。现有 20 个 MLP 文件都与目录对应模型配置的维度完全匹配。Phi-2 的三个文件没有 `post_attention_layernorm.*`；因为 Phi-2 配置 `post_attn_norm=False`，运行时本来也返回 0，这一例语义上合理。

### 3.2 `compute/{DEVICE}/{MODEL}/attention.csv`

过滤键：

```text
n_embd == model.embedding_dim
n_q_head == model.num_q_heads
n_kv_head == model.num_kv_heads
block_size == scheduler.block_size
num_tensor_parallel_workers == TP
```

派生与模型：

| 模型 | 训练子集 | 特征 | target |
|---|---|---|---|
| KV-cache save | 全部 attention 行 | `max(prefill_chunk_size, batch_size)` | `attn_kv_cache_save.median` |
| Prefill attention | `prefill_chunk_size != 0` | `kv_cache_size`, `prefill_chunk_size²` | `attn_prefill.median` |
| Decode attention | `prefill_chunk_size == 0` | `batch_size`, `kv_cache_size` | `attn_decode.median` |

`is_prefill` 列不用于切分；代码重新用 `prefill_chunk_size == 0` 推导。20 个文件中两者没有不一致行。`attention_backend` 和 `max_model_len` 也不参与过滤或建模：18 个旧文件均为 `FLASH_ATTENTION`/4096，两份 Llama-3 文件为 `FLASHINFER`/16384。当前每个文件只有一个 backend，暂时没有发生混合，但契约本身不能阻止未来将两个 backend 混进同一个 learner。

版本 schema 存在明显漂移：

- 18 个 paper-era 文件为 31 列，不含 `attn_kv_cache_save.median`，loader 为所有行补 0。
- 两个 A100 Llama-3 文件为 36 列，包含 KV-save。
- Prefill 与 decode 的 inactive target 在旧文件中通常为 NaN，loader 在切分后只训练 active target，因此这些 NaN 不构成训练错误。
- `attn_input_reshape.*` 与 `attn_output_reshape.*` 被完整测量但从未进入 ExecutionTime。

### 3.3 `network/{NETWORK_DEVICE}/all_reduce.csv`

必需列：`num_workers, devices_per_node, collective, size, time_stats.all_reduce.median`。

真实过滤规则是：

```text
num_workers == TP
devices_per_node == TP
collective == "all_reduce"
```

然后按 `num_tokens = size / embedding_dim / 2` 把字节数换成 token 数；常数 2 固定假设每个 hidden element 为 2 B。运行时还在预测值之外加默认 0.02 ms NCCL CPU launch overhead 和可选 skew 项。

该过滤规则只选择“一个 TP group 全部位于单节点”的行。它不会根据 world size 或 `_is_multi_node` 选择跨节点 all-reduce 数据。

### 3.4 `network/{NETWORK_DEVICE}/send_recv.csv`

当 `PP > 1` 时才加载。过滤规则：

```text
collective == "send_recv"
devices_per_node == 1  if PP*TP > node_devices
devices_per_node == 2  otherwise
```

所有现有 send/recv 文件均同时有 994 行 `devices_per_node=1` 和 994 行 `=2`。loader 不过滤 `num_workers`，但现有数据该列恒为 2；同样用 `size / embedding_dim / 2` 转 token。

### 3.5 CPU overhead

路径模板：`data/profiling/cpu_overhead/{NETWORK_DEVICE}/{MODEL}/cpu_overheads.csv`。

预期过滤键为 `model_name` 和 `tensor_parallel_degree`，特征为 `batch_size`，targets 为：

```text
schedule_median
sampler_e2e_median
prepare_inputs_e2e_median
process_model_outputs_median
ray_comm_time_mean
```

仓库没有任何一个此类文件。默认 `skip_cpu_overhead_modeling=True`，所以这些时间全部返回 0；如果仅把开关改为 false 而不额外提供文件，会在 `read_csv` 时失败。

### 3.6 请求 trace

| Loader | 必需列 | 仓库兼容文件 |
|---|---|---|
| Trace length | `num_prefill_tokens`, `num_decode_tokens` | 三个文件均兼容 |
| Trace replay | 再加 `arrived_at` | `splitwise_code.csv`, `splitwise_conv.csv` |
| Trace interval | `arrival_time` datetime | 0 个 |

配置中的默认 length 文件 `sharegpt_8k_filtered_stats_llama2_tokenizer.csv` 和 interval 文件 `AzureFunctionsInvocationTraceForTwoWeeksJan2021Processed.csv` 均不在仓库中。Replay 默认的 `splitwise_conv.csv` 存在。

Length loader 会按 seed 随机打乱行；Replay 保留 CSV 顺序并按 `time_scale_factor` 缩放 arrival。三类 loader 都不 drop duplicates。Arxiv 文件的 469 个 exact duplicates 因而会被保留。

## 4. 运行时 lookup、取整和边界

默认参数：

| 参数 | 默认值 |
|---|---:|
| block size | 16 |
| prediction max tokens/request | 4096 |
| prediction max prefill chunk | 4096 |
| prediction max batch size | 128 |
| KV granularity | 64 |

运行时键的构造：

- MLP、projection、norm、RoPE、all-reduce、send/recv 使用 batch 总 token，并向上取整到 8 的倍数（`batch.py:49`）。
- KV-save 不按 8 取整，使用 `sum(batch.num_tokens)` 的精确整数。
- Decode 先取 decode request 的平均已处理 token，截成整数，再向上取整到 64；lookup key 为 `(decode_batch_size, rounded_avg_kv)`。
- Prefill 将每个 request 的历史 KV 分别向上取整到 64，再求和；多个 prefill chunk 被压成 `round(sqrt(sum(chunk_i²)))²`。
- 对 GQA 模型，如果 decode batch size > 1 或 prefill request 数 > 1，预测值再乘默认 1.1；此修正不是 CSV 特征。

边界行为有两种：

1. 配置 lookup 范围仍在 dictionary 中、但超出训练样本范围：RF 给出末端叶子的常数，静默“外推”。例如旧 attention 数据的 KV 最大为 4032，默认却预生成 KV=4096；Orca 将一维 token lookup 扩大到 `4096*128=524288`，而旧 MLP 数据最大只有 4096。
2. 实际 batch 超出预生成 dictionary 范围：直接 `KeyError`。没有调用 estimator、clamp、警告或 profile-on-demand fallback。

配置之间没有联动校验。例如可以把 scheduler `batch_size_cap` 调到 256，却忘记同步把 predictor `prediction_max_batch_size` 从 128 调大。

## 5. Compute 覆盖矩阵

模型注册表有 9 个具体模型配置，设备有 A40/A100/H100，共 27 对：

| 设备 | 存在的模型目录 | Compute 可用 TP 的主要结论 |
|---|---|---|
| A100 | 除 InternLM2-20B 外的 8 个 | 大多数为 TP1/2/4/8；Llama-3-8B attention 只有 TP1/4；Phi-2 只有 TP1 |
| A40 | CodeLlama、InternLM-20B、Llama2-7B/70B、Phi-2、Qwen-72B | 除 Phi-2 仅 TP1 外，compute 有 TP1/2/4/8；没有两个 Llama-3 和 InternLM2 |
| H100 | 与 A40 相同的 6 个 | 同上 |

因此有 7 个模型—设备对完全缺少两个 compute 文件：InternLM2 在三种设备上，以及两个 Llama-3 在 A40/H100 上。

进一步的交叉限制：

- 所有 attention 数据只覆盖 block size 16；配置改成其他 block size 会得到空训练集。
- A100 Llama-3-8B 的 MLP 虽有 TP2/8，但 attention 没有，因此整个 predictor 仍不可用。
- compute 数据中的 TP8 不保证 end-to-end 可用；pairwise network 的 all-reduce 只覆盖 TP2/4。
- Llama-3 MLP 覆盖至 32768 token、attention 覆盖 batch 512/KV 16320/prefill 16384，但 predictor 默认只建 4096/128 lookup。这些额外数据默认不会被查询，虽然仍被放入 RF 训练。

积极的一面是：所有当前存在的 40 个 compute 文件，其模型维度与 `model_config.py` 完全匹配；所有 attention 文件的 block size 均为 16；active prefill/decode targets 没有 NaN。

## 6. Network 可达性

| network device | AR 文件 | 当前 loader 可选 TP | 不可达 AR 行 | SR |
|---|---|---|---:|---|
| `a40_pairwise_nvlink` | 缺失 | 无 | — | intra/inter 均有 |
| `a100_pairwise_nvlink` | 有 | 2、4 | 0 | intra/inter 均有 |
| `h100_pairwise_nvlink` | 有 | 2、4 | 0 | intra/inter 均有 |
| `a100_dgx` | 有 | 2、4、8 | 3,976 | intra/inter 均有 |
| `h100_dgx` | 有 | 2、4、8 | 0 | intra/inter 均有 |

A100 DGX 的原始 `(num_workers, devices_per_node)` 组合为：

```text
(2,1), (2,2), (4,2), (4,4), (8,4), (8,8), (16,8)
```

代码只能选 `(2,2), (4,4), (8,8)`。其余四组每组 994 行，共 3,976 行，永远不可达；TP16 也会因为寻找 `(16,16)` 而得到空集。

A40 目录还有一个 136,750 行、32,611,944 B 的 `network/a40_pairwise_nvlink/attention.csv`。它是 50 列的旧 attention schema，不是 collective schema；current-main 的任何默认路径或源码均未引用它。同时该目录恰好缺少需要的 `all_reduce.csv`。因此：A40 TP1 可不触发 all-reduce loader；A40 TP>1 按默认路径必然 `FileNotFoundError`，而该大文件仍为孤立数据。

另一个一致性缺口是 `ReplicaConfig.device` 与 `network_device` 独立实例化，没有检查 node SKU 的 device type。A100 compute 搭配 H100 network 在语法上会通过，物理上却不自洽。

## 7. 重复、聚合和异常标签

### 7.1 重复 shape 没有再聚合

在完整行 exact dedup 之后，仍存在：

| 数据类 | 相同契约键的额外行 |
|---|---:|
| 20 个 MLP 文件 | 166 |
| 20 个 attention 文件（prefill/decode 各按真实特征键） | 25,812 |
| 4 个 all-reduce 文件 | 14 |
| 5 个 send/recv 文件 | 10 |

MLP 的重叠来自分段采样区间端点：旧网格中每个 TP 的 token=2048、4096 各出现两次；Llama-3 网格还重复 8192、16384、32768。它们的 timing 并不完全相等，因此不会被 `drop_duplicates()` 删除。

以 A100 Llama2-7B 为例，重复 MLP-up 端点的两次 median 差异可到约 3.43%；attention 重复 prefill key 的相对 spread 最大约 14.9%，decode 约 12.1%。这些不一定是错误，它们本来可以作为重复测量估计噪声；但当前实现把它们当成独立训练行，隐式提高边界 shape 的权重，也没有输出每个 shape 的样本数/方差。

### 7.2 A100 Qwen 的 16 个零 decode median

`a100/Qwen/Qwen-72B/attention.csv` 在 TP1 有 16 个 active decode label 的 median 为 0：

- KV=160：batch 94、106、114、118、126；
- KV=192：batch 10、14、18、…、50。

这些行的 max 为 0.060–0.529 ms，说明并非整个测量都为零，更像内部 5 次样本中多数记录为零。loader 没有 `target > 0`、统计一致性或 outlier 检查，会直接训练。自定义 MAPE 对 `y_true=0` 的规则是：prediction 也为 0 则误差 0，否则固定 100%。

### 7.3 缺列补零隐藏 schema 漂移

18 个旧 attention 文件没有 KV-save target，补零后会训练一个恒零模型；这可能对应旧 backend 将保存动作融合进其他 kernel，但 CSV 本身没有 manifest 表达这一语义。缺失测量与真实零耗时不可区分。对于昇腾等编译器融合更强的平台，这种做法尤其不应沿用。

## 8. Trace 数据的实际变化

- `arxiv_summarization...csv`：28,257 行，总 token 已不超过 4096，适合作为 length source；缺 `arrived_at`，不能 replay。
- `splitwise_code.csv`：8,819 行，1,257 行原始总 token >4096。
- `splitwise_conv.csv`：19,366 行，1,612 行原始总 token >4096。

Replay 对超长行把全部 excess 只从 prefill 中扣除，因此以上 2,869 行的 prompt 分布会改变，decode 保持原值。现有两个 splitwise 文件 decode 最大 1,899/1,000，扣除后 prefill 仍为正；但如果把 `decode_scale_factor` 放大到 decode 本身超过 `max_tokens`，prefill 可以变成非正数，当前代码只断言 `prefill + decode <= max_tokens`，不会再次断言 prefill > 0。

Replay 也不排序 `arrived_at`；所幸两个内置 splitwise 文件当前均单调递增。Interval loader 则直接在当前行序上做 diff，并先把时间戳 floor 到整秒，亚秒到达间隔会变成 0。

## 9. Prediction cache 与数据版本的隐蔽耦合

训练模型 cache 的 hash 包含 dataframe JSON hash，因此训练 estimator 能感知 CSV 内容变化。但 lookup prediction cache 使用：

```python
model_hash = self._get_model_hash(model, df=None)
```

这里传入的是 fitted estimator 对象，其字符串通常只呈现超参数，不包含训练数据和树节点状态。prediction cache 文件名虽然含 operation name，但同一个 operation 在以下情况可能复用旧 lookup：

- CSV 在同一路径被替换，而 grid search 仍选出相同 RF 超参数；
- `attention_input_file` 被改到另一数据集，但 `to_dict()` 根本没有包含该路径；
- KV granularity 改变，但 `to_dict()` 没有包含该值，旧 dictionary 甚至可能缺新查询键。

这不是理论上的模型泛化问题，而是数据更新后可能完全不运行新 estimator 的 cache correctness 问题。应将 dataframe/file content hash、完整 prediction config、prediction X grid 和 fitted estimator state 一并纳入 lookup hash。

## 10. 建议的修复优先级

### P0：建立启动前 contract validator

在训练前一次性检查并输出 manifest：

1. 所有路径存在；device 与 network SKU 一致。
2. required columns、dtype、单位、有限值和 active target > 0。
3. 过滤后每个所需 TP/block/backend 子集非空。
4. `(training_min, training_max)` 覆盖完整 lookup query 域。
5. 相同契约键的重复数量和 spread；默认按键重新取 median，而不是只 exact dedup。
6. schema/backend/compiler 版本为单一已知值。

任何失败应在构造 predictor 时给出具体的“缺哪个模型/TP/列/边界”，而不是随后出现 `FileNotFoundError`、空训练集或 `KeyError`。

### P1：修复数据与选择规则

- 为 A40 提供真正的 `all_reduce.csv`；将孤立 attention 文件移入有明确模型/backend/version 的 compute 路径，或从发布包移除。
- 发布 CPU overhead CSV，或把“CPU overhead=0”作为显式实验模式而非静默默认。
- 把 compute coverage matrix 变成仓库内机器可读 registry，只允许列出的 model/device/TP/block combinations。
- all-reduce 过滤应使用真实 `(TP group size, devices_per_node, num_nodes/topology)`，使 A100 DGX 的跨节点数据可选。
- 修复 prediction cache hash；对超域 RF query 拒绝、告警或 on-demand profile，不允许静默末端常数。

### P2：保留分布与 provenance

- 每个 shape 先聚合重复 profile，保留 `count/p50/p90/p99/std/CV`。
- 数据 manifest 至少记录 GPU SKU、driver/CUDA、kernel backend、dtype、model revision、TP、block size、profiler/warmup/active 次数、时间单位和生成 commit。
- 修复 trace 默认路径和统一 schema；arrival 排序、正 token 校验和 truncation policy 应显式化。
- 将目前被丢弃的 min/max/std 用于置信区间和 OOD 风险，而不仅训练一个 median 点估计。

## 11. 对昇腾 NPU 数据契约的直接启示

如果把这一框架迁移到昇腾，`attention_backend` 在 Vidur 中“存在但被忽略”的模式不能照搬。NPU CSV 的过滤/manifest 至少需要加入：CANN/固件/驱动版本、图与 kernel hash、tiling key、fusion pattern、dtype/layout、block/core 配置、动态 shape bucket 和冷/热态。否则同一个逻辑 shape 下的不同编译执行机制会被混入一个 learner。

同时应禁止“缺 target 自动补 0”。编译器把某动作融合掉时，应以 `fused_into=<segment>` 或 segment-level target 表达，而不是伪造零时延。NPU 上比 RF 类型更先要解决的是：数据能否唯一标识执行 regime、训练域能否覆盖每个编译边界、重复测量能否刻画抖动，以及 cache 能否在软件栈变化时可靠失效。


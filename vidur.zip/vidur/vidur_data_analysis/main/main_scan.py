from __future__ import annotations

import hashlib
import json
import math
from pathlib import Path

import numpy as np
import pandas as pd


ROOT = Path(r"D:\workspaces\trace\vidur_repro\vidur")
DATA = ROOT / "data"
OUT = Path(r"D:\workspaces\trace\vidur_data_analysis\main")


def scalar(value):
    if isinstance(value, (np.integer,)):
        return int(value)
    if isinstance(value, (np.floating,)):
        return None if not np.isfinite(value) else float(value)
    if pd.isna(value):
        return None
    return value


def q(series: pd.Series, p: float):
    values = pd.to_numeric(series, errors="coerce").replace([np.inf, -np.inf], np.nan).dropna()
    return float(values.quantile(p)) if len(values) else np.nan


def compact_unique(series: pd.Series, limit: int = 12) -> str:
    vals = [scalar(v) for v in series.drop_duplicates().tolist()]
    vals = sorted(vals, key=lambda x: str(x))
    shown = vals[:limit]
    suffix = f" …(+{len(vals)-limit})" if len(vals) > limit else ""
    return ", ".join(str(v) for v in shown) + suffix


def classify(rel: Path):
    parts = rel.parts
    if parts[0] == "processed_traces":
        return {"category": "workload", "device": "", "model": "", "kind": "trace"}
    if parts[:2] == ("profiling", "compute"):
        return {
            "category": "compute",
            "device": parts[2],
            "model": "/".join(parts[3:-1]),
            "kind": Path(parts[-1]).stem,
        }
    if parts[:2] == ("profiling", "network"):
        return {
            "category": "network",
            "device": parts[2],
            "model": "",
            "kind": Path(parts[-1]).stem,
        }
    return {"category": "other", "device": "", "model": "", "kind": Path(parts[-1]).stem}


def measurement_consistency(df: pd.DataFrame, prefix: str):
    names = {s: f"{prefix}.{s}" for s in ["min", "max", "mean", "median", "std"]}
    if not all(c in df.columns for c in names.values()):
        return {"stat_order_violations": np.nan, "negative_std_rows": np.nan}
    block = df[list(names.values())].apply(pd.to_numeric, errors="coerce")
    active = block[names["median"]].notna()
    b = block.loc[active]
    # CSV decimal round-tripping can place mean a few machine epsilons outside
    # min/max even when the displayed statistics are equal. Ignore <=1e-9 ms.
    tol = 1e-9
    violations = (
        (b[names["min"]] - b[names["median"]] > tol)
        | (b[names["median"]] - b[names["max"]] > tol)
        | (b[names["min"]] - b[names["mean"]] > tol)
        | (b[names["mean"]] - b[names["max"]] > tol)
    )
    return {
        "stat_order_violations": int(violations.sum()),
        "negative_std_rows": int((b[names["std"]] < 0).sum()),
    }


def curve_stats(group: pd.DataFrame, x: str, y: str):
    g = group[[x, y]].dropna().sort_values(x)
    if len(g) < 2:
        return None
    xv = g[x].to_numpy(dtype=float)
    yv = g[y].to_numpy(dtype=float)
    keep = np.r_[True, np.diff(xv) != 0]
    xv, yv = xv[keep], yv[keep]
    if len(yv) < 2:
        return None
    prev = yv[:-1]
    delta = np.diff(yv)
    rel = np.divide(delta, prev, out=np.full_like(delta, np.nan), where=prev != 0)
    abs_rel = np.abs(rel[np.isfinite(rel)])
    return {
        "adjacent_pairs": int(len(delta)),
        "decrease_pairs": int(np.sum(delta < 0)),
        "decrease_gt5pct_pairs": int(np.sum(rel < -0.05)),
        "jump_gt10pct_pairs": int(np.sum(abs_rel > 0.10)),
        "jump_gt20pct_pairs": int(np.sum(abs_rel > 0.20)),
        "max_up_step_pct": float(np.nanmax(rel) * 100) if np.isfinite(rel).any() else np.nan,
        "max_down_step_pct": float(np.nanmin(rel) * 100) if np.isfinite(rel).any() else np.nan,
        "p95_abs_step_pct": float(np.nanquantile(abs_rel, 0.95) * 100) if len(abs_rel) else np.nan,
    }


def aggregate_curve_groups(df, group_cols, x, y):
    totals = {
        "curve_groups": 0,
        "adjacent_pairs": 0,
        "decrease_pairs": 0,
        "decrease_gt5pct_pairs": 0,
        "jump_gt10pct_pairs": 0,
        "jump_gt20pct_pairs": 0,
        "max_up_step_pct": -np.inf,
        "max_down_step_pct": np.inf,
        "p95_abs_step_pct_values": [],
    }
    iterator = [((), df)] if not group_cols else df.groupby(group_cols, dropna=False, sort=False)
    for _, g in iterator:
        stats = curve_stats(g, x, y)
        if stats is None:
            continue
        totals["curve_groups"] += 1
        for key in ["adjacent_pairs", "decrease_pairs", "decrease_gt5pct_pairs", "jump_gt10pct_pairs", "jump_gt20pct_pairs"]:
            totals[key] += stats[key]
        totals["max_up_step_pct"] = max(totals["max_up_step_pct"], stats["max_up_step_pct"])
        totals["max_down_step_pct"] = min(totals["max_down_step_pct"], stats["max_down_step_pct"])
        totals["p95_abs_step_pct_values"].append(stats["p95_abs_step_pct"])
    pairs = totals["adjacent_pairs"]
    result = {k: v for k, v in totals.items() if k != "p95_abs_step_pct_values"}
    result["decrease_rate"] = totals["decrease_pairs"] / pairs if pairs else np.nan
    result["decrease_gt5pct_rate"] = totals["decrease_gt5pct_pairs"] / pairs if pairs else np.nan
    result["jump_gt10pct_rate"] = totals["jump_gt10pct_pairs"] / pairs if pairs else np.nan
    result["jump_gt20pct_rate"] = totals["jump_gt20pct_pairs"] / pairs if pairs else np.nan
    result["median_curve_p95_abs_step_pct"] = (
        float(np.nanmedian(totals["p95_abs_step_pct_values"])) if totals["p95_abs_step_pct_values"] else np.nan
    )
    if result["max_up_step_pct"] == -np.inf:
        result["max_up_step_pct"] = np.nan
    if result["max_down_step_pct"] == np.inf:
        result["max_down_step_pct"] = np.nan
    return result


def workload_analysis(path: Path, df: pd.DataFrame):
    name = path.name
    pre = pd.to_numeric(df["num_prefill_tokens"], errors="coerce")
    dec = pd.to_numeric(df["num_decode_tokens"], errors="coerce")
    total = pre + dec
    ratio = pre / dec.replace(0, np.nan)
    result = {
        "file": name,
        "rows": len(df),
        "unique_prefill_decode_pairs": int(df[["num_prefill_tokens", "num_decode_tokens"]].drop_duplicates().shape[0]),
        "duplicate_shape_rows": int(df.duplicated(["num_prefill_tokens", "num_decode_tokens"], keep=False).sum()),
        "prefill_decode_pearson": float(pre.corr(dec)),
        "total_gt_4096_rate": float((total > 4096).mean()),
        "prefill_gt_4096_rate": float((pre > 4096).mean()),
        "decode_gt_4096_rate": float((dec > 4096).mean()),
        "zero_prefill_rows": int((pre == 0).sum()),
        "zero_decode_rows": int((dec == 0).sum()),
        "negative_length_rows": int(((pre < 0) | (dec < 0)).sum()),
    }
    if "num_total_tokens" in df:
        reported = pd.to_numeric(df["num_total_tokens"], errors="coerce")
        result["total_mismatch_rows"] = int((reported != total).sum())
    else:
        result["total_mismatch_rows"] = np.nan
    if "pd_ratio" in df:
        reported_ratio = pd.to_numeric(df["pd_ratio"], errors="coerce")
        result["pd_ratio_max_abs_error"] = float((reported_ratio - ratio).abs().max())
    else:
        result["pd_ratio_max_abs_error"] = np.nan
    if "arrived_at" in df:
        arrivals = pd.to_numeric(df["arrived_at"], errors="coerce").dropna()
        diffs = arrivals.sort_values().diff().dropna()
        result.update(
            {
                "arrival_min": float(arrivals.min()),
                "arrival_max": float(arrivals.max()),
                "arrival_duration": float(arrivals.max() - arrivals.min()),
                "arrival_rate_qps": float((len(arrivals) - 1) / (arrivals.max() - arrivals.min()))
                if len(arrivals) > 1 and arrivals.max() > arrivals.min()
                else np.nan,
                "interarrival_p50": q(diffs, 0.5),
                "interarrival_p90": q(diffs, 0.9),
                "nonpositive_interarrival_rows": int((diffs <= 0).sum()),
            }
        )
    for label, values in [("prefill", pre), ("decode", dec), ("total", total), ("pd_ratio", ratio)]:
        result[f"{label}_mean"] = float(values.mean())
        result[f"{label}_std"] = float(values.std())
        for p, suffix in [(0, "min"), (0.1, "p10"), (0.5, "p50"), (0.9, "p90"), (0.95, "p95"), (0.99, "p99"), (1, "max")]:
            result[f"{label}_{suffix}"] = q(values, p)
    return result


def compute_coverage(meta, df, rel):
    dims = [c for c in df.columns if not c.startswith("time_stats.") and not c.lower().startswith("unnamed")]
    row = {
        "path": rel.as_posix(),
        "device": meta["device"],
        "model": meta["model"],
        "kind": meta["kind"],
        "rows": len(df),
        "dimension_columns": ",".join(dims),
        "exact_dimension_duplicate_rows": int(df.duplicated(dims, keep=False).sum()) if dims else 0,
        "exact_dimension_unique_rows": int(df[dims].drop_duplicates().shape[0]) if dims else len(df),
    }
    mappings = {
        "tp": "num_tensor_parallel_workers",
        "num_tokens": "num_tokens",
        "batch_size": "batch_size",
        "prefill_chunk_size": "prefill_chunk_size",
        "kv_cache_size": "kv_cache_size",
        "is_prefill": "is_prefill",
        "attention_backend": "attention_backend",
        "block_size": "block_size",
        "max_model_len": "max_model_len",
    }
    for label, col in mappings.items():
        if col in df:
            row[f"{label}_unique"] = int(df[col].nunique(dropna=True))
            row[f"{label}_values"] = compact_unique(df[col])
            numeric = pd.to_numeric(df[col], errors="coerce")
            row[f"{label}_min"] = float(numeric.min()) if numeric.notna().any() else np.nan
            row[f"{label}_max"] = float(numeric.max()) if numeric.notna().any() else np.nan
        else:
            row[f"{label}_unique"] = np.nan
            row[f"{label}_values"] = ""
            row[f"{label}_min"] = np.nan
            row[f"{label}_max"] = np.nan
    if "is_prefill" in df:
        bools = df["is_prefill"].astype(str).str.lower().map({"true": True, "false": False, "1": True, "0": False})
        row["prefill_rows"] = int((bools == True).sum())
        row["decode_rows"] = int((bools == False).sum())
    return row


def analyze_operator(meta, df, rel, median_col):
    op = median_col.removeprefix("time_stats.").removesuffix(".median")
    y = pd.to_numeric(df[median_col], errors="coerce")
    active = y.notna()
    vals = y[active]
    std_col = median_col.removesuffix("median") + "std"
    std = pd.to_numeric(df.loc[active, std_col], errors="coerce") if std_col in df else pd.Series(dtype=float)
    cv = std / vals.replace(0, np.nan) if len(std) else pd.Series(dtype=float)
    base = {
        "path": rel.as_posix(),
        "device": meta["device"],
        "model": meta["model"],
        "kind": meta["kind"],
        "operator": op,
        "active_rows": int(active.sum()),
        "null_rows": int((~active).sum()),
        "zero_rows": int((vals == 0).sum()),
        "negative_rows": int((vals < 0).sum()),
        "latency_min_ms": q(vals, 0),
        "latency_p50_ms": q(vals, 0.5),
        "latency_p90_ms": q(vals, 0.9),
        "latency_p99_ms": q(vals, 0.99),
        "latency_max_ms": q(vals, 1),
        "measurement_cv_p50": q(cv, 0.5),
        "measurement_cv_p90": q(cv, 0.9),
        "measurement_cv_p99": q(cv, 0.99),
        "measurement_cv_gt5pct_rate": float((cv > 0.05).mean()) if len(cv) else np.nan,
        "measurement_cv_gt10pct_rate": float((cv > 0.10).mean()) if len(cv) else np.nan,
    }
    base.update(measurement_consistency(df, median_col.removesuffix(".median")))

    d = df.loc[active].copy()
    d[median_col] = vals
    if meta["kind"] == "mlp" and "num_tokens" in d:
        group_cols = [c for c in ["num_tensor_parallel_workers"] if c in d]
        base.update({f"token_axis_{k}": v for k, v in aggregate_curve_groups(d, group_cols, "num_tokens", median_col).items()})
    elif meta["kind"] == "attention":
        is_prefill = d.get("is_prefill", pd.Series(False, index=d.index)).astype(str).str.lower().isin(["true", "1"])
        if op == "attn_decode":
            dd = d.loc[~is_prefill]
            group_cols = [c for c in ["num_tensor_parallel_workers", "batch_size", "attention_backend"] if c in dd]
            if "kv_cache_size" in dd:
                base.update({f"kv_axis_{k}": v for k, v in aggregate_curve_groups(dd, group_cols, "kv_cache_size", median_col).items()})
            group_cols = [c for c in ["num_tensor_parallel_workers", "kv_cache_size", "attention_backend"] if c in dd]
            if "batch_size" in dd:
                base.update({f"batch_axis_{k}": v for k, v in aggregate_curve_groups(dd, group_cols, "batch_size", median_col).items()})
        elif op == "attn_prefill":
            dd = d.loc[is_prefill]
            group_cols = [c for c in ["num_tensor_parallel_workers", "kv_cache_size", "batch_size", "attention_backend"] if c in dd]
            if "prefill_chunk_size" in dd:
                base.update({f"prefill_axis_{k}": v for k, v in aggregate_curve_groups(dd, group_cols, "prefill_chunk_size", median_col).items()})
    return base


def duplicate_shape_dispersion(meta, df, rel, median_col):
    dims = [c for c in df.columns if not c.startswith("time_stats.") and not c.lower().startswith("unnamed")]
    if not dims:
        return None
    repeated = df[df.duplicated(dims, keep=False)]
    if repeated.empty:
        return None
    op = median_col.removeprefix("time_stats.").removesuffix(".median")
    rows = []
    max_group_size = 0
    for _, group in repeated.groupby(dims, dropna=False, sort=False):
        values = pd.to_numeric(group[median_col], errors="coerce").dropna()
        if len(values) < 2:
            continue
        max_group_size = max(max_group_size, len(values))
        center = float(values.median())
        spread = float((values.max() - values.min()) / center) if center != 0 else np.nan
        rows.append(spread)
    if not rows:
        return None
    s = pd.Series(rows, dtype=float)
    return {
        "path": rel.as_posix(),
        "device": meta["device"],
        "model": meta["model"],
        "kind": meta["kind"],
        "operator": op,
        "duplicate_shape_groups": len(rows),
        "max_repeats_per_shape": max_group_size,
        "within_shape_range_over_median_p50": q(s, 0.5),
        "within_shape_range_over_median_p90": q(s, 0.9),
        "within_shape_range_over_median_p99": q(s, 0.99),
        "within_shape_range_over_median_max": q(s, 1),
        "groups_over_5pct": int((s > 0.05).sum()),
        "groups_over_10pct": int((s > 0.10).sum()),
    }


def build_speedups(observations: list[pd.DataFrame]):
    if not observations:
        return pd.DataFrame()
    long = pd.concat(observations, ignore_index=True)
    outputs = []
    for kind, kind_long in long.groupby("kind", sort=False):
        candidate_keys = [c for c in kind_long.columns if c not in ["device", "latency_ms"]]
        key_cols = [c for c in candidate_keys if kind_long[c].notna().any()]
        wide = kind_long.pivot_table(
            index=key_cols,
            columns="device",
            values="latency_ms",
            aggfunc="median",
            dropna=True,
            observed=True,
        ).reset_index()
        pairs = [("a40", "a100", "A100_vs_A40"), ("a100", "h100", "H100_vs_A100")]
        for slow, fast, label in pairs:
            if slow not in wide or fast not in wide:
                continue
            matched = wide.dropna(subset=[slow, fast]).copy()
            matched["speedup"] = matched[slow] / matched[fast]
            group_cols = [c for c in ["kind", "model", "operator", "num_tensor_parallel_workers", "attention_backend"] if c in matched]
            for keys, g in matched.groupby(group_cols, dropna=False):
                if not isinstance(keys, tuple):
                    keys = (keys,)
                row = dict(zip(group_cols, keys))
                row.update(
                    {
                        "comparison": label,
                        "matched_shapes": len(g),
                        "speedup_p10": q(g["speedup"], 0.1),
                        "speedup_p50": q(g["speedup"], 0.5),
                        "speedup_p90": q(g["speedup"], 0.9),
                        "speedup_min": q(g["speedup"], 0),
                        "speedup_max": q(g["speedup"], 1),
                        "faster_device_slower_rate": float((g["speedup"] < 1).mean()),
                    }
                )
                outputs.append(row)
    return pd.DataFrame(outputs)


def main():
    OUT.mkdir(parents=True, exist_ok=True)
    inventory = []
    schemas = {}
    workloads = []
    coverage = []
    operator_quality = []
    duplicate_dispersion = []
    speed_observations = []

    paths = sorted(DATA.rglob("*.csv"))
    for index, path in enumerate(paths, start=1):
        rel = path.relative_to(DATA)
        meta = classify(rel)
        df = pd.read_csv(path, low_memory=False)
        unnamed = [c for c in df.columns if str(c).lower().startswith("unnamed") or str(c) == ""]
        logical_cols = [c for c in df.columns if c not in unnamed]
        schema_text = "|".join(logical_cols)
        schema_hash = hashlib.sha1(schema_text.encode("utf-8")).hexdigest()[:10]
        schemas.setdefault(schema_hash, {"schema_hash": schema_hash, "columns": schema_text, "file_count": 0, "paths": []})
        schemas[schema_hash]["file_count"] += 1
        schemas[schema_hash]["paths"].append(rel.as_posix())

        numeric = df.select_dtypes(include=[np.number])
        inv = {
            "path": rel.as_posix(),
            **meta,
            "bytes": path.stat().st_size,
            "rows": len(df),
            "columns": len(df.columns),
            "schema_hash": schema_hash,
            "unnamed_index_columns": ",".join(unnamed),
            "null_cells": int(df.isna().sum().sum()),
            "null_cell_rate": float(df.isna().sum().sum() / max(1, df.shape[0] * df.shape[1])),
            "all_null_columns": ",".join(df.columns[df.isna().all()].tolist()),
            "exact_duplicate_rows": int(df.duplicated().sum()),
            "infinite_numeric_cells": int(np.isinf(numeric.to_numpy(dtype=float, na_value=np.nan)).sum()) if len(numeric.columns) else 0,
        }
        inventory.append(inv)

        if meta["category"] == "workload":
            workloads.append(workload_analysis(path, df))
        elif meta["category"] == "compute":
            coverage.append(compute_coverage(meta, df, rel))
            median_cols = [c for c in df.columns if c.startswith("time_stats.") and c.endswith(".median")]
            for median_col in median_cols:
                operator_quality.append(analyze_operator(meta, df, rel, median_col))
                duplicate_row = duplicate_shape_dispersion(meta, df, rel, median_col)
                if duplicate_row is not None:
                    duplicate_dispersion.append(duplicate_row)

            # Cross-GPU comparisons. MLP has a stable schema; attention includes backend
            # when available so unlike implementations are not silently mixed.
            if meta["kind"] == "mlp":
                keys = [c for c in ["num_tensor_parallel_workers", "num_tokens"] if c in df]
                for median_col in median_cols:
                    op = median_col.removeprefix("time_stats.").removesuffix(".median")
                    slim = df[keys + [median_col]].copy()
                    slim = slim.rename(columns={median_col: "latency_ms"})
                    slim["device"] = meta["device"]
                    slim["model"] = meta["model"]
                    slim["kind"] = meta["kind"]
                    slim["operator"] = op
                    speed_observations.append(slim.dropna(subset=["latency_ms"]))
            elif meta["kind"] == "attention":
                for median_col, phase in [("time_stats.attn_decode.median", False), ("time_stats.attn_prefill.median", True)]:
                    if median_col not in df:
                        continue
                    flag = df.get("is_prefill", pd.Series(False, index=df.index)).astype(str).str.lower().isin(["true", "1"])
                    subset = df.loc[flag == phase]
                    keys = [c for c in ["num_tensor_parallel_workers", "batch_size", "prefill_chunk_size", "kv_cache_size", "is_prefill", "attention_backend"] if c in subset]
                    slim = subset[keys + [median_col]].copy().rename(columns={median_col: "latency_ms"})
                    if "attention_backend" not in slim:
                        slim["attention_backend"] = "<not-recorded>"
                    slim["device"] = meta["device"]
                    slim["model"] = meta["model"]
                    slim["kind"] = meta["kind"]
                    slim["operator"] = "attn_prefill" if phase else "attn_decode"
                    speed_observations.append(slim.dropna(subset=["latency_ms"]))
        print(f"[{index:02d}/{len(paths)}] {rel.as_posix()} rows={len(df):,}")

    inventory_df = pd.DataFrame(inventory)
    schemas_df = pd.DataFrame(
        [{**v, "paths": "\n".join(v["paths"])} for v in schemas.values()]
    ).sort_values(["file_count", "schema_hash"], ascending=[False, True])
    workload_df = pd.DataFrame(workloads)
    coverage_df = pd.DataFrame(coverage)
    quality_df = pd.DataFrame(operator_quality)
    duplicate_df = pd.DataFrame(duplicate_dispersion)
    speed_df = build_speedups(speed_observations)

    inventory_df.to_csv(OUT / "file_inventory.csv", index=False)
    schemas_df.to_csv(OUT / "schema_catalog.csv", index=False)
    workload_df.to_csv(OUT / "workload_summary.csv", index=False)
    coverage_df.to_csv(OUT / "compute_coverage.csv", index=False)
    quality_df.to_csv(OUT / "compute_operator_quality.csv", index=False)
    duplicate_df.to_csv(OUT / "duplicate_shape_dispersion.csv", index=False)
    speed_df.to_csv(OUT / "cross_gpu_speedup.csv", index=False)

    summary = {
        "repo_commit": "8383d2935bc62723a212090baa9f98ada206fc14",
        "csv_files": int(len(inventory_df)),
        "total_rows": int(inventory_df.rows.sum()),
        "total_bytes": int(inventory_df.bytes.sum()),
        "schema_count_excluding_unnamed_index": int(len(schemas_df)),
        "by_category": inventory_df.groupby("category").agg(files=("path", "count"), rows=("rows", "sum"), bytes=("bytes", "sum")).reset_index().to_dict("records"),
        "files_with_exact_duplicate_rows": int((inventory_df.exact_duplicate_rows > 0).sum()),
        "files_with_unnamed_index": int((inventory_df.unnamed_index_columns != "").sum()),
        "files_with_all_null_columns": int((inventory_df.all_null_columns != "").sum()),
        "operator_quality_rows": int(len(quality_df)),
        "duplicate_dispersion_rows": int(len(duplicate_df)),
        "speedup_summary_rows": int(len(speed_df)),
    }
    (OUT / "main_summary.json").write_text(json.dumps(summary, indent=2, ensure_ascii=False), encoding="utf-8")
    print(json.dumps(summary, indent=2, ensure_ascii=False))


if __name__ == "__main__":
    main()

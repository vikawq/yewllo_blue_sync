# Vidur workload 与 network profiling 数据审计

本报告由 `analyze_network_workloads.py` 从官方仓库 CSV 只读生成。统计对象为 `data/processed_traces` 与 `data/profiling/network` 下的全部 CSV；未修改源文件。

## 1. 结论摘要

- 共审计 13 个 CSV：3 个 processed workload、10 个 network 目录文件。
- 当前仓库的三个 processed workload 是 Arxiv summarization、Splitwise code、Splitwise conversation；它们并不是论文 Table 1 的 Chat-1M/Arxiv-4K/BWB-4K 三件套，尤其仓库没有 BWB processed trace。
- `a40_pairwise_nvlink/attention.csv` 是 compute-attention 数据误放在 network 目录，不能作为 collective profile 使用。
- 标准 collective CSV 只有 rank 0 的三次重复统计，足以做单点中位数插值，但无法验证 rank 间不对称；三次重复也不足以稳定刻画尾部。
- `h100_pairwise_nvlink/send_recv.csv` 与 `a100_pairwise_nvlink/send_recv.csv` 字节级完全相同，不能据此声称 H100 与 A100 的 send/recv 实测一致。
- A40 目录缺 all-reduce，H100 DGX all-reduce 的 world-size 覆盖也明显窄于 A100；模拟器对缺失配置没有可靠实测支撑。

## 2. 数据资产与质量

| 类别 | 路径 | 行 | 列 | 字节 | 缺失单元格 | 重复行（去 index） |
|---|---|---|---|---|---|---|
| network | profiling/network/a100_dgx/all_reduce.csv | 6958 | 12 | 652149 | 0 | 0 |
| network | profiling/network/a100_dgx/send_recv.csv | 1988 | 12 | 178780 | 0 | 1 |
| network | profiling/network/a100_pairwise_nvlink/all_reduce.csv | 4496 | 12 | 424946 | 0 | 0 |
| network | profiling/network/a100_pairwise_nvlink/send_recv.csv | 1988 | 12 | 182593 | 0 | 0 |
| network | profiling/network/a40_pairwise_nvlink/attention.csv | 136750 | 50 | 32611944 | 2235600 | 479 |
| network | profiling/network/a40_pairwise_nvlink/send_recv.csv | 1988 | 12 | 183039 | 0 | 0 |
| network | profiling/network/h100_dgx/all_reduce.csv | 2982 | 12 | 277125 | 0 | 1 |
| network | profiling/network/h100_dgx/send_recv.csv | 1988 | 12 | 179059 | 0 | 0 |
| network | profiling/network/h100_pairwise_nvlink/all_reduce.csv | 1988 | 12 | 181897 | 0 | 0 |
| network | profiling/network/h100_pairwise_nvlink/send_recv.csv | 1988 | 12 | 182593 | 0 | 0 |
| workload | processed_traces/arxiv_summarization_stats_llama2_tokenizer_filtered_v2.csv | 28257 | 4 | 913190 | 0 | 469 |
| workload | processed_traces/splitwise_code.csv | 8819 | 3 | 175015 | 0 | 0 |
| workload | processed_traces/splitwise_conv.csv | 19366 | 3 | 402096 | 0 | 0 |

### 2.1 Workload schema 与完整性

| workload | 行 | prefill 缺失 | decode 缺失 | prefill<=0 | decode<=0 | 重复行 | total 不一致 | P:D 不一致 |
|---|---|---|---|---|---|---|---|---|
| arxiv_summarization_stats_llama2_tokenizer_filtered_v2 | 28257 | 0 | 0 | 0 | 0 | 469 | 0 | 0 |
| splitwise_code | 8819 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| splitwise_conv | 19366 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |

Arxiv 文件自带 `num_total_tokens` 与 `pd_ratio`，分析脚本逐行用 prefill/decode 重算核对；Splitwise 两个文件另带到达时间。Arxiv 的 469 个重复行只是相同长度/比值元组重复；文件没有 request id 或 arrival time，故不能据此判定为数据损坏，也不能还原请求次序。

## 3. 三个 workload 的长度与长尾

| workload | 请求数 | P50 prefill | P90 prefill | P99 prefill | max prefill | P50 decode | P90 decode | P99 decode | max decode | P99 total | max total | P:D 中位 |
|---|---|---|---|---|---|---|---|---|---|---|---|---|
| arxiv_summarization_stats_llama2_tokenizer_filtered_v2 | 28257 | 2,730.0000 | 3,702.0000 | 3,933.4400 | 4054 | 167.0000 | 372.0000 | 3,271.3200 | 4056 | 4,077.0000 | 4096 | 15.6907 |
| splitwise_code | 8819 | 1,469.0000 | 5,187.6000 | 7,436.0000 | 7437 | 13.0000 | 55.0000 | 251.4600 | 1899 | 7,461.8200 | 7841 | 91.8125 |
| splitwise_conv | 19366 | 1,020.0000 | 2,734.5000 | 4,142.0000 | 14050 | 129.0000 | 424.0000 | 601.0000 | 1000 | 4,259.0000 | 14089 | 3.5818 |

### 3.1 分布形态与截断证据

- **Arxiv**：total 最大值恰为 4096，且有 18 条恰好命中 4096；decode P99/P50=19.59，top 1% 请求贡献 12.33% decode tokens。这是经过 4K 过滤/截断的数据，不应视为未裁剪的自然长度分布。
- **Splitwise code**：prefill P50/P99/max=1469/7436/7437，并在 7435/7436/7437 形成明显堆积（103/201/18 条），说明源 trace 存在约 7.44K 的长度上沿；P:D 中位为 91.8，属于极强 prefill-heavy 负载。
- **Splitwise conversation**：prefill P50/P99/max=1020/4142/14050，最大 total=14089；主体在约 4K 内，但存在稀疏超长离群请求。
- 两条 Splitwise trace 的到达时间均单调且无负/零间隔；观测时段分别为 3435.9s/3501.7s，平均 QPS=2.566/5.530。

### 3.2 Prefill 与 decode 相关性

| workload | Pearson | Spearman |
|---|---|---|
| arxiv_summarization_stats_llama2_tokenizer_filtered_v2 | -0.4631 | -0.1138 |
| splitwise_code | 0.0012 | -0.0215 |
| splitwise_conv | -0.1124 | 0.0728 |

相关性低不等于两个边际分布可独立采样；仿真 trace 应保留原始成对长度，否则会改变 KV-cache 压力和 batch composition。

### 3.3 对默认 4096-token attention profiling domain 的覆盖

| workload | prefill<=4096 | decode<=4096 | total/context<=4096 |
|---|---|---|---|
| arxiv_summarization_stats_llama2_tokenizer_filtered_v2 | 100.0% | 100.0% | 100.0% |
| splitwise_code | 85.9% | 100.0% | 85.7% |
| splitwise_conv | 97.9% | 100.0% | 91.7% |

`request_total<=4096` 是 attention context 全程不超默认 4096 的保守判据。Arxiv/code/conversation 的 total/context 覆盖率分别为 100.00%/85.75%/91.68%；三者 decode 长度本身均 100% 落在 4096 内。Token-level 每 iteration 总 token 还取决于 scheduler、chunk size 和 batch composition，不能仅由请求长度文件精确推出。

## 4. Network profile 覆盖与性能

| 目录 | profile | 行 | world sizes | devices/node | min bytes | max bytes | size 点数 | CV>20% 行 |
|---|---|---|---|---|---|---|---|---|
| a100_dgx | all_reduce | 6958 | 2,4,8,16 | 1,2,4,8 | 2,048.0000 | 67,108,864.0000 | 993.0000 | 174.0000 |
| a100_dgx | send_recv | 1988 | 2 | 1,2 | 2,048.0000 | 67,108,864.0000 | 993.0000 | 12.0000 |
| a100_pairwise_nvlink | all_reduce | 4496 | 2,4 | 2,4 | 2,048.0000 | 536,373,250.0000 | 2,247.0000 | 65.0000 |
| a100_pairwise_nvlink | send_recv | 1988 | 2 | 1,2 | 2,048.0000 | 67,108,864.0000 | 993.0000 | 70.0000 |
| a40_pairwise_nvlink | attention_compute | 136750 |  |  | NA | NA | NA | NA |
| a40_pairwise_nvlink | send_recv | 1988 | 2 | 1,2 | 2,048.0000 | 67,108,864.0000 | 993.0000 | 14.0000 |
| h100_dgx | all_reduce | 2982 | 2,4,8 | 2,4,8 | 2,048.0000 | 67,108,864.0000 | 993.0000 | 155.0000 |
| h100_dgx | send_recv | 1988 | 2 | 1,2 | 2,048.0000 | 67,108,864.0000 | 993.0000 | 85.0000 |
| h100_pairwise_nvlink | all_reduce | 1988 | 2,4 | 2,4 | 2,048.0000 | 67,108,864.0000 | 993.0000 | 36.0000 |
| h100_pairwise_nvlink | send_recv | 1988 | 2 | 1,2 | 2,048.0000 | 67,108,864.0000 | 993.0000 | 70.0000 |

`size` 是代码写出的字节数。下述带宽为 `size / median_latency` 的 payload-equivalent GB/s；all-reduce 的 ring bus 带宽只作为带明确假设的辅助列，不能等同 NCCL 实际算法带宽。P95 是对采样网格点求分位数，不是按真实 message-size workload 加权后的 P95；网格在不同 size 区间的密度也不同。

### 4.1 分组延迟、带宽与抖动

| group | size 点 | <=64KiB 延迟中位 ms | payload BW P95 GB/s | 大消息 BW 中位 GB/s | 单点 CV P95 | 非单调下降 | 跳变候选 |
|---|---|---|---|---|---|---|---|
| a100_dgx/all_reduce/w2/dpn1 | 993 | 0.0500 | 5.8649 | 5.8574 | 0.0214 | 1 | 0 |
| a100_dgx/all_reduce/w2/dpn2 | 993 | 0.0460 | 153.1821 | 153.1825 | 0.1584 | 3 | 4 |
| a100_dgx/all_reduce/w4/dpn2 | 993 | 0.0615 | 7.0435 | 3.9234 | 0.0199 | 3 | 1 |
| a100_dgx/all_reduce/w4/dpn4 | 993 | 0.0205 | 110.6078 | 110.4502 | 0.3918 | 0 | 0 |
| a100_dgx/all_reduce/w8/dpn4 | 993 | 0.0780 | 12.1709 | 12.1709 | 0.0306 | 2 | 0 |
| a100_dgx/all_reduce/w8/dpn8 | 993 | 0.0325 | 96.0147 | 95.0896 | 0.2093 | 3 | 1 |
| a100_dgx/all_reduce/w16/dpn8 | 993 | 0.0780 | 9.3531 | 9.3442 | 0.0266 | 2 | 1 |
| a100_dgx/send_recv/w2/dpn1 | 993 | 0.0290 | 7.8175 | 7.8012 | 0.0545 | 0 | 1 |
| a100_dgx/send_recv/w2/dpn2 | 993 | 0.0135 | 262.5960 | 226.6238 | 0.0786 | 0 | 0 |
| a100_pairwise_nvlink/all_reduce/w2/dpn2 | 2247 | 0.0505 | 194.6577 | 194.6581 | 0.1030 | 7 | 3 |
| a100_pairwise_nvlink/all_reduce/w4/dpn4 | 2247 | 0.0590 | 15.7909 | 15.7683 | 0.0079 | 0 | 0 |
| a100_pairwise_nvlink/send_recv/w2/dpn1 | 993 | 0.0185 | 7.5941 | 2.3275 | 0.2245 | 60 | 41 |
| a100_pairwise_nvlink/send_recv/w2/dpn2 | 993 | 0.0085 | 335.0088 | 295.2959 | 0.0617 | 0 | 0 |
| a40_pairwise_nvlink/send_recv/w2/dpn1 | 993 | 0.0530 | 3.2645 | 2.3310 | 0.1726 | 2 | 7 |
| a40_pairwise_nvlink/send_recv/w2/dpn2 | 993 | 0.0085 | 4.4036 | 3.9871 | 0.0598 | 0 | 0 |
| h100_dgx/all_reduce/w2/dpn2 | 993 | 0.0210 | 269.9013 | 269.9043 | 0.2897 | 8 | 4 |
| h100_dgx/all_reduce/w4/dpn4 | 993 | 0.0380 | 209.8044 | 209.8047 | 0.0784 | 2 | 1 |
| h100_dgx/all_reduce/w8/dpn8 | 993 | 0.0310 | 189.1071 | 189.1120 | 0.0744 | 1 | 0 |
| h100_dgx/send_recv/w2/dpn1 | 993 | 0.0185 | 35.7141 | 34.6132 | 0.4407 | 1 | 0 |
| h100_dgx/send_recv/w2/dpn2 | 993 | 0.0075 | 344.7222 | 344.7284 | 0.0177 | 0 | 0 |
| h100_pairwise_nvlink/all_reduce/w2/dpn2 | 993 | 0.0070 | 187.6599 | 187.6679 | 0.1279 | 10 | 13 |
| h100_pairwise_nvlink/all_reduce/w4/dpn4 | 993 | 0.0280 | 32.3017 | 32.3018 | 0.0165 | 0 | 1 |
| h100_pairwise_nvlink/send_recv/w2/dpn1 | 993 | 0.0185 | 7.5941 | 2.3275 | 0.2245 | 60 | 41 |
| h100_pairwise_nvlink/send_recv/w2/dpn2 | 993 | 0.0085 | 335.0088 | 295.2959 | 0.0617 | 0 | 0 |

### 4.2 拓扑与带宽拐点的主要读数

- **A100 DGX all-reduce** 的 payload-BW P95 清楚地区分节点内/跨节点：w2/dpn2=153.18 GB/s，w2/dpn1=5.86；w4/dpn4=110.61，w4/dpn2=7.04；w8/dpn8=96.01，w8/dpn4=12.17。
- **H100 DGX all-reduce** 仅有节点内 w2/w4/w8，P95 分别为 269.90/209.80/189.11 GB/s；不能据此外推 H100 跨节点或 w16。
- **pairwise-NVLink all-reduce** 从 w2 到 w4 出现巨大拓扑惩罚：A100 194.66->15.79 GB/s；H100 187.66->32.30 GB/s。这与 w4 跨越成对高速链路边界相容，但算法原因仍需拓扑/NCCL 日志确认。
- 带宽均为 payload-equivalent，不是厂商峰值或 NCCL busbw。尤其跨节点/跨 pair 配置的大消息带宽可能在最大 size 区间回落，因此不能用单一饱和带宽常数替代整条实测曲线。

### 4.3 阈值/非单调候选

共检出 284 个局部不连续候选。规则要求：size>=64KiB、相邻 size 比<=1.25、绝对延迟变化>=0.005ms 且>=相邻两点合成标准差的 3 倍，并满足上跳>=25% 或下降>=20%。这只是噪声过滤后的 change-point 候选；它们可能来自 NCCL 算法/协议切换、拓扑阈值、拥塞或三次重复仍未覆盖的偶发抖动，没有 NCCL debug 日志和阈值两侧加密复测就不能定性为算法切换。`network_transitions.csv` 保留全部相邻点，便于采用别的规则复核。

| 目录 | collective | world | dpn | 前一 size | 当前 size | 前一 ms | 当前 ms | 延迟变化 | BW 变化 | 类型 |
|---|---|---|---|---|---|---|---|---|---|---|
| a100_pairwise_nvlink | all_reduce | 2 | 2 | 395,264.0000 | 403456 | 0.0130 | 0.0630 | 3.8462 | -0.7894 | candidate_latency_jump |
| a100_pairwise_nvlink | all_reduce | 2 | 2 | 264,192.0000 | 272384 | 0.0130 | 0.0590 | 3.5385 | -0.7728 | candidate_latency_jump |
| h100_dgx | all_reduce | 2 | 2 | 395,264.0000 | 403456 | 0.0100 | 0.0430 | 3.3000 | -0.7626 | candidate_latency_jump |
| h100_dgx | all_reduce | 2 | 2 | 518,144.0000 | 526336 | 0.0110 | 0.0420 | 2.8182 | -0.7340 | candidate_latency_jump |
| h100_pairwise_nvlink | all_reduce | 2 | 2 | 231,424.0000 | 239616 | 0.0080 | 0.0300 | 2.7500 | -0.7239 | candidate_latency_jump |
| a100_dgx | all_reduce | 2 | 2 | 411,648.0000 | 419840 | 0.0180 | 0.0620 | 2.4444 | -0.7039 | candidate_latency_jump |
| h100_pairwise_nvlink | all_reduce | 2 | 2 | 346,112.0000 | 354304 | 0.0100 | 0.0310 | 2.1000 | -0.6698 | candidate_latency_jump |
| h100_pairwise_nvlink | all_reduce | 2 | 2 | 370,688.0000 | 378880 | 0.0100 | 0.0300 | 2.0000 | -0.6593 | candidate_latency_jump |
| h100_pairwise_nvlink | all_reduce | 2 | 2 | 272,384.0000 | 280576 | 0.0100 | 0.0300 | 2.0000 | -0.6566 | candidate_latency_jump |
| h100_dgx | all_reduce | 4 | 4 | 681,984.0000 | 690176 | 0.0150 | 0.0420 | 1.8000 | -0.6386 | candidate_latency_jump |
| h100_pairwise_nvlink | all_reduce | 2 | 2 | 428,032.0000 | 436224 | 0.0110 | 0.0300 | 1.7273 | -0.6263 | candidate_latency_jump |
| h100_pairwise_nvlink | all_reduce | 2 | 2 | 116,736.0000 | 124928 | 0.0120 | 0.0290 | 1.4167 | -0.5572 | candidate_latency_jump |
| h100_pairwise_nvlink | all_reduce | 2 | 2 | 542,720.0000 | 550912 | 0.0130 | 0.0310 | 1.3846 | -0.5743 | candidate_latency_jump |
| h100_pairwise_nvlink | all_reduce | 2 | 2 | 575,488.0000 | 583680 | 0.0130 | 0.0300 | 1.3077 | -0.5605 | candidate_latency_jump |
| a100_dgx | all_reduce | 2 | 2 | 182,272.0000 | 190464 | 0.0290 | 0.0570 | 0.9655 | -0.4684 | candidate_latency_jump |
| a100_dgx | all_reduce | 16 | 8 | 16,744,448.0000 | 16777216 | 2.1530 | 4.1700 | 0.9368 | -0.4827 | candidate_latency_jump |
| h100_dgx | all_reduce | 2 | 2 | 903,168.0000 | 911360 | 0.0220 | 0.0420 | 0.9091 | -0.4714 | candidate_latency_jump |
| h100_pairwise_nvlink | send_recv | 2 | 1 | 44,302,336.0000 | 44433408 | 13.3470 | 25.1940 | 0.8876 | -0.4687 | candidate_latency_jump |
| a100_pairwise_nvlink | send_recv | 2 | 1 | 44,302,336.0000 | 44433408 | 13.3470 | 25.1940 | 0.8876 | -0.4687 | candidate_latency_jump |
| a100_pairwise_nvlink | all_reduce | 2 | 2 | 83,968.0000 | 92160 | 0.0640 | 0.0100 | -0.8438 | 6.0244 | nonmonotonic_latency_drop |
| a100_pairwise_nvlink | all_reduce | 2 | 2 | 755,712.0000 | 763904 | 0.0340 | 0.0620 | 0.8235 | -0.4457 | candidate_latency_jump |
| h100_dgx | all_reduce | 2 | 2 | 149,504.0000 | 157696 | 0.0410 | 0.0080 | -0.8049 | 4.4058 | nonmonotonic_latency_drop |
| a100_pairwise_nvlink | send_recv | 2 | 1 | 19,660,800.0000 | 19791872 | 6.8770 | 12.3960 | 0.8025 | -0.4415 | candidate_latency_jump |
| h100_pairwise_nvlink | send_recv | 2 | 1 | 19,660,800.0000 | 19791872 | 6.8770 | 12.3960 | 0.8025 | -0.4415 | candidate_latency_jump |
| a100_pairwise_nvlink | all_reduce | 2 | 2 | 387,072.0000 | 395264 | 0.0620 | 0.0130 | -0.7903 | 3.8702 | nonmonotonic_latency_drop |
| a100_dgx | all_reduce | 4 | 2 | 16,744,448.0000 | 16777216 | 2.3630 | 4.2300 | 0.7901 | -0.4403 | candidate_latency_jump |
| a100_pairwise_nvlink | all_reduce | 2 | 2 | 133,120.0000 | 141312 | 0.0520 | 0.0110 | -0.7885 | 4.0182 | nonmonotonic_latency_drop |
| h100_dgx | all_reduce | 2 | 2 | 387,072.0000 | 395264 | 0.0420 | 0.0100 | -0.7619 | 3.2889 | nonmonotonic_latency_drop |
| a100_pairwise_nvlink | all_reduce | 2 | 2 | 542,720.0000 | 550912 | 0.0630 | 0.0150 | -0.7619 | 3.2634 | nonmonotonic_latency_drop |
| h100_dgx | all_reduce | 2 | 2 | 509,952.0000 | 518144 | 0.0420 | 0.0110 | -0.7381 | 2.8795 | nonmonotonic_latency_drop |

## 5. 异常与数据缺口

除下表逐文件告警外，还有两个直接影响复现的版本缺口：当前 `config_optimizer/.../config.yml` 仍引用 `lmsys_chat_1m_conversation_stats_llama2_tokenizer.csv` 与 `bwb_stats_llama2_tokenizer_filtered_v2.csv`，但 processed-traces 目录没有这两个文件；因此仓库现状不能直接复现论文 Chat-1M/BWB-4K workload。另外，标准 network 文件的重复 key 全部位于 16,777,216 bytes，这是分段 size 采样网格边界重叠，而非有明确 repeat_id 的独立复测。

A40 `attention.csv` 的 2,235,600 个空值全部落在 decode 行的 prefill-only timing 字段，属于 phase-conditional schema，而不是随机缺失；但它仍含 479 个完全重复行，并有 29,236 行超出唯一 shape-key 组合（decode 22,752、prefill 6,484），且没有 repeat/config provenance 字段。详见 `misplaced_compute_profile_summary.csv`。

network 采样域也存在明显漂移：A100 pairwise all-reduce 有 2,247 个 size 点并延伸到 536,373,250 bytes（约 511.5 MiB），其余标准文件通常只有 993 个点、上限 64 MiB；H100 DGX all-reduce 只有节点内 w2/w4/w8，A40 则完全没有 all-reduce。所有标准 collective CSV 还都带一个多余的 `Unnamed: 0` index 列。

| 级别 | 路径 | 类型 | 说明 |
|---|---|---|---|
| high | profiling/network/a100_pairwise_nvlink/send_recv.csv | byte_identical_cross_file_copy | identical_to=profiling/network/h100_pairwise_nvlink/send_recv.csv; sha256=01985ec314f4e54fa7bb9512c4a76b5081aa98b2b60db902cbfb3a6f30cb9c21 |
| high | profiling/network/a40_pairwise_nvlink | missing_collective_profile | missing=all_reduce; observed=attention_compute,send_recv |
| high | profiling/network/a40_pairwise_nvlink/attention.csv | non_network_schema_under_network_directory | profile_type=attention_compute; metric columns are attention/compute fields |
| high | profiling/network/a40_pairwise_nvlink/send_recv.csv | topology_directory_metadata_mismatch | directory says pairwise_nvlink, max_devices_per_node values=[8] |
| medium | profiling/network/a100_dgx/all_reduce.csv | duplicate_profile_keys | rows=14; size_bytes=[16777216] |
| medium | profiling/network/a100_dgx/all_reduce.csv | high_within_point_jitter | CV>20% rows=174/6958 |
| medium | profiling/network/a100_dgx/all_reduce.csv | rank0_only | No cross-rank latency/asymmetry observations |
| medium | profiling/network/a100_dgx/send_recv.csv | duplicate_profile_keys | rows=4; size_bytes=[16777216] |
| medium | profiling/network/a100_dgx/send_recv.csv | high_within_point_jitter | CV>20% rows=12/1988 |
| medium | profiling/network/a100_dgx/send_recv.csv | rank0_only | No cross-rank latency/asymmetry observations |
| medium | profiling/network/a100_pairwise_nvlink/all_reduce.csv | duplicate_profile_keys | rows=4; size_bytes=[16777216] |
| medium | profiling/network/a100_pairwise_nvlink/all_reduce.csv | high_within_point_jitter | CV>20% rows=65/4496 |
| medium | profiling/network/a100_pairwise_nvlink/all_reduce.csv | rank0_only | No cross-rank latency/asymmetry observations |
| medium | profiling/network/a100_pairwise_nvlink/send_recv.csv | duplicate_profile_keys | rows=4; size_bytes=[16777216] |
| medium | profiling/network/a100_pairwise_nvlink/send_recv.csv | high_within_point_jitter | CV>20% rows=70/1988 |
| medium | profiling/network/a100_pairwise_nvlink/send_recv.csv | rank0_only | No cross-rank latency/asymmetry observations |
| medium | profiling/network/a40_pairwise_nvlink/send_recv.csv | duplicate_profile_keys | rows=4; size_bytes=[16777216] |
| medium | profiling/network/a40_pairwise_nvlink/send_recv.csv | high_within_point_jitter | CV>20% rows=14/1988 |
| medium | profiling/network/a40_pairwise_nvlink/send_recv.csv | rank0_only | No cross-rank latency/asymmetry observations |
| medium | profiling/network/h100_dgx/all_reduce.csv | duplicate_profile_keys | rows=6; size_bytes=[16777216] |
| medium | profiling/network/h100_dgx/all_reduce.csv | high_within_point_jitter | CV>20% rows=155/2982 |
| medium | profiling/network/h100_dgx/all_reduce.csv | rank0_only | No cross-rank latency/asymmetry observations |
| medium | profiling/network/h100_dgx/send_recv.csv | duplicate_profile_keys | rows=4; size_bytes=[16777216] |
| medium | profiling/network/h100_dgx/send_recv.csv | high_within_point_jitter | CV>20% rows=85/1988 |
| medium | profiling/network/h100_dgx/send_recv.csv | rank0_only | No cross-rank latency/asymmetry observations |
| medium | profiling/network/h100_pairwise_nvlink/all_reduce.csv | duplicate_profile_keys | rows=4; size_bytes=[16777216] |
| medium | profiling/network/h100_pairwise_nvlink/all_reduce.csv | high_within_point_jitter | CV>20% rows=36/1988 |
| medium | profiling/network/h100_pairwise_nvlink/all_reduce.csv | rank0_only | No cross-rank latency/asymmetry observations |
| medium | profiling/network/h100_pairwise_nvlink/send_recv.csv | duplicate_profile_keys | rows=4; size_bytes=[16777216] |
| medium | profiling/network/h100_pairwise_nvlink/send_recv.csv | high_within_point_jitter | CV>20% rows=70/1988 |
| medium | profiling/network/h100_pairwise_nvlink/send_recv.csv | rank0_only | No cross-rank latency/asymmetry observations |
| low | profiling/network/a100_dgx/all_reduce.csv | unnamed_index_column | Unnamed: 0 |
| low | profiling/network/a100_dgx/send_recv.csv | unnamed_index_column | Unnamed: 0 |
| low | profiling/network/a100_pairwise_nvlink/all_reduce.csv | unnamed_index_column | Unnamed: 0 |
| low | profiling/network/a100_pairwise_nvlink/send_recv.csv | unnamed_index_column | Unnamed: 0 |
| low | profiling/network/a40_pairwise_nvlink/send_recv.csv | unnamed_index_column | Unnamed: 0 |
| low | profiling/network/h100_dgx/all_reduce.csv | unnamed_index_column | Unnamed: 0 |
| low | profiling/network/h100_dgx/send_recv.csv | unnamed_index_column | Unnamed: 0 |
| low | profiling/network/h100_pairwise_nvlink/all_reduce.csv | unnamed_index_column | Unnamed: 0 |
| low | profiling/network/h100_pairwise_nvlink/send_recv.csv | unnamed_index_column | Unnamed: 0 |

## 6. 对论文结论和模拟器可用性的影响

1. **Workload 资产不能直接复现论文三 trace 结果。** 当前 processed 目录只有 Arxiv 与两条 Splitwise trace；缺 Chat-1M、BWB-4K 的论文版 processed trace。代码 README 的 Splitwise 示例是仓库后续能力，不应与论文 Table 1 混写。
2. **4096 域覆盖要按请求类型分别审计。** 超过 4096 的请求若仍使用默认 predictor max，会进入未经默认 attention profile 支撑的 KV/context 区域；扩大 CLI 上限并不会自动产生实测数据。当前 `trace_request_length_generator.py` 会把超限 prefill/decode 按比例缩短，而 `trace_replay_request_generator.py` 只从 prefill 扣除超额；所以原始 OOD 比例可能在运行时下降，但这是改变 workload，不能当作 profiling 覆盖已经解决。
3. **Network profile 是 topology-specific 的，而且有资产未被当前 loader 使用。** 同一 GPU 名称下 world size、devices_per_node 和跨节点组合不同，不能仅按 `device` 合并。当前 `sklearn_execution_time_predictor.py::_load_all_reduce_df` 要求 `num_workers==TP` 且 `devices_per_node==TP`，因此 A100 DGX 的 w4/dpn2、w8/dpn4、w16/dpn8 等跨节点 all-reduce 行不会进入该 predictor；send/recv 则按是否多节点固定选 dpn=1/2。缺失组合应拒绝或显式回退，不应默默借用另一拓扑。
4. **仅 rank 0 + 三次 active 重复不足以建尾部模型。** 对 median 插值尚可，但无法验证慢 rank、collective barrier skew 或 P95/P99；SLO 仿真应增加全 rank 记录和更多重复。
5. **非单调和跳变必须保留。** 不宜用单一线性带宽模型平滑掉阈值；RF/查表应按 world size、topology 分域，并在候选阈值两侧补采样。
6. **字节级复制和错放文件必须先治理。** H100 pairwise send/recv 在重新实测前应标为 provenance 不明；A40 attention 应移出 network 资产清单；A40 all-reduce 缺失应阻断相应配置搜索。

## 7. 建议的最小治理动作

- 给每个 CSV 增加 manifest：GPU SKU/PCIe 或 NVLink 形态、节点数、driver/CUDA/NCCL/PyTorch commit、采样日期、profile 命令、hash。
- network CSV 去除多余 index 列，按 `(collective, world_size, devices_per_node, size, rank, repeat_id)` 保存原始重复，而不只保存 rank0 汇总。
- 对所有阈值候选点在两侧补采至少 20–30 次，并随机化 size 顺序；报告 median、MAD、P95 与置信区间。
- 模拟器启动时校验请求/消息是否处在真实 profile envelope，未知 topology/world size/compiler 组合直接报 OOD。
- 将论文 trace、当前 Splitwise trace、演示 trace 分目录并附 provenance，避免把后续仓库资产误当论文复现实验输入。

## 8. 产物说明

- `file_inventory.csv`：全文件 schema、hash、缺失与重复审计。
- `workload_summary.csv`、`workload_quantiles.csv`、`workload_correlations.csv`、`workload_coverage.csv`、`workload_quality.csv`：workload 统计。
- `network_rows_enriched.csv`：标准 network 行，附 payload 带宽与抖动指标。
- `network_file_quality.csv`、`network_group_summary.csv`、`network_transitions.csv`、`network_threshold_candidates.csv`、`network_duplicate_keys.csv`、`network_anomalies.csv`：network 审计。
- `misplaced_compute_profile_summary.csv`：误放在 network 目录的 A40 attention 文件，按 prefill/decode 汇总其缺失、重复和 shape 范围。
- `analysis_summary.json`：机器可读摘要和 top-length 细节。

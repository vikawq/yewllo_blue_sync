#!/usr/bin/env python3
"""Read-only audit of Vidur processed workloads and network profiling CSVs.

Inputs are never modified. All outputs are written beside this script.
The analysis intentionally distinguishes observed facts from heuristic flags:
candidate network thresholds are diagnostic leads, not asserted NCCL algorithm switches.
"""

from __future__ import annotations

import hashlib
import json
import math
from pathlib import Path
from typing import Any, Iterable

import numpy as np
import pandas as pd


SOURCE_ROOT = Path(r"D:\workspaces\trace\vidur_repro\vidur\data")
WORKLOAD_ROOT = SOURCE_ROOT / "processed_traces"
NETWORK_ROOT = SOURCE_ROOT / "profiling" / "network"
OUTPUT_ROOT = Path(r"D:\workspaces\trace\vidur_data_analysis\network_workload_agent")

QUANTILES = [0, 0.01, 0.05, 0.10, 0.25, 0.50, 0.75, 0.90, 0.95, 0.99, 0.999, 1.0]
DOMAIN_LIMITS = [2048, 4096, 8192, 16384, 32768, 65536, 131072]
STANDARD_NETWORK_KEYS = [
    "num_workers",
    "size",
    "collective",
    "devices_per_node",
    "max_devices_per_node",
]


def json_safe(value: Any) -> Any:
    if isinstance(value, dict):
        return {str(k): json_safe(v) for k, v in value.items()}
    if isinstance(value, (list, tuple, set)):
        return [json_safe(v) for v in value]
    if isinstance(value, Path):
        return str(value)
    if isinstance(value, (np.integer,)):
        return int(value)
    if isinstance(value, (np.floating,)):
        if np.isnan(value) or np.isinf(value):
            return None
        return float(value)
    if isinstance(value, (pd.Timestamp,)):
        return value.isoformat()
    if pd.isna(value) if not isinstance(value, (str, bytes)) else False:
        return None
    return value


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def rel_path(path: Path) -> str:
    return path.relative_to(SOURCE_ROOT).as_posix()


def safe_ratio(numerator: pd.Series, denominator: pd.Series) -> pd.Series:
    result = numerator.astype(float) / denominator.astype(float).replace(0, np.nan)
    return result.replace([np.inf, -np.inf], np.nan)


def top_share(series: pd.Series, fraction: float) -> float:
    clean = pd.to_numeric(series, errors="coerce").dropna().clip(lower=0)
    if clean.empty or clean.sum() == 0:
        return np.nan
    count = max(1, int(math.ceil(len(clean) * fraction)))
    return float(clean.nlargest(count).sum() / clean.sum())


def audit_file(path: Path, category: str) -> tuple[dict[str, Any], pd.DataFrame]:
    df = pd.read_csv(path, low_memory=False)
    unnamed = [str(col) for col in df.columns if str(col).startswith("Unnamed:") or str(col) == ""]
    empty_cols = [str(col) for col in df.columns if df[col].isna().all()]
    missing = {str(col): int(df[col].isna().sum()) for col in df.columns if df[col].isna().any()}
    without_index = df.drop(columns=unnamed, errors="ignore")
    record = {
        "category": category,
        "path": rel_path(path),
        "filename": path.name,
        "bytes": path.stat().st_size,
        "sha256": sha256_file(path),
        "rows": len(df),
        "columns": len(df.columns),
        "column_names": json.dumps([str(c) for c in df.columns], ensure_ascii=False),
        "schema_signature": hashlib.sha256("|".join(map(str, df.columns)).encode()).hexdigest()[:16],
        "unnamed_index_columns": json.dumps(unnamed, ensure_ascii=False),
        "all_missing_columns": json.dumps(empty_cols, ensure_ascii=False),
        "missing_cells": int(df.isna().sum().sum()),
        "columns_with_missing": len(missing),
        "missing_by_column": json.dumps(missing, ensure_ascii=False, sort_keys=True),
        "exact_duplicate_rows_including_index": int(df.duplicated().sum()),
        "exact_duplicate_rows_excluding_index": int(without_index.duplicated().sum()),
    }
    return record, df


def analyze_workloads(
    workload_frames: dict[Path, pd.DataFrame],
) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame, pd.DataFrame, pd.DataFrame, dict[str, Any]]:
    summaries: list[dict[str, Any]] = []
    quantile_rows: list[dict[str, Any]] = []
    coverage_rows: list[dict[str, Any]] = []
    quality_rows: list[dict[str, Any]] = []
    correlation_rows: list[dict[str, Any]] = []
    details: dict[str, Any] = {}

    for path, source_df in workload_frames.items():
        name = path.stem
        df = source_df.copy()
        prefill = pd.to_numeric(df.get("num_prefill_tokens"), errors="coerce")
        decode = pd.to_numeric(df.get("num_decode_tokens"), errors="coerce")
        derived_total = prefill + decode
        derived_ratio = safe_ratio(prefill, decode)
        source_total = pd.to_numeric(df.get("num_total_tokens"), errors="coerce") if "num_total_tokens" in df else None
        source_ratio = pd.to_numeric(df.get("pd_ratio"), errors="coerce") if "pd_ratio" in df else None

        invalid_prefill = int((prefill <= 0).sum())
        invalid_decode = int((decode <= 0).sum())
        non_integral_prefill = int(((prefill.dropna() % 1) != 0).sum())
        non_integral_decode = int(((decode.dropna() % 1) != 0).sum())
        total_mismatch = 0
        ratio_mismatch = 0
        if source_total is not None:
            total_mismatch = int((~np.isclose(source_total, derived_total, equal_nan=True)).sum())
        if source_ratio is not None:
            ratio_mismatch = int((~np.isclose(source_ratio, derived_ratio, rtol=1e-9, atol=1e-12, equal_nan=True)).sum())

        arrival_stats: dict[str, Any] = {
            "has_arrival_time": "arrived_at" in df.columns,
            "arrival_not_monotonic": 0,
            "arrival_duplicate_timestamps": 0,
            "arrival_negative_gaps": 0,
            "arrival_zero_gaps": 0,
            "duration_seconds": np.nan,
            "observed_qps": np.nan,
            "interarrival_median_seconds": np.nan,
            "interarrival_p95_seconds": np.nan,
        }
        if "arrived_at" in df.columns:
            arrivals = pd.to_numeric(df["arrived_at"], errors="coerce")
            gaps = arrivals.diff().dropna()
            duration = float(arrivals.max() - arrivals.min()) if arrivals.notna().any() else np.nan
            arrival_stats.update(
                {
                    "arrival_not_monotonic": int(not arrivals.is_monotonic_increasing),
                    "arrival_duplicate_timestamps": int(arrivals.duplicated().sum()),
                    "arrival_negative_gaps": int((gaps < 0).sum()),
                    "arrival_zero_gaps": int((gaps == 0).sum()),
                    "duration_seconds": duration,
                    "observed_qps": float((len(df) - 1) / duration) if duration and duration > 0 else np.nan,
                    "interarrival_median_seconds": float(gaps.median()) if not gaps.empty else np.nan,
                    "interarrival_p95_seconds": float(gaps.quantile(0.95)) if not gaps.empty else np.nan,
                }
            )

        metrics = {
            "prefill_tokens": prefill,
            "decode_tokens": decode,
            "total_tokens": derived_total,
            "prefill_decode_ratio": derived_ratio,
        }
        summary = {
            "workload": name,
            "source_path": rel_path(path),
            "rows": len(df),
            "prefill_mean": prefill.mean(),
            "prefill_median": prefill.median(),
            "prefill_p90": prefill.quantile(0.90),
            "prefill_p95": prefill.quantile(0.95),
            "prefill_p99": prefill.quantile(0.99),
            "prefill_max": prefill.max(),
            "decode_mean": decode.mean(),
            "decode_median": decode.median(),
            "decode_p90": decode.quantile(0.90),
            "decode_p95": decode.quantile(0.95),
            "decode_p99": decode.quantile(0.99),
            "decode_max": decode.max(),
            "total_mean": derived_total.mean(),
            "total_median": derived_total.median(),
            "total_p90": derived_total.quantile(0.90),
            "total_p95": derived_total.quantile(0.95),
            "total_p99": derived_total.quantile(0.99),
            "total_max": derived_total.max(),
            "pd_ratio_median": derived_ratio.median(),
            "pd_ratio_p90": derived_ratio.quantile(0.90),
            "pd_ratio_p99": derived_ratio.quantile(0.99),
            "prefill_top1pct_token_share": top_share(prefill, 0.01),
            "decode_top1pct_token_share": top_share(decode, 0.01),
            "total_top1pct_token_share": top_share(derived_total, 0.01),
            "prefill_p99_over_median": float(prefill.quantile(0.99) / prefill.median()) if prefill.median() else np.nan,
            "decode_p99_over_median": float(decode.quantile(0.99) / decode.median()) if decode.median() else np.nan,
            **arrival_stats,
        }
        summaries.append(summary)

        for metric_name, values in metrics.items():
            clean = values.dropna()
            q_values = clean.quantile(QUANTILES)
            for quantile, value in q_values.items():
                quantile_rows.append(
                    {
                        "workload": name,
                        "metric": metric_name,
                        "quantile": quantile,
                        "value": value,
                    }
                )
            quantile_rows.append({"workload": name, "metric": metric_name, "quantile": "mean", "value": clean.mean()})
            quantile_rows.append({"workload": name, "metric": metric_name, "quantile": "std", "value": clean.std()})
            quantile_rows.append({"workload": name, "metric": metric_name, "quantile": "skew", "value": clean.skew()})

        corr_frame = pd.DataFrame({"prefill": prefill, "decode": decode}).dropna()
        for method in ["pearson", "spearman"]:
            correlation_rows.append(
                {
                    "workload": name,
                    "variables": "prefill_vs_decode",
                    "method": method,
                    "correlation": corr_frame.corr(method=method).loc["prefill", "decode"] if len(corr_frame) > 1 else np.nan,
                }
            )

        for limit in DOMAIN_LIMITS:
            coverage_rows.extend(
                [
                    {"workload": name, "domain_limit_tokens": limit, "coverage_kind": "prefill_le_limit", "rows": int((prefill <= limit).sum()), "fraction": float((prefill <= limit).mean())},
                    {"workload": name, "domain_limit_tokens": limit, "coverage_kind": "decode_le_limit", "rows": int((decode <= limit).sum()), "fraction": float((decode <= limit).mean())},
                    {"workload": name, "domain_limit_tokens": limit, "coverage_kind": "both_components_le_limit", "rows": int(((prefill <= limit) & (decode <= limit)).sum()), "fraction": float(((prefill <= limit) & (decode <= limit)).mean())},
                    {"workload": name, "domain_limit_tokens": limit, "coverage_kind": "request_total_le_limit", "rows": int((derived_total <= limit).sum()), "fraction": float((derived_total <= limit).mean())},
                    {"workload": name, "domain_limit_tokens": limit, "coverage_kind": "request_total_eq_limit", "rows": int((derived_total == limit).sum()), "fraction": float((derived_total == limit).mean())},
                ]
            )

        exact_common_caps = {
            f"prefill_eq_{limit}": int((prefill == limit).sum()) for limit in DOMAIN_LIMITS
        } | {f"decode_eq_{limit}": int((decode == limit).sum()) for limit in DOMAIN_LIMITS} | {
            f"total_eq_{limit}": int((derived_total == limit).sum()) for limit in DOMAIN_LIMITS
        }
        quality = {
            "workload": name,
            "rows": len(df),
            "missing_prefill": int(prefill.isna().sum()),
            "missing_decode": int(decode.isna().sum()),
            "nonpositive_prefill": invalid_prefill,
            "nonpositive_decode": invalid_decode,
            "nonintegral_prefill": non_integral_prefill,
            "nonintegral_decode": non_integral_decode,
            "duplicate_rows": int(df.duplicated().sum()),
            "source_total_mismatch": total_mismatch,
            "source_pd_ratio_mismatch": ratio_mismatch,
            **arrival_stats,
            **exact_common_caps,
        }
        quality_rows.append(quality)

        details[name] = {
            "top_10_prefill_lengths": prefill.value_counts().head(10).to_dict(),
            "top_10_decode_lengths": decode.value_counts().head(10).to_dict(),
            "top_10_total_lengths": derived_total.value_counts().head(10).to_dict(),
            "max_total_rows": df.loc[derived_total.nlargest(min(10, len(df))).index].to_dict(orient="records"),
        }

    return (
        pd.DataFrame(summaries),
        pd.DataFrame(quantile_rows),
        pd.DataFrame(coverage_rows),
        pd.DataFrame(quality_rows),
        pd.DataFrame(correlation_rows),
        details,
    )


def infer_network_metadata(path: Path, df: pd.DataFrame) -> dict[str, str]:
    directory = path.parent.name
    device, _, topology = directory.partition("_")
    metric_columns = [str(c) for c in df.columns if str(c).startswith("time_stats.")]
    if "collective" in df.columns and df["collective"].notna().any():
        collective_values = sorted(df["collective"].dropna().astype(str).unique())
        profile_type = collective_values[0] if len(collective_values) == 1 else "mixed_collective"
    elif any("attn_" in c for c in metric_columns):
        profile_type = "attention_compute"
    else:
        profile_type = "unknown"
    return {
        "device": device,
        "topology_directory": directory,
        "topology": topology,
        "profile_type": profile_type,
    }


def standard_network_metric_columns(collective: str) -> dict[str, str]:
    prefix = f"time_stats.{collective}"
    return {stat: f"{prefix}.{stat}" for stat in ["min", "max", "mean", "median", "std"]}


def analyze_network(
    network_frames: dict[Path, pd.DataFrame],
) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame, pd.DataFrame, pd.DataFrame, pd.DataFrame, pd.DataFrame, dict[str, Any]]:
    row_frames: list[pd.DataFrame] = []
    file_quality: list[dict[str, Any]] = []
    anomalies: list[dict[str, Any]] = []
    duplicate_keys: list[dict[str, Any]] = []
    misplaced_compute_summaries: list[dict[str, Any]] = []
    metadata_by_path: dict[Path, dict[str, str]] = {}

    for path, source_df in network_frames.items():
        df = source_df.copy()
        metadata = infer_network_metadata(path, df)
        metadata_by_path[path] = metadata
        unnamed = [str(c) for c in df.columns if str(c).startswith("Unnamed:") or str(c) == ""]
        clean = df.drop(columns=unnamed, errors="ignore")
        standard = metadata["profile_type"] in {"all_reduce", "send_recv"}
        record: dict[str, Any] = {
            "source_path": rel_path(path),
            **metadata,
            "rows": len(df),
            "columns": len(df.columns),
            "unnamed_index_columns": len(unnamed),
            "missing_cells": int(df.isna().sum().sum()),
            "exact_duplicate_rows_excluding_index": int(clean.duplicated().sum()),
            "is_standard_network_schema": standard,
            "key_duplicate_rows": np.nan,
            "rank_values": "",
            "world_sizes": "",
            "devices_per_node_values": "",
            "size_min_bytes": np.nan,
            "size_max_bytes": np.nan,
            "unique_sizes": np.nan,
            "invalid_metric_rows": np.nan,
            "high_cv_rows_gt_20pct": np.nan,
        }

        if unnamed:
            anomalies.append({"severity": "low", "source_path": rel_path(path), "kind": "unnamed_index_column", "detail": ",".join(unnamed)})
        if not standard:
            anomalies.append(
                {
                    "severity": "high",
                    "source_path": rel_path(path),
                    "kind": "non_network_schema_under_network_directory",
                    "detail": f"profile_type={metadata['profile_type']}; metric columns are attention/compute fields",
                }
            )
            if metadata["profile_type"].startswith("attention"):
                profile_keys = [
                    "n_embd", "n_q_head", "n_kv_head", "block_size",
                    "num_tensor_parallel_workers", "max_model_len", "batch_size",
                    "prefill_chunk_size", "kv_cache_size", "is_prefill",
                ]
                available_keys = [col for col in profile_keys if col in clean.columns]
                phase_groups = clean.groupby("is_prefill", dropna=False) if "is_prefill" in clean.columns else [("unknown", clean)]
                for phase, phase_df in phase_groups:
                    summary: dict[str, Any] = {
                        "source_path": rel_path(path),
                        "phase": "prefill" if pd.notna(phase) and bool(phase) else "decode" if pd.notna(phase) else str(phase),
                        "rows": len(phase_df),
                        "missing_cells": int(phase_df.isna().sum().sum()),
                        "exact_duplicate_rows": int(phase_df.duplicated().sum()),
                        "duplicate_profile_key_rows_keep_all": int(phase_df.duplicated(available_keys, keep=False).sum()) if available_keys else np.nan,
                        "extra_rows_beyond_unique_profile_keys": int(phase_df.duplicated(available_keys).sum()) if available_keys else np.nan,
                    }
                    for col in [
                        "n_embd", "n_q_head", "n_kv_head", "block_size",
                        "num_tensor_parallel_workers", "max_model_len", "batch_size",
                        "prefill_chunk_size", "kv_cache_size",
                    ]:
                        if col in phase_df.columns:
                            numeric = pd.to_numeric(phase_df[col], errors="coerce")
                            summary[f"{col}_unique"] = int(numeric.nunique())
                            summary[f"{col}_min"] = numeric.min()
                            summary[f"{col}_max"] = numeric.max()
                    misplaced_compute_summaries.append(summary)
            file_quality.append(record)
            continue

        collective = metadata["profile_type"]
        metric_cols = standard_network_metric_columns(collective)
        required = STANDARD_NETWORK_KEYS + list(metric_cols.values()) + ["rank"]
        missing_required = [col for col in required if col not in clean.columns]
        if missing_required:
            anomalies.append({"severity": "high", "source_path": rel_path(path), "kind": "missing_required_columns", "detail": ",".join(missing_required)})
            file_quality.append(record)
            continue

        for col in ["rank", "num_workers", "size", "devices_per_node", "max_devices_per_node", *metric_cols.values()]:
            clean[col] = pd.to_numeric(clean[col], errors="coerce")

        key_dupe_mask = clean.duplicated(STANDARD_NETWORK_KEYS, keep=False)
        record.update(
            {
                "key_duplicate_rows": int(key_dupe_mask.sum()),
                "rank_values": ",".join(map(str, sorted(clean["rank"].dropna().astype(int).unique()))),
                "world_sizes": ",".join(map(str, sorted(clean["num_workers"].dropna().astype(int).unique()))),
                "devices_per_node_values": ",".join(map(str, sorted(clean["devices_per_node"].dropna().astype(int).unique()))),
                "size_min_bytes": clean["size"].min(),
                "size_max_bytes": clean["size"].max(),
                "unique_sizes": clean["size"].nunique(),
            }
        )
        if key_dupe_mask.any():
            grouped_dupes = clean.loc[key_dupe_mask].groupby(STANDARD_NETWORK_KEYS, dropna=False)
            for key, group in grouped_dupes:
                medians = group[metric_cols["median"]]
                duplicate_keys.append(
                    {
                        "source_path": rel_path(path),
                        **dict(zip(STANDARD_NETWORK_KEYS, key)),
                        "count": len(group),
                        "median_min_ms": medians.min(),
                        "median_max_ms": medians.max(),
                        "median_spread_fraction": float((medians.max() - medians.min()) / medians.median()) if medians.median() else np.nan,
                    }
                )
            duplicate_sizes = [
                int(value) for value in sorted(clean.loc[key_dupe_mask, "size"].dropna().astype(int).unique())
            ]
            anomalies.append(
                {
                    "severity": "medium",
                    "source_path": rel_path(path),
                    "kind": "duplicate_profile_keys",
                    "detail": f"rows={int(key_dupe_mask.sum())}; size_bytes={duplicate_sizes}",
                }
            )

        stat_min = clean[metric_cols["min"]]
        stat_max = clean[metric_cols["max"]]
        stat_mean = clean[metric_cols["mean"]]
        stat_median = clean[metric_cols["median"]]
        stat_std = clean[metric_cols["std"]]
        # pandas CSV round-tripping can place mean/median a few ulps outside the
        # printed min/max. Treat only differences larger than a scale-aware
        # floating-point tolerance as invalid.
        stat_scale = pd.concat([stat_min.abs(), stat_max.abs(), stat_mean.abs(), stat_median.abs()], axis=1).max(axis=1)
        stat_eps = np.maximum(1e-12, stat_scale * 1e-12)
        invalid_metric = (
            (clean["size"] <= 0)
            | (stat_min < 0)
            | (stat_max < 0)
            | (stat_mean < stat_min - stat_eps)
            | (stat_mean > stat_max + stat_eps)
            | (stat_median < stat_min - stat_eps)
            | (stat_median > stat_max + stat_eps)
            | (stat_std < -stat_eps)
        )
        cv = stat_std / stat_mean.replace(0, np.nan)
        record["invalid_metric_rows"] = int(invalid_metric.sum())
        record["high_cv_rows_gt_20pct"] = int((cv > 0.20).sum())
        if invalid_metric.any():
            anomalies.append({"severity": "high", "source_path": rel_path(path), "kind": "invalid_summary_statistics", "detail": f"rows={int(invalid_metric.sum())}"})
        if (cv > 0.20).any():
            anomalies.append({"severity": "medium", "source_path": rel_path(path), "kind": "high_within_point_jitter", "detail": f"CV>20% rows={int((cv > 0.20).sum())}/{len(clean)}"})

        if clean["rank"].nunique() == 1 and clean["rank"].iloc[0] == 0:
            anomalies.append({"severity": "medium", "source_path": rel_path(path), "kind": "rank0_only", "detail": "No cross-rank latency/asymmetry observations"})
        if path.name.replace(".csv", "") != collective:
            anomalies.append({"severity": "high", "source_path": rel_path(path), "kind": "filename_collective_mismatch", "detail": f"filename={path.name}, collective={collective}"})
        if (clean["collective"].astype(str) != collective).any():
            anomalies.append({"severity": "high", "source_path": rel_path(path), "kind": "collective_value_mismatch", "detail": f"expected={collective}"})

        clean["source_path"] = rel_path(path)
        for key, value in metadata.items():
            clean[key] = value
        clean["latency_min_ms"] = stat_min
        clean["latency_max_ms"] = stat_max
        clean["latency_mean_ms"] = stat_mean
        clean["latency_median_ms"] = stat_median
        clean["latency_std_ms"] = stat_std
        clean["within_point_cv"] = cv
        clean["range_over_median"] = (stat_max - stat_min) / stat_median.replace(0, np.nan)
        clean["payload_equiv_GBps"] = clean["size"] / (clean["latency_median_ms"] * 1_000_000.0)
        clean["ring_assumed_bus_GBps"] = np.where(
            clean["collective"].astype(str) == "all_reduce",
            clean["payload_equiv_GBps"] * 2 * (clean["num_workers"] - 1) / clean["num_workers"],
            clean["payload_equiv_GBps"],
        )
        row_frames.append(clean)
        file_quality.append(record)

    rows = pd.concat(row_frames, ignore_index=True) if row_frames else pd.DataFrame()
    group_cols = ["device", "topology_directory", "collective", "num_workers", "devices_per_node", "max_devices_per_node"]
    group_summaries: list[dict[str, Any]] = []
    transitions: list[dict[str, Any]] = []
    threshold_candidates: list[dict[str, Any]] = []

    if not rows.empty:
        for key, group_source in rows.groupby(group_cols, dropna=False):
            group = (
                group_source.groupby("size", as_index=False)
                .agg(
                    latency_median_ms=("latency_median_ms", "median"),
                    latency_mean_ms=("latency_mean_ms", "median"),
                    latency_std_ms=("latency_std_ms", "median"),
                    within_point_cv=("within_point_cv", "median"),
                    payload_equiv_GBps=("payload_equiv_GBps", "median"),
                    ring_assumed_bus_GBps=("ring_assumed_bus_GBps", "median"),
                    source_path=("source_path", "first"),
                )
                .sort_values("size")
                .reset_index(drop=True)
            )
            meta = dict(zip(group_cols, key))
            group["prev_size"] = group["size"].shift(1)
            group["prev_latency"] = group["latency_median_ms"].shift(1)
            group["prev_bw"] = group["payload_equiv_GBps"].shift(1)
            group["size_ratio"] = group["size"] / group["prev_size"]
            group["latency_rel_change"] = group["latency_median_ms"] / group["prev_latency"] - 1
            group["latency_abs_change_ms"] = group["latency_median_ms"] - group["prev_latency"]
            group["bw_rel_change"] = group["payload_equiv_GBps"] / group["prev_bw"] - 1
            group["combined_adjacent_std_ms"] = np.sqrt(
                group["latency_std_ms"].pow(2) + group["latency_std_ms"].shift(1).pow(2)
            )
            group["transition_kind"] = "normal"
            adjacent = group["size_ratio"] <= 1.25
            # Keep the full transition table, but call a point a threshold
            # candidate only when it clears both an absolute floor and the
            # measured three-repeat noise floor. This avoids flooding the
            # report with 1-us timer quantisation steps.
            credible_change = (
                group["size"].ge(64 * 1024)
                & group["latency_abs_change_ms"].abs().ge(0.005)
                & group["latency_abs_change_ms"].abs().ge(3 * group["combined_adjacent_std_ms"].fillna(0))
            )
            jump = adjacent & credible_change & (group["latency_rel_change"] >= 0.25)
            drop = adjacent & credible_change & (group["latency_rel_change"] <= -0.20)
            group.loc[jump, "transition_kind"] = "candidate_latency_jump"
            group.loc[drop, "transition_kind"] = "nonmonotonic_latency_drop"
            for _, row in group.iloc[1:].iterrows():
                transition = {
                    **meta,
                    "source_path": row["source_path"],
                    "prev_size_bytes": row["prev_size"],
                    "size_bytes": row["size"],
                    "size_ratio": row["size_ratio"],
                    "prev_latency_ms": row["prev_latency"],
                    "latency_ms": row["latency_median_ms"],
                    "latency_rel_change": row["latency_rel_change"],
                    "latency_abs_change_ms": row["latency_abs_change_ms"],
                    "combined_adjacent_std_ms": row["combined_adjacent_std_ms"],
                    "bw_rel_change": row["bw_rel_change"],
                    "transition_kind": row["transition_kind"],
                }
                transitions.append(transition)
                if row["transition_kind"] != "normal":
                    threshold_candidates.append(transition)

            top_size_cutoff = group["size"].quantile(0.90)
            small = group[group["size"] <= 64 * 1024]
            large = group[group["size"] >= top_size_cutoff]
            p95_bw = group["payload_equiv_GBps"].quantile(0.95)
            reach_80 = group[group["payload_equiv_GBps"] >= 0.80 * p95_bw]
            group_summaries.append(
                {
                    **meta,
                    "source_path": group["source_path"].iloc[0],
                    "rows_raw": len(group_source),
                    "unique_sizes": group["size"].nunique(),
                    "size_min_bytes": group["size"].min(),
                    "size_max_bytes": group["size"].max(),
                    "latency_at_min_size_ms": group.iloc[0]["latency_median_ms"],
                    "latency_at_max_size_ms": group.iloc[-1]["latency_median_ms"],
                    "small_message_latency_median_ms_le_64KiB": small["latency_median_ms"].median() if not small.empty else np.nan,
                    "payload_bw_median_GBps": group["payload_equiv_GBps"].median(),
                    "payload_bw_p95_GBps": p95_bw,
                    "payload_bw_max_GBps": group["payload_equiv_GBps"].max(),
                    "large_message_payload_bw_median_GBps_top10pct_sizes": large["payload_equiv_GBps"].median() if not large.empty else np.nan,
                    "ring_assumed_bus_bw_p95_GBps": group["ring_assumed_bus_GBps"].quantile(0.95),
                    "first_size_reaching_80pct_p95_bw_bytes": reach_80["size"].min() if not reach_80.empty else np.nan,
                    "within_point_cv_median": group_source["within_point_cv"].median(),
                    "within_point_cv_p95": group_source["within_point_cv"].quantile(0.95),
                    "within_point_cv_max": group_source["within_point_cv"].max(),
                    "high_cv_share_gt_20pct": float((group_source["within_point_cv"] > 0.20).mean()),
                    "nonmonotonic_drop_count": int(drop.sum()),
                    "candidate_jump_count": int(jump.sum()),
                }
            )

    group_summary_df = pd.DataFrame(group_summaries)
    transitions_df = pd.DataFrame(transitions)
    threshold_df = pd.DataFrame(threshold_candidates)

    # Cross-file exact copies are especially suspicious when device labels differ.
    paths = sorted(network_frames)
    hashes = {path: sha256_file(path) for path in paths}
    for i, left in enumerate(paths):
        for right in paths[i + 1 :]:
            if hashes[left] == hashes[right]:
                anomalies.append(
                    {
                        "severity": "high" if left.parent.name != right.parent.name else "medium",
                        "source_path": rel_path(left),
                        "kind": "byte_identical_cross_file_copy",
                        "detail": f"identical_to={rel_path(right)}; sha256={hashes[left]}",
                    }
                )

    # Coverage matrix: each directory should normally have all_reduce and send_recv.
    observed: dict[str, set[str]] = {}
    for path, meta in metadata_by_path.items():
        observed.setdefault(path.parent.name, set()).add(meta["profile_type"])
    for directory, types in observed.items():
        for expected in ["all_reduce", "send_recv"]:
            if expected not in types:
                anomalies.append(
                    {
                        "severity": "high",
                        "source_path": f"profiling/network/{directory}",
                        "kind": "missing_collective_profile",
                        "detail": f"missing={expected}; observed={','.join(sorted(types))}",
                    }
                )

    # Directory metadata should agree with recorded node width for pairwise 4-GPU profiles.
    for path, df in network_frames.items():
        if "max_devices_per_node" in df.columns and "pairwise_nvlink" in path.parent.name:
            values = [
                int(value)
                for value in sorted(
                    pd.to_numeric(df["max_devices_per_node"], errors="coerce").dropna().astype(int).unique()
                )
            ]
            if values and max(values) > 4:
                anomalies.append(
                    {
                        "severity": "high",
                        "source_path": rel_path(path),
                        "kind": "topology_directory_metadata_mismatch",
                        "detail": f"directory says pairwise_nvlink, max_devices_per_node values={values}",
                    }
                )

    details = {
        "observed_profile_types_by_directory": {k: sorted(v) for k, v in observed.items()},
        "standard_network_rows": len(rows),
        "standard_network_groups": len(group_summary_df),
    }
    return (
        rows,
        pd.DataFrame(file_quality),
        group_summary_df,
        transitions_df,
        threshold_df,
        pd.DataFrame(duplicate_keys),
        pd.DataFrame(misplaced_compute_summaries),
        {"anomalies": anomalies, **details},
    )


def fmt_number(value: Any, digits: int = 2) -> str:
    if value is None or (isinstance(value, float) and (np.isnan(value) or np.isinf(value))):
        return "NA"
    if isinstance(value, (int, np.integer)):
        return f"{int(value):,}"
    return f"{float(value):,.{digits}f}"


def fmt_pct(value: Any, digits: int = 1) -> str:
    if value is None or pd.isna(value):
        return "NA"
    return f"{float(value) * 100:.{digits}f}%"


def markdown_table(frame: pd.DataFrame, columns: list[str], headers: list[str] | None = None, limit: int | None = None) -> str:
    if frame.empty:
        return "（无数据）"
    shown = frame.head(limit) if limit else frame
    headers = headers or columns
    lines = ["| " + " | ".join(headers) + " |", "|" + "|".join(["---"] * len(columns)) + "|"]
    for _, row in shown.iterrows():
        values = []
        for col in columns:
            value = row[col]
            if isinstance(value, float):
                values.append(fmt_number(value, 4))
            else:
                values.append(str(value).replace("|", "\\|"))
        lines.append("| " + " | ".join(values) + " |")
    return "\n".join(lines)


def generate_report(
    inventory: pd.DataFrame,
    workload_summary: pd.DataFrame,
    workload_quality: pd.DataFrame,
    workload_coverage: pd.DataFrame,
    workload_correlations: pd.DataFrame,
    network_file_quality: pd.DataFrame,
    network_group_summary: pd.DataFrame,
    network_thresholds: pd.DataFrame,
    network_details: dict[str, Any],
) -> str:
    lines: list[str] = []
    lines.append("# Vidur workload 与 network profiling 数据审计\n")
    lines.append("本报告由 `analyze_network_workloads.py` 从官方仓库 CSV 只读生成。统计对象为 `data/processed_traces` 与 `data/profiling/network` 下的全部 CSV；未修改源文件。\n")
    lines.append("## 1. 结论摘要\n")
    lines.append(f"- 共审计 {len(inventory)} 个 CSV：{int((inventory['category'] == 'workload').sum())} 个 processed workload、{int((inventory['category'] == 'network').sum())} 个 network 目录文件。")
    lines.append("- 当前仓库的三个 processed workload 是 Arxiv summarization、Splitwise code、Splitwise conversation；它们并不是论文 Table 1 的 Chat-1M/Arxiv-4K/BWB-4K 三件套，尤其仓库没有 BWB processed trace。")
    lines.append("- `a40_pairwise_nvlink/attention.csv` 是 compute-attention 数据误放在 network 目录，不能作为 collective profile 使用。")
    lines.append("- 标准 collective CSV 只有 rank 0 的三次重复统计，足以做单点中位数插值，但无法验证 rank 间不对称；三次重复也不足以稳定刻画尾部。")
    lines.append("- `h100_pairwise_nvlink/send_recv.csv` 与 `a100_pairwise_nvlink/send_recv.csv` 字节级完全相同，不能据此声称 H100 与 A100 的 send/recv 实测一致。")
    lines.append("- A40 目录缺 all-reduce，H100 DGX all-reduce 的 world-size 覆盖也明显窄于 A100；模拟器对缺失配置没有可靠实测支撑。\n")

    lines.append("## 2. 数据资产与质量\n")
    inv_view = inventory[["category", "path", "rows", "columns", "bytes", "missing_cells", "exact_duplicate_rows_excluding_index"]].copy()
    lines.append(markdown_table(inv_view, list(inv_view.columns), ["类别", "路径", "行", "列", "字节", "缺失单元格", "重复行（去 index）"]))
    lines.append("")

    lines.append("### 2.1 Workload schema 与完整性\n")
    quality_cols = ["workload", "rows", "missing_prefill", "missing_decode", "nonpositive_prefill", "nonpositive_decode", "duplicate_rows", "source_total_mismatch", "source_pd_ratio_mismatch"]
    lines.append(markdown_table(workload_quality, quality_cols, ["workload", "行", "prefill 缺失", "decode 缺失", "prefill<=0", "decode<=0", "重复行", "total 不一致", "P:D 不一致"]))
    lines.append(
        "\nArxiv 文件自带 `num_total_tokens` 与 `pd_ratio`，分析脚本逐行用 prefill/decode 重算核对；Splitwise 两个文件另带到达时间。"
        "Arxiv 的 469 个重复行只是相同长度/比值元组重复；文件没有 request id 或 arrival time，故不能据此判定为数据损坏，也不能还原请求次序。\n"
    )

    lines.append("## 3. 三个 workload 的长度与长尾\n")
    workload_view = workload_summary[[
        "workload", "rows", "prefill_median", "prefill_p90", "prefill_p99", "prefill_max",
        "decode_median", "decode_p90", "decode_p99", "decode_max", "total_p99", "total_max", "pd_ratio_median"
    ]].copy()
    lines.append(markdown_table(workload_view, list(workload_view.columns), [
        "workload", "请求数", "P50 prefill", "P90 prefill", "P99 prefill", "max prefill",
        "P50 decode", "P90 decode", "P99 decode", "max decode", "P99 total", "max total", "P:D 中位"
    ]))
    lines.append("")
    arxiv = workload_summary[workload_summary["workload"].str.startswith("arxiv_")].iloc[0]
    code = workload_summary[workload_summary["workload"].eq("splitwise_code")].iloc[0]
    conv = workload_summary[workload_summary["workload"].eq("splitwise_conv")].iloc[0]
    arxiv_eq_4096 = workload_coverage[
        workload_coverage["workload"].str.startswith("arxiv_")
        & workload_coverage["domain_limit_tokens"].eq(4096)
        & workload_coverage["coverage_kind"].eq("request_total_eq_limit")
    ]["rows"].iloc[0]
    lines.append("### 3.1 分布形态与截断证据\n")
    lines.append(
        f"- **Arxiv**：total 最大值恰为 4096，且有 {int(arxiv_eq_4096)} 条恰好命中 4096；"
        f"decode P99/P50={arxiv['decode_p99_over_median']:.2f}，top 1% 请求贡献 {arxiv['decode_top1pct_token_share']:.2%} decode tokens。"
        "这是经过 4K 过滤/截断的数据，不应视为未裁剪的自然长度分布。"
    )
    lines.append(
        f"- **Splitwise code**：prefill P50/P99/max={code['prefill_median']:.0f}/{code['prefill_p99']:.0f}/{code['prefill_max']:.0f}，"
        "并在 7435/7436/7437 形成明显堆积（103/201/18 条），说明源 trace 存在约 7.44K 的长度上沿；"
        f"P:D 中位为 {code['pd_ratio_median']:.1f}，属于极强 prefill-heavy 负载。"
    )
    lines.append(
        f"- **Splitwise conversation**：prefill P50/P99/max={conv['prefill_median']:.0f}/{conv['prefill_p99']:.0f}/{conv['prefill_max']:.0f}，"
        f"最大 total={conv['total_max']:.0f}；主体在约 4K 内，但存在稀疏超长离群请求。"
    )
    lines.append(
        f"- 两条 Splitwise trace 的到达时间均单调且无负/零间隔；观测时段分别为 {code['duration_seconds']:.1f}s/"
        f"{conv['duration_seconds']:.1f}s，平均 QPS={code['observed_qps']:.3f}/{conv['observed_qps']:.3f}。"
    )
    lines.append("")

    corr_p = workload_correlations[workload_correlations["method"] == "pearson"][["workload", "correlation"]].rename(columns={"correlation": "pearson"})
    corr_s = workload_correlations[workload_correlations["method"] == "spearman"][["workload", "correlation"]].rename(columns={"correlation": "spearman"})
    corr = corr_p.merge(corr_s, on="workload", how="outer")
    lines.append("### 3.2 Prefill 与 decode 相关性\n")
    lines.append(markdown_table(corr, ["workload", "pearson", "spearman"], ["workload", "Pearson", "Spearman"]))
    lines.append("\n相关性低不等于两个边际分布可独立采样；仿真 trace 应保留原始成对长度，否则会改变 KV-cache 压力和 batch composition。\n")

    coverage_4096 = workload_coverage[(workload_coverage["domain_limit_tokens"] == 4096) & (workload_coverage["coverage_kind"].isin(["prefill_le_limit", "decode_le_limit", "request_total_le_limit"]))]
    coverage_pivot = coverage_4096.pivot(index="workload", columns="coverage_kind", values="fraction").reset_index()
    coverage_pivot = coverage_pivot.reindex(
        columns=["workload", "prefill_le_limit", "decode_le_limit", "request_total_le_limit"]
    )
    for col in ["prefill_le_limit", "decode_le_limit", "request_total_le_limit"]:
        if col in coverage_pivot:
            coverage_pivot[col] = coverage_pivot[col].map(fmt_pct)
    lines.append("### 3.3 对默认 4096-token attention profiling domain 的覆盖\n")
    lines.append(markdown_table(coverage_pivot, list(coverage_pivot.columns), ["workload", "prefill<=4096", "decode<=4096", "total/context<=4096"]))
    lines.append(
        "\n`request_total<=4096` 是 attention context 全程不超默认 4096 的保守判据。"
        "Arxiv/code/conversation 的 total/context 覆盖率分别为 100.00%/85.75%/91.68%；"
        "三者 decode 长度本身均 100% 落在 4096 内。Token-level 每 iteration 总 token 还取决于 scheduler、chunk size 和 batch composition，不能仅由请求长度文件精确推出。\n"
    )

    lines.append("## 4. Network profile 覆盖与性能\n")
    nf_cols = ["topology_directory", "profile_type", "rows", "world_sizes", "devices_per_node_values", "size_min_bytes", "size_max_bytes", "unique_sizes", "high_cv_rows_gt_20pct"]
    lines.append(markdown_table(network_file_quality, nf_cols, ["目录", "profile", "行", "world sizes", "devices/node", "min bytes", "max bytes", "size 点数", "CV>20% 行"]))
    lines.append(
        "\n`size` 是代码写出的字节数。下述带宽为 `size / median_latency` 的 payload-equivalent GB/s；"
        "all-reduce 的 ring bus 带宽只作为带明确假设的辅助列，不能等同 NCCL 实际算法带宽。"
        "P95 是对采样网格点求分位数，不是按真实 message-size workload 加权后的 P95；网格在不同 size 区间的密度也不同。\n"
    )

    if not network_group_summary.empty:
        group_view = network_group_summary.copy()
        group_view["group"] = (
            group_view["topology_directory"].astype(str)
            + "/" + group_view["collective"].astype(str)
            + "/w" + group_view["num_workers"].astype(int).astype(str)
            + "/dpn" + group_view["devices_per_node"].astype(int).astype(str)
        )
        group_view = group_view.sort_values(["topology_directory", "collective", "num_workers", "devices_per_node"])
        columns = ["group", "unique_sizes", "small_message_latency_median_ms_le_64KiB", "payload_bw_p95_GBps", "large_message_payload_bw_median_GBps_top10pct_sizes", "within_point_cv_p95", "nonmonotonic_drop_count", "candidate_jump_count"]
        lines.append("### 4.1 分组延迟、带宽与抖动\n")
        lines.append(markdown_table(group_view, columns, ["group", "size 点", "<=64KiB 延迟中位 ms", "payload BW P95 GB/s", "大消息 BW 中位 GB/s", "单点 CV P95", "非单调下降", "跳变候选"]))
        lines.append("")

        def group_metric(topology: str, collective: str, world: int, dpn: int, metric: str) -> float:
            matched = network_group_summary[
                network_group_summary["topology_directory"].eq(topology)
                & network_group_summary["collective"].eq(collective)
                & network_group_summary["num_workers"].eq(world)
                & network_group_summary["devices_per_node"].eq(dpn)
            ]
            return float(matched.iloc[0][metric]) if len(matched) else float("nan")

        p95 = "payload_bw_p95_GBps"
        lines.append("### 4.2 拓扑与带宽拐点的主要读数\n")
        lines.append(
            "- **A100 DGX all-reduce** 的 payload-BW P95 清楚地区分节点内/跨节点："
            f"w2/dpn2={group_metric('a100_dgx', 'all_reduce', 2, 2, p95):.2f} GB/s，"
            f"w2/dpn1={group_metric('a100_dgx', 'all_reduce', 2, 1, p95):.2f}；"
            f"w4/dpn4={group_metric('a100_dgx', 'all_reduce', 4, 4, p95):.2f}，"
            f"w4/dpn2={group_metric('a100_dgx', 'all_reduce', 4, 2, p95):.2f}；"
            f"w8/dpn8={group_metric('a100_dgx', 'all_reduce', 8, 8, p95):.2f}，"
            f"w8/dpn4={group_metric('a100_dgx', 'all_reduce', 8, 4, p95):.2f}。"
        )
        lines.append(
            "- **H100 DGX all-reduce** 仅有节点内 w2/w4/w8，P95 分别为 "
            f"{group_metric('h100_dgx', 'all_reduce', 2, 2, p95):.2f}/"
            f"{group_metric('h100_dgx', 'all_reduce', 4, 4, p95):.2f}/"
            f"{group_metric('h100_dgx', 'all_reduce', 8, 8, p95):.2f} GB/s；"
            "不能据此外推 H100 跨节点或 w16。"
        )
        lines.append(
            "- **pairwise-NVLink all-reduce** 从 w2 到 w4 出现巨大拓扑惩罚：A100 "
            f"{group_metric('a100_pairwise_nvlink', 'all_reduce', 2, 2, p95):.2f}->"
            f"{group_metric('a100_pairwise_nvlink', 'all_reduce', 4, 4, p95):.2f} GB/s；H100 "
            f"{group_metric('h100_pairwise_nvlink', 'all_reduce', 2, 2, p95):.2f}->"
            f"{group_metric('h100_pairwise_nvlink', 'all_reduce', 4, 4, p95):.2f} GB/s。"
            "这与 w4 跨越成对高速链路边界相容，但算法原因仍需拓扑/NCCL 日志确认。"
        )
        lines.append(
            "- 带宽均为 payload-equivalent，不是厂商峰值或 NCCL busbw。尤其跨节点/跨 pair 配置的大消息带宽可能在最大 size 区间回落，"
            "因此不能用单一饱和带宽常数替代整条实测曲线。"
        )
        lines.append("")

    lines.append("### 4.3 阈值/非单调候选\n")
    lines.append(
        f"共检出 {len(network_thresholds)} 个局部不连续候选。规则要求：size>=64KiB、相邻 size 比<=1.25、"
        "绝对延迟变化>=0.005ms 且>=相邻两点合成标准差的 3 倍，并满足上跳>=25% 或下降>=20%。"
        "这只是噪声过滤后的 change-point 候选；它们可能来自 NCCL 算法/协议切换、拓扑阈值、拥塞或三次重复仍未覆盖的偶发抖动，"
        "没有 NCCL debug 日志和阈值两侧加密复测就不能定性为算法切换。`network_transitions.csv` 保留全部相邻点，便于采用别的规则复核。\n"
    )
    if not network_thresholds.empty:
        ranked = network_thresholds.copy()
        ranked["abs_change"] = ranked["latency_rel_change"].abs()
        ranked = ranked.sort_values("abs_change", ascending=False)
        tcols = ["topology_directory", "collective", "num_workers", "devices_per_node", "prev_size_bytes", "size_bytes", "prev_latency_ms", "latency_ms", "latency_rel_change", "bw_rel_change", "transition_kind"]
        lines.append(markdown_table(ranked, tcols, ["目录", "collective", "world", "dpn", "前一 size", "当前 size", "前一 ms", "当前 ms", "延迟变化", "BW 变化", "类型"], limit=30))
    else:
        lines.append("未检出满足规则的候选点。")
    lines.append("")

    lines.append("## 5. 异常与数据缺口\n")
    lines.append(
        "除下表逐文件告警外，还有两个直接影响复现的版本缺口：当前 `config_optimizer/.../config.yml` 仍引用 "
        "`lmsys_chat_1m_conversation_stats_llama2_tokenizer.csv` 与 `bwb_stats_llama2_tokenizer_filtered_v2.csv`，"
        "但 processed-traces 目录没有这两个文件；因此仓库现状不能直接复现论文 Chat-1M/BWB-4K workload。"
        "另外，标准 network 文件的重复 key 全部位于 16,777,216 bytes，这是分段 size 采样网格边界重叠，而非有明确 repeat_id 的独立复测。\n"
    )
    lines.append(
        "A40 `attention.csv` 的 2,235,600 个空值全部落在 decode 行的 prefill-only timing 字段，属于 phase-conditional schema，而不是随机缺失；"
        "但它仍含 479 个完全重复行，并有 29,236 行超出唯一 shape-key 组合（decode 22,752、prefill 6,484），且没有 repeat/config provenance 字段。"
        "详见 `misplaced_compute_profile_summary.csv`。\n"
    )
    lines.append(
        "network 采样域也存在明显漂移：A100 pairwise all-reduce 有 2,247 个 size 点并延伸到 536,373,250 bytes（约 511.5 MiB），"
        "其余标准文件通常只有 993 个点、上限 64 MiB；H100 DGX all-reduce 只有节点内 w2/w4/w8，A40 则完全没有 all-reduce。"
        "所有标准 collective CSV 还都带一个多余的 `Unnamed: 0` index 列。\n"
    )
    anomalies = pd.DataFrame(network_details.get("anomalies", []))
    if not anomalies.empty:
        severity_order = pd.Categorical(anomalies["severity"], ["high", "medium", "low"], ordered=True)
        anomalies = anomalies.assign(_order=severity_order).sort_values(["_order", "source_path", "kind"]).drop(columns="_order")
        lines.append(markdown_table(anomalies, ["severity", "source_path", "kind", "detail"], ["级别", "路径", "类型", "说明"]))
    else:
        lines.append("未检出异常。")
    lines.append("")

    lines.append("## 6. 对论文结论和模拟器可用性的影响\n")
    lines.append("1. **Workload 资产不能直接复现论文三 trace 结果。** 当前 processed 目录只有 Arxiv 与两条 Splitwise trace；缺 Chat-1M、BWB-4K 的论文版 processed trace。代码 README 的 Splitwise 示例是仓库后续能力，不应与论文 Table 1 混写。")
    lines.append(
        "2. **4096 域覆盖要按请求类型分别审计。** 超过 4096 的请求若仍使用默认 predictor max，会进入未经默认 attention profile 支撑的 KV/context 区域；"
        "扩大 CLI 上限并不会自动产生实测数据。当前 `trace_request_length_generator.py` 会把超限 prefill/decode 按比例缩短，"
        "而 `trace_replay_request_generator.py` 只从 prefill 扣除超额；所以原始 OOD 比例可能在运行时下降，但这是改变 workload，不能当作 profiling 覆盖已经解决。"
    )
    lines.append(
        "3. **Network profile 是 topology-specific 的，而且有资产未被当前 loader 使用。** 同一 GPU 名称下 world size、devices_per_node 和跨节点组合不同，不能仅按 `device` 合并。"
        "当前 `sklearn_execution_time_predictor.py::_load_all_reduce_df` 要求 `num_workers==TP` 且 `devices_per_node==TP`，"
        "因此 A100 DGX 的 w4/dpn2、w8/dpn4、w16/dpn8 等跨节点 all-reduce 行不会进入该 predictor；send/recv 则按是否多节点固定选 dpn=1/2。"
        "缺失组合应拒绝或显式回退，不应默默借用另一拓扑。"
    )
    lines.append("4. **仅 rank 0 + 三次 active 重复不足以建尾部模型。** 对 median 插值尚可，但无法验证慢 rank、collective barrier skew 或 P95/P99；SLO 仿真应增加全 rank 记录和更多重复。")
    lines.append("5. **非单调和跳变必须保留。** 不宜用单一线性带宽模型平滑掉阈值；RF/查表应按 world size、topology 分域，并在候选阈值两侧补采样。")
    lines.append("6. **字节级复制和错放文件必须先治理。** H100 pairwise send/recv 在重新实测前应标为 provenance 不明；A40 attention 应移出 network 资产清单；A40 all-reduce 缺失应阻断相应配置搜索。\n")

    lines.append("## 7. 建议的最小治理动作\n")
    lines.append("- 给每个 CSV 增加 manifest：GPU SKU/PCIe 或 NVLink 形态、节点数、driver/CUDA/NCCL/PyTorch commit、采样日期、profile 命令、hash。")
    lines.append("- network CSV 去除多余 index 列，按 `(collective, world_size, devices_per_node, size, rank, repeat_id)` 保存原始重复，而不只保存 rank0 汇总。")
    lines.append("- 对所有阈值候选点在两侧补采至少 20–30 次，并随机化 size 顺序；报告 median、MAD、P95 与置信区间。")
    lines.append("- 模拟器启动时校验请求/消息是否处在真实 profile envelope，未知 topology/world size/compiler 组合直接报 OOD。")
    lines.append("- 将论文 trace、当前 Splitwise trace、演示 trace 分目录并附 provenance，避免把后续仓库资产误当论文复现实验输入。\n")

    lines.append("## 8. 产物说明\n")
    lines.append("- `file_inventory.csv`：全文件 schema、hash、缺失与重复审计。")
    lines.append("- `workload_summary.csv`、`workload_quantiles.csv`、`workload_correlations.csv`、`workload_coverage.csv`、`workload_quality.csv`：workload 统计。")
    lines.append("- `network_rows_enriched.csv`：标准 network 行，附 payload 带宽与抖动指标。")
    lines.append("- `network_file_quality.csv`、`network_group_summary.csv`、`network_transitions.csv`、`network_threshold_candidates.csv`、`network_duplicate_keys.csv`、`network_anomalies.csv`：network 审计。")
    lines.append("- `misplaced_compute_profile_summary.csv`：误放在 network 目录的 A40 attention 文件，按 prefill/decode 汇总其缺失、重复和 shape 范围。")
    lines.append("- `analysis_summary.json`：机器可读摘要和 top-length 细节。")
    return "\n".join(lines) + "\n"


def write_csv(frame: pd.DataFrame, name: str) -> None:
    frame.to_csv(OUTPUT_ROOT / name, index=False, encoding="utf-8-sig")


def main() -> None:
    OUTPUT_ROOT.mkdir(parents=True, exist_ok=True)
    workload_paths = sorted(WORKLOAD_ROOT.rglob("*.csv"))
    network_paths = sorted(NETWORK_ROOT.rglob("*.csv"))
    if not workload_paths or not network_paths:
        raise RuntimeError("Expected workload and network CSV files were not found")

    inventory_rows: list[dict[str, Any]] = []
    workload_frames: dict[Path, pd.DataFrame] = {}
    network_frames: dict[Path, pd.DataFrame] = {}
    for path in workload_paths:
        audit, frame = audit_file(path, "workload")
        inventory_rows.append(audit)
        workload_frames[path] = frame
    for path in network_paths:
        audit, frame = audit_file(path, "network")
        inventory_rows.append(audit)
        network_frames[path] = frame
    inventory = pd.DataFrame(inventory_rows).sort_values(["category", "path"]).reset_index(drop=True)

    (
        workload_summary,
        workload_quantiles,
        workload_coverage,
        workload_quality,
        workload_correlations,
        workload_details,
    ) = analyze_workloads(workload_frames)
    (
        network_rows,
        network_file_quality,
        network_group_summary,
        network_transitions,
        network_thresholds,
        network_duplicate_keys,
        misplaced_compute_profile_summary,
        network_details,
    ) = analyze_network(network_frames)
    network_anomalies = pd.DataFrame(network_details.get("anomalies", []))

    write_csv(inventory, "file_inventory.csv")
    write_csv(workload_summary, "workload_summary.csv")
    write_csv(workload_quantiles, "workload_quantiles.csv")
    write_csv(workload_coverage, "workload_coverage.csv")
    write_csv(workload_quality, "workload_quality.csv")
    write_csv(workload_correlations, "workload_correlations.csv")
    write_csv(network_rows, "network_rows_enriched.csv")
    write_csv(network_file_quality, "network_file_quality.csv")
    write_csv(network_group_summary, "network_group_summary.csv")
    write_csv(network_transitions, "network_transitions.csv")
    write_csv(network_thresholds, "network_threshold_candidates.csv")
    write_csv(network_duplicate_keys, "network_duplicate_keys.csv")
    write_csv(misplaced_compute_profile_summary, "misplaced_compute_profile_summary.csv")
    write_csv(network_anomalies, "network_anomalies.csv")

    summary = {
        "source_root": str(SOURCE_ROOT),
        "workload_files": len(workload_paths),
        "network_directory_files": len(network_paths),
        "inventory": inventory.to_dict(orient="records"),
        "workload_summary": workload_summary.to_dict(orient="records"),
        "workload_coverage": workload_coverage.to_dict(orient="records"),
        "workload_details": workload_details,
        "network_file_quality": network_file_quality.to_dict(orient="records"),
        "network_group_summary": network_group_summary.to_dict(orient="records"),
        "network_threshold_candidate_count": len(network_thresholds),
        "misplaced_compute_profile_summary": misplaced_compute_profile_summary.to_dict(orient="records"),
        "network_details": network_details,
    }
    (OUTPUT_ROOT / "analysis_summary.json").write_text(
        json.dumps(json_safe(summary), ensure_ascii=False, indent=2), encoding="utf-8"
    )

    report = generate_report(
        inventory,
        workload_summary,
        workload_quality,
        workload_coverage,
        workload_correlations,
        network_file_quality,
        network_group_summary,
        network_thresholds,
        network_details,
    )
    (OUTPUT_ROOT / "NETWORK_WORKLOAD_ANALYSIS.md").write_text(report, encoding="utf-8")

    manifest = {
        "generated_files": sorted(path.name for path in OUTPUT_ROOT.iterdir() if path.is_file()),
        "source_files_sha256": dict(zip(inventory["path"], inventory["sha256"])),
    }
    (OUTPUT_ROOT / "output_manifest.json").write_text(
        json.dumps(json_safe(manifest), ensure_ascii=False, indent=2), encoding="utf-8"
    )


if __name__ == "__main__":
    main()

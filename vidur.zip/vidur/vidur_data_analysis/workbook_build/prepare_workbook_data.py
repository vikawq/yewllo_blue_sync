from __future__ import annotations

import csv
import json
from pathlib import Path


ROOT = Path(r"D:\workspaces\trace\vidur_data_analysis")
OUT = ROOT / "workbook_build" / "workbook_data.json"


def read_csv(path: Path) -> list[dict[str, str]]:
    with path.open("r", encoding="utf-8-sig", newline="") as handle:
        return list(csv.DictReader(handle))


def n(value: str | None, default=None):
    if value is None or value == "":
        return default
    try:
        if any(token in value.lower() for token in (".", "e")):
            return float(value)
        return int(value)
    except (TypeError, ValueError):
        return value


def pct(value: str | None, default=None):
    value = n(value, default)
    return value if value is None or isinstance(value, str) else value * 100.0


def table(headers, rows):
    return {"headers": headers, "rows": rows}


inventory = read_csv(ROOT / "main" / "file_inventory.csv")
workloads = read_csv(ROOT / "main" / "workload_summary.csv")
coverage = read_csv(ROOT / "contract_agent" / "compute_coverage_matrix.csv")
findings = read_csv(ROOT / "contract_agent" / "findings.csv")
compute_assets = read_csv(
    ROOT / "compute_agent" / "artifacts" / "compact_asset_summary.csv"
)
jitter = read_csv(
    ROOT / "compute_agent" / "artifacts" / "compact_within_row_jitter.csv"
)
monotonicity = read_csv(
    ROOT / "compute_agent" / "artifacts" / "compact_monotonicity.csv"
)
cross_gpu = read_csv(
    ROOT / "compute_agent" / "artifacts" / "compact_cross_gpu_speedup.csv"
)
tp_scaling = read_csv(
    ROOT / "compute_agent" / "artifacts" / "compact_tp_compute_scaling.csv"
)
network_groups = read_csv(
    ROOT / "network_workload_agent" / "network_group_summary.csv"
)
network_candidates = read_csv(
    ROOT / "network_workload_agent" / "network_threshold_candidates.csv"
)

network_candidates.sort(
    key=lambda row: abs(float(row["latency_rel_change"])), reverse=True
)

SEVERITY_ZH = {"high": "高", "medium": "中", "info": "信息"}
FINDINGS_ZH = {
    "DC-001": (
        "网络路径",
        "a40_pairwise_nvlink 有 send_recv.csv 和 136,750 行 attention.csv，却没有 all_reduce.csv；当前代码和路径模板都不会消费 network/attention.csv。",
        "A40 TP>1 会在打开文件时失败；136,750 行、约 32.6 MB 数据在 current main 中成为孤立资产。",
    ),
    "DC-002": (
        "CPU开销",
        "仓库没有任何 cpu_overheads.csv，且 skip_cpu_overhead_modeling 默认开启。",
        "默认仿真把 schedule/sampler/input/output/Ray 开销置零；使用默认路径启用该功能会失败。",
    ),
    "DC-003": (
        "Compute覆盖",
        "27 个具体 model-device 组合中 7 个没有 compute 文件；A100 Llama-3-8B 的 MLP 有 TP1/2/4/8，但 attention 只有 TP1/4。",
        "真正可用的 model/device/TP 组合比配置注册表更窄；不支持的选择要到加载/过滤后才暴露。",
    ),
    "DC-004": (
        "多节点AllReduce",
        "All-reduce 过滤强制 num_workers==TP 且 devices_per_node==TP，使 A100 DGX 中 (2,1)/(4,2)/(8,4)/(16,8) 的 3,976 行不可达，TP16 为空。",
        "已发布的跨节点 all-reduce 数据不能被选中，当前 loader 无法表示跨节点张量并行。",
    ),
    "DC-005": (
        "预测缓存",
        "Prediction lookup 的 hash 使用 estimator 字符串，却不包含训练 dataframe 或树状态；to_dict 还漏掉 attention_input_file 和部分预测粒度设置。",
        "同路径 CSV 内容或 attention 文件变化后，只要最佳超参相同，就可能静默复用旧 lookup。",
    ),
    "DC-006": (
        "预测域",
        "Lookup 只按配置范围生成，运行时直接查字典且不验证训练支撑域。旧 attention KV 到 4032，默认 lookup 含 4096；Orca 还把旧 MLP 4K 数据用于 4096×128 token。",
        "随机森林在训练域外静默饱和；超过预计算范围则 KeyError，没有 profiling/fallback。",
    ),
    "DC-007": (
        "重复聚合",
        "Loader 只删除整行完全重复，不聚合相同 contract key；exact dedup 后仍有 166 个额外 MLP 行和 25,812 个额外 attention 行共享模型特征。",
        "采样段边界被额外加权；不同 median 的重复测量被当作独立样本，而非一个稳健 shape 估计。",
    ),
    "DC-008": (
        "数据质量",
        "A100 Qwen-72B TP1 attention 有 16 个 active decode 行 median=0、max>0，当前没有 target 校验或清洗。",
        "不合理的零时延污染 decode 模型；自定义 MAPE 会把任何非零预测记为恰好 100% 误差。",
    ),
    "DC-009": (
        "Schema兼容",
        "18 个论文时期 attention 文件缺 attn_kv_cache_save.median 并被静默补 0；3 个 Phi-2 MLP 文件缺 post_attention_layernorm.median。",
        "缺测与实测为零无法区分；Phi-2 因 post_attn_norm=false 语义安全，KV-save 为兼容性假设。",
    ),
    "DC-010": (
        "隐含制度",
        "attention_backend、max_model_len 和 is_prefill 不是过滤/建模特征；旧数据用 FlashAttention，Llama-3 用 FlashInfer。",
        "未来若一个 CSV 混入多个 backend 或编译制度，会静默训练成单一混合模型。",
    ),
    "DC-011": (
        "设备拓扑一致性",
        "ReplicaConfig 独立构造 device 与 network_device，不检查 node SKU 的设备类型是否与 compute device 一致。",
        "用户可把 A100 compute CSV 与 H100 network CSV 静默组合，语法有效但物理不一致。",
    ),
    "DC-012": (
        "Trace默认值",
        "默认 trace-length/trace-interval 路径不存在；三条现有 trace 都没有 interval loader 的 arrival_time，只有 splitwise_code/conv 符合 replay 的 arrived_at。",
        "这些 generator 无法用仓库现有数据开箱复现，schema 错误到运行时才出现。",
    ),
    "DC-013": (
        "Trace变换",
        "Replay 把全部超额 token 只从 prefill 扣除，未重新断言 prefill>0 或排序 arrival；默认 4096 下会改写 code 1,257 行、conv 1,612 行。",
        "放大 decode 时可能产生非正 prefill 但仍通过 total-token 断言；长 prompt 分布被实质改变。",
    ),
    "DC-014": (
        "未使用字段",
        "只学习 *.median；MLP embedding、attention input/output reshape、min/max/mean/std 和 backend 等元数据都不被消费。",
        "CSV 内的不确定性和分量信息不能影响预测，遗漏的 reshape/embedding 也不会自动在别处补回。",
    ),
    "DC-015": (
        "通信单位",
        "Network size 按 size/(embedding_dim×2) 转为 token，硬编码每 hidden element 两字节；all-reduce 在学习 median 后再加固定 NCCL launch。",
        "FP8/FP32 或压缩通信不能直接复用同一契约；dtype 不在 CSV 过滤条件中。",
    ),
    "DC-016": (
        "数据完整性",
        "40 个 compute 文件都匹配目录模型的维度，均为 block_size=16，active prefill/decode target 无空值；唯一 active zero-target 异常是 A100 Qwen 的 16 行。",
        "已存在且受支持的切片结构一致，多数故障来自覆盖/选择，而不是广泛 schema 损坏。",
    ),
}

payload = {
    "metadata": {
        "repository": "microsoft/vidur",
        "commit": "8383d2935bc62723a212090baa9f98ada206fc14",
        "audit_date": "2026-08-13",
        "source_root": r"D:\workspaces\trace\vidur_repro\vidur\data",
        "report": r"D:\workspaces\trace\vidur_data_analysis\VIDUR_REPOSITORY_DATA_ANALYSIS.md",
    },
    "assets": table(
        [
            "相对路径",
            "类别",
            "设备",
            "模型",
            "类型",
            "行数",
            "列数",
            "大小(MB)",
            "完整重复行",
            "空值率",
            "含Unnamed索引",
        ],
        [
            [
                row["path"],
                row["category"],
                row["device"] or None,
                row["model"] or None,
                row["kind"],
                n(row["rows"]),
                n(row["columns"]),
                round(float(row["bytes"]) / 1_000_000, 4),
                n(row["exact_duplicate_rows"]),
                float(row["null_cell_rate"]),
                bool(row["unnamed_index_columns"]),
            ]
            for row in inventory
        ],
    ),
    "workloads": table(
        [
            "Trace",
            "请求数",
            "唯一长度对",
            "Prefill P50",
            "Prefill P90",
            "Prefill P99",
            "Prefill Max",
            "Decode P50",
            "Decode P90",
            "Decode P99",
            "Decode Max",
            "Total P50",
            "Total P90",
            "Total P99",
            "Total Max",
            ">4K比例(%)",
            "平均QPS",
            "到达间隔P50(ms)",
        ],
        [
            [
                row["file"].replace("_stats_llama2_tokenizer_filtered_v2.csv", "").replace(".csv", ""),
                n(row["rows"]),
                n(row["unique_prefill_decode_pairs"]),
                n(row["prefill_p50"]),
                n(row["prefill_p90"]),
                n(row["prefill_p99"]),
                n(row["prefill_max"]),
                n(row["decode_p50"]),
                n(row["decode_p90"]),
                n(row["decode_p99"]),
                n(row["decode_max"]),
                n(row["total_p50"]),
                n(row["total_p90"]),
                n(row["total_p99"]),
                n(row["total_max"]),
                round(pct(row["total_gt_4096_rate"], 0), 4),
                n(row["arrival_rate_qps"]),
                None if not row["interarrival_p50"] else float(row["interarrival_p50"]) * 1000,
            ]
            for row in workloads
        ],
    ),
    "compute_coverage": table(
        [
            "设备",
            "模型",
            "MLP存在",
            "Attention存在",
            "可用TP",
            "MLP最大Token",
            "Attention最大Batch",
            "Prefill最大值",
            "KV最大值",
            "Block sizes",
            "Backends",
            "默认4K MLP覆盖",
            "默认Batch128覆盖",
            "默认Prefill4K覆盖",
            "默认KV4096实测",
        ],
        [
            [
                row["device"],
                row["model"],
                row["mlp_exists"].lower() == "true",
                row["attention_exists"].lower() == "true",
                row["usable_compute_tp"],
                n(row["mlp_num_tokens_max"]),
                n(row["attention_batch_max"]),
                n(row["attention_prefill_max"]),
                n(row["attention_kv_max"]),
                row["attention_block_sizes"],
                row["attention_backends"],
                row["default_mlp_4096_covered"].lower() == "true",
                row["default_decode_batch_128_covered"].lower() == "true",
                row["default_prefill_4096_covered"].lower() == "true",
                row["default_decode_kv_4096_observed"].lower() == "true",
            ]
            for row in coverage
        ],
    ),
    "compute_assets": table(
        ["GPU", "类型", "文件", "模型", "行数", "唯一Shape", "重复Shape组", "完整重复行"],
        [
            [
                row["gpu"].upper(),
                row["kind"],
                n(row["files"]),
                n(row["models"]),
                n(row["rows"]),
                n(row["unique_shapes"]),
                n(row["repeated_shape_groups"]),
                n(row["exact_duplicate_rows_removable"]),
            ]
            for row in compute_assets
        ],
    ),
    "jitter": table(
        ["GPU", "Operator", "模型数", "行数", "CV P50(%)", "CV P95(%)", "单文件CV P95最大(%)", "Range P95(%)"],
        [
            [
                row["gpu"].upper(),
                row["operator"],
                n(row["models"]),
                n(row["rows"]),
                n(row["file_cv_p50_median"]),
                n(row["file_cv_p95_median"]),
                n(row["file_cv_p95_max"]),
                n(row["file_range_p95_median"]),
            ]
            for row in jitter
        ],
    ),
    "monotonicity": table(
        [
            "GPU",
            "类型",
            "Phase",
            "Operator",
            "比较轴",
            "文件数",
            "相邻点数",
            "下降>5%(%)",
            "上升>5%(%)",
            "最大下降(%)",
            "最大上升(%)",
        ],
        [
            [
                row["gpu"].upper(),
                row["kind"],
                row["phase"],
                row["operator"],
                row["axis"],
                n(row["files"]),
                n(row["adjacent_pairs"]),
                round(pct(row["decrease_gt_5pct_fraction"]), 4),
                round(pct(row["increase_gt_5pct_fraction"]), 4),
                n(row["largest_decrease_pct"]),
                n(row["largest_increase_pct"]),
            ]
            for row in monotonicity
        ],
    ),
    "cross_gpu": table(
        [
            "From",
            "To",
            "类型",
            "Operator",
            "模型数",
            "TP cells",
            "共同Shape",
            "Speedup中位",
            "Speedup最小",
            "Speedup最大",
            "目标GPU更慢(%)",
        ],
        [
            [
                row["from_gpu"].upper(),
                row["to_gpu"].upper(),
                row["kind"],
                row["operator"],
                n(row["models"]),
                n(row["tp_cells"]),
                n(row["common_shapes_sum"]),
                n(row["cell_speedup_p50_median"]),
                n(row["cell_speedup_p50_min"]),
                n(row["cell_speedup_p50_max"]),
                round(pct(row["weighted_fraction_to_gpu_slower"]), 4),
            ]
            for row in cross_gpu
        ],
    ),
    "tp_scaling": table(
        [
            "GPU",
            "类型",
            "Operator",
            "TP",
            "模型数",
            "共同Shape",
            "Compute Speedup中位",
            "最小",
            "最大",
            "并行效率中位(%)",
            "慢于TP1(%)",
        ],
        [
            [
                row["gpu"].upper(),
                row["kind"],
                row["operator"],
                n(row["tp"]),
                n(row["models"]),
                n(row["common_shapes_sum"]),
                n(row["cell_compute_speedup_p50_median"]),
                n(row["cell_compute_speedup_p50_min"]),
                n(row["cell_compute_speedup_p50_max"]),
                round(pct(row["cell_parallel_efficiency_p50_median"]), 4),
                round(pct(row["weighted_fraction_slower_than_tp1"]), 4),
            ]
            for row in tp_scaling
        ],
    ),
    "network_groups": table(
        [
            "设备",
            "拓扑目录",
            "Collective",
            "Workers",
            "Devices/Node",
            "行数",
            "唯一Size",
            "最小Size(KiB)",
            "最大Size(MiB)",
            "最小Size时延(ms)",
            "最大Size时延(ms)",
            "小消息中位时延(ms)",
            "Payload BW P50(GB/s)",
            "Payload BW P95(GB/s)",
            "CV P95(%)",
            "高抖动点(%)",
            "非单调下降数",
            "候选跳变数",
        ],
        [
            [
                row["device"].upper(),
                row["topology_directory"],
                row["collective"],
                n(row["num_workers"]),
                n(row["devices_per_node"]),
                n(row["rows_raw"]),
                n(row["unique_sizes"]),
                round(float(row["size_min_bytes"]) / 1024, 3),
                round(float(row["size_max_bytes"]) / 1024 / 1024, 3),
                n(row["latency_at_min_size_ms"]),
                n(row["latency_at_max_size_ms"]),
                n(row["small_message_latency_median_ms_le_64KiB"]),
                n(row["payload_bw_median_GBps"]),
                n(row["payload_bw_p95_GBps"]),
                round(pct(row["within_point_cv_p95"]), 4),
                round(pct(row["high_cv_share_gt_20pct"]), 4),
                n(row["nonmonotonic_drop_count"]),
                n(row["candidate_jump_count"]),
            ]
            for row in network_groups
        ],
    ),
    "network_candidates": table(
        [
            "设备",
            "拓扑",
            "Collective",
            "Workers",
            "Devices/Node",
            "前Size(KiB)",
            "当前Size(KiB)",
            "前时延(ms)",
            "当前时延(ms)",
            "时延变化(%)",
            "绝对变化(ms)",
            "合成Std(ms)",
            "BW变化(%)",
            "候选类型",
        ],
        [
            [
                row["device"].upper(),
                row["topology_directory"],
                row["collective"],
                n(row["num_workers"]),
                n(row["devices_per_node"]),
                round(float(row["prev_size_bytes"]) / 1024, 3),
                round(float(row["size_bytes"]) / 1024, 3),
                n(row["prev_latency_ms"]),
                n(row["latency_ms"]),
                round(pct(row["latency_rel_change"]), 4),
                n(row["latency_abs_change_ms"]),
                n(row["combined_adjacent_std_ms"]),
                round(pct(row["bw_rel_change"]), 4),
                row["transition_kind"],
            ]
            for row in network_candidates
        ],
    ),
    "findings": table(
        ["编号", "严重度", "领域", "发现", "证据", "影响"],
        [
            [
                row["id"],
                SEVERITY_ZH[row["severity"]],
                FINDINGS_ZH[row["id"]][0],
                FINDINGS_ZH[row["id"]][1],
                row["evidence"],
                FINDINGS_ZH[row["id"]][2],
            ]
            for row in findings
        ],
    ),
    "notes": [
        ["版本边界", "本工作簿审计 current-main commit 8383d29，不等同于 MLSys'24 提交时数据快照。"],
        ["论文复现", "current main 缺 Chat-1M、BWB、默认 ShareGPT/Azure interval 文件；现有三条 trace 不能完整复现论文 workload。"],
        ["Compute比较", "跨GPU只保留同 model/TP/backend/operator/精确shape；TP结果为compute-only。"],
        ["Network带宽", "工作簿中的BW是payload-equivalent GB/s，不是NCCL busbw或厂商峰值。"],
        ["跳变候选", "284个network候选满足绝对变化、相对变化和3×观测噪声阈值；需带协议/kernel信息复测后才能归因。"],
        ["空值语义", "大量空单元格来自旧attention对非当前phase的结构性留空，不应全部视为测量失败。"],
        ["Learner", "当前模型主要使用median；min/max/mean/std没有作为标签不确定性或样本权重。"],
        ["外推", "旧attention KV最大4032而默认lookup含4096；旧MLP 4K数据在Orca下可静默外推到524K。"],
        ["NPU建议", "采用regime分类+regime内回归/查表+OOD拒绝；显式记录compiler/kernel/tiling/cache/搬运路径。"],
        ["完整报告", r"D:\workspaces\trace\vidur_data_analysis\VIDUR_REPOSITORY_DATA_ANALYSIS.md"],
    ],
}

OUT.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
print(f"wrote {OUT} ({OUT.stat().st_size} bytes)")

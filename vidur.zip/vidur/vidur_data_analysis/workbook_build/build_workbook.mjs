import fs from "node:fs/promises";
import path from "node:path";
import {
  FileBlob,
  SpreadsheetFile,
  Workbook,
} from "@oai/artifact-tool";


const BUILD_DIR = "D:/workspaces/trace/vidur_data_analysis/workbook_build";
const OUTPUT_DIR = "D:/workspaces/trace/outputs/019ff8f1-64d3-7a30-bcd9-a6eda1323b99";
const OUTPUT_PATH = `${OUTPUT_DIR}/vidur_data_analysis.xlsx`;
const PREVIEW_DIR = `${OUTPUT_DIR}/vidur_data_analysis_previews`;
const data = JSON.parse(await fs.readFile(`${BUILD_DIR}/workbook_data.json`, "utf8"));

const COLORS = {
  navy: "#17324D",
  teal: "#167C80",
  tealDark: "#0F5E63",
  lightTeal: "#E6F4F1",
  paleBlue: "#EAF1F8",
  orange: "#D97706",
  paleOrange: "#FFF4E5",
  red: "#B42318",
  paleRed: "#FEECEB",
  green: "#207A4A",
  paleGreen: "#EAF6EE",
  ink: "#1F2937",
  muted: "#5F6B7A",
  grid: "#D9E2EC",
  white: "#FFFFFF",
};

function colName(index1) {
  let n = index1;
  let out = "";
  while (n > 0) {
    n -= 1;
    out = String.fromCharCode(65 + (n % 26)) + out;
    n = Math.floor(n / 26);
  }
  return out;
}

function setColumnWidths(sheet, widths, endRow) {
  widths.forEach((width, idx) => {
    sheet.getRange(`${colName(idx + 1)}1:${colName(idx + 1)}${endRow}`).format.columnWidth = width;
  });
}

function baseSheet(sheet, title, subtitle, lastCol) {
  sheet.showGridLines = false;
  sheet.mergeCells(`A1:${lastCol}1`);
  sheet.mergeCells(`A2:${lastCol}2`);
  sheet.getRange("A1").values = [[title]];
  sheet.getRange("A2").values = [[subtitle]];
  sheet.getRange(`A1:${lastCol}1`).format = {
    fill: COLORS.navy,
    font: { bold: true, color: COLORS.white, size: 18 },
    verticalAlignment: "center",
  };
  sheet.getRange(`A2:${lastCol}2`).format = {
    fill: COLORS.paleBlue,
    font: { color: COLORS.muted, italic: true, size: 10 },
    verticalAlignment: "center",
    wrapText: true,
  };
  sheet.getRange("A1").format.rowHeight = 30;
  sheet.getRange("A2").format.rowHeight = 28;
}

function addDataSheet(workbook, cfg) {
  const sheet = workbook.worksheets.add(cfg.name);
  const headers = cfg.data.headers;
  const rows = cfg.data.rows;
  const lastCol = colName(headers.length);
  const endRow = 4 + rows.length;
  baseSheet(sheet, cfg.title, cfg.subtitle, lastCol);
  sheet.getRange(`A4:${lastCol}4`).values = [headers];
  if (rows.length) {
    sheet.getRange(`A5:${lastCol}${endRow}`).values = rows;
  }
  sheet.getRange(`A4:${lastCol}4`).format = {
    fill: COLORS.teal,
    font: { bold: true, color: COLORS.white, size: 10 },
    horizontalAlignment: "center",
    verticalAlignment: "center",
    wrapText: true,
  };
  sheet.getRange(`A4:${lastCol}4`).format.rowHeight = 34;
  if (rows.length) {
    sheet.getRange(`A5:${lastCol}${endRow}`).format = {
      font: { color: COLORS.ink, size: 9 },
      verticalAlignment: "center",
    };
    const table = sheet.tables.add(`A4:${lastCol}${endRow}`, true, cfg.tableName);
    table.style = "TableStyleMedium2";
    table.showBandedColumns = false;
    table.showFilterButton = true;
  }
  sheet.freezePanes.freezeRows(4);
  setColumnWidths(sheet, cfg.widths, Math.max(endRow, 8));
  for (const spec of cfg.numberFormats || []) {
    sheet.getRange(`${colName(spec.col)}5:${colName(spec.col)}${endRow}`).format.numberFormat = spec.format;
  }
  if (cfg.wrapCols) {
    for (const col of cfg.wrapCols) {
      sheet.getRange(`${colName(col)}5:${colName(col)}${endRow}`).format.wrapText = true;
    }
  }
  if (cfg.rowHeight) {
    sheet.getRange(`A5:${lastCol}${endRow}`).format.rowHeight = cfg.rowHeight;
  }
  if (cfg.colorScaleCols) {
    for (const col of cfg.colorScaleCols) {
      sheet.getRange(`${colName(col)}5:${colName(col)}${endRow}`).conditionalFormats.add("colorScale", {
        criteria: [
          { type: "lowestValue", color: COLORS.paleGreen },
          { type: "percentile", value: 50, color: COLORS.paleOrange },
          { type: "highestValue", color: "#F3A6A1" },
        ],
      });
    }
  }
  return { sheet, endRow, lastCol };
}

const workbook = Workbook.create();
const overview = workbook.worksheets.add("概览");

const sheets = {};
sheets.assets = addDataSheet(workbook, {
  name: "文件清单",
  title: "全部 CSV 文件清单",
  subtitle: "53 个公开 CSV；大小按十进制 MB。空值率中包含旧 attention schema 的结构性留空。",
  data: data.assets,
  tableName: "AssetInventoryTable",
  widths: [52, 12, 10, 31, 13, 13, 9, 12, 13, 11, 14],
  numberFormats: [
    { col: 6, format: "#,##0" },
    { col: 8, format: "0.0000" },
    { col: 9, format: "#,##0" },
    { col: 10, format: "0.0000%" },
  ],
  wrapCols: [1, 4],
  rowHeight: 28,
});

sheets.workloads = addDataSheet(workbook, {
  name: "工作负载",
  title: "Workload 长度与到达分布",
  subtitle: "Arxiv 无 arrival timestamp；Splitwise code/conversation 含严格递增到达时间。>4K 比例按 total tokens 计算。",
  data: data.workloads,
  tableName: "WorkloadSummaryTable",
  widths: [31, 12, 14, 12, 12, 12, 12, 12, 12, 12, 12, 12, 12, 12, 12, 13, 12, 18],
  numberFormats: [
    { col: 2, format: "#,##0" },
    { col: 3, format: "#,##0" },
    { col: 16, format: "0.0000\"%\"" },
    { col: 17, format: "0.000" },
    { col: 18, format: "0.000" },
  ],
  colorScaleCols: [16],
});

sheets.coverage = addDataSheet(workbook, {
  name: "Compute覆盖",
  title: "模型 × 设备 × TP 可用性",
  subtitle: "可用 TP 取 MLP、attention 和 block-size=16 过滤后的交集；配置注册不代表数据可用。",
  data: data.compute_coverage,
  tableName: "ComputeCoverageTable",
  widths: [10, 34, 11, 15, 14, 15, 18, 15, 12, 14, 31, 16, 18, 18, 18],
  numberFormats: [
    { col: 6, format: "#,##0" },
    { col: 7, format: "#,##0" },
    { col: 8, format: "#,##0" },
    { col: 9, format: "#,##0" },
  ],
  wrapCols: [2, 5, 10, 11],
  rowHeight: 34,
});

sheets.computeAssets = addDataSheet(workbook, {
  name: "Compute资产",
  title: "Compute profiling 资产",
  subtitle: "40 个 compute CSV，共 1,217,254 行。唯一 shape 和重复 shape 按文件内 key 统计后汇总。",
  data: data.compute_assets,
  tableName: "ComputeAssetTable",
  widths: [10, 14, 10, 10, 15, 16, 17, 16],
  numberFormats: [
    { col: 5, format: "#,##0" },
    { col: 6, format: "#,##0" },
    { col: 7, format: "#,##0" },
    { col: 8, format: "#,##0" },
  ],
  colorScaleCols: [7, 8],
});

sheets.jitter = addDataSheet(workbook, {
  name: "测量抖动",
  title: "行内重复测量抖动",
  subtitle: "CV 为每行 active 重复测量的变异系数；数值已按百分比展示。小算子需同时看绝对 μs。",
  data: data.jitter,
  tableName: "JitterSummaryTable",
  widths: [10, 25, 11, 14, 13, 13, 20, 15],
  numberFormats: [
    { col: 4, format: "#,##0" },
    { col: 5, format: "0.000" },
    { col: 6, format: "0.000" },
    { col: 7, format: "0.000" },
    { col: 8, format: "0.000" },
  ],
  colorScaleCols: [6, 7],
});

sheets.monotonicity = addDataSheet(workbook, {
  name: "单调跳变",
  title: "相邻 shape 的非单调与跳变",
  subtitle: "先聚合同 shape，再沿单一轴比较相邻点。下降/上升不是自动异常；需结合绝对变化与观测噪声。",
  data: data.monotonicity,
  tableName: "MonotonicityTable",
  widths: [9, 12, 11, 27, 23, 10, 15, 15, 15, 15, 15],
  numberFormats: [
    { col: 7, format: "#,##0" },
    { col: 8, format: "0.000" },
    { col: 9, format: "0.000" },
    { col: 10, format: "0.000" },
    { col: 11, format: "0.000" },
  ],
  colorScaleCols: [8, 9, 11],
});

sheets.crossGpu = addDataSheet(workbook, {
  name: "跨GPU",
  title: "严格 shape 交集上的跨 GPU speedup",
  subtitle: "仅比较同 model、TP、backend、operator、精确 shape；为当前数据集经验比值，不是纯硬件峰值归因。",
  data: data.cross_gpu,
  tableName: "CrossGpuSpeedupTable",
  widths: [10, 10, 12, 27, 11, 12, 15, 16, 15, 15, 17],
  numberFormats: [
    { col: 7, format: "#,##0" },
    { col: 8, format: "0.000\"×\"" },
    { col: 9, format: "0.000\"×\"" },
    { col: 10, format: "0.000\"×\"" },
    { col: 11, format: "0.000" },
  ],
  colorScaleCols: [8, 11],
});

sheets.tp = addDataSheet(workbook, {
  name: "TP缩放",
  title: "Compute-only Tensor Parallel scaling",
  subtitle: "不含 collective、同步、CPU、pipeline bubble 与调度；不可直接解释为端到端 TP speedup。",
  data: data.tp_scaling,
  tableName: "TpScalingTable",
  widths: [9, 12, 27, 9, 11, 15, 20, 13, 13, 19, 14],
  numberFormats: [
    { col: 6, format: "#,##0" },
    { col: 7, format: "0.000\"×\"" },
    { col: 8, format: "0.000\"×\"" },
    { col: 9, format: "0.000\"×\"" },
    { col: 10, format: "0.000" },
    { col: 11, format: "0.000" },
  ],
  colorScaleCols: [7, 10],
});

sheets.network = addDataSheet(workbook, {
  name: "网络性能",
  title: "Network profiling 分组统计",
  subtitle: "带宽为 payload-equivalent GB/s，并非 NCCL busbw。当前标准 profile 只保留 rank 0、每点 3 次 active 测量。",
  data: data.network_groups,
  tableName: "NetworkGroupTable",
  widths: [9, 24, 15, 11, 15, 11, 13, 15, 15, 18, 18, 20, 20, 20, 13, 15, 15, 15],
  numberFormats: [
    { col: 6, format: "#,##0" },
    { col: 7, format: "#,##0" },
    { col: 8, format: "0.000" },
    { col: 9, format: "0.000" },
    { col: 10, format: "0.0000" },
    { col: 11, format: "0.0000" },
    { col: 12, format: "0.0000" },
    { col: 13, format: "0.000" },
    { col: 14, format: "0.000" },
    { col: 15, format: "0.000" },
    { col: 16, format: "0.000" },
  ],
  colorScaleCols: [14, 15, 16],
});

sheets.networkCandidates = addDataSheet(workbook, {
  name: "网络跳变",
  title: "Network change-point 候选（284 个）",
  subtitle: "满足 size/绝对变化/相对变化/3×观测噪声联合阈值；按绝对时延变化比例降序，仅用于指导复测。",
  data: data.network_candidates,
  tableName: "NetworkCandidateTable",
  widths: [9, 24, 15, 11, 15, 15, 15, 15, 15, 15, 16, 16, 14, 28],
  numberFormats: [
    { col: 6, format: "0.000" },
    { col: 7, format: "0.000" },
    { col: 8, format: "0.0000" },
    { col: 9, format: "0.0000" },
    { col: 10, format: "0.000" },
    { col: 11, format: "0.0000" },
    { col: 12, format: "0.0000" },
    { col: 13, format: "0.000" },
  ],
  colorScaleCols: [10, 11],
});

sheets.findings = addDataSheet(workbook, {
  name: "契约问题",
  title: "代码与数据契约问题清单",
  subtitle: "16 项发现来自路径解析、loader 过滤、lookup 生成、缓存与 trace 配置的联合审计。",
  data: data.findings,
  tableName: "DataContractFindingTable",
  widths: [11, 11, 19, 62, 58, 62],
  wrapCols: [3, 4, 5, 6],
  rowHeight: 72,
});

// Severity colors on the full finding rows.
sheets.findings.sheet.getRange(`A5:F${sheets.findings.endRow}`).conditionalFormats.addCustom(
  '=$B5="高"',
  { fill: COLORS.paleRed, font: { color: COLORS.red } },
);
sheets.findings.sheet.getRange(`A5:F${sheets.findings.endRow}`).conditionalFormats.addCustom(
  '=$B5="中"',
  { fill: COLORS.paleOrange, font: { color: "#8A4B08" } },
);

const notesSheet = workbook.worksheets.add("说明");
baseSheet(notesSheet, "口径、限制与来源", "本页解释数字的适用边界；详细推导见配套 Markdown 报告和三个分析目录。", "F");
notesSheet.getRange("A4:B4").values = [["主题", "说明"]];
notesSheet.getRange(`A5:B${4 + data.notes.length}`).values = data.notes;
notesSheet.getRange("A4:B4").format = {
  fill: COLORS.teal,
  font: { bold: true, color: COLORS.white },
  horizontalAlignment: "center",
};
notesSheet.getRange(`A5:B${4 + data.notes.length}`).format = {
  font: { color: COLORS.ink, size: 10 },
  wrapText: true,
  verticalAlignment: "center",
  rowHeight: 48,
};
notesSheet.getRange(`A4:B${4 + data.notes.length}`).format.borders = {
  top: { style: "continuous", color: COLORS.grid },
  bottom: { style: "continuous", color: COLORS.grid },
  left: { style: "continuous", color: COLORS.grid },
  right: { style: "continuous", color: COLORS.grid },
};
notesSheet.getRange(`A1:A${4 + data.notes.length}`).format.columnWidth = 20;
notesSheet.getRange(`B1:B${4 + data.notes.length}`).format.columnWidth = 110;
notesSheet.freezePanes.freezeRows(4);

// Build the overview only after every referenced sheet exists.
baseSheet(
  overview,
  "Vidur 公开数据审计总览",
  `microsoft/vidur @ ${data.metadata.commit.slice(0, 8)} · current-main 数据资产，不等同于论文提交时快照 · 审计日期 ${data.metadata.audit_date}`,
  "O",
);
overview.showGridLines = false;

const cards = [
  { range: "A4:C4", valueRange: "A5:C6", label: "CSV 文件", formula: "=COUNTA('文件清单'!A5:A57)", format: "#,##0" },
  { range: "D4:F4", valueRange: "D5:F6", label: "总行数", formula: "=SUM('文件清单'!F5:F57)", format: "#,##0" },
  { range: "G4:I4", valueRange: "G5:I6", label: "数据大小 (MB)", formula: "=SUM('文件清单'!H5:H57)", format: "#,##0.00" },
  { range: "J4:L4", valueRange: "J5:L6", label: "可删除完整重复行", formula: "=SUM('文件清单'!I5:I57)", format: "#,##0" },
  { range: "M4:O4", valueRange: "M5:O6", label: "高风险契约问题", formula: '=COUNTIF(\'契约问题\'!B5:B20,"高")', format: "#,##0" },
];
for (const card of cards) {
  overview.mergeCells(card.range);
  overview.mergeCells(card.valueRange);
  const labelCell = card.range.split(":")[0];
  const valueCell = card.valueRange.split(":")[0];
  overview.getRange(labelCell).values = [[card.label]];
  overview.getRange(valueCell).formulas = [[card.formula]];
  overview.getRange(card.range).format = {
    fill: COLORS.tealDark,
    font: { bold: true, color: COLORS.white, size: 10 },
    horizontalAlignment: "center",
    verticalAlignment: "center",
  };
  overview.getRange(card.valueRange).format = {
    fill: COLORS.lightTeal,
    font: { bold: true, color: COLORS.navy, size: 18 },
    horizontalAlignment: "center",
    verticalAlignment: "center",
    numberFormat: card.format,
  };
}
overview.getRange("A4:O6").format.rowHeight = 25;

// Formula-backed helper tables for charts.
overview.getRange("Q2:R2").values = [["Trace", "4K域内覆盖(%)"]];
overview.getRange("Q3:Q5").values = data.workloads.rows.map((row) => [row[0]]);
overview.getRange("R3:R5").formulas = [
  ["=100-'工作负载'!P5"],
  ["=100-'工作负载'!P6"],
  ["=100-'工作负载'!P7"],
];
overview.getRange("Q2:R5").format = {
  fill: COLORS.paleBlue,
  font: { color: COLORS.ink, size: 9 },
  numberFormat: "0.0",
};
overview.getRange("Q2:R2").format = {
  fill: COLORS.teal,
  font: { bold: true, color: COLORS.white, size: 9 },
};

const speedupOps = [
  ["Decode", "attn_decode"],
  ["Prefill", "attn_prefill"],
  ["MLP Up", "mlp_up_proj"],
  ["MLP Down", "mlp_down_proj"],
];
overview.getRange("Q8:S8").values = [["Operator", "A40→A100", "A100→H100"]];
overview.getRange("Q9:Q12").values = speedupOps.map((spec) => [spec[0]]);
overview.getRange("R9:S12").formulas = speedupOps.map((spec) => {
  const formulaFor = (fromGpu, toGpu) => {
    const idx = data.cross_gpu.rows.findIndex(
      (row) => row[0].toLowerCase() === fromGpu && row[1].toLowerCase() === toGpu && row[3] === spec[1],
    );
    if (idx < 0) throw new Error(`Missing cross-GPU helper row: ${fromGpu}/${toGpu}/${spec[1]}`);
    return `='跨GPU'!H${5 + idx}`;
  };
  return [formulaFor("a40", "a100"), formulaFor("a100", "h100")];
});
overview.getRange("Q8:S12").format = {
  fill: COLORS.paleBlue,
  font: { color: COLORS.ink, size: 9 },
  numberFormat: "0.000",
};
overview.getRange("Q8:S8").format = {
  fill: COLORS.teal,
  font: { bold: true, color: COLORS.white, size: 9 },
};

const coverageChart = overview.charts.add("bar", overview.getRange("Q2:R5"));
coverageChart.title = "默认 4K 预测域覆盖";
coverageChart.hasLegend = false;
coverageChart.xAxis = { axisType: "textAxis", textStyle: { fontSize: 9 } };
coverageChart.yAxis = { numberFormatCode: '0"%"', min: 0, max: 100 };
coverageChart.setPosition("A9", "G23");

const speedupChart = overview.charts.add("bar", overview.getRange("Q8:S12"));
speedupChart.title = "严格 shape 交集上的 GPU speedup";
speedupChart.hasLegend = true;
speedupChart.xAxis = { axisType: "textAxis", textStyle: { fontSize: 8 } };
speedupChart.yAxis = { numberFormatCode: '0.0"×"', min: 0 };
speedupChart.setPosition("I9", "O23");

overview.mergeCells("A25:O25");
overview.getRange("A25").values = [["关键判断"]];
overview.getRange("A25:O25").format = {
  fill: COLORS.navy,
  font: { bold: true, color: COLORS.white, size: 12 },
  horizontalAlignment: "left",
};
const takeaways = [
  ["可学习范围", "固定 device/model/TP/backend 与采样域内，可做分段插值；不应把叶节点常数当作可信 OOD 外推。"],
  ["数据主体", "40 个 compute CSV 占 86.7% 行数；网络路径下 136,750 行 attention 是误放 compute 数据。"],
  ["曲线性质", "多数点的 median 稳定，但存在量化平台、局部非单调和 >100% 跳变；应做 regime/boundary 感知建模。"],
  ["评估风险", "按行随机 CV 会把重复/邻近 shape 分到训练与验证；当前代码还记录训练集 score，不能代表 OOD 精度。"],
  ["NPU建议", "显式记录 compiler/kernel/tiling/cache/搬运路径，采用 regime 分类 + regime 内回归 + OOD 拒绝/补采。"],
];
overview.getRange("A26:C30").values = takeaways.map((row) => [row[0], null, null]);
overview.getRange("D26:O30").values = takeaways.map((row) => [row[1], ...Array(11).fill(null)]);
for (let r = 26; r <= 30; r++) {
  overview.mergeCells(`A${r}:C${r}`);
  overview.mergeCells(`D${r}:O${r}`);
}
overview.getRange("A26:C30").format = {
  fill: COLORS.lightTeal,
  font: { bold: true, color: COLORS.tealDark, size: 10 },
  verticalAlignment: "center",
};
overview.getRange("D26:O30").format = {
  fill: "#F8FAFC",
  font: { color: COLORS.ink, size: 10 },
  verticalAlignment: "center",
  wrapText: true,
};
overview.getRange("A26:O30").format.rowHeight = 34;

overview.getRange("A32:O34").values = [
  ["审计版本", data.metadata.commit, null, null, null, null, null, null, null, null, null, null, null, null, null],
  ["完整报告", data.metadata.report, null, null, null, null, null, null, null, null, null, null, null, null, null],
  ["重要限制", "current main 缺论文 Chat-1M/BWB workload；跨 GPU 比值无统一软件/采集 manifest，不能作纯硬件归因。", null, null, null, null, null, null, null, null, null, null, null, null, null],
];
for (let r = 32; r <= 34; r++) {
  overview.mergeCells(`B${r}:O${r}`);
}
overview.getRange("A32:A34").format = {
  fill: COLORS.paleOrange,
  font: { bold: true, color: "#8A4B08", size: 9 },
};
overview.getRange("B32:O34").format = {
  fill: "#FFFDF8",
  font: { color: COLORS.muted, size: 9 },
  wrapText: true,
};
overview.getRange("A32:O34").format.rowHeight = 28;
setColumnWidths(overview, [12, 12, 12, 12, 12, 12, 12, 2, 12, 12, 12, 12, 12, 12, 12, 3, 22, 16, 16], 40);
overview.freezePanes.freezeRows(2);

await fs.mkdir(OUTPUT_DIR, { recursive: true });
await fs.mkdir(PREVIEW_DIR, { recursive: true });

const preExportInspect = await workbook.inspect({
  kind: "workbook,sheet,table",
  maxChars: 12000,
  tableMaxRows: 3,
  tableMaxCols: 8,
  tableMaxCellChars: 90,
});
await fs.writeFile(`${BUILD_DIR}/inspect_pre_export.json`, JSON.stringify(preExportInspect, null, 2), "utf8");

const overviewInspect = await workbook.inspect({
  kind: "region,formula,drawing",
  sheetId: "概览",
  range: "A1:S34",
  maxChars: 16000,
  options: { maxResults: 150 },
});
await fs.writeFile(`${BUILD_DIR}/inspect_overview.json`, JSON.stringify(overviewInspect, null, 2), "utf8");

const xlsx = await SpreadsheetFile.exportXlsx(workbook);
await xlsx.save(OUTPUT_PATH);

// Re-import the exported artifact, inspect key ranges, and render every sheet.
const exportedBlob = await FileBlob.load(OUTPUT_PATH);
const verified = await SpreadsheetFile.importXlsx(exportedBlob);
const verifyInspect = await verified.inspect({
  kind: "workbook,sheet,table,formula,drawing",
  maxChars: 18000,
  tableMaxRows: 3,
  tableMaxCols: 8,
  tableMaxCellChars: 90,
  options: { maxResults: 200 },
});
const verifyText = JSON.stringify(verifyInspect, null, 2);
await fs.writeFile(`${BUILD_DIR}/inspect_post_export.json`, verifyText, "utf8");

const formulaErrorTokens = ["#REF!", "#DIV/0!", "#VALUE!", "#NAME?", "#NUM!", "#NULL!", "#N/A"];
const formulaErrors = formulaErrorTokens.filter((token) => verifyText.includes(token));
if (formulaErrors.length) {
  throw new Error(`Formula error tokens found after export: ${formulaErrors.join(", ")}`);
}

const sheetNames = [
  "概览",
  "文件清单",
  "工作负载",
  "Compute覆盖",
  "Compute资产",
  "测量抖动",
  "单调跳变",
  "跨GPU",
  "TP缩放",
  "网络性能",
  "网络跳变",
  "契约问题",
  "说明",
];
for (let i = 0; i < sheetNames.length; i += 1) {
  const sheetName = sheetNames[i];
  const preview = await verified.render({
    sheetName,
    autoCrop: "all",
    scale: sheetName === "概览" ? 1 : 0.72,
    format: "png",
  });
  const safe = sheetName.replace(/[^\p{L}\p{N}_-]+/gu, "_");
  const previewPath = path.join(PREVIEW_DIR, `${String(i + 1).padStart(2, "0")}_${safe}.png`);
  await fs.writeFile(previewPath, new Uint8Array(await preview.arrayBuffer()));
}

const result = {
  output: OUTPUT_PATH,
  bytes: (await fs.stat(OUTPUT_PATH)).size,
  previews: sheetNames.length,
  formulaErrors,
  sheets: sheetNames,
};
await fs.writeFile(`${BUILD_DIR}/build_result.json`, JSON.stringify(result, null, 2), "utf8");
console.log(JSON.stringify(result, null, 2));
process.exitCode = 0;

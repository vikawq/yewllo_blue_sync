from __future__ import annotations

import csv
import json
import re
from pathlib import Path


HERE = Path(r"D:\workspaces\trace\vidur_data_analysis\complete_report")
ROOT = HERE.parent
REPORT = HERE / "VIDUR_COMPLETE_DATA_REPORT.md"


def rows(path: Path):
    with path.open("r", encoding="utf-8-sig", newline="") as handle:
        return list(csv.DictReader(handle))


text = REPORT.read_text(encoding="utf-8")
inventory = rows(ROOT / "main" / "file_inventory.csv")
candidates = rows(ROOT / "network_workload_agent" / "network_threshold_candidates.csv")
coverage = rows(ROOT / "contract_agent" / "compute_coverage_matrix.csv")

checks = {}
checks["utf8_replacement_chars"] = text.count("\ufffd")
checks["code_fences_even"] = text.count("```") % 2 == 0
checks["characters"] = len(text)
checks["lines"] = len(text.splitlines())
checks["all_53_paths_present"] = all(row["path"] in text for row in inventory)
checks["all_27_model_device_pairs_present"] = all(
    row["device"].upper() in text and row["model"] in text for row in coverage
)
checks["network_candidate_source_count"] = len(candidates)
checks["report_declares_284_candidates"] = "全部 284 个 network change-point 候选" in text
checks["required_findings_present"] = all(f"DC-{i:03d}" in text for i in range(1, 17))
checks["required_file_ids_present"] = all(f"F{i:03d}" in text for i in range(1, 54))
checks["required_config_ids_present"] = all(f"C{i:03d}" in text for i in range(1, 28))
checks["required_topology_ids_present"] = all(f"N{i:03d}" in text for i in range(1, 6))
checks["required_trace_ids_present"] = all(f"T{i:03d}" in text for i in range(1, 4))

figure_refs = re.findall(r"!\[[^\]]*\]\(([^)]+)\)", text)
checks["figure_refs"] = figure_refs
checks["all_figures_exist"] = all((HERE / ref).exists() for ref in figure_refs if not re.match(r"^[a-z]+://", ref))

# Validate contiguous Markdown tables by pipe count. Wrapped prose is ignored.
bad_table_rows = []
current_expected = None
for line_no, line in enumerate(text.splitlines(), start=1):
    if line.startswith("|") and line.endswith("|"):
        count = len(re.findall(r"(?<!\\)\|", line))
        if current_expected is None:
            current_expected = count
        elif count != current_expected:
            bad_table_rows.append({"line": line_no, "expected_pipes": current_expected, "actual_pipes": count})
    else:
        current_expected = None
checks["bad_markdown_table_rows"] = bad_table_rows

checks["no_nan_literals"] = not bool(re.search(r"\|\s*(?:nan|None)\s*\|", text, flags=re.I))
checks["minimum_size_met"] = len(text) > 200_000 and len(text.splitlines()) > 2_000

failures = {
    key: value
    for key, value in checks.items()
    if (
        (isinstance(value, bool) and not value)
        or key == "utf8_replacement_chars" and value != 0
        or key == "bad_markdown_table_rows" and value
        or key == "network_candidate_source_count" and value != 284
    )
}

result = {"report": str(REPORT), "checks": checks, "failures": failures, "ok": not failures}
(HERE / "qa_summary.json").write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding="utf-8")
print(json.dumps(result, ensure_ascii=False, indent=2))
raise SystemExit(0 if not failures else 1)

# Vidur 仓库公开数据：完整审计、建模边界与 NPU 迁移报告

> 报告版本：2026-08-15 扩展版  
> 数据快照：`microsoft/vidur` current main，commit `8383d2935bc62723a212090baa9f98ada206fc14`  
> 覆盖：53 个 CSV、1,436,810 行、275,312,735 bytes；代码读取链、可达性、学习器、lookup 与缓存  
> 定位：这是一份“研究报告 + 数据字典 + 证据索引”，不是把 CSV 原样拼接，也不把 current-main 冒充论文提交时数据。

## 如何阅读这份报告

- **想快速做决策**：阅读第 1–3 章和“对昇腾 NPU 的落地建议”。
- **想判断数据是否可学习**：阅读 compute 的网格、噪声、局部跳变、评估切分和 OOD 章节。
- **想复现/改 Vidur**：阅读数据契约、loader/feature/lookup/cache 数据流，以及 16 项问题清单。
- **想逐个核对 CSV**：跳到附录 A–H；53 个文件和 284 个 network change-point 候选均可检索。

## 一页答案

1. 仓库数据的主体是 operator/collective 微基准，不是端到端请求观测。
2. 在固定 device/model/TP/backend/软件制度且位于采样域内时，shape→median latency 是**分段可学习**的。
3. 数据并非全局平滑：量化平台、非单调、tiling/kernel/搬运制度切换候选广泛存在。
4. 低随机 CV 误差不能代表边界、新 shape、长上下文或新编译器的精度；当前实现还有重复 shape 泄漏和训练集 score 问题。
5. GPU 间没有统一缩放因子：attention、投影、elementwise 和 network 的倍率显著不同。
6. current-main 缺论文 Chat-1M/BWB 等 workload，因此只能复核当前仓库，不能原样复现论文全部实验。
7. 对 NPU 应建模“shape + regime”，而不是只建一个全局 shape→time 函数。

![完整数据审计概览](figures/overview.png)

## 报告结构

1. 统一结论与主报告
2. Compute 深度审计
3. Network 与 workload 深度审计
4. 数据契约、代码消费与可达性
5. 全量可检索附录与证据目录


## 第一部分：统一主报告

### Vidur 仓库公开数据详析

> 审计对象：`microsoft/vidur` current main，commit `8383d2935bc62723a212090baa9f98ada206fc14`  
> 审计日期：2026-08-13  
> 本地只读副本：`D:\workspaces\trace\vidur_repro\vidur`  
> 范围：仓库内全部 53 个 CSV、当前 predictor 的读取/过滤/特征/缓存路径，以及 CSV 与论文实验的可复现关系。

#### 1. 结论先行

1. **公开数据足以支持“固定 device/model/TP/backend、已采样 shape 域内”的分段学习，但不支持任意 OOD 外推。** 标准 attention 网格在其设计域内相当密集，单点重复测量的中位数通常稳定；与此同时，曲线存在平台、非单调区和明显跳变。随机森林适合拟合这种分段关系，但“可学习”应被限定为同一运行制度（regime）内插值。
2. **仓库不是论文实验数据的完整快照。** current main 的三条 workload 是 Arxiv、Splitwise code、Splitwise conversation；论文配置引用的 Chat-1M、BWB 等文件不在仓库。Splitwise trace 和 Llama-3 profile 还是论文发布后加入的。因此可以审计当前代码和数据，但不能据此逐项复现论文 workload 结果。
3. **53 个 CSV 共 1,436,810 行、275.31 MB。** 其中 compute 40 个/1,217,254 行，workload 3 个/56,442 行；`profiling/network` 下 10 个/163,114 行，但其中 136,750 行其实是误放的 A40 attention compute profile，真正标准 collective 只有 26,364 行。
4. **数据的主体不是端到端请求观测，而是 operator/collective 微基准。** learner 使用各 operator 的 `median`，按 MLP、prefill attention、decode attention、all-reduce、send/recv 分别建模，再由仿真器组合。CPU overhead CSV 完全缺失且默认跳过，因此调度、采样、输入准备、输出处理和 Ray 通信开销默认为 0。
5. **数据并不“平滑”，但多数点的测量噪声不大。** attention 的行内 CV p95 通常约 0.94%–2.76%；H100 MLP 投影的尾部 CV p95 可到 8.53%–11.37%。attention 中位数全部量化到 1 μs 网格，MLP 全部量化到 0.5 μs 网格，因此微小算子的巨大相对误差经常只是计时分辨率效应。
6. **shape 细微变化确实可能带来大跳变。** 例如 H100/Qwen-72B/TP1 的 `mlp_down_proj` 从 512 到 520 token，工作量代理仅增 1.56%，中位时延却由 0.2310 ms 增至 0.6525 ms（+182.47%）。这支持“边界/制度感知”的模型，而不是强制单调或全局光滑模型。
7. **当前训练评估容易高估泛化。** loader 只删除完整重复行，不按 shape 聚合；compute 数据仍有 28,744 个重复 shape 组。当前 10-fold CV 按行拆分，邻近网格和同 shape 可能同时进入训练与验证；代码又没有独立 test，并最终记录训练集 score。这个数字不能代表新 shape、边界邻域或 OOD 精度。
8. **存在会直接影响模拟正确性的契约缺陷。** A40 没有 all-reduce 文件；A100 Llama-3-8B attention 只覆盖 TP1/4；旧 attention 的 KV 最大 4032，却默认生成 4096 lookup；Orca 可用最大 4K 的旧 MLP 数据静默预测到 524K token；lookup cache 的 hash 没有完整包含训练数据、树状态、attention 文件和 KV 粒度。
9. **对昇腾 NPU，最合理的效仿不是照搬 GPU 的 shape→time 回归，而是把编译/tiling/搬运/流水制度显式化。** 推荐“regime 分类器 + regime 内回归/查表 + OOD 拒绝/补采”，并在疑似边界两侧做自适应密采，保留 compiler/kernel/tiling/cache/搬运路径元数据。

#### 2. 审计口径与可复现边界

##### 2.1 数据版本

本报告固定到 current-main commit `8383d29`。Git 历史显示：

- Llama-3 A100 profiles 于 2024-07-24 加入；
- Splitwise code/conversation traces 于 2024-08-16 加入；
- 它们都晚于 MLSys 2024 论文对应的代码/数据时点。

因此本报告中的“作者仓库数据”特指当前公开仓库资产，不把后来增加的数据冒充论文提交时的数据。

##### 2.2 方法

- 枚举并完整读取全部 CSV，统计 schema、行列数、字节数、空值、无穷值、完整重复行、shape 重复、数值范围与哈希。
- compute 比较只在同 model、TP、backend、operator、精确 shape 的交集上进行。
- 单调性先在相同曲线条件内聚合同 shape，再沿单轴比较相邻点；同时报告绝对量和相对量。
- network change-point 候选要求：消息至少 64 KiB、相邻 size 比不超过 1.25、绝对时延变化至少 0.005 ms 且超过相邻观测标准差合成值的 3 倍，并满足上跳至少 25%或下跳至少 20%。它们只是复测候选，不是已经确认的 NCCL 算法边界。
- 跨 GPU speedup 是当前数据集的经验比值；CSV 缺少 driver/CUDA/PyTorch/backend build/频率/功耗/采集日期等 manifest，不能把差异完全归因于硬件。

#### 3. 数据资产全景

| 类别 | CSV | 行数 | 字节 | 可删除完整重复行 | 主要用途/问题 |
|---|---:|---:|---:|---:|---|
| Compute | 40 | 1,217,254 | 238,768,309 | 3,108 | 20 attention + 20 MLP；predictor 的主要训练数据 |
| Network 路径下 | 10 | 163,114 | 35,054,125 | 479 | 其中 136,750 行是误放的 A40 attention；标准 collective 仅 26,364 行 |
| Workload | 3 | 56,442 | 1,490,301 | 469 | 请求长度与两条 arrival trace；不等于论文完整 workload 集 |
| **合计** | **53** | **1,436,810** | **275,312,735** | **4,056** | 9 种 schema |

质量概览：

- 22 个文件含完整重复行；9 个 network 文件带无业务含义的 `Unnamed: 0` 索引列。
- 共 7,512,480 个空单元格，绝大多数来自旧 attention schema 对非当前 phase 的结构性留空，并非同等严重的测量失败。
- 未发现全空列、数值无穷或负时延。
- CSV 没有统一数据字典、run ID、replicate ID、采集时间、软件栈版本、温度/频率或原始逐次样本；只能看到 min/max/mean/median/std 聚合值。

#### 4. Workload 数据

##### 4.1 三条 trace 的统计

| Trace | 请求数 | prefill p50 / p90 / p99 | decode p50 / p90 / p99 | total p50 / p90 / p99 / max | total > 4096 | 到达信息 |
|---|---:|---|---|---|---:|---|
| Arxiv summarization | 28,257 | 2730 / 3702 / 3933 | 167 / 372 / 3271 | 2992 / 3907 / 4077 / 4096 | 0% | 无 arrival timestamp |
| Splitwise code | 8,819 | 1469 / 5188 / 7436 | 13 / 55 / 251 | 1493 / 5208 / 7462 / 7841 | 14.253% | 3435.95 s，均值 2.566 QPS |
| Splitwise conversation | 19,366 | 1020 / 2735 / 4142 | 129 / 424 / 601 | 1412 / 2820 / 4259 / 14,089 | 8.324% | 3501.72 s，均值 5.530 QPS |

进一步观察：

- Arxiv 的 total 被限制到 4096，prefill 与 decode 的 Pearson 相关为 -0.463；decode 有明显长尾，top 1% 请求贡献约 12.33% 的 decode token。
- Splitwise code 是极端 prefill-heavy：prefill/decode 比值中位数约 91.81；prefill=7435–7437 形成明显封顶堆积。
- Splitwise conversation 的 prefill/decode 比值中位数约 3.58，更接近对话负载，但最大 total 达 14,089。
- 按 `(prefill, decode)` 看，Arxiv 有 934 行处于重复 shape，code 为 1,437 行，conversation 为 8,186 行。Arxiv 还有 469 行完整重复；另两条带 arrival 的 trace 没有完整重复。
- code/conv 的 arrival timestamp 严格递增，没有非正 inter-arrival；中位 inter-arrival 分别约 63.8 ms 和 118.4 ms。

##### 4.2 4K 配置与 trace 变换

默认 `prediction_max_tokens_per_request=4096` 时，原始请求落在域内的比例为：Arxiv 100%、code 85.75%、conversation 91.68%。共有 2,869 条 code/conv 请求超过 4K。

这不仅是“丢掉尾部”这么简单：

- trace replay 路径在总长度超限时优先从 prefill 扣除超额，尽量保留 decode；
- length generator 路径按比例缩短输入/输出；
- 两种生成器面对同一原始 trace，会产生不同的有效 workload 分布。

因此报告模拟结果时必须同时记录：原始 trace、最大 context、使用的 generator、截断请求数，以及截断前后的长度分布。

##### 4.3 与论文复现的差距

- current main 没有论文配置所需的 `lmsys_chat_1m_conversation_stats_llama2_tokenizer.csv` 和 `bwb_stats_llama2_tokenizer_filtered_v2.csv`。
- 默认 trace-length 配置还引用缺失的 ShareGPT 8K 文件；默认 interval 配置引用缺失的 Azure Functions 文件。
- 仓库三个现有 trace 都没有 interval loader 所要求的 `arrival_time` schema。

结论是：当前仓库可运行 Splitwise replay 或对现有长度分布做分析，但不能仅凭现有 CSV 原样复现论文的 Chat-1M/Arxiv-4K/BWB-4K 对比。

#### 5. Compute profiling 数据

##### 5.1 规模与 schema

| GPU | 类型 | 文件/模型 | 行数 | 唯一 shape（逐文件求和） | 重复 shape 组 | 可删除完整重复行 |
|---|---|---:|---:|---:|---:|---:|
| A100 | attention | 8 / 8 | 493,579 | 480,979 | 12,450 | 1,153 |
| A100 | MLP | 8 / 8 | 9,129 | 9,047 | 82 | 0 |
| A40 | attention | 6 / 6 | 351,792 | 343,632 | 8,064 | 405 |
| A40 | MLP | 6 / 6 | 5,481 | 5,439 | 42 | 0 |
| H100 | attention | 6 / 6 | 351,792 | 343,632 | 8,064 | 1,550 |
| H100 | MLP | 6 / 6 | 5,481 | 5,439 | 42 | 0 |

共 4 套 compute schema：

1. 18 个旧 attention 文件：31 列，FlashAttention，`max_model_len=4096`，没有 `attn_kv_cache_save`；loader 会把该 target 补成 0。
2. 2 个 A100 Llama-3 attention 文件：36 列，FlashInfer，`max_model_len=16384`，带 KV-cache-save；非当前 phase 的 target 使用 0，而不是旧 schema 的空值。
3. 17 个标准 MLP 文件：包含 post-attention norm。
4. 3 个 Phi-2 MLP 文件：按模型结构没有 post-attention norm。

`attention_backend` 和 `max_model_len` 被写入 CSV，却没有作为 learner 的显式特征或 loader 过滤条件；当前每个文件内部只有一个 backend，暂时没有混合，但数据契约无法防止未来误混。

##### 5.2 shape 网格与覆盖

旧数据的主要网格：

- MLP：TP1/2/4/8；每 TP 259 个唯一 `num_tokens`，覆盖 1–4096，大 shape 步长逐渐变大，2048/4096 等段边界重复。
- Decode attention：每 TP 是 128 个 batch × 79 个 KV 点，共 10,112 个唯一 shape；KV 从 32 起，最大 4032。
- Prefill attention：在 `prefill + KV <= 4096` 的采样约束内，每 TP 4,206 个唯一 shape；最小 prefill chunk 为 64。
- Llama-3 MLP：每 TP 451 个唯一点，1–32768；中位步长 32、最大步长 256。
- Llama-3 attention：A100/FlashInfer，batch 可到 512、prefill 可到 16384、KV 可到 16320；显存过滤与 TP 强相关。

域内网格完整不等于没有空洞：旧 attention 的 prefill 1–63、decode KV 0–31 没有实测；默认 lookup 仍会生成 KV=0 和 KV=4096 等点，这些是边界常数预测/外推，不是插值。大 shape 的步长也越来越粗，无法观察 `x±1` 触发的 kernel/tiling 边界。

##### 5.3 重复、异常与测量噪声

- Compute 中有 3,108 行可删除的完整重复，另有 28,744 个重复 shape 组。重复主要来自分段网格边界和 full-prefill/chunked-prefill 构造重叠，并不等价于独立复测。
- Loader 只执行整行 `drop_duplicates()`；同 shape 但统计值不同的行仍作为独立训练样本，使这些边界 shape 获得额外权重。
- 唯一硬异常是 A100/Qwen-72B/TP1 decode 的 16 行：`median=0`，但 mean 为 0.0154–0.2114 ms、max 最高 0.529 ms。当前代码会直接把 0 当 label；对 MAPE 而言也会产生不稳定语义，应重测或剔除。
- attention 的 2,394,310 个正中位数全部在 1 μs 网格；MLP 的 200,127 个正中位数全部在 0.5 μs 网格，其中约 88%–90% 又落在整数 μs 网格。对 0.001–0.01 ms 算子必须同时看绝对 μs 差，不能只看百分比。

行内重复测量的代表性 CV p95（文件中位数）如下：

| Operator | A100 | A40 | H100 |
|---|---:|---:|---:|
| `attn_decode` | 2.144% | 0.941% | 2.761% |
| `attn_prefill` | 2.218% | 2.727% | 2.547% |
| `attn_pre_proj` | 2.556% | 2.076% | 11.371% |
| `mlp_up_proj` | 2.097% | 2.114% | 8.528% |
| `mlp_down_proj` | 2.666% | 2.047% | 8.527% |

这说明大部分 attention 点的 median 相当稳定；H100 MLP 的尾部显著更不稳定，需独立复测。这里的重复次数是单行内部 5/20 次采样，而重复 shape 行往往只是网格构造重叠，两者不能混为一谈。

##### 5.4 非单调与跳变

以相邻点时延下降超过 5% 为例：

| 轴 | A100 | A40 | H100 |
|---|---:|---:|---:|
| Decode：沿 batch | 0.887% | 0.314% | 1.439% |
| Decode：沿 KV | 0.677% | 0.343% | 1.109% |
| Prefill：沿 chunk | 1.480% | 1.945% | 2.381% |
| Prefill：沿 KV | 4.771% | 5.685% | 5.899% |

非单调不是自动的数据错误：并行度、tile、搬运、cache、调度和计时量化都可能让更大 shape 更快。真正值得复测的是“变化远大于观测噪声、工作量变化很小、且边界附近可重复”的点。

代表性强跳变：

- H100/Qwen-72B/TP1 `mlp_down_proj`：512→520 token，0.2310→0.6525 ms，+182.47%。
- A40/Qwen-72B/TP1 同算子：256→264 token，1.043→2.919 ms，+179.87%。
- 2 的幂边界附近的偏差在多组 prefill KV 曲线中富集，但采样步长也恰在这些位置改变，故只能称“量化/网格效应候选”，不能直接断言是 kernel 切换。

##### 5.5 跨 GPU 与 TP

严格使用相同 model/TP/backend/operator/精确 shape 的交集后，6 个共同模型的 cell 中位 speedup 中位数为：

| 比较 | Decode | Prefill | Attention pre-proj | Attention post-proj | MLP up | MLP down |
|---|---:|---:|---:|---:|---:|---:|
| A40 → A100 | 2.583× | 1.849× | 1.969× | 1.994× | 2.015× | 2.015× |
| A100 → H100 | 1.690× | 1.497× | 2.800× | 2.865× | 2.827× | 2.923× |

差异明显依赖 operator，说明不能用单一“硬件倍率”缩放全部算子。`emb` 在 A40→A100 上甚至多数 shape 显示 A100 更慢；该列又不进入当前 ExecutionTime，反而像是软件/实现/采集环境不一致的提示。

Compute-only TP scaling 看起来较好，例如 A100 `mlp_up_proj` 的 TP2/4/8 中位 speedup 约 2.013×/4.036×/8.016×；但 attention 的效率更低，例如 A100 decode TP2/4/8 约 1.796×/3.248×/5.614×。这些数字不含 collective、同步、CPU、pipeline bubble 和调度，不能作为端到端 TP 扩展率。

#### 6. Network profiling 数据

##### 6.1 标准数据范围

真正标准的 all-reduce/send-recv 数据共 26,364 行：

- 多数曲线有 993 个唯一 message size，覆盖 2 KiB–64 MiB；分段网格在 16 MiB 边界重复。
- A100 pairwise all-reduce 例外，覆盖到约 511.5 MiB。
- 所有标准文件只保留 rank 0；当前 benchmark 每点只有 3 次 active 测量。因此不能观察 rank 不对称和尾延迟。
- 9 个文件包含 `Unnamed: 0`；重复 network key 全位于 16 MiB 分段边界。

##### 6.2 吞吐与拓扑差异

以下为 payload-equivalent bandwidth 的 p95，不是 NCCL 官方 `busbw`，也不是厂商峰值：

| 数据组 | p95 payload BW |
|---|---:|
| A100 DGX AR，w2/dpn2（节点内） | 153.18 GB/s |
| A100 DGX AR，w2/dpn1（跨节点） | 5.86 GB/s |
| A100 DGX AR，w4/dpn4 / w4/dpn2 | 110.61 / 7.04 GB/s |
| A100 DGX AR，w8/dpn8 / w8/dpn4 | 96.01 / 12.17 GB/s |
| H100 DGX AR，w2 / w4 / w8 节点内 | 269.90 / 209.80 / 189.11 GB/s |
| A100 pairwise AR，w2 / w4 | 194.66 / 15.79 GB/s |
| H100 pairwise AR，w2 / w4 | 187.66 / 32.30 GB/s |

拓扑/worker 数对网络曲线的影响远大于简单 device 标签；它们必须成为模型契约的一部分。

##### 6.3 数据异常与代码不可达性

- `a40_pairwise_nvlink/attention.csv` 有 136,750 行、50 列，是旧 attention compute profile，当前代码没有路径会消费它；同时该目录没有 `all_reduce.csv`，A40 TP>1 默认会在文件打开阶段失败。
- A100 DGX all-reduce 含 `(workers, devices_per_node)` 为 `(2,1)/(2,2)/(4,2)/(4,4)/(8,4)/(8,8)/(16,8)` 的曲线。当前 loader 强制 `num_workers == TP && devices_per_node == TP`，所以 3,976 行跨节点曲线永久不可达，TP16 也因不存在 `(16,16)` 而不可用。
- H100 DGX all-reduce 只有节点内 w2/w4/w8；没有跨节点或 w16 数据。
- H100 与 A100 pairwise `send_recv.csv` 字节级完全相同，缺少 provenance 无法判断是复用、占位还是独立测量恰好相同，不能据此声称两种硬件网络性能一致。
- A40 目录名是 pairwise NVLink，但记录的 `max_devices_per_node=8`；命名和拓扑元数据应统一验证。

##### 6.4 抖动与候选边界

CV > 20% 的点包括：A100 DGX AR 174/6958、A100 pairwise AR 65/4496、H100 DGX AR 155/2982、H100 pairwise AR 36/1988；各 send/recv 文件也有 12–85/1988 个高抖动点。

联合绝对变化、相对变化和 3×观测噪声阈值后，共得到 284 个局部跳变/非单调候选。比如约 395–403 KiB 附近，部分 A100/H100 曲线出现 0.013→0.063 ms 或 0.010→0.043 ms 的上跳。没有 NCCL debug log、算法/协议 ID 和密集复测前，这些只能用来指导补采。

#### 7. 当前 learner 到底消费了什么

##### 7.1 标签与特征

当前 sklearn predictor 的核心逻辑是：

- 对每个 operator 单独取 CSV 的 `median` 作为 target；min/max/mean/std 不进入训练，也不作为样本权重。
- MLP/投影/norm/rope/add 等主要以 `num_tokens` 为输入。
- Decode attention 使用 `[batch_size, kv_cache_size]`。
- Prefill attention 使用 `[kv_cache_size, prefill_chunk_size²]`。
- all-reduce/send-recv 把 bytes 换算成 token 后学习一维曲线。
- 默认随机森林 grid 为 `n_estimators=[250,500,750]`、`max_depth=[8,16,32]`、`min_samples_split=[2,5,10]`，以自定义 MAPE 做 10-fold GridSearchCV。

运行时还会施加额外的人为规则：

- MLP 总 token 向上取整到 8 的倍数。
- Decode 将 batch 内 KV 先求平均，再向上取整到 64 的倍数。
- Prefill 将每请求 KV 向上取整到 64，再对 KV 求和、对 chunk 的平方和开根聚合。
- GQA 多请求 attention 统一乘约 1.1 的经验修正。
- KV-cache-save 用精确 token；旧 schema 缺列时则被训练成常数 0。

所以“预测一个 batch”并不是直接学习完整 batch 的真实联合执行时间，而是把 batch 投影到少数聚合特征后查表。

##### 7.2 没被使用或被弱化的信息

- CSV 虽保存每点 min/max/mean/median/std，模型只吃 median；无法表达 aleatoric uncertainty。
- `attention_backend`、`max_model_len` 不作为特征/过滤条件。
- `attn_input_reshape` 在公开 compute 数据里没有有效学习信号；reshape/output reshape 等字段也没有进入最终 ExecutionTime 组合。
- `emb` 被测量但不进入当前 ExecutionTime。
- CPU overhead 文件为 0 个，默认全部置零。
- 网络 CSV 的 cross-node 曲线因过滤条件不可达。

#### 8. 数据契约与运行风险

##### 8.1 覆盖矩阵

- 配置注册的 27 个 model×device 组合中，7 个完全没有 compute 文件：InternLM2-20B 在三种设备上均缺，两个 Llama-3 模型在 A40/H100 上均缺。
- A100 Llama-3-8B 的 MLP 有 TP1/2/4/8，但 attention 只有 TP1/4，所以可用 compute TP 仍只有 1/4。
- 所有 attention profile 只覆盖 block size 16。
- Compute 有 TP8 并不意味着端到端 TP8 可用；pairwise all-reduce 可能只支持 TP2/4，A40 更完全缺 AR。
- `device` 与 `network_device` 独立配置，代码允许 A100 compute + H100 network 这类物理上未验证的组合，没有一致性校验。

##### 8.2 外推与查表失败

- 旧 attention 最大 KV=4032，但默认 lookup 会生成 4096；RF 在边界外只能返回叶节点常数。
- 旧 MLP 最大 token=4096；在 Orca scheduler 下，lookup 上限可能是 `4096×128=524,288`，形成两个数量级的静默外推。
- 超过生成 lookup 的实际 batch/shape 没有 clamp 或 fallback，会直接 `KeyError`。
- scheduler 的 batch cap 与 predictor 的 max batch 没有耦合验证。

##### 8.3 缓存正确性

- 训练模型 cache hash 包含 dataframe；但 prediction lookup cache 使用拟合 estimator 的字符串表示，通常只反映超参，不包含树状态或训练数据。
- predictor 的 `to_dict()` 没包含 `attention_input_file` 和 `kv_cache_prediction_granularity` 等关键输入。
- 因此 CSV、模型或粒度变化后，存在静默复用旧 prediction lookup 的风险。运行严格实验时应使用 `no_cache` 或修复 hash 契约，并把数据文件哈希、代码 commit、超参和软件环境写入 manifest。

#### 9. “可学习”应如何定义

##### 9.1 当前数据支持的命题

在固定 GPU、模型结构、TP、attention backend、软件栈和采集状态下，对已覆盖 shape 域：

- 重复测量的 median 多数稳定；
- attention 网格足够密，MLP 一维曲线也覆盖主要 token 范围；
- 非线性、平台和离散跳变可以由树模型分段逼近；
- 因而适合做 same-regime、in-domain 插值。

##### 9.2 当前数据不支持的命题

不能由这些 CSV 推出：

- 未见过的 compiler、kernel、tiling、attention backend 或设备仍共享同一函数；
- 4K 数据可以可靠外推到 16K/524K；
- 随机行 CV 的低误差等价于新 shape、连续空区间或边界邻域的误差；
- compute-only TP speedup 等于端到端扩展率；
- operator median 相加能完整覆盖 CPU、搬运、并发、通信重叠和流水线开销。

更准确的说法是：**时延函数是“分段可学习”的；分段边界本身必须被识别、观测和版本化。**

#### 10. 对昇腾 NPU 的落地建议

NPU 的 shape 变化可能同时触发图编译、tiling、workspace、DMA 搬运、核函数选择、流水并行或融合变化。建议把这些离散状态视为一等信息，而不是藏在一个全局连续函数里。

##### 10.1 数据契约

每条样本至少记录：

- 硬件：NPU 型号、卡/节点拓扑、频率/功耗模式、固件；
- 软件：CANN/torch_npu/框架/算子库/编译器 commit 与关键 flag；
- 图与 kernel：graph hash、kernel/tiling ID、workspace、融合/拆分方案、stream 数；
- Shape：原始维度、padding/对齐后维度、dtype/layout、batch/sequence/KV/TP；
- 搬运：H2D/D2D/片上搬运字节、路径和是否重叠；
- 状态：cold compile、warm cache、compile-cache hit、独立进程/run/replicate ID；
- 标签：compile time、host launch、搬运、kernel、同步、端到端分别记录，保留逐次样本而非只存五元统计。

##### 10.2 采样策略

1. 先做粗网格覆盖生产域，并按线上 workload 分布加权。
2. 计算相邻点的绝对跳变、相对跳变和噪声标准化跳变。
3. 对候选边界补采 `x±1`、对齐块 `x±tile`、2 的幂两侧、常见 batch/sequence/KV 组合。
4. 每个 shape 至少区分 warm 重复与多个独立进程/独立编译的重复；高抖动点提高重复数。
5. 保留没被线上 workload 高频覆盖但可能触发大制度切换的 guardrail 点。

##### 10.3 建模结构

推荐三级结构：

1. **Regime 分类**：预测/读取 compiler、kernel、tiling、搬运路径和 cache 状态。
2. **Regime 内回归**：小维度可用查表/分段树/GBDT；有足够数据再用更复杂模型。不要强制全局单调。
3. **不确定性与 OOD**：报告与最近训练点距离、叶节点样本量、重复测量方差；越界或低置信度时拒绝预测并触发补采，而不是静默叶节点常数外推。

如果运行时拿不到 tiling/kernel ID，可把它们作为训练时的 latent regime 标签：先离线聚类/分类边界，再用 shape 预测 regime；但必须单独评估 regime 分类错误，因为跨 regime 的误差远大于 regime 内回归误差。

##### 10.4 评估切分


至少同时报告：

- `Group holdout`：同 shape 的所有重复必须在同一 fold；
- `Contiguous-block holdout`：整段 token/KV/batch 区间留出；
- `Boundary-neighborhood holdout`：专门留出 tiling/kernel 切换两侧；
- `OOD holdout`：新 compiler、backend、TP、拓扑或设备；
- `Workload-weighted`：按真实请求分布计算端到端误差。

指标同时给出 MAE（μs/ms）、相对误差、p95/p99、边界误差和 regime 分类准确率。对接近 0 的算子不要单独依赖 MAPE。

#### 11. 数据质量修复优先级

| 优先级 | 动作 | 原因 |
|---|---|---|
| P0 | 重测/剔除 A100 Qwen-72B TP1 的 16 个 zero-median decode 点 | 直接制造 0 ms 标签并破坏 MAPE 语义 |
| P0 | 修复 prediction lookup cache hash | 数据或模型变化后可能静默使用旧预测 |
| P1 | 按 shape 聚合或保留 replicate ID；CV 按 shape 分组 | 避免重复 shape 权重偏置与 train/validation 泄漏 |
| P1 | 给所有 profile 增加环境与采集 manifest | 当前无法区分硬件、软件、温度和版本影响 |
| P1 | 修复 all-reduce 跨节点过滤与 A40 缺文件 | 已有 3,976 行跨节点数据不可达，A40 TP>1 失败 |
| P1 | 禁止超出 profile 域静默外推 | 4K→524K 的叶常数不是可信预测 |
| P1 | 重测 H100 MLP 高抖动点与 284 个 network 候选边界 | 判断真实 regime change 与测量噪声 |
| P2 | 补齐 CPU overhead、rank/tail、Llama-3 跨 GPU 与 TP 缺口 | 扩大端到端可解释范围 |
| P2 | 补回论文 workload 或发布准确版本清单 | 支持论文实验的可复现性 |

#### 12. 本地可复查产物

- 总扫描与汇总：`D:\workspaces\trace\vidur_data_analysis\main`
- Compute 详析：`D:\workspaces\trace\vidur_data_analysis\compute_agent\COMPUTE_ANALYSIS.md`
- Network/workload 详析：`D:\workspaces\trace\vidur_data_analysis\network_workload_agent\NETWORK_WORKLOAD_ANALYSIS.md`
- 代码/数据契约审计：`D:\workspaces\trace\vidur_data_analysis\contract_agent\DATA_CONTRACT_ANALYSIS.md`
- 全部结构化 CSV/JSON 与可重跑脚本均位于上述目录；官方仓库在分析后保持 clean。

本报告的统计是对 current-main 公开资产的描述性审计，不替代作者论文中的精度结果，也不把候选跳变解释成已经证实的微架构因果。要得到因果结论，需要带 kernel/tiling/compiler/NCCL 协议信息的定向复测。

## 第二部分：Compute 深度审计

![Compute 覆盖矩阵](figures/compute_coverage.png)

![Compute 测量抖动](figures/compute_jitter.png)

### Compute profiling 深度附录：逐 GPU、逐模型、逐文件证据表

> 数据范围：现有 compute artifacts；原始资产共 **40 个 CSV、1,217,254 行、238,768,309 bytes、4 套 schema**。本附录不读取或修改官方仓库。所有数值均是当前 main 数据的补充分析，不代表论文同期重新实验。

#### A. 读表规则与指标定义

逐文件表中的 `行/唯一/重复组/完全重复` 依次表示 CSV 行数、完整 shape key 的唯一组合数、出现至少两次的 shape 组数、`duplicated()` 可删除的逐列完全重复行数。`CV95` 是该文件内每行多次采样的 `std/mean` 分布 p95；attention 通常来自 5 次 active sample，MLP 通常来自20 个 traced operator instance。runtime 一栏是各 TP 上、该文件所有 shape 的 operator median之 p50 的最小–最大值，单位 ms。

`最大增/降` 在完全相同 GPU/model/TP/backend/其余 shape 条件下，对一个轴排序后比较相邻**已采样点**；重复 shape 先取 median。它不保证横轴步长相同：Llama3 稀疏 prefill 可能跨越很大区间，因此这里是采样曲线的极值，不自动等价于 `x±1` 的微架构跳变。

| schema | 文件数 | 含义 | 关键差异 |
|---|---|---|---|
| ATT-31 | 18 | 旧 attention | 31 列；FLASH_ATTENTION；inactive phase target 为 NaN；无 KV-save |
| ATT-36 | 2 | Llama3 attention | 36 列；FLASHINFER；含 KV-save；inactive phase target 为 0 |
| MLP-58 | 17 | 标准 MLP | 10 个 operator，含 post-attention layernorm |
| MLP-53 | 3 | Phi-2 MLP | 无 post-attention layernorm；Phi-2 仅 TP1 |

| GPU | 类型 | 正 median 数 | 整数 µs 网格 | 0.5 µs 网格 | 最小正值(ms) |
|---|---|---|---|---|---|
| A100 | attention | 987,142 | 100.00% | 100.00% | 0.001 |
| A100 | mlp | 91,029 | 87.38% | 100.00% | 0.001 |
| A40 | attention | 703,584 | 100.00% | 100.00% | 0.001 |
| A40 | mlp | 54,549 | 88.20% | 100.00% | 0.001 |
| H100 | attention | 703,584 | 100.00% | 100.00% | 0.001 |
| H100 | mlp | 54,549 | 90.20% | 100.00% | 0.001 |

attention 的正 median 全部落在 1 µs 网格，MLP 全部落在 0.5 µs 网格；因此后续百分比抖动和微小 operator 跳变必须结合绝对毫秒值解释。

#### B. GPU × model × 文件逐项总表

##### A100

###### Attention 文件

| model | schema/backend/maxlen | TP | 行/唯一/重复组/完全重复 | decode shape 与唯一覆盖/TP | prefill shape 与唯一覆盖/TP | target runtime p50范围(ms) | 关键 CV95 | 关键算子最大增/降 |
|---|---|---|---|---|---|---|---|---|
| Qwen-72B | ATT-31/FLASH_ATTENTION/L4096 | 1/2/4/8 | 58,632/57,272/1,344/77 | B1–128(128) × KV32–4032(79); T1:10,112@100.0%/T2:10,112@100.0%/T4:10,112@100.0%/T8:10,112@100.0% | P64–4096(81) × KV0–4032(80); T1:4,206@100.0%/T2:4,206@100.0%/T4:4,206@100.0%/T8:4,206@100.0% | D 0.1950–1.0585; P 0.1310–0.6460 | D 1.36%; P 2.74% | +119.2%(attn_decode/batch_size/T1); −100.0%(attn_decode/kv_cache_size/T1) |
| CodeLlama-34B | ATT-31/FLASH_ATTENTION/L4096 | 1/2/4/8 | 58,632/57,272/1,344/171 | B1–128(128) × KV32–4032(79); T1:10,112@100.0%/T2:10,112@100.0%/T4:10,112@100.0%/T8:10,112@100.0% | P64–4096(81) × KV0–4032(80); T1:4,206@100.0%/T2:4,206@100.0%/T4:4,206@100.0%/T8:4,206@100.0% | D 0.0360–0.1995; P 0.1260–0.5250 | D 2.40%; P 2.08% | +126.3%(attn_prefill/prefill_chunk_size/T1); −34.3%(attn_prefill/kv_cache_size/T8) |
| InternLM-20B | ATT-31/FLASH_ATTENTION/L4096 | 1/2/4/8 | 58,632/57,272/1,344/105 | B1–128(128) × KV32–4032(79); T1:10,112@100.0%/T2:10,112@100.0%/T4:10,112@100.0%/T8:10,112@100.0% | P64–4096(81) × KV0–4032(80); T1:4,206@100.0%/T2:4,206@100.0%/T4:4,206@100.0%/T8:4,206@100.0% | D 0.1350–0.7465; P 0.0950–0.4340 | D 1.52%; P 3.07% | +137.7%(attn_prefill/prefill_chunk_size/T4); −40.0%(attn_prefill/kv_cache_size/T2) |
| Llama2-70B | ATT-31/FLASH_ATTENTION/L4096 | 1/2/4/8 | 58,632/57,272/1,344/176 | B1–128(128) × KV32–4032(79); T1:10,112@100.0%/T2:10,112@100.0%/T4:10,112@100.0%/T8:10,112@100.0% | P64–4096(81) × KV0–4032(80); T1:4,206@100.0%/T2:4,206@100.0%/T4:4,206@100.0%/T8:4,206@100.0% | D 0.0360–0.1970; P 0.1260–0.5275 | D 2.45%; P 2.05% | +131.9%(attn_prefill/prefill_chunk_size/T1); −34.1%(attn_prefill/kv_cache_size/T4) |
| Llama2-7B | ATT-31/FLASH_ATTENTION/L4096 | 1/2/4/8 | 58,632/57,272/1,344/142 | B1–128(128) × KV32–4032(79); T1:10,112@100.0%/T2:10,112@100.0%/T4:10,112@100.0%/T8:10,112@100.0% | P64–4096(81) × KV0–4032(80); T1:4,206@100.0%/T2:4,206@100.0%/T4:4,206@100.0%/T8:4,206@100.0% | D 0.1130–0.6620; P 0.0790–0.3605 | D 1.75%; P 2.76% | +96.2%(attn_decode/batch_size/T1); −38.5%(attn_prefill/kv_cache_size/T4) |
| Llama3-70B | ATT-36/FLASHINFER/L16384 | 1/2/4/8 | 99,200/96,183/2,981/212 | B1–512(176) × KV32–16128(127); T1:20,471@91.6%/T2:21,552@96.4%/T4:22,324@99.9%/T8:22,352@100.0% | P32–16384(178) × KV0–16320(584); T1:2,371@3.7%/T2:2,371@3.7%/T4:2,371@3.7%/T8:2,371@3.7% | D 0.0970–0.5470; P 0.0680–0.4205 | D 3.08%; P 0.93%; KVsave 18.84% | +4957.5%(attn_prefill/prefill_chunk_size/T1); −42.9%(attn_prefill/prefill_chunk_size/T4) |
| Llama3-8B | ATT-36/FLASHINFER/L16384 | 1/4 | 42,587/41,164/1,405/63 | B1–512(176) × KV32–16128(127); T1:15,572@69.7%/T4:20,850@93.3% | P32–16384(178) × KV0–16320(584); T1:2,371@3.7%/T4:2,371@3.7% | D 0.1500–0.3160; P 0.0690–0.2185 | D 2.63%; P 1.00%; KVsave 18.84% | +3693.5%(attn_prefill/prefill_chunk_size/T1); −22.3%(attn_prefill/prefill_chunk_size/T4) |
| Phi-2 | ATT-31/FLASH_ATTENTION/L4096 | 1/2/4/8 | 58,632/57,272/1,344/207 | B1–128(128) × KV32–4032(79); T1:10,112@100.0%/T2:10,112@100.0%/T4:10,112@100.0%/T8:10,112@100.0% | P64–4096(81) × KV0–4032(80); T1:4,206@100.0%/T2:4,206@100.0%/T4:4,206@100.0%/T8:4,206@100.0% | D 0.0990–0.5880; P 0.0660–0.2990 | D 1.89%; P 2.36% | +80.0%(attn_decode/batch_size/T2); −41.5%(attn_prefill/kv_cache_size/T2) |

###### MLP 文件

| model | schema | TP | 行/唯一/重复组/完全重复 | token shape 域 | 四投影 runtime p50范围(ms) | 四投影 CV95 | 四投影最大增/降 |
|---|---|---|---|---|---|---|---|
| Qwen-72B | MLP-58 | 1/2/4/8 | 1,044/1,036/8/0 | token 1–4096(259/TP); step 1/8/32 (min/median/max) | QKV 0.2505–1.8585; O 0.0840–0.6710; Up 0.4390–3.8075; Down 0.2340–2.0020 | QKV 2.30%; O 2.32%; Up 2.03%; Down 2.72% | +84.2%(attn_post_proj/num_tokens/T8); −40.0%(attn_post_proj/num_tokens/T8) |
| CodeLlama-34B | MLP-58 | 1/2/4/8 | 1,044/1,036/8/0 | token 1–4096(259/TP); step 1/8/32 (min/median/max) | QKV 0.1085–0.8080; O 0.0790–0.6605; Up 0.4190–3.4240; Down 0.2030–1.7870 | QKV 2.77%; O 2.28%; Up 1.98%; Down 2.61% | +76.6%(attn_pre_proj/num_tokens/T8); −37.1%(attn_post_proj/num_tokens/T8) |
| InternLM-20B | MLP-58 | 1/2/4/8 | 1,044/1,036/8/0 | token 1–4096(259/TP); step 1/8/32 (min/median/max) | QKV 0.1080–0.7520; O 0.0340–0.2640; Up 0.1570–1.3300; Down 0.0770–0.7060 | QKV 2.36%; O 2.95%; Up 2.05%; Down 3.00% | +87.9%(attn_pre_proj/num_tokens/T2); −36.3%(attn_pre_proj/num_tokens/T2) |
| Llama2-70B | MLP-58 | 1/2/4/8 | 1,044/1,036/8/0 | token 1–4096(259/TP); step 1/8/32 (min/median/max) | QKV 0.1120–0.8100; O 0.0800–0.6580; Up 0.5500–4.4650; Down 0.2755–2.3110 | QKV 2.70%; O 2.43%; Up 2.04%; Down 2.44% | +82.3%(attn_pre_proj/num_tokens/T8); −38.8%(attn_pre_proj/num_tokens/T8) |
| Llama2-7B | MLP-58 | 1/2/4/8 | 1,044/1,036/8/0 | token 1–4096(259/TP); step 1/8/32 (min/median/max) | QKV 0.0670–0.4760; O 0.0290–0.1870; Up 0.1230–0.8770; Down 0.0610–0.4385 | QKV 2.34%; O 3.03%; Up 2.21%; Down 3.08% | +83.3%(attn_pre_proj/num_tokens/T8); −37.5%(mlp_up_proj/num_tokens/T8) |
| Llama3-70B | MLP-58 | 1/2/4/8 | 1,824/1,804/20/0 | token 1–32768(451/TP); step 1/32/256 (min/median/max) | QKV 0.3025–2.3718; O 0.2457–1.9743; Up 1.5905–12.6402; Down 0.8682–6.4988 | QKV 2.68%; O 2.63%; Up 2.22%; Down 2.54% | +75.0%(attn_post_proj/num_tokens/T8); −40.0%(attn_post_proj/num_tokens/T8) |
| Llama3-8B | MLP-58 | 1/2/4/8 | 1,824/1,804/20/0 | token 1–32768(451/TP); step 1/32/256 (min/median/max) | QKV 0.0930–0.7845; O 0.0680–0.4775; Up 0.3782–3.2038; Down 0.1978–1.6225 | QKV 2.43%; O 2.54%; Up 2.14%; Down 2.56% | +91.7%(attn_pre_proj/num_tokens/T4); −32.6%(attn_pre_proj/num_tokens/T4) |
| Phi-2 | MLP-53 | 1 | 261/259/2/0 | token 1–4096(259/TP); step 1/8/32 (min/median/max) | QKV 0.1810–0.1810; O 0.0800–0.0800; Up 0.2370–0.2370; Down 0.2510–0.2510 | QKV 2.87%; O 3.28%; Up 2.87%; Down 3.27% | +69.4%(mlp_down_proj/num_tokens/T1); −33.3%(attn_pre_proj/num_tokens/T1) |

##### A40

###### Attention 文件

| model | schema/backend/maxlen | TP | 行/唯一/重复组/完全重复 | decode shape 与唯一覆盖/TP | prefill shape 与唯一覆盖/TP | target runtime p50范围(ms) | 关键 CV95 | 关键算子最大增/降 |
|---|---|---|---|---|---|---|---|---|
| Qwen-72B | ATT-31/FLASH_ATTENTION/L4096 | 1/2/4/8 | 58,632/57,272/1,344/25 | B1–128(128) × KV32–4032(79); T1:10,112@100.0%/T2:10,112@100.0%/T4:10,112@100.0%/T8:10,112@100.0% | P64–4096(81) × KV0–4032(80); T1:4,206@100.0%/T2:4,206@100.0%/T4:4,206@100.0%/T8:4,206@100.0% | D 0.5040–2.6065; P 0.2210–1.3870 | D 0.68%; P 2.84% | +164.3%(attn_decode/batch_size/T1); −50.2%(attn_prefill/kv_cache_size/T2) |
| CodeLlama-34B | ATT-31/FLASH_ATTENTION/L4096 | 1/2/4/8 | 58,632/57,272/1,344/88 | B1–128(128) × KV32–4032(79); T1:10,112@100.0%/T2:10,112@100.0%/T4:10,112@100.0%/T8:10,112@100.0% | P64–4096(81) × KV0–4032(80); T1:4,206@100.0%/T2:4,206@100.0%/T4:4,206@100.0%/T8:4,206@100.0% | D 0.0760–0.5180; P 0.2000–1.0465 | D 1.37%; P 1.35% | +161.3%(attn_prefill/kv_cache_size/T1); −54.2%(attn_prefill/kv_cache_size/T2) |
| InternLM-20B | ATT-31/FLASH_ATTENTION/L4096 | 1/2/4/8 | 58,632/57,272/1,344/57 | B1–128(128) × KV32–4032(79); T1:10,112@100.0%/T2:10,112@100.0%/T4:10,112@100.0%/T8:10,112@100.0% | P64–4096(81) × KV0–4032(80); T1:4,206@100.0%/T2:4,206@100.0%/T4:4,206@100.0%/T8:4,206@100.0% | D 0.3330–2.0945; P 0.1515–0.9210 | D 0.72%; P 3.51% | +153.3%(attn_prefill/prefill_chunk_size/T1); −44.0%(attn_prefill/prefill_chunk_size/T2) |
| Llama2-70B | ATT-31/FLASH_ATTENTION/L4096 | 1/2/4/8 | 58,632/57,272/1,344/67 | B1–128(128) × KV32–4032(79); T1:10,112@100.0%/T2:10,112@100.0%/T4:10,112@100.0%/T8:10,112@100.0% | P64–4096(81) × KV0–4032(80); T1:4,206@100.0%/T2:4,206@100.0%/T4:4,206@100.0%/T8:4,206@100.0% | D 0.0750–0.5100; P 0.2000–1.0460 | D 1.40%; P 1.33% | +166.7%(attn_prefill/kv_cache_size/T1); −53.8%(attn_prefill/kv_cache_size/T2) |
| Llama2-7B | ATT-31/FLASH_ATTENTION/L4096 | 1/2/4/8 | 58,632/57,272/1,344/59 | B1–128(128) × KV32–4032(79); T1:10,112@100.0%/T2:10,112@100.0%/T4:10,112@100.0%/T8:10,112@100.0% | P64–4096(81) × KV0–4032(80); T1:4,206@100.0%/T2:4,206@100.0%/T4:4,206@100.0%/T8:4,206@100.0% | D 0.2710–1.8970; P 0.1250–0.7425 | D 0.78%; P 3.53% | +160.7%(attn_prefill/prefill_chunk_size/T1); −51.0%(attn_prefill/kv_cache_size/T1) |
| Phi-2 | ATT-31/FLASH_ATTENTION/L4096 | 1/2/4/8 | 58,632/57,272/1,344/109 | B1–128(128) × KV32–4032(79); T1:10,112@100.0%/T2:10,112@100.0%/T4:10,112@100.0%/T8:10,112@100.0% | P64–4096(81) × KV0–4032(80); T1:4,206@100.0%/T2:4,206@100.0%/T4:4,206@100.0%/T8:4,206@100.0% | D 0.2490–1.9475; P 0.0990–0.5330 | D 1.10%; P 2.61% | +205.3%(attn_prefill/prefill_chunk_size/T1); −55.1%(attn_prefill/kv_cache_size/T8) |

###### MLP 文件

| model | schema | TP | 行/唯一/重复组/完全重复 | token shape 域 | 四投影 runtime p50范围(ms) | 四投影 CV95 | 四投影最大增/降 |
|---|---|---|---|---|---|---|---|
| Qwen-72B | MLP-58 | 1/2/4/8 | 1,044/1,036/8/0 | token 1–4096(259/TP); step 1/8/32 (min/median/max) | QKV 0.5290–3.6280; O 0.1870–1.3570; Up 0.8630–7.2400; Down 0.4880–3.9710 | QKV 5.35%; O 2.23%; Up 2.12%; Down 2.80% | +179.9%(mlp_down_proj/num_tokens/T1); −33.3%(attn_pre_proj/num_tokens/T8) |
| CodeLlama-34B | MLP-58 | 1/2/4/8 | 1,044/1,036/8/0 | token 1–4096(259/TP); step 1/8/32 (min/median/max) | QKV 0.2550–1.5865; O 0.1830–1.3450; Up 0.9860–6.4795; Down 0.4290–3.5370 | QKV 1.98%; O 2.05%; Up 2.10%; Down 2.05% | +95.6%(mlp_down_proj/num_tokens/T1); −31.7%(mlp_down_proj/num_tokens/T4) |
| InternLM-20B | MLP-58 | 1/2/4/8 | 1,044/1,036/8/0 | token 1–4096(259/TP); step 1/8/32 (min/median/max) | QKV 0.2480–1.5175; O 0.0720–0.5110; Up 0.3380–2.6830; Down 0.1510–1.2100 | QKV 1.49%; O 1.77%; Up 1.35%; Down 1.80% | +98.0%(attn_pre_proj/num_tokens/T4); −34.6%(attn_pre_proj/num_tokens/T8) |
| Llama2-70B | MLP-58 | 1/2/4/8 | 1,044/1,036/8/0 | token 1–4096(259/TP); step 1/8/32 (min/median/max) | QKV 0.2600–1.5955; O 0.1870–1.3575; Up 1.0330–8.5275; Down 0.5655–4.6080 | QKV 2.17%; O 2.08%; Up 2.22%; Down 2.12% | +123.4%(mlp_down_proj/num_tokens/T1); −33.0%(mlp_down_proj/num_tokens/T1) |
| Llama2-7B | MLP-58 | 1/2/4/8 | 1,044/1,036/8/0 | token 1–4096(259/TP); step 1/8/32 (min/median/max) | QKV 0.1270–0.8975; O 0.0560–0.3705; Up 0.2470–1.7120; Down 0.1200–0.9510 | QKV 1.53%; O 1.77%; Up 1.13%; Down 2.04% | +96.3%(attn_pre_proj/num_tokens/T2); −35.3%(attn_post_proj/num_tokens/T4) |
| Phi-2 | MLP-53 | 1 | 261/259/2/0 | token 1–4096(259/TP); step 1/8/32 (min/median/max) | QKV 0.4200–0.4200; O 0.1400–0.1400; Up 0.5060–0.5060; Down 0.4840–0.4840 | QKV 2.50%; O 3.59%; Up 2.15%; Down 1.97% | +67.5%(attn_post_proj/num_tokens/T1); −23.9%(attn_post_proj/num_tokens/T1) |

##### H100

###### Attention 文件

| model | schema/backend/maxlen | TP | 行/唯一/重复组/完全重复 | decode shape 与唯一覆盖/TP | prefill shape 与唯一覆盖/TP | target runtime p50范围(ms) | 关键 CV95 | 关键算子最大增/降 |
|---|---|---|---|---|---|---|---|---|
| Qwen-72B | ATT-31/FLASH_ATTENTION/L4096 | 1/2/4/8 | 58,632/57,272/1,344/139 | B1–128(128) × KV32–4032(79); T1:10,112@100.0%/T2:10,112@100.0%/T4:10,112@100.0%/T8:10,112@100.0% | P64–4096(81) × KV0–4032(80); T1:4,206@100.0%/T2:4,206@100.0%/T4:4,206@100.0%/T8:4,206@100.0% | D 0.1150–0.6240; P 0.0880–0.3875 | D 1.84%; P 2.69% | +110.0%(attn_prefill/prefill_chunk_size/T1); −39.2%(attn_prefill/prefill_chunk_size/T2) |
| CodeLlama-34B | ATT-31/FLASH_ATTENTION/L4096 | 1/2/4/8 | 58,632/57,272/1,344/352 | B1–128(128) × KV32–4032(79); T1:10,112@100.0%/T2:10,112@100.0%/T4:10,112@100.0%/T8:10,112@100.0% | P64–4096(81) × KV0–4032(80); T1:4,206@100.0%/T2:4,206@100.0%/T4:4,206@100.0%/T8:4,206@100.0% | D 0.0200–0.1180; P 0.0860–0.3420 | D 3.39%; P 2.11% | +91.8%(attn_prefill/prefill_chunk_size/T1); −34.5%(attn_decode/kv_cache_size/T4) |
| InternLM-20B | ATT-31/FLASH_ATTENTION/L4096 | 1/2/4/8 | 58,632/57,272/1,344/194 | B1–128(128) × KV32–4032(79); T1:10,112@100.0%/T2:10,112@100.0%/T4:10,112@100.0%/T8:10,112@100.0% | P64–4096(81) × KV0–4032(80); T1:4,206@100.0%/T2:4,206@100.0%/T4:4,206@100.0%/T8:4,206@100.0% | D 0.0790–0.4450; P 0.0630–0.2660 | D 2.44%; P 3.03% | +118.8%(attn_decode/batch_size/T2); −34.1%(attn_prefill/kv_cache_size/T8) |
| Llama2-70B | ATT-31/FLASH_ATTENTION/L4096 | 1/2/4/8 | 58,632/57,272/1,344/383 | B1–128(128) × KV32–4032(79); T1:10,112@100.0%/T2:10,112@100.0%/T4:10,112@100.0%/T8:10,112@100.0% | P64–4096(81) × KV0–4032(80); T1:4,206@100.0%/T2:4,206@100.0%/T4:4,206@100.0%/T8:4,206@100.0% | D 0.0200–0.1160; P 0.0860–0.3420 | D 3.39%; P 2.13% | +94.3%(attn_prefill/prefill_chunk_size/T8); −34.5%(attn_decode/kv_cache_size/T8) |
| Llama2-7B | ATT-31/FLASH_ATTENTION/L4096 | 1/2/4/8 | 58,632/57,272/1,344/209 | B1–128(128) × KV32–4032(79); T1:10,112@100.0%/T2:10,112@100.0%/T4:10,112@100.0%/T8:10,112@100.0% | P64–4096(81) × KV0–4032(80); T1:4,206@100.0%/T2:4,206@100.0%/T4:4,206@100.0%/T8:4,206@100.0% | D 0.0640–0.3900; P 0.0590–0.2270 | D 2.55%; P 2.88% | +117.1%(attn_prefill/prefill_chunk_size/T2); −39.6%(attn_prefill/prefill_chunk_size/T8) |
| Phi-2 | ATT-31/FLASH_ATTENTION/L4096 | 1/2/4/8 | 58,632/57,272/1,344/273 | B1–128(128) × KV32–4032(79); T1:10,112@100.0%/T2:10,112@100.0%/T4:10,112@100.0%/T8:10,112@100.0% | P64–4096(81) × KV0–4032(80); T1:4,206@100.0%/T2:4,206@100.0%/T4:4,206@100.0%/T8:4,206@100.0% | D 0.0560–0.3380; P 0.0530–0.1985 | D 2.98%; P 2.40% | +119.6%(attn_prefill/prefill_chunk_size/T8); −34.8%(attn_prefill/prefill_chunk_size/T8) |

###### MLP 文件

| model | schema | TP | 行/唯一/重复组/完全重复 | token shape 域 | 四投影 runtime p50范围(ms) | 四投影 CV95 | 四投影最大增/降 |
|---|---|---|---|---|---|---|---|
| Qwen-72B | MLP-58 | 1/2/4/8 | 1,044/1,036/8/0 | token 1–4096(259/TP); step 1/8/32 (min/median/max) | QKV 0.0890–0.6485; O 0.0340–0.2570; Up 0.1700–1.1995; Down 0.0780–0.7515 | QKV 8.50%; O 6.14%; Up 6.32%; Down 7.92% | +182.5%(mlp_down_proj/num_tokens/T1); −37.4%(mlp_down_proj/num_tokens/T2) |
| CodeLlama-34B | MLP-58 | 1/2/4/8 | 1,044/1,036/8/0 | token 1–4096(259/TP); step 1/8/32 (min/median/max) | QKV 0.0460–0.2710; O 0.0350–0.2530; Up 0.1485–1.0760; Down 0.0810–0.6570 | QKV 11.14%; O 6.75%; Up 9.83%; Down 8.21% | +177.8%(mlp_down_proj/num_tokens/T2); −37.3%(mlp_down_proj/num_tokens/T1) |
| InternLM-20B | MLP-58 | 1/2/4/8 | 1,044/1,036/8/0 | token 1–4096(259/TP); step 1/8/32 (min/median/max) | QKV 0.0460–0.2350; O 0.0175–0.0835; Up 0.0560–0.4625; Down 0.0355–0.2000 | QKV 11.92%; O 8.25%; Up 7.22%; Down 8.84% | +116.9%(attn_pre_proj/num_tokens/T1); −39.8%(attn_pre_proj/num_tokens/T1) |
| Llama2-70B | MLP-58 | 1/2/4/8 | 1,044/1,036/8/0 | token 1–4096(259/TP); step 1/8/32 (min/median/max) | QKV 0.0460–0.2825; O 0.0340–0.2550; Up 0.1905–1.3835; Down 0.0880–0.8405 | QKV 8.03%; O 7.27%; Up 7.12%; Down 9.83% | +167.9%(mlp_down_proj/num_tokens/T2); −39.0%(mlp_down_proj/num_tokens/T1) |
| Llama2-7B | MLP-58 | 1/2/4/8 | 1,044/1,036/8/0 | token 1–4096(259/TP); step 1/8/32 (min/median/max) | QKV 0.0270–0.1680; O 0.0130–0.0520; Up 0.0460–0.2705; Down 0.0225–0.1275 | QKV 11.60%; O 9.82%; Up 11.91%; Down 11.40% | +77.5%(mlp_up_proj/num_tokens/T1); −40.6%(mlp_up_proj/num_tokens/T8) |
| Phi-2 | MLP-53 | 1 | 261/259/2/0 | token 1–4096(259/TP); step 1/8/32 (min/median/max) | QKV 0.0840–0.0840; O 0.0310–0.0310; Up 0.1010–0.1010; Down 0.1010–0.1010 | QKV 12.87%; O 15.63%; Up 14.89%; Down 7.71% | +57.7%(mlp_up_proj/num_tokens/T1); −28.1%(mlp_up_proj/num_tokens/T1) |

#### C. 逐文件表的直接观察

1. 三种 GPU 上的 6 个共同旧模型 attention 文件均为 58,632 行、57,272 个唯一 shape、1,344 个重复 shape 组；MLP 除 Phi-2 外均为 1,044 行、1,036 个唯一 shape。说明主要网格由采样程序决定，而非模型尺寸决定。
2. 完全重复行只出现在 attention：H100 attention 为 1,550 行，显著高于 A100 的 1,153 和 A40 的 405。结合 1 µs 量化，这更像重复 profile 在离散时间格上碰到同值，而不是 H100 shape 更多。
3. 旧 attention 每 TP 的 decode 是 10,112 个唯一点；prefill 是 4,206 个有效三角网格点。Llama3 decode 受显存过滤，coverage 随 TP 增大；Llama3 prefill 每 TP 2,371 点，是当前整数倍 KV 采样器的结构化稀疏网格。
4. A100 Llama3 MLP 把 token 域扩展到 32,768；attention 则 max_model_len=16,384。不能用单一 `max shape` 描述整个模型文件对。
5. H100 MLP 的四个矩阵投影 CV95 普遍高于 A100/A40；这既可能包含更短 kernel 的绝对量化效应，也可能包含 kernel 选择/调度波动。没有 run/worker/时钟元数据，不能进一步归因。

##### 硬异常与 schema 语义

| 文件 | 检查项 | 行数 |
|---|---|---|
| a100\Qwen\Qwen-72B\attention.csv | attn_decode:zero_median_positive_mean | 16 |

A100/Qwen-72B/TP1 的 16 个 decode 点为 `median=0, mean>0`，会在表中产生 100% 最大下降；这是应重测/剔除的标签异常。Llama3 的 inactive-phase target 列存在但值为 0，被归类为 schema语义而非硬错误。

#### D. 跨 GPU：严格精确 shape 交集

speedup 定义为 `from_gpu median runtime / to_gpu median runtime`；大于 1 表示目标 GPU 更快。连接键严格包含 model、TP、backend、完整 shape 和 operator。只有 6 个共同旧模型进入跨 GPU 表；Llama3 没有 A40/H100 数据。每个 cell 先对其精确 shape 交集取 speedup p50，再在 compact 表中对 model×TP cell 取中位数。

| 比较 | operator | 模型 | model×TP cell | shape交集总数 | cell-p50中位数[min,max] | 目标GPU更慢shape占比 |
|---|---|---|---|---|---|---|
| A40→A100 | attn_decode | 6 | 24 | 242,672 | 2.583× [2.091, 3.206] | 2.242% |
| A40→A100 | attn_prefill | 6 | 24 | 100,944 | 1.849× [1.352, 2.153] | 2.453% |
| A40→A100 | attn_pre_proj | 6 | 21 | 5,439 | 1.969× [1.899, 2.143] | 0.000% |
| A40→A100 | attn_post_proj | 6 | 21 | 5,439 | 1.994× [1.877, 2.071] | 0.000% |
| A40→A100 | mlp_up_proj | 6 | 21 | 5,439 | 2.015× [1.934, 2.201] | 0.000% |
| A40→A100 | mlp_down_proj | 6 | 21 | 5,439 | 2.015× [1.893, 2.107] | 0.037% |
| A100→H100 | attn_decode | 6 | 24 | 242,672 | 1.690× [1.568, 1.798] | 0.003% |
| A100→H100 | attn_prefill | 6 | 24 | 100,944 | 1.497× [1.270, 1.703] | 0.293% |
| A100→H100 | attn_pre_proj | 6 | 21 | 5,439 | 2.800× [2.324, 3.111] | 0.000% |
| A100→H100 | attn_post_proj | 6 | 21 | 5,439 | 2.865× [2.000, 3.155] | 0.000% |
| A100→H100 | mlp_up_proj | 6 | 21 | 5,439 | 2.827× [2.392, 2.990] | 0.000% |
| A100→H100 | mlp_down_proj | 6 | 21 | 5,439 | 2.923× [2.350, 3.224] | 0.000% |
| A40→H100 | attn_decode | 6 | 24 | 242,688 | 4.385× [3.529, 5.800] | 0.030% |
| A40→H100 | attn_prefill | 6 | 24 | 100,944 | 2.800× [1.769, 3.671] | 0.089% |
| A40→H100 | attn_pre_proj | 6 | 21 | 5,439 | 5.592× [4.598, 6.225] | 0.000% |
| A40→H100 | attn_post_proj | 6 | 21 | 5,439 | 5.566× [3.917, 5.862] | 0.000% |
| A40→H100 | mlp_up_proj | 6 | 21 | 5,439 | 5.699× [4.986, 6.136] | 0.000% |
| A40→H100 | mlp_down_proj | 6 | 21 | 5,439 | 6.000× [4.698, 6.439] | 0.000% |

##### 模型级 speedup p50 的 TP 向量

###### A40 → A100

| model | decode | prefill | QKV proj | O proj | MLP up | MLP down |
|---|---|---|---|---|---|---|
| CodeLlama-34B | T1:2.58×/T2:2.37×/T4:2.14×/T8:2.09× | T1:1.98×/T2:1.88×/T4:1.80×/T8:1.66× | T1:1.91×/T2:1.91×/T4:1.92×/T8:1.98× | T1:2.01×/T2:1.88×/T4:1.90×/T8:2.00× | T1:1.96×/T2:2.16×/T4:2.19×/T8:2.08× | T1:2.09×/T2:1.99×/T4:2.11×/T8:1.89× |
| InternLM-20B | T1:2.81×/T2:2.77×/T4:2.64×/T8:2.42× | T1:2.13×/T2:2.00×/T4:1.82×/T8:1.68× | T1:2.08×/T2:2.13×/T4:2.14×/T8:2.02× | T1:1.91×/T2:1.89×/T4:2.04×/T8:2.00× | T1:2.03×/T2:2.20×/T4:2.15×/T8:2.06× | T1:1.96×/T2:1.99×/T4:1.92×/T8:2.01× |
| Llama2-70B | T1:2.58×/T2:2.37×/T4:2.14×/T8:2.09× | T1:1.98×/T2:1.88×/T4:1.80×/T8:1.66× | T1:1.92×/T2:1.91×/T4:1.91×/T8:1.97× | T1:2.00×/T2:1.88×/T4:1.89×/T8:2.00× | T1:1.95×/T2:1.93×/T4:1.96×/T8:1.96× | T1:2.08×/T2:2.01×/T4:2.05×/T8:1.92× |
| Llama2-7B | T1:2.85×/T2:2.76×/T4:2.59×/T8:2.37× | T1:2.13×/T2:1.93×/T4:1.73×/T8:1.49× | T1:1.94×/T2:1.93×/T4:2.10×/T8:1.97× | T1:2.07×/T2:2.05×/T4:2.06×/T8:2.03× | T1:2.02×/T2:2.01×/T4:2.02×/T8:2.06× | T1:2.10×/T2:2.08×/T4:2.01×/T8:1.98× |
| Phi-2 | T1:3.21×/T2:3.11×/T4:2.91×/T8:2.57× | T1:1.90×/T2:1.74×/T4:1.57×/T8:1.35× | T1:1.97× | T1:1.97× | T1:1.94× | T1:2.05× |
| Qwen-72B | T1:2.40×/T2:2.81×/T4:2.75×/T8:2.58× | T1:2.15×/T2:2.12×/T4:1.93×/T8:1.73× | T1:1.98×/T2:1.98×/T4:1.90×/T8:1.98× | T1:1.97×/T2:1.88×/T4:1.88×/T8:1.99× | T1:1.95×/T2:1.95×/T4:2.11×/T8:2.01× | T1:2.07×/T2:2.05×/T4:2.10×/T8:1.89× |

###### A100 → H100

| model | decode | prefill | QKV proj | O proj | MLP up | MLP down |
|---|---|---|---|---|---|---|
| CodeLlama-34B | T1:1.69×/T2:1.69×/T4:1.72×/T8:1.57× | T1:1.54×/T2:1.50×/T4:1.45×/T8:1.42× | T1:2.89×/T2:2.85×/T4:2.72×/T8:2.40× | T1:2.88×/T2:3.16×/T4:2.92×/T8:2.66× | T1:2.94×/T2:2.93×/T4:2.81×/T8:2.61× | T1:2.86×/T2:3.01×/T4:3.11×/T8:3.15× |
| InternLM-20B | T1:1.69×/T2:1.69×/T4:1.68×/T8:1.63× | T1:1.66×/T2:1.60×/T4:1.51×/T8:1.36× | T1:3.03×/T2:2.94×/T4:2.47×/T8:2.32× | T1:2.96×/T2:2.88×/T4:2.46×/T8:2.25× | T1:2.91×/T2:2.81×/T4:2.39×/T8:2.40× | T1:3.00×/T2:3.02×/T4:2.80×/T8:2.50× |
| Llama2-70B | T1:1.69×/T2:1.69×/T4:1.73×/T8:1.57× | T1:1.54×/T2:1.50×/T4:1.45×/T8:1.42× | T1:2.89×/T2:2.82×/T4:2.75×/T8:2.41× | T1:2.87×/T2:3.13×/T4:2.97×/T8:2.67× | T1:2.93×/T2:2.95×/T4:2.93×/T8:2.83× | T1:2.85×/T2:2.92×/T4:3.12×/T8:3.22× |
| Llama2-7B | T1:1.73×/T2:1.71×/T4:1.69×/T8:1.70× | T1:1.59×/T2:1.61×/T4:1.48×/T8:1.33× | T1:3.11×/T2:2.80×/T4:2.46×/T8:2.33× | T1:2.82×/T2:2.54×/T4:2.23×/T8:2.00× | T1:2.99×/T2:2.83×/T4:2.65×/T8:2.50× | T1:2.98×/T2:2.80×/T4:2.70×/T8:2.35× |
| Phi-2 | T1:1.80×/T2:1.77×/T4:1.70×/T8:1.63× | T1:1.53×/T2:1.47×/T4:1.42×/T8:1.27× | T1:2.75× | T1:2.65× | T1:2.83× | T1:2.65× |
| Qwen-72B | T1:1.70×/T2:1.68×/T4:1.68×/T8:1.68× | T1:1.70×/T2:1.60×/T4:1.60×/T8:1.48× | T1:2.82×/T2:2.85×/T4:2.84×/T8:2.78× | T1:2.86×/T2:3.09×/T4:3.00×/T8:2.82× | T1:2.94×/T2:2.94×/T4:2.94×/T8:2.61× | T1:2.85×/T2:2.91×/T4:3.10×/T8:3.22× |

###### A40 → H100

| model | decode | prefill | QKV proj | O proj | MLP up | MLP down |
|---|---|---|---|---|---|---|
| CodeLlama-34B | T1:4.38×/T2:4.09×/T4:3.98×/T8:3.53× | T1:3.08×/T2:2.84×/T4:2.61×/T8:2.36× | T1:5.73×/T2:5.61×/T4:5.48×/T8:4.67× | T1:5.77×/T2:5.79×/T4:5.59×/T8:5.35× | T1:5.78×/T2:6.14×/T4:5.99×/T8:5.63× | T1:5.82×/T2:6.05×/T4:6.41×/T8:6.17× |
| InternLM-20B | T1:4.78×/T2:4.67×/T4:4.42×/T8:4.14× | T1:3.53×/T2:3.17×/T4:2.75×/T8:2.38× | T1:6.22×/T2:5.98×/T4:5.67×/T8:4.81× | T1:5.57×/T2:5.25×/T4:4.69×/T8:4.31× | T1:5.92×/T2:5.72×/T4:5.26×/T8:4.99× | T1:5.89×/T2:6.14×/T4:5.22×/T8:4.70× |
| Llama2-70B | T1:4.38×/T2:4.10×/T4:4.00×/T8:3.53× | T1:3.09×/T2:2.85×/T4:2.62×/T8:2.36× | T1:5.65×/T2:5.59×/T4:5.53×/T8:4.73× | T1:5.76×/T2:5.77×/T4:5.58×/T8:5.44× | T1:5.69×/T2:5.72×/T4:5.70×/T8:5.54× | T1:5.90×/T2:6.00×/T4:6.31×/T8:6.26× |
| Llama2-7B | T1:4.92×/T2:4.69×/T4:4.40×/T8:4.11× | T1:3.43×/T2:3.13×/T4:2.59×/T8:2.02× | T1:5.97×/T2:5.53×/T4:5.22×/T8:4.60× | T1:5.86×/T2:5.26×/T4:4.59×/T8:3.92× | T1:6.12×/T2:6.06×/T4:5.48×/T8:5.09× | T1:6.06×/T2:5.89×/T4:5.22×/T8:4.70× |
| Phi-2 | T1:5.80×/T2:5.44×/T4:4.96×/T8:4.39× | T1:2.93×/T2:2.63×/T4:2.20×/T8:1.77× | T1:5.72× | T1:5.09× | T1:5.63× | T1:5.42× |
| Qwen-72B | T1:4.10×/T2:4.72×/T4:4.61×/T8:4.38× | T1:3.67×/T2:3.41×/T4:3.13×/T8:2.60× | T1:5.47×/T2:5.61×/T4:5.54×/T8:5.78× | T1:5.68×/T2:5.74×/T4:5.63×/T8:5.55× | T1:5.70×/T2:5.73×/T4:5.97×/T8:5.52× | T1:5.98×/T2:6.10×/T4:6.44×/T8:6.27× |

旧 attention 正常 cell 的交集通常为 decode 10,112 shape/TP、prefill 4,206 shape/TP；A100/Qwen-72B/TP1 的 16 个零 median 会因 `runtime>0` 过滤而使相关 decode 交集降为 10,096。MLP 通常为 259 shape/TP；Phi-2 只有 TP1。A40→A100 的部分 attention shape speedup<1，说明跨 GPU 优势不是每个 shape 都一致；不能只用一个总体平均数覆盖局部 regime。

#### E. TP compute-only 扩展

TP speedup 定义为同 GPU/model/operator/外部 shape 下 `TP1 runtime / TPn runtime`。以下 compact 值是各模型 cell-p50 的中位数，方括号给出模型间 min/max，η 为 `speedup/TP`。它只包含单卡上被 profile 的局部 compute operator，不包含 all-reduce、跨卡链路、同步、CPU launch、调度、显存争用或整层串并行，因此不是端到端 TP speedup。

##### A100 TP 扩展

| operator | 模型数(max) | TP2 speedup[min,max];η | TP4 speedup[min,max];η | TP8 speedup[min,max];η | 最坏 slower-than-TP1 占比 |
|---|---|---|---|---|---|
| attn_decode | 8 | 1.80× [1.73,1.87]; η89.8% | 3.25× [3.04,3.50]; η81.2% | 5.61× [5.39,6.24]; η70.2% | 0.017% |
| attn_prefill | 8 | 1.78× [1.72,1.87]; η89.1% | 2.96× [2.80,3.26]; η73.9% | 4.45× [4.05,5.26]; η55.6% | 0.268% |
| attn_pre_proj | 7 | 2.00× [1.98,2.05]; η100.0% | 3.87× [3.81,4.18]; η96.7% | 7.41× [7.20,7.94]; η92.6% | 0.000% |
| attn_post_proj | 7 | 1.90× [1.85,1.95]; η95.2% | 3.75× [3.67,3.94]; η93.8% | 7.54× [6.37,7.64]; η94.2% | 0.000% |
| mlp_up_proj | 7 | 2.01× [1.88,2.02]; η100.6% | 4.04× [3.84,4.13]; η100.9% | 8.02× [7.11,8.36]; η100.2% | 0.000% |
| mlp_down_proj | 7 | 2.00× [1.98,2.06]; η100.0% | 4.03× [3.98,4.11]; η100.7% | 7.48× [7.21,8.01]; η93.6% | 0.000% |

##### A40 TP 扩展

| operator | 模型数(max) | TP2 speedup[min,max];η | TP4 speedup[min,max];η | TP8 speedup[min,max];η | 最坏 slower-than-TP1 占比 |
|---|---|---|---|---|---|
| attn_decode | 6 | 1.89× [1.58,1.93]; η94.7% | 3.66× [2.76,3.77]; η91.6% | 6.76× [5.09,7.52]; η84.4% | 0.000% |
| attn_prefill | 6 | 1.88× [1.87,1.90]; η94.2% | 3.42× [3.35,3.52]; η85.4% | 5.77× [5.44,6.54]; η72.1% | 0.182% |
| attn_pre_proj | 5 | 2.02× [2.01,2.04]; η101.1% | 3.86× [3.82,3.99]; η96.6% | 7.38× [7.01,7.72]; η92.3% | 0.000% |
| attn_post_proj | 5 | 1.98× [1.96,2.00]; η99.2% | 3.89× [3.68,3.91]; η97.2% | 7.37× [6.31,7.48]; η92.2% | 0.000% |
| mlp_up_proj | 5 | 1.96× [1.91,2.02]; η97.8% | 3.93× [3.71,3.96]; η98.2% | 7.71× [7.52,8.10]; η96.3% | 0.000% |
| mlp_down_proj | 5 | 2.02× [1.98,2.04]; η100.8% | 4.02× [4.00,4.03]; η100.4% | 8.05× [7.77,8.17]; η100.6% | 0.000% |

##### H100 TP 扩展

| operator | 模型数(max) | TP2 speedup[min,max];η | TP4 speedup[min,max];η | TP8 speedup[min,max];η | 最坏 slower-than-TP1 占比 |
|---|---|---|---|---|---|
| attn_decode | 6 | 1.82× [1.72,1.87]; η90.9% | 3.32× [3.06,3.40]; η83.1% | 5.57× [5.30,6.11]; η69.7% | 0.053% |
| attn_prefill | 6 | 1.73× [1.69,1.78]; η86.5% | 2.77× [2.56,3.01]; η69.2% | 4.07× [3.47,4.63]; η50.9% | 0.396% |
| attn_pre_proj | 5 | 1.97× [1.89,2.05]; η98.7% | 3.66× [3.29,3.95]; η91.5% | 6.26× [5.61,7.45]; η78.2% | 0.000% |
| attn_post_proj | 5 | 1.98× [1.73,2.01]; η98.8% | 3.81× [2.82,3.83]; η95.2% | 7.30× [4.26,7.50]; η91.3% | 0.000% |
| mlp_up_proj | 5 | 2.02× [1.93,2.04]; η101.0% | 3.91× [3.53,4.10]; η97.8% | 7.37× [6.06,7.81]; η92.1% | 0.000% |
| mlp_down_proj | 5 | 2.04× [1.92,2.05]; η101.9% | 4.22× [3.43,4.41]; η105.6% | 8.56× [5.67,8.81]; η106.9% | 0.000% |

TP 解释要点：

- MLP 大矩阵投影通常接近线性，个别 compact 中位数略超线性（例如 H100 `mlp_down_proj` TP8），更可能来自 kernel/tiling regime 和固定开销摊薄，不能解释为总系统超线性扩展。
- attention 扩展弱于 MLP，尤其 prefill：TP 增大时固定开销、KV 访问和注意力 kernel 的非矩阵部分不会同比缩小。
- Llama3 decode 的 shape 集随 TP 改变且受显存过滤。原始 TP 表只连接共同 shape，因而估计的是交集条件下的 compute scaling，不代表各 TP 可服务域的总体分布。
- Phi-2 MLP 配置为 `no_tensor_parallel`，不会进入 TP2/4/8 统计；模型数差异不是缺值填零。

#### F. 最大 work-normalized 局部跳变示例

下面从已有 `top_local_jumps.csv` 选取关键算子、两点均 ≥0.01 ms、work ratio≤1.25 的最高 `abs(log(runtime_ratio/work_ratio))` 记录。该筛选排除了 Llama3 稀疏曲线中的超大横轴跳跃，更接近工程上希望复测的局部边界。

| GPU | model | TP | operator | axis | 固定条件 | shape变化 | runtime(ms) | 变化 | work比 | 超额比 |
|---|---|---|---|---|---|---|---|---|---|---|
| H100 | Qwen-72B | T1 | mlp_down_proj | num_tokens | — | 512→520 | 0.2310→0.6525 | 182.5% | 1.016 | 2.781 |
| H100 | CodeLlama-34B | T2 | mlp_down_proj | num_tokens | — | 512→520 | 0.1150→0.3195 | 177.8% | 1.016 | 2.736 |
| A40 | Qwen-72B | T1 | mlp_down_proj | num_tokens | — | 256→264 | 1.0430→2.9190 | 179.9% | 1.031 | 2.714 |
| H100 | Llama2-70B | T2 | mlp_down_proj | num_tokens | — | 512→520 | 0.1400→0.3750 | 167.9% | 1.016 | 2.637 |
| H100 | Llama2-70B | T1 | mlp_down_proj | num_tokens | — | 512→520 | 0.2690→0.6895 | 156.3% | 1.016 | 2.524 |
| A40 | Llama2-70B | T1 | attn_prefill | kv_cache_size | B=1,P=64 | 448→480 | 0.0300→0.0800 | 166.7% | 1.062 | 2.510 |
| H100 | CodeLlama-34B | T1 | mlp_down_proj | num_tokens | — | 512→520 | 0.2250→0.5730 | 154.7% | 1.016 | 2.507 |
| A40 | CodeLlama-34B | T1 | attn_prefill | kv_cache_size | B=1,P=64 | 448→480 | 0.0310→0.0810 | 161.3% | 1.062 | 2.459 |
| A40 | CodeLlama-34B | T2 | attn_prefill | kv_cache_size | B=1,P=128 | 384→416 | 0.0270→0.0700 | 159.3% | 1.062 | 2.440 |
| H100 | Qwen-72B | T2 | mlp_down_proj | num_tokens | — | 512→520 | 0.1230→0.2950 | 139.8% | 1.016 | 2.361 |
| A40 | Llama2-70B | T2 | attn_prefill | kv_cache_size | B=1,P=128 | 384→416 | 0.0280→0.0700 | 150.0% | 1.062 | 2.353 |
| A40 | CodeLlama-34B | T2 | attn_prefill | kv_cache_size | B=1,P=128 | 640→672 | 0.0840→0.0385 | -54.2% | 1.042 | 0.440 |
| A40 | Phi-2 | T8 | attn_prefill | kv_cache_size | B=1,P=128 | 3840→3904 | 0.0590→0.0265 | -55.1% | 1.016 | 0.442 |
| A40 | Llama2-70B | T2 | attn_prefill | kv_cache_size | B=1,P=128 | 640→672 | 0.0845→0.0390 | -53.8% | 1.042 | 0.443 |
| A40 | Llama2-7B | T2 | attn_prefill | prefill_chunk_size | B=1,KV=480 | 256→288 | 0.1090→0.0570 | -47.7% | 1.174 | 0.445 |
| A40 | Qwen-72B | T4 | attn_prefill | prefill_chunk_size | B=1,KV=480 | 256→288 | 0.1090→0.0570 | -47.7% | 1.174 | 0.445 |
| A40 | CodeLlama-34B | T2 | attn_prefill | kv_cache_size | B=1,P=112 | 384→416 | 0.0270→0.0640 | 137.0% | 1.065 | 2.227 |
| A40 | Llama2-70B | T2 | attn_prefill | kv_cache_size | B=1,P=112 | 384→416 | 0.0270→0.0640 | 137.0% | 1.065 | 2.227 |
| A40 | Llama2-70B | T2 | attn_prefill | prefill_chunk_size | B=1,KV=672 | 96→112 | 0.0710→0.0380 | -46.5% | 1.191 | 0.449 |
| A40 | CodeLlama-34B | T2 | attn_prefill | prefill_chunk_size | B=1,KV=672 | 96→112 | 0.0710→0.0380 | -46.5% | 1.191 | 0.449 |

#### G. 可比性矩阵与引用边界

| 比较 | 是否可比 | 必要条件/限制 |
|---|---|---|
| 同文件相邻 shape | 条件可比 | 固定 TP/backend/其余 shape；检查步长，重复 shape 先聚合；不强制单调 |
| 同文件重复 shape | 可比 | 可估计重复测量差异；但重复多来自网格边界构造，非独立随机 run |
| A40/A100/H100 | 条件可比 | 仅 6 个共同模型、同 TP/backend/operator/精确 shape；环境版本和时钟元数据缺失 |
| Llama3 与旧模型 attention | 不可直接比较 | FLASHINFER vs FLASH_ATTENTION、schema、maxlen、采样器和 shape 域同时变化 |
| 不同模型绝对时延 | 不可直接比较 | hidden/head/KV-head/MLP width/vocab/gating 均改变工作量 |
| TP1 vs TPn compute | 条件可比 | 只比较共同外部 shape 的局部算子；不含通信，且可服务 shape 域可能不同 |
| compute TP vs 端到端吞吐 | 不可替代 | 缺少 collective、同步、CPU、scheduler、pipeline 和内存竞争 |
| 微秒级算子百分比 | 谨慎 | attention 1 µs、MLP 0.5 µs 量化；必须同时引用绝对 ms/us |
| inactive phase target | 不可当测量 | 旧 schema 为 NaN；Llama3 为 0；KV-save 在旧 schema 中不存在 |

#### H. 面向昇腾 NPU 的直接实验含义

1. GPU 数据已经展示明显分段和 shape 局部跳变；NPU 上编译器搬运策略、tiling、指令流水与 workspace 切换更可能产生离散 regime。因此应学习 `regime + regime 内残差`，而不是假定全局光滑。
2. 采样不能只沿 Vidur 的多分辨率主网格。对每个候选边界补 `x−2,x−1,x,x+1,x+2`，并在二维 attention shape 上补交叉邻域；否则 RF 只能在未观测断点两侧做阶梯插值。
3. 每个 shape 至少保留独立进程、独立编译和热 cache 三类重复；记录 compile cache hit、tiling/kernel ID、workspace、搬运路径、并行策略、DVFS/温度。只有这些离散标签才能把“可学习”从记忆噪声变成 regime 识别。
4. 评估必须按完整 shape 分组，并增加连续区间、边界邻域、未见 tiling ID、未见 TP/backend 的 OOD holdout。随机拆重复行会严重高估精度。
5. 标签应同时保存 median、p90/p95、CV、失败/超时/编译回退状态；对于计时分辨率附近的小算子，优先预测聚合段或整算子链，而非放大相对误差。

#### I. 机器证据索引

本附录直接使用：`file_inventory.csv`、`shape_coverage.csv`、`within_row_jitter.csv`、`operator_runtime_summary.csv`、`monotonicity_summary.csv`、`top_local_jumps.csv`、`cross_gpu_speedup_summary.csv`、`compact_cross_gpu_speedup.csv`、`compact_tp_compute_scaling.csv`、`invariant_violations.csv`、`compact_timing_quantization.csv`。这些文件位于 compute agent 的 `artifacts/` 目录。

复算说明：跨 GPU speedup 和 TP scaling 都先对重复 exact shape 取 median；跨 GPU 只做精确 shape inner join；TP 以 TP1 为基线。compact 表中的“中位数”是 model×TP cell 的描述性中位数，不是把所有原始 shape 混合后的 pooled estimate。

## 第三部分：Network 与 workload 深度审计

![Network 分组性能](figures/network_performance.png)

### Vidur workload 与 network profiling 数据审计

本报告由 `analyze_network_workloads.py` 从官方仓库 CSV 只读生成。统计对象为 `data/processed_traces` 与 `data/profiling/network` 下的全部 CSV；未修改源文件。

#### 1. 结论摘要

- 共审计 13 个 CSV：3 个 processed workload、10 个 network 目录文件。
- 当前仓库的三个 processed workload 是 Arxiv summarization、Splitwise code、Splitwise conversation；它们并不是论文 Table 1 的 Chat-1M/Arxiv-4K/BWB-4K 三件套，尤其仓库没有 BWB processed trace。
- `a40_pairwise_nvlink/attention.csv` 是 compute-attention 数据误放在 network 目录，不能作为 collective profile 使用。
- 标准 collective CSV 只有 rank 0 的三次重复统计，足以做单点中位数插值，但无法验证 rank 间不对称；三次重复也不足以稳定刻画尾部。
- `h100_pairwise_nvlink/send_recv.csv` 与 `a100_pairwise_nvlink/send_recv.csv` 字节级完全相同，不能据此声称 H100 与 A100 的 send/recv 实测一致。
- A40 目录缺 all-reduce，H100 DGX all-reduce 的 world-size 覆盖也明显窄于 A100；模拟器对缺失配置没有可靠实测支撑。

#### 2. 数据资产与质量

| 类别 | 路径 | 行 | 列 | 字节 | 缺失单元格 | 重复行（去 index） |
|---|---|---|---|---|---|---|
| network | profiling/network/a100_dgx/all_reduce.csv | 6958 | 12 | 652149 | 0 | 0 |
| network | profiling/network/a100_dgx/send_recv.csv | 1988 | 12 | 178780 | 0 | 1 |
| network | profiling/network/a100_pairwise_nvlink/all_reduce.csv | 4496 | 12 | 424946 | 0 | 0 |
| network | profiling/network/a100_pairwise_nvlink/send_recv.csv | 1988 | 12 | 182593 | 0 | 0 |
| network | profiling/network/a40_pairwise_nvlink/attention.csv | 136750 | 50 | 32611944 | 2235600 | 479 |
| network | profiling/network/a40_pairwise_nvlink/send_recv.csv | 1988 | 12 | 183039 | 0 | 0 |
| network | profiling/network/h100_dgx/all_reduce.csv | 2982 | 12 | 277125 | 0 | 1 |
| network | profiling/network/h100_dgx/send_recv.csv | 1988 | 12 | 179059 | 0 | 0 |
| network | profiling/network/h100_pairwise_nvlink/all_reduce.csv | 1988 | 12 | 181897 | 0 | 0 |
| network | profiling/network/h100_pairwise_nvlink/send_recv.csv | 1988 | 12 | 182593 | 0 | 0 |
| workload | processed_traces/arxiv_summarization_stats_llama2_tokenizer_filtered_v2.csv | 28257 | 4 | 913190 | 0 | 469 |
| workload | processed_traces/splitwise_code.csv | 8819 | 3 | 175015 | 0 | 0 |
| workload | processed_traces/splitwise_conv.csv | 19366 | 3 | 402096 | 0 | 0 |

##### 2.1 Workload schema 与完整性

| workload | 行 | prefill 缺失 | decode 缺失 | prefill<=0 | decode<=0 | 重复行 | total 不一致 | P:D 不一致 |
|---|---|---|---|---|---|---|---|---|
| arxiv_summarization_stats_llama2_tokenizer_filtered_v2 | 28257 | 0 | 0 | 0 | 0 | 469 | 0 | 0 |
| splitwise_code | 8819 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| splitwise_conv | 19366 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |

Arxiv 文件自带 `num_total_tokens` 与 `pd_ratio`，分析脚本逐行用 prefill/decode 重算核对；Splitwise 两个文件另带到达时间。Arxiv 的 469 个重复行只是相同长度/比值元组重复；文件没有 request id 或 arrival time，故不能据此判定为数据损坏，也不能还原请求次序。

#### 3. 三个 workload 的长度与长尾

| workload | 请求数 | P50 prefill | P90 prefill | P99 prefill | max prefill | P50 decode | P90 decode | P99 decode | max decode | P99 total | max total | P:D 中位 |
|---|---|---|---|---|---|---|---|---|---|---|---|---|
| arxiv_summarization_stats_llama2_tokenizer_filtered_v2 | 28257 | 2,730.0000 | 3,702.0000 | 3,933.4400 | 4054 | 167.0000 | 372.0000 | 3,271.3200 | 4056 | 4,077.0000 | 4096 | 15.6907 |
| splitwise_code | 8819 | 1,469.0000 | 5,187.6000 | 7,436.0000 | 7437 | 13.0000 | 55.0000 | 251.4600 | 1899 | 7,461.8200 | 7841 | 91.8125 |
| splitwise_conv | 19366 | 1,020.0000 | 2,734.5000 | 4,142.0000 | 14050 | 129.0000 | 424.0000 | 601.0000 | 1000 | 4,259.0000 | 14089 | 3.5818 |

##### 3.1 分布形态与截断证据

- **Arxiv**：total 最大值恰为 4096，且有 18 条恰好命中 4096；decode P99/P50=19.59，top 1% 请求贡献 12.33% decode tokens。这是经过 4K 过滤/截断的数据，不应视为未裁剪的自然长度分布。
- **Splitwise code**：prefill P50/P99/max=1469/7436/7437，并在 7435/7436/7437 形成明显堆积（103/201/18 条），说明源 trace 存在约 7.44K 的长度上沿；P:D 中位为 91.8，属于极强 prefill-heavy 负载。
- **Splitwise conversation**：prefill P50/P99/max=1020/4142/14050，最大 total=14089；主体在约 4K 内，但存在稀疏超长离群请求。
- 两条 Splitwise trace 的到达时间均单调且无负/零间隔；观测时段分别为 3435.9s/3501.7s，平均 QPS=2.566/5.530。

##### 3.2 Prefill 与 decode 相关性

| workload | Pearson | Spearman |
|---|---|---|
| arxiv_summarization_stats_llama2_tokenizer_filtered_v2 | -0.4631 | -0.1138 |
| splitwise_code | 0.0012 | -0.0215 |
| splitwise_conv | -0.1124 | 0.0728 |

相关性低不等于两个边际分布可独立采样；仿真 trace 应保留原始成对长度，否则会改变 KV-cache 压力和 batch composition。

##### 3.3 对默认 4096-token attention profiling domain 的覆盖

| workload | prefill<=4096 | decode<=4096 | total/context<=4096 |
|---|---|---|---|
| arxiv_summarization_stats_llama2_tokenizer_filtered_v2 | 100.0% | 100.0% | 100.0% |
| splitwise_code | 85.9% | 100.0% | 85.7% |
| splitwise_conv | 97.9% | 100.0% | 91.7% |

`request_total<=4096` 是 attention context 全程不超默认 4096 的保守判据。Arxiv/code/conversation 的 total/context 覆盖率分别为 100.00%/85.75%/91.68%；三者 decode 长度本身均 100% 落在 4096 内。Token-level 每 iteration 总 token 还取决于 scheduler、chunk size 和 batch composition，不能仅由请求长度文件精确推出。

#### 4. Network profile 覆盖与性能

| 目录 | profile | 行 | world sizes | devices/node | min bytes | max bytes | size 点数 | CV>20% 行 |
|---|---|---|---|---|---|---|---|---|
| a100_dgx | all_reduce | 6958 | 2,4,8,16 | 1,2,4,8 | 2,048.0000 | 67,108,864.0000 | 993.0000 | 174.0000 |
| a100_dgx | send_recv | 1988 | 2 | 1,2 | 2,048.0000 | 67,108,864.0000 | 993.0000 | 12.0000 |
| a100_pairwise_nvlink | all_reduce | 4496 | 2,4 | 2,4 | 2,048.0000 | 536,373,250.0000 | 2,247.0000 | 65.0000 |
| a100_pairwise_nvlink | send_recv | 1988 | 2 | 1,2 | 2,048.0000 | 67,108,864.0000 | 993.0000 | 70.0000 |
| a40_pairwise_nvlink | attention_compute | 136750 |  |  | NA | NA | NA | NA |
| a40_pairwise_nvlink | send_recv | 1988 | 2 | 1,2 | 2,048.0000 | 67,108,864.0000 | 993.0000 | 14.0000 |
| h100_dgx | all_reduce | 2982 | 2,4,8 | 2,4,8 | 2,048.0000 | 67,108,864.0000 | 993.0000 | 155.0000 |
| h100_dgx | send_recv | 1988 | 2 | 1,2 | 2,048.0000 | 67,108,864.0000 | 993.0000 | 85.0000 |
| h100_pairwise_nvlink | all_reduce | 1988 | 2,4 | 2,4 | 2,048.0000 | 67,108,864.0000 | 993.0000 | 36.0000 |
| h100_pairwise_nvlink | send_recv | 1988 | 2 | 1,2 | 2,048.0000 | 67,108,864.0000 | 993.0000 | 70.0000 |

`size` 是代码写出的字节数。下述带宽为 `size / median_latency` 的 payload-equivalent GB/s；all-reduce 的 ring bus 带宽只作为带明确假设的辅助列，不能等同 NCCL 实际算法带宽。P95 是对采样网格点求分位数，不是按真实 message-size workload 加权后的 P95；网格在不同 size 区间的密度也不同。

##### 4.1 分组延迟、带宽与抖动

| group | size 点 | <=64KiB 延迟中位 ms | payload BW P95 GB/s | 大消息 BW 中位 GB/s | 单点 CV P95 | 非单调下降 | 跳变候选 |
|---|---|---|---|---|---|---|---|
| a100_dgx/all_reduce/w2/dpn1 | 993 | 0.0500 | 5.8649 | 5.8574 | 0.0214 | 1 | 0 |
| a100_dgx/all_reduce/w2/dpn2 | 993 | 0.0460 | 153.1821 | 153.1825 | 0.1584 | 3 | 4 |
| a100_dgx/all_reduce/w4/dpn2 | 993 | 0.0615 | 7.0435 | 3.9234 | 0.0199 | 3 | 1 |
| a100_dgx/all_reduce/w4/dpn4 | 993 | 0.0205 | 110.6078 | 110.4502 | 0.3918 | 0 | 0 |
| a100_dgx/all_reduce/w8/dpn4 | 993 | 0.0780 | 12.1709 | 12.1709 | 0.0306 | 2 | 0 |
| a100_dgx/all_reduce/w8/dpn8 | 993 | 0.0325 | 96.0147 | 95.0896 | 0.2093 | 3 | 1 |
| a100_dgx/all_reduce/w16/dpn8 | 993 | 0.0780 | 9.3531 | 9.3442 | 0.0266 | 2 | 1 |
| a100_dgx/send_recv/w2/dpn1 | 993 | 0.0290 | 7.8175 | 7.8012 | 0.0545 | 0 | 1 |
| a100_dgx/send_recv/w2/dpn2 | 993 | 0.0135 | 262.5960 | 226.6238 | 0.0786 | 0 | 0 |
| a100_pairwise_nvlink/all_reduce/w2/dpn2 | 2247 | 0.0505 | 194.6577 | 194.6581 | 0.1030 | 7 | 3 |
| a100_pairwise_nvlink/all_reduce/w4/dpn4 | 2247 | 0.0590 | 15.7909 | 15.7683 | 0.0079 | 0 | 0 |
| a100_pairwise_nvlink/send_recv/w2/dpn1 | 993 | 0.0185 | 7.5941 | 2.3275 | 0.2245 | 60 | 41 |
| a100_pairwise_nvlink/send_recv/w2/dpn2 | 993 | 0.0085 | 335.0088 | 295.2959 | 0.0617 | 0 | 0 |
| a40_pairwise_nvlink/send_recv/w2/dpn1 | 993 | 0.0530 | 3.2645 | 2.3310 | 0.1726 | 2 | 7 |
| a40_pairwise_nvlink/send_recv/w2/dpn2 | 993 | 0.0085 | 4.4036 | 3.9871 | 0.0598 | 0 | 0 |
| h100_dgx/all_reduce/w2/dpn2 | 993 | 0.0210 | 269.9013 | 269.9043 | 0.2897 | 8 | 4 |
| h100_dgx/all_reduce/w4/dpn4 | 993 | 0.0380 | 209.8044 | 209.8047 | 0.0784 | 2 | 1 |
| h100_dgx/all_reduce/w8/dpn8 | 993 | 0.0310 | 189.1071 | 189.1120 | 0.0744 | 1 | 0 |
| h100_dgx/send_recv/w2/dpn1 | 993 | 0.0185 | 35.7141 | 34.6132 | 0.4407 | 1 | 0 |
| h100_dgx/send_recv/w2/dpn2 | 993 | 0.0075 | 344.7222 | 344.7284 | 0.0177 | 0 | 0 |
| h100_pairwise_nvlink/all_reduce/w2/dpn2 | 993 | 0.0070 | 187.6599 | 187.6679 | 0.1279 | 10 | 13 |
| h100_pairwise_nvlink/all_reduce/w4/dpn4 | 993 | 0.0280 | 32.3017 | 32.3018 | 0.0165 | 0 | 1 |
| h100_pairwise_nvlink/send_recv/w2/dpn1 | 993 | 0.0185 | 7.5941 | 2.3275 | 0.2245 | 60 | 41 |
| h100_pairwise_nvlink/send_recv/w2/dpn2 | 993 | 0.0085 | 335.0088 | 295.2959 | 0.0617 | 0 | 0 |

##### 4.2 拓扑与带宽拐点的主要读数

- **A100 DGX all-reduce** 的 payload-BW P95 清楚地区分节点内/跨节点：w2/dpn2=153.18 GB/s，w2/dpn1=5.86；w4/dpn4=110.61，w4/dpn2=7.04；w8/dpn8=96.01，w8/dpn4=12.17。
- **H100 DGX all-reduce** 仅有节点内 w2/w4/w8，P95 分别为 269.90/209.80/189.11 GB/s；不能据此外推 H100 跨节点或 w16。
- **pairwise-NVLink all-reduce** 从 w2 到 w4 出现巨大拓扑惩罚：A100 194.66->15.79 GB/s；H100 187.66->32.30 GB/s。这与 w4 跨越成对高速链路边界相容，但算法原因仍需拓扑/NCCL 日志确认。
- 带宽均为 payload-equivalent，不是厂商峰值或 NCCL busbw。尤其跨节点/跨 pair 配置的大消息带宽可能在最大 size 区间回落，因此不能用单一饱和带宽常数替代整条实测曲线。

##### 4.3 阈值/非单调候选

共检出 284 个局部不连续候选。规则要求：size>=64KiB、相邻 size 比<=1.25、绝对延迟变化>=0.005ms 且>=相邻两点合成标准差的 3 倍，并满足上跳>=25% 或下降>=20%。这只是噪声过滤后的 change-point 候选；它们可能来自 NCCL 算法/协议切换、拓扑阈值、拥塞或三次重复仍未覆盖的偶发抖动，没有 NCCL debug 日志和阈值两侧加密复测就不能定性为算法切换。`network_transitions.csv` 保留全部相邻点，便于采用别的规则复核。

| 目录 | collective | world | dpn | 前一 size | 当前 size | 前一 ms | 当前 ms | 延迟变化 | BW 变化 | 类型 |
|---|---|---|---|---|---|---|---|---|---|---|
| a100_pairwise_nvlink | all_reduce | 2 | 2 | 395,264.0000 | 403456 | 0.0130 | 0.0630 | 3.8462 | -0.7894 | candidate_latency_jump |
| a100_pairwise_nvlink | all_reduce | 2 | 2 | 264,192.0000 | 272384 | 0.0130 | 0.0590 | 3.5385 | -0.7728 | candidate_latency_jump |
| h100_dgx | all_reduce | 2 | 2 | 395,264.0000 | 403456 | 0.0100 | 0.0430 | 3.3000 | -0.7626 | candidate_latency_jump |
| h100_dgx | all_reduce | 2 | 2 | 518,144.0000 | 526336 | 0.0110 | 0.0420 | 2.8182 | -0.7340 | candidate_latency_jump |
| h100_pairwise_nvlink | all_reduce | 2 | 2 | 231,424.0000 | 239616 | 0.0080 | 0.0300 | 2.7500 | -0.7239 | candidate_latency_jump |
| a100_dgx | all_reduce | 2 | 2 | 411,648.0000 | 419840 | 0.0180 | 0.0620 | 2.4444 | -0.7039 | candidate_latency_jump |
| h100_pairwise_nvlink | all_reduce | 2 | 2 | 346,112.0000 | 354304 | 0.0100 | 0.0310 | 2.1000 | -0.6698 | candidate_latency_jump |
| h100_pairwise_nvlink | all_reduce | 2 | 2 | 370,688.0000 | 378880 | 0.0100 | 0.0300 | 2.0000 | -0.6593 | candidate_latency_jump |
| h100_pairwise_nvlink | all_reduce | 2 | 2 | 272,384.0000 | 280576 | 0.0100 | 0.0300 | 2.0000 | -0.6566 | candidate_latency_jump |
| h100_dgx | all_reduce | 4 | 4 | 681,984.0000 | 690176 | 0.0150 | 0.0420 | 1.8000 | -0.6386 | candidate_latency_jump |
| h100_pairwise_nvlink | all_reduce | 2 | 2 | 428,032.0000 | 436224 | 0.0110 | 0.0300 | 1.7273 | -0.6263 | candidate_latency_jump |
| h100_pairwise_nvlink | all_reduce | 2 | 2 | 116,736.0000 | 124928 | 0.0120 | 0.0290 | 1.4167 | -0.5572 | candidate_latency_jump |
| h100_pairwise_nvlink | all_reduce | 2 | 2 | 542,720.0000 | 550912 | 0.0130 | 0.0310 | 1.3846 | -0.5743 | candidate_latency_jump |
| h100_pairwise_nvlink | all_reduce | 2 | 2 | 575,488.0000 | 583680 | 0.0130 | 0.0300 | 1.3077 | -0.5605 | candidate_latency_jump |
| a100_dgx | all_reduce | 2 | 2 | 182,272.0000 | 190464 | 0.0290 | 0.0570 | 0.9655 | -0.4684 | candidate_latency_jump |
| a100_dgx | all_reduce | 16 | 8 | 16,744,448.0000 | 16777216 | 2.1530 | 4.1700 | 0.9368 | -0.4827 | candidate_latency_jump |
| h100_dgx | all_reduce | 2 | 2 | 903,168.0000 | 911360 | 0.0220 | 0.0420 | 0.9091 | -0.4714 | candidate_latency_jump |
| h100_pairwise_nvlink | send_recv | 2 | 1 | 44,302,336.0000 | 44433408 | 13.3470 | 25.1940 | 0.8876 | -0.4687 | candidate_latency_jump |
| a100_pairwise_nvlink | send_recv | 2 | 1 | 44,302,336.0000 | 44433408 | 13.3470 | 25.1940 | 0.8876 | -0.4687 | candidate_latency_jump |
| a100_pairwise_nvlink | all_reduce | 2 | 2 | 83,968.0000 | 92160 | 0.0640 | 0.0100 | -0.8438 | 6.0244 | nonmonotonic_latency_drop |
| a100_pairwise_nvlink | all_reduce | 2 | 2 | 755,712.0000 | 763904 | 0.0340 | 0.0620 | 0.8235 | -0.4457 | candidate_latency_jump |
| h100_dgx | all_reduce | 2 | 2 | 149,504.0000 | 157696 | 0.0410 | 0.0080 | -0.8049 | 4.4058 | nonmonotonic_latency_drop |
| a100_pairwise_nvlink | send_recv | 2 | 1 | 19,660,800.0000 | 19791872 | 6.8770 | 12.3960 | 0.8025 | -0.4415 | candidate_latency_jump |
| h100_pairwise_nvlink | send_recv | 2 | 1 | 19,660,800.0000 | 19791872 | 6.8770 | 12.3960 | 0.8025 | -0.4415 | candidate_latency_jump |
| a100_pairwise_nvlink | all_reduce | 2 | 2 | 387,072.0000 | 395264 | 0.0620 | 0.0130 | -0.7903 | 3.8702 | nonmonotonic_latency_drop |
| a100_dgx | all_reduce | 4 | 2 | 16,744,448.0000 | 16777216 | 2.3630 | 4.2300 | 0.7901 | -0.4403 | candidate_latency_jump |
| a100_pairwise_nvlink | all_reduce | 2 | 2 | 133,120.0000 | 141312 | 0.0520 | 0.0110 | -0.7885 | 4.0182 | nonmonotonic_latency_drop |
| h100_dgx | all_reduce | 2 | 2 | 387,072.0000 | 395264 | 0.0420 | 0.0100 | -0.7619 | 3.2889 | nonmonotonic_latency_drop |
| a100_pairwise_nvlink | all_reduce | 2 | 2 | 542,720.0000 | 550912 | 0.0630 | 0.0150 | -0.7619 | 3.2634 | nonmonotonic_latency_drop |
| h100_dgx | all_reduce | 2 | 2 | 509,952.0000 | 518144 | 0.0420 | 0.0110 | -0.7381 | 2.8795 | nonmonotonic_latency_drop |

#### 5. 异常与数据缺口

除下表逐文件告警外，还有两个直接影响复现的版本缺口：当前 `config_optimizer/.../config.yml` 仍引用 `lmsys_chat_1m_conversation_stats_llama2_tokenizer.csv` 与 `bwb_stats_llama2_tokenizer_filtered_v2.csv`，但 processed-traces 目录没有这两个文件；因此仓库现状不能直接复现论文 Chat-1M/BWB-4K workload。另外，标准 network 文件的重复 key 全部位于 16,777,216 bytes，这是分段 size 采样网格边界重叠，而非有明确 repeat_id 的独立复测。

A40 `attention.csv` 的 2,235,600 个空值全部落在 decode 行的 prefill-only timing 字段，属于 phase-conditional schema，而不是随机缺失；但它仍含 479 个完全重复行，并有 29,236 行超出唯一 shape-key 组合（decode 22,752、prefill 6,484），且没有 repeat/config provenance 字段。详见 `misplaced_compute_profile_summary.csv`。

network 采样域也存在明显漂移：A100 pairwise all-reduce 有 2,247 个 size 点并延伸到 536,373,250 bytes（约 511.5 MiB），其余标准文件通常只有 993 个点、上限 64 MiB；H100 DGX all-reduce 只有节点内 w2/w4/w8，A40 则完全没有 all-reduce。所有标准 collective CSV 还都带一个多余的 `Unnamed: 0` index 列。

| 级别 | 路径 | 类型 | 说明 |
|---|---|---|---|
| high | profiling/network/a100_pairwise_nvlink/send_recv.csv | byte_identical_cross_file_copy | identical_to=profiling/network/h100_pairwise_nvlink/send_recv.csv; sha256=01985ec314f4e54fa7bb9512c4a76b5081aa98b2b60db902cbfb3a6f30cb9c21 |
| high | profiling/network/a40_pairwise_nvlink | missing_collective_profile | missing=all_reduce; observed=attention_compute,send_recv |
| high | profiling/network/a40_pairwise_nvlink/attention.csv | non_network_schema_under_network_directory | profile_type=attention_compute; metric columns are attention/compute fields |
| high | profiling/network/a40_pairwise_nvlink/send_recv.csv | topology_directory_metadata_mismatch | directory says pairwise_nvlink, max_devices_per_node values=[8] |
| medium | profiling/network/a100_dgx/all_reduce.csv | duplicate_profile_keys | rows=14; size_bytes=[16777216] |
| medium | profiling/network/a100_dgx/all_reduce.csv | high_within_point_jitter | CV>20% rows=174/6958 |
| medium | profiling/network/a100_dgx/all_reduce.csv | rank0_only | No cross-rank latency/asymmetry observations |
| medium | profiling/network/a100_dgx/send_recv.csv | duplicate_profile_keys | rows=4; size_bytes=[16777216] |
| medium | profiling/network/a100_dgx/send_recv.csv | high_within_point_jitter | CV>20% rows=12/1988 |
| medium | profiling/network/a100_dgx/send_recv.csv | rank0_only | No cross-rank latency/asymmetry observations |
| medium | profiling/network/a100_pairwise_nvlink/all_reduce.csv | duplicate_profile_keys | rows=4; size_bytes=[16777216] |
| medium | profiling/network/a100_pairwise_nvlink/all_reduce.csv | high_within_point_jitter | CV>20% rows=65/4496 |
| medium | profiling/network/a100_pairwise_nvlink/all_reduce.csv | rank0_only | No cross-rank latency/asymmetry observations |
| medium | profiling/network/a100_pairwise_nvlink/send_recv.csv | duplicate_profile_keys | rows=4; size_bytes=[16777216] |
| medium | profiling/network/a100_pairwise_nvlink/send_recv.csv | high_within_point_jitter | CV>20% rows=70/1988 |
| medium | profiling/network/a100_pairwise_nvlink/send_recv.csv | rank0_only | No cross-rank latency/asymmetry observations |
| medium | profiling/network/a40_pairwise_nvlink/send_recv.csv | duplicate_profile_keys | rows=4; size_bytes=[16777216] |
| medium | profiling/network/a40_pairwise_nvlink/send_recv.csv | high_within_point_jitter | CV>20% rows=14/1988 |
| medium | profiling/network/a40_pairwise_nvlink/send_recv.csv | rank0_only | No cross-rank latency/asymmetry observations |
| medium | profiling/network/h100_dgx/all_reduce.csv | duplicate_profile_keys | rows=6; size_bytes=[16777216] |
| medium | profiling/network/h100_dgx/all_reduce.csv | high_within_point_jitter | CV>20% rows=155/2982 |
| medium | profiling/network/h100_dgx/all_reduce.csv | rank0_only | No cross-rank latency/asymmetry observations |
| medium | profiling/network/h100_dgx/send_recv.csv | duplicate_profile_keys | rows=4; size_bytes=[16777216] |
| medium | profiling/network/h100_dgx/send_recv.csv | high_within_point_jitter | CV>20% rows=85/1988 |
| medium | profiling/network/h100_dgx/send_recv.csv | rank0_only | No cross-rank latency/asymmetry observations |
| medium | profiling/network/h100_pairwise_nvlink/all_reduce.csv | duplicate_profile_keys | rows=4; size_bytes=[16777216] |
| medium | profiling/network/h100_pairwise_nvlink/all_reduce.csv | high_within_point_jitter | CV>20% rows=36/1988 |
| medium | profiling/network/h100_pairwise_nvlink/all_reduce.csv | rank0_only | No cross-rank latency/asymmetry observations |
| medium | profiling/network/h100_pairwise_nvlink/send_recv.csv | duplicate_profile_keys | rows=4; size_bytes=[16777216] |
| medium | profiling/network/h100_pairwise_nvlink/send_recv.csv | high_within_point_jitter | CV>20% rows=70/1988 |
| medium | profiling/network/h100_pairwise_nvlink/send_recv.csv | rank0_only | No cross-rank latency/asymmetry observations |
| low | profiling/network/a100_dgx/all_reduce.csv | unnamed_index_column | Unnamed: 0 |
| low | profiling/network/a100_dgx/send_recv.csv | unnamed_index_column | Unnamed: 0 |
| low | profiling/network/a100_pairwise_nvlink/all_reduce.csv | unnamed_index_column | Unnamed: 0 |
| low | profiling/network/a100_pairwise_nvlink/send_recv.csv | unnamed_index_column | Unnamed: 0 |
| low | profiling/network/a40_pairwise_nvlink/send_recv.csv | unnamed_index_column | Unnamed: 0 |
| low | profiling/network/h100_dgx/all_reduce.csv | unnamed_index_column | Unnamed: 0 |
| low | profiling/network/h100_dgx/send_recv.csv | unnamed_index_column | Unnamed: 0 |
| low | profiling/network/h100_pairwise_nvlink/all_reduce.csv | unnamed_index_column | Unnamed: 0 |
| low | profiling/network/h100_pairwise_nvlink/send_recv.csv | unnamed_index_column | Unnamed: 0 |

#### 6. 对论文结论和模拟器可用性的影响

1. **Workload 资产不能直接复现论文三 trace 结果。** 当前 processed 目录只有 Arxiv 与两条 Splitwise trace；缺 Chat-1M、BWB-4K 的论文版 processed trace。代码 README 的 Splitwise 示例是仓库后续能力，不应与论文 Table 1 混写。
2. **4096 域覆盖要按请求类型分别审计。** 超过 4096 的请求若仍使用默认 predictor max，会进入未经默认 attention profile 支撑的 KV/context 区域；扩大 CLI 上限并不会自动产生实测数据。当前 `trace_request_length_generator.py` 会把超限 prefill/decode 按比例缩短，而 `trace_replay_request_generator.py` 只从 prefill 扣除超额；所以原始 OOD 比例可能在运行时下降，但这是改变 workload，不能当作 profiling 覆盖已经解决。
3. **Network profile 是 topology-specific 的，而且有资产未被当前 loader 使用。** 同一 GPU 名称下 world size、devices_per_node 和跨节点组合不同，不能仅按 `device` 合并。当前 `sklearn_execution_time_predictor.py::_load_all_reduce_df` 要求 `num_workers==TP` 且 `devices_per_node==TP`，因此 A100 DGX 的 w4/dpn2、w8/dpn4、w16/dpn8 等跨节点 all-reduce 行不会进入该 predictor；send/recv 则按是否多节点固定选 dpn=1/2。缺失组合应拒绝或显式回退，不应默默借用另一拓扑。
4. **仅 rank 0 + 三次 active 重复不足以建尾部模型。** 对 median 插值尚可，但无法验证慢 rank、collective barrier skew 或 P95/P99；SLO 仿真应增加全 rank 记录和更多重复。
5. **非单调和跳变必须保留。** 不宜用单一线性带宽模型平滑掉阈值；RF/查表应按 world size、topology 分域，并在候选阈值两侧补采样。
6. **字节级复制和错放文件必须先治理。** H100 pairwise send/recv 在重新实测前应标为 provenance 不明；A40 attention 应移出 network 资产清单；A40 all-reduce 缺失应阻断相应配置搜索。

#### 7. 建议的最小治理动作

- 给每个 CSV 增加 manifest：GPU SKU/PCIe 或 NVLink 形态、节点数、driver/CUDA/NCCL/PyTorch commit、采样日期、profile 命令、hash。
- network CSV 去除多余 index 列，按 `(collective, world_size, devices_per_node, size, rank, repeat_id)` 保存原始重复，而不只保存 rank0 汇总。
- 对所有阈值候选点在两侧补采至少 20–30 次，并随机化 size 顺序；报告 median、MAD、P95 与置信区间。
- 模拟器启动时校验请求/消息是否处在真实 profile envelope，未知 topology/world size/compiler 组合直接报 OOD。
- 将论文 trace、当前 Splitwise trace、演示 trace 分目录并附 provenance，避免把后续仓库资产误当论文复现实验输入。

#### 8. 产物说明

- `file_inventory.csv`：全文件 schema、hash、缺失与重复审计。
- `workload_summary.csv`、`workload_quantiles.csv`、`workload_correlations.csv`、`workload_coverage.csv`、`workload_quality.csv`：workload 统计。
- `network_rows_enriched.csv`：标准 network 行，附 payload 带宽与抖动指标。
- `network_file_quality.csv`、`network_group_summary.csv`、`network_transitions.csv`、`network_threshold_candidates.csv`、`network_duplicate_keys.csv`、`network_anomalies.csv`：network 审计。
- `misplaced_compute_profile_summary.csv`：误放在 network 目录的 A40 attention 文件，按 prefill/decode 汇总其缺失、重复和 shape 范围。
- `analysis_summary.json`：机器可读摘要和 top-length 细节。

## 第四部分：数据契约与代码消费链

### 附录：Vidur 数据资产与 current-main 代码契约深度审计

> 本附录面向逐文件复核、配置排障和后续昇腾迁移。审计的 current-main 固定为 commit `8383d2935bc62723a212090baa9f98ada206fc14`；论文时期只使用 2024-05-09 的开源发布准备提交 `6d98aa8f71696520acc603d87439e77cc78160a7` 作为代码/目录结构参照，不把二者混成同一快照。

#### A.1 先读结论与证据边界

current-main 仓库共有 **53 个 CSV、1,436,810 行、262.56 MiB**。数据主体是 operator/collective 微基准，不是端到端请求记录。

审计支持的强结论：

- 对 current-main 已存在且过滤后非空的 model/device/TP/block/backend 切片，可以确定 learner 实际读取哪些列、怎样构造特征、怎样预生成 lookup，以及哪些数据永远不可达。
- 现有 40 个 compute 文件的模型维度与 current-main 模型配置一致；active prefill/decode target 没有 NaN。
- A40 all-reduce、CPU overhead、部分 model/device/TP、跨节点 all-reduce、预测域和 cache 存在可由代码及文件直接证明的契约断点。

本审计不支持的推论：

- 不能把 current-main 的 53 个 CSV 当成 MLSys 2024 论文提交时的数据快照。
- 不能仅凭仓库数据复现论文的 Chat-1M/BWB-4K 全部 workload；当前仓库并没有这些文件。
- 不能把 RF 在配置范围内能返回数值，解释为对未采样 shape、其他 backend、其他软件栈或其他硬件的可靠外推。

#### A.2 论文时期与 current-main：必须分开阅读

| 边界 | commit | 时间/提交说明 | 本报告如何使用 |
|---|---|---|---|
| 代码参照 | `6d98aa8f71696520acc603d87439e77cc78160a7` | 2024-05-09，Prepare for open-source release (#6) | paper-era repository reference；不是论文逐实验数据的形式化归档 tag |
| 本次数据审计 | `8383d2935bc62723a212090baa9f98ada206fc14` | 2025-07-25，[Bugfix] Revert scheduler regression… (#65) | 53 CSV、current-main loader、配置和模型注册表 |

两个版本的数据目录和默认行为不同：

| 主题 | paper-era 参照 | current-main 审计对象 |
|---|---|---|
| Profiling 路径 | `data/profiling/{DEVICE}/{mlp,attention,all_reduce,send_recv}.csv` | compute 按 device/model 分层；network 按 topology 分层 |
| CPU overhead | A100/A40 各有平铺 `cpu_overheads.csv`；默认不跳过 | 仓库 0 个 CPU overhead CSV；`skip_cpu_overhead_modeling=True` |
| A40 all-reduce | tree 中存在 `data/profiling/a40/all_reduce.csv` | `network/a40_pairwise_nvlink/all_reduce.csv` 缺失 |
| RF 搜索网格 | estimators 500/750，depth 32，split 2/5/10 | estimators 250/500/750，depth 8/16/32，split 2/5/10 |
| 模型/数据 | 无 Llama-3 目录；模型配置还包括 GPT-3/Falcon | 加入 Llama-3 profiles；当前模型注册表与 paper-era 不同 |
| Workload | tree 中只有 Arxiv processed trace | Arxiv + Splitwise code/conversation；仍缺论文 Chat-1M/BWB 文件 |

Paper-era 参照提交的 tree 中只有以下 15 个 CSV（路径本身即可通过 `git ls-tree` 复核）：

```text
data/processed_traces/arxiv_summarization_stats_llama2_tokenizer_filtered_v2.csv
data/profiling/a100/{all_reduce,attention,cpu_overheads,mlp,send_recv}.csv
data/profiling/a40/{all_reduce,attention,cpu_overheads,mlp,send_recv}.csv
data/profiling/h100/{all_reduce,attention,mlp,send_recv}.csv
```

重要解释：loader 的许多核心过滤与特征构造从 paper-era 延续到了 current-main，但路径布局、数据集合、CPU 默认值和模型覆盖已变化。因此，论文给出的端到端精度不能自动为 current-main 每个新增文件和每个配置背书。

#### A.3 证据索引

| 证据 ID | 版本 | 路径/命令 | 证明内容 |
|---|---|---|---|
| S01 | current | `vidur/config/config.py:428-464` | model/device/network_device 独立实例化 |
| S02 | current | `vidur/config/config.py:494-561` | 五类 CSV 路径、lookup 上限、KV 粒度、CPU 默认开关 |
| S03 | current | `vidur/config/config.py:590-606` | current RF 参数网格 |
| S04 | current | `vidur/config/model_config.py` | 9 个具体模型的维度与 no_tensor_parallel 声明 |
| S05 | current | `vidur/execution_time_predictor/sklearn_execution_time_predictor.py:87-201` | 路径展开、读取、exact dedup、四类 profile 过滤 |
| S06 | current | `.../sklearn_execution_time_predictor.py:203-242` | attention/network 派生特征 |
| S07 | current | `.../sklearn_execution_time_predictor.py:281-449` | 模型 cache、prediction cache、训练与 GridSearchCV |
| S08 | current | `.../sklearn_execution_time_predictor.py:451-579` | operation→feature→target 映射 |
| S09 | current | `.../sklearn_execution_time_predictor.py:588-723` | lookup grid 预生成 |
| S10 | current | `.../sklearn_execution_time_predictor.py:725-899` | KV 聚合、取整、dictionary 查询、CPU 置零 |
| S11 | current | `.../sklearn_execution_time_predictor.py:901-920` | cache hash 使用的 to_dict 字段 |
| S12 | current | `vidur/entities/batch.py:41-49` | 总 token 向上取整到 8 |
| S13 | current | `vidur/execution_time_predictor/base_execution_time_predictor.py` | 各 component 进入 ExecutionTime 的组合位置 |
| S14 | current | `vidur/request_generator/trace_replay_request_generator.py:19-92` | replay schema、缩放、截断与顺序 |
| S15 | current | `vidur/request_generator/trace_request_length_generator.py:17-100` | length schema、比例截断与 shuffle |
| S16 | current | `vidur/request_generator/trace_request_interval_generator.py:19-60` | arrival_time schema、时间过滤/floor/diff |
| S17 | paper-era | `6d98aa8f71696520acc603d87439e77cc78160a7:simulator/config/default.yml` | 旧路径、CPU 开关、旧 RF 网格 |
| S18 | paper-era | `6d98aa8f71696520acc603d87439e77cc78160a7:simulator/execution_time_predictor/sklearn_execution_time_predictor.py` | 旧 loader/特征构造 |
| S19 | paper-era | `git ls-tree -r 6d98aa8f71696520acc603d87439e77cc78160a7 -- data` | 旧数据树中 15 个 CSV 和配置目录 |
| S20 | audit | `contract_agent/csv_inventory.csv` | 53 文件逐项 schema/行数/重复/target/范围 |
| S21 | audit | `contract_agent/compute_coverage_matrix.csv` | 27 model-device 配置过滤重放 |
| S22 | audit | `contract_agent/network_reachability.csv` | 5 topology 的实际可达行 |
| S23 | audit | `contract_agent/trace_compatibility.csv` | 3 trace 与 3 loader 的 schema 兼容性 |
| S24 | audit | `contract_agent/findings.csv` | 16 项问题、证据与影响 |

#### A.4 CSV 到模拟器的完整数据流

```mermaid
flowchart LR
  A["Replica / scheduler / predictor config"] --> B["展开 {DEVICE}/{MODEL}/{NETWORK_DEVICE}"]
  B --> C["pd.read_csv"]
  C --> D["完整行 drop_duplicates"]
  D --> E{"数据类"}
  E -->|MLP| F["模型维度 + TP 过滤"]
  E -->|Attention| G["模型维度 + block + TP 过滤"]
  E -->|All-reduce| H["workers=TP 且 dpn=TP"]
  E -->|Send/recv| I["dpn=1 或 2"]
  E -->|CPU| J["model + TP；默认跳过"]
  F --> K["operator median / num_tokens"]
  G --> L["prefill/decode/KV-save 派生特征"]
  H --> M["bytes/(hidden*2)"]
  I --> M
  J --> N["batch_size→CPU median/mean"]
  K --> O["每个 target 单独 GridSearchCV + RF"]
  L --> O
  M --> O
  N --> O
  O --> P["预生成稠密 prediction dictionary"]
  P --> Q["运行时 token→8；KV→64；attention 聚合"]
  Q --> R["直接 dictionary key 查询"]
  R --> S["各层/通信/CPU 组合成 ExecutionTime"]
```

这个流程包含四个容易误读的事实：

1. CSV 每行的 `median` 是 profiler 内部重复的中位数；loader 不再对相同 shape 的多行取 median。
2. learner 并非输入完整 batch：它先把 batch 压缩为一两个统计量，再查表。
3. RF 可以对配置 grid 返回数值，不代表该 grid 被 profile 数据覆盖；RF 超出训练范围只会落到边界叶常数。
4. 实际 key 超出预生成 dictionary 时不会动态回归或 profile，而是直接 `KeyError`。

#### A.5 各类 loader 的精确数据契约

##### A.5.1 MLP/投影/Norm/RoPE/Add

路径：`data/profiling/compute/{DEVICE}/{MODEL}/mlp.csv`。

过滤必须同时满足：`n_head`、`n_kv_head`、`n_embd`、`n_expanded_embd`、`use_gated_mlp`、`vocab_size` 等于模型配置，且 `num_tensor_parallel_workers == TP`。

| 模型名 | 特征 | target | schema 行为 |
|---|---|---|---|
| attn_pre_proj | num_tokens | time_stats.attn_pre_proj.median | required |
| attn_post_proj | num_tokens | time_stats.attn_post_proj.median | required |
| mlp_up_proj | num_tokens | time_stats.mlp_up_proj.median | required |
| mlp_down_proj | num_tokens | time_stats.mlp_down_proj.median | required |
| mlp_act | num_tokens | time_stats.mlp_act.median | required |
| attn_rope | num_tokens | time_stats.attn_rope.median | required |
| input_layernorm | num_tokens | time_stats.input_layernorm.median | 缺列/NaN→0 |
| post_attention_layernorm | num_tokens | time_stats.post_attention_layernorm.median | 缺列/NaN→0 |
| add | num_tokens | time_stats.add.median | 缺列/NaN→0 |

`time_stats.emb.*` 与所有 min/max/mean/std 不进入模型；运行时这些 component 使用向上取整到 8 的 batch 总 token。

##### A.5.2 Attention

路径：`data/profiling/compute/{DEVICE}/{MODEL}/attention.csv`。过滤键为 `n_embd/n_q_head/n_kv_head/block_size/TP`。

| 模型 | 训练子集 | 特征 | target | 行为 |
|---|---|---|---|---|
| KV-cache save | 全部行 | max(prefill_chunk_size,batch_size) | attn_kv_cache_save.median | 旧 schema 缺列→0 |
| Prefill | prefill_chunk_size != 0 | kv_cache_size, prefill_chunk_size² | attn_prefill.median | active target 必须非空 |
| Decode | prefill_chunk_size == 0 | batch_size, kv_cache_size | attn_decode.median | active target 必须非空 |

`attention_backend`、`max_model_len`、CSV 自带 `is_prefill` 不参与过滤；代码以 `prefill_chunk_size==0` 重建 decode 标志。当前每个文件只有一种 backend，所以尚未混合，但 contract 无法防止未来误混。Input/output reshape 虽被测量，也没有进入最终 ExecutionTime。

##### A.5.3 All-reduce / Send-recv

| 类型 | 过滤 | 特征 | target | 触发条件 |
|---|---|---|---|---|
| All-reduce | num_workers==TP；devices_per_node==TP；collective=all_reduce | size/(embedding_dim*2) | all_reduce.median | TP>1 才训练；另加 NCCL launch/skew |
| Send/recv | collective=send_recv；单节点 dpn=2，多节点 dpn=1 | size/(embedding_dim*2) | send_recv.median | PP>1 才训练 |

常数 2 固定假设每个 hidden element 占 2 B；dtype 并不是 CSV filter 或特征。A100 DGX 的跨节点曲线正是因为 all-reduce 强制 `dpn==TP` 而不可达。

##### A.5.4 CPU overhead

预期路径：`data/profiling/cpu_overhead/{NETWORK_DEVICE}/{MODEL}/cpu_overheads.csv`；过滤 `model_name` 与 `tensor_parallel_degree`，以 `batch_size` 预测 schedule、sampler、prepare-input、process-output、Ray communication。current-main 仓库没有任何该类文件，默认开关又是 skip，因此五项均为 0。

##### A.5.5 Trace loaders

| Loader | required columns | 转换 | current 数据兼容 |
|---|---|---|---|
| Length | num_prefill_tokens,num_decode_tokens | 缩放→int→按比例截断→至少1→seed shuffle | 三文件 |
| Replay | arrived_at,num_prefill_tokens,num_decode_tokens | 缩放→int→至少1→超长只扣 prefill→arrival 缩放；不排序 | Splitwise code/conv |
| Interval | arrival_time(datetime) | 时间窗口严格开区间→floor 到整秒→diff；不排序 | 0 文件 |

#### A.6 Lookup、取整、OOD 与 cache

| 参数/规则 | current default |
|---|---|
| block_size | 16 |
| prediction_max_tokens_per_request | 4096 |
| prediction_max_prefill_chunk_size | 4096 |
| prediction_max_batch_size | 128 |
| kv_cache_prediction_granularity | 64 |
| skip_cpu_overhead_modeling | True |
| compute_total_tokens_rounding | ceil to multiple of 8 |
| decode_and_prefill_kv_rounding | ceil to multiple of 64 |

运行时 key：

- 主 compute/通信 component：`ceil(total_tokens/8)*8`。
- KV-save：`sum(batch.num_tokens)`，不按 8 取整。
- Decode：decode request 数作为 batch；历史 KV 先求平均、转 int，再向上取整到 64。
- Prefill：每个 request 的历史 KV 分别向上取整到 64 后求和；多个 chunk 使用 `round(sqrt(sum(p_i²)))²`。
- GQA 多请求 attention：在 RF lookup 之外再乘默认 1.1；不是训练特征。

预测域风险：旧 attention 的实测 KV 最大为 4032，默认却生成 KV=4096；Orca 的一维 token lookup 可到 4096×128=524,288，而旧 MLP 最大只到 4096。前者是边界外常数预测，后者跨两个数量级，均不是可靠插值。

Cache 分两层：

1. estimator cache 的训练 hash 含 dataframe JSON hash，能感知数据内容。
2. prediction dictionary cache 用 fitted estimator 的字符串和不完整 `to_dict()`；字符串通常只反映超参数，不含树节点/训练集，`to_dict()` 又漏掉 `attention_input_file` 与 KV granularity。CSV 同路径替换、attention 文件切换或粒度变化后，存在复用旧 lookup 的实质风险。

#### A.7 53 个 CSV 的逐文件索引

ID 按 `csv_inventory.csv` 的路径字典序稳定生成。`key-extra` 表示 exact dedup 后，按实际 learner 特征/过滤键仍重复的额外行；它不是完整行重复数。

##### A.7.1 Processed traces

| ID | 文件 | raw rows | cols | exact dup | key-extra | 范围/配置 | schema/消费备注 |
|---|---|---|---|---|---|---|---|
| F001 | `data/processed_traces/arxiv_summarization_stats_llama2_tokenizer_filtered_v2.csv` | 28,257 | 4 | 469 | 0 | num_decode_tokens=[5.0, 4056.0], num_prefill_tokens=[1.0, 4054.0] | length_compatible=True;replay_compatible=False;interval_compatible=False |
| F002 | `data/processed_traces/splitwise_code.csv` | 8,819 | 3 | 0 | 0 | arrived_at=[0.0, 3435.948056], num_decode_tokens=[6.0, 1899.0], num_prefill_tokens=[3.0, 7437.0] | length_compatible=True;replay_compatible=True;interval_compatible=False;arrival_monotonic=True |
| F003 | `data/processed_traces/splitwise_conv.csv` | 19,366 | 3 | 0 | 0 | arrived_at=[0.0, 3501.721937], num_decode_tokens=[7.0, 1000.0], num_prefill_tokens=[2.0, 14050.0] | length_compatible=True;replay_compatible=True;interval_compatible=False;arrival_monotonic=True |

##### A.7.2 Compute MLP

| ID | 文件 | raw rows | cols | exact dup | key-extra | 范围/配置 | schema/消费备注 |
|---|---|---|---|---|---|---|---|
| F005 | `data/profiling/compute/a100/Qwen/Qwen-72B/mlp.csv` | 1,044 | 58 | 0 | 8 | tokens=[1.0, 4096.0]; TP=[1, 2, 4, 8] | required schema OK |
| F007 | `data/profiling/compute/a100/codellama/CodeLlama-34b-Instruct-hf/mlp.csv` | 1,044 | 58 | 0 | 8 | tokens=[1.0, 4096.0]; TP=[1, 2, 4, 8] | required schema OK |
| F009 | `data/profiling/compute/a100/internlm/internlm-20b/mlp.csv` | 1,044 | 58 | 0 | 8 | tokens=[1.0, 4096.0]; TP=[1, 2, 4, 8] | required schema OK |
| F011 | `data/profiling/compute/a100/meta-llama/Llama-2-70b-hf/mlp.csv` | 1,044 | 58 | 0 | 8 | tokens=[1.0, 4096.0]; TP=[1, 2, 4, 8] | required schema OK |
| F013 | `data/profiling/compute/a100/meta-llama/Llama-2-7b-hf/mlp.csv` | 1,044 | 58 | 0 | 8 | tokens=[1.0, 4096.0]; TP=[1, 2, 4, 8] | required schema OK |
| F015 | `data/profiling/compute/a100/meta-llama/Meta-Llama-3-70B/mlp.csv` | 1,824 | 58 | 0 | 20 | tokens=[1.0, 32768.0]; TP=[1, 2, 4, 8] | required schema OK |
| F017 | `data/profiling/compute/a100/meta-llama/Meta-Llama-3-8B/mlp.csv` | 1,824 | 58 | 0 | 20 | tokens=[1.0, 32768.0]; TP=[1, 2, 4, 8] | required schema OK |
| F019 | `data/profiling/compute/a100/microsoft/phi-2/mlp.csv` | 261 | 53 | 0 | 2 | tokens=[1.0, 4096.0]; TP=[1] | 缺列→0: post_attention_layernorm |
| F021 | `data/profiling/compute/a40/Qwen/Qwen-72B/mlp.csv` | 1,044 | 58 | 0 | 8 | tokens=[1.0, 4096.0]; TP=[1, 2, 4, 8] | required schema OK |
| F023 | `data/profiling/compute/a40/codellama/CodeLlama-34b-Instruct-hf/mlp.csv` | 1,044 | 58 | 0 | 8 | tokens=[1.0, 4096.0]; TP=[1, 2, 4, 8] | required schema OK |
| F025 | `data/profiling/compute/a40/internlm/internlm-20b/mlp.csv` | 1,044 | 58 | 0 | 8 | tokens=[1.0, 4096.0]; TP=[1, 2, 4, 8] | required schema OK |
| F027 | `data/profiling/compute/a40/meta-llama/Llama-2-70b-hf/mlp.csv` | 1,044 | 58 | 0 | 8 | tokens=[1.0, 4096.0]; TP=[1, 2, 4, 8] | required schema OK |
| F029 | `data/profiling/compute/a40/meta-llama/Llama-2-7b-hf/mlp.csv` | 1,044 | 58 | 0 | 8 | tokens=[1.0, 4096.0]; TP=[1, 2, 4, 8] | required schema OK |
| F031 | `data/profiling/compute/a40/microsoft/phi-2/mlp.csv` | 261 | 53 | 0 | 2 | tokens=[1.0, 4096.0]; TP=[1] | 缺列→0: post_attention_layernorm |
| F033 | `data/profiling/compute/h100/Qwen/Qwen-72B/mlp.csv` | 1,044 | 58 | 0 | 8 | tokens=[1.0, 4096.0]; TP=[1, 2, 4, 8] | required schema OK |
| F035 | `data/profiling/compute/h100/codellama/CodeLlama-34b-Instruct-hf/mlp.csv` | 1,044 | 58 | 0 | 8 | tokens=[1.0, 4096.0]; TP=[1, 2, 4, 8] | required schema OK |
| F037 | `data/profiling/compute/h100/internlm/internlm-20b/mlp.csv` | 1,044 | 58 | 0 | 8 | tokens=[1.0, 4096.0]; TP=[1, 2, 4, 8] | required schema OK |
| F039 | `data/profiling/compute/h100/meta-llama/Llama-2-70b-hf/mlp.csv` | 1,044 | 58 | 0 | 8 | tokens=[1.0, 4096.0]; TP=[1, 2, 4, 8] | required schema OK |
| F041 | `data/profiling/compute/h100/meta-llama/Llama-2-7b-hf/mlp.csv` | 1,044 | 58 | 0 | 8 | tokens=[1.0, 4096.0]; TP=[1, 2, 4, 8] | required schema OK |
| F043 | `data/profiling/compute/h100/microsoft/phi-2/mlp.csv` | 261 | 53 | 0 | 2 | tokens=[1.0, 4096.0]; TP=[1] | 缺列→0: post_attention_layernorm |

##### A.7.3 Compute attention

| ID | 文件 | raw rows | cols | exact dup | key-extra | 范围/配置 | schema/消费备注 |
|---|---|---|---|---|---|---|---|
| F004 | `data/profiling/compute/a100/Qwen/Qwen-72B/attention.csv` | 58,632 | 31 | 77 | 1283 | B=[1.0, 128.0]; P=[0.0, 4096.0]; KV=[0.0, 4032.0]; TP=[1, 2, 4, 8]; block=[16]; backend=['AttentionBackend.FLASH_ATTENTION'] | 缺列→0: attn_kv_cache_save; active target=0: 16 |
| F006 | `data/profiling/compute/a100/codellama/CodeLlama-34b-Instruct-hf/attention.csv` | 58,632 | 31 | 171 | 1189 | B=[1.0, 128.0]; P=[0.0, 4096.0]; KV=[0.0, 4032.0]; TP=[1, 2, 4, 8]; block=[16]; backend=['AttentionBackend.FLASH_ATTENTION'] | 缺列→0: attn_kv_cache_save |
| F008 | `data/profiling/compute/a100/internlm/internlm-20b/attention.csv` | 58,632 | 31 | 105 | 1255 | B=[1.0, 128.0]; P=[0.0, 4096.0]; KV=[0.0, 4032.0]; TP=[1, 2, 4, 8]; block=[16]; backend=['AttentionBackend.FLASH_ATTENTION'] | 缺列→0: attn_kv_cache_save |
| F010 | `data/profiling/compute/a100/meta-llama/Llama-2-70b-hf/attention.csv` | 58,632 | 31 | 176 | 1184 | B=[1.0, 128.0]; P=[0.0, 4096.0]; KV=[0.0, 4032.0]; TP=[1, 2, 4, 8]; block=[16]; backend=['AttentionBackend.FLASH_ATTENTION'] | 缺列→0: attn_kv_cache_save |
| F012 | `data/profiling/compute/a100/meta-llama/Llama-2-7b-hf/attention.csv` | 58,632 | 31 | 142 | 1218 | B=[1.0, 128.0]; P=[0.0, 4096.0]; KV=[0.0, 4032.0]; TP=[1, 2, 4, 8]; block=[16]; backend=['AttentionBackend.FLASH_ATTENTION'] | 缺列→0: attn_kv_cache_save |
| F014 | `data/profiling/compute/a100/meta-llama/Meta-Llama-3-70B/attention.csv` | 99,200 | 36 | 212 | 2805 | B=[1.0, 512.0]; P=[0.0, 16384.0]; KV=[0.0, 16320.0]; TP=[1, 2, 4, 8]; block=[16]; backend=['AttentionBackend.FLASHINFER'] | required schema OK |
| F016 | `data/profiling/compute/a100/meta-llama/Meta-Llama-3-8B/attention.csv` | 42,587 | 36 | 63 | 1360 | B=[1.0, 512.0]; P=[0.0, 16384.0]; KV=[0.0, 16320.0]; TP=[1, 4]; block=[16]; backend=['AttentionBackend.FLASHINFER'] | required schema OK |
| F018 | `data/profiling/compute/a100/microsoft/phi-2/attention.csv` | 58,632 | 31 | 207 | 1153 | B=[1.0, 128.0]; P=[0.0, 4096.0]; KV=[0.0, 4032.0]; TP=[1, 2, 4, 8]; block=[16]; backend=['AttentionBackend.FLASH_ATTENTION'] | 缺列→0: attn_kv_cache_save |
| F020 | `data/profiling/compute/a40/Qwen/Qwen-72B/attention.csv` | 58,632 | 31 | 25 | 1335 | B=[1.0, 128.0]; P=[0.0, 4096.0]; KV=[0.0, 4032.0]; TP=[1, 2, 4, 8]; block=[16]; backend=['AttentionBackend.FLASH_ATTENTION'] | 缺列→0: attn_kv_cache_save |
| F022 | `data/profiling/compute/a40/codellama/CodeLlama-34b-Instruct-hf/attention.csv` | 58,632 | 31 | 88 | 1272 | B=[1.0, 128.0]; P=[0.0, 4096.0]; KV=[0.0, 4032.0]; TP=[1, 2, 4, 8]; block=[16]; backend=['AttentionBackend.FLASH_ATTENTION'] | 缺列→0: attn_kv_cache_save |
| F024 | `data/profiling/compute/a40/internlm/internlm-20b/attention.csv` | 58,632 | 31 | 57 | 1303 | B=[1.0, 128.0]; P=[0.0, 4096.0]; KV=[0.0, 4032.0]; TP=[1, 2, 4, 8]; block=[16]; backend=['AttentionBackend.FLASH_ATTENTION'] | 缺列→0: attn_kv_cache_save |
| F026 | `data/profiling/compute/a40/meta-llama/Llama-2-70b-hf/attention.csv` | 58,632 | 31 | 67 | 1293 | B=[1.0, 128.0]; P=[0.0, 4096.0]; KV=[0.0, 4032.0]; TP=[1, 2, 4, 8]; block=[16]; backend=['AttentionBackend.FLASH_ATTENTION'] | 缺列→0: attn_kv_cache_save |
| F028 | `data/profiling/compute/a40/meta-llama/Llama-2-7b-hf/attention.csv` | 58,632 | 31 | 59 | 1301 | B=[1.0, 128.0]; P=[0.0, 4096.0]; KV=[0.0, 4032.0]; TP=[1, 2, 4, 8]; block=[16]; backend=['AttentionBackend.FLASH_ATTENTION'] | 缺列→0: attn_kv_cache_save |
| F030 | `data/profiling/compute/a40/microsoft/phi-2/attention.csv` | 58,632 | 31 | 109 | 1251 | B=[1.0, 128.0]; P=[0.0, 4096.0]; KV=[0.0, 4032.0]; TP=[1, 2, 4, 8]; block=[16]; backend=['AttentionBackend.FLASH_ATTENTION'] | 缺列→0: attn_kv_cache_save |
| F032 | `data/profiling/compute/h100/Qwen/Qwen-72B/attention.csv` | 58,632 | 31 | 139 | 1221 | B=[1.0, 128.0]; P=[0.0, 4096.0]; KV=[0.0, 4032.0]; TP=[1, 2, 4, 8]; block=[16]; backend=['AttentionBackend.FLASH_ATTENTION'] | 缺列→0: attn_kv_cache_save |
| F034 | `data/profiling/compute/h100/codellama/CodeLlama-34b-Instruct-hf/attention.csv` | 58,632 | 31 | 352 | 1008 | B=[1.0, 128.0]; P=[0.0, 4096.0]; KV=[0.0, 4032.0]; TP=[1, 2, 4, 8]; block=[16]; backend=['AttentionBackend.FLASH_ATTENTION'] | 缺列→0: attn_kv_cache_save |
| F036 | `data/profiling/compute/h100/internlm/internlm-20b/attention.csv` | 58,632 | 31 | 194 | 1166 | B=[1.0, 128.0]; P=[0.0, 4096.0]; KV=[0.0, 4032.0]; TP=[1, 2, 4, 8]; block=[16]; backend=['AttentionBackend.FLASH_ATTENTION'] | 缺列→0: attn_kv_cache_save |
| F038 | `data/profiling/compute/h100/meta-llama/Llama-2-70b-hf/attention.csv` | 58,632 | 31 | 383 | 977 | B=[1.0, 128.0]; P=[0.0, 4096.0]; KV=[0.0, 4032.0]; TP=[1, 2, 4, 8]; block=[16]; backend=['AttentionBackend.FLASH_ATTENTION'] | 缺列→0: attn_kv_cache_save |
| F040 | `data/profiling/compute/h100/meta-llama/Llama-2-7b-hf/attention.csv` | 58,632 | 31 | 209 | 1151 | B=[1.0, 128.0]; P=[0.0, 4096.0]; KV=[0.0, 4032.0]; TP=[1, 2, 4, 8]; block=[16]; backend=['AttentionBackend.FLASH_ATTENTION'] | 缺列→0: attn_kv_cache_save |
| F042 | `data/profiling/compute/h100/microsoft/phi-2/attention.csv` | 58,632 | 31 | 273 | 1087 | B=[1.0, 128.0]; P=[0.0, 4096.0]; KV=[0.0, 4032.0]; TP=[1, 2, 4, 8]; block=[16]; backend=['AttentionBackend.FLASH_ATTENTION'] | 缺列→0: attn_kv_cache_save |

##### A.7.4 Network all-reduce

| ID | 文件 | raw rows | cols | exact dup | key-extra | 范围/配置 | schema/消费备注 |
|---|---|---|---|---|---|---|---|
| F044 | `data/profiling/network/a100_dgx/all_reduce.csv` | 6,958 | 12 | 0 | 7 | bytes=[2048.0, 67108864.0]; (workers,dpn)=[[2, 1], [2, 2], [4, 2], [4, 4], [8, 4], [8, 8], [16, 8]] | required schema OK |
| F046 | `data/profiling/network/a100_pairwise_nvlink/all_reduce.csv` | 4,496 | 12 | 0 | 2 | bytes=[2048.0, 536373250.0]; (workers,dpn)=[[2, 2], [4, 4]] | required schema OK |
| F050 | `data/profiling/network/h100_dgx/all_reduce.csv` | 2,982 | 12 | 0 | 3 | bytes=[2048.0, 67108864.0]; (workers,dpn)=[[2, 2], [4, 4], [8, 8]] | required schema OK |
| F052 | `data/profiling/network/h100_pairwise_nvlink/all_reduce.csv` | 1,988 | 12 | 0 | 2 | bytes=[2048.0, 67108864.0]; (workers,dpn)=[[2, 2], [4, 4]] | required schema OK |

##### A.7.5 Network send/recv

| ID | 文件 | raw rows | cols | exact dup | key-extra | 范围/配置 | schema/消费备注 |
|---|---|---|---|---|---|---|---|
| F045 | `data/profiling/network/a100_dgx/send_recv.csv` | 1,988 | 12 | 0 | 2 | bytes=[2048.0, 67108864.0]; dpn=[1, 2] | required schema OK |
| F047 | `data/profiling/network/a100_pairwise_nvlink/send_recv.csv` | 1,988 | 12 | 0 | 2 | bytes=[2048.0, 67108864.0]; dpn=[1, 2] | required schema OK |
| F049 | `data/profiling/network/a40_pairwise_nvlink/send_recv.csv` | 1,988 | 12 | 0 | 2 | bytes=[2048.0, 67108864.0]; dpn=[1, 2] | required schema OK |
| F051 | `data/profiling/network/h100_dgx/send_recv.csv` | 1,988 | 12 | 0 | 2 | bytes=[2048.0, 67108864.0]; dpn=[1, 2] | required schema OK |
| F053 | `data/profiling/network/h100_pairwise_nvlink/send_recv.csv` | 1,988 | 12 | 0 | 2 | bytes=[2048.0, 67108864.0]; dpn=[1, 2] | required schema OK |

##### A.7.6 孤立的 A40 attention

| ID | 文件 | raw rows | cols | exact dup | key-extra | 范围/配置 | schema/消费备注 |
|---|---|---|---|---|---|---|---|
| F048 | `data/profiling/network/a40_pairwise_nvlink/attention.csv` | 136,750 | 50 | 479 | 0 | — | current-main 无消费者 |

逐文件合计校验：

| category | files | rows | exact dup | key-extra | active zeros |
|---|---|---|---|---|---|
| processed_trace | 3 | 56,442 | 469 | 0 | 0 |
| compute_attention | 20 | 1,197,163 | 3,108 | 25,812 | 16 |
| compute_mlp | 20 | 20,091 | 0 | 166 | 0 |
| network_all_reduce | 4 | 16,424 | 0 | 14 | 0 |
| network_send_recv | 5 | 9,940 | 0 | 10 | 0 |
| orphan_network_attention | 1 | 136,750 | 479 | 0 | 0 |

#### A.8 27 个 model-device 配置覆盖索引

`usable TP` 是按 current loader 同时过滤 MLP 与 attention 后的交集；它还没有叠加 network 文件可用性。

| ID | device | model | MLP | Attn | MLP rows/TP | Attn rows/TP | usable TP | 观测上限 | backend | 结论 |
|---|---|---|---|---|---|---|---|---|---|---|
| C001 | a100 | `Qwen/Qwen-72B` | Y | Y | `{"1":261,"2":261,"4":261,"8":261,"16":0}` | `{"1":14653,"2":14653,"4":14639,"8":14610,"16":0}` | [1, 2, 4, 8] | MLP≤4096; B≤128; P≤4096; KV≤4032 | ["AttentionBackend.FLASH_ATTENTION"] | compute slice 可用 |
| C002 | a100 | `codellama/CodeLlama-34b-Instruct-hf` | Y | Y | `{"1":261,"2":261,"4":261,"8":261,"16":0}` | `{"1":14652,"2":14628,"4":14600,"8":14581,"16":0}` | [1, 2, 4, 8] | MLP≤4096; B≤128; P≤4096; KV≤4032 | ["AttentionBackend.FLASH_ATTENTION"] | compute slice 可用 |
| C003 | a100 | `internlm/internlm-20b` | Y | Y | `{"1":261,"2":261,"4":261,"8":261,"16":0}` | `{"1":14651,"2":14648,"4":14631,"8":14597,"16":0}` | [1, 2, 4, 8] | MLP≤4096; B≤128; P≤4096; KV≤4032 | ["AttentionBackend.FLASH_ATTENTION"] | compute slice 可用 |
| C004 | a100 | `internlm/internlm2-20b` | N | N | `{}` | `{}` | [] | MLP≤—; B≤—; P≤—; KV≤— | [] | 缺两个 compute 文件 |
| C005 | a100 | `meta-llama/Llama-2-70b-hf` | Y | Y | `{"1":261,"2":261,"4":261,"8":261,"16":0}` | `{"1":14648,"2":14621,"4":14607,"8":14580,"16":0}` | [1, 2, 4, 8] | MLP≤4096; B≤128; P≤4096; KV≤4032 | ["AttentionBackend.FLASH_ATTENTION"] | compute slice 可用 |
| C006 | a100 | `meta-llama/Llama-2-7b-hf` | Y | Y | `{"1":261,"2":261,"4":261,"8":261,"16":0}` | `{"1":14650,"2":14639,"4":14612,"8":14589,"16":0}` | [1, 2, 4, 8] | MLP≤4096; B≤128; P≤4096; KV≤4032 | ["AttentionBackend.FLASH_ATTENTION"] | compute slice 可用 |
| C007 | a100 | `meta-llama/Meta-Llama-3-70B` | Y | Y | `{"1":456,"2":456,"4":456,"8":456,"16":0}` | `{"1":23576,"2":24654,"4":25393,"8":25365,"16":0}` | [1, 2, 4, 8] | MLP≤32768; B≤512; P≤16384; KV≤16320 | ["AttentionBackend.FLASHINFER"] | compute slice 可用 |
| C008 | a100 | `meta-llama/Meta-Llama-3-8B` | Y | Y | `{"1":456,"2":456,"4":456,"8":456,"16":0}` | `{"1":18601,"2":0,"4":23923,"8":0,"16":0}` | [1, 4] | MLP≤32768; B≤512; P≤16384; KV≤16320 | ["AttentionBackend.FLASHINFER"] | attention 仅 TP1/4 |
| C009 | a100 | `microsoft/phi-2` | Y | Y | `{"1":261,"2":0,"4":0,"8":0,"16":0}` | `{"1":14644,"2":14618,"4":14593,"8":14570,"16":0}` | [1] | MLP≤4096; B≤128; P≤4096; KV≤4032 | ["AttentionBackend.FLASH_ATTENTION"] | 模型声明 no_tensor_parallel；实际 TP1 |
| C010 | a40 | `Qwen/Qwen-72B` | Y | Y | `{"1":261,"2":261,"4":261,"8":261,"16":0}` | `{"1":14658,"2":14655,"4":14650,"8":14644,"16":0}` | [1, 2, 4, 8] | MLP≤4096; B≤128; P≤4096; KV≤4032 | ["AttentionBackend.FLASH_ATTENTION"] | compute slice 可用 |
| C011 | a40 | `codellama/CodeLlama-34b-Instruct-hf` | Y | Y | `{"1":261,"2":261,"4":261,"8":261,"16":0}` | `{"1":14654,"2":14640,"4":14630,"8":14620,"16":0}` | [1, 2, 4, 8] | MLP≤4096; B≤128; P≤4096; KV≤4032 | ["AttentionBackend.FLASH_ATTENTION"] | compute slice 可用 |
| C012 | a40 | `internlm/internlm-20b` | Y | Y | `{"1":261,"2":261,"4":261,"8":261,"16":0}` | `{"1":14655,"2":14650,"4":14643,"8":14627,"16":0}` | [1, 2, 4, 8] | MLP≤4096; B≤128; P≤4096; KV≤4032 | ["AttentionBackend.FLASH_ATTENTION"] | compute slice 可用 |
| C013 | a40 | `internlm/internlm2-20b` | N | N | `{}` | `{}` | [] | MLP≤—; B≤—; P≤—; KV≤— | [] | 缺两个 compute 文件 |
| C014 | a40 | `meta-llama/Llama-2-70b-hf` | Y | Y | `{"1":261,"2":261,"4":261,"8":261,"16":0}` | `{"1":14655,"2":14648,"4":14636,"8":14626,"16":0}` | [1, 2, 4, 8] | MLP≤4096; B≤128; P≤4096; KV≤4032 | ["AttentionBackend.FLASH_ATTENTION"] | compute slice 可用 |
| C015 | a40 | `meta-llama/Llama-2-7b-hf` | Y | Y | `{"1":261,"2":261,"4":261,"8":261,"16":0}` | `{"1":14653,"2":14651,"4":14645,"8":14624,"16":0}` | [1, 2, 4, 8] | MLP≤4096; B≤128; P≤4096; KV≤4032 | ["AttentionBackend.FLASH_ATTENTION"] | compute slice 可用 |
| C016 | a40 | `meta-llama/Meta-Llama-3-70B` | N | N | `{}` | `{}` | [] | MLP≤—; B≤—; P≤—; KV≤— | [] | 缺两个 compute 文件 |
| C017 | a40 | `meta-llama/Meta-Llama-3-8B` | N | N | `{}` | `{}` | [] | MLP≤—; B≤—; P≤—; KV≤— | [] | 缺两个 compute 文件 |
| C018 | a40 | `microsoft/phi-2` | Y | Y | `{"1":261,"2":0,"4":0,"8":0,"16":0}` | `{"1":14650,"2":14639,"4":14631,"8":14603,"16":0}` | [1] | MLP≤4096; B≤128; P≤4096; KV≤4032 | ["AttentionBackend.FLASH_ATTENTION"] | 模型声明 no_tensor_parallel；实际 TP1 |
| C019 | h100 | `Qwen/Qwen-72B` | Y | Y | `{"1":261,"2":261,"4":261,"8":261,"16":0}` | `{"1":14649,"2":14638,"4":14628,"8":14578,"16":0}` | [1, 2, 4, 8] | MLP≤4096; B≤128; P≤4096; KV≤4032 | ["AttentionBackend.FLASH_ATTENTION"] | compute slice 可用 |
| C020 | h100 | `codellama/CodeLlama-34b-Instruct-hf` | Y | Y | `{"1":261,"2":261,"4":261,"8":261,"16":0}` | `{"1":14607,"2":14580,"4":14559,"8":14534,"16":0}` | [1, 2, 4, 8] | MLP≤4096; B≤128; P≤4096; KV≤4032 | ["AttentionBackend.FLASH_ATTENTION"] | compute slice 可用 |
| C021 | h100 | `internlm/internlm-20b` | Y | Y | `{"1":261,"2":261,"4":261,"8":261,"16":0}` | `{"1":14643,"2":14635,"4":14596,"8":14564,"16":0}` | [1, 2, 4, 8] | MLP≤4096; B≤128; P≤4096; KV≤4032 | ["AttentionBackend.FLASH_ATTENTION"] | compute slice 可用 |
| C022 | h100 | `internlm/internlm2-20b` | N | N | `{}` | `{}` | [] | MLP≤—; B≤—; P≤—; KV≤— | [] | 缺两个 compute 文件 |
| C023 | h100 | `meta-llama/Llama-2-70b-hf` | Y | Y | `{"1":261,"2":261,"4":261,"8":261,"16":0}` | `{"1":14600,"2":14573,"4":14548,"8":14528,"16":0}` | [1, 2, 4, 8] | MLP≤4096; B≤128; P≤4096; KV≤4032 | ["AttentionBackend.FLASH_ATTENTION"] | compute slice 可用 |
| C024 | h100 | `meta-llama/Llama-2-7b-hf` | Y | Y | `{"1":261,"2":261,"4":261,"8":261,"16":0}` | `{"1":14643,"2":14629,"4":14580,"8":14571,"16":0}` | [1, 2, 4, 8] | MLP≤4096; B≤128; P≤4096; KV≤4032 | ["AttentionBackend.FLASH_ATTENTION"] | compute slice 可用 |
| C025 | h100 | `meta-llama/Meta-Llama-3-70B` | N | N | `{}` | `{}` | [] | MLP≤—; B≤—; P≤—; KV≤— | [] | 缺两个 compute 文件 |
| C026 | h100 | `meta-llama/Meta-Llama-3-8B` | N | N | `{}` | `{}` | [] | MLP≤—; B≤—; P≤—; KV≤— | [] | 缺两个 compute 文件 |
| C027 | h100 | `microsoft/phi-2` | Y | Y | `{"1":261,"2":0,"4":0,"8":0,"16":0}` | `{"1":14630,"2":14599,"4":14574,"8":14556,"16":0}` | [1] | MLP≤4096; B≤128; P≤4096; KV≤4032 | ["AttentionBackend.FLASH_ATTENTION"] | 模型声明 no_tensor_parallel；实际 TP1 |

覆盖层面的三个二次约束：

- 所有 attention 文件仅有 block size 16；其他 block 配置过滤后为空。
- pairwise all-reduce 只覆盖 TP2/4，A40 没有 AR；所以 compute TP8 不等于端到端 TP8。
- `device` 与 `network_device` 没有 SKU 一致性断言，A100 compute + H100 network 这类物理不一致组合会通过配置构造。

#### A.9 Network reachability 全表

| ID | network_device | node GPUs | AR file | AR selected/TP | AR unreachable | (workers,dpn) | SR intra | SR inter | unexpected attention |
|---|---|---|---|---|---|---|---|---|---|
| N001 | `a100_dgx` | 8 | Y | {"2":994,"4":994,"8":994,"16":0} | 3976 | [[2,1],[2,2],[4,2],[4,4],[8,4],[8,8],[16,8]] | 994 | 994 | N |
| N002 | `a100_pairwise_nvlink` | 4 | Y | {"2":2248,"4":2248,"8":0,"16":0} | 0 | [[2,2],[4,4]] | 994 | 994 | N |
| N003 | `a40_pairwise_nvlink` | 8 | N | {} | 0 | [] | 994 | 994 | Y |
| N004 | `h100_dgx` | 8 | Y | {"2":994,"4":994,"8":994,"16":0} | 0 | [[2,2],[4,4],[8,8]] | 994 | 994 | N |
| N005 | `h100_pairwise_nvlink` | 4 | Y | {"2":994,"4":994,"8":0,"16":0} | 0 | [[2,2],[4,4]] | 994 | 994 | N |

A100 DGX 的 3,976 行不可达数据对应 `(2,1),(4,2),(8,4),(16,8)`；当前 filter 只能选择 `(2,2),(4,4),(8,8)`。A40 目录中的 unexpected attention 有 136,750 行，而真正需要的 all-reduce 文件不存在。

#### A.10 Trace compatibility 全表

| ID | 文件 | rows | exact dup retained | Length | Replay | Interval | max total | >4096 | arrival monotonic |
|---|---|---|---|---|---|---|---|---|---|
| T001 | `data/processed_traces/arxiv_summarization_stats_llama2_tokenizer_filtered_v2.csv` | 28,257 | 469 | Y | N | N | 4096 | 0 | — |
| T002 | `data/processed_traces/splitwise_code.csv` | 8,819 | 0 | Y | Y | N | 7841 | 1257 | True |
| T003 | `data/processed_traces/splitwise_conv.csv` | 19,366 | 0 | Y | Y | N | 14089 | 1612 | True |

Replay 会将 Splitwise 中 2,869 个超 4K 请求的 excess 全从 prefill 扣除；这不是无损截尾。Length loader 对同一输入采用按比例扣减，因此两种 loader 会生成不同的有效 workload。

#### A.11 十六项发现：逐项证据与影响

##### DC-001 [高] Network 路径

- 发现：`a40_pairwise_nvlink` 有 `send_recv.csv` 和一个 136,750 行的 `attention.csv`，却没有 loader 所需的 `all_reduce.csv`；current-main 也没有任何路径模板或源码会消费这个 network/attention 文件。
- 证据：`data/profiling/network/a40_pairwise_nvlink; config.py:503-508; sklearn_execution_time_predictor.py:87-103`
- 影响：A40 TP>1 会在打开文件时失败；136,750 行、约 32.6 MB 数据成为孤立资产。

##### DC-002 [高] CPU overhead

- 发现：current-main 仓库没有任何 `cpu_overheads.csv`，同时 `skip_cpu_overhead_modeling` 默认为 true。
- 证据：`config.py:511-512,559-561; sklearn_execution_time_predictor.py:518-549,871-899`
- 影响：schedule、sampler、input preparation、output processing 和 Ray communication 默认全部为 0；只打开开关而不提供外部文件会失败。

##### DC-003 [高] Compute 覆盖

- 发现：27 个具体 model-device 组合中有 7 个没有 compute 文件：InternLM2-20B 在三种设备上均缺，两个 Llama-3 在 A40/H100 均缺；A100 Llama-3-8B 的 attention 只有 TP1/4，虽然 MLP 有 TP1/2/4/8。
- 证据：`compute_coverage_matrix.csv; model_config.py`
- 影响：真正可用的 model/device/TP 集合小于配置注册表；不支持的组合要到加载或过滤阶段才失败。

##### DC-004 [高] 跨节点 all-reduce

- 发现：All-reduce filter 强制 `num_workers==TP` 且 `devices_per_node==TP`。A100 DGX 中 `(2,1),(4,2),(8,4),(16,8)` 共 3,976 行因此不可达，TP16 也为空。
- 证据：`sklearn_execution_time_predictor.py:166-172; network_reachability.csv`
- 影响：仓库已经发布的跨节点 all-reduce 曲线无法被 current loader 选择，TP 跨节点通信没有进入模拟。

##### DC-005 [高] Prediction cache

- 发现：Prediction-cache hash 使用 fitted estimator 的字符串，不含训练 dataframe 或树状态；`to_dict()` 又漏掉 `attention_input_file` 和若干控制 prediction grid 的设置。
- 证据：`sklearn_execution_time_predictor.py:281-290,422-449,901-920`
- 影响：同路径 CSV 内容变化或切换 attention CSV 后，只要最佳超参数相同，就可能静默复用旧 lookup。

##### DC-006 [高] 预测域

- 发现：Lookup 只按配置范围生成，运行时直接查 dictionary；代码不检查该范围是否被训练数据覆盖。旧 attention 到 KV=4032，默认却含 4096；Orca 可把旧 MLP 的一维 lookup 从实测 4096 扩到 4096×128。
- 证据：`sklearn_execution_time_predictor.py:57-63,588-716,725-869`
- 影响：RF 在训练域外静默饱和为叶常数；超出预生成范围的 shape 则 `KeyError`，没有 profiling/fallback。

##### DC-008 [高] 数据质量

- 发现：A100 Qwen-72B TP1 attention 有 16 个 active decode 行的 median 为 0、max 却非 0；当前没有 target validator 过滤或告警。
- 证据：`data/profiling/compute/a100/Qwen/Qwen-72B/attention.csv; csv_inventory.csv`
- 影响：不合理的零时延标签污染 decode learner；自定义 MAPE 对任何非零预测都把这些行记为 100% 误差。

##### DC-012 [高] Trace 默认值

- 发现：默认 trace-length 与 trace-interval 路径对应的文件不存在；三个内置 trace 都没有 interval loader 所需的 `arrival_time`，只有两个 Splitwise 文件符合 replay 的 `arrived_at` schema。
- 证据：`config.py:48-65,111-127,228-247; trace_compatibility.csv`
- 影响：相关 generator 模式不能仅用仓库资产开箱复现，错误会在运行时才暴露。

##### DC-007 [中] 重复与聚合

- 发现：Loader 只删除所有列完全相同的行，不按 contract key 聚合。Exact dedup 后仍有 166 个额外 MLP 行和 25,812 个额外 attention 行共享 learner 特征。
- 证据：`sklearn_execution_time_predictor.py:105-107,143-145,198-201; csv_inventory.csv`
- 影响：采样分段边界获得额外权重；target 不同的重复测量被当成独立样本，而不是一个 shape 的稳健统计。

##### DC-009 [中] Schema fallback

- 发现：18 个旧 attention 文件缺 `attn_kv_cache_save.median` 并被静默补 0；三个 Phi-2 MLP 文件缺 `post_attention_layernorm.median`。
- 证据：`sklearn_execution_time_predictor.py:132-153; csv_inventory.csv`
- 影响：缺失测量和真实零耗时不可区分。Phi-2 因 `post_attn_norm=false` 语义安全；KV-save 为 0 只是兼容性假设。

##### DC-010 [中] 隐藏执行 regime

- 发现：`attention_backend`、`max_model_len` 和 CSV 自带 `is_prefill` 都不是 filter/feature；只有 `prefill_chunk_size` 决定 phase。当前旧数据为 FLASH_ATTENTION、Llama-3 为 FLASHINFER。
- 证据：`sklearn_execution_time_predictor.py:143-164,207-218; csv_inventory.csv`
- 影响：未来若把多个 backend 或编译执行 regime 放进同一 CSV，loader 会静默训练一个混合模型。

##### DC-011 [中] 设备—拓扑一致性

- 发现：`ReplicaConfig` 独立构造 `device` 与 `network_device`，不检查 node SKU 的 device type 是否匹配 compute device。
- 证据：`config.py:428-464`
- 影响：A100 compute + H100 network 这类语法合法、物理不一致的模拟配置不会被拒绝。

##### DC-013 [中] Trace 转换

- 发现：Replay 将超长请求的 excess 全从 prefill 扣除，不再次断言 prefill>0，也不排序 arrival；默认会截断 1,257 条 Splitwise code 和 1,612 条 conversation。Trace loader 还保留重复行。
- 证据：`trace_replay_request_generator.py:23-67,80-92; trace_compatibility.csv`
- 影响：decode scale 足够大时可得到非正 prefill，却仍通过总长度断言；现有长 prompt 分布也被实质改变。

##### DC-014 [中] 未消费字段

- 发现：模型只学习 `*.median`。MLP embedding、attention input/output reshape、min/max/mean/std 以及 backend 等元数据都不消费。
- 证据：`sklearn_execution_time_predictor.py:451-579; csv_inventory.csv`
- 影响：CSV 中的不确定性和部分 component 无法影响预测；reshape/embedding 时间也不会自动在其他位置补回。

##### DC-015 [中] 通信单位

- 发现：Network size 通过 `size/(embedding_dim*2)` 换算 token，硬编码每个 hidden element 为 2 B；all-reduce median 后再加固定 NCCL launch 项。
- 证据：`sklearn_execution_time_predictor.py:220-236,811-817`
- 影响：FP8/FP32 或压缩通信不能直接复用该契约，dtype 又没有进入 CSV filter。

##### DC-016 [信息] 数据完整性正向结论

- 发现：40 个 compute 文件都匹配目录模型的配置维度，block size 均为 16，active prefill/decode target 没有 null；唯一 active 零标签异常是 A100 Qwen 的 16 行。
- 证据：`compute_coverage_matrix.csv; csv_inventory.csv`
- 影响：当前支持切片总体结构一致；主要风险来自覆盖、选择和版本契约，而非普遍 schema 损坏。

#### A.12 建议的新数据契约

##### A.12.1 启动前 validator

每次构造 predictor 前必须一次性验证：

1. 路径存在，device 与 network SKU 一致，文件 hash 进入 run manifest。
2. required columns、dtype、单位、finite、active target > 0。缺列不能再无条件补零；只有 manifest 明确声明 `fused_into` 才可省略 component。
3. model/TP/block/backend/compiler-regime 过滤后非空，并报告精确行数。
4. 训练 support 完整覆盖 lookup X；越界点拒绝或触发补采，不允许 RF 静默叶常数。
5. 对相同 contract key 聚合独立重复，保存 count/p50/p90/p99/std/CV 和 run IDs。
6. prediction cache key 包含数据内容 hash、完整 config、lookup X hash、fitted model state、代码和软件栈版本。

##### A.12.2 建议的 profile manifest

| 类别 | 最低字段 |
|---|---|
| 身份 | dataset_id, run_id, generated_at, source_commit, schema_version |
| 硬件 | device SKU, device UUID, node topology, link type, frequency/power mode, firmware |
| 软件 | driver/CUDA 或 CANN, framework, kernel library/backend, compiler commits/flags |
| 模型 | model revision, graph hash, layer/head/hidden dims, dtype/layout, TP/PP/block |
| 执行 regime | kernel hash, tiling key, fusion pattern, workspace, stream/core assignment |
| 测量 | warmup/active counts, timer source/unit, cold/warm state, raw replicate or aggregate provenance |
| 支持域 | feature min/max/grid, known holes, alignment boundaries, allowed interpolation policy |

##### A.12.3 昇腾 NPU 迁移时的加严项

current Vidur 将 `attention_backend` 写进 CSV 却不用于过滤，这在昇腾上不能沿用。CANN/编译器版本、graph/kernel hash、tiling key、融合方案、DMA/流水路径、layout/dtype 和 cold/warm compile-cache 状态必须成为一等分区键。否则同一逻辑 shape 下不同编译执行机制会被混成一个 target 分布。

NPU 的推荐最小建模单元不是固定的源代码 operator 名，而是 compiler-emitted kernel 或 fused segment。缺失 component 应表达为“融合到哪个 segment”，不能伪造为 0 ms。验证切分也必须按 regime、连续 shape 区间和编译版本分组，而不是仅按 CSV 行随机拆分。

#### A.13 本附录的机器证据

| 资产 | 绝对路径 |
|---|---|
| 53 文件 inventory | `D:/workspaces/trace/vidur_data_analysis/contract_agent/csv_inventory.csv` |
| 27 配置 coverage | `D:/workspaces/trace/vidur_data_analysis/contract_agent/compute_coverage_matrix.csv` |
| Network reachability | `D:/workspaces/trace/vidur_data_analysis/contract_agent/network_reachability.csv` |
| Trace compatibility | `D:/workspaces/trace/vidur_data_analysis/contract_agent/trace_compatibility.csv` |
| 16 findings | `D:/workspaces/trace/vidur_data_analysis/contract_agent/findings.csv` |
| 契约 JSON | `D:/workspaces/trace/vidur_data_analysis/contract_agent/contract_summary.json` |
| 复算脚本 | `D:/workspaces/trace/vidur_data_analysis/contract_agent/audit_data_contract.py` |
| 本附录生成脚本 | `D:/workspaces/trace/vidur_data_analysis/contract_agent/build_deep_appendix.py` |

官方仓库在本分析过程中保持只读；所有新增产物均位于 `D:/workspaces/trace/vidur_data_analysis/`。

## 第五部分：统一数据流与“可学习”定义

### 从 CSV 到模拟结果

```mermaid
flowchart LR
  A["53 个 CSV"] --> B["路径展开与 pandas 读取"]
  B --> C["整行 drop_duplicates"]
  C --> D["按 device/model/TP/block/topology 过滤"]
  D --> E["派生特征：tokens、KV、chunk²、bytes→tokens"]
  E --> F["各 operator 独立 Random Forest + GridSearchCV"]
  F --> G["生成有限范围 prediction lookup"]
  G --> H["运行时 batch 聚合与粒度取整"]
  H --> I["operator + collective + 固定修正项组合"]
  I --> J["离散事件模拟与请求指标"]

  K["未消费：多数 min/max/mean/std、backend 元数据、部分 reshape/emb、CPU overhead"] -.-> E
  L["风险：OOD 饱和、KeyError、旧 lookup cache"] -.-> G
```

### 建议采用的严格定义

“可学习”不应等同于随机拆分 MAPE 低，而应同时满足：

1. 训练和测试属于同一硬件/软件/编译/tiling/kernel 制度，或模型能可靠识别制度；
2. 测试 shape 位于训练点覆盖的插值域，而不是树叶常数外推区；
3. 同 shape 的所有重复位于同一 fold，避免复制与网格边界泄漏；
4. 连续区间留出、边界邻域留出和 OOD 留出都有单独结果；
5. 对接近 0 的 operator 同时报 MAE（μs）而非只报 MAPE；
6. 端到端误差还要包含 CPU、搬运、通信、重叠、排队和流水线，而非只验证 operator median。


## 附录 A：全部 53 个 CSV 资产与消费状态

| 路径 | 类别 | 设备 | 模型 | 类型 | 行 | 列 | MB | Schema | 完整重复 | 空值率 | 当前消费状态 |
|---|---|---|---|---|---|---|---|---|---|---|---|
| processed_traces/arxiv_summarization_stats_llama2_tokenizer_filtered_v2.csv | workload | — | — | trace | 28,257 | 4 | 0.9132 | 869bb0ca40 | 469 | 0.0000% | 可作长度分布；不兼容 replay/interval |
| processed_traces/splitwise_code.csv | workload | — | — | trace | 8,819 | 3 | 0.1750 | f682e16862 | 0 | 0.0000% | 兼容 length + replay；不兼容 interval |
| processed_traces/splitwise_conv.csv | workload | — | — | trace | 19,366 | 3 | 0.4021 | f682e16862 | 0 | 0.0000% | 兼容 length + replay；不兼容 interval |
| profiling/compute/a100/codellama/CodeLlama-34b-Instruct-hf/attention.csv | compute | a100 | codellama/CodeLlama-34b-Instruct-hf | attention | 58,632 | 31 | 10.7922 | 32d502d632 | 171 | 16.1290% | 匹配 device/model/TP/block-size 后进入 operator learner |
| profiling/compute/a100/codellama/CodeLlama-34b-Instruct-hf/mlp.csv | compute | a100 | codellama/CodeLlama-34b-Instruct-hf | mlp | 1,044 | 58 | 0.6934 | 205db5b084 | 0 | 0.0000% | 匹配 device/model/TP/block-size 后进入 operator learner |
| profiling/compute/a100/internlm/internlm-20b/attention.csv | compute | a100 | internlm/internlm-20b | attention | 58,632 | 31 | 10.8006 | 32d502d632 | 105 | 16.1290% | 匹配 device/model/TP/block-size 后进入 operator learner |
| profiling/compute/a100/internlm/internlm-20b/mlp.csv | compute | a100 | internlm/internlm-20b | mlp | 1,044 | 58 | 0.6986 | 205db5b084 | 0 | 0.0000% | 匹配 device/model/TP/block-size 后进入 operator learner |
| profiling/compute/a100/meta-llama/Llama-2-70b-hf/attention.csv | compute | a100 | meta-llama/Llama-2-70b-hf | attention | 58,632 | 31 | 10.7890 | 32d502d632 | 176 | 16.1290% | 匹配 device/model/TP/block-size 后进入 operator learner |
| profiling/compute/a100/meta-llama/Llama-2-70b-hf/mlp.csv | compute | a100 | meta-llama/Llama-2-70b-hf | mlp | 1,044 | 58 | 0.6893 | 205db5b084 | 0 | 0.0000% | 匹配 device/model/TP/block-size 后进入 operator learner |
| profiling/compute/a100/meta-llama/Llama-2-7b-hf/attention.csv | compute | a100 | meta-llama/Llama-2-7b-hf | attention | 58,632 | 31 | 10.7390 | 32d502d632 | 142 | 16.1290% | 匹配 device/model/TP/block-size 后进入 operator learner |
| profiling/compute/a100/meta-llama/Llama-2-7b-hf/mlp.csv | compute | a100 | meta-llama/Llama-2-7b-hf | mlp | 1,044 | 58 | 0.7077 | 205db5b084 | 0 | 0.0000% | 匹配 device/model/TP/block-size 后进入 operator learner |
| profiling/compute/a100/meta-llama/Meta-Llama-3-70B/attention.csv | compute | a100 | meta-llama/Meta-Llama-3-70B | attention | 99,200 | 36 | 21.4292 | 528000ac9f | 212 | 0.0000% | 匹配 device/model/TP/block-size 后进入 operator learner |
| profiling/compute/a100/meta-llama/Meta-Llama-3-70B/mlp.csv | compute | a100 | meta-llama/Meta-Llama-3-70B | mlp | 1,824 | 58 | 1.1825 | 205db5b084 | 0 | 0.0000% | 匹配 device/model/TP/block-size 后进入 operator learner |
| profiling/compute/a100/meta-llama/Meta-Llama-3-8B/attention.csv | compute | a100 | meta-llama/Meta-Llama-3-8B | attention | 42,587 | 36 | 9.1979 | 528000ac9f | 63 | 0.0000% | 匹配 device/model/TP/block-size 后进入 operator learner |
| profiling/compute/a100/meta-llama/Meta-Llama-3-8B/mlp.csv | compute | a100 | meta-llama/Meta-Llama-3-8B | mlp | 1,824 | 58 | 1.2067 | 205db5b084 | 0 | 0.0000% | 匹配 device/model/TP/block-size 后进入 operator learner |
| profiling/compute/a100/microsoft/phi-2/attention.csv | compute | a100 | microsoft/phi-2 | attention | 58,632 | 31 | 10.7181 | 32d502d632 | 207 | 16.1290% | 匹配 device/model/TP/block-size 后进入 operator learner |
| profiling/compute/a100/microsoft/phi-2/mlp.csv | compute | a100 | microsoft/phi-2 | mlp | 261 | 53 | 0.1627 | 1545165a6c | 0 | 0.0000% | 匹配 device/model/TP/block-size 后进入 operator learner |
| profiling/compute/a100/Qwen/Qwen-72B/attention.csv | compute | a100 | Qwen/Qwen-72B | attention | 58,632 | 31 | 10.8985 | 32d502d632 | 77 | 16.1290% | 匹配 device/model/TP/block-size 后进入 operator learner |
| profiling/compute/a100/Qwen/Qwen-72B/mlp.csv | compute | a100 | Qwen/Qwen-72B | mlp | 1,044 | 58 | 0.6910 | 205db5b084 | 0 | 0.0000% | 匹配 device/model/TP/block-size 后进入 operator learner |
| profiling/compute/a40/codellama/CodeLlama-34b-Instruct-hf/attention.csv | compute | a40 | codellama/CodeLlama-34b-Instruct-hf | attention | 58,632 | 31 | 10.8271 | 32d502d632 | 88 | 16.1290% | 匹配 device/model/TP/block-size 后进入 operator learner |
| profiling/compute/a40/codellama/CodeLlama-34b-Instruct-hf/mlp.csv | compute | a40 | codellama/CodeLlama-34b-Instruct-hf | mlp | 1,044 | 58 | 0.6794 | 205db5b084 | 0 | 0.0000% | 匹配 device/model/TP/block-size 后进入 operator learner |
| profiling/compute/a40/internlm/internlm-20b/attention.csv | compute | a40 | internlm/internlm-20b | attention | 58,632 | 31 | 10.9901 | 32d502d632 | 57 | 16.1290% | 匹配 device/model/TP/block-size 后进入 operator learner |
| profiling/compute/a40/internlm/internlm-20b/mlp.csv | compute | a40 | internlm/internlm-20b | mlp | 1,044 | 58 | 0.6914 | 205db5b084 | 0 | 0.0000% | 匹配 device/model/TP/block-size 后进入 operator learner |
| profiling/compute/a40/meta-llama/Llama-2-70b-hf/attention.csv | compute | a40 | meta-llama/Llama-2-70b-hf | attention | 58,632 | 31 | 10.8410 | 32d502d632 | 67 | 16.1290% | 匹配 device/model/TP/block-size 后进入 operator learner |
| profiling/compute/a40/meta-llama/Llama-2-70b-hf/mlp.csv | compute | a40 | meta-llama/Llama-2-70b-hf | mlp | 1,044 | 58 | 0.6797 | 205db5b084 | 0 | 0.0000% | 匹配 device/model/TP/block-size 后进入 operator learner |
| profiling/compute/a40/meta-llama/Llama-2-7b-hf/attention.csv | compute | a40 | meta-llama/Llama-2-7b-hf | attention | 58,632 | 31 | 10.9359 | 32d502d632 | 59 | 16.1290% | 匹配 device/model/TP/block-size 后进入 operator learner |
| profiling/compute/a40/meta-llama/Llama-2-7b-hf/mlp.csv | compute | a40 | meta-llama/Llama-2-7b-hf | mlp | 1,044 | 58 | 0.6903 | 205db5b084 | 0 | 0.0000% | 匹配 device/model/TP/block-size 后进入 operator learner |
| profiling/compute/a40/microsoft/phi-2/attention.csv | compute | a40 | microsoft/phi-2 | attention | 58,632 | 31 | 10.8515 | 32d502d632 | 109 | 16.1290% | 匹配 device/model/TP/block-size 后进入 operator learner |
| profiling/compute/a40/microsoft/phi-2/mlp.csv | compute | a40 | microsoft/phi-2 | mlp | 261 | 53 | 0.1588 | 1545165a6c | 0 | 0.0000% | 匹配 device/model/TP/block-size 后进入 operator learner |
| profiling/compute/a40/Qwen/Qwen-72B/attention.csv | compute | a40 | Qwen/Qwen-72B | attention | 58,632 | 31 | 11.0194 | 32d502d632 | 25 | 16.1290% | 匹配 device/model/TP/block-size 后进入 operator learner |
| profiling/compute/a40/Qwen/Qwen-72B/mlp.csv | compute | a40 | Qwen/Qwen-72B | mlp | 1,044 | 58 | 0.6814 | 205db5b084 | 0 | 0.0000% | 匹配 device/model/TP/block-size 后进入 operator learner |
| profiling/compute/h100/codellama/CodeLlama-34b-Instruct-hf/attention.csv | compute | h100 | codellama/CodeLlama-34b-Instruct-hf | attention | 58,632 | 31 | 10.5892 | 32d502d632 | 352 | 16.1290% | 匹配 device/model/TP/block-size 后进入 operator learner |
| profiling/compute/h100/codellama/CodeLlama-34b-Instruct-hf/mlp.csv | compute | h100 | codellama/CodeLlama-34b-Instruct-hf | mlp | 1,044 | 58 | 0.6949 | 205db5b084 | 0 | 0.0000% | 匹配 device/model/TP/block-size 后进入 operator learner |
| profiling/compute/h100/internlm/internlm-20b/attention.csv | compute | h100 | internlm/internlm-20b | attention | 58,632 | 31 | 10.9165 | 32d502d632 | 194 | 16.1290% | 匹配 device/model/TP/block-size 后进入 operator learner |
| profiling/compute/h100/internlm/internlm-20b/mlp.csv | compute | h100 | internlm/internlm-20b | mlp | 1,044 | 58 | 0.7021 | 205db5b084 | 0 | 0.0000% | 匹配 device/model/TP/block-size 后进入 operator learner |
| profiling/compute/h100/meta-llama/Llama-2-70b-hf/attention.csv | compute | h100 | meta-llama/Llama-2-70b-hf | attention | 58,632 | 31 | 10.5835 | 32d502d632 | 383 | 16.1290% | 匹配 device/model/TP/block-size 后进入 operator learner |
| profiling/compute/h100/meta-llama/Llama-2-70b-hf/mlp.csv | compute | h100 | meta-llama/Llama-2-70b-hf | mlp | 1,044 | 58 | 0.6925 | 205db5b084 | 0 | 0.0000% | 匹配 device/model/TP/block-size 后进入 operator learner |
| profiling/compute/h100/meta-llama/Llama-2-7b-hf/attention.csv | compute | h100 | meta-llama/Llama-2-7b-hf | attention | 58,632 | 31 | 10.8508 | 32d502d632 | 209 | 16.1290% | 匹配 device/model/TP/block-size 后进入 operator learner |
| profiling/compute/h100/meta-llama/Llama-2-7b-hf/mlp.csv | compute | h100 | meta-llama/Llama-2-7b-hf | mlp | 1,044 | 58 | 0.7165 | 205db5b084 | 0 | 0.0000% | 匹配 device/model/TP/block-size 后进入 operator learner |
| profiling/compute/h100/microsoft/phi-2/attention.csv | compute | h100 | microsoft/phi-2 | attention | 58,632 | 31 | 10.7407 | 32d502d632 | 273 | 16.1290% | 匹配 device/model/TP/block-size 后进入 operator learner |
| profiling/compute/h100/microsoft/phi-2/mlp.csv | compute | h100 | microsoft/phi-2 | mlp | 261 | 53 | 0.1594 | 1545165a6c | 0 | 0.0000% | 匹配 device/model/TP/block-size 后进入 operator learner |
| profiling/compute/h100/Qwen/Qwen-72B/attention.csv | compute | h100 | Qwen/Qwen-72B | attention | 58,632 | 31 | 10.9765 | 32d502d632 | 139 | 16.1290% | 匹配 device/model/TP/block-size 后进入 operator learner |
| profiling/compute/h100/Qwen/Qwen-72B/mlp.csv | compute | h100 | Qwen/Qwen-72B | mlp | 1,044 | 58 | 0.7033 | 205db5b084 | 0 | 0.0000% | 匹配 device/model/TP/block-size 后进入 operator learner |
| profiling/network/a100_dgx/all_reduce.csv | network | a100_dgx | — | all_reduce | 6,958 | 12 | 0.6521 | f849316081 | 0 | 0.0000% | 受 num_workers==TP 且 devices_per_node==TP 过滤 |
| profiling/network/a100_dgx/send_recv.csv | network | a100_dgx | — | send_recv | 1,988 | 12 | 0.1788 | e6b3b8e25a | 0 | 0.0000% | 按节点内/跨节点 send-recv 路径过滤 |
| profiling/network/a100_pairwise_nvlink/all_reduce.csv | network | a100_pairwise_nvlink | — | all_reduce | 4,496 | 12 | 0.4249 | f849316081 | 0 | 0.0000% | 受 num_workers==TP 且 devices_per_node==TP 过滤 |
| profiling/network/a100_pairwise_nvlink/send_recv.csv | network | a100_pairwise_nvlink | — | send_recv | 1,988 | 12 | 0.1826 | e6b3b8e25a | 0 | 0.0000% | 按节点内/跨节点 send-recv 路径过滤 |
| profiling/network/a40_pairwise_nvlink/attention.csv | network | a40_pairwise_nvlink | — | attention | 136,750 | 50 | 32.6119 | 49382b8ca6 | 479 | 32.6962% | 不消费：误放的 attention compute profile |
| profiling/network/a40_pairwise_nvlink/send_recv.csv | network | a40_pairwise_nvlink | — | send_recv | 1,988 | 12 | 0.1830 | e6b3b8e25a | 0 | 0.0000% | 按节点内/跨节点 send-recv 路径过滤 |
| profiling/network/h100_dgx/all_reduce.csv | network | h100_dgx | — | all_reduce | 2,982 | 12 | 0.2771 | f849316081 | 0 | 0.0000% | 受 num_workers==TP 且 devices_per_node==TP 过滤 |
| profiling/network/h100_dgx/send_recv.csv | network | h100_dgx | — | send_recv | 1,988 | 12 | 0.1791 | e6b3b8e25a | 0 | 0.0000% | 按节点内/跨节点 send-recv 路径过滤 |
| profiling/network/h100_pairwise_nvlink/all_reduce.csv | network | h100_pairwise_nvlink | — | all_reduce | 1,988 | 12 | 0.1819 | f849316081 | 0 | 0.0000% | 受 num_workers==TP 且 devices_per_node==TP 过滤 |
| profiling/network/h100_pairwise_nvlink/send_recv.csv | network | h100_pairwise_nvlink | — | send_recv | 1,988 | 12 | 0.1826 | e6b3b8e25a | 0 | 0.0000% | 按节点内/跨节点 send-recv 路径过滤 |

## 附录 B：9 类 schema 目录

| Schema hash | 解释 | 文件数 | 业务列数 | 示例路径 |
|---|---|---|---|---|
| 32d502d632 | 旧 attention / FlashAttention | 18 | 31 | profiling/compute/a100/codellama/CodeLlama-34b-Instruct-hf/attention.csv; profiling/compute/a100/internlm/internlm-20b/attention.csv; profiling/compute/a100/meta-llama/Llama-2-70b-hf/attention.csv；另 15 个 |
| 205db5b084 | 标准 MLP | 17 | 58 | profiling/compute/a100/codellama/CodeLlama-34b-Instruct-hf/mlp.csv; profiling/compute/a100/internlm/internlm-20b/mlp.csv; profiling/compute/a100/meta-llama/Llama-2-70b-hf/mlp.csv；另 14 个 |
| e6b3b8e25a | Network collective | 5 | 11 | profiling/network/a100_dgx/send_recv.csv; profiling/network/a100_pairwise_nvlink/send_recv.csv; profiling/network/a40_pairwise_nvlink/send_recv.csv；另 2 个 |
| f849316081 | Network collective | 4 | 11 | profiling/network/a100_dgx/all_reduce.csv; profiling/network/a100_pairwise_nvlink/all_reduce.csv; profiling/network/h100_dgx/all_reduce.csv；另 1 个 |
| 1545165a6c | Phi-2 MLP | 3 | 53 | profiling/compute/a100/microsoft/phi-2/mlp.csv; profiling/compute/a40/microsoft/phi-2/mlp.csv; profiling/compute/h100/microsoft/phi-2/mlp.csv |
| 528000ac9f | Llama-3 attention / FlashInfer | 2 | 36 | profiling/compute/a100/meta-llama/Meta-Llama-3-70B/attention.csv; profiling/compute/a100/meta-llama/Meta-Llama-3-8B/attention.csv |
| f682e16862 | Replay workload | 2 | 3 | processed_traces/splitwise_code.csv; processed_traces/splitwise_conv.csv |
| 49382b8ca6 | Llama-3 attention / FlashInfer | 1 | 50 | profiling/network/a40_pairwise_nvlink/attention.csv |
| 869bb0ca40 | Length workload | 1 | 4 | processed_traces/arxiv_summarization_stats_llama2_tokenizer_filtered_v2.csv |

## 附录 C：40 个 compute 文件逐项质量摘要

| GPU | 模型 | 文件 | 行 | 列 | 唯一shape | 重复shape组 | 重复shape内行 | 可删完整重复 | Operator数 | Schema |
|---|---|---|---|---|---|---|---|---|---|---|
| A100 | codellama/CodeLlama-34b-Instruct-hf | attention | 58,632 | 31 | 57,272 | 1,344 | 2,704 | 171 | 4 | 63d9a674 |
| A100 | codellama/CodeLlama-34b-Instruct-hf | mlp | 1,044 | 58 | 1,036 | 8 | 16 | 0 | 10 | 78cfc8a9 |
| A100 | internlm/internlm-20b | attention | 58,632 | 31 | 57,272 | 1,344 | 2,704 | 105 | 4 | 63d9a674 |
| A100 | internlm/internlm-20b | mlp | 1,044 | 58 | 1,036 | 8 | 16 | 0 | 10 | 78cfc8a9 |
| A100 | meta-llama/Llama-2-70b-hf | attention | 58,632 | 31 | 57,272 | 1,344 | 2,704 | 176 | 4 | 63d9a674 |
| A100 | meta-llama/Llama-2-70b-hf | mlp | 1,044 | 58 | 1,036 | 8 | 16 | 0 | 10 | 78cfc8a9 |
| A100 | meta-llama/Llama-2-7b-hf | attention | 58,632 | 31 | 57,272 | 1,344 | 2,704 | 142 | 4 | 63d9a674 |
| A100 | meta-llama/Llama-2-7b-hf | mlp | 1,044 | 58 | 1,036 | 8 | 16 | 0 | 10 | 78cfc8a9 |
| A100 | meta-llama/Meta-Llama-3-70B | attention | 99,200 | 36 | 96,183 | 2,981 | 5,998 | 212 | 5 | d1806018 |
| A100 | meta-llama/Meta-Llama-3-70B | mlp | 1,824 | 58 | 1,804 | 20 | 40 | 0 | 10 | 78cfc8a9 |
| A100 | meta-llama/Meta-Llama-3-8B | attention | 42,587 | 36 | 41,164 | 1,405 | 2,828 | 63 | 5 | d1806018 |
| A100 | meta-llama/Meta-Llama-3-8B | mlp | 1,824 | 58 | 1,804 | 20 | 40 | 0 | 10 | 78cfc8a9 |
| A100 | microsoft/phi-2 | attention | 58,632 | 31 | 57,272 | 1,344 | 2,704 | 207 | 4 | 63d9a674 |
| A100 | microsoft/phi-2 | mlp | 261 | 53 | 259 | 2 | 4 | 0 | 9 | e3bd7637 |
| A100 | Qwen/Qwen-72B | attention | 58,632 | 31 | 57,272 | 1,344 | 2,704 | 77 | 4 | 63d9a674 |
| A100 | Qwen/Qwen-72B | mlp | 1,044 | 58 | 1,036 | 8 | 16 | 0 | 10 | 78cfc8a9 |
| A40 | codellama/CodeLlama-34b-Instruct-hf | attention | 58,632 | 31 | 57,272 | 1,344 | 2,704 | 88 | 4 | 63d9a674 |
| A40 | codellama/CodeLlama-34b-Instruct-hf | mlp | 1,044 | 58 | 1,036 | 8 | 16 | 0 | 10 | 78cfc8a9 |
| A40 | internlm/internlm-20b | attention | 58,632 | 31 | 57,272 | 1,344 | 2,704 | 57 | 4 | 63d9a674 |
| A40 | internlm/internlm-20b | mlp | 1,044 | 58 | 1,036 | 8 | 16 | 0 | 10 | 78cfc8a9 |
| A40 | meta-llama/Llama-2-70b-hf | attention | 58,632 | 31 | 57,272 | 1,344 | 2,704 | 67 | 4 | 63d9a674 |
| A40 | meta-llama/Llama-2-70b-hf | mlp | 1,044 | 58 | 1,036 | 8 | 16 | 0 | 10 | 78cfc8a9 |
| A40 | meta-llama/Llama-2-7b-hf | attention | 58,632 | 31 | 57,272 | 1,344 | 2,704 | 59 | 4 | 63d9a674 |
| A40 | meta-llama/Llama-2-7b-hf | mlp | 1,044 | 58 | 1,036 | 8 | 16 | 0 | 10 | 78cfc8a9 |
| A40 | microsoft/phi-2 | attention | 58,632 | 31 | 57,272 | 1,344 | 2,704 | 109 | 4 | 63d9a674 |
| A40 | microsoft/phi-2 | mlp | 261 | 53 | 259 | 2 | 4 | 0 | 9 | e3bd7637 |
| A40 | Qwen/Qwen-72B | attention | 58,632 | 31 | 57,272 | 1,344 | 2,704 | 25 | 4 | 63d9a674 |
| A40 | Qwen/Qwen-72B | mlp | 1,044 | 58 | 1,036 | 8 | 16 | 0 | 10 | 78cfc8a9 |
| H100 | codellama/CodeLlama-34b-Instruct-hf | attention | 58,632 | 31 | 57,272 | 1,344 | 2,704 | 352 | 4 | 63d9a674 |
| H100 | codellama/CodeLlama-34b-Instruct-hf | mlp | 1,044 | 58 | 1,036 | 8 | 16 | 0 | 10 | 78cfc8a9 |
| H100 | internlm/internlm-20b | attention | 58,632 | 31 | 57,272 | 1,344 | 2,704 | 194 | 4 | 63d9a674 |
| H100 | internlm/internlm-20b | mlp | 1,044 | 58 | 1,036 | 8 | 16 | 0 | 10 | 78cfc8a9 |
| H100 | meta-llama/Llama-2-70b-hf | attention | 58,632 | 31 | 57,272 | 1,344 | 2,704 | 383 | 4 | 63d9a674 |
| H100 | meta-llama/Llama-2-70b-hf | mlp | 1,044 | 58 | 1,036 | 8 | 16 | 0 | 10 | 78cfc8a9 |
| H100 | meta-llama/Llama-2-7b-hf | attention | 58,632 | 31 | 57,272 | 1,344 | 2,704 | 209 | 4 | 63d9a674 |
| H100 | meta-llama/Llama-2-7b-hf | mlp | 1,044 | 58 | 1,036 | 8 | 16 | 0 | 10 | 78cfc8a9 |
| H100 | microsoft/phi-2 | attention | 58,632 | 31 | 57,272 | 1,344 | 2,704 | 273 | 4 | 63d9a674 |
| H100 | microsoft/phi-2 | mlp | 261 | 53 | 259 | 2 | 4 | 0 | 9 | e3bd7637 |
| H100 | Qwen/Qwen-72B | attention | 58,632 | 31 | 57,272 | 1,344 | 2,704 | 139 | 4 | 63d9a674 |
| H100 | Qwen/Qwen-72B | mlp | 1,044 | 58 | 1,036 | 8 | 16 | 0 | 10 | 78cfc8a9 |

### C.1 每个 compute 文件的 shape 域

| GPU | 模型 | 文件 | TP | Phase | Backend | 观测域 |
|---|---|---|---|---|---|---|
| A100 | Qwen/Qwen-72B | attention | 1,2,4,8 | decode,prefill | FLASH_ATTENTION | batch≤128; KV≤4032; prefill≤4096 |
| A100 | Qwen/Qwen-72B | mlp | 1,2,4,8 | token | — | num_tokens 1–4096; 中位步长 8 |
| A100 | codellama/CodeLlama-34b-Instruct-hf | attention | 1,2,4,8 | decode,prefill | FLASH_ATTENTION | batch≤128; KV≤4032; prefill≤4096 |
| A100 | codellama/CodeLlama-34b-Instruct-hf | mlp | 1,2,4,8 | token | — | num_tokens 1–4096; 中位步长 8 |
| A100 | internlm/internlm-20b | attention | 1,2,4,8 | decode,prefill | FLASH_ATTENTION | batch≤128; KV≤4032; prefill≤4096 |
| A100 | internlm/internlm-20b | mlp | 1,2,4,8 | token | — | num_tokens 1–4096; 中位步长 8 |
| A100 | meta-llama/Llama-2-70b-hf | attention | 1,2,4,8 | decode,prefill | FLASH_ATTENTION | batch≤128; KV≤4032; prefill≤4096 |
| A100 | meta-llama/Llama-2-70b-hf | mlp | 1,2,4,8 | token | — | num_tokens 1–4096; 中位步长 8 |
| A100 | meta-llama/Llama-2-7b-hf | attention | 1,2,4,8 | decode,prefill | FLASH_ATTENTION | batch≤128; KV≤4032; prefill≤4096 |
| A100 | meta-llama/Llama-2-7b-hf | mlp | 1,2,4,8 | token | — | num_tokens 1–4096; 中位步长 8 |
| A100 | meta-llama/Meta-Llama-3-70B | attention | 1,2,4,8 | decode,prefill | FLASHINFER | batch≤512; KV≤16320; prefill≤16384 |
| A100 | meta-llama/Meta-Llama-3-70B | mlp | 1,2,4,8 | token | — | num_tokens 1–32768; 中位步长 32 |
| A100 | meta-llama/Meta-Llama-3-8B | attention | 1,4 | decode,prefill | FLASHINFER | batch≤512; KV≤16320; prefill≤16384 |
| A100 | meta-llama/Meta-Llama-3-8B | mlp | 1,2,4,8 | token | — | num_tokens 1–32768; 中位步长 32 |
| A100 | microsoft/phi-2 | attention | 1,2,4,8 | decode,prefill | FLASH_ATTENTION | batch≤128; KV≤4032; prefill≤4096 |
| A100 | microsoft/phi-2 | mlp | 1 | token | — | num_tokens 1–4096; 中位步长 8 |
| A40 | Qwen/Qwen-72B | attention | 1,2,4,8 | decode,prefill | FLASH_ATTENTION | batch≤128; KV≤4032; prefill≤4096 |
| A40 | Qwen/Qwen-72B | mlp | 1,2,4,8 | token | — | num_tokens 1–4096; 中位步长 8 |
| A40 | codellama/CodeLlama-34b-Instruct-hf | attention | 1,2,4,8 | decode,prefill | FLASH_ATTENTION | batch≤128; KV≤4032; prefill≤4096 |
| A40 | codellama/CodeLlama-34b-Instruct-hf | mlp | 1,2,4,8 | token | — | num_tokens 1–4096; 中位步长 8 |
| A40 | internlm/internlm-20b | attention | 1,2,4,8 | decode,prefill | FLASH_ATTENTION | batch≤128; KV≤4032; prefill≤4096 |
| A40 | internlm/internlm-20b | mlp | 1,2,4,8 | token | — | num_tokens 1–4096; 中位步长 8 |
| A40 | meta-llama/Llama-2-70b-hf | attention | 1,2,4,8 | decode,prefill | FLASH_ATTENTION | batch≤128; KV≤4032; prefill≤4096 |
| A40 | meta-llama/Llama-2-70b-hf | mlp | 1,2,4,8 | token | — | num_tokens 1–4096; 中位步长 8 |
| A40 | meta-llama/Llama-2-7b-hf | attention | 1,2,4,8 | decode,prefill | FLASH_ATTENTION | batch≤128; KV≤4032; prefill≤4096 |
| A40 | meta-llama/Llama-2-7b-hf | mlp | 1,2,4,8 | token | — | num_tokens 1–4096; 中位步长 8 |
| A40 | microsoft/phi-2 | attention | 1,2,4,8 | decode,prefill | FLASH_ATTENTION | batch≤128; KV≤4032; prefill≤4096 |
| A40 | microsoft/phi-2 | mlp | 1 | token | — | num_tokens 1–4096; 中位步长 8 |
| H100 | Qwen/Qwen-72B | attention | 1,2,4,8 | decode,prefill | FLASH_ATTENTION | batch≤128; KV≤4032; prefill≤4096 |
| H100 | Qwen/Qwen-72B | mlp | 1,2,4,8 | token | — | num_tokens 1–4096; 中位步长 8 |
| H100 | codellama/CodeLlama-34b-Instruct-hf | attention | 1,2,4,8 | decode,prefill | FLASH_ATTENTION | batch≤128; KV≤4032; prefill≤4096 |
| H100 | codellama/CodeLlama-34b-Instruct-hf | mlp | 1,2,4,8 | token | — | num_tokens 1–4096; 中位步长 8 |
| H100 | internlm/internlm-20b | attention | 1,2,4,8 | decode,prefill | FLASH_ATTENTION | batch≤128; KV≤4032; prefill≤4096 |
| H100 | internlm/internlm-20b | mlp | 1,2,4,8 | token | — | num_tokens 1–4096; 中位步长 8 |
| H100 | meta-llama/Llama-2-70b-hf | attention | 1,2,4,8 | decode,prefill | FLASH_ATTENTION | batch≤128; KV≤4032; prefill≤4096 |
| H100 | meta-llama/Llama-2-70b-hf | mlp | 1,2,4,8 | token | — | num_tokens 1–4096; 中位步长 8 |
| H100 | meta-llama/Llama-2-7b-hf | attention | 1,2,4,8 | decode,prefill | FLASH_ATTENTION | batch≤128; KV≤4032; prefill≤4096 |
| H100 | meta-llama/Llama-2-7b-hf | mlp | 1,2,4,8 | token | — | num_tokens 1–4096; 中位步长 8 |
| H100 | microsoft/phi-2 | attention | 1,2,4,8 | decode,prefill | FLASH_ATTENTION | batch≤128; KV≤4032; prefill≤4096 |
| H100 | microsoft/phi-2 | mlp | 1 | token | — | num_tokens 1–4096; 中位步长 8 |

### C.2 GPU×phase×operator 运行时间分布汇总（跨 model×TP cell 的中位）

单位均为 ms。该表用于量级比较，不替代同 shape 严格配对。

| GPU | Phase | Operator | Cells | P50中位 | P95中位 | P99中位 | 最大观测 |
|---|---|---|---|---|---|---|---|
| A100 | decode | attn_decode | 30 | 0.1980 | 0.9897 | 1.2935 | 6.3050 |
| A100 | decode | attn_input_reshape | 30 | 0.0000 | 0.0000 | 0.0000 | 0.0000 |
| A100 | decode | attn_kv_cache_save | 6 | 0.0030 | 0.0035 | 0.0040 | 0.0050 |
| A100 | decode | attn_output_reshape | 30 | 0.0020 | 0.0020 | 0.0020 | 0.0090 |
| A100 | decode | attn_prefill | 6 | 0.0000 | 0.0000 | 0.0000 | 0.0000 |
| A100 | prefill | attn_decode | 6 | 0.0000 | 0.0000 | 0.0000 | 0.0000 |
| A100 | prefill | attn_input_reshape | 30 | 0.0000 | 0.0000 | 0.0000 | 0.0000 |
| A100 | prefill | attn_kv_cache_save | 6 | 0.1030 | 3.2989 | 7.4416 | 9.3410 |
| A100 | prefill | attn_output_reshape | 30 | 0.0040 | 0.0115 | 0.0125 | 0.0860 |
| A100 | prefill | attn_prefill | 30 | 0.1940 | 1.3420 | 1.7526 | 24.7470 |
| A100 | token | add | 29 | 0.0270 | 0.1030 | 0.1104 | 0.9450 |
| A100 | token | attn_post_proj | 29 | 0.1870 | 0.6480 | 0.7272 | 17.8970 |
| A100 | token | attn_pre_proj | 29 | 0.3545 | 1.4095 | 1.4239 | 20.3860 |
| A100 | token | attn_rope | 29 | 0.0210 | 0.0940 | 0.0987 | 1.2785 |
| A100 | token | emb | 29 | 0.1110 | 0.3860 | 0.4150 | 3.7280 |
| A100 | token | input_layernorm | 29 | 0.0415 | 0.1730 | 0.1845 | 1.5055 |
| A100 | token | mlp_act | 29 | 0.0700 | 0.2430 | 0.2615 | 5.6305 |
| A100 | token | mlp_down_proj | 29 | 0.4890 | 1.8347 | 2.1514 | 62.7030 |
| A100 | token | mlp_up_proj | 29 | 0.9300 | 3.6980 | 4.0710 | 136.4065 |
| A100 | token | post_attention_layernorm | 28 | 0.0520 | 0.1735 | 0.1866 | 1.5000 |
| A40 | decode | attn_decode | 24 | 0.5140 | 2.4055 | 3.0295 | 14.9030 |
| A40 | decode | attn_input_reshape | 24 | 0.0000 | 0.0000 | 0.0000 | 0.0000 |
| A40 | decode | attn_output_reshape | 24 | 0.0020 | 0.0020 | 0.0020 | 0.0090 |
| A40 | prefill | attn_input_reshape | 24 | 0.0000 | 0.0000 | 0.0000 | 0.0000 |
| A40 | prefill | attn_output_reshape | 24 | 0.0105 | 0.0465 | 0.0540 | 0.2370 |
| A40 | prefill | attn_prefill | 24 | 0.3595 | 2.0393 | 2.5618 | 12.2010 |
| A40 | token | add | 21 | 0.0840 | 0.3130 | 0.3432 | 0.3520 |
| A40 | token | attn_post_proj | 21 | 0.3425 | 1.1205 | 1.2961 | 4.7930 |
| A40 | token | attn_pre_proj | 21 | 0.5290 | 1.6285 | 1.8455 | 18.8810 |
| A40 | token | attn_rope | 21 | 0.0340 | 0.1175 | 0.1270 | 0.5510 |
| A40 | token | emb | 21 | 0.0930 | 0.3330 | 0.3662 | 0.4020 |
| A40 | token | input_layernorm | 21 | 0.0820 | 0.2820 | 0.3046 | 0.3175 |
| A40 | token | mlp_act | 21 | 0.0730 | 0.2660 | 0.2918 | 1.2785 |
| A40 | token | mlp_down_proj | 21 | 0.8695 | 2.8995 | 3.2052 | 17.0395 |
| A40 | token | mlp_up_proj | 21 | 1.7040 | 5.6905 | 6.1778 | 38.6950 |
| A40 | token | post_attention_layernorm | 20 | 0.0820 | 0.2825 | 0.3055 | 0.3160 |
| H100 | decode | attn_decode | 24 | 0.1170 | 0.4625 | 0.5840 | 3.5750 |
| H100 | decode | attn_input_reshape | 24 | 0.0000 | 0.0000 | 0.0000 | 0.0000 |
| H100 | decode | attn_output_reshape | 24 | 0.0010 | 0.0020 | 0.0020 | 0.0080 |
| H100 | prefill | attn_input_reshape | 24 | 0.0000 | 0.0000 | 0.0000 | 0.0000 |
| H100 | prefill | attn_output_reshape | 24 | 0.0030 | 0.0085 | 0.0100 | 0.0520 |
| H100 | prefill | attn_prefill | 24 | 0.1255 | 0.6261 | 0.7753 | 3.1590 |
| H100 | token | add | 21 | 0.0140 | 0.0560 | 0.0610 | 0.0630 |
| H100 | token | attn_post_proj | 21 | 0.0520 | 0.1770 | 0.1957 | 0.8120 |
| H100 | token | attn_pre_proj | 21 | 0.0895 | 0.2610 | 0.2905 | 2.6085 |
| H100 | token | attn_rope | 21 | 0.0100 | 0.0380 | 0.0410 | 0.1780 |
| H100 | token | emb | 21 | 0.0530 | 0.1840 | 0.1988 | 0.2500 |
| H100 | token | input_layernorm | 21 | 0.0200 | 0.1025 | 0.1104 | 0.1245 |
| H100 | token | mlp_act | 21 | 0.0190 | 0.0730 | 0.0774 | 0.3630 |
| H100 | token | mlp_down_proj | 21 | 0.1275 | 0.4380 | 0.4590 | 2.8920 |
| H100 | token | mlp_up_proj | 21 | 0.2705 | 0.9330 | 0.9886 | 5.7490 |
| H100 | token | post_attention_layernorm | 20 | 0.0230 | 0.1030 | 0.1110 | 0.1260 |

### C.3 行内测量抖动完整汇总

| GPU | Operator | 模型 | 行 | 文件CV P50中位(%) | 文件CV P95中位(%) | 单文件P95最大(%) | Range P95中位(%) |
|---|---|---|---|---|---|---|---|
| A100 | attn_decode | 8 | 387,547 | 0.480 | 2.144 | 3.081 | 5.322 |
| A100 | attn_post_proj | 8 | 9,129 | 0.904 | 2.584 | 3.279 | 9.471 |
| A100 | attn_pre_proj | 8 | 9,129 | 0.874 | 2.556 | 2.872 | 8.868 |
| A100 | attn_prefill | 8 | 247,819 | 0.728 | 2.218 | 3.070 | 5.968 |
| A100 | mlp_down_proj | 8 | 9,129 | 0.874 | 2.666 | 3.270 | 8.883 |
| A100 | mlp_up_proj | 8 | 9,129 | 0.747 | 2.097 | 2.871 | 7.169 |
| A40 | attn_decode | 6 | 245,760 | 0.147 | 0.941 | 1.396 | 2.421 |
| A40 | attn_post_proj | 6 | 5,481 | 0.714 | 2.067 | 3.591 | 7.999 |
| A40 | attn_pre_proj | 6 | 5,481 | 0.656 | 2.076 | 5.354 | 7.337 |
| A40 | attn_prefill | 6 | 106,032 | 0.804 | 2.727 | 3.528 | 7.421 |
| A40 | mlp_down_proj | 6 | 5,481 | 0.677 | 2.047 | 2.804 | 7.538 |
| A40 | mlp_up_proj | 6 | 5,481 | 0.563 | 2.114 | 2.219 | 7.505 |
| H100 | attn_decode | 6 | 245,760 | 0.425 | 2.761 | 3.390 | 6.665 |
| H100 | attn_post_proj | 6 | 5,481 | 1.519 | 7.764 | 15.626 | 21.905 |
| H100 | attn_pre_proj | 6 | 5,481 | 1.164 | 11.371 | 12.870 | 26.565 |
| H100 | attn_prefill | 6 | 106,032 | 0.753 | 2.547 | 3.032 | 6.716 |
| H100 | mlp_down_proj | 6 | 5,481 | 1.249 | 8.527 | 11.397 | 24.913 |
| H100 | mlp_up_proj | 6 | 5,481 | 0.634 | 8.528 | 14.890 | 21.370 |

### C.4 相邻 shape 单调性完整汇总

| GPU | 类型 | Phase | Operator | 轴 | 相邻对 | 下降>5% | 上升>5% | 最大下降 | 最大上升 |
|---|---|---|---|---|---|---|---|---|---|
| A100 | attention | decode | attn_decode | batch_size | 363,135 | 0.89% | 11.62% | 100.00% | 122.73% |
| A100 | attention | decode | attn_decode | kv_cache_size | 361,665 | 0.68% | 20.79% | 100.00% | 74.07% |
| A100 | attention | prefill | attn_prefill | kv_cache_size | 112,158 | 4.77% | 17.02% | 41.46% | 257.69% |
| A100 | attention | prefill | attn_prefill | prefill_chunk_size | 109,746 | 1.48% | 45.98% | 42.92% | 4957.47% |
| A100 | mlp | token | add | num_tokens | 9,018 | 1.45% | 7.32% | 50.00% | 100.00% |
| A100 | mlp | token | attn_post_proj | num_tokens | 9,018 | 1.83% | 7.53% | 40.00% | 85.71% |
| A100 | mlp | token | attn_pre_proj | num_tokens | 9,018 | 1.94% | 8.27% | 38.75% | 91.67% |
| A100 | mlp | token | attn_rope | num_tokens | 9,018 | 2.23% | 7.37% | 33.33% | 53.85% |
| A100 | mlp | token | emb | num_tokens | 9,018 | 0.44% | 7.62% | 71.43% | 75.00% |
| A100 | mlp | token | input_layernorm | num_tokens | 9,018 | 1.31% | 5.81% | 20.00% | 68.75% |
| A100 | mlp | token | mlp_act | num_tokens | 9,018 | 1.39% | 5.87% | 33.33% | 52.63% |
| A100 | mlp | token | mlp_down_proj | num_tokens | 9,018 | 1.28% | 7.66% | 35.00% | 82.14% |
| A100 | mlp | token | mlp_up_proj | num_tokens | 9,018 | 0.65% | 6.97% | 37.50% | 78.69% |
| A100 | mlp | token | post_attention_layernorm | num_tokens | 8,760 | 1.32% | 5.81% | 20.00% | 66.67% |
| A40 | attention | decode | attn_decode | batch_size | 240,792 | 0.31% | 13.82% | 22.73% | 180.00% |
| A40 | attention | decode | attn_decode | kv_cache_size | 239,616 | 0.34% | 26.72% | 38.10% | 92.31% |
| A40 | attention | prefill | attn_prefill | kv_cache_size | 99,000 | 5.68% | 17.35% | 55.08% | 166.67% |
| A40 | attention | prefill | attn_prefill | prefill_chunk_size | 99,024 | 1.94% | 49.75% | 47.71% | 205.26% |
| A40 | mlp | token | add | num_tokens | 5,418 | 0.66% | 8.25% | 40.00% | 100.00% |
| A40 | mlp | token | attn_post_proj | num_tokens | 5,418 | 2.55% | 8.55% | 35.29% | 84.26% |
| A40 | mlp | token | attn_pre_proj | num_tokens | 5,418 | 2.09% | 7.79% | 34.65% | 98.01% |
| A40 | mlp | token | attn_rope | num_tokens | 5,418 | 1.79% | 8.23% | 42.86% | 100.00% |
| A40 | mlp | token | emb | num_tokens | 5,418 | 0.46% | 8.49% | 70.00% | 100.00% |
| A40 | mlp | token | input_layernorm | num_tokens | 5,418 | 0.41% | 8.29% | 25.00% | 50.00% |
| A40 | mlp | token | mlp_act | num_tokens | 5,418 | 0.87% | 6.70% | 40.00% | 100.00% |
| A40 | mlp | token | mlp_down_proj | num_tokens | 5,418 | 2.07% | 8.05% | 33.05% | 179.87% |
| A40 | mlp | token | mlp_up_proj | num_tokens | 5,418 | 1.97% | 8.42% | 28.53% | 85.45% |
| A40 | mlp | token | post_attention_layernorm | num_tokens | 5,160 | 0.35% | 8.45% | 25.00% | 50.00% |
| H100 | attention | decode | attn_decode | batch_size | 240,792 | 1.44% | 11.65% | 31.03% | 118.75% |
| H100 | attention | decode | attn_decode | kv_cache_size | 239,616 | 1.11% | 22.69% | 34.48% | 58.33% |
| H100 | attention | prefill | attn_prefill | kv_cache_size | 99,000 | 5.90% | 13.63% | 36.96% | 75.61% |
| H100 | attention | prefill | attn_prefill | prefill_chunk_size | 99,024 | 2.38% | 38.86% | 39.62% | 119.61% |
| H100 | mlp | token | add | num_tokens | 5,418 | 0.87% | 8.42% | 33.33% | 100.00% |
| H100 | mlp | token | attn_post_proj | num_tokens | 5,418 | 6.61% | 12.70% | 34.55% | 105.88% |
| H100 | mlp | token | attn_pre_proj | num_tokens | 5,418 | 4.36% | 10.19% | 39.82% | 116.88% |
| H100 | mlp | token | attn_rope | num_tokens | 5,418 | 2.77% | 8.80% | 33.33% | 50.00% |
| H100 | mlp | token | emb | num_tokens | 5,418 | 0.76% | 9.71% | 75.00% | 100.00% |
| H100 | mlp | token | input_layernorm | num_tokens | 5,418 | 1.26% | 7.68% | 20.00% | 75.00% |
| H100 | mlp | token | mlp_act | num_tokens | 5,418 | 1.61% | 7.31% | 33.33% | 100.00% |
| H100 | mlp | token | mlp_down_proj | num_tokens | 5,418 | 7.62% | 12.38% | 38.98% | 182.47% |
| H100 | mlp | token | mlp_up_proj | num_tokens | 5,418 | 3.84% | 9.60% | 40.62% | 100.00% |
| H100 | mlp | token | post_attention_layernorm | num_tokens | 5,160 | 1.49% | 8.16% | 25.00% | 75.00% |

### C.5 局部大跳变复测候选 Top 50

筛选要求 `runtime_prev≥0.02 ms` 且相邻 shape 相对步长≤25%；按绝对时延变化百分比排序。它们是复测候选，不是已证实的 kernel 因果。

| GPU | 模型 | TP | Phase | Operator | 轴 | x前 | x后 | 前ms | 后ms | 变化 | 绝对变化ms |
|---|---|---|---|---|---|---|---|---|---|---|---|
| H100 | Qwen/Qwen-72B | 1 | token | mlp_down_proj | num_tokens | 512 | 520 | 0.2310 | 0.6525 | 182.47% | 0.4215 |
| A40 | Qwen/Qwen-72B | 1 | token | mlp_down_proj | num_tokens | 256 | 264 | 1.0430 | 2.9190 | 179.87% | 1.8760 |
| H100 | codellama/CodeLlama-34b-Instruct-hf | 2 | token | mlp_down_proj | num_tokens | 512 | 520 | 0.1150 | 0.3195 | 177.83% | 0.2045 |
| H100 | meta-llama/Llama-2-70b-hf | 2 | token | mlp_down_proj | num_tokens | 512 | 520 | 0.1400 | 0.3750 | 167.86% | 0.2350 |
| A40 | meta-llama/Llama-2-70b-hf | 1 | prefill | attn_prefill | kv_cache_size | 448 | 480 | 0.0300 | 0.0800 | 166.67% | 0.0500 |
| A40 | microsoft/phi-2 | 1 | prefill | attn_prefill | prefill_chunk_size | 128 | 160 | 0.0265 | 0.0700 | 164.15% | 0.0435 |
| A40 | codellama/CodeLlama-34b-Instruct-hf | 1 | prefill | attn_prefill | kv_cache_size | 448 | 480 | 0.0310 | 0.0810 | 161.29% | 0.0500 |
| A40 | meta-llama/Llama-2-7b-hf | 1 | prefill | attn_prefill | prefill_chunk_size | 128 | 160 | 0.0280 | 0.0730 | 160.71% | 0.0450 |
| A40 | Qwen/Qwen-72B | 2 | prefill | attn_prefill | prefill_chunk_size | 128 | 160 | 0.0280 | 0.0730 | 160.71% | 0.0450 |
| A40 | codellama/CodeLlama-34b-Instruct-hf | 2 | prefill | attn_prefill | kv_cache_size | 384 | 416 | 0.0270 | 0.0700 | 159.26% | 0.0430 |
| H100 | meta-llama/Llama-2-70b-hf | 1 | token | mlp_down_proj | num_tokens | 512 | 520 | 0.2690 | 0.6895 | 156.32% | 0.4205 |
| H100 | codellama/CodeLlama-34b-Instruct-hf | 1 | token | mlp_down_proj | num_tokens | 512 | 520 | 0.2250 | 0.5730 | 154.67% | 0.3480 |
| A40 | internlm/internlm-20b | 1 | prefill | attn_prefill | prefill_chunk_size | 128 | 160 | 0.0300 | 0.0760 | 153.33% | 0.0460 |
| A40 | Qwen/Qwen-72B | 2 | prefill | attn_prefill | prefill_chunk_size | 128 | 160 | 0.0335 | 0.0840 | 150.75% | 0.0505 |
| A40 | meta-llama/Llama-2-70b-hf | 2 | prefill | attn_prefill | kv_cache_size | 384 | 416 | 0.0280 | 0.0700 | 150.00% | 0.0420 |
| A40 | microsoft/phi-2 | 1 | prefill | attn_prefill | prefill_chunk_size | 128 | 160 | 0.0300 | 0.0740 | 146.67% | 0.0440 |
| A40 | meta-llama/Llama-2-7b-hf | 1 | prefill | attn_prefill | prefill_chunk_size | 128 | 160 | 0.0345 | 0.0840 | 143.48% | 0.0495 |
| A40 | meta-llama/Llama-2-70b-hf | 1 | prefill | attn_prefill | prefill_chunk_size | 64 | 80 | 0.0200 | 0.0480 | 140.00% | 0.0280 |
| H100 | Qwen/Qwen-72B | 2 | token | mlp_down_proj | num_tokens | 512 | 520 | 0.1230 | 0.2950 | 139.84% | 0.1720 |
| A40 | codellama/CodeLlama-34b-Instruct-hf | 2 | prefill | attn_prefill | prefill_chunk_size | 64 | 80 | 0.0290 | 0.0690 | 137.93% | 0.0400 |
| A40 | meta-llama/Llama-2-70b-hf | 2 | prefill | attn_prefill | prefill_chunk_size | 64 | 80 | 0.0290 | 0.0690 | 137.93% | 0.0400 |
| A100 | internlm/internlm-20b | 4 | prefill | attn_prefill | prefill_chunk_size | 128 | 160 | 0.0265 | 0.0630 | 137.74% | 0.0365 |
| A40 | codellama/CodeLlama-34b-Instruct-hf | 2 | prefill | attn_prefill | prefill_chunk_size | 96 | 112 | 0.0270 | 0.0640 | 137.04% | 0.0370 |
| A40 | codellama/CodeLlama-34b-Instruct-hf | 2 | prefill | attn_prefill | kv_cache_size | 384 | 416 | 0.0270 | 0.0640 | 137.04% | 0.0370 |
| A40 | meta-llama/Llama-2-70b-hf | 2 | prefill | attn_prefill | prefill_chunk_size | 96 | 112 | 0.0270 | 0.0640 | 137.04% | 0.0370 |
| A40 | meta-llama/Llama-2-70b-hf | 2 | prefill | attn_prefill | kv_cache_size | 384 | 416 | 0.0270 | 0.0640 | 137.04% | 0.0370 |
| A100 | meta-llama/Llama-2-70b-hf | 1 | prefill | attn_prefill | prefill_chunk_size | 64 | 80 | 0.0690 | 0.1600 | 131.88% | 0.0910 |
| A40 | meta-llama/Llama-2-70b-hf | 2 | prefill | attn_prefill | prefill_chunk_size | 128 | 160 | 0.0230 | 0.0530 | 130.43% | 0.0300 |
| A40 | meta-llama/Llama-2-7b-hf | 1 | prefill | attn_prefill | prefill_chunk_size | 128 | 160 | 0.0395 | 0.0910 | 130.38% | 0.0515 |
| A40 | meta-llama/Llama-2-70b-hf | 2 | prefill | attn_prefill | prefill_chunk_size | 128 | 160 | 0.0200 | 0.0460 | 130.00% | 0.0260 |
| A40 | codellama/CodeLlama-34b-Instruct-hf | 4 | prefill | attn_prefill | prefill_chunk_size | 64 | 80 | 0.0270 | 0.0620 | 129.63% | 0.0350 |
| A40 | microsoft/phi-2 | 1 | prefill | attn_prefill | prefill_chunk_size | 128 | 160 | 0.0205 | 0.0470 | 129.27% | 0.0265 |
| A40 | meta-llama/Llama-2-70b-hf | 1 | prefill | attn_prefill | prefill_chunk_size | 64 | 80 | 0.0240 | 0.0550 | 129.17% | 0.0310 |
| A40 | internlm/internlm-20b | 1 | prefill | attn_prefill | prefill_chunk_size | 128 | 160 | 0.0385 | 0.0880 | 128.57% | 0.0495 |
| A100 | meta-llama/Llama-2-70b-hf | 1 | prefill | attn_prefill | prefill_chunk_size | 64 | 80 | 0.0760 | 0.1730 | 127.63% | 0.0970 |
| A40 | Qwen/Qwen-72B | 2 | prefill | attn_prefill | prefill_chunk_size | 128 | 160 | 0.0400 | 0.0910 | 127.50% | 0.0510 |
| A40 | microsoft/phi-2 | 1 | prefill | attn_prefill | prefill_chunk_size | 128 | 160 | 0.0445 | 0.1010 | 126.97% | 0.0565 |
| A40 | Qwen/Qwen-72B | 2 | prefill | attn_prefill | kv_cache_size | 384 | 416 | 0.0395 | 0.0895 | 126.58% | 0.0500 |
| A100 | codellama/CodeLlama-34b-Instruct-hf | 1 | prefill | attn_prefill | prefill_chunk_size | 64 | 80 | 0.0760 | 0.1720 | 126.32% | 0.0960 |
| A40 | meta-llama/Llama-2-70b-hf | 2 | prefill | attn_prefill | prefill_chunk_size | 128 | 160 | 0.0270 | 0.0610 | 125.93% | 0.0340 |
| A40 | meta-llama/Llama-2-70b-hf | 4 | prefill | attn_prefill | prefill_chunk_size | 64 | 80 | 0.0270 | 0.0610 | 125.93% | 0.0340 |
| A40 | microsoft/phi-2 | 1 | prefill | attn_prefill | prefill_chunk_size | 128 | 160 | 0.0440 | 0.0990 | 125.00% | 0.0550 |
| A40 | codellama/CodeLlama-34b-Instruct-hf | 2 | prefill | attn_prefill | prefill_chunk_size | 128 | 160 | 0.0200 | 0.0450 | 125.00% | 0.0250 |
| A40 | meta-llama/Llama-2-7b-hf | 1 | prefill | attn_prefill | prefill_chunk_size | 128 | 160 | 0.0280 | 0.0630 | 125.00% | 0.0350 |
| A40 | meta-llama/Llama-2-7b-hf | 1 | prefill | attn_prefill | kv_cache_size | 384 | 416 | 0.0400 | 0.0900 | 125.00% | 0.0500 |
| A40 | codellama/CodeLlama-34b-Instruct-hf | 2 | prefill | attn_prefill | prefill_chunk_size | 64 | 80 | 0.0290 | 0.0650 | 124.14% | 0.0360 |
| A40 | meta-llama/Llama-2-70b-hf | 2 | prefill | attn_prefill | prefill_chunk_size | 64 | 80 | 0.0290 | 0.0650 | 124.14% | 0.0360 |
| A40 | meta-llama/Llama-2-70b-hf | 2 | prefill | attn_prefill | prefill_chunk_size | 64 | 80 | 0.0290 | 0.0650 | 124.14% | 0.0360 |
| A40 | meta-llama/Llama-2-70b-hf | 1 | token | mlp_down_proj | num_tokens | 256 | 264 | 1.1220 | 2.5060 | 123.35% | 1.3840 |
| A40 | microsoft/phi-2 | 1 | prefill | attn_prefill | kv_cache_size | 384 | 416 | 0.0300 | 0.0670 | 123.33% | 0.0370 |

### C.6 严格 shape 交集的跨 GPU speedup

| From | To | 类型 | Operator | 模型 | TP cells | 共同shape | 中位speedup | 最小 | 最大 | 目标GPU更慢 |
|---|---|---|---|---|---|---|---|---|---|---|
| A100 | H100 | attention | attn_decode | 6 | 24 | 242,672 | 1.690× | 1.568× | 1.798× | 0.00% |
| A100 | H100 | attention | attn_prefill | 6 | 24 | 100,944 | 1.497× | 1.270× | 1.703× | 0.29% |
| A100 | H100 | mlp | attn_post_proj | 6 | 21 | 5,439 | 2.865× | 2.000× | 3.155× | 0.00% |
| A100 | H100 | mlp | attn_pre_proj | 6 | 21 | 5,439 | 2.800× | 2.324× | 3.111× | 0.00% |
| A100 | H100 | mlp | mlp_act | 6 | 21 | 5,439 | 1.881× | 1.667× | 1.918× | 0.00% |
| A100 | H100 | mlp | mlp_down_proj | 6 | 21 | 5,439 | 2.923× | 2.350× | 3.224× | 0.00% |
| A100 | H100 | mlp | mlp_up_proj | 6 | 21 | 5,439 | 2.827× | 2.392× | 2.990× | 0.00% |
| A40 | A100 | attention | attn_decode | 6 | 24 | 242,672 | 2.583× | 2.091× | 3.206× | 2.24% |
| A40 | A100 | attention | attn_prefill | 6 | 24 | 100,944 | 1.849× | 1.352× | 2.153× | 2.45% |
| A40 | A100 | mlp | attn_post_proj | 6 | 21 | 5,439 | 1.994× | 1.877× | 2.071× | 0.00% |
| A40 | A100 | mlp | attn_pre_proj | 6 | 21 | 5,439 | 1.969× | 1.899× | 2.143× | 0.00% |
| A40 | A100 | mlp | mlp_act | 6 | 21 | 5,439 | 1.810× | 1.711× | 2.248× | 4.45% |
| A40 | A100 | mlp | mlp_down_proj | 6 | 21 | 5,439 | 2.015× | 1.893× | 2.107× | 0.04% |
| A40 | A100 | mlp | mlp_up_proj | 6 | 21 | 5,439 | 2.015× | 1.934× | 2.201× | 0.00% |
| A40 | H100 | attention | attn_decode | 6 | 24 | 242,688 | 4.385× | 3.529× | 5.800× | 0.03% |
| A40 | H100 | attention | attn_prefill | 6 | 24 | 100,944 | 2.800× | 1.769× | 3.671× | 0.09% |
| A40 | H100 | mlp | attn_post_proj | 6 | 21 | 5,439 | 5.566× | 3.917× | 5.862× | 0.00% |
| A40 | H100 | mlp | attn_pre_proj | 6 | 21 | 5,439 | 5.592× | 4.598× | 6.225× | 0.00% |
| A40 | H100 | mlp | mlp_act | 6 | 21 | 5,439 | 3.476× | 2.938× | 4.000× | 0.40% |
| A40 | H100 | mlp | mlp_down_proj | 6 | 21 | 5,439 | 6.000× | 4.698× | 6.439× | 0.00% |
| A40 | H100 | mlp | mlp_up_proj | 6 | 21 | 5,439 | 5.699× | 4.986× | 6.136× | 0.00% |

### C.7 Compute-only TP scaling 全表

| GPU | 类型 | Operator | TP | 模型 | 共同shape | 中位speedup | 最小 | 最大 | 中位效率 | 慢于TP1 |
|---|---|---|---|---|---|---|---|---|---|---|
| A100 | attention | attn_decode | 2 | 7 | 81,127 | 1.796× | 1.728× | 1.870× | 89.81% | 0.02% |
| A100 | attention | attn_decode | 4 | 8 | 96,699 | 3.248× | 3.035× | 3.498× | 81.21% | 0.00% |
| A100 | attention | attn_decode | 8 | 7 | 81,127 | 5.614× | 5.389× | 6.242× | 70.17% | 0.00% |
| A100 | attention | attn_prefill | 2 | 7 | 27,607 | 1.781× | 1.716× | 1.873× | 89.05% | 0.27% |
| A100 | attention | attn_prefill | 4 | 8 | 29,978 | 2.955× | 2.795× | 3.262× | 73.88% | 0.11% |
| A100 | attention | attn_prefill | 8 | 7 | 27,607 | 4.449× | 4.047× | 5.263× | 55.62% | 0.04% |
| A100 | mlp | attn_post_proj | 2 | 7 | 2,197 | 1.905× | 1.852× | 1.949× | 95.24% | 0.00% |
| A100 | mlp | attn_post_proj | 4 | 7 | 2,197 | 3.753× | 3.669× | 3.936× | 93.83% | 0.00% |
| A100 | mlp | attn_post_proj | 8 | 7 | 2,197 | 7.537× | 6.367× | 7.641× | 94.22% | 0.00% |
| A100 | mlp | attn_pre_proj | 2 | 7 | 2,197 | 2.000× | 1.977× | 2.050× | 100.00% | 0.00% |
| A100 | mlp | attn_pre_proj | 4 | 7 | 2,197 | 3.866× | 3.807× | 4.176× | 96.66% | 0.00% |
| A100 | mlp | attn_pre_proj | 8 | 7 | 2,197 | 7.410× | 7.200× | 7.939× | 92.62% | 0.00% |
| A100 | mlp | mlp_act | 2 | 7 | 2,197 | 2.000× | 1.901× | 2.027× | 100.00% | 0.00% |
| A100 | mlp | mlp_act | 4 | 7 | 2,197 | 3.815× | 3.622× | 4.060× | 95.37% | 0.00% |
| A100 | mlp | mlp_act | 8 | 7 | 2,197 | 7.412× | 5.857× | 7.875× | 92.65% | 0.00% |
| A100 | mlp | mlp_down_proj | 2 | 7 | 2,197 | 2.000× | 1.980× | 2.059× | 100.01% | 0.00% |
| A100 | mlp | mlp_down_proj | 4 | 7 | 2,197 | 4.029× | 3.975× | 4.109× | 100.73% | 0.00% |
| A100 | mlp | mlp_down_proj | 8 | 7 | 2,197 | 7.485× | 7.207× | 8.010× | 93.56% | 0.00% |
| A100 | mlp | mlp_up_proj | 2 | 7 | 2,197 | 2.013× | 1.884× | 2.023× | 100.63% | 0.00% |
| A100 | mlp | mlp_up_proj | 4 | 7 | 2,197 | 4.036× | 3.839× | 4.133× | 100.91% | 0.00% |
| A100 | mlp | mlp_up_proj | 8 | 7 | 2,197 | 8.016× | 7.107× | 8.358× | 100.20% | 0.00% |
| A40 | attention | attn_decode | 2 | 6 | 60,672 | 1.893× | 1.577× | 1.928× | 94.67% | 0.00% |
| A40 | attention | attn_decode | 4 | 6 | 60,672 | 3.664× | 2.762× | 3.767× | 91.59% | 0.00% |
| A40 | attention | attn_decode | 8 | 6 | 60,672 | 6.756× | 5.089× | 7.517× | 84.45% | 0.00% |
| A40 | attention | attn_prefill | 2 | 6 | 25,236 | 1.884× | 1.867× | 1.899× | 94.20% | 0.18% |
| A40 | attention | attn_prefill | 4 | 6 | 25,236 | 3.417× | 3.348× | 3.520× | 85.42% | 0.00% |
| A40 | attention | attn_prefill | 8 | 6 | 25,236 | 5.767× | 5.436× | 6.542× | 72.08% | 0.00% |
| A40 | mlp | attn_post_proj | 2 | 5 | 1,295 | 1.985× | 1.960× | 1.999× | 99.24% | 0.00% |
| A40 | mlp | attn_post_proj | 4 | 5 | 1,295 | 3.888× | 3.684× | 3.912× | 97.20% | 0.00% |
| A40 | mlp | attn_post_proj | 8 | 5 | 1,295 | 7.372× | 6.310× | 7.478× | 92.15% | 0.00% |
| A40 | mlp | attn_pre_proj | 2 | 5 | 1,295 | 2.021× | 2.008× | 2.043× | 101.07% | 0.00% |
| A40 | mlp | attn_pre_proj | 4 | 5 | 1,295 | 3.864× | 3.825× | 3.994× | 96.59% | 0.00% |
| A40 | mlp | attn_pre_proj | 8 | 5 | 1,295 | 7.385× | 7.012× | 7.722× | 92.31% | 0.00% |
| A40 | mlp | mlp_act | 2 | 5 | 1,295 | 1.992× | 1.960× | 2.019× | 99.58% | 0.00% |
| A40 | mlp | mlp_act | 4 | 5 | 1,295 | 3.912× | 3.721× | 3.992× | 97.79% | 0.00% |
| A40 | mlp | mlp_act | 8 | 5 | 1,295 | 7.404× | 6.282× | 7.812× | 92.55% | 0.00% |
| A40 | mlp | mlp_down_proj | 2 | 5 | 1,295 | 2.016× | 1.983× | 2.042× | 100.78% | 0.00% |
| A40 | mlp | mlp_down_proj | 4 | 5 | 1,295 | 4.018× | 4.000× | 4.032× | 100.45% | 0.00% |
| A40 | mlp | mlp_down_proj | 8 | 5 | 1,295 | 8.050× | 7.765× | 8.175× | 100.63% | 0.00% |
| A40 | mlp | mlp_up_proj | 2 | 5 | 1,295 | 1.955× | 1.910× | 2.019× | 97.77% | 0.00% |
| A40 | mlp | mlp_up_proj | 4 | 5 | 1,295 | 3.928× | 3.710× | 3.962× | 98.20% | 0.00% |
| A40 | mlp | mlp_up_proj | 8 | 5 | 1,295 | 7.707× | 7.518× | 8.100× | 96.34% | 0.00% |
| H100 | attention | attn_decode | 2 | 6 | 60,672 | 1.818× | 1.719× | 1.870× | 90.91% | 0.05% |
| H100 | attention | attn_decode | 4 | 6 | 60,672 | 3.322× | 3.058× | 3.403× | 83.06% | 0.01% |
| H100 | attention | attn_decode | 8 | 6 | 60,672 | 5.575× | 5.302× | 6.107× | 69.68% | 0.00% |
| H100 | attention | attn_prefill | 2 | 6 | 25,236 | 1.729× | 1.686× | 1.778× | 86.47% | 0.40% |
| H100 | attention | attn_prefill | 4 | 6 | 25,236 | 2.768× | 2.555× | 3.006× | 69.20% | 0.07% |
| H100 | attention | attn_prefill | 8 | 6 | 25,236 | 4.072× | 3.468× | 4.634× | 50.89% | 0.01% |
| H100 | mlp | attn_post_proj | 2 | 5 | 1,295 | 1.976× | 1.731× | 2.009× | 98.81% | 0.00% |
| H100 | mlp | attn_post_proj | 4 | 5 | 1,295 | 3.810× | 2.824× | 3.829× | 95.24% | 0.00% |
| H100 | mlp | attn_post_proj | 8 | 5 | 1,295 | 7.305× | 4.258× | 7.500× | 91.31% | 0.00% |
| H100 | mlp | attn_pre_proj | 2 | 5 | 1,295 | 1.974× | 1.885× | 2.052× | 98.69% | 0.00% |
| H100 | mlp | attn_pre_proj | 4 | 5 | 1,295 | 3.658× | 3.290× | 3.954× | 91.45% | 0.00% |
| H100 | mlp | attn_pre_proj | 8 | 5 | 1,295 | 6.257× | 5.605× | 7.455× | 78.21% | 0.00% |
| H100 | mlp | mlp_act | 2 | 5 | 1,295 | 2.000× | 1.902× | 2.013× | 100.00% | 0.00% |
| H100 | mlp | mlp_act | 4 | 5 | 1,295 | 3.795× | 3.444× | 3.977× | 94.86% | 0.00% |
| H100 | mlp | mlp_act | 8 | 5 | 1,295 | 6.936× | 5.364× | 7.179× | 86.70% | 0.00% |
| H100 | mlp | mlp_down_proj | 2 | 5 | 1,295 | 2.037× | 1.916× | 2.052× | 101.85% | 0.00% |
| H100 | mlp | mlp_down_proj | 4 | 5 | 1,295 | 4.223× | 3.429× | 4.414× | 105.58% | 0.00% |
| H100 | mlp | mlp_down_proj | 8 | 5 | 1,295 | 8.556× | 5.667× | 8.812× | 106.94% | 0.00% |
| H100 | mlp | mlp_up_proj | 2 | 5 | 1,295 | 2.020× | 1.927× | 2.038× | 100.98% | 0.00% |
| H100 | mlp | mlp_up_proj | 4 | 5 | 1,295 | 3.912× | 3.530× | 4.101× | 97.79% | 0.00% |
| H100 | mlp | mlp_up_proj | 8 | 5 | 1,295 | 7.370× | 6.057× | 7.805× | 92.13% | 0.00% |

## 附录 D：27 个 model×device compute 覆盖

| 设备 | 模型 | MLP | Attention | 可用TP | MLP max | Batch max | Prefill max | KV max | Backend | 默认KV4096实测 |
|---|---|---|---|---|---|---|---|---|---|---|
| A40 | codellama/CodeLlama-34b-Instruct-hf | 是 | 是 | [1,2,4,8] | 4,096 | 128 | 4,096 | 4,032 | ["AttentionBackend.FLASH_ATTENTION"] | 否 |
| A40 | meta-llama/Llama-2-7b-hf | 是 | 是 | [1,2,4,8] | 4,096 | 128 | 4,096 | 4,032 | ["AttentionBackend.FLASH_ATTENTION"] | 否 |
| A40 | meta-llama/Llama-2-70b-hf | 是 | 是 | [1,2,4,8] | 4,096 | 128 | 4,096 | 4,032 | ["AttentionBackend.FLASH_ATTENTION"] | 否 |
| A40 | meta-llama/Meta-Llama-3-8B | 否 | 否 | [] | — | — | — | — | [] | 否 |
| A40 | meta-llama/Meta-Llama-3-70B | 否 | 否 | [] | — | — | — | — | [] | 否 |
| A40 | internlm/internlm-20b | 是 | 是 | [1,2,4,8] | 4,096 | 128 | 4,096 | 4,032 | ["AttentionBackend.FLASH_ATTENTION"] | 否 |
| A40 | internlm/internlm2-20b | 否 | 否 | [] | — | — | — | — | [] | 否 |
| A40 | microsoft/phi-2 | 是 | 是 | [1] | 4,096 | 128 | 4,096 | 4,032 | ["AttentionBackend.FLASH_ATTENTION"] | 否 |
| A40 | Qwen/Qwen-72B | 是 | 是 | [1,2,4,8] | 4,096 | 128 | 4,096 | 4,032 | ["AttentionBackend.FLASH_ATTENTION"] | 否 |
| A100 | codellama/CodeLlama-34b-Instruct-hf | 是 | 是 | [1,2,4,8] | 4,096 | 128 | 4,096 | 4,032 | ["AttentionBackend.FLASH_ATTENTION"] | 否 |
| A100 | meta-llama/Llama-2-7b-hf | 是 | 是 | [1,2,4,8] | 4,096 | 128 | 4,096 | 4,032 | ["AttentionBackend.FLASH_ATTENTION"] | 否 |
| A100 | meta-llama/Llama-2-70b-hf | 是 | 是 | [1,2,4,8] | 4,096 | 128 | 4,096 | 4,032 | ["AttentionBackend.FLASH_ATTENTION"] | 否 |
| A100 | meta-llama/Meta-Llama-3-8B | 是 | 是 | [1,4] | 32,768 | 512 | 16,384 | 16,320 | ["AttentionBackend.FLASHINFER"] | 是 |
| A100 | meta-llama/Meta-Llama-3-70B | 是 | 是 | [1,2,4,8] | 32,768 | 512 | 16,384 | 16,320 | ["AttentionBackend.FLASHINFER"] | 是 |
| A100 | internlm/internlm-20b | 是 | 是 | [1,2,4,8] | 4,096 | 128 | 4,096 | 4,032 | ["AttentionBackend.FLASH_ATTENTION"] | 否 |
| A100 | internlm/internlm2-20b | 否 | 否 | [] | — | — | — | — | [] | 否 |
| A100 | microsoft/phi-2 | 是 | 是 | [1] | 4,096 | 128 | 4,096 | 4,032 | ["AttentionBackend.FLASH_ATTENTION"] | 否 |
| A100 | Qwen/Qwen-72B | 是 | 是 | [1,2,4,8] | 4,096 | 128 | 4,096 | 4,032 | ["AttentionBackend.FLASH_ATTENTION"] | 否 |
| H100 | codellama/CodeLlama-34b-Instruct-hf | 是 | 是 | [1,2,4,8] | 4,096 | 128 | 4,096 | 4,032 | ["AttentionBackend.FLASH_ATTENTION"] | 否 |
| H100 | meta-llama/Llama-2-7b-hf | 是 | 是 | [1,2,4,8] | 4,096 | 128 | 4,096 | 4,032 | ["AttentionBackend.FLASH_ATTENTION"] | 否 |
| H100 | meta-llama/Llama-2-70b-hf | 是 | 是 | [1,2,4,8] | 4,096 | 128 | 4,096 | 4,032 | ["AttentionBackend.FLASH_ATTENTION"] | 否 |
| H100 | meta-llama/Meta-Llama-3-8B | 否 | 否 | [] | — | — | — | — | [] | 否 |
| H100 | meta-llama/Meta-Llama-3-70B | 否 | 否 | [] | — | — | — | — | [] | 否 |
| H100 | internlm/internlm-20b | 是 | 是 | [1,2,4,8] | 4,096 | 128 | 4,096 | 4,032 | ["AttentionBackend.FLASH_ATTENTION"] | 否 |
| H100 | internlm/internlm2-20b | 否 | 否 | [] | — | — | — | — | [] | 否 |
| H100 | microsoft/phi-2 | 是 | 是 | [1] | 4,096 | 128 | 4,096 | 4,032 | ["AttentionBackend.FLASH_ATTENTION"] | 否 |
| H100 | Qwen/Qwen-72B | 是 | 是 | [1,2,4,8] | 4,096 | 128 | 4,096 | 4,032 | ["AttentionBackend.FLASH_ATTENTION"] | 否 |

## 附录 E：Network 文件质量、曲线与可达性

### E.1 文件级质量

| 路径 | 设备 | 类型 | 行 | 列 | 唯一size | 范围 | 重复key行 | 高CV>20% | 标准schema |
|---|---|---|---|---|---|---|---|---|---|
| profiling/network/a100_dgx/all_reduce.csv | A100 | all_reduce | 6,958 | 12 | 993 | 2 KiB–64.000 MiB | 14 | 174 | 是 |
| profiling/network/a100_dgx/send_recv.csv | A100 | send_recv | 1,988 | 12 | 993 | 2 KiB–64.000 MiB | 4 | 12 | 是 |
| profiling/network/a100_pairwise_nvlink/all_reduce.csv | A100 | all_reduce | 4,496 | 12 | 2,247 | 2 KiB–511.525 MiB | 4 | 65 | 是 |
| profiling/network/a100_pairwise_nvlink/send_recv.csv | A100 | send_recv | 1,988 | 12 | 993 | 2 KiB–64.000 MiB | 4 | 70 | 是 |
| profiling/network/a40_pairwise_nvlink/attention.csv | A40 | attention_compute | 136,750 | 50 | — | — | — | — | 否 |
| profiling/network/a40_pairwise_nvlink/send_recv.csv | A40 | send_recv | 1,988 | 12 | 993 | 2 KiB–64.000 MiB | 4 | 14 | 是 |
| profiling/network/h100_dgx/all_reduce.csv | H100 | all_reduce | 2,982 | 12 | 993 | 2 KiB–64.000 MiB | 6 | 155 | 是 |
| profiling/network/h100_dgx/send_recv.csv | H100 | send_recv | 1,988 | 12 | 993 | 2 KiB–64.000 MiB | 4 | 85 | 是 |
| profiling/network/h100_pairwise_nvlink/all_reduce.csv | H100 | all_reduce | 1,988 | 12 | 993 | 2 KiB–64.000 MiB | 4 | 36 | 是 |
| profiling/network/h100_pairwise_nvlink/send_recv.csv | H100 | send_recv | 1,988 | 12 | 993 | 2 KiB–64.000 MiB | 4 | 70 | 是 |

### E.2 分组性能全表

Payload BW 不是 NCCL busbw。

| 设备 | 拓扑 | Collective | Workers | dpn | Size上限MiB | 最小/最大size时延ms | BW P50 | BW P95 | CV P95 | 高抖动 | 候选跳变 |
|---|---|---|---|---|---|---|---|---|---|---|---|
| A100 | a100_dgx | all_reduce | 2 | 1 | 64.000 | 0.0430/11.4390 | 5.760 GB/s | 5.865 GB/s | 2.14% | 0.40% | 0 |
| A100 | a100_dgx | all_reduce | 2 | 2 | 64.000 | 0.0100/0.4300 | 106.840 GB/s | 153.182 GB/s | 15.84% | 4.23% | 4 |
| A100 | a100_dgx | all_reduce | 4 | 2 | 64.000 | 0.0290/8.4900 | 4.020 GB/s | 7.043 GB/s | 1.99% | 0.20% | 1 |
| A100 | a100_dgx | all_reduce | 4 | 4 | 64.000 | 0.0610/0.6030 | 73.728 GB/s | 110.608 GB/s | 39.18% | 7.44% | 0 |
| A100 | a100_dgx | all_reduce | 8 | 4 | 64.000 | 0.0630/5.2390 | 10.376 GB/s | 12.171 GB/s | 3.06% | 0.00% | 0 |
| A100 | a100_dgx | all_reduce | 8 | 8 | 64.000 | 0.0620/0.6750 | 60.375 GB/s | 96.015 GB/s | 20.93% | 5.23% | 1 |
| A100 | a100_dgx | all_reduce | 16 | 8 | 64.000 | 0.0650/7.1930 | 4.080 GB/s | 9.353 GB/s | 2.66% | 0.00% | 1 |
| A100 | a100_dgx | send_recv | 2 | 1 | 64.000 | 0.0240/8.5860 | 7.606 GB/s | 7.818 GB/s | 5.45% | 1.21% | 1 |
| A100 | a100_dgx | send_recv | 2 | 2 | 64.000 | 0.0080/0.2940 | 223.376 GB/s | 262.596 GB/s | 7.86% | 0.00% | 0 |
| A100 | a100_pairwise_nvlink | all_reduce | 2 | 2 | 511.525 | 0.0070/2.7460 | 177.528 GB/s | 194.658 GB/s | 10.30% | 2.76% | 3 |
| A100 | a100_pairwise_nvlink | all_reduce | 4 | 4 | 511.525 | 0.0660/33.9020 | 15.568 GB/s | 15.791 GB/s | 0.79% | 0.13% | 0 |
| A100 | a100_pairwise_nvlink | send_recv | 2 | 1 | 64.000 | 0.0120/27.0660 | 2.415 GB/s | 7.594 GB/s | 22.45% | 7.04% | 41 |
| A100 | a100_pairwise_nvlink | send_recv | 2 | 2 | 64.000 | 0.0040/0.2350 | 297.016 GB/s | 335.009 GB/s | 6.17% | 0.00% | 0 |
| A40 | a40_pairwise_nvlink | send_recv | 2 | 1 | 64.000 | 0.0210/29.9830 | 2.449 GB/s | 3.264 GB/s | 17.26% | 1.41% | 7 |
| A40 | a40_pairwise_nvlink | send_recv | 2 | 2 | 64.000 | 0.0040/16.9000 | 4.079 GB/s | 4.404 GB/s | 5.98% | 0.00% | 0 |
| H100 | h100_dgx | all_reduce | 2 | 2 | 64.000 | 0.0070/0.2450 | 212.130 GB/s | 269.901 GB/s | 28.97% | 9.46% | 4 |
| H100 | h100_dgx | all_reduce | 4 | 4 | 64.000 | 0.0380/0.3180 | 165.863 GB/s | 209.804 GB/s | 7.84% | 2.21% | 1 |
| H100 | h100_dgx | all_reduce | 8 | 8 | 64.000 | 0.0370/0.3220 | 128.935 GB/s | 189.107 GB/s | 7.44% | 3.92% | 0 |
| H100 | h100_dgx | send_recv | 2 | 1 | 64.000 | 0.0170/1.8710 | 34.212 GB/s | 35.714 GB/s | 44.07% | 8.45% | 0 |
| H100 | h100_dgx | send_recv | 2 | 2 | 64.000 | 0.0050/0.1930 | 299.827 GB/s | 344.722 GB/s | 1.77% | 0.10% | 0 |
| H100 | h100_pairwise_nvlink | all_reduce | 2 | 2 | 64.000 | 0.0280/0.3520 | 160.450 GB/s | 187.660 GB/s | 12.79% | 2.82% | 13 |
| H100 | h100_pairwise_nvlink | all_reduce | 4 | 4 | 64.000 | 0.0280/2.0630 | 29.275 GB/s | 32.302 GB/s | 1.65% | 0.80% | 1 |
| H100 | h100_pairwise_nvlink | send_recv | 2 | 1 | 64.000 | 0.0120/27.0660 | 2.415 GB/s | 7.594 GB/s | 22.45% | 7.04% | 41 |
| H100 | h100_pairwise_nvlink | send_recv | 2 | 2 | 64.000 | 0.0040/0.2350 | 297.016 GB/s | 335.009 GB/s | 6.17% | 0.00% | 0 |

### E.3 当前 loader 的 network 可达性

| Network device | 节点设备 | AR文件 | SR文件 | AR过滤后TP | 不可达AR行 | Worker/dpn组合 | 孤立attention |
|---|---|---|---|---|---|---|---|
| a40_pairwise_nvlink | 8 | 否 | 是 | {} | 0 | [] | 是 |
| a100_pairwise_nvlink | 4 | 是 | 是 | {"2":2248,"4":2248,"8":0,"16":0} | 0 | [[2,2],[4,4]] | 否 |
| h100_pairwise_nvlink | 4 | 是 | 是 | {"2":994,"4":994,"8":0,"16":0} | 0 | [[2,2],[4,4]] | 否 |
| a100_dgx | 8 | 是 | 是 | {"2":994,"4":994,"8":994,"16":0} | 3,976 | [[2,1],[2,2],[4,2],[4,4],[8,4],[8,8],[16,8]] | 否 |
| h100_dgx | 8 | 是 | 是 | {"2":994,"4":994,"8":994,"16":0} | 0 | [[2,2],[4,4],[8,8]] | 否 |

### E.4 全部 284 个 network change-point 候选

<details><summary>展开完整表格（按绝对时延变化比例降序）</summary>

| 设备 | 拓扑 | Collective | Workers | dpn | 前KiB | 后KiB | 前ms | 后ms | 时延变化 | 绝对变化ms | 合成std | BW变化 | 类型 |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| A100 | a100_pairwise_nvlink | all_reduce | 2 | 2 | 386.000 | 394.000 | 0.0130 | 0.0630 | 384.62% | 0.0500 | 0.0048 | -78.94% | candidate_latency_jump |
| A100 | a100_pairwise_nvlink | all_reduce | 2 | 2 | 258.000 | 266.000 | 0.0130 | 0.0590 | 353.85% | 0.0460 | 0.0142 | -77.28% | candidate_latency_jump |
| H100 | h100_dgx | all_reduce | 2 | 2 | 386.000 | 394.000 | 0.0100 | 0.0430 | 330.00% | 0.0330 | 0.0033 | -76.26% | candidate_latency_jump |
| H100 | h100_dgx | all_reduce | 2 | 2 | 506.000 | 514.000 | 0.0110 | 0.0420 | 281.82% | 0.0310 | 0.0013 | -73.40% | candidate_latency_jump |
| H100 | h100_pairwise_nvlink | all_reduce | 2 | 2 | 226.000 | 234.000 | 0.0080 | 0.0300 | 275.00% | 0.0220 | 0.0005 | -72.39% | candidate_latency_jump |
| A100 | a100_dgx | all_reduce | 2 | 2 | 402.000 | 410.000 | 0.0180 | 0.0620 | 244.44% | 0.0440 | 0.0132 | -70.39% | candidate_latency_jump |
| H100 | h100_pairwise_nvlink | all_reduce | 2 | 2 | 338.000 | 346.000 | 0.0100 | 0.0310 | 210.00% | 0.0210 | 0.0012 | -66.98% | candidate_latency_jump |
| H100 | h100_pairwise_nvlink | all_reduce | 2 | 2 | 266.000 | 274.000 | 0.0100 | 0.0300 | 200.00% | 0.0200 | 0.0014 | -65.66% | candidate_latency_jump |
| H100 | h100_pairwise_nvlink | all_reduce | 2 | 2 | 362.000 | 370.000 | 0.0100 | 0.0300 | 200.00% | 0.0200 | 0.0005 | -65.93% | candidate_latency_jump |
| H100 | h100_dgx | all_reduce | 4 | 4 | 666.000 | 674.000 | 0.0150 | 0.0420 | 180.00% | 0.0270 | 0.0022 | -63.86% | candidate_latency_jump |
| H100 | h100_pairwise_nvlink | all_reduce | 2 | 2 | 418.000 | 426.000 | 0.0110 | 0.0300 | 172.73% | 0.0190 | 0.0009 | -62.63% | candidate_latency_jump |
| H100 | h100_pairwise_nvlink | all_reduce | 2 | 2 | 114.000 | 122.000 | 0.0120 | 0.0290 | 141.67% | 0.0170 | 0.0030 | -55.72% | candidate_latency_jump |
| H100 | h100_pairwise_nvlink | all_reduce | 2 | 2 | 530.000 | 538.000 | 0.0130 | 0.0310 | 138.46% | 0.0180 | 0.0005 | -57.43% | candidate_latency_jump |
| H100 | h100_pairwise_nvlink | all_reduce | 2 | 2 | 562.000 | 570.000 | 0.0130 | 0.0300 | 130.77% | 0.0170 | 0.0042 | -56.05% | candidate_latency_jump |
| A100 | a100_dgx | all_reduce | 2 | 2 | 178.000 | 186.000 | 0.0290 | 0.0570 | 96.55% | 0.0280 | 0.0089 | -46.84% | candidate_latency_jump |
| A100 | a100_dgx | all_reduce | 16 | 8 | 16,352.000 | 16,384.000 | 2.1530 | 4.1700 | 93.68% | 2.0170 | 0.0418 | -48.27% | candidate_latency_jump |
| H100 | h100_dgx | all_reduce | 2 | 2 | 882.000 | 890.000 | 0.0220 | 0.0420 | 90.91% | 0.0200 | 0.0005 | -47.14% | candidate_latency_jump |
| A100 | a100_pairwise_nvlink | send_recv | 2 | 1 | 43,264.000 | 43,392.000 | 13.3470 | 25.1940 | 88.76% | 11.8470 | 2.7583 | -46.87% | candidate_latency_jump |
| H100 | h100_pairwise_nvlink | send_recv | 2 | 1 | 43,264.000 | 43,392.000 | 13.3470 | 25.1940 | 88.76% | 11.8470 | 2.7583 | -46.87% | candidate_latency_jump |
| A100 | a100_pairwise_nvlink | all_reduce | 2 | 2 | 82.000 | 90.000 | 0.0640 | 0.0100 | -84.38% | -0.0540 | 0.0069 | 602.44% | nonmonotonic_latency_drop |
| A100 | a100_pairwise_nvlink | all_reduce | 2 | 2 | 738.000 | 746.000 | 0.0340 | 0.0620 | 82.35% | 0.0280 | 0.0079 | -44.57% | candidate_latency_jump |
| H100 | h100_dgx | all_reduce | 2 | 2 | 146.000 | 154.000 | 0.0410 | 0.0080 | -80.49% | -0.0330 | 0.0092 | 440.58% | nonmonotonic_latency_drop |
| A100 | a100_pairwise_nvlink | send_recv | 2 | 1 | 19,200.000 | 19,328.000 | 6.8770 | 12.3960 | 80.25% | 5.5190 | 0.9775 | -44.15% | candidate_latency_jump |
| H100 | h100_pairwise_nvlink | send_recv | 2 | 1 | 19,200.000 | 19,328.000 | 6.8770 | 12.3960 | 80.25% | 5.5190 | 0.9775 | -44.15% | candidate_latency_jump |
| A100 | a100_pairwise_nvlink | all_reduce | 2 | 2 | 378.000 | 386.000 | 0.0620 | 0.0130 | -79.03% | -0.0490 | 0.0141 | 387.02% | nonmonotonic_latency_drop |
| A100 | a100_dgx | all_reduce | 4 | 2 | 16,352.000 | 16,384.000 | 2.3630 | 4.2300 | 79.01% | 1.8670 | 0.0126 | -44.03% | candidate_latency_jump |
| A100 | a100_pairwise_nvlink | all_reduce | 2 | 2 | 130.000 | 138.000 | 0.0520 | 0.0110 | -78.85% | -0.0410 | 0.0113 | 401.82% | nonmonotonic_latency_drop |
| A100 | a100_pairwise_nvlink | all_reduce | 2 | 2 | 530.000 | 538.000 | 0.0630 | 0.0150 | -76.19% | -0.0480 | 0.0145 | 326.34% | nonmonotonic_latency_drop |
| H100 | h100_dgx | all_reduce | 2 | 2 | 378.000 | 386.000 | 0.0420 | 0.0100 | -76.19% | -0.0320 | 0.0012 | 328.89% | nonmonotonic_latency_drop |
| H100 | h100_dgx | all_reduce | 2 | 2 | 498.000 | 506.000 | 0.0420 | 0.0110 | -73.81% | -0.0310 | 0.0059 | 287.95% | nonmonotonic_latency_drop |
| A100 | a100_pairwise_nvlink | send_recv | 2 | 1 | 63,488.000 | 63,616.000 | 18.8360 | 32.7370 | 73.80% | 13.9010 | 0.7498 | -42.35% | candidate_latency_jump |
| H100 | h100_pairwise_nvlink | send_recv | 2 | 1 | 63,488.000 | 63,616.000 | 18.8360 | 32.7370 | 73.80% | 13.9010 | 0.7498 | -42.35% | candidate_latency_jump |
| A100 | a100_dgx | send_recv | 2 | 1 | 74.000 | 82.000 | 0.0370 | 0.0630 | 70.27% | 0.0260 | 0.0048 | -34.92% | candidate_latency_jump |
| H100 | h100_dgx | all_reduce | 2 | 2 | 690.000 | 698.000 | 0.0380 | 0.0120 | -68.42% | -0.0260 | 0.0059 | 220.34% | nonmonotonic_latency_drop |
| H100 | h100_pairwise_nvlink | all_reduce | 2 | 2 | 258.000 | 266.000 | 0.0310 | 0.0100 | -67.74% | -0.0210 | 0.0015 | 219.61% | nonmonotonic_latency_drop |
| H100 | h100_dgx | all_reduce | 2 | 2 | 218.000 | 226.000 | 0.0270 | 0.0090 | -66.67% | -0.0180 | 0.0025 | 211.01% | nonmonotonic_latency_drop |
| H100 | h100_pairwise_nvlink | all_reduce | 2 | 2 | 274.000 | 282.000 | 0.0300 | 0.0100 | -66.67% | -0.0200 | 0.0000 | 208.76% | nonmonotonic_latency_drop |
| H100 | h100_dgx | all_reduce | 4 | 4 | 658.000 | 666.000 | 0.0420 | 0.0150 | -64.29% | -0.0270 | 0.0005 | 183.40% | nonmonotonic_latency_drop |
| H100 | h100_pairwise_nvlink | all_reduce | 2 | 2 | 306.000 | 314.000 | 0.0270 | 0.0100 | -62.96% | -0.0170 | 0.0025 | 177.06% | nonmonotonic_latency_drop |
| H100 | h100_pairwise_nvlink | all_reduce | 2 | 2 | 378.000 | 386.000 | 0.0290 | 0.0110 | -62.07% | -0.0180 | 0.0022 | 169.22% | nonmonotonic_latency_drop |
| A100 | a100_pairwise_nvlink | send_recv | 2 | 1 | 28,800.000 | 28,928.000 | 8.6470 | 13.9760 | 61.63% | 5.3290 | 1.4332 | -37.85% | candidate_latency_jump |
| H100 | h100_pairwise_nvlink | send_recv | 2 | 1 | 28,800.000 | 28,928.000 | 8.6470 | 13.9760 | 61.63% | 5.3290 | 1.4332 | -37.85% | candidate_latency_jump |
| A100 | a100_pairwise_nvlink | send_recv | 2 | 1 | 51,200.000 | 51,328.000 | 15.2740 | 24.3560 | 59.46% | 9.0820 | 1.8662 | -37.13% | candidate_latency_jump |
| H100 | h100_pairwise_nvlink | send_recv | 2 | 1 | 51,200.000 | 51,328.000 | 15.2740 | 24.3560 | 59.46% | 9.0820 | 1.8662 | -37.13% | candidate_latency_jump |
| H100 | h100_pairwise_nvlink | all_reduce | 2 | 2 | 82.000 | 90.000 | 0.0170 | 0.0070 | -58.82% | -0.0100 | 0.0027 | 166.55% | nonmonotonic_latency_drop |
| A100 | a100_pairwise_nvlink | send_recv | 2 | 1 | 46,976.000 | 47,104.000 | 19.0640 | 29.7100 | 55.84% | 10.6460 | 1.6924 | -35.66% | candidate_latency_jump |
| H100 | h100_pairwise_nvlink | send_recv | 2 | 1 | 46,976.000 | 47,104.000 | 19.0640 | 29.7100 | 55.84% | 10.6460 | 1.6924 | -35.66% | candidate_latency_jump |
| A40 | a40_pairwise_nvlink | send_recv | 2 | 1 | 122.000 | 130.000 | 0.0900 | 0.1400 | 55.56% | 0.0500 | 0.0131 | -31.50% | candidate_latency_jump |
| H100 | h100_pairwise_nvlink | all_reduce | 2 | 2 | 522.000 | 530.000 | 0.0290 | 0.0130 | -55.17% | -0.0160 | 0.0022 | 126.50% | nonmonotonic_latency_drop |
| H100 | h100_pairwise_nvlink | all_reduce | 2 | 2 | 666.000 | 674.000 | 0.0200 | 0.0310 | 55.00% | 0.0110 | 0.0008 | -34.71% | candidate_latency_jump |
| H100 | h100_pairwise_nvlink | all_reduce | 2 | 2 | 746.000 | 754.000 | 0.0200 | 0.0310 | 55.00% | 0.0110 | 0.0009 | -34.79% | candidate_latency_jump |
| A100 | a100_pairwise_nvlink | send_recv | 2 | 1 | 55,552.000 | 55,680.000 | 19.1850 | 29.6870 | 54.74% | 10.5020 | 2.6877 | -35.23% | candidate_latency_jump |
| H100 | h100_pairwise_nvlink | send_recv | 2 | 1 | 55,552.000 | 55,680.000 | 19.1850 | 29.6870 | 54.74% | 10.5020 | 2.6877 | -35.23% | candidate_latency_jump |
| A100 | a100_pairwise_nvlink | send_recv | 2 | 1 | 25,856.000 | 25,984.000 | 10.3060 | 15.8730 | 54.02% | 5.5670 | 1.8216 | -34.75% | candidate_latency_jump |
| H100 | h100_pairwise_nvlink | send_recv | 2 | 1 | 25,856.000 | 25,984.000 | 10.3060 | 15.8730 | 54.02% | 5.5670 | 1.8216 | -34.75% | candidate_latency_jump |
| A100 | a100_pairwise_nvlink | all_reduce | 2 | 2 | 714.000 | 722.000 | 0.0690 | 0.0330 | -52.17% | -0.0360 | 0.0102 | 111.43% | nonmonotonic_latency_drop |
| A100 | a100_dgx | all_reduce | 4 | 2 | 65,408.000 | 65,536.000 | 17.0640 | 8.4900 | -50.25% | -8.5740 | 0.0370 | 101.38% | nonmonotonic_latency_drop |
| A100 | a100_pairwise_nvlink | send_recv | 2 | 1 | 41,216.000 | 41,344.000 | 14.6260 | 21.9490 | 50.07% | 7.3230 | 1.1842 | -33.16% | candidate_latency_jump |
| H100 | h100_pairwise_nvlink | send_recv | 2 | 1 | 41,216.000 | 41,344.000 | 14.6260 | 21.9490 | 50.07% | 7.3230 | 1.1842 | -33.16% | candidate_latency_jump |
| H100 | h100_pairwise_nvlink | all_reduce | 2 | 2 | 690.000 | 698.000 | 0.0200 | 0.0300 | 50.00% | 0.0100 | 0.0008 | -32.56% | candidate_latency_jump |
| A100 | a100_dgx | all_reduce | 16 | 8 | 20,224.000 | 20,352.000 | 5.1350 | 2.5800 | -49.76% | -2.5550 | 0.0666 | 100.29% | nonmonotonic_latency_drop |
| H100 | h100_dgx | all_reduce | 2 | 2 | 874.000 | 882.000 | 0.0430 | 0.0220 | -48.84% | -0.0210 | 0.0033 | 97.24% | nonmonotonic_latency_drop |
| H100 | h100_dgx | all_reduce | 2 | 2 | 906.000 | 914.000 | 0.0430 | 0.0220 | -48.84% | -0.0210 | 0.0012 | 97.18% | nonmonotonic_latency_drop |
| A100 | a100_pairwise_nvlink | send_recv | 2 | 1 | 63,872.000 | 64,000.000 | 18.9490 | 28.1910 | 48.77% | 9.2420 | 3.0634 | -32.65% | candidate_latency_jump |
| H100 | h100_pairwise_nvlink | send_recv | 2 | 1 | 63,872.000 | 64,000.000 | 18.9490 | 28.1910 | 48.77% | 9.2420 | 3.0634 | -32.65% | candidate_latency_jump |
| A100 | a100_pairwise_nvlink | send_recv | 2 | 1 | 15,360.000 | 15,392.000 | 5.8460 | 8.6770 | 48.43% | 2.8310 | 0.9373 | -32.49% | candidate_latency_jump |
| H100 | h100_pairwise_nvlink | send_recv | 2 | 1 | 15,360.000 | 15,392.000 | 5.8460 | 8.6770 | 48.43% | 2.8310 | 0.9373 | -32.49% | candidate_latency_jump |
| A100 | a100_pairwise_nvlink | send_recv | 2 | 1 | 14,656.000 | 14,688.000 | 5.1930 | 7.6680 | 47.66% | 2.4750 | 0.5824 | -32.13% | candidate_latency_jump |
| H100 | h100_pairwise_nvlink | send_recv | 2 | 1 | 14,656.000 | 14,688.000 | 5.1930 | 7.6680 | 47.66% | 2.4750 | 0.5824 | -32.13% | candidate_latency_jump |
| A100 | a100_dgx | all_reduce | 16 | 8 | 12,640.000 | 12,672.000 | 3.1940 | 1.6730 | -47.62% | -1.5210 | 0.0516 | 91.40% | nonmonotonic_latency_drop |
| A100 | a100_dgx | all_reduce | 8 | 8 | 410.000 | 418.000 | 0.0420 | 0.0620 | 47.62% | 0.0200 | 0.0061 | -30.94% | candidate_latency_jump |
| A100 | a100_pairwise_nvlink | all_reduce | 2 | 2 | 674.000 | 682.000 | 0.0620 | 0.0330 | -46.77% | -0.0290 | 0.0069 | 90.11% | nonmonotonic_latency_drop |
| A100 | a100_pairwise_nvlink | send_recv | 2 | 1 | 26,112.000 | 26,240.000 | 17.4810 | 9.5980 | -45.09% | -7.8830 | 0.4272 | 83.02% | nonmonotonic_latency_drop |
| H100 | h100_pairwise_nvlink | send_recv | 2 | 1 | 26,112.000 | 26,240.000 | 17.4810 | 9.5980 | -45.09% | -7.8830 | 0.4272 | 83.02% | nonmonotonic_latency_drop |
| A100 | a100_pairwise_nvlink | send_recv | 2 | 1 | 39,680.000 | 39,808.000 | 21.1780 | 11.7280 | -44.62% | -9.4500 | 1.9239 | 81.16% | nonmonotonic_latency_drop |
| H100 | h100_pairwise_nvlink | send_recv | 2 | 1 | 39,680.000 | 39,808.000 | 21.1780 | 11.7280 | -44.62% | -9.4500 | 1.9239 | 81.16% | nonmonotonic_latency_drop |
| A100 | a100_dgx | all_reduce | 8 | 8 | 906.000 | 914.000 | 0.0680 | 0.0380 | -44.12% | -0.0300 | 0.0065 | 80.53% | nonmonotonic_latency_drop |
| A100 | a100_pairwise_nvlink | send_recv | 2 | 1 | 23,552.000 | 23,680.000 | 12.7330 | 7.3050 | -42.63% | -5.4280 | 0.1212 | 75.25% | nonmonotonic_latency_drop |
| H100 | h100_pairwise_nvlink | send_recv | 2 | 1 | 23,552.000 | 23,680.000 | 12.7330 | 7.3050 | -42.63% | -5.4280 | 0.1212 | 75.25% | nonmonotonic_latency_drop |
| A100 | a100_pairwise_nvlink | send_recv | 2 | 1 | 47,104.000 | 47,232.000 | 29.7100 | 17.8150 | -40.04% | -11.8950 | 1.4559 | 67.22% | nonmonotonic_latency_drop |
| H100 | h100_pairwise_nvlink | send_recv | 2 | 1 | 47,104.000 | 47,232.000 | 29.7100 | 17.8150 | -40.04% | -11.8950 | 1.4559 | 67.22% | nonmonotonic_latency_drop |
| H100 | h100_pairwise_nvlink | all_reduce | 4 | 4 | 618.000 | 626.000 | 0.0480 | 0.0670 | 39.58% | 0.0190 | 0.0007 | -27.43% | candidate_latency_jump |
| A100 | a100_dgx | all_reduce | 4 | 2 | 8,160.000 | 8,192.000 | 2.0320 | 1.2280 | -39.57% | -0.8040 | 0.0096 | 66.12% | nonmonotonic_latency_drop |
| A100 | a100_pairwise_nvlink | send_recv | 2 | 1 | 14,048.000 | 14,080.000 | 7.6480 | 4.6520 | -39.17% | -2.9960 | 0.2241 | 64.78% | nonmonotonic_latency_drop |
| H100 | h100_pairwise_nvlink | send_recv | 2 | 1 | 14,048.000 | 14,080.000 | 7.6480 | 4.6520 | -39.17% | -2.9960 | 0.2241 | 64.78% | nonmonotonic_latency_drop |
| A100 | a100_pairwise_nvlink | send_recv | 2 | 1 | 27,136.000 | 27,264.000 | 15.0260 | 9.2450 | -38.47% | -5.7810 | 1.5451 | 63.30% | nonmonotonic_latency_drop |
| H100 | h100_pairwise_nvlink | send_recv | 2 | 1 | 27,136.000 | 27,264.000 | 15.0260 | 9.2450 | -38.47% | -5.7810 | 1.5451 | 63.30% | nonmonotonic_latency_drop |
| H100 | h100_dgx | all_reduce | 2 | 2 | 4,416.000 | 4,448.000 | 0.0320 | 0.0440 | 37.50% | 0.0120 | 0.0008 | -26.75% | candidate_latency_jump |
| A100 | a100_pairwise_nvlink | send_recv | 2 | 1 | 11,360.000 | 11,392.000 | 3.8670 | 5.3060 | 37.21% | 1.4390 | 0.1734 | -26.91% | candidate_latency_jump |
| H100 | h100_pairwise_nvlink | send_recv | 2 | 1 | 11,360.000 | 11,392.000 | 3.8670 | 5.3060 | 37.21% | 1.4390 | 0.1734 | -26.91% | candidate_latency_jump |
| A100 | a100_pairwise_nvlink | all_reduce | 2 | 2 | 730.000 | 738.000 | 0.0540 | 0.0340 | -37.04% | -0.0200 | 0.0063 | 60.56% | nonmonotonic_latency_drop |
| A100 | a100_dgx | all_reduce | 2 | 2 | 754.000 | 762.000 | 0.0460 | 0.0630 | 36.96% | 0.0170 | 0.0024 | -26.21% | candidate_latency_jump |
| A100 | a100_pairwise_nvlink | send_recv | 2 | 1 | 22,656.000 | 22,784.000 | 10.7950 | 6.8190 | -36.83% | -3.9760 | 0.1868 | 59.20% | nonmonotonic_latency_drop |
| H100 | h100_pairwise_nvlink | send_recv | 2 | 1 | 22,656.000 | 22,784.000 | 10.7950 | 6.8190 | -36.83% | -3.9760 | 0.1868 | 59.20% | nonmonotonic_latency_drop |
| A100 | a100_pairwise_nvlink | send_recv | 2 | 1 | 63,744.000 | 63,872.000 | 29.9280 | 18.9490 | -36.68% | -10.9790 | 3.3733 | 58.26% | nonmonotonic_latency_drop |
| H100 | h100_pairwise_nvlink | send_recv | 2 | 1 | 63,744.000 | 63,872.000 | 29.9280 | 18.9490 | -36.68% | -10.9790 | 3.3733 | 58.26% | nonmonotonic_latency_drop |
| A100 | a100_dgx | all_reduce | 8 | 8 | 1,088.000 | 1,120.000 | 0.0630 | 0.0400 | -36.51% | -0.0230 | 0.0024 | 62.13% | nonmonotonic_latency_drop |
| H100 | h100_pairwise_nvlink | all_reduce | 2 | 2 | 866.000 | 874.000 | 0.0220 | 0.0300 | 36.36% | 0.0080 | 0.0026 | -25.99% | candidate_latency_jump |
| A100 | a100_pairwise_nvlink | send_recv | 2 | 1 | 10,496.000 | 10,528.000 | 3.6760 | 5.0120 | 36.34% | 1.3360 | 0.4363 | -26.43% | candidate_latency_jump |
| H100 | h100_pairwise_nvlink | send_recv | 2 | 1 | 10,496.000 | 10,528.000 | 3.6760 | 5.0120 | 36.34% | 1.3360 | 0.4363 | -26.43% | candidate_latency_jump |
| A100 | a100_pairwise_nvlink | send_recv | 2 | 1 | 15,264.000 | 15,296.000 | 6.4200 | 8.7520 | 36.32% | 2.3320 | 0.5240 | -26.49% | candidate_latency_jump |
| H100 | h100_pairwise_nvlink | send_recv | 2 | 1 | 15,264.000 | 15,296.000 | 6.4200 | 8.7520 | 36.32% | 2.3320 | 0.5240 | -26.49% | candidate_latency_jump |
| A100 | a100_pairwise_nvlink | send_recv | 2 | 1 | 63,360.000 | 63,488.000 | 29.5230 | 18.8360 | -36.20% | -10.6870 | 0.9751 | 57.05% | nonmonotonic_latency_drop |
| H100 | h100_pairwise_nvlink | send_recv | 2 | 1 | 63,360.000 | 63,488.000 | 29.5230 | 18.8360 | -36.20% | -10.6870 | 0.9751 | 57.05% | nonmonotonic_latency_drop |
| A100 | a100_pairwise_nvlink | send_recv | 2 | 1 | 6,688.000 | 6,720.000 | 2.9940 | 4.0660 | 35.80% | 1.0720 | 0.1923 | -26.01% | candidate_latency_jump |
| H100 | h100_pairwise_nvlink | send_recv | 2 | 1 | 6,688.000 | 6,720.000 | 2.9940 | 4.0660 | 35.80% | 1.0720 | 0.1923 | -26.01% | candidate_latency_jump |
| A100 | a100_pairwise_nvlink | send_recv | 2 | 1 | 27,264.000 | 27,392.000 | 9.2450 | 12.5460 | 35.71% | 3.3010 | 0.7747 | -25.97% | candidate_latency_jump |
| H100 | h100_pairwise_nvlink | send_recv | 2 | 1 | 27,264.000 | 27,392.000 | 9.2450 | 12.5460 | 35.71% | 3.3010 | 0.7747 | -25.97% | candidate_latency_jump |
| H100 | h100_pairwise_nvlink | all_reduce | 2 | 2 | 754.000 | 762.000 | 0.0310 | 0.0200 | -35.48% | -0.0110 | 0.0011 | 56.64% | nonmonotonic_latency_drop |
| A100 | a100_pairwise_nvlink | send_recv | 2 | 1 | 14,880.000 | 14,912.000 | 9.3700 | 6.0740 | -35.18% | -3.2960 | 0.3735 | 54.60% | nonmonotonic_latency_drop |
| H100 | h100_pairwise_nvlink | send_recv | 2 | 1 | 14,880.000 | 14,912.000 | 9.3700 | 6.0740 | -35.18% | -3.2960 | 0.3735 | 54.60% | nonmonotonic_latency_drop |
| A100 | a100_pairwise_nvlink | send_recv | 2 | 1 | 51,072.000 | 51,200.000 | 23.5020 | 15.2740 | -35.01% | -8.2280 | 1.2946 | 54.25% | nonmonotonic_latency_drop |
| H100 | h100_pairwise_nvlink | send_recv | 2 | 1 | 51,072.000 | 51,200.000 | 23.5020 | 15.2740 | -35.01% | -8.2280 | 1.2946 | 54.25% | nonmonotonic_latency_drop |
| A100 | a100_pairwise_nvlink | send_recv | 2 | 1 | 50,176.000 | 50,304.000 | 21.0660 | 28.3720 | 34.68% | 7.3060 | 1.4050 | -25.56% | candidate_latency_jump |
| H100 | h100_pairwise_nvlink | send_recv | 2 | 1 | 50,176.000 | 50,304.000 | 21.0660 | 28.3720 | 34.68% | 7.3060 | 1.4050 | -25.56% | candidate_latency_jump |
| A100 | a100_pairwise_nvlink | send_recv | 2 | 1 | 43,136.000 | 43,264.000 | 20.3080 | 13.3470 | -34.28% | -6.9610 | 2.1999 | 52.61% | nonmonotonic_latency_drop |
| H100 | h100_pairwise_nvlink | send_recv | 2 | 1 | 43,136.000 | 43,264.000 | 20.3080 | 13.3470 | -34.28% | -6.9610 | 2.1999 | 52.61% | nonmonotonic_latency_drop |
| A100 | a100_pairwise_nvlink | send_recv | 2 | 1 | 12,160.000 | 12,192.000 | 5.1790 | 6.9540 | 34.27% | 1.7750 | 0.3871 | -25.33% | candidate_latency_jump |
| H100 | h100_pairwise_nvlink | send_recv | 2 | 1 | 12,160.000 | 12,192.000 | 5.1790 | 6.9540 | 34.27% | 1.7750 | 0.3871 | -25.33% | candidate_latency_jump |
| H100 | h100_dgx | all_reduce | 2 | 2 | 210.000 | 218.000 | 0.0410 | 0.0270 | -34.15% | -0.0140 | 0.0026 | 57.64% | nonmonotonic_latency_drop |
| A40 | a40_pairwise_nvlink | send_recv | 2 | 1 | 650.000 | 658.000 | 0.3020 | 0.4050 | 34.11% | 0.1030 | 0.0150 | -24.51% | candidate_latency_jump |
| A100 | a100_dgx | all_reduce | 2 | 2 | 642.000 | 650.000 | 0.0470 | 0.0630 | 34.04% | 0.0160 | 0.0027 | -24.47% | candidate_latency_jump |
| A100 | a100_pairwise_nvlink | send_recv | 2 | 1 | 5,792.000 | 5,824.000 | 2.1210 | 2.8430 | 34.04% | 0.7220 | 0.2228 | -24.98% | candidate_latency_jump |
| H100 | h100_pairwise_nvlink | send_recv | 2 | 1 | 5,792.000 | 5,824.000 | 2.1210 | 2.8430 | 34.04% | 0.7220 | 0.2228 | -24.98% | candidate_latency_jump |
| A100 | a100_pairwise_nvlink | send_recv | 2 | 1 | 14,912.000 | 14,944.000 | 6.0740 | 8.1410 | 34.03% | 2.0670 | 0.2652 | -25.23% | candidate_latency_jump |
| H100 | h100_pairwise_nvlink | send_recv | 2 | 1 | 14,912.000 | 14,944.000 | 6.0740 | 8.1410 | 34.03% | 2.0670 | 0.2652 | -25.23% | candidate_latency_jump |
| A100 | a100_pairwise_nvlink | send_recv | 2 | 1 | 5,440.000 | 5,472.000 | 2.4230 | 3.2400 | 33.72% | 0.8170 | 0.2631 | -24.78% | candidate_latency_jump |
| H100 | h100_pairwise_nvlink | send_recv | 2 | 1 | 5,440.000 | 5,472.000 | 2.4230 | 3.2400 | 33.72% | 0.8170 | 0.2631 | -24.78% | candidate_latency_jump |
| A100 | a100_pairwise_nvlink | send_recv | 2 | 1 | 7,968.000 | 8,000.000 | 2.7450 | 3.6680 | 33.62% | 0.9230 | 0.0850 | -24.86% | candidate_latency_jump |
| H100 | h100_pairwise_nvlink | send_recv | 2 | 1 | 7,968.000 | 8,000.000 | 2.7450 | 3.6680 | 33.62% | 0.9230 | 0.0850 | -24.86% | candidate_latency_jump |
| A40 | a40_pairwise_nvlink | send_recv | 2 | 1 | 306.000 | 314.000 | 0.1610 | 0.2150 | 33.54% | 0.0540 | 0.0180 | -23.16% | candidate_latency_jump |
| A100 | a100_pairwise_nvlink | send_recv | 2 | 1 | 30,976.000 | 31,104.000 | 10.9100 | 14.5620 | 33.47% | 3.6520 | 0.6908 | -24.77% | candidate_latency_jump |
| H100 | h100_pairwise_nvlink | send_recv | 2 | 1 | 30,976.000 | 31,104.000 | 10.9100 | 14.5620 | 33.47% | 3.6520 | 0.6908 | -24.77% | candidate_latency_jump |
| H100 | h100_pairwise_nvlink | all_reduce | 2 | 2 | 738.000 | 746.000 | 0.0300 | 0.0200 | -33.33% | -0.0100 | 0.0000 | 51.63% | nonmonotonic_latency_drop |
| A100 | a100_pairwise_nvlink | send_recv | 2 | 1 | 42,240.000 | 42,368.000 | 23.7370 | 15.8440 | -33.25% | -7.8930 | 1.6787 | 50.27% | nonmonotonic_latency_drop |
| H100 | h100_pairwise_nvlink | send_recv | 2 | 1 | 42,240.000 | 42,368.000 | 23.7370 | 15.8440 | -33.25% | -7.8930 | 1.6787 | 50.27% | nonmonotonic_latency_drop |
| A100 | a100_pairwise_nvlink | send_recv | 2 | 1 | 15,424.000 | 15,456.000 | 7.6920 | 5.1350 | -33.24% | -2.5570 | 0.1390 | 50.11% | nonmonotonic_latency_drop |
| H100 | h100_pairwise_nvlink | send_recv | 2 | 1 | 15,424.000 | 15,456.000 | 7.6920 | 5.1350 | -33.24% | -2.5570 | 0.1390 | 50.11% | nonmonotonic_latency_drop |
| A100 | a100_pairwise_nvlink | send_recv | 2 | 1 | 13,408.000 | 13,440.000 | 5.1440 | 6.8490 | 33.15% | 1.7050 | 0.2842 | -24.71% | candidate_latency_jump |
| H100 | h100_pairwise_nvlink | send_recv | 2 | 1 | 13,408.000 | 13,440.000 | 5.1440 | 6.8490 | 33.15% | 1.7050 | 0.2842 | -24.71% | candidate_latency_jump |
| A100 | a100_pairwise_nvlink | send_recv | 2 | 1 | 47,616.000 | 47,744.000 | 24.9040 | 16.6550 | -33.12% | -8.2490 | 2.7141 | 49.93% | nonmonotonic_latency_drop |
| H100 | h100_pairwise_nvlink | send_recv | 2 | 1 | 47,616.000 | 47,744.000 | 24.9040 | 16.6550 | -33.12% | -8.2490 | 2.7141 | 49.93% | nonmonotonic_latency_drop |
| A100 | a100_pairwise_nvlink | send_recv | 2 | 1 | 14,400.000 | 14,432.000 | 4.8000 | 6.3870 | 33.06% | 1.5870 | 0.3654 | -24.68% | candidate_latency_jump |
| H100 | h100_pairwise_nvlink | send_recv | 2 | 1 | 14,400.000 | 14,432.000 | 4.8000 | 6.3870 | 33.06% | 1.5870 | 0.3654 | -24.68% | candidate_latency_jump |
| A100 | a100_pairwise_nvlink | send_recv | 2 | 1 | 11,968.000 | 12,000.000 | 4.3340 | 5.7500 | 32.67% | 1.4160 | 0.1907 | -24.42% | candidate_latency_jump |
| H100 | h100_pairwise_nvlink | send_recv | 2 | 1 | 11,968.000 | 12,000.000 | 4.3340 | 5.7500 | 32.67% | 1.4160 | 0.1907 | -24.42% | candidate_latency_jump |
| A100 | a100_pairwise_nvlink | send_recv | 2 | 1 | 36,608.000 | 36,736.000 | 16.3040 | 10.9840 | -32.63% | -5.3200 | 1.4819 | 48.95% | nonmonotonic_latency_drop |
| H100 | h100_pairwise_nvlink | send_recv | 2 | 1 | 36,608.000 | 36,736.000 | 16.3040 | 10.9840 | -32.63% | -5.3200 | 1.4819 | 48.95% | nonmonotonic_latency_drop |
| A100 | a100_pairwise_nvlink | send_recv | 2 | 1 | 15,328.000 | 15,360.000 | 8.6490 | 5.8460 | -32.41% | -2.8030 | 0.7207 | 48.26% | nonmonotonic_latency_drop |
| H100 | h100_pairwise_nvlink | send_recv | 2 | 1 | 15,328.000 | 15,360.000 | 8.6490 | 5.8460 | -32.41% | -2.8030 | 0.7207 | 48.26% | nonmonotonic_latency_drop |
| A100 | a100_pairwise_nvlink | send_recv | 2 | 1 | 10,656.000 | 10,688.000 | 3.8240 | 5.0590 | 32.30% | 1.2350 | 0.1464 | -24.18% | candidate_latency_jump |
| H100 | h100_pairwise_nvlink | send_recv | 2 | 1 | 10,656.000 | 10,688.000 | 3.8240 | 5.0590 | 32.30% | 1.2350 | 0.1464 | -24.18% | candidate_latency_jump |
| A100 | a100_pairwise_nvlink | send_recv | 2 | 1 | 6,656.000 | 6,688.000 | 2.2670 | 2.9940 | 32.07% | 0.7270 | 0.0546 | -23.92% | candidate_latency_jump |
| H100 | h100_pairwise_nvlink | send_recv | 2 | 1 | 6,656.000 | 6,688.000 | 2.2670 | 2.9940 | 32.07% | 0.7270 | 0.0546 | -23.92% | candidate_latency_jump |
| A100 | a100_dgx | all_reduce | 4 | 2 | 90.000 | 98.000 | 0.1250 | 0.0850 | -32.00% | -0.0400 | 0.0055 | 60.13% | nonmonotonic_latency_drop |
| A100 | a100_pairwise_nvlink | send_recv | 2 | 1 | 9,280.000 | 9,312.000 | 3.6490 | 4.8160 | 31.98% | 1.1670 | 0.2115 | -23.97% | candidate_latency_jump |
| H100 | h100_pairwise_nvlink | send_recv | 2 | 1 | 9,280.000 | 9,312.000 | 3.6490 | 4.8160 | 31.98% | 1.1670 | 0.2115 | -23.97% | candidate_latency_jump |
| A40 | a40_pairwise_nvlink | send_recv | 2 | 1 | 186.000 | 194.000 | 0.1350 | 0.1780 | 31.85% | 0.0430 | 0.0133 | -20.90% | candidate_latency_jump |
| A100 | a100_dgx | all_reduce | 2 | 1 | 466.000 | 474.000 | 0.2240 | 0.1530 | -31.70% | -0.0710 | 0.0024 | 48.92% | nonmonotonic_latency_drop |
| A100 | a100_pairwise_nvlink | send_recv | 2 | 1 | 10,112.000 | 10,144.000 | 3.7110 | 4.8840 | 31.61% | 1.1730 | 0.3492 | -23.78% | candidate_latency_jump |
| H100 | h100_pairwise_nvlink | send_recv | 2 | 1 | 10,112.000 | 10,144.000 | 3.7110 | 4.8840 | 31.61% | 1.1730 | 0.3492 | -23.78% | candidate_latency_jump |
| A100 | a100_pairwise_nvlink | send_recv | 2 | 1 | 13,152.000 | 13,184.000 | 4.6200 | 6.0780 | 31.56% | 1.4580 | 0.1599 | -23.80% | candidate_latency_jump |
| H100 | h100_pairwise_nvlink | send_recv | 2 | 1 | 13,152.000 | 13,184.000 | 4.6200 | 6.0780 | 31.56% | 1.4580 | 0.1599 | -23.80% | candidate_latency_jump |
| A100 | a100_pairwise_nvlink | send_recv | 2 | 1 | 13,664.000 | 13,696.000 | 7.2790 | 4.9900 | -31.45% | -2.2890 | 0.2334 | 46.21% | nonmonotonic_latency_drop |
| H100 | h100_pairwise_nvlink | send_recv | 2 | 1 | 13,664.000 | 13,696.000 | 7.2790 | 4.9900 | -31.45% | -2.2890 | 0.2334 | 46.21% | nonmonotonic_latency_drop |
| A100 | a100_pairwise_nvlink | send_recv | 2 | 1 | 21,632.000 | 21,760.000 | 10.9920 | 7.5610 | -31.21% | -3.4310 | 0.2346 | 46.24% | nonmonotonic_latency_drop |
| H100 | h100_pairwise_nvlink | send_recv | 2 | 1 | 21,632.000 | 21,760.000 | 10.9920 | 7.5610 | -31.21% | -3.4310 | 0.2346 | 46.24% | nonmonotonic_latency_drop |
| A100 | a100_pairwise_nvlink | send_recv | 2 | 1 | 55,424.000 | 55,552.000 | 27.8740 | 19.1850 | -31.17% | -8.6890 | 2.8882 | 45.63% | nonmonotonic_latency_drop |
| H100 | h100_pairwise_nvlink | send_recv | 2 | 1 | 55,424.000 | 55,552.000 | 27.8740 | 19.1850 | -31.17% | -8.6890 | 2.8882 | 45.63% | nonmonotonic_latency_drop |
| A100 | a100_pairwise_nvlink | send_recv | 2 | 1 | 6,336.000 | 6,368.000 | 3.1290 | 2.1590 | -31.00% | -0.9700 | 0.1814 | 45.66% | nonmonotonic_latency_drop |
| H100 | h100_pairwise_nvlink | send_recv | 2 | 1 | 6,336.000 | 6,368.000 | 3.1290 | 2.1590 | -31.00% | -0.9700 | 0.1814 | 45.66% | nonmonotonic_latency_drop |
| A100 | a100_pairwise_nvlink | send_recv | 2 | 1 | 33,152.000 | 33,280.000 | 17.0560 | 11.7870 | -30.89% | -5.2690 | 1.6470 | 45.26% | nonmonotonic_latency_drop |
| H100 | h100_pairwise_nvlink | send_recv | 2 | 1 | 33,152.000 | 33,280.000 | 17.0560 | 11.7870 | -30.89% | -5.2690 | 1.6470 | 45.26% | nonmonotonic_latency_drop |
| A100 | a100_pairwise_nvlink | send_recv | 2 | 1 | 24,320.000 | 24,448.000 | 13.8240 | 9.5700 | -30.77% | -4.2540 | 0.7976 | 45.21% | nonmonotonic_latency_drop |
| H100 | h100_pairwise_nvlink | send_recv | 2 | 1 | 24,320.000 | 24,448.000 | 13.8240 | 9.5700 | -30.77% | -4.2540 | 0.7976 | 45.21% | nonmonotonic_latency_drop |
| A100 | a100_dgx | all_reduce | 2 | 2 | 394.000 | 402.000 | 0.0260 | 0.0180 | -30.77% | -0.0080 | 0.0027 | 47.38% | nonmonotonic_latency_drop |
| A100 | a100_pairwise_nvlink | send_recv | 2 | 1 | 30,848.000 | 30,976.000 | 15.7560 | 10.9100 | -30.76% | -4.8460 | 0.6837 | 45.02% | nonmonotonic_latency_drop |
| H100 | h100_pairwise_nvlink | send_recv | 2 | 1 | 30,848.000 | 30,976.000 | 15.7560 | 10.9100 | -30.76% | -4.8460 | 0.6837 | 45.02% | nonmonotonic_latency_drop |
| A100 | a100_pairwise_nvlink | send_recv | 2 | 1 | 21,120.000 | 21,248.000 | 11.8890 | 8.2500 | -30.61% | -3.6390 | 0.4253 | 44.98% | nonmonotonic_latency_drop |
| H100 | h100_pairwise_nvlink | send_recv | 2 | 1 | 21,120.000 | 21,248.000 | 11.8890 | 8.2500 | -30.61% | -3.6390 | 0.4253 | 44.98% | nonmonotonic_latency_drop |
| A100 | a100_pairwise_nvlink | send_recv | 2 | 1 | 43,904.000 | 44,032.000 | 23.4490 | 16.3240 | -30.39% | -7.1250 | 2.2562 | 44.07% | nonmonotonic_latency_drop |
| H100 | h100_pairwise_nvlink | send_recv | 2 | 1 | 43,904.000 | 44,032.000 | 23.4490 | 16.3240 | -30.39% | -7.1250 | 2.2562 | 44.07% | nonmonotonic_latency_drop |
| A40 | a40_pairwise_nvlink | send_recv | 2 | 1 | 522.000 | 530.000 | 0.2580 | 0.3360 | 30.23% | 0.0780 | 0.0181 | -22.04% | candidate_latency_jump |
| A100 | a100_pairwise_nvlink | send_recv | 2 | 1 | 36,992.000 | 37,120.000 | 15.8570 | 11.0790 | -30.13% | -4.7780 | 1.1180 | 43.62% | nonmonotonic_latency_drop |
| H100 | h100_pairwise_nvlink | send_recv | 2 | 1 | 36,992.000 | 37,120.000 | 15.8570 | 11.0790 | -30.13% | -4.7780 | 1.1180 | 43.62% | nonmonotonic_latency_drop |
| A100 | a100_pairwise_nvlink | send_recv | 2 | 1 | 25,728.000 | 25,856.000 | 14.7390 | 10.3060 | -30.08% | -4.4330 | 0.4660 | 43.73% | nonmonotonic_latency_drop |
| H100 | h100_pairwise_nvlink | send_recv | 2 | 1 | 25,728.000 | 25,856.000 | 14.7390 | 10.3060 | -30.08% | -4.4330 | 0.4660 | 43.73% | nonmonotonic_latency_drop |
| A100 | a100_pairwise_nvlink | send_recv | 2 | 1 | 13,344.000 | 13,376.000 | 5.0290 | 6.5390 | 30.03% | 1.5100 | 0.3956 | -22.91% | candidate_latency_jump |
| H100 | h100_pairwise_nvlink | send_recv | 2 | 1 | 13,344.000 | 13,376.000 | 5.0290 | 6.5390 | 30.03% | 1.5100 | 0.3956 | -22.91% | candidate_latency_jump |
| H100 | h100_pairwise_nvlink | all_reduce | 2 | 2 | 714.000 | 722.000 | 0.0300 | 0.0210 | -30.00% | -0.0090 | 0.0014 | 44.46% | nonmonotonic_latency_drop |
| A40 | a40_pairwise_nvlink | send_recv | 2 | 1 | 2,048.000 | 2,080.000 | 0.6220 | 0.8080 | 29.90% | 0.1860 | 0.0377 | -21.82% | candidate_latency_jump |
| A100 | a100_pairwise_nvlink | send_recv | 2 | 1 | 12,192.000 | 12,224.000 | 6.9540 | 4.9050 | -29.47% | -2.0490 | 0.3230 | 42.15% | nonmonotonic_latency_drop |
| H100 | h100_pairwise_nvlink | send_recv | 2 | 1 | 12,192.000 | 12,224.000 | 6.9540 | 4.9050 | -29.47% | -2.0490 | 0.3230 | 42.15% | nonmonotonic_latency_drop |
| A100 | a100_dgx | all_reduce | 8 | 4 | 250.000 | 258.000 | 0.2030 | 0.1440 | -29.06% | -0.0590 | 0.0041 | 45.48% | nonmonotonic_latency_drop |
| A100 | a100_dgx | all_reduce | 8 | 4 | 4,064.000 | 4,096.000 | 0.7820 | 0.5600 | -28.39% | -0.2220 | 0.0088 | 40.74% | nonmonotonic_latency_drop |
| A100 | a100_pairwise_nvlink | send_recv | 2 | 1 | 35,840.000 | 35,968.000 | 15.7050 | 11.2570 | -28.32% | -4.4480 | 0.7539 | 40.01% | nonmonotonic_latency_drop |
| H100 | h100_pairwise_nvlink | send_recv | 2 | 1 | 35,840.000 | 35,968.000 | 15.7050 | 11.2570 | -28.32% | -4.4480 | 0.7539 | 40.01% | nonmonotonic_latency_drop |
| A100 | a100_pairwise_nvlink | send_recv | 2 | 1 | 14,368.000 | 14,400.000 | 6.6910 | 4.8000 | -28.26% | -1.8910 | 0.0488 | 39.71% | nonmonotonic_latency_drop |
| H100 | h100_pairwise_nvlink | send_recv | 2 | 1 | 14,368.000 | 14,400.000 | 6.6910 | 4.8000 | -28.26% | -1.8910 | 0.0488 | 39.71% | nonmonotonic_latency_drop |
| A100 | a100_pairwise_nvlink | send_recv | 2 | 1 | 8,768.000 | 8,800.000 | 3.0150 | 3.8570 | 27.93% | 0.8420 | 0.2058 | -21.55% | candidate_latency_jump |
| H100 | h100_pairwise_nvlink | send_recv | 2 | 1 | 8,768.000 | 8,800.000 | 3.0150 | 3.8570 | 27.93% | 0.8420 | 0.2058 | -21.55% | candidate_latency_jump |
| A100 | a100_pairwise_nvlink | send_recv | 2 | 1 | 45,568.000 | 45,696.000 | 15.6220 | 19.9770 | 27.88% | 4.3550 | 1.2682 | -21.58% | candidate_latency_jump |
| H100 | h100_pairwise_nvlink | send_recv | 2 | 1 | 45,568.000 | 45,696.000 | 15.6220 | 19.9770 | 27.88% | 4.3550 | 1.2682 | -21.58% | candidate_latency_jump |
| A100 | a100_pairwise_nvlink | send_recv | 2 | 1 | 20,352.000 | 20,480.000 | 11.7160 | 8.4550 | -27.83% | -3.2610 | 0.0695 | 39.44% | nonmonotonic_latency_drop |
| H100 | h100_pairwise_nvlink | send_recv | 2 | 1 | 20,352.000 | 20,480.000 | 11.7160 | 8.4550 | -27.83% | -3.2610 | 0.0695 | 39.44% | nonmonotonic_latency_drop |
| A100 | a100_pairwise_nvlink | send_recv | 2 | 1 | 10,240.000 | 10,272.000 | 4.6380 | 5.9080 | 27.38% | 1.2700 | 0.3262 | -21.25% | candidate_latency_jump |
| H100 | h100_pairwise_nvlink | send_recv | 2 | 1 | 10,240.000 | 10,272.000 | 4.6380 | 5.9080 | 27.38% | 1.2700 | 0.3262 | -21.25% | candidate_latency_jump |
| A100 | a100_pairwise_nvlink | send_recv | 2 | 1 | 61,184.000 | 61,312.000 | 31.9390 | 23.2160 | -27.31% | -8.7230 | 1.9784 | 37.86% | nonmonotonic_latency_drop |
| H100 | h100_pairwise_nvlink | send_recv | 2 | 1 | 61,184.000 | 61,312.000 | 31.9390 | 23.2160 | -27.31% | -8.7230 | 1.9784 | 37.86% | nonmonotonic_latency_drop |
| A100 | a100_pairwise_nvlink | send_recv | 2 | 1 | 54,144.000 | 54,272.000 | 28.7890 | 20.9440 | -27.25% | -7.8450 | 1.2662 | 37.78% | nonmonotonic_latency_drop |
| H100 | h100_pairwise_nvlink | send_recv | 2 | 1 | 54,144.000 | 54,272.000 | 28.7890 | 20.9440 | -27.25% | -7.8450 | 1.2662 | 37.78% | nonmonotonic_latency_drop |
| A100 | a100_pairwise_nvlink | send_recv | 2 | 1 | 23,168.000 | 23,296.000 | 13.5850 | 9.9020 | -27.11% | -3.6830 | 0.2417 | 37.95% | nonmonotonic_latency_drop |
| H100 | h100_pairwise_nvlink | send_recv | 2 | 1 | 23,168.000 | 23,296.000 | 13.5850 | 9.9020 | -27.11% | -3.6830 | 0.2417 | 37.95% | nonmonotonic_latency_drop |
| A100 | a100_pairwise_nvlink | send_recv | 2 | 1 | 11,744.000 | 11,776.000 | 6.8870 | 5.0220 | -27.08% | -1.8650 | 0.2849 | 37.51% | nonmonotonic_latency_drop |
| H100 | h100_pairwise_nvlink | send_recv | 2 | 1 | 11,744.000 | 11,776.000 | 6.8870 | 5.0220 | -27.08% | -1.8650 | 0.2849 | 37.51% | nonmonotonic_latency_drop |
| A100 | a100_pairwise_nvlink | send_recv | 2 | 1 | 5,920.000 | 5,952.000 | 2.8920 | 2.1090 | -27.07% | -0.7830 | 0.1922 | 37.87% | nonmonotonic_latency_drop |
| H100 | h100_pairwise_nvlink | send_recv | 2 | 1 | 5,920.000 | 5,952.000 | 2.8920 | 2.1090 | -27.07% | -0.7830 | 0.1922 | 37.87% | nonmonotonic_latency_drop |
| A100 | a100_pairwise_nvlink | send_recv | 2 | 1 | 6,368.000 | 6,400.000 | 2.1590 | 2.7430 | 27.05% | 0.5840 | 0.0935 | -20.90% | candidate_latency_jump |
| H100 | h100_pairwise_nvlink | send_recv | 2 | 1 | 6,368.000 | 6,400.000 | 2.1590 | 2.7430 | 27.05% | 0.5840 | 0.0935 | -20.90% | candidate_latency_jump |
| A100 | a100_dgx | all_reduce | 2 | 2 | 746.000 | 754.000 | 0.0630 | 0.0460 | -26.98% | -0.0170 | 0.0038 | 38.43% | nonmonotonic_latency_drop |
| A100 | a100_pairwise_nvlink | send_recv | 2 | 1 | 35,328.000 | 35,456.000 | 20.4940 | 14.9680 | -26.96% | -5.5260 | 1.4809 | 37.41% | nonmonotonic_latency_drop |
| H100 | h100_pairwise_nvlink | send_recv | 2 | 1 | 35,328.000 | 35,456.000 | 20.4940 | 14.9680 | -26.96% | -5.5260 | 1.4809 | 37.41% | nonmonotonic_latency_drop |
| H100 | h100_pairwise_nvlink | all_reduce | 2 | 2 | 858.000 | 866.000 | 0.0300 | 0.0220 | -26.67% | -0.0080 | 0.0022 | 37.64% | nonmonotonic_latency_drop |
| A100 | a100_pairwise_nvlink | send_recv | 2 | 1 | 15,456.000 | 15,488.000 | 5.1350 | 6.5020 | 26.62% | 1.3670 | 0.0696 | -20.86% | candidate_latency_jump |
| H100 | h100_pairwise_nvlink | send_recv | 2 | 1 | 15,456.000 | 15,488.000 | 5.1350 | 6.5020 | 26.62% | 1.3670 | 0.0696 | -20.86% | candidate_latency_jump |
| A40 | a40_pairwise_nvlink | send_recv | 2 | 1 | 850.000 | 858.000 | 0.4070 | 0.5150 | 26.54% | 0.1080 | 0.0258 | -20.23% | candidate_latency_jump |
| A100 | a100_pairwise_nvlink | send_recv | 2 | 1 | 14,080.000 | 14,112.000 | 4.6520 | 5.8860 | 26.53% | 1.2340 | 0.2200 | -20.79% | candidate_latency_jump |
| H100 | h100_pairwise_nvlink | send_recv | 2 | 1 | 14,080.000 | 14,112.000 | 4.6520 | 5.8860 | 26.53% | 1.2340 | 0.2200 | -20.79% | candidate_latency_jump |
| A100 | a100_pairwise_nvlink | send_recv | 2 | 1 | 13,696.000 | 13,728.000 | 4.9900 | 6.3070 | 26.39% | 1.3170 | 0.2800 | -20.70% | candidate_latency_jump |
| H100 | h100_pairwise_nvlink | send_recv | 2 | 1 | 13,696.000 | 13,728.000 | 4.9900 | 6.3070 | 26.39% | 1.3170 | 0.2800 | -20.70% | candidate_latency_jump |
| A40 | a40_pairwise_nvlink | send_recv | 2 | 1 | 106.000 | 114.000 | 0.1220 | 0.0900 | -26.23% | -0.0320 | 0.0087 | 45.79% | nonmonotonic_latency_drop |
| A100 | a100_pairwise_nvlink | send_recv | 2 | 1 | 9,472.000 | 9,504.000 | 4.1410 | 5.2170 | 25.98% | 1.0760 | 0.3219 | -20.36% | candidate_latency_jump |
| H100 | h100_pairwise_nvlink | send_recv | 2 | 1 | 9,472.000 | 9,504.000 | 4.1410 | 5.2170 | 25.98% | 1.0760 | 0.3219 | -20.36% | candidate_latency_jump |
| A100 | a100_pairwise_nvlink | send_recv | 2 | 1 | 8,480.000 | 8,512.000 | 4.6750 | 3.4700 | -25.78% | -1.2050 | 0.3893 | 35.23% | nonmonotonic_latency_drop |
| H100 | h100_pairwise_nvlink | send_recv | 2 | 1 | 8,480.000 | 8,512.000 | 4.6750 | 3.4700 | -25.78% | -1.2050 | 0.3893 | 35.23% | nonmonotonic_latency_drop |
| A100 | a100_pairwise_nvlink | send_recv | 2 | 1 | 44,288.000 | 44,416.000 | 25.0010 | 18.6590 | -25.37% | -6.3420 | 0.8595 | 34.38% | nonmonotonic_latency_drop |
| H100 | h100_pairwise_nvlink | send_recv | 2 | 1 | 44,288.000 | 44,416.000 | 25.0010 | 18.6590 | -25.37% | -6.3420 | 0.8595 | 34.38% | nonmonotonic_latency_drop |
| A100 | a100_pairwise_nvlink | send_recv | 2 | 1 | 56,832.000 | 56,960.000 | 28.1110 | 21.0350 | -25.17% | -7.0760 | 2.3081 | 33.94% | nonmonotonic_latency_drop |
| H100 | h100_pairwise_nvlink | send_recv | 2 | 1 | 56,832.000 | 56,960.000 | 28.1110 | 21.0350 | -25.17% | -7.0760 | 2.3081 | 33.94% | nonmonotonic_latency_drop |
| A100 | a100_pairwise_nvlink | send_recv | 2 | 1 | 18,432.000 | 18,560.000 | 7.5370 | 5.6410 | -25.16% | -1.8960 | 0.1381 | 34.54% | nonmonotonic_latency_drop |
| H100 | h100_pairwise_nvlink | send_recv | 2 | 1 | 18,432.000 | 18,560.000 | 7.5370 | 5.6410 | -25.16% | -1.8960 | 0.1381 | 34.54% | nonmonotonic_latency_drop |
| A100 | a100_pairwise_nvlink | send_recv | 2 | 1 | 55,680.000 | 55,808.000 | 29.6870 | 22.2210 | -25.15% | -7.4660 | 1.4749 | 33.91% | nonmonotonic_latency_drop |
| H100 | h100_pairwise_nvlink | send_recv | 2 | 1 | 55,680.000 | 55,808.000 | 29.6870 | 22.2210 | -25.15% | -7.4660 | 1.4749 | 33.91% | nonmonotonic_latency_drop |
| A100 | a100_pairwise_nvlink | send_recv | 2 | 1 | 7,936.000 | 7,968.000 | 3.6620 | 2.7450 | -25.04% | -0.9170 | 0.0809 | 33.94% | nonmonotonic_latency_drop |
| H100 | h100_pairwise_nvlink | send_recv | 2 | 1 | 7,936.000 | 7,968.000 | 3.6620 | 2.7450 | -25.04% | -0.9170 | 0.0809 | 33.94% | nonmonotonic_latency_drop |
| H100 | h100_pairwise_nvlink | all_reduce | 2 | 2 | 1,248.000 | 1,280.000 | 0.0240 | 0.0300 | 25.00% | 0.0060 | 0.0005 | -17.95% | candidate_latency_jump |
| A100 | a100_pairwise_nvlink | send_recv | 2 | 1 | 28,416.000 | 28,544.000 | 13.9740 | 10.5960 | -24.17% | -3.3780 | 0.5120 | 32.47% | nonmonotonic_latency_drop |
| H100 | h100_pairwise_nvlink | send_recv | 2 | 1 | 28,416.000 | 28,544.000 | 13.9740 | 10.5960 | -24.17% | -3.3780 | 0.5120 | 32.47% | nonmonotonic_latency_drop |
| A100 | a100_pairwise_nvlink | send_recv | 2 | 1 | 14,784.000 | 14,816.000 | 7.4070 | 5.6230 | -24.09% | -1.7840 | 0.2089 | 32.01% | nonmonotonic_latency_drop |
| H100 | h100_pairwise_nvlink | send_recv | 2 | 1 | 14,784.000 | 14,816.000 | 7.4070 | 5.6230 | -24.09% | -1.7840 | 0.2089 | 32.01% | nonmonotonic_latency_drop |
| H100 | h100_dgx | send_recv | 2 | 1 | 2,016.000 | 2,048.000 | 0.0930 | 0.0710 | -23.66% | -0.0220 | 0.0018 | 33.07% | nonmonotonic_latency_drop |
| A100 | a100_pairwise_nvlink | send_recv | 2 | 1 | 8,544.000 | 8,576.000 | 3.5010 | 2.6910 | -23.14% | -0.8100 | 0.1071 | 30.59% | nonmonotonic_latency_drop |
| H100 | h100_pairwise_nvlink | send_recv | 2 | 1 | 8,544.000 | 8,576.000 | 3.5010 | 2.6910 | -23.14% | -0.8100 | 0.1071 | 30.59% | nonmonotonic_latency_drop |
| A100 | a100_pairwise_nvlink | send_recv | 2 | 1 | 54,912.000 | 55,040.000 | 23.7130 | 18.2570 | -23.01% | -5.4560 | 1.4013 | 30.19% | nonmonotonic_latency_drop |
| H100 | h100_pairwise_nvlink | send_recv | 2 | 1 | 54,912.000 | 55,040.000 | 23.7130 | 18.2570 | -23.01% | -5.4560 | 1.4013 | 30.19% | nonmonotonic_latency_drop |
| A100 | a100_pairwise_nvlink | send_recv | 2 | 1 | 6,880.000 | 6,912.000 | 3.9230 | 3.0210 | -22.99% | -0.9020 | 0.2715 | 30.46% | nonmonotonic_latency_drop |
| H100 | h100_pairwise_nvlink | send_recv | 2 | 1 | 6,880.000 | 6,912.000 | 3.9230 | 3.0210 | -22.99% | -0.9020 | 0.2715 | 30.46% | nonmonotonic_latency_drop |
| A40 | a40_pairwise_nvlink | send_recv | 2 | 1 | 642.000 | 650.000 | 0.3900 | 0.3020 | -22.56% | -0.0880 | 0.0237 | 30.75% | nonmonotonic_latency_drop |
| A100 | a100_pairwise_nvlink | send_recv | 2 | 1 | 8,736.000 | 8,768.000 | 3.8920 | 3.0150 | -22.53% | -0.8770 | 0.2043 | 29.56% | nonmonotonic_latency_drop |
| H100 | h100_pairwise_nvlink | send_recv | 2 | 1 | 8,736.000 | 8,768.000 | 3.8920 | 3.0150 | -22.53% | -0.8770 | 0.2043 | 29.56% | nonmonotonic_latency_drop |
| A100 | a100_dgx | all_reduce | 2 | 2 | 82.000 | 90.000 | 0.0580 | 0.0450 | -22.41% | -0.0130 | 0.0043 | 41.46% | nonmonotonic_latency_drop |
| A100 | a100_pairwise_nvlink | send_recv | 2 | 1 | 40,576.000 | 40,704.000 | 22.0540 | 17.1290 | -22.33% | -4.9250 | 1.0847 | 29.16% | nonmonotonic_latency_drop |
| H100 | h100_pairwise_nvlink | send_recv | 2 | 1 | 40,576.000 | 40,704.000 | 22.0540 | 17.1290 | -22.33% | -4.9250 | 1.0847 | 29.16% | nonmonotonic_latency_drop |
| A100 | a100_pairwise_nvlink | send_recv | 2 | 1 | 26,368.000 | 26,496.000 | 11.7060 | 9.1030 | -22.24% | -2.6030 | 0.3677 | 29.22% | nonmonotonic_latency_drop |
| H100 | h100_pairwise_nvlink | send_recv | 2 | 1 | 26,368.000 | 26,496.000 | 11.7060 | 9.1030 | -22.24% | -2.6030 | 0.3677 | 29.22% | nonmonotonic_latency_drop |
| A100 | a100_pairwise_nvlink | send_recv | 2 | 1 | 7,840.000 | 7,872.000 | 4.7520 | 3.7080 | -21.97% | -1.0440 | 0.1695 | 28.68% | nonmonotonic_latency_drop |
| H100 | h100_pairwise_nvlink | send_recv | 2 | 1 | 7,840.000 | 7,872.000 | 4.7520 | 3.7080 | -21.97% | -1.0440 | 0.1695 | 28.68% | nonmonotonic_latency_drop |
| A100 | a100_dgx | all_reduce | 8 | 8 | 58.000 | 66.000 | 0.0410 | 0.0320 | -21.95% | -0.0090 | 0.0009 | 45.80% | nonmonotonic_latency_drop |
| A100 | a100_pairwise_nvlink | send_recv | 2 | 1 | 12,128.000 | 12,160.000 | 6.6230 | 5.1790 | -21.80% | -1.4440 | 0.2533 | 28.22% | nonmonotonic_latency_drop |
| H100 | h100_pairwise_nvlink | send_recv | 2 | 1 | 12,128.000 | 12,160.000 | 6.6230 | 5.1790 | -21.80% | -1.4440 | 0.2533 | 28.22% | nonmonotonic_latency_drop |
| A100 | a100_pairwise_nvlink | send_recv | 2 | 1 | 9,056.000 | 9,088.000 | 4.2810 | 3.3570 | -21.58% | -0.9240 | 0.1072 | 27.98% | nonmonotonic_latency_drop |
| H100 | h100_pairwise_nvlink | send_recv | 2 | 1 | 9,056.000 | 9,088.000 | 4.2810 | 3.3570 | -21.58% | -0.9240 | 0.1072 | 27.98% | nonmonotonic_latency_drop |
| A100 | a100_pairwise_nvlink | send_recv | 2 | 1 | 13,376.000 | 13,408.000 | 6.5390 | 5.1440 | -21.33% | -1.3950 | 0.2740 | 27.42% | nonmonotonic_latency_drop |
| H100 | h100_pairwise_nvlink | send_recv | 2 | 1 | 13,376.000 | 13,408.000 | 6.5390 | 5.1440 | -21.33% | -1.3950 | 0.2740 | 27.42% | nonmonotonic_latency_drop |
| A100 | a100_pairwise_nvlink | send_recv | 2 | 1 | 8,640.000 | 8,672.000 | 5.1040 | 4.0400 | -20.85% | -1.0640 | 0.2420 | 26.80% | nonmonotonic_latency_drop |
| H100 | h100_pairwise_nvlink | send_recv | 2 | 1 | 8,640.000 | 8,672.000 | 5.1040 | 4.0400 | -20.85% | -1.0640 | 0.2420 | 26.80% | nonmonotonic_latency_drop |
| A100 | a100_pairwise_nvlink | send_recv | 2 | 1 | 13,920.000 | 13,952.000 | 7.1360 | 5.6650 | -20.61% | -1.4710 | 0.3672 | 26.26% | nonmonotonic_latency_drop |
| H100 | h100_pairwise_nvlink | send_recv | 2 | 1 | 13,920.000 | 13,952.000 | 7.1360 | 5.6650 | -20.61% | -1.4710 | 0.3672 | 26.26% | nonmonotonic_latency_drop |
| H100 | h100_dgx | all_reduce | 8 | 8 | 482.000 | 490.000 | 0.0390 | 0.0310 | -20.51% | -0.0080 | 0.0018 | 27.89% | nonmonotonic_latency_drop |
| A100 | a100_pairwise_nvlink | send_recv | 2 | 1 | 10,624.000 | 10,656.000 | 4.7880 | 3.8240 | -20.13% | -0.9640 | 0.2006 | 25.59% | nonmonotonic_latency_drop |
| H100 | h100_pairwise_nvlink | send_recv | 2 | 1 | 10,624.000 | 10,656.000 | 4.7880 | 3.8240 | -20.13% | -0.9640 | 0.2006 | 25.59% | nonmonotonic_latency_drop |
| A100 | a100_pairwise_nvlink | send_recv | 2 | 1 | 13,120.000 | 13,152.000 | 5.7750 | 4.6200 | -20.00% | -1.1550 | 0.2638 | 25.30% | nonmonotonic_latency_drop |
| H100 | h100_dgx | all_reduce | 4 | 4 | 4,960.000 | 4,992.000 | 0.0550 | 0.0440 | -20.00% | -0.0110 | 0.0019 | 25.81% | nonmonotonic_latency_drop |
| H100 | h100_pairwise_nvlink | send_recv | 2 | 1 | 13,120.000 | 13,152.000 | 5.7750 | 4.6200 | -20.00% | -1.1550 | 0.2638 | 25.30% | nonmonotonic_latency_drop |

</details>

## 附录 F：Workload 全量摘要与兼容性

### F.1 长度、相关性和到达分布

| Trace | 请求 | 唯一长度对 | Prefill P50/P90/P99/max | Decode P50/P90/P99/max | Total P50/P90/P99/max | >4K | 相关系数 | QPS | 间隔P50 |
|---|---|---|---|---|---|---|---|---|---|
| arxiv_summarization_stats_llama2_tokenizer_filtered_v2.csv | 28,257 | 27,788 | 2,730/3,702/3,933/4,054 | 167/372/3,271/4,056 | 2,992/3,907/4,077/4,096 | 0.00% | -0.463 | — | — |
| splitwise_code.csv | 8,819 | 7,981 | 1,469/5,188/7,436/7,437 | 13/55/251/1,899 | 1,493/5,208/7,462/7,841 | 14.25% | 0.001 | 2.566 | 63.798 ms |
| splitwise_conv.csv | 19,366 | 14,027 | 1,020/2,734/4,142/14,050 | 129/424/601/1,000 | 1,412/2,820/4,259/14,089 | 8.32% | -0.112 | 5.530 | 118.424 ms |

### F.2 Loader 兼容性

| 路径 | 行 | 重复保留 | Length | Replay | Interval | Total max | >4096行 | Arrival单调 |
|---|---|---|---|---|---|---|---|---|
| data/processed_traces/arxiv_summarization_stats_llama2_tokenizer_filtered_v2.csv | 28,257 | 469 | 是 | 否 | 否 | 4,096 | 0 | — |
| data/processed_traces/splitwise_code.csv | 8,819 | 0 | 是 | 是 | 否 | 7,841 | 1,257 | 是 |
| data/processed_traces/splitwise_conv.csv | 19,366 | 0 | 是 | 是 | 否 | 14,089 | 1,612 | 是 |

## 附录 G：16 项数据契约问题原始证据

| ID | 严重度 | 领域 | 发现 | 证据 | 影响 |
|---|---|---|---|---|---|
| DC-001 | high | network path | a40_pairwise_nvlink has send_recv.csv and a 136750-row attention.csv, but no all_reduce.csv; no current code or path template consumes the network/attention.csv file. | data/profiling/network/a40_pairwise_nvlink; config.py:503-508; sklearn_execution_time_predictor.py:87-103 | A40 TP>1 fails at file open; 136750 rows / 32.6 MB are orphaned in current main. |
| DC-002 | high | CPU overhead | The repository contains zero cpu_overheads.csv files and skip_cpu_overhead_modeling defaults to true. | config.py:511-512,559-561; sklearn_execution_time_predictor.py:518-549,871-899 | Default simulations force schedule/sampler/input/output/Ray overhead to zero; enabling the feature with default paths fails. |
| DC-003 | high | compute coverage | Seven of 27 concrete model-device pairs have no compute files: InternLM2-20B on all devices and both Llama-3 models on A40/H100. A100 Llama-3-8B attention covers TP1/4 only although its MLP covers TP1/2/4/8. | compute_coverage_matrix.csv; model_config.py | Valid model/device/TP combinations are narrower than the config registry suggests; unsupported selections fail only after loading/filtering. |
| DC-004 | high | multi-node all-reduce | The all-reduce filter requires num_workers==TP and devices_per_node==TP. In A100 DGX data this makes 3976 rows for (2,1),(4,2),(8,4),(16,8) unreachable and leaves TP16 empty. | sklearn_execution_time_predictor.py:166-172; network_reachability.csv | Published inter-node all-reduce data cannot be selected, so tensor parallelism spanning nodes is not represented by the current loader. |
| DC-005 | high | prediction cache | Prediction-cache hashes use the fitted estimator's string but not the training dataframe or learned tree state; to_dict also omits attention_input_file and several prediction-shaping settings. | sklearn_execution_time_predictor.py:281-290,422-449,901-920 | Changing CSV contents at the same path, or changing the attention CSV path, can silently reuse stale lookup predictions when best hyperparameters remain the same. |
| DC-006 | high | prediction domain | Lookup tables are generated only for configured ranges; runtime does direct dictionary access. No OOD check compares that range to observed training support. Old attention CSVs stop at KV=4032 while the default lookup includes 4096; Orca expands one-dimensional token lookups to 4096*128 although old MLP data stop at 4096. | sklearn_execution_time_predictor.py:57-63,588-716,725-869 | Random forests silently saturate outside the training range; shapes beyond the precomputed range fail with KeyError instead of profiling/fallback. |
| DC-007 | medium | aggregation | loaders remove only exact full-row duplicates and never aggregate repeated contract keys. After exact dedup there remain 166 extra MLP rows and 25812 extra attention rows sharing model features. | sklearn_execution_time_predictor.py:105-107,143-145,198-201; csv_inventory.csv | Overlapping sampling-grid boundaries receive extra weight, and repeated measurements with different medians are treated as independent samples rather than one robust shape estimate. |
| DC-008 | high | data quality | A100 Qwen-72B TP1 attention contains 16 active decode rows whose median is zero while max is nonzero; no target validation removes or flags them. | data/profiling/compute/a100/Qwen/Qwen-72B/attention.csv; csv_inventory.csv | Physically implausible zero-latency labels contaminate the decode model and the custom MAPE treats any nonzero prediction on them as exactly 100% error. |
| DC-009 | medium | schema fallback | Eighteen paper-era attention files lack attn_kv_cache_save.median and are silently filled with zero; three Phi-2 MLP files similarly lack post_attention_layernorm.median. | sklearn_execution_time_predictor.py:132-153; csv_inventory.csv | A missing measurement is indistinguishable from a measured zero. Phi-2 is semantically safe because post_attn_norm=false; KV-save zero is a compatibility assumption. |
| DC-010 | medium | hidden regimes | attention_backend, max_model_len and is_prefill are not filter/model features; only prefill_chunk_size derives the decode split. Current files each contain one backend, but old data use FLASH_ATTENTION and Llama-3 data use FLASHINFER. | sklearn_execution_time_predictor.py:143-164,207-218; csv_inventory.csv | Combining data from multiple backends or compiler regimes in one future CSV would silently train one mixed model. |
| DC-011 | medium | device-topology consistency | ReplicaConfig constructs device and network_device independently and does not check the node SKU's device type against the compute device. | config.py:428-464 | A user can silently combine A100 compute CSVs with H100 network CSVs, producing a syntactically valid but physically inconsistent simulation. |
| DC-012 | high | trace defaults | The default trace-length and trace-interval paths are absent. None of the three included traces has the interval loader's arrival_time column; only splitwise_code/conv satisfy replay's arrived_at schema. | config.py:48-65,111-127,228-247; trace_compatibility.csv | Those generator modes are not reproducible out of the box from repository data; schema errors appear at runtime. |
| DC-013 | medium | trace transformation | Replay truncates all excess tokens from prefill only and does not reassert prefill>0 or sort arrivals. It truncates 1257 splitwise_code and 1612 splitwise_conv rows at default max_tokens=4096. Trace loaders retain duplicates. | trace_replay_request_generator.py:23-67,80-92; trace_compatibility.csv | Scaling decode above max_tokens can create nonpositive prefill values that still satisfy the total-token assertion; included long-prompt distributions are materially altered. |
| DC-014 | medium | unused columns | Only *.median targets are learned. MLP embedding timings; attention input/output reshape timings; min/max/mean/std; and metadata such as backend are not consumed. | sklearn_execution_time_predictor.py:451-579; csv_inventory.csv | The files contain uncertainty and component information that cannot influence predicted latency, and omitted reshape/embedding work is not automatically included elsewhere. |
| DC-015 | medium | communication units | Network size is converted to tokens as size/(embedding_dim*2), hard-coding two bytes per hidden element; all-reduce adds a fixed NCCL launch term after the learned median. | sklearn_execution_time_predictor.py:220-236,811-817 | FP8/FP32 or compressed communication cannot reuse the same contract without changing the derivation; dtype is not represented in CSV filters. |
| DC-016 | info | data integrity | All 40 compute files match their directory model's configured dimensions; all use block_size=16; active prefill/decode targets have no nulls. The only active zero-target anomaly is the 16-row A100 Qwen case. | compute_coverage_matrix.csv; csv_inventory.csv | Present and supported model/device/TP slices are structurally consistent, so most failures are coverage/selection issues rather than widespread schema corruption. |

## 附录 H：NPU 采样与建模执行清单

### H.1 一条样本必须带的契约

| 层 | 必需字段 |
|---|---|
| 硬件 | NPU 型号、卡/节点拓扑、频率/功耗、固件、NUMA/主机 |
| 软件 | CANN、torch_npu、框架、算子库、编译器 commit、关键 flag |
| 图/kernel | graph hash、kernel ID、tiling ID、workspace、融合方案、stream 数 |
| Shape | 原始/对齐后维度、dtype、layout、batch、seq、KV、TP/EP/PP |
| 搬运 | H2D/D2D/片上 bytes、路径、是否与 compute 重叠 |
| 状态 | cold/warm、compile cache hit、独立进程、run/replicate、采集时间 |
| 标签 | compile、host launch、搬运、kernel、同步、端到端逐项时间与原始 repeats |

### H.2 推荐实验顺序

1. 以真实 workload 分布建立粗网格，同时保留安全边界点。
2. 在相邻点上计算绝对变化、相对变化、噪声标准化变化和制度标签变化。
3. 对候选边界补采 `x±1`、`x±tile`、2 的幂/对齐块两侧。
4. 每个 shape 分开 cold compile、warm steady-state 和多个独立进程。
5. 先训练 regime 分类器，再训练 regime 内回归；无法识别 regime 时报告置信度。
6. 运行时遇到 OOD/低置信度，拒绝静默外推，转为补采或保守 fallback。

### H.3 最低验收门槛

- Group holdout、连续区间 holdout、边界邻域 holdout、编译器/backend OOD 全部独立报告；
- MAE（μs/ms）、相对误差、P95/P99、边界误差和制度分类准确率同时给出；
- 端到端回放与 operator 级误差同时评估；
- 数据、代码、环境、模型和 lookup cache 全部内容寻址；
- 任何超出 profile 域的调用必须显式告警或失败，不允许叶节点常数悄悄饱和。


## 附录 I：本地证据与可重跑产物目录

| 相对路径 | 用途 | KiB |
|---|---|---|
| compute_agent/COMPUTE_ANALYSIS.md | 叙事报告 | 11.4 |
| compute_agent/analyze_compute_profiles.py | 可重跑分析脚本 | 38.7 |
| compute_agent/artifacts/audit_summary.json | 机器可读摘要/清单 | 1.4 |
| compute_agent/artifacts/boundary_quantization_summary.csv | 结构化证据表 | 1,326.9 |
| compute_agent/artifacts/column_missingness.csv | 结构化证据表 | 186.1 |
| compute_agent/artifacts/compact_asset_summary.csv | 结构化证据表 | 0.4 |
| compute_agent/artifacts/compact_cross_gpu_speedup.csv | 结构化证据表 | 2.3 |
| compute_agent/artifacts/compact_monotonicity.csv | 结构化证据表 | 9.0 |
| compute_agent/artifacts/compact_summary.json | 机器可读摘要/清单 | 3.1 |
| compute_agent/artifacts/compact_timing_quantization.csv | 结构化证据表 | 0.3 |
| compute_agent/artifacts/compact_tp_compute_scaling.csv | 结构化证据表 | 7.2 |
| compute_agent/artifacts/compact_within_row_jitter.csv | 结构化证据表 | 1.9 |
| compute_agent/artifacts/cross_gpu_speedup_detail.csv | 结构化证据表 | 2,268.6 |
| compute_agent/artifacts/cross_gpu_speedup_summary.csv | 结构化证据表 | 131.7 |
| compute_agent/artifacts/duplicate_shape_quality.csv | 结构化证据表 | 540.2 |
| compute_agent/artifacts/file_inventory.csv | 结构化证据表 | 5.3 |
| compute_agent/artifacts/invariant_violations.csv | 结构化证据表 | 0.7 |
| compute_agent/artifacts/monotonicity_summary.csv | 结构化证据表 | 361.6 |
| compute_agent/artifacts/operator_runtime_summary.csv | 结构化证据表 | 191.4 |
| compute_agent/artifacts/sampling_steps.csv | 结构化证据表 | 137.6 |
| compute_agent/artifacts/schemas.json | 机器可读摘要/清单 | 8.6 |
| compute_agent/artifacts/shape_coverage.csv | 结构化证据表 | 55.0 |
| compute_agent/artifacts/timing_quantization.csv | 结构化证据表 | 34.3 |
| compute_agent/artifacts/top_local_jumps.csv | 结构化证据表 | 5,793.1 |
| compute_agent/artifacts/tp_compute_scaling_summary.csv | 结构化证据表 | 111.8 |
| compute_agent/artifacts/within_row_jitter.csv | 结构化证据表 | 56.3 |
| compute_agent/build_compute_deep_appendix.py | 可重跑分析脚本 | 25.0 |
| compute_agent/logs/analysis.log | 运行日志 | 2.7 |
| compute_agent/make_compact_summaries.py | 可重跑分析脚本 | 7.1 |
| contract_agent/DATA_CONTRACT_ANALYSIS.md | 叙事报告 | 18.6 |
| contract_agent/audit_data_contract.py | 可重跑分析脚本 | 24.6 |
| contract_agent/build_deep_appendix.py | 可重跑分析脚本 | 35.7 |
| contract_agent/compute_coverage_matrix.csv | 结构化证据表 | 6.0 |
| contract_agent/contract_summary.json | 机器可读摘要/清单 | 4.8 |
| contract_agent/csv_inventory.csv | 结构化证据表 | 16.7 |
| contract_agent/findings.csv | 结构化证据表 | 6.8 |
| contract_agent/network_reachability.csv | 结构化证据表 | 0.9 |
| contract_agent/trace_compatibility.csv | 结构化证据表 | 0.5 |
| main/compute_coverage.csv | 结构化证据表 | 21.1 |
| main/compute_operator_quality.csv | 结构化证据表 | 120.8 |
| main/cross_gpu_speedup.csv | 结构化证据表 | 79.2 |
| main/duplicate_shape_dispersion.csv | 结构化证据表 | 50.2 |
| main/file_inventory.csv | 结构化证据表 | 7.7 |
| main/main_scan.py | 可重跑分析脚本 | 22.5 |
| main/main_summary.json | 机器可读摘要/清单 | 0.7 |
| main/schema_catalog.csv | 结构化证据表 | 9.5 |
| main/workload_summary.csv | 结构化证据表 | 2.6 |
| network_workload_agent/NETWORK_WORKLOAD_ANALYSIS.md | 叙事报告 | 24.5 |
| network_workload_agent/analysis_summary.json | 机器可读摘要/清单 | 91.6 |
| network_workload_agent/analyze_network_workloads.py | 可重跑分析脚本 | 56.7 |
| network_workload_agent/file_inventory.csv | 结构化证据表 | 8.3 |
| network_workload_agent/misplaced_compute_profile_summary.csv | 结构化证据表 | 1.0 |
| network_workload_agent/network_anomalies.csv | 结构化证据表 | 4.3 |
| network_workload_agent/network_duplicate_keys.csv | 结构化证据表 | 2.6 |
| network_workload_agent/network_file_quality.csv | 结构化证据表 | 1.9 |
| network_workload_agent/network_group_summary.csv | 结构化证据表 | 7.8 |
| network_workload_agent/network_rows_enriched.csv | 结构化证据表 | 7,605.9 |
| network_workload_agent/network_threshold_candidates.csv | 结构化证据表 | 67.5 |
| network_workload_agent/network_transitions.csv | 结构化证据表 | 5,587.7 |
| network_workload_agent/output_manifest.json | 机器可读摘要/清单 | 2.2 |
| network_workload_agent/workload_correlations.csv | 结构化证据表 | 0.5 |
| network_workload_agent/workload_coverage.csv | 结构化证据表 | 7.1 |
| network_workload_agent/workload_quality.csv | 结构化证据表 | 1.2 |
| network_workload_agent/workload_quantiles.csv | 结构化证据表 | 10.9 |
| network_workload_agent/workload_summary.csv | 结构化证据表 | 2.0 |


## 最终结论

Vidur 公开数据证明了一条有价值但需要精确定义的路线：**微基准 + 分算子学习 + 离散事件组合**可以显著降低端到端系统探索成本。它真正依赖的是“采样域内、制度稳定、数据契约正确”，而不是硬件时延天然光滑。

将这条路线迁移到昇腾 NPU 时，最关键的升级是把编译、tiling、kernel、workspace、搬运和缓存状态从隐藏扰动变成显式 regime；随后用边界感知采样、分 regime 模型和 OOD 拒绝机制保证可信度。这样，“shape 细微变化会抖动”不是不可学习的证据，反而成为应该识别和建模的结构信息。

本报告中的所有百分比、speedup 和 change-point 均为 current-main 公开数据的描述性统计。没有对应软件栈 manifest 或定向复测时，不应把它们解释为单一 GPU/NPU 微架构的因果结论。

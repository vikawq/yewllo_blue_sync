from __future__ import annotations

import csv
import json
import math
import re
import statistics
from collections import defaultdict
from pathlib import Path


ROOT = Path(r"D:\workspaces\trace\vidur_data_analysis")
HERE = ROOT / "complete_report"
OUTPUT = HERE / "VIDUR_COMPLETE_DATA_REPORT.md"


def read_csv(path: Path) -> list[dict[str, str]]:
    with path.open("r", encoding="utf-8-sig", newline="") as handle:
        return list(csv.DictReader(handle))


def read_text(path: Path) -> str:
    return path.read_text(encoding="utf-8").strip()


def fnum(value, digits=3, default="—") -> str:
    if value is None or value == "":
        return default
    try:
        x = float(value)
    except (TypeError, ValueError):
        return str(value)
    if math.isnan(x) or math.isinf(x):
        return default
    if abs(x - round(x)) < 1e-12 and digits == 0:
        return f"{int(round(x)):,}"
    return f"{x:,.{digits}f}"


def pct(value, digits=2, already_percent=False) -> str:
    if value is None or value == "":
        return "—"
    x = float(value)
    if not already_percent:
        x *= 100
    return f"{x:.{digits}f}%"


def esc(value) -> str:
    if value is None:
        return "—"
    text = str(value).replace("\r", " ").replace("\n", " ")
    return text.replace("|", "\\|").strip() or "—"


def md_table(headers: list[str], rows: list[list[object]]) -> str:
    lines = [
        "| " + " | ".join(esc(x) for x in headers) + " |",
        "|" + "|".join("---" for _ in headers) + "|",
    ]
    lines.extend("| " + " | ".join(esc(x) for x in row) + " |" for row in rows)
    return "\n".join(lines)


def downgrade(markdown: str, levels: int = 2) -> str:
    out = []
    in_fence = False
    for line in markdown.splitlines():
        if line.lstrip().startswith("```"):
            in_fence = not in_fence
            out.append(line)
            continue
        if not in_fence:
            match = re.match(r"^(#{1,6})\s+(.*)$", line)
            if match:
                hashes = "#" * min(6, len(match.group(1)) + levels)
                line = f"{hashes} {match.group(2)}"
        out.append(line)
    return "\n".join(out)


def bool_zh(value: str) -> str:
    return "是" if str(value).lower() == "true" else "否"


inventory = read_csv(ROOT / "main" / "file_inventory.csv")
schemas = read_csv(ROOT / "main" / "schema_catalog.csv")
workloads = read_csv(ROOT / "main" / "workload_summary.csv")
compute_files = read_csv(ROOT / "compute_agent" / "artifacts" / "file_inventory.csv")
shape_coverage = read_csv(ROOT / "compute_agent" / "artifacts" / "shape_coverage.csv")
operator_runtime = read_csv(ROOT / "compute_agent" / "artifacts" / "operator_runtime_summary.csv")
top_jumps = read_csv(ROOT / "compute_agent" / "artifacts" / "top_local_jumps.csv")
jitter = read_csv(ROOT / "compute_agent" / "artifacts" / "compact_within_row_jitter.csv")
monotonicity = read_csv(ROOT / "compute_agent" / "artifacts" / "compact_monotonicity.csv")
cross_gpu = read_csv(ROOT / "compute_agent" / "artifacts" / "compact_cross_gpu_speedup.csv")
tp_scaling = read_csv(ROOT / "compute_agent" / "artifacts" / "compact_tp_compute_scaling.csv")
coverage_matrix = read_csv(ROOT / "contract_agent" / "compute_coverage_matrix.csv")
network_reachability = read_csv(ROOT / "contract_agent" / "network_reachability.csv")
trace_compatibility = read_csv(ROOT / "contract_agent" / "trace_compatibility.csv")
findings = read_csv(ROOT / "contract_agent" / "findings.csv")
network_quality = read_csv(ROOT / "network_workload_agent" / "network_file_quality.csv")
network_groups = read_csv(ROOT / "network_workload_agent" / "network_group_summary.csv")
network_candidates = read_csv(ROOT / "network_workload_agent" / "network_threshold_candidates.csv")


def consumption_status(row: dict[str, str]) -> str:
    path = row["path"].replace("\\", "/")
    if path.endswith("a40_pairwise_nvlink/attention.csv"):
        return "不消费：误放的 attention compute profile"
    if row["category"] == "compute":
        return "匹配 device/model/TP/block-size 后进入 operator learner"
    if row["category"] == "network":
        if row["kind"] == "all_reduce":
            return "受 num_workers==TP 且 devices_per_node==TP 过滤"
        return "按节点内/跨节点 send-recv 路径过滤"
    if "arxiv" in path:
        return "可作长度分布；不兼容 replay/interval"
    return "兼容 length + replay；不兼容 interval"


def schema_class(columns: str, paths: str) -> str:
    if "attn_decode" in columns:
        return "Llama-3 attention / FlashInfer" if "attn_kv_cache_save" in columns else "旧 attention / FlashAttention"
    if "mlp_up_proj" in columns:
        return "Phi-2 MLP" if "post_attention_layernorm" not in columns else "标准 MLP"
    if "collective" in columns:
        return "Network collective"
    if "arrived_at" in columns:
        return "Replay workload"
    if "total_tokens" in columns:
        return "Length workload"
    return "其他"


# Aggregate compute shape domains to one row per file.
coverage_by_file: dict[str, list[dict[str, str]]] = defaultdict(list)
for row in shape_coverage:
    coverage_by_file[row["relative_path"]].append(row)

shape_domain_rows = []
for path, group in sorted(coverage_by_file.items()):
    first = group[0]
    tps = sorted({int(float(r["tp"])) for r in group})
    phases = sorted({r["phase"] for r in group})
    backends = sorted({r["attention_backend"] for r in group if r["attention_backend"]})
    if first["kind"] == "mlp":
        axis_min = min(float(r["axis_min"]) for r in group if r["axis_min"])
        axis_max = max(float(r["axis_max"]) for r in group if r["axis_max"])
        step_med = statistics.median(float(r["step_median"]) for r in group if r["step_median"])
        domain = f"num_tokens {axis_min:.0f}–{axis_max:.0f}; 中位步长 {step_med:.0f}"
    else:
        batch_max = max(float(r["batch_size_max"]) for r in group if r["batch_size_max"])
        kv_max = max(float(r["kv_cache_size_max"]) for r in group if r["kv_cache_size_max"])
        prefill_max = max(float(r["prefill_chunk_size_max"]) for r in group if r["prefill_chunk_size_max"])
        domain = f"batch≤{batch_max:.0f}; KV≤{kv_max:.0f}; prefill≤{prefill_max:.0f}"
    shape_domain_rows.append([
        first["gpu"].upper(),
        first["model"],
        first["kind"],
        ",".join(str(x) for x in tps),
        ",".join(phases),
        ",".join(x.replace("AttentionBackend.", "") for x in backends) or "—",
        domain,
    ])


# Aggregate operator timing by GPU/phase/operator across model×TP cells.
runtime_groups: dict[tuple[str, str, str], list[dict[str, str]]] = defaultdict(list)
for row in operator_runtime:
    if not row["runtime_p50"]:
        continue
    phase = "prefill" if row["is_prefill"].lower() == "true" else "decode" if row["kind"] == "attention" else "token"
    runtime_groups[(row["gpu"].upper(), phase, row["operator"])].append(row)

runtime_rows = []
for (gpu, phase, op), group in sorted(runtime_groups.items()):
    p50s = [float(r["runtime_p50"]) for r in group]
    p95s = [float(r["runtime_p95"]) for r in group]
    p99s = [float(r["runtime_p99"]) for r in group]
    runtime_rows.append([
        gpu, phase, op, len(group),
        fnum(statistics.median(p50s), 4),
        fnum(statistics.median(p95s), 4),
        fnum(statistics.median(p99s), 4),
        fnum(max(float(r["runtime_max"]) for r in group), 4),
    ])


# Meaningful local jumps: positive timings, small relative shape step, sort by absolute change.
meaningful_jumps = []
for row in top_jumps:
    try:
        prev = float(row["runtime_prev"])
        curr = float(row["runtime_curr"])
        x_prev = float(row["x_prev"])
        x_curr = float(row["x_curr"])
        change = float(row["runtime_change_pct"])
    except (TypeError, ValueError):
        continue
    if prev < 0.02 or curr <= 0 or x_prev <= 0:
        continue
    if abs(x_curr - x_prev) / x_prev > 0.25:
        continue
    meaningful_jumps.append((abs(change), row))
meaningful_jumps.sort(key=lambda item: item[0], reverse=True)
meaningful_jumps = meaningful_jumps[:50]


network_candidates_sorted = sorted(
    network_candidates,
    key=lambda r: abs(float(r["latency_rel_change"])),
    reverse=True,
)


def make_file_manifest() -> str:
    rows = []
    for row in inventory:
        rows.append([
            row["path"], row["category"], row["device"] or "—", row["model"] or "—", row["kind"],
            fnum(row["rows"], 0), row["columns"], fnum(float(row["bytes"]) / 1_000_000, 4),
            row["schema_hash"], fnum(row["exact_duplicate_rows"], 0), pct(row["null_cell_rate"], 4),
            consumption_status(row),
        ])
    return md_table(
        ["路径", "类别", "设备", "模型", "类型", "行", "列", "MB", "Schema", "完整重复", "空值率", "当前消费状态"],
        rows,
    )


def make_compute_file_table() -> str:
    rows = []
    for row in compute_files:
        rows.append([
            row["gpu"].upper(), row["model"], row["kind"], fnum(row["rows"], 0), row["columns"],
            fnum(row["unique_shapes"], 0), fnum(row["repeated_shape_groups"], 0),
            fnum(row["rows_in_repeated_shapes"], 0), fnum(row["exact_duplicate_rows_removable"], 0),
            row["operator_count"], row["schema_hash"],
        ])
    return md_table(
        ["GPU", "模型", "文件", "行", "列", "唯一shape", "重复shape组", "重复shape内行", "可删完整重复", "Operator数", "Schema"],
        rows,
    )


def make_schema_table() -> str:
    rows = []
    for row in schemas:
        cols = row["columns"].split("|") if row["columns"] else []
        paths = [x for x in row["paths"].splitlines() if x]
        rows.append([
            row["schema_hash"], schema_class(row["columns"], row["paths"]), row["file_count"], len(cols),
            "; ".join(paths[:3]) + (f"；另 {len(paths)-3} 个" if len(paths) > 3 else ""),
        ])
    return md_table(["Schema hash", "解释", "文件数", "业务列数", "示例路径"], rows)


def evidence_catalog() -> str:
    files = []
    for folder in [ROOT / "main", ROOT / "compute_agent", ROOT / "network_workload_agent", ROOT / "contract_agent"]:
        for path in folder.rglob("*"):
            if not path.is_file() or "__pycache__" in path.parts:
                continue
            rel = path.relative_to(ROOT)
            suffix = path.suffix.lower()
            role = {
                ".md": "叙事报告",
                ".csv": "结构化证据表",
                ".json": "机器可读摘要/清单",
                ".py": "可重跑分析脚本",
                ".log": "运行日志",
            }.get(suffix, "辅助文件")
            files.append([str(rel).replace("\\", "/"), role, fnum(path.stat().st_size / 1024, 1)])
    files.sort()
    return md_table(["相对路径", "用途", "KiB"], files)


core_report = downgrade(read_text(ROOT / "VIDUR_REPOSITORY_DATA_ANALYSIS.md"), 2)
compute_deep_path = HERE / "COMPUTE_DEEP_APPENDIX.md"
compute_deep = downgrade(read_text(compute_deep_path), 2) if compute_deep_path.exists() else downgrade(read_text(ROOT / "compute_agent" / "COMPUTE_ANALYSIS.md"), 2)
network_deep_path = HERE / "NETWORK_WORKLOAD_DEEP_APPENDIX.md"
network_deep = downgrade(read_text(network_deep_path), 2) if network_deep_path.exists() else downgrade(read_text(ROOT / "network_workload_agent" / "NETWORK_WORKLOAD_ANALYSIS.md"), 2)
contract_deep_path = HERE / "DATA_CONTRACT_DEEP_APPENDIX.md"
contract_deep = downgrade(read_text(contract_deep_path), 2) if contract_deep_path.exists() else downgrade(read_text(ROOT / "contract_agent" / "DATA_CONTRACT_ANALYSIS.md"), 2)


sections: list[str] = []
sections.append("""# Vidur 仓库公开数据：完整审计、建模边界与 NPU 迁移报告

> 报告版本：2026-08-15 扩展版  
> 数据快照：`microsoft/vidur` current main，commit `8383d2935bc62723a212090baa9f98ada206fc14`  
> 覆盖：53 个 CSV、1,436,810 行、275,312,735 bytes；代码读取链、可达性、学习器、lookup 与缓存  
> 定位：这是一份“研究报告 + 数据字典 + 证据索引”，不是把 CSV 原样拼接，也不把 current-main 冒充论文提交时数据。

## 如何阅读这份报告

- **想快速做决策**：阅读第 1–3 章和“对昇腾 NPU 的落地建议”。
- **想判断数据是否可学习**：阅读 compute 的网格、噪声、局部跳变、评估切分和 OOD 章节。
- **想复现/改 Vidur**：阅读数据契约、loader/feature/lookup/cache 数据流，以及 16 项问题清单。
- **想逐个核对 CSV**：跳到附录 A–H；53 个文件和 284 个 network change-point 候选均可检索。

## 一页答案

1. 仓库数据的主体是 operator/collective 微基准，不是端到端请求观测。
2. 在固定 device/model/TP/backend/软件制度且位于采样域内时，shape→median latency 是**分段可学习**的。
3. 数据并非全局平滑：量化平台、非单调、tiling/kernel/搬运制度切换候选广泛存在。
4. 低随机 CV 误差不能代表边界、新 shape、长上下文或新编译器的精度；当前实现还有重复 shape 泄漏和训练集 score 问题。
5. GPU 间没有统一缩放因子：attention、投影、elementwise 和 network 的倍率显著不同。
6. current-main 缺论文 Chat-1M/BWB 等 workload，因此只能复核当前仓库，不能原样复现论文全部实验。
7. 对 NPU 应建模“shape + regime”，而不是只建一个全局 shape→time 函数。

![完整数据审计概览](figures/overview.png)

## 报告结构

1. 统一结论与主报告
2. Compute 深度审计
3. Network 与 workload 深度审计
4. 数据契约、代码消费与可达性
5. 全量可检索附录与证据目录
""")

sections.append("\n## 第一部分：统一主报告\n\n" + core_report)
sections.append("\n## 第二部分：Compute 深度审计\n\n![Compute 覆盖矩阵](figures/compute_coverage.png)\n\n![Compute 测量抖动](figures/compute_jitter.png)\n\n" + compute_deep)
sections.append("\n## 第三部分：Network 与 workload 深度审计\n\n![Network 分组性能](figures/network_performance.png)\n\n" + network_deep)
sections.append("\n## 第四部分：数据契约与代码消费链\n\n" + contract_deep)


sections.append("""
## 第五部分：统一数据流与“可学习”定义

### 从 CSV 到模拟结果

```mermaid
flowchart LR
  A["53 个 CSV"] --> B["路径展开与 pandas 读取"]
  B --> C["整行 drop_duplicates"]
  C --> D["按 device/model/TP/block/topology 过滤"]
  D --> E["派生特征：tokens、KV、chunk²、bytes→tokens"]
  E --> F["各 operator 独立 Random Forest + GridSearchCV"]
  F --> G["生成有限范围 prediction lookup"]
  G --> H["运行时 batch 聚合与粒度取整"]
  H --> I["operator + collective + 固定修正项组合"]
  I --> J["离散事件模拟与请求指标"]

  K["未消费：多数 min/max/mean/std、backend 元数据、部分 reshape/emb、CPU overhead"] -.-> E
  L["风险：OOD 饱和、KeyError、旧 lookup cache"] -.-> G
```

### 建议采用的严格定义

“可学习”不应等同于随机拆分 MAPE 低，而应同时满足：

1. 训练和测试属于同一硬件/软件/编译/tiling/kernel 制度，或模型能可靠识别制度；
2. 测试 shape 位于训练点覆盖的插值域，而不是树叶常数外推区；
3. 同 shape 的所有重复位于同一 fold，避免复制与网格边界泄漏；
4. 连续区间留出、边界邻域留出和 OOD 留出都有单独结果；
5. 对接近 0 的 operator 同时报 MAE（μs）而非只报 MAPE；
6. 端到端误差还要包含 CPU、搬运、通信、重叠、排队和流水线，而非只验证 operator median。
""")


sections.append("\n## 附录 A：全部 53 个 CSV 资产与消费状态\n\n" + make_file_manifest())
sections.append("\n## 附录 B：9 类 schema 目录\n\n" + make_schema_table())
sections.append("\n## 附录 C：40 个 compute 文件逐项质量摘要\n\n" + make_compute_file_table())
sections.append("\n### C.1 每个 compute 文件的 shape 域\n\n" + md_table(
    ["GPU", "模型", "文件", "TP", "Phase", "Backend", "观测域"], shape_domain_rows
))
sections.append("\n### C.2 GPU×phase×operator 运行时间分布汇总（跨 model×TP cell 的中位）\n\n单位均为 ms。该表用于量级比较，不替代同 shape 严格配对。\n\n" + md_table(
    ["GPU", "Phase", "Operator", "Cells", "P50中位", "P95中位", "P99中位", "最大观测"], runtime_rows
))
sections.append("\n### C.3 行内测量抖动完整汇总\n\n" + md_table(
    ["GPU", "Operator", "模型", "行", "文件CV P50中位(%)", "文件CV P95中位(%)", "单文件P95最大(%)", "Range P95中位(%)"],
    [[r["gpu"].upper(), r["operator"], r["models"], fnum(r["rows"], 0), fnum(r["file_cv_p50_median"], 3), fnum(r["file_cv_p95_median"], 3), fnum(r["file_cv_p95_max"], 3), fnum(r["file_range_p95_median"], 3)] for r in jitter]
))
sections.append("\n### C.4 相邻 shape 单调性完整汇总\n\n" + md_table(
    ["GPU", "类型", "Phase", "Operator", "轴", "相邻对", "下降>5%", "上升>5%", "最大下降", "最大上升"],
    [[r["gpu"].upper(), r["kind"], r["phase"], r["operator"], r["axis"], fnum(r["adjacent_pairs"], 0), pct(r["decrease_gt_5pct_fraction"]), pct(r["increase_gt_5pct_fraction"]), pct(r["largest_decrease_pct"], already_percent=True), pct(r["largest_increase_pct"], already_percent=True)] for r in monotonicity]
))
sections.append("\n### C.5 局部大跳变复测候选 Top 50\n\n筛选要求 `runtime_prev≥0.02 ms` 且相邻 shape 相对步长≤25%；按绝对时延变化百分比排序。它们是复测候选，不是已证实的 kernel 因果。\n\n" + md_table(
    ["GPU", "模型", "TP", "Phase", "Operator", "轴", "x前", "x后", "前ms", "后ms", "变化", "绝对变化ms"],
    [[r["gpu"].upper(), r["model"], r["tp"], r["phase"], r["operator"], r["axis"], fnum(r["x_prev"], 0), fnum(r["x_curr"], 0), fnum(r["runtime_prev"], 4), fnum(r["runtime_curr"], 4), pct(r["runtime_change_pct"], already_percent=True), fnum(r["runtime_delta_ms"], 4)] for _, r in meaningful_jumps]
))
sections.append("\n### C.6 严格 shape 交集的跨 GPU speedup\n\n" + md_table(
    ["From", "To", "类型", "Operator", "模型", "TP cells", "共同shape", "中位speedup", "最小", "最大", "目标GPU更慢"],
    [[r["from_gpu"].upper(), r["to_gpu"].upper(), r["kind"], r["operator"], r["models"], r["tp_cells"], fnum(r["common_shapes_sum"], 0), fnum(r["cell_speedup_p50_median"], 3)+"×", fnum(r["cell_speedup_p50_min"], 3)+"×", fnum(r["cell_speedup_p50_max"], 3)+"×", pct(r["weighted_fraction_to_gpu_slower"])] for r in cross_gpu]
))
sections.append("\n### C.7 Compute-only TP scaling 全表\n\n" + md_table(
    ["GPU", "类型", "Operator", "TP", "模型", "共同shape", "中位speedup", "最小", "最大", "中位效率", "慢于TP1"],
    [[r["gpu"].upper(), r["kind"], r["operator"], r["tp"], r["models"], fnum(r["common_shapes_sum"], 0), fnum(r["cell_compute_speedup_p50_median"], 3)+"×", fnum(r["cell_compute_speedup_p50_min"], 3)+"×", fnum(r["cell_compute_speedup_p50_max"], 3)+"×", pct(r["cell_parallel_efficiency_p50_median"]), pct(r["weighted_fraction_slower_than_tp1"])] for r in tp_scaling]
))


sections.append("\n## 附录 D：27 个 model×device compute 覆盖\n\n" + md_table(
    ["设备", "模型", "MLP", "Attention", "可用TP", "MLP max", "Batch max", "Prefill max", "KV max", "Backend", "默认KV4096实测"],
    [[r["device"].upper(), r["model"], bool_zh(r["mlp_exists"]), bool_zh(r["attention_exists"]), r["usable_compute_tp"], fnum(r["mlp_num_tokens_max"], 0), fnum(r["attention_batch_max"], 0), fnum(r["attention_prefill_max"], 0), fnum(r["attention_kv_max"], 0), r["attention_backends"], bool_zh(r["default_decode_kv_4096_observed"])] for r in coverage_matrix]
))


sections.append("\n## 附录 E：Network 文件质量、曲线与可达性\n\n### E.1 文件级质量\n\n" + md_table(
    ["路径", "设备", "类型", "行", "列", "唯一size", "范围", "重复key行", "高CV>20%", "标准schema"],
    [[r["source_path"], r["device"].upper(), r["profile_type"], fnum(r["rows"], 0), r["columns"], fnum(r["unique_sizes"], 0), f"{fnum(float(r['size_min_bytes'])/1024,0)} KiB–{fnum(float(r['size_max_bytes'])/1024/1024,3)} MiB" if r["size_min_bytes"] else "—", fnum(r["key_duplicate_rows"], 0), fnum(r["high_cv_rows_gt_20pct"], 0), bool_zh(r["is_standard_network_schema"])] for r in network_quality]
))
sections.append("\n### E.2 分组性能全表\n\nPayload BW 不是 NCCL busbw。\n\n" + md_table(
    ["设备", "拓扑", "Collective", "Workers", "dpn", "Size上限MiB", "最小/最大size时延ms", "BW P50", "BW P95", "CV P95", "高抖动", "候选跳变"],
    [[r["device"].upper(), r["topology_directory"], r["collective"], r["num_workers"], r["devices_per_node"], fnum(float(r["size_max_bytes"])/1024/1024,3), f"{fnum(r['latency_at_min_size_ms'],4)}/{fnum(r['latency_at_max_size_ms'],4)}", fnum(r["payload_bw_median_GBps"],3)+" GB/s", fnum(r["payload_bw_p95_GBps"],3)+" GB/s", pct(r["within_point_cv_p95"]), pct(r["high_cv_share_gt_20pct"]), r["candidate_jump_count"]] for r in network_groups]
))
sections.append("\n### E.3 当前 loader 的 network 可达性\n\n" + md_table(
    ["Network device", "节点设备", "AR文件", "SR文件", "AR过滤后TP", "不可达AR行", "Worker/dpn组合", "孤立attention"],
    [[r["network_device"], r["node_devices"], bool_zh(r["all_reduce_file_exists"]), bool_zh(r["send_recv_file_exists"]), r["all_reduce_rows_selected_by_tp"], fnum(r["all_reduce_rows_unreachable_by_current_filter"],0), r["all_reduce_worker_device_pairs"], bool_zh(r["unexpected_attention_csv"])] for r in network_reachability]
))
sections.append("\n### E.4 全部 284 个 network change-point 候选\n\n<details><summary>展开完整表格（按绝对时延变化比例降序）</summary>\n\n" + md_table(
    ["设备", "拓扑", "Collective", "Workers", "dpn", "前KiB", "后KiB", "前ms", "后ms", "时延变化", "绝对变化ms", "合成std", "BW变化", "类型"],
    [[r["device"].upper(), r["topology_directory"], r["collective"], r["num_workers"], r["devices_per_node"], fnum(float(r["prev_size_bytes"])/1024,3), fnum(float(r["size_bytes"])/1024,3), fnum(r["prev_latency_ms"],4), fnum(r["latency_ms"],4), pct(r["latency_rel_change"]), fnum(r["latency_abs_change_ms"],4), fnum(r["combined_adjacent_std_ms"],4), pct(r["bw_rel_change"]), r["transition_kind"]] for r in network_candidates_sorted]
) + "\n\n</details>")


sections.append("\n## 附录 F：Workload 全量摘要与兼容性\n\n### F.1 长度、相关性和到达分布\n\n" + md_table(
    ["Trace", "请求", "唯一长度对", "Prefill P50/P90/P99/max", "Decode P50/P90/P99/max", "Total P50/P90/P99/max", ">4K", "相关系数", "QPS", "间隔P50"],
    [[r["file"], fnum(r["rows"],0), fnum(r["unique_prefill_decode_pairs"],0), f"{fnum(r['prefill_p50'],0)}/{fnum(r['prefill_p90'],0)}/{fnum(r['prefill_p99'],0)}/{fnum(r['prefill_max'],0)}", f"{fnum(r['decode_p50'],0)}/{fnum(r['decode_p90'],0)}/{fnum(r['decode_p99'],0)}/{fnum(r['decode_max'],0)}", f"{fnum(r['total_p50'],0)}/{fnum(r['total_p90'],0)}/{fnum(r['total_p99'],0)}/{fnum(r['total_max'],0)}", pct(r["total_gt_4096_rate"]), fnum(r["prefill_decode_pearson"],3), fnum(r["arrival_rate_qps"],3), fnum(float(r["interarrival_p50"])*1000,3)+" ms" if r["interarrival_p50"] else "—"] for r in workloads]
))
sections.append("\n### F.2 Loader 兼容性\n\n" + md_table(
    ["路径", "行", "重复保留", "Length", "Replay", "Interval", "Total max", ">4096行", "Arrival单调"],
    [[r["path"], fnum(r["rows"],0), fnum(r["exact_duplicate_rows_retained_by_trace_loaders"],0), bool_zh(r["length_generator_compatible"]), bool_zh(r["replay_generator_compatible"]), bool_zh(r["interval_generator_compatible"]), fnum(r["total_tokens_max"],0), fnum(r["rows_over_default_max_tokens_4096"],0), bool_zh(r["arrived_at_monotonic"]) if r["arrived_at_monotonic"] else "—"] for r in trace_compatibility]
))


sections.append("\n## 附录 G：16 项数据契约问题原始证据\n\n" + md_table(
    ["ID", "严重度", "领域", "发现", "证据", "影响"],
    [[r["id"], r["severity"], r["area"], r["finding"], r["evidence"], r["impact"]] for r in findings]
))


sections.append("""
## 附录 H：NPU 采样与建模执行清单

### H.1 一条样本必须带的契约

| 层 | 必需字段 |
|---|---|
| 硬件 | NPU 型号、卡/节点拓扑、频率/功耗、固件、NUMA/主机 |
| 软件 | CANN、torch_npu、框架、算子库、编译器 commit、关键 flag |
| 图/kernel | graph hash、kernel ID、tiling ID、workspace、融合方案、stream 数 |
| Shape | 原始/对齐后维度、dtype、layout、batch、seq、KV、TP/EP/PP |
| 搬运 | H2D/D2D/片上 bytes、路径、是否与 compute 重叠 |
| 状态 | cold/warm、compile cache hit、独立进程、run/replicate、采集时间 |
| 标签 | compile、host launch、搬运、kernel、同步、端到端逐项时间与原始 repeats |

### H.2 推荐实验顺序

1. 以真实 workload 分布建立粗网格，同时保留安全边界点。
2. 在相邻点上计算绝对变化、相对变化、噪声标准化变化和制度标签变化。
3. 对候选边界补采 `x±1`、`x±tile`、2 的幂/对齐块两侧。
4. 每个 shape 分开 cold compile、warm steady-state 和多个独立进程。
5. 先训练 regime 分类器，再训练 regime 内回归；无法识别 regime 时报告置信度。
6. 运行时遇到 OOD/低置信度，拒绝静默外推，转为补采或保守 fallback。

### H.3 最低验收门槛

- Group holdout、连续区间 holdout、边界邻域 holdout、编译器/backend OOD 全部独立报告；
- MAE（μs/ms）、相对误差、P95/P99、边界误差和制度分类准确率同时给出；
- 端到端回放与 operator 级误差同时评估；
- 数据、代码、环境、模型和 lookup cache 全部内容寻址；
- 任何超出 profile 域的调用必须显式告警或失败，不允许叶节点常数悄悄饱和。
""")


sections.append("\n## 附录 I：本地证据与可重跑产物目录\n\n" + evidence_catalog())
sections.append("""

## 最终结论

Vidur 公开数据证明了一条有价值但需要精确定义的路线：**微基准 + 分算子学习 + 离散事件组合**可以显著降低端到端系统探索成本。它真正依赖的是“采样域内、制度稳定、数据契约正确”，而不是硬件时延天然光滑。

将这条路线迁移到昇腾 NPU 时，最关键的升级是把编译、tiling、kernel、workspace、搬运和缓存状态从隐藏扰动变成显式 regime；随后用边界感知采样、分 regime 模型和 OOD 拒绝机制保证可信度。这样，“shape 细微变化会抖动”不是不可学习的证据，反而成为应该识别和建模的结构信息。

本报告中的所有百分比、speedup 和 change-point 均为 current-main 公开数据的描述性统计。没有对应软件栈 manifest 或定向复测时，不应把它们解释为单一 GPU/NPU 微架构的因果结论。
""")


text = "\n".join(sections).strip() + "\n"
OUTPUT.write_text(text, encoding="utf-8")

summary = {
    "output": str(OUTPUT),
    "characters": len(text),
    "lines": len(text.splitlines()),
    "csv_files_covered": len(inventory),
    "compute_files": len(compute_files),
    "network_candidates_included": len(network_candidates_sorted),
    "evidence_files": sum(1 for folder in [ROOT / "main", ROOT / "compute_agent", ROOT / "network_workload_agent", ROOT / "contract_agent"] for path in folder.rglob("*") if path.is_file() and "__pycache__" not in path.parts),
    "used_compute_deep_appendix": compute_deep_path.exists(),
    "used_contract_deep_appendix": contract_deep_path.exists(),
    "used_network_deep_appendix": network_deep_path.exists(),
}
(HERE / "build_summary.json").write_text(json.dumps(summary, ensure_ascii=False, indent=2), encoding="utf-8")
print(json.dumps(summary, ensure_ascii=False, indent=2))

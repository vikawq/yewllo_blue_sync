# 附录：Vidur 数据资产与 current-main 代码契约深度审计

> 本附录面向逐文件复核、配置排障和后续昇腾迁移。审计的 current-main 固定为 commit `8383d2935bc62723a212090baa9f98ada206fc14`；论文时期只使用 2024-05-09 的开源发布准备提交 `6d98aa8f71696520acc603d87439e77cc78160a7` 作为代码/目录结构参照，不把二者混成同一快照。

## A.1 先读结论与证据边界

current-main 仓库共有 **53 个 CSV、1,436,810 行、262.56 MiB**。数据主体是 operator/collective 微基准，不是端到端请求记录。

审计支持的强结论：

- 对 current-main 已存在且过滤后非空的 model/device/TP/block/backend 切片，可以确定 learner 实际读取哪些列、怎样构造特征、怎样预生成 lookup，以及哪些数据永远不可达。
- 现有 40 个 compute 文件的模型维度与 current-main 模型配置一致；active prefill/decode target 没有 NaN。
- A40 all-reduce、CPU overhead、部分 model/device/TP、跨节点 all-reduce、预测域和 cache 存在可由代码及文件直接证明的契约断点。

本审计不支持的推论：

- 不能把 current-main 的 53 个 CSV 当成 MLSys 2024 论文提交时的数据快照。
- 不能仅凭仓库数据复现论文的 Chat-1M/BWB-4K 全部 workload；当前仓库并没有这些文件。
- 不能把 RF 在配置范围内能返回数值，解释为对未采样 shape、其他 backend、其他软件栈或其他硬件的可靠外推。

## A.2 论文时期与 current-main：必须分开阅读

| 边界 | commit | 时间/提交说明 | 本报告如何使用 |
|---|---|---|---|
| 代码参照 | `6d98aa8f71696520acc603d87439e77cc78160a7` | 2024-05-09，Prepare for open-source release (#6) | paper-era repository reference；不是论文逐实验数据的形式化归档 tag |
| 本次数据审计 | `8383d2935bc62723a212090baa9f98ada206fc14` | 2025-07-25，[Bugfix] Revert scheduler regression… (#65) | 53 CSV、current-main loader、配置和模型注册表 |

两个版本的数据目录和默认行为不同：

| 主题 | paper-era 参照 | current-main 审计对象 |
|---|---|---|
| Profiling 路径 | `data/profiling/{DEVICE}/{mlp,attention,all_reduce,send_recv}.csv` | compute 按 device/model 分层；network 按 topology 分层 |
| CPU overhead | A100/A40 各有平铺 `cpu_overheads.csv`；默认不跳过 | 仓库 0 个 CPU overhead CSV；`skip_cpu_overhead_modeling=True` |
| A40 all-reduce | tree 中存在 `data/profiling/a40/all_reduce.csv` | `network/a40_pairwise_nvlink/all_reduce.csv` 缺失 |
| RF 搜索网格 | estimators 500/750，depth 32，split 2/5/10 | estimators 250/500/750，depth 8/16/32，split 2/5/10 |
| 模型/数据 | 无 Llama-3 目录；模型配置还包括 GPT-3/Falcon | 加入 Llama-3 profiles；当前模型注册表与 paper-era 不同 |
| Workload | tree 中只有 Arxiv processed trace | Arxiv + Splitwise code/conversation；仍缺论文 Chat-1M/BWB 文件 |

Paper-era 参照提交的 tree 中只有以下 15 个 CSV（路径本身即可通过 `git ls-tree` 复核）：

```text
data/processed_traces/arxiv_summarization_stats_llama2_tokenizer_filtered_v2.csv
data/profiling/a100/{all_reduce,attention,cpu_overheads,mlp,send_recv}.csv
data/profiling/a40/{all_reduce,attention,cpu_overheads,mlp,send_recv}.csv
data/profiling/h100/{all_reduce,attention,mlp,send_recv}.csv
```

重要解释：loader 的许多核心过滤与特征构造从 paper-era 延续到了 current-main，但路径布局、数据集合、CPU 默认值和模型覆盖已变化。因此，论文给出的端到端精度不能自动为 current-main 每个新增文件和每个配置背书。

## A.3 证据索引

| 证据 ID | 版本 | 路径/命令 | 证明内容 |
|---|---|---|---|
| S01 | current | `vidur/config/config.py:428-464` | model/device/network_device 独立实例化 |
| S02 | current | `vidur/config/config.py:494-561` | 五类 CSV 路径、lookup 上限、KV 粒度、CPU 默认开关 |
| S03 | current | `vidur/config/config.py:590-606` | current RF 参数网格 |
| S04 | current | `vidur/config/model_config.py` | 9 个具体模型的维度与 no_tensor_parallel 声明 |
| S05 | current | `vidur/execution_time_predictor/sklearn_execution_time_predictor.py:87-201` | 路径展开、读取、exact dedup、四类 profile 过滤 |
| S06 | current | `.../sklearn_execution_time_predictor.py:203-242` | attention/network 派生特征 |
| S07 | current | `.../sklearn_execution_time_predictor.py:281-449` | 模型 cache、prediction cache、训练与 GridSearchCV |
| S08 | current | `.../sklearn_execution_time_predictor.py:451-579` | operation→feature→target 映射 |
| S09 | current | `.../sklearn_execution_time_predictor.py:588-723` | lookup grid 预生成 |
| S10 | current | `.../sklearn_execution_time_predictor.py:725-899` | KV 聚合、取整、dictionary 查询、CPU 置零 |
| S11 | current | `.../sklearn_execution_time_predictor.py:901-920` | cache hash 使用的 to_dict 字段 |
| S12 | current | `vidur/entities/batch.py:41-49` | 总 token 向上取整到 8 |
| S13 | current | `vidur/execution_time_predictor/base_execution_time_predictor.py` | 各 component 进入 ExecutionTime 的组合位置 |
| S14 | current | `vidur/request_generator/trace_replay_request_generator.py:19-92` | replay schema、缩放、截断与顺序 |
| S15 | current | `vidur/request_generator/trace_request_length_generator.py:17-100` | length schema、比例截断与 shuffle |
| S16 | current | `vidur/request_generator/trace_request_interval_generator.py:19-60` | arrival_time schema、时间过滤/floor/diff |
| S17 | paper-era | `6d98aa8f71696520acc603d87439e77cc78160a7:simulator/config/default.yml` | 旧路径、CPU 开关、旧 RF 网格 |
| S18 | paper-era | `6d98aa8f71696520acc603d87439e77cc78160a7:simulator/execution_time_predictor/sklearn_execution_time_predictor.py` | 旧 loader/特征构造 |
| S19 | paper-era | `git ls-tree -r 6d98aa8f71696520acc603d87439e77cc78160a7 -- data` | 旧数据树中 15 个 CSV 和配置目录 |
| S20 | audit | `contract_agent/csv_inventory.csv` | 53 文件逐项 schema/行数/重复/target/范围 |
| S21 | audit | `contract_agent/compute_coverage_matrix.csv` | 27 model-device 配置过滤重放 |
| S22 | audit | `contract_agent/network_reachability.csv` | 5 topology 的实际可达行 |
| S23 | audit | `contract_agent/trace_compatibility.csv` | 3 trace 与 3 loader 的 schema 兼容性 |
| S24 | audit | `contract_agent/findings.csv` | 16 项问题、证据与影响 |

## A.4 CSV 到模拟器的完整数据流

```mermaid
flowchart LR
  A["Replica / scheduler / predictor config"] --> B["展开 {DEVICE}/{MODEL}/{NETWORK_DEVICE}"]
  B --> C["pd.read_csv"]
  C --> D["完整行 drop_duplicates"]
  D --> E{"数据类"}
  E -->|MLP| F["模型维度 + TP 过滤"]
  E -->|Attention| G["模型维度 + block + TP 过滤"]
  E -->|All-reduce| H["workers=TP 且 dpn=TP"]
  E -->|Send/recv| I["dpn=1 或 2"]
  E -->|CPU| J["model + TP；默认跳过"]
  F --> K["operator median / num_tokens"]
  G --> L["prefill/decode/KV-save 派生特征"]
  H --> M["bytes/(hidden*2)"]
  I --> M
  J --> N["batch_size→CPU median/mean"]
  K --> O["每个 target 单独 GridSearchCV + RF"]
  L --> O
  M --> O
  N --> O
  O --> P["预生成稠密 prediction dictionary"]
  P --> Q["运行时 token→8；KV→64；attention 聚合"]
  Q --> R["直接 dictionary key 查询"]
  R --> S["各层/通信/CPU 组合成 ExecutionTime"]
```

这个流程包含四个容易误读的事实：

1. CSV 每行的 `median` 是 profiler 内部重复的中位数；loader 不再对相同 shape 的多行取 median。
2. learner 并非输入完整 batch：它先把 batch 压缩为一两个统计量，再查表。
3. RF 可以对配置 grid 返回数值，不代表该 grid 被 profile 数据覆盖；RF 超出训练范围只会落到边界叶常数。
4. 实际 key 超出预生成 dictionary 时不会动态回归或 profile，而是直接 `KeyError`。

## A.5 各类 loader 的精确数据契约

### A.5.1 MLP/投影/Norm/RoPE/Add

路径：`data/profiling/compute/{DEVICE}/{MODEL}/mlp.csv`。

过滤必须同时满足：`n_head`、`n_kv_head`、`n_embd`、`n_expanded_embd`、`use_gated_mlp`、`vocab_size` 等于模型配置，且 `num_tensor_parallel_workers == TP`。

| 模型名 | 特征 | target | schema 行为 |
|---|---|---|---|
| attn_pre_proj | num_tokens | time_stats.attn_pre_proj.median | required |
| attn_post_proj | num_tokens | time_stats.attn_post_proj.median | required |
| mlp_up_proj | num_tokens | time_stats.mlp_up_proj.median | required |
| mlp_down_proj | num_tokens | time_stats.mlp_down_proj.median | required |
| mlp_act | num_tokens | time_stats.mlp_act.median | required |
| attn_rope | num_tokens | time_stats.attn_rope.median | required |
| input_layernorm | num_tokens | time_stats.input_layernorm.median | 缺列/NaN→0 |
| post_attention_layernorm | num_tokens | time_stats.post_attention_layernorm.median | 缺列/NaN→0 |
| add | num_tokens | time_stats.add.median | 缺列/NaN→0 |

`time_stats.emb.*` 与所有 min/max/mean/std 不进入模型；运行时这些 component 使用向上取整到 8 的 batch 总 token。

### A.5.2 Attention

路径：`data/profiling/compute/{DEVICE}/{MODEL}/attention.csv`。过滤键为 `n_embd/n_q_head/n_kv_head/block_size/TP`。

| 模型 | 训练子集 | 特征 | target | 行为 |
|---|---|---|---|---|
| KV-cache save | 全部行 | max(prefill_chunk_size,batch_size) | attn_kv_cache_save.median | 旧 schema 缺列→0 |
| Prefill | prefill_chunk_size != 0 | kv_cache_size, prefill_chunk_size² | attn_prefill.median | active target 必须非空 |
| Decode | prefill_chunk_size == 0 | batch_size, kv_cache_size | attn_decode.median | active target 必须非空 |

`attention_backend`、`max_model_len`、CSV 自带 `is_prefill` 不参与过滤；代码以 `prefill_chunk_size==0` 重建 decode 标志。当前每个文件只有一种 backend，所以尚未混合，但 contract 无法防止未来误混。Input/output reshape 虽被测量，也没有进入最终 ExecutionTime。

### A.5.3 All-reduce / Send-recv

| 类型 | 过滤 | 特征 | target | 触发条件 |
|---|---|---|---|---|
| All-reduce | num_workers==TP；devices_per_node==TP；collective=all_reduce | size/(embedding_dim*2) | all_reduce.median | TP>1 才训练；另加 NCCL launch/skew |
| Send/recv | collective=send_recv；单节点 dpn=2，多节点 dpn=1 | size/(embedding_dim*2) | send_recv.median | PP>1 才训练 |

常数 2 固定假设每个 hidden element 占 2 B；dtype 并不是 CSV filter 或特征。A100 DGX 的跨节点曲线正是因为 all-reduce 强制 `dpn==TP` 而不可达。

### A.5.4 CPU overhead

预期路径：`data/profiling/cpu_overhead/{NETWORK_DEVICE}/{MODEL}/cpu_overheads.csv`；过滤 `model_name` 与 `tensor_parallel_degree`，以 `batch_size` 预测 schedule、sampler、prepare-input、process-output、Ray communication。current-main 仓库没有任何该类文件，默认开关又是 skip，因此五项均为 0。

### A.5.5 Trace loaders

| Loader | required columns | 转换 | current 数据兼容 |
|---|---|---|---|
| Length | num_prefill_tokens,num_decode_tokens | 缩放→int→按比例截断→至少1→seed shuffle | 三文件 |
| Replay | arrived_at,num_prefill_tokens,num_decode_tokens | 缩放→int→至少1→超长只扣 prefill→arrival 缩放；不排序 | Splitwise code/conv |
| Interval | arrival_time(datetime) | 时间窗口严格开区间→floor 到整秒→diff；不排序 | 0 文件 |

## A.6 Lookup、取整、OOD 与 cache

| 参数/规则 | current default |
|---|---|
| block_size | 16 |
| prediction_max_tokens_per_request | 4096 |
| prediction_max_prefill_chunk_size | 4096 |
| prediction_max_batch_size | 128 |
| kv_cache_prediction_granularity | 64 |
| skip_cpu_overhead_modeling | True |
| compute_total_tokens_rounding | ceil to multiple of 8 |
| decode_and_prefill_kv_rounding | ceil to multiple of 64 |

运行时 key：

- 主 compute/通信 component：`ceil(total_tokens/8)*8`。
- KV-save：`sum(batch.num_tokens)`，不按 8 取整。
- Decode：decode request 数作为 batch；历史 KV 先求平均、转 int，再向上取整到 64。
- Prefill：每个 request 的历史 KV 分别向上取整到 64 后求和；多个 chunk 使用 `round(sqrt(sum(p_i²)))²`。
- GQA 多请求 attention：在 RF lookup 之外再乘默认 1.1；不是训练特征。

预测域风险：旧 attention 的实测 KV 最大为 4032，默认却生成 KV=4096；Orca 的一维 token lookup 可到 4096×128=524,288，而旧 MLP 最大只到 4096。前者是边界外常数预测，后者跨两个数量级，均不是可靠插值。

Cache 分两层：

1. estimator cache 的训练 hash 含 dataframe JSON hash，能感知数据内容。
2. prediction dictionary cache 用 fitted estimator 的字符串和不完整 `to_dict()`；字符串通常只反映超参数，不含树节点/训练集，`to_dict()` 又漏掉 `attention_input_file` 与 KV granularity。CSV 同路径替换、attention 文件切换或粒度变化后，存在复用旧 lookup 的实质风险。

## A.7 53 个 CSV 的逐文件索引

ID 按 `csv_inventory.csv` 的路径字典序稳定生成。`key-extra` 表示 exact dedup 后，按实际 learner 特征/过滤键仍重复的额外行；它不是完整行重复数。

### A.7.1 Processed traces

| ID | 文件 | raw rows | cols | exact dup | key-extra | 范围/配置 | schema/消费备注 |
|---|---|---|---|---|---|---|---|
| F001 | `data/processed_traces/arxiv_summarization_stats_llama2_tokenizer_filtered_v2.csv` | 28,257 | 4 | 469 | 0 | num_decode_tokens=[5.0, 4056.0], num_prefill_tokens=[1.0, 4054.0] | length_compatible=True;replay_compatible=False;interval_compatible=False |
| F002 | `data/processed_traces/splitwise_code.csv` | 8,819 | 3 | 0 | 0 | arrived_at=[0.0, 3435.948056], num_decode_tokens=[6.0, 1899.0], num_prefill_tokens=[3.0, 7437.0] | length_compatible=True;replay_compatible=True;interval_compatible=False;arrival_monotonic=True |
| F003 | `data/processed_traces/splitwise_conv.csv` | 19,366 | 3 | 0 | 0 | arrived_at=[0.0, 3501.721937], num_decode_tokens=[7.0, 1000.0], num_prefill_tokens=[2.0, 14050.0] | length_compatible=True;replay_compatible=True;interval_compatible=False;arrival_monotonic=True |

### A.7.2 Compute MLP

| ID | 文件 | raw rows | cols | exact dup | key-extra | 范围/配置 | schema/消费备注 |
|---|---|---|---|---|---|---|---|
| F005 | `data/profiling/compute/a100/Qwen/Qwen-72B/mlp.csv` | 1,044 | 58 | 0 | 8 | tokens=[1.0, 4096.0]; TP=[1, 2, 4, 8] | required schema OK |
| F007 | `data/profiling/compute/a100/codellama/CodeLlama-34b-Instruct-hf/mlp.csv` | 1,044 | 58 | 0 | 8 | tokens=[1.0, 4096.0]; TP=[1, 2, 4, 8] | required schema OK |
| F009 | `data/profiling/compute/a100/internlm/internlm-20b/mlp.csv` | 1,044 | 58 | 0 | 8 | tokens=[1.0, 4096.0]; TP=[1, 2, 4, 8] | required schema OK |
| F011 | `data/profiling/compute/a100/meta-llama/Llama-2-70b-hf/mlp.csv` | 1,044 | 58 | 0 | 8 | tokens=[1.0, 4096.0]; TP=[1, 2, 4, 8] | required schema OK |
| F013 | `data/profiling/compute/a100/meta-llama/Llama-2-7b-hf/mlp.csv` | 1,044 | 58 | 0 | 8 | tokens=[1.0, 4096.0]; TP=[1, 2, 4, 8] | required schema OK |
| F015 | `data/profiling/compute/a100/meta-llama/Meta-Llama-3-70B/mlp.csv` | 1,824 | 58 | 0 | 20 | tokens=[1.0, 32768.0]; TP=[1, 2, 4, 8] | required schema OK |
| F017 | `data/profiling/compute/a100/meta-llama/Meta-Llama-3-8B/mlp.csv` | 1,824 | 58 | 0 | 20 | tokens=[1.0, 32768.0]; TP=[1, 2, 4, 8] | required schema OK |
| F019 | `data/profiling/compute/a100/microsoft/phi-2/mlp.csv` | 261 | 53 | 0 | 2 | tokens=[1.0, 4096.0]; TP=[1] | 缺列→0: post_attention_layernorm |
| F021 | `data/profiling/compute/a40/Qwen/Qwen-72B/mlp.csv` | 1,044 | 58 | 0 | 8 | tokens=[1.0, 4096.0]; TP=[1, 2, 4, 8] | required schema OK |
| F023 | `data/profiling/compute/a40/codellama/CodeLlama-34b-Instruct-hf/mlp.csv` | 1,044 | 58 | 0 | 8 | tokens=[1.0, 4096.0]; TP=[1, 2, 4, 8] | required schema OK |
| F025 | `data/profiling/compute/a40/internlm/internlm-20b/mlp.csv` | 1,044 | 58 | 0 | 8 | tokens=[1.0, 4096.0]; TP=[1, 2, 4, 8] | required schema OK |
| F027 | `data/profiling/compute/a40/meta-llama/Llama-2-70b-hf/mlp.csv` | 1,044 | 58 | 0 | 8 | tokens=[1.0, 4096.0]; TP=[1, 2, 4, 8] | required schema OK |
| F029 | `data/profiling/compute/a40/meta-llama/Llama-2-7b-hf/mlp.csv` | 1,044 | 58 | 0 | 8 | tokens=[1.0, 4096.0]; TP=[1, 2, 4, 8] | required schema OK |
| F031 | `data/profiling/compute/a40/microsoft/phi-2/mlp.csv` | 261 | 53 | 0 | 2 | tokens=[1.0, 4096.0]; TP=[1] | 缺列→0: post_attention_layernorm |
| F033 | `data/profiling/compute/h100/Qwen/Qwen-72B/mlp.csv` | 1,044 | 58 | 0 | 8 | tokens=[1.0, 4096.0]; TP=[1, 2, 4, 8] | required schema OK |
| F035 | `data/profiling/compute/h100/codellama/CodeLlama-34b-Instruct-hf/mlp.csv` | 1,044 | 58 | 0 | 8 | tokens=[1.0, 4096.0]; TP=[1, 2, 4, 8] | required schema OK |
| F037 | `data/profiling/compute/h100/internlm/internlm-20b/mlp.csv` | 1,044 | 58 | 0 | 8 | tokens=[1.0, 4096.0]; TP=[1, 2, 4, 8] | required schema OK |
| F039 | `data/profiling/compute/h100/meta-llama/Llama-2-70b-hf/mlp.csv` | 1,044 | 58 | 0 | 8 | tokens=[1.0, 4096.0]; TP=[1, 2, 4, 8] | required schema OK |
| F041 | `data/profiling/compute/h100/meta-llama/Llama-2-7b-hf/mlp.csv` | 1,044 | 58 | 0 | 8 | tokens=[1.0, 4096.0]; TP=[1, 2, 4, 8] | required schema OK |
| F043 | `data/profiling/compute/h100/microsoft/phi-2/mlp.csv` | 261 | 53 | 0 | 2 | tokens=[1.0, 4096.0]; TP=[1] | 缺列→0: post_attention_layernorm |

### A.7.3 Compute attention

| ID | 文件 | raw rows | cols | exact dup | key-extra | 范围/配置 | schema/消费备注 |
|---|---|---|---|---|---|---|---|
| F004 | `data/profiling/compute/a100/Qwen/Qwen-72B/attention.csv` | 58,632 | 31 | 77 | 1283 | B=[1.0, 128.0]; P=[0.0, 4096.0]; KV=[0.0, 4032.0]; TP=[1, 2, 4, 8]; block=[16]; backend=['AttentionBackend.FLASH_ATTENTION'] | 缺列→0: attn_kv_cache_save; active target=0: 16 |
| F006 | `data/profiling/compute/a100/codellama/CodeLlama-34b-Instruct-hf/attention.csv` | 58,632 | 31 | 171 | 1189 | B=[1.0, 128.0]; P=[0.0, 4096.0]; KV=[0.0, 4032.0]; TP=[1, 2, 4, 8]; block=[16]; backend=['AttentionBackend.FLASH_ATTENTION'] | 缺列→0: attn_kv_cache_save |
| F008 | `data/profiling/compute/a100/internlm/internlm-20b/attention.csv` | 58,632 | 31 | 105 | 1255 | B=[1.0, 128.0]; P=[0.0, 4096.0]; KV=[0.0, 4032.0]; TP=[1, 2, 4, 8]; block=[16]; backend=['AttentionBackend.FLASH_ATTENTION'] | 缺列→0: attn_kv_cache_save |
| F010 | `data/profiling/compute/a100/meta-llama/Llama-2-70b-hf/attention.csv` | 58,632 | 31 | 176 | 1184 | B=[1.0, 128.0]; P=[0.0, 4096.0]; KV=[0.0, 4032.0]; TP=[1, 2, 4, 8]; block=[16]; backend=['AttentionBackend.FLASH_ATTENTION'] | 缺列→0: attn_kv_cache_save |
| F012 | `data/profiling/compute/a100/meta-llama/Llama-2-7b-hf/attention.csv` | 58,632 | 31 | 142 | 1218 | B=[1.0, 128.0]; P=[0.0, 4096.0]; KV=[0.0, 4032.0]; TP=[1, 2, 4, 8]; block=[16]; backend=['AttentionBackend.FLASH_ATTENTION'] | 缺列→0: attn_kv_cache_save |
| F014 | `data/profiling/compute/a100/meta-llama/Meta-Llama-3-70B/attention.csv` | 99,200 | 36 | 212 | 2805 | B=[1.0, 512.0]; P=[0.0, 16384.0]; KV=[0.0, 16320.0]; TP=[1, 2, 4, 8]; block=[16]; backend=['AttentionBackend.FLASHINFER'] | required schema OK |
| F016 | `data/profiling/compute/a100/meta-llama/Meta-Llama-3-8B/attention.csv` | 42,587 | 36 | 63 | 1360 | B=[1.0, 512.0]; P=[0.0, 16384.0]; KV=[0.0, 16320.0]; TP=[1, 4]; block=[16]; backend=['AttentionBackend.FLASHINFER'] | required schema OK |
| F018 | `data/profiling/compute/a100/microsoft/phi-2/attention.csv` | 58,632 | 31 | 207 | 1153 | B=[1.0, 128.0]; P=[0.0, 4096.0]; KV=[0.0, 4032.0]; TP=[1, 2, 4, 8]; block=[16]; backend=['AttentionBackend.FLASH_ATTENTION'] | 缺列→0: attn_kv_cache_save |
| F020 | `data/profiling/compute/a40/Qwen/Qwen-72B/attention.csv` | 58,632 | 31 | 25 | 1335 | B=[1.0, 128.0]; P=[0.0, 4096.0]; KV=[0.0, 4032.0]; TP=[1, 2, 4, 8]; block=[16]; backend=['AttentionBackend.FLASH_ATTENTION'] | 缺列→0: attn_kv_cache_save |
| F022 | `data/profiling/compute/a40/codellama/CodeLlama-34b-Instruct-hf/attention.csv` | 58,632 | 31 | 88 | 1272 | B=[1.0, 128.0]; P=[0.0, 4096.0]; KV=[0.0, 4032.0]; TP=[1, 2, 4, 8]; block=[16]; backend=['AttentionBackend.FLASH_ATTENTION'] | 缺列→0: attn_kv_cache_save |
| F024 | `data/profiling/compute/a40/internlm/internlm-20b/attention.csv` | 58,632 | 31 | 57 | 1303 | B=[1.0, 128.0]; P=[0.0, 4096.0]; KV=[0.0, 4032.0]; TP=[1, 2, 4, 8]; block=[16]; backend=['AttentionBackend.FLASH_ATTENTION'] | 缺列→0: attn_kv_cache_save |
| F026 | `data/profiling/compute/a40/meta-llama/Llama-2-70b-hf/attention.csv` | 58,632 | 31 | 67 | 1293 | B=[1.0, 128.0]; P=[0.0, 4096.0]; KV=[0.0, 4032.0]; TP=[1, 2, 4, 8]; block=[16]; backend=['AttentionBackend.FLASH_ATTENTION'] | 缺列→0: attn_kv_cache_save |
| F028 | `data/profiling/compute/a40/meta-llama/Llama-2-7b-hf/attention.csv` | 58,632 | 31 | 59 | 1301 | B=[1.0, 128.0]; P=[0.0, 4096.0]; KV=[0.0, 4032.0]; TP=[1, 2, 4, 8]; block=[16]; backend=['AttentionBackend.FLASH_ATTENTION'] | 缺列→0: attn_kv_cache_save |
| F030 | `data/profiling/compute/a40/microsoft/phi-2/attention.csv` | 58,632 | 31 | 109 | 1251 | B=[1.0, 128.0]; P=[0.0, 4096.0]; KV=[0.0, 4032.0]; TP=[1, 2, 4, 8]; block=[16]; backend=['AttentionBackend.FLASH_ATTENTION'] | 缺列→0: attn_kv_cache_save |
| F032 | `data/profiling/compute/h100/Qwen/Qwen-72B/attention.csv` | 58,632 | 31 | 139 | 1221 | B=[1.0, 128.0]; P=[0.0, 4096.0]; KV=[0.0, 4032.0]; TP=[1, 2, 4, 8]; block=[16]; backend=['AttentionBackend.FLASH_ATTENTION'] | 缺列→0: attn_kv_cache_save |
| F034 | `data/profiling/compute/h100/codellama/CodeLlama-34b-Instruct-hf/attention.csv` | 58,632 | 31 | 352 | 1008 | B=[1.0, 128.0]; P=[0.0, 4096.0]; KV=[0.0, 4032.0]; TP=[1, 2, 4, 8]; block=[16]; backend=['AttentionBackend.FLASH_ATTENTION'] | 缺列→0: attn_kv_cache_save |
| F036 | `data/profiling/compute/h100/internlm/internlm-20b/attention.csv` | 58,632 | 31 | 194 | 1166 | B=[1.0, 128.0]; P=[0.0, 4096.0]; KV=[0.0, 4032.0]; TP=[1, 2, 4, 8]; block=[16]; backend=['AttentionBackend.FLASH_ATTENTION'] | 缺列→0: attn_kv_cache_save |
| F038 | `data/profiling/compute/h100/meta-llama/Llama-2-70b-hf/attention.csv` | 58,632 | 31 | 383 | 977 | B=[1.0, 128.0]; P=[0.0, 4096.0]; KV=[0.0, 4032.0]; TP=[1, 2, 4, 8]; block=[16]; backend=['AttentionBackend.FLASH_ATTENTION'] | 缺列→0: attn_kv_cache_save |
| F040 | `data/profiling/compute/h100/meta-llama/Llama-2-7b-hf/attention.csv` | 58,632 | 31 | 209 | 1151 | B=[1.0, 128.0]; P=[0.0, 4096.0]; KV=[0.0, 4032.0]; TP=[1, 2, 4, 8]; block=[16]; backend=['AttentionBackend.FLASH_ATTENTION'] | 缺列→0: attn_kv_cache_save |
| F042 | `data/profiling/compute/h100/microsoft/phi-2/attention.csv` | 58,632 | 31 | 273 | 1087 | B=[1.0, 128.0]; P=[0.0, 4096.0]; KV=[0.0, 4032.0]; TP=[1, 2, 4, 8]; block=[16]; backend=['AttentionBackend.FLASH_ATTENTION'] | 缺列→0: attn_kv_cache_save |

### A.7.4 Network all-reduce

| ID | 文件 | raw rows | cols | exact dup | key-extra | 范围/配置 | schema/消费备注 |
|---|---|---|---|---|---|---|---|
| F044 | `data/profiling/network/a100_dgx/all_reduce.csv` | 6,958 | 12 | 0 | 7 | bytes=[2048.0, 67108864.0]; (workers,dpn)=[[2, 1], [2, 2], [4, 2], [4, 4], [8, 4], [8, 8], [16, 8]] | required schema OK |
| F046 | `data/profiling/network/a100_pairwise_nvlink/all_reduce.csv` | 4,496 | 12 | 0 | 2 | bytes=[2048.0, 536373250.0]; (workers,dpn)=[[2, 2], [4, 4]] | required schema OK |
| F050 | `data/profiling/network/h100_dgx/all_reduce.csv` | 2,982 | 12 | 0 | 3 | bytes=[2048.0, 67108864.0]; (workers,dpn)=[[2, 2], [4, 4], [8, 8]] | required schema OK |
| F052 | `data/profiling/network/h100_pairwise_nvlink/all_reduce.csv` | 1,988 | 12 | 0 | 2 | bytes=[2048.0, 67108864.0]; (workers,dpn)=[[2, 2], [4, 4]] | required schema OK |

### A.7.5 Network send/recv

| ID | 文件 | raw rows | cols | exact dup | key-extra | 范围/配置 | schema/消费备注 |
|---|---|---|---|---|---|---|---|
| F045 | `data/profiling/network/a100_dgx/send_recv.csv` | 1,988 | 12 | 0 | 2 | bytes=[2048.0, 67108864.0]; dpn=[1, 2] | required schema OK |
| F047 | `data/profiling/network/a100_pairwise_nvlink/send_recv.csv` | 1,988 | 12 | 0 | 2 | bytes=[2048.0, 67108864.0]; dpn=[1, 2] | required schema OK |
| F049 | `data/profiling/network/a40_pairwise_nvlink/send_recv.csv` | 1,988 | 12 | 0 | 2 | bytes=[2048.0, 67108864.0]; dpn=[1, 2] | required schema OK |
| F051 | `data/profiling/network/h100_dgx/send_recv.csv` | 1,988 | 12 | 0 | 2 | bytes=[2048.0, 67108864.0]; dpn=[1, 2] | required schema OK |
| F053 | `data/profiling/network/h100_pairwise_nvlink/send_recv.csv` | 1,988 | 12 | 0 | 2 | bytes=[2048.0, 67108864.0]; dpn=[1, 2] | required schema OK |

### A.7.6 孤立的 A40 attention

| ID | 文件 | raw rows | cols | exact dup | key-extra | 范围/配置 | schema/消费备注 |
|---|---|---|---|---|---|---|---|
| F048 | `data/profiling/network/a40_pairwise_nvlink/attention.csv` | 136,750 | 50 | 479 | 0 | — | current-main 无消费者 |

逐文件合计校验：

| category | files | rows | exact dup | key-extra | active zeros |
|---|---|---|---|---|---|
| processed_trace | 3 | 56,442 | 469 | 0 | 0 |
| compute_attention | 20 | 1,197,163 | 3,108 | 25,812 | 16 |
| compute_mlp | 20 | 20,091 | 0 | 166 | 0 |
| network_all_reduce | 4 | 16,424 | 0 | 14 | 0 |
| network_send_recv | 5 | 9,940 | 0 | 10 | 0 |
| orphan_network_attention | 1 | 136,750 | 479 | 0 | 0 |

## A.8 27 个 model-device 配置覆盖索引

`usable TP` 是按 current loader 同时过滤 MLP 与 attention 后的交集；它还没有叠加 network 文件可用性。

| ID | device | model | MLP | Attn | MLP rows/TP | Attn rows/TP | usable TP | 观测上限 | backend | 结论 |
|---|---|---|---|---|---|---|---|---|---|---|
| C001 | a100 | `Qwen/Qwen-72B` | Y | Y | `{"1":261,"2":261,"4":261,"8":261,"16":0}` | `{"1":14653,"2":14653,"4":14639,"8":14610,"16":0}` | [1, 2, 4, 8] | MLP≤4096; B≤128; P≤4096; KV≤4032 | ["AttentionBackend.FLASH_ATTENTION"] | compute slice 可用 |
| C002 | a100 | `codellama/CodeLlama-34b-Instruct-hf` | Y | Y | `{"1":261,"2":261,"4":261,"8":261,"16":0}` | `{"1":14652,"2":14628,"4":14600,"8":14581,"16":0}` | [1, 2, 4, 8] | MLP≤4096; B≤128; P≤4096; KV≤4032 | ["AttentionBackend.FLASH_ATTENTION"] | compute slice 可用 |
| C003 | a100 | `internlm/internlm-20b` | Y | Y | `{"1":261,"2":261,"4":261,"8":261,"16":0}` | `{"1":14651,"2":14648,"4":14631,"8":14597,"16":0}` | [1, 2, 4, 8] | MLP≤4096; B≤128; P≤4096; KV≤4032 | ["AttentionBackend.FLASH_ATTENTION"] | compute slice 可用 |
| C004 | a100 | `internlm/internlm2-20b` | N | N | `{}` | `{}` | [] | MLP≤—; B≤—; P≤—; KV≤— | [] | 缺两个 compute 文件 |
| C005 | a100 | `meta-llama/Llama-2-70b-hf` | Y | Y | `{"1":261,"2":261,"4":261,"8":261,"16":0}` | `{"1":14648,"2":14621,"4":14607,"8":14580,"16":0}` | [1, 2, 4, 8] | MLP≤4096; B≤128; P≤4096; KV≤4032 | ["AttentionBackend.FLASH_ATTENTION"] | compute slice 可用 |
| C006 | a100 | `meta-llama/Llama-2-7b-hf` | Y | Y | `{"1":261,"2":261,"4":261,"8":261,"16":0}` | `{"1":14650,"2":14639,"4":14612,"8":14589,"16":0}` | [1, 2, 4, 8] | MLP≤4096; B≤128; P≤4096; KV≤4032 | ["AttentionBackend.FLASH_ATTENTION"] | compute slice 可用 |
| C007 | a100 | `meta-llama/Meta-Llama-3-70B` | Y | Y | `{"1":456,"2":456,"4":456,"8":456,"16":0}` | `{"1":23576,"2":24654,"4":25393,"8":25365,"16":0}` | [1, 2, 4, 8] | MLP≤32768; B≤512; P≤16384; KV≤16320 | ["AttentionBackend.FLASHINFER"] | compute slice 可用 |
| C008 | a100 | `meta-llama/Meta-Llama-3-8B` | Y | Y | `{"1":456,"2":456,"4":456,"8":456,"16":0}` | `{"1":18601,"2":0,"4":23923,"8":0,"16":0}` | [1, 4] | MLP≤32768; B≤512; P≤16384; KV≤16320 | ["AttentionBackend.FLASHINFER"] | attention 仅 TP1/4 |
| C009 | a100 | `microsoft/phi-2` | Y | Y | `{"1":261,"2":0,"4":0,"8":0,"16":0}` | `{"1":14644,"2":14618,"4":14593,"8":14570,"16":0}` | [1] | MLP≤4096; B≤128; P≤4096; KV≤4032 | ["AttentionBackend.FLASH_ATTENTION"] | 模型声明 no_tensor_parallel；实际 TP1 |
| C010 | a40 | `Qwen/Qwen-72B` | Y | Y | `{"1":261,"2":261,"4":261,"8":261,"16":0}` | `{"1":14658,"2":14655,"4":14650,"8":14644,"16":0}` | [1, 2, 4, 8] | MLP≤4096; B≤128; P≤4096; KV≤4032 | ["AttentionBackend.FLASH_ATTENTION"] | compute slice 可用 |
| C011 | a40 | `codellama/CodeLlama-34b-Instruct-hf` | Y | Y | `{"1":261,"2":261,"4":261,"8":261,"16":0}` | `{"1":14654,"2":14640,"4":14630,"8":14620,"16":0}` | [1, 2, 4, 8] | MLP≤4096; B≤128; P≤4096; KV≤4032 | ["AttentionBackend.FLASH_ATTENTION"] | compute slice 可用 |
| C012 | a40 | `internlm/internlm-20b` | Y | Y | `{"1":261,"2":261,"4":261,"8":261,"16":0}` | `{"1":14655,"2":14650,"4":14643,"8":14627,"16":0}` | [1, 2, 4, 8] | MLP≤4096; B≤128; P≤4096; KV≤4032 | ["AttentionBackend.FLASH_ATTENTION"] | compute slice 可用 |
| C013 | a40 | `internlm/internlm2-20b` | N | N | `{}` | `{}` | [] | MLP≤—; B≤—; P≤—; KV≤— | [] | 缺两个 compute 文件 |
| C014 | a40 | `meta-llama/Llama-2-70b-hf` | Y | Y | `{"1":261,"2":261,"4":261,"8":261,"16":0}` | `{"1":14655,"2":14648,"4":14636,"8":14626,"16":0}` | [1, 2, 4, 8] | MLP≤4096; B≤128; P≤4096; KV≤4032 | ["AttentionBackend.FLASH_ATTENTION"] | compute slice 可用 |
| C015 | a40 | `meta-llama/Llama-2-7b-hf` | Y | Y | `{"1":261,"2":261,"4":261,"8":261,"16":0}` | `{"1":14653,"2":14651,"4":14645,"8":14624,"16":0}` | [1, 2, 4, 8] | MLP≤4096; B≤128; P≤4096; KV≤4032 | ["AttentionBackend.FLASH_ATTENTION"] | compute slice 可用 |
| C016 | a40 | `meta-llama/Meta-Llama-3-70B` | N | N | `{}` | `{}` | [] | MLP≤—; B≤—; P≤—; KV≤— | [] | 缺两个 compute 文件 |
| C017 | a40 | `meta-llama/Meta-Llama-3-8B` | N | N | `{}` | `{}` | [] | MLP≤—; B≤—; P≤—; KV≤— | [] | 缺两个 compute 文件 |
| C018 | a40 | `microsoft/phi-2` | Y | Y | `{"1":261,"2":0,"4":0,"8":0,"16":0}` | `{"1":14650,"2":14639,"4":14631,"8":14603,"16":0}` | [1] | MLP≤4096; B≤128; P≤4096; KV≤4032 | ["AttentionBackend.FLASH_ATTENTION"] | 模型声明 no_tensor_parallel；实际 TP1 |
| C019 | h100 | `Qwen/Qwen-72B` | Y | Y | `{"1":261,"2":261,"4":261,"8":261,"16":0}` | `{"1":14649,"2":14638,"4":14628,"8":14578,"16":0}` | [1, 2, 4, 8] | MLP≤4096; B≤128; P≤4096; KV≤4032 | ["AttentionBackend.FLASH_ATTENTION"] | compute slice 可用 |
| C020 | h100 | `codellama/CodeLlama-34b-Instruct-hf` | Y | Y | `{"1":261,"2":261,"4":261,"8":261,"16":0}` | `{"1":14607,"2":14580,"4":14559,"8":14534,"16":0}` | [1, 2, 4, 8] | MLP≤4096; B≤128; P≤4096; KV≤4032 | ["AttentionBackend.FLASH_ATTENTION"] | compute slice 可用 |
| C021 | h100 | `internlm/internlm-20b` | Y | Y | `{"1":261,"2":261,"4":261,"8":261,"16":0}` | `{"1":14643,"2":14635,"4":14596,"8":14564,"16":0}` | [1, 2, 4, 8] | MLP≤4096; B≤128; P≤4096; KV≤4032 | ["AttentionBackend.FLASH_ATTENTION"] | compute slice 可用 |
| C022 | h100 | `internlm/internlm2-20b` | N | N | `{}` | `{}` | [] | MLP≤—; B≤—; P≤—; KV≤— | [] | 缺两个 compute 文件 |
| C023 | h100 | `meta-llama/Llama-2-70b-hf` | Y | Y | `{"1":261,"2":261,"4":261,"8":261,"16":0}` | `{"1":14600,"2":14573,"4":14548,"8":14528,"16":0}` | [1, 2, 4, 8] | MLP≤4096; B≤128; P≤4096; KV≤4032 | ["AttentionBackend.FLASH_ATTENTION"] | compute slice 可用 |
| C024 | h100 | `meta-llama/Llama-2-7b-hf` | Y | Y | `{"1":261,"2":261,"4":261,"8":261,"16":0}` | `{"1":14643,"2":14629,"4":14580,"8":14571,"16":0}` | [1, 2, 4, 8] | MLP≤4096; B≤128; P≤4096; KV≤4032 | ["AttentionBackend.FLASH_ATTENTION"] | compute slice 可用 |
| C025 | h100 | `meta-llama/Meta-Llama-3-70B` | N | N | `{}` | `{}` | [] | MLP≤—; B≤—; P≤—; KV≤— | [] | 缺两个 compute 文件 |
| C026 | h100 | `meta-llama/Meta-Llama-3-8B` | N | N | `{}` | `{}` | [] | MLP≤—; B≤—; P≤—; KV≤— | [] | 缺两个 compute 文件 |
| C027 | h100 | `microsoft/phi-2` | Y | Y | `{"1":261,"2":0,"4":0,"8":0,"16":0}` | `{"1":14630,"2":14599,"4":14574,"8":14556,"16":0}` | [1] | MLP≤4096; B≤128; P≤4096; KV≤4032 | ["AttentionBackend.FLASH_ATTENTION"] | 模型声明 no_tensor_parallel；实际 TP1 |

覆盖层面的三个二次约束：

- 所有 attention 文件仅有 block size 16；其他 block 配置过滤后为空。
- pairwise all-reduce 只覆盖 TP2/4，A40 没有 AR；所以 compute TP8 不等于端到端 TP8。
- `device` 与 `network_device` 没有 SKU 一致性断言，A100 compute + H100 network 这类物理不一致组合会通过配置构造。

## A.9 Network reachability 全表

| ID | network_device | node GPUs | AR file | AR selected/TP | AR unreachable | (workers,dpn) | SR intra | SR inter | unexpected attention |
|---|---|---|---|---|---|---|---|---|---|
| N001 | `a100_dgx` | 8 | Y | {"2":994,"4":994,"8":994,"16":0} | 3976 | [[2,1],[2,2],[4,2],[4,4],[8,4],[8,8],[16,8]] | 994 | 994 | N |
| N002 | `a100_pairwise_nvlink` | 4 | Y | {"2":2248,"4":2248,"8":0,"16":0} | 0 | [[2,2],[4,4]] | 994 | 994 | N |
| N003 | `a40_pairwise_nvlink` | 8 | N | {} | 0 | [] | 994 | 994 | Y |
| N004 | `h100_dgx` | 8 | Y | {"2":994,"4":994,"8":994,"16":0} | 0 | [[2,2],[4,4],[8,8]] | 994 | 994 | N |
| N005 | `h100_pairwise_nvlink` | 4 | Y | {"2":994,"4":994,"8":0,"16":0} | 0 | [[2,2],[4,4]] | 994 | 994 | N |

A100 DGX 的 3,976 行不可达数据对应 `(2,1),(4,2),(8,4),(16,8)`；当前 filter 只能选择 `(2,2),(4,4),(8,8)`。A40 目录中的 unexpected attention 有 136,750 行，而真正需要的 all-reduce 文件不存在。

## A.10 Trace compatibility 全表

| ID | 文件 | rows | exact dup retained | Length | Replay | Interval | max total | >4096 | arrival monotonic |
|---|---|---|---|---|---|---|---|---|---|
| T001 | `data/processed_traces/arxiv_summarization_stats_llama2_tokenizer_filtered_v2.csv` | 28,257 | 469 | Y | N | N | 4096 | 0 | — |
| T002 | `data/processed_traces/splitwise_code.csv` | 8,819 | 0 | Y | Y | N | 7841 | 1257 | True |
| T003 | `data/processed_traces/splitwise_conv.csv` | 19,366 | 0 | Y | Y | N | 14089 | 1612 | True |

Replay 会将 Splitwise 中 2,869 个超 4K 请求的 excess 全从 prefill 扣除；这不是无损截尾。Length loader 对同一输入采用按比例扣减，因此两种 loader 会生成不同的有效 workload。

## A.11 十六项发现：逐项证据与影响

### DC-001 [高] Network 路径

- 发现：`a40_pairwise_nvlink` 有 `send_recv.csv` 和一个 136,750 行的 `attention.csv`，却没有 loader 所需的 `all_reduce.csv`；current-main 也没有任何路径模板或源码会消费这个 network/attention 文件。
- 证据：`data/profiling/network/a40_pairwise_nvlink; config.py:503-508; sklearn_execution_time_predictor.py:87-103`
- 影响：A40 TP>1 会在打开文件时失败；136,750 行、约 32.6 MB 数据成为孤立资产。

### DC-002 [高] CPU overhead

- 发现：current-main 仓库没有任何 `cpu_overheads.csv`，同时 `skip_cpu_overhead_modeling` 默认为 true。
- 证据：`config.py:511-512,559-561; sklearn_execution_time_predictor.py:518-549,871-899`
- 影响：schedule、sampler、input preparation、output processing 和 Ray communication 默认全部为 0；只打开开关而不提供外部文件会失败。

### DC-003 [高] Compute 覆盖

- 发现：27 个具体 model-device 组合中有 7 个没有 compute 文件：InternLM2-20B 在三种设备上均缺，两个 Llama-3 在 A40/H100 均缺；A100 Llama-3-8B 的 attention 只有 TP1/4，虽然 MLP 有 TP1/2/4/8。
- 证据：`compute_coverage_matrix.csv; model_config.py`
- 影响：真正可用的 model/device/TP 集合小于配置注册表；不支持的组合要到加载或过滤阶段才失败。

### DC-004 [高] 跨节点 all-reduce

- 发现：All-reduce filter 强制 `num_workers==TP` 且 `devices_per_node==TP`。A100 DGX 中 `(2,1),(4,2),(8,4),(16,8)` 共 3,976 行因此不可达，TP16 也为空。
- 证据：`sklearn_execution_time_predictor.py:166-172; network_reachability.csv`
- 影响：仓库已经发布的跨节点 all-reduce 曲线无法被 current loader 选择，TP 跨节点通信没有进入模拟。

### DC-005 [高] Prediction cache

- 发现：Prediction-cache hash 使用 fitted estimator 的字符串，不含训练 dataframe 或树状态；`to_dict()` 又漏掉 `attention_input_file` 和若干控制 prediction grid 的设置。
- 证据：`sklearn_execution_time_predictor.py:281-290,422-449,901-920`
- 影响：同路径 CSV 内容变化或切换 attention CSV 后，只要最佳超参数相同，就可能静默复用旧 lookup。

### DC-006 [高] 预测域

- 发现：Lookup 只按配置范围生成，运行时直接查 dictionary；代码不检查该范围是否被训练数据覆盖。旧 attention 到 KV=4032，默认却含 4096；Orca 可把旧 MLP 的一维 lookup 从实测 4096 扩到 4096×128。
- 证据：`sklearn_execution_time_predictor.py:57-63,588-716,725-869`
- 影响：RF 在训练域外静默饱和为叶常数；超出预生成范围的 shape 则 `KeyError`，没有 profiling/fallback。

### DC-008 [高] 数据质量

- 发现：A100 Qwen-72B TP1 attention 有 16 个 active decode 行的 median 为 0、max 却非 0；当前没有 target validator 过滤或告警。
- 证据：`data/profiling/compute/a100/Qwen/Qwen-72B/attention.csv; csv_inventory.csv`
- 影响：不合理的零时延标签污染 decode learner；自定义 MAPE 对任何非零预测都把这些行记为 100% 误差。

### DC-012 [高] Trace 默认值

- 发现：默认 trace-length 与 trace-interval 路径对应的文件不存在；三个内置 trace 都没有 interval loader 所需的 `arrival_time`，只有两个 Splitwise 文件符合 replay 的 `arrived_at` schema。
- 证据：`config.py:48-65,111-127,228-247; trace_compatibility.csv`
- 影响：相关 generator 模式不能仅用仓库资产开箱复现，错误会在运行时才暴露。

### DC-007 [中] 重复与聚合

- 发现：Loader 只删除所有列完全相同的行，不按 contract key 聚合。Exact dedup 后仍有 166 个额外 MLP 行和 25,812 个额外 attention 行共享 learner 特征。
- 证据：`sklearn_execution_time_predictor.py:105-107,143-145,198-201; csv_inventory.csv`
- 影响：采样分段边界获得额外权重；target 不同的重复测量被当成独立样本，而不是一个 shape 的稳健统计。

### DC-009 [中] Schema fallback

- 发现：18 个旧 attention 文件缺 `attn_kv_cache_save.median` 并被静默补 0；三个 Phi-2 MLP 文件缺 `post_attention_layernorm.median`。
- 证据：`sklearn_execution_time_predictor.py:132-153; csv_inventory.csv`
- 影响：缺失测量和真实零耗时不可区分。Phi-2 因 `post_attn_norm=false` 语义安全；KV-save 为 0 只是兼容性假设。

### DC-010 [中] 隐藏执行 regime

- 发现：`attention_backend`、`max_model_len` 和 CSV 自带 `is_prefill` 都不是 filter/feature；只有 `prefill_chunk_size` 决定 phase。当前旧数据为 FLASH_ATTENTION、Llama-3 为 FLASHINFER。
- 证据：`sklearn_execution_time_predictor.py:143-164,207-218; csv_inventory.csv`
- 影响：未来若把多个 backend 或编译执行 regime 放进同一 CSV，loader 会静默训练一个混合模型。

### DC-011 [中] 设备—拓扑一致性

- 发现：`ReplicaConfig` 独立构造 `device` 与 `network_device`，不检查 node SKU 的 device type 是否匹配 compute device。
- 证据：`config.py:428-464`
- 影响：A100 compute + H100 network 这类语法合法、物理不一致的模拟配置不会被拒绝。

### DC-013 [中] Trace 转换

- 发现：Replay 将超长请求的 excess 全从 prefill 扣除，不再次断言 prefill>0，也不排序 arrival；默认会截断 1,257 条 Splitwise code 和 1,612 条 conversation。Trace loader 还保留重复行。
- 证据：`trace_replay_request_generator.py:23-67,80-92; trace_compatibility.csv`
- 影响：decode scale 足够大时可得到非正 prefill，却仍通过总长度断言；现有长 prompt 分布也被实质改变。

### DC-014 [中] 未消费字段

- 发现：模型只学习 `*.median`。MLP embedding、attention input/output reshape、min/max/mean/std 以及 backend 等元数据都不消费。
- 证据：`sklearn_execution_time_predictor.py:451-579; csv_inventory.csv`
- 影响：CSV 中的不确定性和部分 component 无法影响预测；reshape/embedding 时间也不会自动在其他位置补回。

### DC-015 [中] 通信单位

- 发现：Network size 通过 `size/(embedding_dim*2)` 换算 token，硬编码每个 hidden element 为 2 B；all-reduce median 后再加固定 NCCL launch 项。
- 证据：`sklearn_execution_time_predictor.py:220-236,811-817`
- 影响：FP8/FP32 或压缩通信不能直接复用该契约，dtype 又没有进入 CSV filter。

### DC-016 [信息] 数据完整性正向结论

- 发现：40 个 compute 文件都匹配目录模型的配置维度，block size 均为 16，active prefill/decode target 没有 null；唯一 active 零标签异常是 A100 Qwen 的 16 行。
- 证据：`compute_coverage_matrix.csv; csv_inventory.csv`
- 影响：当前支持切片总体结构一致；主要风险来自覆盖、选择和版本契约，而非普遍 schema 损坏。

## A.12 建议的新数据契约

### A.12.1 启动前 validator

每次构造 predictor 前必须一次性验证：

1. 路径存在，device 与 network SKU 一致，文件 hash 进入 run manifest。
2. required columns、dtype、单位、finite、active target > 0。缺列不能再无条件补零；只有 manifest 明确声明 `fused_into` 才可省略 component。
3. model/TP/block/backend/compiler-regime 过滤后非空，并报告精确行数。
4. 训练 support 完整覆盖 lookup X；越界点拒绝或触发补采，不允许 RF 静默叶常数。
5. 对相同 contract key 聚合独立重复，保存 count/p50/p90/p99/std/CV 和 run IDs。
6. prediction cache key 包含数据内容 hash、完整 config、lookup X hash、fitted model state、代码和软件栈版本。

### A.12.2 建议的 profile manifest

| 类别 | 最低字段 |
|---|---|
| 身份 | dataset_id, run_id, generated_at, source_commit, schema_version |
| 硬件 | device SKU, device UUID, node topology, link type, frequency/power mode, firmware |
| 软件 | driver/CUDA 或 CANN, framework, kernel library/backend, compiler commits/flags |
| 模型 | model revision, graph hash, layer/head/hidden dims, dtype/layout, TP/PP/block |
| 执行 regime | kernel hash, tiling key, fusion pattern, workspace, stream/core assignment |
| 测量 | warmup/active counts, timer source/unit, cold/warm state, raw replicate or aggregate provenance |
| 支持域 | feature min/max/grid, known holes, alignment boundaries, allowed interpolation policy |

### A.12.3 昇腾 NPU 迁移时的加严项

current Vidur 将 `attention_backend` 写进 CSV 却不用于过滤，这在昇腾上不能沿用。CANN/编译器版本、graph/kernel hash、tiling key、融合方案、DMA/流水路径、layout/dtype 和 cold/warm compile-cache 状态必须成为一等分区键。否则同一逻辑 shape 下不同编译执行机制会被混成一个 target 分布。

NPU 的推荐最小建模单元不是固定的源代码 operator 名，而是 compiler-emitted kernel 或 fused segment。缺失 component 应表达为“融合到哪个 segment”，不能伪造为 0 ms。验证切分也必须按 regime、连续 shape 区间和编译版本分组，而不是仅按 CSV 行随机拆分。

## A.13 本附录的机器证据

| 资产 | 绝对路径 |
|---|---|
| 53 文件 inventory | `D:/workspaces/trace/vidur_data_analysis/contract_agent/csv_inventory.csv` |
| 27 配置 coverage | `D:/workspaces/trace/vidur_data_analysis/contract_agent/compute_coverage_matrix.csv` |
| Network reachability | `D:/workspaces/trace/vidur_data_analysis/contract_agent/network_reachability.csv` |
| Trace compatibility | `D:/workspaces/trace/vidur_data_analysis/contract_agent/trace_compatibility.csv` |
| 16 findings | `D:/workspaces/trace/vidur_data_analysis/contract_agent/findings.csv` |
| 契约 JSON | `D:/workspaces/trace/vidur_data_analysis/contract_agent/contract_summary.json` |
| 复算脚本 | `D:/workspaces/trace/vidur_data_analysis/contract_agent/audit_data_contract.py` |
| 本附录生成脚本 | `D:/workspaces/trace/vidur_data_analysis/contract_agent/build_deep_appendix.py` |

官方仓库在本分析过程中保持只读；所有新增产物均位于 `D:/workspaces/trace/vidur_data_analysis/`。

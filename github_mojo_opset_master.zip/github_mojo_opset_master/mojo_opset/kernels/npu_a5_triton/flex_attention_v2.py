from typing import Optional
from typing import Tuple

import torch
import torch.nn.functional as _F
import triton
import triton.language as tl

from packaging.version import Version
from torch.nn.attention.flex_attention import _convert_mask_to_block_mask
from torch.nn.attention.flex_attention import create_mask as _torch_create_mask

from mojo_opset.kernels._npu_triton_utils import get_ascend_compiler_version
from mojo_opset.kernels._npu_triton_utils import get_num_cores
from mojo_opset.utils.flex_attention_mask import _create_sparse_block_from_block_mask
from mojo_opset.utils.target import get_torch_device as _get_torch_device

TILE_BLOCK_SIZE = 128


def _dq_cache_config():
    kind, version = get_ascend_compiler_version()
    minimum = Version("3.6.0.post1" if kind == "internal" else "3.6.0")
    # Older/unknown compilers can corrupt dQ and dropout forward double buffering.
    return (3, 2) if version is not None and version >= minimum else (1, 1)


_DQ_INTRA_CACHE_NUM, _DQ_INTER_CACHE_NUM = _dq_cache_config()


def _dkdv_config(head_dim, value_dim, has_dropout):
    """Return Q tile, KV tile, and local buffer count together."""
    # A wider KV tile reuses Q/dO loads across more keys. Keep the measured
    # 950PR configuration scoped to D=128; 128x128 overflows UB with dropout.
    if has_dropout and head_dim == value_dim == 128:
        return 64, 128, 1
    return (128, 64, 2) if has_dropout else (128, 128, 2)


@torch._dynamo.assume_constant_result
def _get_num_aicore():
    try:
        return max(get_num_cores(op_type="cube"), 1)
    except Exception:
        return 1


def _persistent_launch_config(num_tasks):
    num_tasks = max(int(num_tasks), 1)
    return (min(_get_num_aicore(), num_tasks),), num_tasks


@triton.jit
def load_dropout_keep(
    RANDOM_VALUES, BLOCK_TABLE, NUM_ACTIVE,
    batch, head, Q_HEAD, start_m, start_n, KV_LEN,
    SPARSE_M: tl.constexpr, SPARSE_N: tl.constexpr, THRESHOLD: tl.constexpr,
    BLOCK_M: tl.constexpr, BLOCK_N: tl.constexpr,
    COMPARE_IN_HALF: tl.constexpr = False,
    BITPACKED: tl.constexpr = False,
):
    # All callers operate on subtiles contained in a single sparse block.
    qb = start_m // SPARSE_M
    kb = start_n // SPARSE_N
    slot = tl.load(BLOCK_TABLE + qb * tl.cdiv(KV_LEN, SPARSE_N) + kb).to(tl.int64)
    slot_base = (batch.to(tl.int64) * Q_HEAD + head) * NUM_ACTIVE + slot
    if BITPACKED:
        rows_per_plane: tl.constexpr = SPARSE_M // 8
        packed_ptr = tl.make_block_ptr(
            base=RANDOM_VALUES + slot_base * (rows_per_plane * SPARSE_N),
            shape=(rows_per_plane, SPARSE_N), strides=(SPARSE_N, 1),
            offsets=(0, start_n % SPARSE_N),
            block_shape=(rows_per_plane, BLOCK_N), order=(1, 0),
        )
        packed = tl.load(packed_ptr)
        plane = tl.arange(0, BLOCK_M // rows_per_plane) + (start_m % SPARSE_M) // rows_per_plane
        bit_masks = (1 << plane).to(tl.uint8)
        keep = (packed[None, :, :] & bit_masks[:, None, None]).reshape(BLOCK_M, BLOCK_N)
        return keep != tl.full((), 0, tl.uint8)
    else:
        # Every scheduled block owns a full padded tile, including sequence tails.
        random_ptr = tl.make_block_ptr(
            base=RANDOM_VALUES + slot_base * (SPARSE_M * SPARSE_N), shape=(SPARSE_M, SPARSE_N),
            strides=(SPARSE_N, 1), offsets=(start_m % SPARSE_M, start_n % SPARSE_N),
            block_shape=(BLOCK_M, BLOCK_N), order=(1, 0),
        )
        random_bytes = tl.load(random_ptr)
        if COMPARE_IN_HALF:
            # Every uint8 value and integer threshold is exactly representable in FP16.
            return random_bytes.to(tl.float16) <= tl.full((), THRESHOLD, tl.float16)
        return random_bytes.to(tl.int32) <= THRESHOLD


def _prepare_dropout_args(q, k, block_mask, dropout):
    if dropout is None or dropout.dropout_p == 0:
        return q, q, 0, 255, 1.0, False, False
    layout = dropout.layout
    if tuple(block_mask.BLOCK_SIZE) != (TILE_BLOCK_SIZE, TILE_BLOCK_SIZE):
        raise ValueError("A5 dropout currently requires 128 x 128 sparse blocks")
    height = TILE_BLOCK_SIZE // 8 if dropout.bitpacked else TILE_BLOCK_SIZE
    expected = (q.shape[0], q.shape[1], layout.num_active, height, TILE_BLOCK_SIZE)
    if dropout.tiles is None or tuple(dropout.tiles.shape) != expected:
        raise ValueError("Dropout random tensor shape does not match Q and the sparse layout")
    table = layout.block_table
    if tuple(table.shape) != (triton.cdiv(q.shape[2], TILE_BLOCK_SIZE), triton.cdiv(k.shape[2], TILE_BLOCK_SIZE)):
        raise ValueError("Dropout block table shape does not match Q/K lengths")
    if dropout.tiles.dtype != torch.uint8 or table.dtype != torch.int32:
        raise ValueError("Dropout requires uint8 random values and int32 block indices")
    if dropout.tiles.device != q.device or table.device != q.device:
        raise ValueError("Dropout metadata must reside on the attention device")
    if not dropout.tiles.is_contiguous() or not table.is_contiguous():
        raise ValueError("Dropout random values and block table must be contiguous")
    return dropout.tiles, table, layout.num_active, dropout.threshold, dropout.scale, True, dropout.bitpacked


@triton.jit(
    do_not_specialize=[
        "stride_mask_m",
        "stride_lse_z", "stride_lse_h", "stride_kv_idx_m",
        "Q_LEN", "KV_LEN", "NUM_TASKS", "NUM_Q_BLOCKS",
        "stride_partial_p", "stride_partial_m",
        "stride_qz", "stride_qh",
        "stride_kz", "stride_kh",
        "stride_vz", "stride_vh",
        "stride_out_z", "stride_out_h",
    ]
)
def flex_attention_kernel(
    Q,
    K,
    V,
    KV_NUM_BLKS,
    KV_IDX,
    FULL_KV_NUM_BLKS,
    FULL_KV_IDX,
    DENSE_MASK,
    stride_mask_m,
    stride_mask_n,
    PARTIAL_MASK_PACKED,
    PARTIAL_MASK_OFFSETS,
    stride_partial_p,
    stride_partial_m,
    stride_partial_n,
    stride_partial_offset_m,
    OUT,
    LSE,
    stride_qz, stride_qh, stride_qm, stride_qk,
    stride_kz, stride_kh, stride_kn, stride_kk,
    stride_vz, stride_vh, stride_vn, stride_vk,
    stride_out_z, stride_out_h, stride_out_m, stride_out_k,
    stride_lse_z, stride_lse_h, stride_lse_m,
    stride_kv_idx_m,
    SM_SCALE,
    QK_HEAD_DIM: tl.constexpr,
    V_HEAD_DIM: tl.constexpr,
    BLOCK_M: tl.constexpr,
    BLOCK_N: tl.constexpr,
    NUM_TASKS,
    NUM_Q_BLOCKS,
    Q_HEAD,
    SPARSE_Q_BLOCK_SIZE: tl.constexpr,
    SPARSE_KV_BLOCK_SIZE: tl.constexpr,
    Q_LEN,
    KV_LEN,
    GQA_SHARED_HEADS,
    HAS_FULL_BLOCKS: tl.constexpr = True,
    USE_PACKED_PARTIAL_MASK: tl.constexpr = False,
    DROPOUT_VALUES=None,
    DROPOUT_TABLE=None,
    NUM_DROPOUT_BLOCKS=0,
    DROPOUT_THRESHOLD: tl.constexpr = 255,
    DROPOUT_SCALE: tl.constexpr = 1.0,
    HAS_DROPOUT: tl.constexpr = False,
    DROPOUT_BITPACKED: tl.constexpr = False,
    AUX_OUT=None,
    WRITE_AUX_OUT: tl.constexpr = False,
):
    pid = tl.program_id(0).to(tl.int32)
    num_core = tl.num_programs(0).to(tl.int32)

    for task_id in range(pid, NUM_TASKS, num_core):
        q_start = task_id % NUM_Q_BLOCKS
        off_z = (task_id // NUM_Q_BLOCKS) // Q_HEAD
        off_hq = (task_id // NUM_Q_BLOCKS) % Q_HEAD
        off_hkv = off_hq // GQA_SHARED_HEADS

        off_z = off_z.to(tl.int64)
        off_hq = off_hq.to(tl.int64)
        off_hkv = off_hkv.to(tl.int64)

        q_offset = off_z * stride_qz + off_hq * stride_qh
        k_offset = off_z * stride_kz + off_hkv * stride_kh
        v_offset = off_z * stride_vz + off_hkv * stride_vh
        out_offset = off_z * stride_out_z + off_hq * stride_out_h
        lse_offset = off_z * stride_lse_z + off_hq * stride_lse_h

        Q_ptr = Q + q_offset
        K_ptr = K + k_offset
        V_ptr = V + v_offset
        OUT_ptr = OUT + out_offset
        LSE_ptr = LSE + lse_offset

        m_i = tl.full([BLOCK_M], float("-inf"), dtype=tl.float32)
        l_i = tl.zeros([BLOCK_M], dtype=tl.float32)
        acc = tl.zeros([BLOCK_M, V_HEAD_DIM], dtype=tl.float32)

        offs_m = q_start * BLOCK_M + tl.arange(0, BLOCK_M)
        offs_k = tl.arange(0, QK_HEAD_DIM)
        offs_v = tl.arange(0, V_HEAD_DIM)

        q = tl.load(
            Q_ptr + offs_m[:, None] * stride_qm + offs_k[None, :] * stride_qk,
            mask=(offs_m[:, None] < Q_LEN),
            other=0.0
        )

        SPARSE_Q_MULTIPLE = SPARSE_Q_BLOCK_SIZE // BLOCK_M
        SPARSE_KV_MULTIPLE = SPARSE_KV_BLOCK_SIZE // BLOCK_N

        q_sparse_idx = q_start // SPARSE_Q_MULTIPLE
        sparse_kv_num_blks_offset = q_sparse_idx
        sparse_kv_idx_offset = q_sparse_idx * stride_kv_idx_m
        partial_mask_offset = tl.load(PARTIAL_MASK_OFFSETS + q_sparse_idx * stride_partial_offset_m)
        q_sparse_base = q_sparse_idx * SPARSE_Q_BLOCK_SIZE

        kv_indices = KV_IDX + sparse_kv_idx_offset
        kv_num_blocks = tl.load(KV_NUM_BLKS + sparse_kv_num_blks_offset)
        block_n_end = tl.minimum(
            kv_num_blocks * SPARSE_KV_MULTIPLE,
            tl.maximum(tl.cdiv(KV_LEN, BLOCK_N), 1, propagate_nan=True),
            propagate_nan=tl.PropagateNan.ALL,
        )
        for start_n in range(0, block_n_end):
            blk_idx_in_list = start_n // SPARSE_KV_MULTIPLE
            kv_block = tl.load(kv_indices + blk_idx_in_list)
            kv_start = kv_block * SPARSE_KV_BLOCK_SIZE + (start_n % SPARSE_KV_MULTIPLE) * BLOCK_N

            offs_n_load = kv_start + tl.arange(0, BLOCK_N)
            if USE_PACKED_PARTIAL_MASK:
                partial_block_idx = partial_mask_offset + blk_idx_in_list
                offs_m_in_block = offs_m - q_sparse_base
                offs_n_in_block = (start_n % SPARSE_KV_MULTIPLE) * BLOCK_N + tl.arange(0, BLOCK_N)
                mask = load_packed_partial_mask(
                    PARTIAL_MASK_PACKED,
                    stride_partial_p,
                    stride_partial_m,
                    stride_partial_n,
                    partial_block_idx,
                    offs_m_in_block,
                    offs_n_in_block,
                    SPARSE_Q_BLOCK_SIZE=SPARSE_Q_BLOCK_SIZE,
                    SPARSE_KV_BLOCK_SIZE=SPARSE_KV_BLOCK_SIZE,
                )
            else:
                mask = load_dense_mask(
                    DENSE_MASK,
                    stride_mask_m,
                    stride_mask_n,
                    offs_m,
                    offs_n_load,
                    Q_LEN=Q_LEN,
                    KV_LEN=KV_LEN,
                )

            k = tl.load(
                K_ptr + offs_n_load[:, None] * stride_kn + offs_k[None, :] * stride_kk,
                mask=(offs_n_load[:, None] < KV_LEN),
                other=0.0
            )
            v = tl.load(
                V_ptr + offs_n_load[:, None] * stride_vn + offs_v[None, :] * stride_vk,
                mask=(offs_n_load[:, None] < KV_LEN),
                other=0.0
            )
            k = tl.trans(k)

            qk = tl.dot(q, k, input_precision="ieee")
            qk *= SM_SCALE

            qk = tl.where(mask, qk, float("-inf"))

            m_ij = tl.maximum(m_i, tl.max(qk, 1, propagate_nan=True), propagate_nan=tl.PropagateNan.ALL)
            masked_out_rows = (m_ij == float("-inf"))
            m_ij_masked = tl.where(masked_out_rows, 0, m_ij)

            alpha = tl.math.exp(m_i - m_ij_masked)
            p = tl.math.exp(qk - m_ij_masked[:, None])

            p_for_pv = p
            if HAS_DROPOUT:
                keep = load_dropout_keep(
                    DROPOUT_VALUES, DROPOUT_TABLE, NUM_DROPOUT_BLOCKS,
                    off_z, off_hq, Q_HEAD, q_start * BLOCK_M, kv_start, KV_LEN,
                    SPARSE_Q_BLOCK_SIZE, SPARSE_KV_BLOCK_SIZE, DROPOUT_THRESHOLD, BLOCK_M, BLOCK_N,
                    COMPARE_IN_HALF=True, BITPACKED=DROPOUT_BITPACKED,
                )
                p_for_pv = tl.where(keep, p.to(Q.dtype.element_ty), tl.full((), 0, Q.dtype.element_ty))
            pv = tl.dot(p_for_pv.to(Q.dtype.element_ty), v, input_precision="ieee")
            l_i = l_i * alpha + tl.sum(p, 1)
            acc = acc * alpha[:, None] + pv
            m_i = m_ij

        if HAS_FULL_BLOCKS:
            kv_indices = FULL_KV_IDX + sparse_kv_idx_offset
            kv_num_blocks = tl.load(FULL_KV_NUM_BLKS + sparse_kv_num_blks_offset)
            block_n_end = tl.minimum(
                kv_num_blocks * SPARSE_KV_MULTIPLE,
                tl.maximum(tl.cdiv(KV_LEN, BLOCK_N), 1, propagate_nan=True),
                propagate_nan=tl.PropagateNan.ALL,
            )

            for start_n in range(0, block_n_end):
                blk_idx_in_list = start_n // SPARSE_KV_MULTIPLE
                kv_block = tl.load(kv_indices + blk_idx_in_list)
                kv_start = kv_block * SPARSE_KV_BLOCK_SIZE + (start_n % SPARSE_KV_MULTIPLE) * BLOCK_N

                offs_n_load = kv_start + tl.arange(0, BLOCK_N)
                k = tl.load(
                    K_ptr + offs_n_load[:, None] * stride_kn + offs_k[None, :] * stride_kk,
                    mask=(offs_n_load[:, None] < KV_LEN),
                    other=0.0
                )
                v = tl.load(
                    V_ptr + offs_n_load[:, None] * stride_vn + offs_v[None, :] * stride_vk,
                    mask=(offs_n_load[:, None] < KV_LEN),
                    other=0.0
                )
                k = tl.trans(k)

                qk = tl.dot(q, k, input_precision="ieee")
                qk *= SM_SCALE

                m_ij = tl.maximum(m_i, tl.max(qk, 1, propagate_nan=True), propagate_nan=tl.PropagateNan.ALL)
                alpha = tl.math.exp(m_i - m_ij)
                p = tl.math.exp(qk - m_ij[:, None])

                p_for_pv = p
                if HAS_DROPOUT:
                    keep = load_dropout_keep(
                        DROPOUT_VALUES, DROPOUT_TABLE, NUM_DROPOUT_BLOCKS,
                        off_z, off_hq, Q_HEAD, q_start * BLOCK_M, kv_start, KV_LEN,
                        SPARSE_Q_BLOCK_SIZE, SPARSE_KV_BLOCK_SIZE, DROPOUT_THRESHOLD, BLOCK_M, BLOCK_N,
                        COMPARE_IN_HALF=True, BITPACKED=DROPOUT_BITPACKED,
                    )
                    p_for_pv = tl.where(keep, p.to(Q.dtype.element_ty), tl.full((), 0, Q.dtype.element_ty))
                pv = tl.dot(p_for_pv.to(Q.dtype.element_ty), v, input_precision="ieee")
                l_i = l_i * alpha + tl.sum(p, 1)
                acc = acc * alpha[:, None] + pv
                m_i = m_ij
        l_i = tl.where(l_i == 0.0, 1.0, l_i)
        acc = acc / l_i[:, None]
        if HAS_DROPOUT:
            acc *= DROPOUT_SCALE

        out_mask = (offs_m[:, None] < Q_LEN) & (offs_v[None, :] < V_HEAD_DIM)
        tl.store(
            OUT_ptr + offs_m[:, None] * stride_out_m + offs_v[None, :] * stride_out_k,
            acc,
            mask=out_mask
        )

        if WRITE_AUX_OUT:
            tl.store(
                AUX_OUT + off_z * stride_out_z + off_hq * stride_out_h
                + offs_m[:, None] * stride_out_m + offs_v[None, :] * stride_out_k,
                acc, mask=out_mask,
            )
        lse = m_i + tl.math.log(l_i)
        tl.store(LSE_ptr + offs_m * stride_lse_m, lse, mask=offs_m < Q_LEN)


@triton.jit
def load_dense_mask(
    DENSE_MASK,
    stride_mask_m,
    stride_mask_n,
    offs_m,
    offs_n,
    Q_LEN,
    KV_LEN,
):
    stride_mask_m = stride_mask_m.to(tl.int64)
    ptrs = DENSE_MASK + offs_m[:, None] * stride_mask_m + offs_n[None, :] * stride_mask_n
    valid = (offs_m[:, None] < Q_LEN) & (offs_n[None, :] < KV_LEN)
    return tl.load(ptrs, mask=valid, other=0)


@triton.jit
def load_packed_partial_mask(
    PARTIAL_MASK_PACKED,
    stride_partial_p,
    stride_partial_m,
    stride_partial_n,
    partial_block_idx,
    offs_m_in_block,
    offs_n_in_block,
    SPARSE_Q_BLOCK_SIZE: tl.constexpr,
    SPARSE_KV_BLOCK_SIZE: tl.constexpr,
):
    ptrs = (
        PARTIAL_MASK_PACKED
        + partial_block_idx * stride_partial_p
        + offs_m_in_block[:, None] * stride_partial_m
        + offs_n_in_block[None, :] * stride_partial_n
    )
    valid = (
        (offs_m_in_block[:, None] < SPARSE_Q_BLOCK_SIZE)
        & (offs_n_in_block[None, :] < SPARSE_KV_BLOCK_SIZE)
    )
    return tl.load(ptrs, mask=valid, other=0)


@triton.jit
def bwd_dq_block_mn(
    q, do, lse, delta,
    K_ptr, V_ptr,
    DENSE_MASK, stride_mask_m, stride_mask_n,
    PARTIAL_MASK_PACKED, stride_partial_p, stride_partial_m, stride_partial_n,
    PARTIAL_BLOCK_TABLE, stride_partial_table_m, stride_partial_table_n,
    Q_LEN, KV_LEN,
    offs_m, offs_n, offs_k, offs_v,
    q_sparse_idx, kv_block, kv_sub, q_sparse_base,
    stride_kn, stride_kk, stride_vn, stride_vk,
    MATMUL_PRECISION,
    QK_HEAD_DIM: tl.constexpr,
    V_HEAD_DIM: tl.constexpr,
    BLOCK_N: tl.constexpr,
    SPARSE_Q_BLOCK_SIZE: tl.constexpr,
    SPARSE_KV_BLOCK_SIZE: tl.constexpr,
    SM_SCALE: tl.constexpr,
    IS_FULL_BLOCKS: tl.constexpr,
    USE_PACKED_PARTIAL_MASK: tl.constexpr,
):
    k = tl.load(
        K_ptr + offs_n[:, None] * stride_kn + offs_k[None, :] * stride_kk,
        mask=(offs_n[:, None] < KV_LEN),
        other=0.0,
    )
    v = tl.load(
        V_ptr + offs_n[:, None] * stride_vn + offs_v[None, :] * stride_vk,
        mask=(offs_n[:, None] < KV_LEN),
        other=0.0,
    )

    qk = tl.dot(q, tl.trans(k), input_precision="ieee")
    qk *= SM_SCALE

    mask = True
    if not IS_FULL_BLOCKS:
        if USE_PACKED_PARTIAL_MASK:
            partial_block_idx = tl.load(
                PARTIAL_BLOCK_TABLE
                + q_sparse_idx * stride_partial_table_m
                + kv_block * stride_partial_table_n
            )
            safe_partial_block_idx = tl.maximum(partial_block_idx, 0)
            offs_m_in_block = offs_m - q_sparse_base
            offs_n_in_block = kv_sub * BLOCK_N + tl.arange(0, BLOCK_N)
            mask = load_packed_partial_mask(
                PARTIAL_MASK_PACKED,
                stride_partial_p,
                stride_partial_m,
                stride_partial_n,
                safe_partial_block_idx,
                offs_m_in_block,
                offs_n_in_block,
                SPARSE_Q_BLOCK_SIZE=SPARSE_Q_BLOCK_SIZE,
                SPARSE_KV_BLOCK_SIZE=SPARSE_KV_BLOCK_SIZE,
            )
            mask = mask & (partial_block_idx >= 0)
        else:
            mask = load_dense_mask(
                DENSE_MASK,
                stride_mask_m,
                stride_mask_n,
                offs_m,
                offs_n,
                Q_LEN=Q_LEN,
                KV_LEN=KV_LEN,
            )
        qk = tl.where(mask & (offs_n[None, :] < KV_LEN), qk, float("-inf"))
    else:
        qk = tl.where(offs_n[None, :] < KV_LEN, qk, float("-inf"))

    p = tl.math.exp(qk - lse[:, None])
    dp = tl.dot(do, tl.trans(v), input_precision="ieee")
    ds = p * (dp - delta[:, None])
    ds *= SM_SCALE

    dq = tl.dot(ds.to(MATMUL_PRECISION), k, input_precision="ieee")
    return dq


@triton.jit(
    do_not_specialize=[
        "stride_mask_m",
        "stride_partial_p", "stride_partial_m",
        "stride_partial_table_m",
        "stride_lse_z", "stride_lse_h", "stride_kv_idx_m",
        "Q_LEN", "KV_LEN", "NUM_TASKS", "NUM_Q_BLOCKS",
        "stride_qz", "stride_qh",
        "stride_kz", "stride_kh",
        "stride_vz", "stride_vh",
        "stride_doz", "stride_doh",
        "stride_delta_z", "stride_delta_h",
        "stride_dqz", "stride_dqh",
    ]
)
def flex_attention_backward_dq_kernel(
    Q,
    K,
    V,
    DO,
    LSE,
    DELTA,
    KV_NUM_BLKS,
    KV_IDX,
    FULL_KV_NUM_BLKS,
    FULL_KV_IDX,
    DENSE_MASK,
    stride_mask_m,
    stride_mask_n,
    PARTIAL_MASK_PACKED,
    PARTIAL_MASK_OFFSETS,
    PARTIAL_BLOCK_TABLE,
    stride_partial_p,
    stride_partial_m,
    stride_partial_n,
    stride_partial_offset_m,
    stride_partial_table_m,
    stride_partial_table_n,
    DQ,
    stride_qz, stride_qh, stride_qm, stride_qk,
    stride_kz, stride_kh, stride_kn, stride_kk,
    stride_vz, stride_vh, stride_vn, stride_vk,
    stride_doz, stride_doh, stride_dom, stride_dok,
    stride_lse_z, stride_lse_h, stride_lse_m,
    stride_delta_z, stride_delta_h, stride_delta_m,
    stride_dqz, stride_dqh, stride_dqm, stride_dqk,
    stride_kv_idx_m,
    SM_SCALE: tl.constexpr,
    QK_HEAD_DIM: tl.constexpr,
    V_HEAD_DIM: tl.constexpr,
    BLOCK_M: tl.constexpr,
    BLOCK_N: tl.constexpr,
    NUM_KV_SUB_BLOCKS: tl.constexpr,
    NUM_TASKS,
    NUM_Q_BLOCKS,
    Q_HEAD,
    SPARSE_Q_BLOCK_SIZE: tl.constexpr,
    SPARSE_KV_BLOCK_SIZE: tl.constexpr,
    Q_LEN,
    KV_LEN,
    GQA_SHARED_HEADS: tl.constexpr,
    HAS_FULL_BLOCKS: tl.constexpr = True,
    USE_PACKED_PARTIAL_MASK: tl.constexpr = False,
    DROPOUT_VALUES=None,
    DROPOUT_TABLE=None,
    NUM_DROPOUT_BLOCKS=0,
    DROPOUT_THRESHOLD: tl.constexpr = 255,
    DROPOUT_SCALE: tl.constexpr = 1.0,
    HAS_DROPOUT: tl.constexpr = False,
    DROPOUT_BITPACKED: tl.constexpr = False,
):
    pid = tl.program_id(0).to(tl.int32)
    num_core = tl.num_programs(0).to(tl.int32)
    sparse_q_multiple = SPARSE_Q_BLOCK_SIZE // BLOCK_M
    MATMUL_PRECISION = Q.dtype.element_ty

    for task_id in range(pid, NUM_TASKS, num_core):
        q_start = task_id % NUM_Q_BLOCKS
        off_z = (task_id // NUM_Q_BLOCKS) // Q_HEAD
        off_hq = (task_id // NUM_Q_BLOCKS) % Q_HEAD
        off_hkv = off_hq // GQA_SHARED_HEADS

        off_z = off_z.to(tl.int64)
        off_hq = off_hq.to(tl.int64)
        off_hkv = off_hkv.to(tl.int64)

        q_offset = off_z * stride_qz + off_hq * stride_qh
        k_offset = off_z * stride_kz + off_hkv * stride_kh
        v_offset = off_z * stride_vz + off_hkv * stride_vh
        do_offset = off_z * stride_doz + off_hq * stride_doh
        lse_offset = off_z * stride_lse_z + off_hq * stride_lse_h
        delta_offset = off_z * stride_delta_z + off_hq * stride_delta_h
        dq_offset = off_z * stride_dqz + off_hq * stride_dqh

        Q_ptr = Q + q_offset
        K_ptr = K + k_offset
        V_ptr = V + v_offset
        DO_ptr = DO + do_offset
        LSE_ptr = LSE + lse_offset
        DELTA_ptr = DELTA + delta_offset
        DQ_ptr = DQ + dq_offset

        offs_m = q_start * BLOCK_M + tl.arange(0, BLOCK_M)
        offs_k = tl.arange(0, QK_HEAD_DIM)
        offs_v = tl.arange(0, V_HEAD_DIM)

        q = tl.load(
            Q_ptr + offs_m[:, None] * stride_qm + offs_k[None, :] * stride_qk,
            mask=(offs_m[:, None] < Q_LEN),
            other=0.0,
        )
        do = tl.load(
            DO_ptr + offs_m[:, None] * stride_dom + offs_v[None, :] * stride_dok,
            mask=(offs_m[:, None] < Q_LEN),
            other=0.0,
        )

        lse = tl.load(LSE_ptr + offs_m * stride_lse_m, mask=offs_m < Q_LEN, other=float("-inf"))
        delta = tl.load(DELTA_ptr + offs_m * stride_delta_m, mask=offs_m < Q_LEN, other=0.0)
        lse = tl.where(lse == float("-inf"), 0.0, lse)

        dq = tl.zeros([BLOCK_M, QK_HEAD_DIM], dtype=tl.float32)

        q_sparse_idx = q_start // sparse_q_multiple
        sparse_kv_num_blks_offset = q_sparse_idx
        sparse_kv_idx_offset = q_sparse_idx * stride_kv_idx_m
        q_sparse_base = q_sparse_idx * SPARSE_Q_BLOCK_SIZE

        kv_indices = KV_IDX + sparse_kv_idx_offset
        kv_num_blocks = tl.load(KV_NUM_BLKS + sparse_kv_num_blks_offset)

        for blk_idx_in_list in range(0, kv_num_blocks):
            kv_block = tl.load(kv_indices + blk_idx_in_list)
            kv_start_full = kv_block * SPARSE_KV_BLOCK_SIZE

            for kv_sub in range(NUM_KV_SUB_BLOCKS):
                start_n = kv_start_full + kv_sub * BLOCK_N
                offs_n = start_n + tl.arange(0, BLOCK_N)

                k = tl.load(
                    K_ptr + offs_n[:, None] * stride_kn + offs_k[None, :] * stride_kk,
                    mask=(offs_n[:, None] < KV_LEN),
                    other=0.0,
                )
                v = tl.load(
                    V_ptr + offs_n[:, None] * stride_vn + offs_v[None, :] * stride_vk,
                    mask=(offs_n[:, None] < KV_LEN),
                    other=0.0,
                )

                qk = tl.dot(q, tl.trans(k), input_precision="ieee")
                qk *= SM_SCALE

                if USE_PACKED_PARTIAL_MASK:
                    partial_block_idx = tl.load(
                        PARTIAL_BLOCK_TABLE
                        + q_sparse_idx * stride_partial_table_m
                        + kv_block * stride_partial_table_n
                    )
                    safe_partial_block_idx = tl.maximum(partial_block_idx, 0, propagate_nan=True)
                    offs_m_in_block = offs_m - q_sparse_base
                    offs_n_in_block = kv_sub * BLOCK_N + tl.arange(0, BLOCK_N)
                    mask = load_packed_partial_mask(
                        PARTIAL_MASK_PACKED,
                        stride_partial_p,
                        stride_partial_m,
                        stride_partial_n,
                        safe_partial_block_idx,
                        offs_m_in_block,
                        offs_n_in_block,
                        SPARSE_Q_BLOCK_SIZE=SPARSE_Q_BLOCK_SIZE,
                        SPARSE_KV_BLOCK_SIZE=SPARSE_KV_BLOCK_SIZE,
                    )
                    mask = mask & (partial_block_idx >= 0)
                else:
                    mask = load_dense_mask(
                        DENSE_MASK,
                        stride_mask_m,
                        stride_mask_n,
                        offs_m,
                        offs_n,
                        Q_LEN=Q_LEN,
                        KV_LEN=KV_LEN,
                    )
                qk = tl.where(mask, qk, float("-inf"))

                p = tl.math.exp(qk - lse[:, None])
                dp = tl.dot(do, tl.trans(v), input_precision="ieee")
                if HAS_DROPOUT:
                    keep = load_dropout_keep(
                        DROPOUT_VALUES, DROPOUT_TABLE, NUM_DROPOUT_BLOCKS,
                        off_z, off_hq, Q_HEAD, q_start * BLOCK_M, start_n, KV_LEN,
                        SPARSE_Q_BLOCK_SIZE, SPARSE_KV_BLOCK_SIZE, DROPOUT_THRESHOLD, BLOCK_M, BLOCK_N,
                        COMPARE_IN_HALF=True, BITPACKED=DROPOUT_BITPACKED,
                    )
                    dp = tl.where(keep, dp * DROPOUT_SCALE, 0.0)
                ds = p * (dp - delta[:, None])
                ds *= SM_SCALE
                dq += tl.dot(ds.to(MATMUL_PRECISION), k, input_precision="ieee")

        if HAS_FULL_BLOCKS:
            kv_indices_f = FULL_KV_IDX + sparse_kv_idx_offset
            kv_num_blocks_f = tl.load(FULL_KV_NUM_BLKS + sparse_kv_num_blks_offset)
            for blk_idx_in_list in range(0, kv_num_blocks_f):
                kv_block = tl.load(kv_indices_f + blk_idx_in_list)
                kv_start_full = kv_block * SPARSE_KV_BLOCK_SIZE

                for kv_sub in range(NUM_KV_SUB_BLOCKS):
                    start_n = kv_start_full + kv_sub * BLOCK_N
                    offs_n = start_n + tl.arange(0, BLOCK_N)

                    k = tl.load(
                        K_ptr + offs_n[:, None] * stride_kn + offs_k[None, :] * stride_kk,
                        mask=(offs_n[:, None] < KV_LEN),
                        other=0.0,
                    )
                    v = tl.load(
                        V_ptr + offs_n[:, None] * stride_vn + offs_v[None, :] * stride_vk,
                        mask=(offs_n[:, None] < KV_LEN),
                        other=0.0,
                    )

                    qk = tl.dot(q, tl.trans(k), input_precision="ieee")
                    qk *= SM_SCALE

                    p = tl.math.exp(qk - lse[:, None])
                    dp = tl.dot(do, tl.trans(v), input_precision="ieee")
                    if HAS_DROPOUT:
                        keep = load_dropout_keep(
                            DROPOUT_VALUES, DROPOUT_TABLE, NUM_DROPOUT_BLOCKS,
                            off_z, off_hq, Q_HEAD, q_start * BLOCK_M, start_n, KV_LEN,
                            SPARSE_Q_BLOCK_SIZE, SPARSE_KV_BLOCK_SIZE, DROPOUT_THRESHOLD, BLOCK_M, BLOCK_N,
                            COMPARE_IN_HALF=True, BITPACKED=DROPOUT_BITPACKED,
                        )
                        dp = tl.where(keep, dp * DROPOUT_SCALE, 0.0)
                    ds = p * (dp - delta[:, None])
                    ds *= SM_SCALE
                    dq += tl.dot(ds.to(MATMUL_PRECISION), k, input_precision="ieee")

        tl.store(
            DQ_ptr + offs_m[:, None] * stride_dqm + offs_k[None, :] * stride_dqk,
            dq,
            mask=(offs_m[:, None] < Q_LEN) & (offs_k[None, :] < QK_HEAD_DIM),
        )


@triton.jit(
    do_not_specialize=[
        "stride_mask_m",
        "stride_partial_p", "stride_partial_m",
        "stride_partial_table_m",
        "stride_lse_z", "stride_lse_h", "stride_q_idx_m",
        "Q_LEN", "KV_LEN", "NUM_TASKS", "NUM_KV_BLOCKS",
        "stride_qz", "stride_qh",
        "stride_kz", "stride_kh",
        "stride_vz", "stride_vh",
        "stride_doz", "stride_doh",
        "stride_delta_z", "stride_delta_h",
        "stride_dkz", "stride_dkh",
        "stride_dvz", "stride_dvh",
    ]
)
def flex_attention_backward_dkdv_kernel(
    Q,
    K,
    V,
    DO,
    LSE,
    DELTA,
    Q_NUM_BLKS,
    Q_IDX,
    FULL_Q_NUM_BLKS,
    FULL_Q_IDX,
    DENSE_MASK,
    stride_mask_m,
    stride_mask_n,
    PARTIAL_MASK_PACKED,
    PARTIAL_MASK_OFFSETS,
    PARTIAL_BLOCK_TABLE,
    stride_partial_p,
    stride_partial_m,
    stride_partial_n,
    stride_partial_offset_m,
    stride_partial_table_m,
    stride_partial_table_n,
    DQ,
    DK,
    DV,
    stride_qz, stride_qh, stride_qm, stride_qk,
    stride_kz, stride_kh, stride_kn, stride_kk,
    stride_vz, stride_vh, stride_vn, stride_vk,
    stride_doz, stride_doh, stride_dom, stride_dok,
    stride_lse_z, stride_lse_h, stride_lse_m,
    stride_delta_z, stride_delta_h, stride_delta_m,
    stride_dkz, stride_dkh, stride_dkn, stride_dkk,
    stride_dvz, stride_dvh, stride_dvn, stride_dvk,
    stride_q_idx_m,
    SM_SCALE: tl.constexpr,
    QK_HEAD_DIM: tl.constexpr,
    V_HEAD_DIM: tl.constexpr,
    BLOCK_M: tl.constexpr,
    BLOCK_N: tl.constexpr,
    NUM_KV_SUB_BLOCKS: tl.constexpr,
    NUM_TASKS,
    NUM_KV_BLOCKS,
    KV_HEAD,
    SPARSE_Q_BLOCK_SIZE: tl.constexpr,
    SPARSE_KV_BLOCK_SIZE: tl.constexpr,
    Q_LEN,
    KV_LEN,
    GQA_SHARED_HEADS,
    HAS_FULL_BLOCKS: tl.constexpr = True,
    USE_PACKED_PARTIAL_MASK: tl.constexpr = False,
    DROPOUT_VALUES=None,
    DROPOUT_TABLE=None,
    NUM_DROPOUT_BLOCKS=0,
    DROPOUT_THRESHOLD: tl.constexpr = 255,
    DROPOUT_SCALE: tl.constexpr = 1.0,
    HAS_DROPOUT: tl.constexpr = False,
    DROPOUT_BITPACKED: tl.constexpr = False,
    DKV_SCHEDULE=None, NUM_SCHEDULES=0, SPLIT_DKV: tl.constexpr = False,
):
    pid = tl.program_id(0).to(tl.int32)
    num_core = tl.num_programs(0).to(tl.int32)

    MATMUL_PRECISION = Q.dtype.element_ty
    KV_BLOCK_SIZE: tl.constexpr = BLOCK_N * NUM_KV_SUB_BLOCKS

    offs_k = tl.arange(0, QK_HEAD_DIM)
    offs_v = tl.arange(0, V_HEAD_DIM)

    for task_id in range(pid, NUM_TASKS, num_core):
        if SPLIT_DKV:
            schedule_id = task_id % NUM_SCHEDULES
            kv_start_block = tl.load(DKV_SCHEDULE + schedule_id * 5)
            partial_begin = tl.load(DKV_SCHEDULE + schedule_id * 5 + 1)
            partial_end = tl.load(DKV_SCHEDULE + schedule_id * 5 + 2)
            full_begin = tl.load(DKV_SCHEDULE + schedule_id * 5 + 3)
            full_end = tl.load(DKV_SCHEDULE + schedule_id * 5 + 4)
            off_z = (task_id // NUM_SCHEDULES) // KV_HEAD
            off_hkv = (task_id // NUM_SCHEDULES) % KV_HEAD
        else:
            kv_start_block = task_id % NUM_KV_BLOCKS
            off_z = (task_id // NUM_KV_BLOCKS) // KV_HEAD
            off_hkv = (task_id // NUM_KV_BLOCKS) % KV_HEAD

        off_z = off_z.to(tl.int64)
        off_hkv = off_hkv.to(tl.int64)

        k_offset = off_z * stride_kz + off_hkv * stride_kh
        v_offset = off_z * stride_vz + off_hkv * stride_vh
        dk_offset = off_z * stride_dkz + off_hkv * stride_dkh
        dv_offset = off_z * stride_dvz + off_hkv * stride_dvh

        K_ptr = K + k_offset
        V_ptr = V + v_offset
        DK_ptr = DK + dk_offset
        DV_ptr = DV + dv_offset
        if SPLIT_DKV:
            # Each task exclusively owns its partial-result tile.
            shift = (schedule_id.to(tl.int64) - kv_start_block) * KV_BLOCK_SIZE
            DK_ptr += shift * stride_dkn
            DV_ptr += shift * stride_dvn

        start_n_full = kv_start_block * KV_BLOCK_SIZE

        sparse_q_multiple = SPARSE_Q_BLOCK_SIZE // BLOCK_M
        sparse_kv_multiple = SPARSE_KV_BLOCK_SIZE // KV_BLOCK_SIZE

        kv_sparse_idx = kv_start_block // sparse_kv_multiple
        sparse_q_num_blks_offset = kv_sparse_idx
        sparse_q_idx_offset = kv_sparse_idx * stride_q_idx_m

        for kv_sub in range(NUM_KV_SUB_BLOCKS):
            sub_offset = kv_sub * BLOCK_N
            start_n = start_n_full + sub_offset
            offs_n = start_n + tl.arange(0, BLOCK_N)
            k = tl.load(
                K_ptr + offs_n[:, None] * stride_kn + offs_k[None, :] * stride_kk,
                mask=(offs_n[:, None] < KV_LEN) & (offs_k[None, :] < QK_HEAD_DIM),
                other=0.0,
            )
            v = tl.load(
                V_ptr + offs_n[:, None] * stride_vn + offs_v[None, :] * stride_vk,
                mask=(offs_n[:, None] < KV_LEN) & (offs_v[None, :] < V_HEAD_DIM),
                other=0.0,
            )

            for off_g in range(0, GQA_SHARED_HEADS):
                dk_acc = tl.zeros([BLOCK_N, QK_HEAD_DIM], tl.float32)
                dv_acc = tl.zeros([BLOCK_N, V_HEAD_DIM], tl.float32)
                off_hq = off_hkv * GQA_SHARED_HEADS + off_g
                off_hq = off_hq.to(tl.int64)

                q_offset = off_z * stride_qz + off_hq * stride_qh
                do_offset = off_z * stride_doz + off_hq * stride_doh
                dq_offset = off_z * stride_qz + off_hq * stride_qh
                lse_offset = off_z * stride_lse_z + off_hq * stride_lse_h
                delta_offset = off_z * stride_delta_z + off_hq * stride_delta_h

                Q_h = Q + q_offset
                DQ_h = DQ + dq_offset
                DO_h = DO + do_offset
                LSE_h = LSE + lse_offset
                DELTA_h = DELTA + delta_offset

                q_indices = Q_IDX + sparse_q_idx_offset
                q_num_blocks = tl.load(Q_NUM_BLKS + sparse_q_num_blks_offset)
                block_m_end = tl.minimum(
                    q_num_blocks * sparse_q_multiple,
                    tl.maximum(tl.cdiv(Q_LEN, BLOCK_M), 1, propagate_nan=True), propagate_nan=tl.PropagateNan.ALL
                )
                block_m_begin = 0
                if SPLIT_DKV:
                    block_m_begin = partial_begin * sparse_q_multiple
                    block_m_end = tl.minimum(block_m_end, partial_end * sparse_q_multiple)
                for start_m in range(block_m_begin, block_m_end):
                    blk_idx_in_list = start_m // sparse_q_multiple
                    q_block = tl.load(q_indices + blk_idx_in_list)
                    q_start = q_block * SPARSE_Q_BLOCK_SIZE + (start_m % sparse_q_multiple) * BLOCK_M
                    offs_m = q_start + tl.arange(0, BLOCK_M)
                    q_sparse_idx = q_block

                    dk_tile, dv_tile = bwd_dkdv_block_mn(
                        Q_h, DO_h, DQ_h, DK_ptr, DELTA_h, LSE_h, DV_ptr,
                        DENSE_MASK, stride_mask_m, stride_mask_n,
                        PARTIAL_MASK_PACKED, stride_partial_p, stride_partial_m, stride_partial_n,
                        PARTIAL_BLOCK_TABLE, stride_partial_table_m, stride_partial_table_n,
                        k, v, Q_LEN, KV_LEN,
                        off_z, off_hq, off_hkv, offs_n, offs_m, start_m, q_sparse_idx, kv_sparse_idx,
                        kv_sub + (kv_start_block % sparse_kv_multiple) * NUM_KV_SUB_BLOCKS, offs_k, offs_v,
                        stride_qm, stride_qk, stride_dom, stride_dok, stride_qm, stride_qk,
                        stride_dvn, stride_dvk, stride_dkn, stride_dkk,
                        MATMUL_PRECISION,
                        SM_SCALE,
                        SPARSE_Q_BLOCK_SIZE=SPARSE_Q_BLOCK_SIZE,
                        SPARSE_KV_BLOCK_SIZE=SPARSE_KV_BLOCK_SIZE,
                        QK_HEAD_DIM=QK_HEAD_DIM,
                        V_HEAD_DIM=V_HEAD_DIM,
                        BLOCK_M=BLOCK_M,
                        BLOCK_N=BLOCK_N,
                        IS_FULL_BLOCKS=False,
                        USE_PACKED_PARTIAL_MASK=USE_PACKED_PARTIAL_MASK,
                        DROPOUT_VALUES=DROPOUT_VALUES, DROPOUT_TABLE=DROPOUT_TABLE,
                        NUM_DROPOUT_BLOCKS=NUM_DROPOUT_BLOCKS, Q_HEAD=KV_HEAD * GQA_SHARED_HEADS,
                        DROPOUT_THRESHOLD=DROPOUT_THRESHOLD, DROPOUT_SCALE=DROPOUT_SCALE,
                        HAS_DROPOUT=HAS_DROPOUT, DROPOUT_BITPACKED=DROPOUT_BITPACKED,
                    )
                    dk_acc += dk_tile
                    dv_acc += dv_tile

                if HAS_FULL_BLOCKS:
                    q_indices = FULL_Q_IDX + sparse_q_idx_offset
                    q_num_blocks = tl.load(FULL_Q_NUM_BLKS + sparse_q_num_blks_offset)
                    block_m_end = tl.minimum(
                        q_num_blocks * sparse_q_multiple,
                        tl.maximum(tl.cdiv(Q_LEN, BLOCK_M), 1, propagate_nan=True), propagate_nan=tl.PropagateNan.ALL
                    )

                    block_m_begin = 0
                    if SPLIT_DKV:
                        block_m_begin = full_begin * sparse_q_multiple
                        block_m_end = tl.minimum(block_m_end, full_end * sparse_q_multiple)
                    for start_m in range(block_m_begin, block_m_end):
                        blk_idx_in_list = start_m // sparse_q_multiple
                        q_block = tl.load(q_indices + blk_idx_in_list)
                        q_start = q_block * SPARSE_Q_BLOCK_SIZE + (start_m % sparse_q_multiple) * BLOCK_M
                        offs_m = q_start + tl.arange(0, BLOCK_M)

                        dk_tile, dv_tile = bwd_dkdv_block_mn(
                            Q_h, DO_h, DQ_h, DK_ptr, DELTA_h, LSE_h, DV_ptr,
                            DENSE_MASK, stride_mask_m, stride_mask_n,
                            PARTIAL_MASK_PACKED, stride_partial_p, stride_partial_m, stride_partial_n,
                            PARTIAL_BLOCK_TABLE, stride_partial_table_m, stride_partial_table_n,
                            k, v, Q_LEN, KV_LEN,
                            off_z, off_hq, off_hkv, offs_n, offs_m, start_m, q_block, kv_sparse_idx,
                            kv_sub + (kv_start_block % sparse_kv_multiple) * NUM_KV_SUB_BLOCKS, offs_k, offs_v,
                            stride_qm, stride_qk, stride_dom, stride_dok, stride_qm, stride_qk,
                            stride_dvn, stride_dvk, stride_dkn, stride_dkk,
                            MATMUL_PRECISION,
                            SM_SCALE,
                            SPARSE_Q_BLOCK_SIZE=SPARSE_Q_BLOCK_SIZE,
                            SPARSE_KV_BLOCK_SIZE=SPARSE_KV_BLOCK_SIZE,
                            QK_HEAD_DIM=QK_HEAD_DIM,
                            V_HEAD_DIM=V_HEAD_DIM,
                            BLOCK_M=BLOCK_M,
                            BLOCK_N=BLOCK_N,
                            IS_FULL_BLOCKS=True,
                            USE_PACKED_PARTIAL_MASK=USE_PACKED_PARTIAL_MASK,
                            DROPOUT_VALUES=DROPOUT_VALUES, DROPOUT_TABLE=DROPOUT_TABLE,
                            NUM_DROPOUT_BLOCKS=NUM_DROPOUT_BLOCKS, Q_HEAD=KV_HEAD * GQA_SHARED_HEADS,
                            DROPOUT_THRESHOLD=DROPOUT_THRESHOLD, DROPOUT_SCALE=DROPOUT_SCALE,
                            HAS_DROPOUT=HAS_DROPOUT, DROPOUT_BITPACKED=DROPOUT_BITPACKED,
                        )
                        dk_acc += dk_tile
                        dv_acc += dv_tile

                # Scale the FP32 Q-shard sum once, before combining GQA heads,
                # instead of scaling every Q tile's dV matmul result.
                if HAS_DROPOUT:
                    dv_acc *= DROPOUT_SCALE
                # One program owns this tile for all GQA heads. Accumulate in
                # ascending head order with ordinary loads/stores, never atomics.
                dk_dst = DK_ptr + offs_n[:, None] * stride_dkn + offs_k[None, :] * stride_dkk
                dv_dst = DV_ptr + offs_n[:, None] * stride_dvn + offs_v[None, :] * stride_dvk
                dk_valid = (offs_n[:, None] < KV_LEN) & (offs_k[None, :] < QK_HEAD_DIM)
                dv_valid = (offs_n[:, None] < KV_LEN) & (offs_v[None, :] < V_HEAD_DIM)
                if off_g > 0:
                    dk_acc += tl.load(dk_dst, mask=dk_valid, other=0.0)
                tl.store(dk_dst, dk_acc, mask=dk_valid)
                if off_g > 0:
                    dv_acc += tl.load(dv_dst, mask=dv_valid, other=0.0)
                tl.store(dv_dst, dv_acc, mask=dv_valid)


@triton.jit
def bwd_dkdv_block_mn(
    Q, DO, DQ, DK_ptr, DELTA, LSE, DV_ptr,
    DENSE_MASK, stride_mask_m, stride_mask_n,
    PARTIAL_MASK_PACKED, stride_partial_p, stride_partial_m, stride_partial_n,
    PARTIAL_BLOCK_TABLE, stride_partial_table_m, stride_partial_table_n,
    k, v, Q_LEN, KV_LEN,
    off_z, off_hq, off_hkv, offs_n, offs_m, start_m, q_sparse_idx, kv_sparse_idx, kv_sub, offs_k, offs_v,
    stride_qm, stride_qk, stride_dom, stride_dok, stride_dqm, stride_dqd,
    stride_dvn, stride_dvk, stride_dkn, stride_dkk,
    MATMUL_PRECISION,
    SM_SCALE: tl.constexpr,
    SPARSE_Q_BLOCK_SIZE: tl.constexpr,
    SPARSE_KV_BLOCK_SIZE: tl.constexpr,
    QK_HEAD_DIM: tl.constexpr,
    V_HEAD_DIM: tl.constexpr,
    BLOCK_M: tl.constexpr,
    BLOCK_N: tl.constexpr,
    IS_FULL_BLOCKS: tl.constexpr,
    USE_PACKED_PARTIAL_MASK: tl.constexpr,
    Q_HEAD=0,
    DROPOUT_VALUES=None,
    DROPOUT_TABLE=None,
    NUM_DROPOUT_BLOCKS=0,
    DROPOUT_THRESHOLD: tl.constexpr = 255,
    DROPOUT_SCALE: tl.constexpr = 1.0,
    HAS_DROPOUT: tl.constexpr = False,
    DROPOUT_BITPACKED: tl.constexpr = False,
):
    q = tl.load(
        Q + offs_m[:, None] * stride_qm + offs_k[None, :] * stride_qk,
        mask=(offs_m[:, None] < Q_LEN) & (offs_k[None, :] < QK_HEAD_DIM),
        other=0.0,
    )
    do = tl.load(
        DO + offs_m[:, None] * stride_dom + offs_v[None, :] * stride_dok,
        mask=(offs_m[:, None] < Q_LEN) & (offs_v[None, :] < V_HEAD_DIM),
        other=0.0,
    )
    lse = tl.load(LSE + offs_m, mask=offs_m < Q_LEN, other=float("-inf"))
    lse = tl.where(lse == float("-inf"), 0.0, lse)

    qk = tl.dot(q, tl.trans(k), input_precision="ieee")
    qk *= SM_SCALE

    if not IS_FULL_BLOCKS:
        if USE_PACKED_PARTIAL_MASK:
            partial_block_idx = tl.load(
                PARTIAL_BLOCK_TABLE
                + q_sparse_idx * stride_partial_table_m
                + kv_sparse_idx * stride_partial_table_n
            )
            safe_partial_block_idx = tl.maximum(partial_block_idx, 0)
            sparse_q_multiple = SPARSE_Q_BLOCK_SIZE // BLOCK_M
            offs_m_in_block = (start_m % sparse_q_multiple) * BLOCK_M + tl.arange(0, BLOCK_M)
            offs_n_in_block = kv_sub * BLOCK_N + tl.arange(0, BLOCK_N)
            mask = load_packed_partial_mask(
                PARTIAL_MASK_PACKED,
                stride_partial_p,
                stride_partial_m,
                stride_partial_n,
                safe_partial_block_idx,
                offs_m_in_block,
                offs_n_in_block,
                SPARSE_Q_BLOCK_SIZE=SPARSE_Q_BLOCK_SIZE,
                SPARSE_KV_BLOCK_SIZE=SPARSE_KV_BLOCK_SIZE,
            )
            mask = mask & (partial_block_idx >= 0)
        else:
            mask = load_dense_mask(
                DENSE_MASK,
                stride_mask_m,
                stride_mask_n,
                offs_m,
                offs_n,
                Q_LEN=Q_LEN,
                KV_LEN=KV_LEN,
            )
        qk = tl.where(mask, qk, float("-inf"))
    p = tl.math.exp(qk - lse[:, None])

    p_for_dv = p
    if HAS_DROPOUT:
        keep = load_dropout_keep(
            DROPOUT_VALUES, DROPOUT_TABLE, NUM_DROPOUT_BLOCKS,
            off_z, off_hq, Q_HEAD,
            q_sparse_idx * SPARSE_Q_BLOCK_SIZE + (start_m % (SPARSE_Q_BLOCK_SIZE // BLOCK_M)) * BLOCK_M,
            kv_sparse_idx * SPARSE_KV_BLOCK_SIZE + kv_sub * BLOCK_N, KV_LEN,
            SPARSE_Q_BLOCK_SIZE, SPARSE_KV_BLOCK_SIZE, DROPOUT_THRESHOLD, BLOCK_M, BLOCK_N,
            COMPARE_IN_HALF=True, BITPACKED=DROPOUT_BITPACKED,
        )
        p_for_dv = tl.where(keep, p.to(MATMUL_PRECISION), tl.full((), 0, MATMUL_PRECISION))
    dv = tl.dot(tl.trans(p_for_dv.to(MATMUL_PRECISION)), do, input_precision="ieee")

    Di = tl.load(DELTA + offs_m, mask=offs_m < Q_LEN, other=0.0)
    dp = tl.dot(do, tl.trans(v), input_precision="ieee")
    if HAS_DROPOUT:
        dp = tl.where(keep, dp * DROPOUT_SCALE, 0.0)
    ds = (p * (dp - Di[:, None]))
    ds *= SM_SCALE

    dk = tl.dot(tl.trans(ds.to(MATMUL_PRECISION)), q, input_precision="ieee")
    return dk, dv


def _resolve_has_full_blocks(block_mask) -> bool:
    has_full = getattr(block_mask, "has_full_blocks", None)
    return True if has_full is None else bool(has_full)


def _prepare_block_mask_attrs(
    block_mask,
    q,
    kv_length,
    num_q_blocks,
    sparse_q_block_size,
    sparse_kv_block_size,
):
    kv_num_blks = block_mask.kv_num_blocks
    kv_idx = block_mask.kv_indices
    has_full_blocks = _resolve_has_full_blocks(block_mask)
    full_kv_num_blks = getattr(block_mask, "full_kv_num_blocks", None)
    if full_kv_num_blks is None:
        full_kv_num_blks = torch.zeros_like(kv_num_blks)
    full_kv_idx = getattr(block_mask, "full_kv_indices", None)
    if full_kv_idx is None:
        full_kv_idx = torch.zeros_like(kv_idx)

    q_num_blks = getattr(block_mask, "q_num_blocks", None)
    q_idx = getattr(block_mask, "q_indices", None)
    assert q_num_blks is not None, "q_num_blocks and q_indices must be provided"
    assert q_idx is not None, "q_indices must be provided"
    if kv_num_blks.ndim != 3 or kv_idx.ndim != 4 or q_num_blks.ndim != 3 or q_idx.ndim != 4:
        raise ValueError("NPU FlexAttention expects standard 3-D counts and 4-D BlockMask indices")
    if any(tensor.shape[0] != 1 or tensor.shape[1] != 1 for tensor in (kv_num_blks, kv_idx, q_num_blks, q_idx)):
        raise NotImplementedError(
            "NPU FlexAttention currently supports only batch/head-independent BlockMask tensors "
            "with leading shape [1, 1]"
        )
    full_q_num_blks = getattr(block_mask, "full_q_num_blocks", None)
    if full_q_num_blks is None:
        full_q_num_blks = torch.zeros_like(q_num_blks)
    full_q_idx = getattr(block_mask, "full_q_indices", None)
    if full_q_idx is None:
        full_q_idx = torch.zeros_like(q_idx)

    kv_num_blks = kv_num_blks.to(torch.int32).contiguous()
    kv_idx = kv_idx.to(torch.int32).contiguous()
    full_kv_num_blks = full_kv_num_blks.to(torch.int32).contiguous()
    full_kv_idx = full_kv_idx.to(torch.int32).contiguous()
    q_num_blks = q_num_blks.to(torch.int32).contiguous()
    q_idx = q_idx.to(torch.int32).contiguous()
    full_q_num_blks = full_q_num_blks.to(torch.int32).contiguous()
    full_q_idx = full_q_idx.to(torch.int32).contiguous()

    dense_mask = getattr(block_mask, "dense_mask", None)
    packed_partial_mask = getattr(block_mask, "packed_partial_mask", None)
    partial_mask_offsets = getattr(block_mask, "partial_mask_offsets", None)
    partial_block_table = getattr(block_mask, "partial_block_table", None)
    packed_attrs = (packed_partial_mask, partial_mask_offsets, partial_block_table)
    if any(attr is not None for attr in packed_attrs) and not all(attr is not None for attr in packed_attrs):
        raise ValueError(
            "NPU FlexAttention requires packed_partial_mask, partial_mask_offsets, "
            "and partial_block_table to be provided together"
        )
    use_packed_partial_mask = (
        packed_partial_mask is not None
        and partial_mask_offsets is not None
        and partial_block_table is not None
    )

    if dense_mask is None:
        if not use_packed_partial_mask:
            raise ValueError(
                "NPU FlexAttention partial blocks require either block_mask.dense_mask "
                "or the complete packed partial-mask attributes"
            )
        dense_mask = torch.zeros((1, 1, 1, 1), dtype=torch.bool, device=q.device)
    elif dense_mask.ndim != 4 or dense_mask.shape[-2] < q.shape[2] or dense_mask.shape[-1] < kv_length:
        raise ValueError(
            "block_mask.dense_mask must have shape [1, 1, Q, KV] covering the input lengths; "
            f"got {tuple(dense_mask.shape)} for Q={q.shape[2]}, KV={kv_length}"
        )
    dense_mask = dense_mask.contiguous()

    if use_packed_partial_mask:
        expected_kv_blocks = max(
            (kv_length + sparse_kv_block_size - 1) // sparse_kv_block_size, 1
        )
        if packed_partial_mask.ndim != 3 or tuple(packed_partial_mask.shape[-2:]) != (
            sparse_q_block_size,
            sparse_kv_block_size,
        ):
            raise ValueError(
                "packed_partial_mask must have shape "
                f"[P, {sparse_q_block_size}, {sparse_kv_block_size}], got "
                f"{tuple(packed_partial_mask.shape)}"
            )
        if tuple(partial_mask_offsets.shape) != (1, 1, num_q_blocks):
            raise ValueError(
                f"partial_mask_offsets must have shape [1, 1, {num_q_blocks}], got "
                f"{tuple(partial_mask_offsets.shape)}"
            )
        if tuple(partial_block_table.shape) != (num_q_blocks, expected_kv_blocks):
            raise ValueError(
                f"partial_block_table must have shape [{num_q_blocks}, {expected_kv_blocks}], got "
                f"{tuple(partial_block_table.shape)}"
            )
        packed_partial_mask = packed_partial_mask.contiguous()
        partial_mask_offsets = partial_mask_offsets.to(torch.int32).contiguous()
        partial_block_table = partial_block_table.to(torch.int32).contiguous()
    else:
        packed_partial_mask = torch.zeros(
            (1, sparse_q_block_size, sparse_kv_block_size),
            dtype=torch.bool,
            device=q.device,
        )
        partial_mask_offsets = torch.zeros(
            (1, 1, max(num_q_blocks, 1)),
            dtype=torch.int32,
            device=q.device,
        )
        partial_block_table = torch.full(
            (
                max(num_q_blocks, 1),
                max((kv_length + sparse_kv_block_size - 1) // sparse_kv_block_size, 1),
            ),
            -1,
            dtype=torch.int32,
            device=q.device,
        )

    return {
        "kv_num_blks": kv_num_blks,
        "kv_idx": kv_idx,
        "full_kv_num_blks": full_kv_num_blks,
        "full_kv_idx": full_kv_idx,
        "q_num_blks": q_num_blks,
        "q_idx": q_idx,
        "full_q_num_blks": full_q_num_blks,
        "full_q_idx": full_q_idx,
        "dense_mask": dense_mask,
        "packed_partial_mask": packed_partial_mask,
        "partial_mask_offsets": partial_mask_offsets,
        "partial_block_table": partial_block_table,
        "use_packed_partial_mask": use_packed_partial_mask,
        "has_full_blocks": has_full_blocks,
    }


def _validate_attention_inputs(q, k, v):
    if q.ndim != 4 or k.ndim != 4 or v.ndim != 4:
        raise ValueError(
            "NPU FlexAttention expects Q/K/V in [batch, heads, sequence, head_dim] layout"
        )
    Z, Hq, _, D = q.shape
    Zk, Hkv, N, Dk = k.shape
    Zv, Hv, Nv, Dv = v.shape
    if Z != Zk or Z != Zv:
        raise NotImplementedError(
            "NPU FlexAttention does not support broadcasting K/V across the batch dimension"
        )
    if Hkv != Hv or N != Nv:
        raise ValueError(f"incompatible K/V shapes: {tuple(k.shape)} and {tuple(v.shape)}")
    if D != Dk:
        raise ValueError(f"Q/K head dimensions must match, got {D} and {Dk}")
    if Hkv <= 0 or Hq % Hkv != 0:
        raise ValueError(f"query heads {Hq} must be divisible by KV heads {Hkv}")
    if q.device != k.device or q.device != v.device:
        raise ValueError("Q/K/V must be on the same device")
    if q.dtype != k.dtype or q.dtype != v.dtype:
        raise ValueError("Q/K/V must have the same dtype")
    for name, dim in (("QK", D), ("V", Dv)):
        if dim < 16 or dim & (dim - 1):
            raise NotImplementedError(
                f"NPU FlexAttention requires a power-of-two {name} head dimension >= 16, got {dim}"
            )


def flex_attention_fwd_impl(
    q: torch.Tensor,
    k: torch.Tensor,
    v: torch.Tensor,
    block_mask,
    sm_scale: Optional[float] = None,
    *, dropout=None, output_dtype=None, aux_output=None,
) -> Tuple[torch.Tensor, torch.Tensor]:
    _validate_attention_inputs(q, k, v)
    drop_values, drop_table, drop_blocks, drop_threshold, drop_scale, has_dropout, drop_bitpacked = (
        _prepare_dropout_args(q, k, block_mask, dropout)
    )
    Z, Hq, M, D = q.shape
    _, Hkv, N, Dv = k.shape

    GQA_SHARED_HEADS = Hq // Hkv
    if sm_scale is None:
        sm_scale = 1.0 / (D ** 0.5)

    BLOCK_M = TILE_BLOCK_SIZE
    BLOCK_N = TILE_BLOCK_SIZE
    SPARSE_Q_BLOCK_SIZE = TILE_BLOCK_SIZE
    SPARSE_KV_BLOCK_SIZE = TILE_BLOCK_SIZE

    num_q_blocks = (M + SPARSE_Q_BLOCK_SIZE - 1) // SPARSE_Q_BLOCK_SIZE

    output = torch.empty((Z, Hq, M, Dv), dtype=q.dtype if output_dtype is None else output_dtype, device=q.device)
    if aux_output is not None:
        if (
            aux_output.shape != output.shape or aux_output.device != q.device
            or aux_output.dtype != q.dtype or not aux_output.is_contiguous()
        ):
            raise ValueError("Auxiliary output must match the contiguous Q-dtype attention output")
    lse = torch.empty((Z, Hq, M), dtype=torch.float32, device=q.device)

    q = q.contiguous()
    k = k.contiguous()
    v = v.contiguous()

    bm = _prepare_block_mask_attrs(
        block_mask, q, N, num_q_blocks, SPARSE_Q_BLOCK_SIZE, SPARSE_KV_BLOCK_SIZE
    )

    num_q_tiles = triton.cdiv(M, BLOCK_M)
    num_tasks = num_q_tiles * Z * Hq
    grid, num_tasks = _persistent_launch_config(num_tasks)

    _flex_attention_v2_forward_leaf(
        [
            q,
            k,
            v,
            bm["kv_num_blks"],
            bm["kv_idx"],
            bm["full_kv_num_blks"],
            bm["full_kv_idx"],
            bm["dense_mask"],
            bm["packed_partial_mask"],
            bm["partial_mask_offsets"],
            drop_values, drop_table,
        ],
        [output, lse] if aux_output is None else [output, lse, aux_output],
        [
            bm["dense_mask"].stride(2),
            bm["dense_mask"].stride(3),
            bm["packed_partial_mask"].stride(0),
            bm["packed_partial_mask"].stride(1),
            bm["packed_partial_mask"].stride(2),
            bm["partial_mask_offsets"].stride(2),
            q.stride(0),
            q.stride(1),
            q.stride(2),
            q.stride(3),
            k.stride(0),
            k.stride(1),
            k.stride(2),
            k.stride(3),
            v.stride(0),
            v.stride(1),
            v.stride(2),
            v.stride(3),
            output.stride(0),
            output.stride(1),
            output.stride(2),
            output.stride(3),
            lse.stride(0),
            lse.stride(1),
            lse.stride(2),
            bm["kv_idx"].stride(2),
            D,
            Dv,
            BLOCK_M,
            BLOCK_N,
            num_tasks,
            num_q_tiles,
            Hq,
            SPARSE_Q_BLOCK_SIZE,
            SPARSE_KV_BLOCK_SIZE,
            M,
            N,
            GQA_SHARED_HEADS,
            drop_blocks, drop_threshold,
        ],
        [sm_scale, drop_scale],
        [bm["use_packed_partial_mask"], bm["has_full_blocks"], has_dropout, drop_bitpacked, aux_output is not None],
        list(grid),
    )

    return output, lse


@triton.jit
def _flex_attention_delta_kernel(
    output_ptr, DO, DELTA, ROWS: tl.constexpr, M: tl.constexpr,
    H: tl.constexpr, D: tl.constexpr,
    O0: tl.constexpr, O1: tl.constexpr, O2: tl.constexpr, O3: tl.constexpr,
    DO0: tl.constexpr, DO1: tl.constexpr, DO2: tl.constexpr, DO3: tl.constexpr,
    BLOCK_R: tl.constexpr, BLOCK_D: tl.constexpr, CONTIG: tl.constexpr,
):
    for tile in range(tl.program_id(0), tl.cdiv(ROWS, BLOCK_R), tl.num_programs(0)):
        # Widen before multiplication so large tensor offsets cannot wrap in int32.
        r = tile.to(tl.int64) * BLOCK_R + tl.arange(0, BLOCK_R)
        d = tl.arange(0, BLOCK_D).to(tl.int64)
        if CONTIG:
            # Flatten contiguous rows to avoid integer division in vector address generation.
            oo = r[:, None] * D + d[None, :]
            doo = oo
        else:
            z, h, m = r // (H * M), r // M % H, r % M
            oo = (z * O0 + h * O1 + m * O2)[:, None] + d[None, :] * O3
            doo = (z * DO0 + h * DO1 + m * DO2)[:, None] + d[None, :] * DO3
        valid = (r[:, None] < ROWS) & (d[None, :] < D)
        o = tl.load(output_ptr + oo, mask=valid, other=0).to(tl.float32)
        do = tl.load(DO + doo, mask=valid, other=0).to(tl.float32)
        delta = tl.sum(o * do, 1)
        tl.store(DELTA + r, delta, mask=r < ROWS)


@torch.library.custom_op("mojo_npu_triton_a5::flex_attention_v2_delta", mutates_args=("delta",))
def _flex_attention_delta_leaf(output: torch.Tensor, grad_output: torch.Tensor, delta: torch.Tensor) -> None:
    z, h, m, d = output.shape
    grid = (min(get_num_cores("vector"), triton.cdiv(z * h * m, 16)),)
    _flex_attention_delta_kernel[grid](
        output, grad_output, delta, z * h * m, m, h, d,
        *output.stride(), *grad_output.stride(),
        BLOCK_R=16, BLOCK_D=triton.next_power_of_2(d),
        CONTIG=output.is_contiguous() and grad_output.is_contiguous(),
        enable_fp_fusion=False,
    )


@_flex_attention_delta_leaf.register_fake
def _flex_attention_delta_leaf_fake(output, grad_output, delta):
    return None


def _compute_delta(output, grad_output):
    delta = torch.empty(output.shape[:-1], dtype=torch.float32, device=output.device)
    _flex_attention_delta_leaf(output, grad_output, delta)
    return delta


@triton.jit
def _merge_dkv_partials(
    DK_PART, DV_PART, DK, DV, RANGES,
    GROUPS: tl.constexpr, KV_LEN: tl.constexpr, PART_ROWS: tl.constexpr,
    D: tl.constexpr, DV_DIM: tl.constexpr, BLOCK_R: tl.constexpr,
):
    kv_blocks: tl.constexpr = (KV_LEN + 127) // 128
    subtiles: tl.constexpr = 128 // BLOCK_R
    for task in range(tl.program_id(0), GROUPS * kv_blocks * subtiles, tl.num_programs(0)):
        sub = task % subtiles
        kb = (task // subtiles) % kv_blocks
        group = task // (subtiles * kv_blocks)
        row = sub * BLOCK_R + tl.arange(0, BLOCK_R)
        dk_cols = tl.arange(0, D)
        dv_cols = tl.arange(0, DV_DIM)
        begin = tl.load(RANGES + kb * 2)
        end = tl.load(RANGES + kb * 2 + 1)
        valid = kb * 128 + row < KV_LEN
        dk_acc = tl.full((BLOCK_R, D), 0, tl.float32)
        dv_acc = tl.full((BLOCK_R, DV_DIM), 0, tl.float32)
        for shard in range(begin, end):
            src = group.to(tl.int64) * PART_ROWS + shard.to(tl.int64) * 128 + row
            dk_acc += tl.load(DK_PART + src[:, None] * D + dk_cols[None, :],
                              mask=valid[:, None] & (dk_cols[None, :] < D), other=0)
            dv_acc += tl.load(DV_PART + src[:, None] * DV_DIM + dv_cols[None, :],
                              mask=valid[:, None] & (dv_cols[None, :] < DV_DIM), other=0)
        dst = group.to(tl.int64) * KV_LEN + kb * 128 + row
        tl.store(DK + dst[:, None] * D + dk_cols[None, :], dk_acc,
                 mask=valid[:, None] & (dk_cols[None, :] < D))
        tl.store(DV + dst[:, None] * DV_DIM + dv_cols[None, :], dv_acc,
                 mask=valid[:, None] & (dv_cols[None, :] < DV_DIM))


@torch.library.custom_op("mojo_npu_triton_a5::flex_attention_merge_dkv", mutates_args=("outputs",))
def _flex_attention_merge_dkv_leaf(
    partials: list[torch.Tensor], outputs: list[torch.Tensor], ranges: torch.Tensor,
) -> None:
    z, h, n, d = outputs[0].shape
    dv_dim = outputs[1].shape[-1]
    grid = (min(get_num_cores("vector"), z * h * triton.cdiv(n, 128) * 8),)
    _merge_dkv_partials[grid](
        *partials, *outputs, ranges, z * h, n, partials[0].shape[2], d, dv_dim, BLOCK_R=16,
    )


@_flex_attention_merge_dkv_leaf.register_fake
def _flex_attention_merge_dkv_leaf_fake(partials, outputs, ranges):
    return None


def flex_attention_bwd_impl(
    grad_output: torch.Tensor,
    q: torch.Tensor,
    k: torch.Tensor,
    v: torch.Tensor,
    output: torch.Tensor,
    lse: torch.Tensor,
    block_mask,
    sm_scale: Optional[float] = None,
    *, dropout=None,
) -> Tuple[torch.Tensor, torch.Tensor, torch.Tensor]:
    _validate_attention_inputs(q, k, v)
    drop_values, drop_table, drop_blocks, drop_threshold, drop_scale, has_dropout, drop_bitpacked = (
        _prepare_dropout_args(q, k, block_mask, dropout)
    )
    Z, Hq, M, D = q.shape
    _, Hkv, N, Dv = k.shape
    GQA_SHARED_HEADS = Hq // Hkv
    if sm_scale is None:
        sm_scale = 1.0 / (D ** 0.5)

    grad_output = grad_output.contiguous()
    delta = _compute_delta(output, grad_output)

    SPARSE_Q_BLOCK_SIZE = TILE_BLOCK_SIZE
    SPARSE_KV_BLOCK_SIZE = TILE_BLOCK_SIZE
    num_q_blocks = triton.cdiv(M, SPARSE_Q_BLOCK_SIZE)

    bm = _prepare_block_mask_attrs(
        block_mask, q, N, num_q_blocks, SPARSE_Q_BLOCK_SIZE, SPARSE_KV_BLOCK_SIZE
    )

    dq = torch.empty_like(q)
    split_layout = None if dropout is None else dropout.layout
    split_schedule = None if split_layout is None else split_layout.dkv_schedule
    split_ranges = None if split_layout is None else split_layout.dkv_ranges
    split_count = 0 if split_layout is None else split_layout.dkv_num_tasks
    split_dkv = split_schedule is not None and split_count > 0
    workspace_rows = split_count * TILE_BLOCK_SIZE if split_dkv else N
    dk = torch.empty((Z, Hkv, workspace_rows, D), dtype=torch.float32, device=k.device)
    dv = torch.empty((Z, Hkv, workspace_rows, Dv), dtype=torch.float32, device=v.device)

    BLOCK_M_DQ = TILE_BLOCK_SIZE
    BLOCK_N_DQ = TILE_BLOCK_SIZE
    NUM_KV_SUB_BLOCKS_VAL = SPARSE_KV_BLOCK_SIZE // BLOCK_N_DQ
    num_q_tiles_dq = triton.cdiv(M, BLOCK_M_DQ)
    grid_dq, num_tasks_dq = _persistent_launch_config(num_q_tiles_dq * Z * Hq)
    _flex_attention_v2_dq_leaf(
        [
            q,
            k,
            v,
            grad_output,
            lse,
            delta,
            bm["kv_num_blks"],
            bm["kv_idx"],
            bm["full_kv_num_blks"],
            bm["full_kv_idx"],
            bm["dense_mask"],
            bm["packed_partial_mask"],
            bm["partial_mask_offsets"],
            bm["partial_block_table"],
            drop_values, drop_table,
        ],
        [dq],
        [
            bm["dense_mask"].stride(2),
            bm["dense_mask"].stride(3),
            bm["packed_partial_mask"].stride(0),
            bm["packed_partial_mask"].stride(1),
            bm["packed_partial_mask"].stride(2),
            bm["partial_mask_offsets"].stride(2),
            bm["partial_block_table"].stride(0),
            bm["partial_block_table"].stride(1),
            q.stride(0),
            q.stride(1),
            q.stride(2),
            q.stride(3),
            k.stride(0),
            k.stride(1),
            k.stride(2),
            k.stride(3),
            v.stride(0),
            v.stride(1),
            v.stride(2),
            v.stride(3),
            grad_output.stride(0),
            grad_output.stride(1),
            grad_output.stride(2),
            grad_output.stride(3),
            lse.stride(0),
            lse.stride(1),
            lse.stride(2),
            delta.stride(0),
            delta.stride(1),
            delta.stride(2),
            dq.stride(0),
            dq.stride(1),
            dq.stride(2),
            dq.stride(3),
            bm["kv_idx"].stride(2),
            D,
            Dv,
            BLOCK_M_DQ,
            BLOCK_N_DQ,
            NUM_KV_SUB_BLOCKS_VAL,
            num_tasks_dq,
            num_q_tiles_dq,
            Hq,
            SPARSE_Q_BLOCK_SIZE,
            SPARSE_KV_BLOCK_SIZE,
            M,
            N,
            GQA_SHARED_HEADS,
            drop_blocks, drop_threshold,
        ],
        [sm_scale, drop_scale],
        [bm["use_packed_partial_mask"], bm["has_full_blocks"], has_dropout, drop_bitpacked],
        list(grid_dq),
    )

    BLOCK_M_DKDV, BLOCK_N_DKDV, dkv_intra_cache = _dkdv_config(D, Dv, has_dropout)
    NUM_KV_SUB_BLOCKS_VAL = SPARSE_KV_BLOCK_SIZE // BLOCK_N_DKDV
    num_kv_blocks = triton.cdiv(N, SPARSE_KV_BLOCK_SIZE)
    # Small no-dropout GQA workloads otherwise leave Cube cores idle after
    # replacing atomic head accumulation with deterministic KV-tile ownership.
    # Split KV ownership into independent 64-column tiles, without a workspace
    # merge or any dropout work. Large/no-GQA workloads retain their old tile.
    if (
        not has_dropout and not split_dkv and GQA_SHARED_HEADS > 1 and D == Dv == 128
        and N > 64 and num_kv_blocks * Z * Hkv < _get_num_aicore()
    ):
        BLOCK_N_DKDV = 64
        NUM_KV_SUB_BLOCKS_VAL = 1
        num_kv_blocks = triton.cdiv(N, BLOCK_N_DKDV)
    grid_dkv, num_tasks_dkv = _persistent_launch_config((split_count if split_dkv else num_kv_blocks) * Z * Hkv)
    _flex_attention_v2_dkdv_leaf(
        [
            q,
            k,
            v,
            grad_output,
            lse,
            delta,
            bm["q_num_blks"],
            bm["q_idx"],
            bm["full_q_num_blks"],
            bm["full_q_idx"],
            bm["dense_mask"],
            bm["packed_partial_mask"],
            bm["partial_mask_offsets"],
            bm["partial_block_table"],
            dq,
            drop_values, drop_table, split_schedule if split_dkv else q,
        ],
        [dk, dv],
        [
            bm["dense_mask"].stride(2),
            bm["dense_mask"].stride(3),
            bm["packed_partial_mask"].stride(0),
            bm["packed_partial_mask"].stride(1),
            bm["packed_partial_mask"].stride(2),
            bm["partial_mask_offsets"].stride(2),
            bm["partial_block_table"].stride(0),
            bm["partial_block_table"].stride(1),
            q.stride(0),
            q.stride(1),
            q.stride(2),
            q.stride(3),
            k.stride(0),
            k.stride(1),
            k.stride(2),
            k.stride(3),
            v.stride(0),
            v.stride(1),
            v.stride(2),
            v.stride(3),
            grad_output.stride(0),
            grad_output.stride(1),
            grad_output.stride(2),
            grad_output.stride(3),
            lse.stride(0),
            lse.stride(1),
            lse.stride(2),
            delta.stride(0),
            delta.stride(1),
            delta.stride(2),
            dk.stride(0),
            dk.stride(1),
            dk.stride(2),
            dk.stride(3),
            dv.stride(0),
            dv.stride(1),
            dv.stride(2),
            dv.stride(3),
            bm["q_idx"].stride(2),
            D,
            Dv,
            BLOCK_M_DKDV,
            BLOCK_N_DKDV,
            NUM_KV_SUB_BLOCKS_VAL,
            num_tasks_dkv,
            num_kv_blocks,
            Hkv,
            SPARSE_Q_BLOCK_SIZE,
            SPARSE_KV_BLOCK_SIZE,
            M,
            N,
            GQA_SHARED_HEADS,
            drop_blocks, drop_threshold, split_count, dkv_intra_cache,
        ],
        [sm_scale, drop_scale],
        [bm["use_packed_partial_mask"], bm["has_full_blocks"], has_dropout, drop_bitpacked, split_dkv],
        list(grid_dkv),
    )

    if split_dkv:
        dk_result = torch.empty(k.shape, dtype=k.dtype, device=k.device)
        dv_result = torch.empty(v.shape, dtype=v.dtype, device=v.device)
        _flex_attention_merge_dkv_leaf([dk, dv], [dk_result, dv_result], split_ranges)
        return dq.to(q.dtype), dk_result, dv_result
    return dq.to(q.dtype), dk.to(k.dtype), dv.to(v.dtype)


# ============================================================================
# BlockMask construction: streaming stripe packed-block builders
# ============================================================================
# Two construction strategies for building a packed BlockMask:
#
#   1. Kernel-based (_build_packed_block_mask_streaming):
#      Uses custom Triton create_mask_kernel + block_classify_kernel for fused
#      mask generation and classification.  Caller supplies a mask_type_str
#      (e.g. "sparse", "full") and a *problem* dict with pre-built index tables.
#
#   2. mask_mod-based (create_block_mask_patched):
#      Evaluates an arbitrary mask_mod callable ``(b, h, q_idx, kv_idx) -> bool``
#      in streaming stripes, then classifies and packs partial blocks.
#      API mirrors torch.nn.attention.flex_attention.create_block_mask.
# ============================================================================

# -- Constants ---------------------------------------------------------------
_MB = 1024 ** 2

# Target memory per stripe for streaming mask build (~256 MB of bool dense mask).
_STRIPE_TARGET_BYTES = 256 * _MB

# During mask_mod evaluation, each intermediate tensor is [stripe_q, KV_LEN] in
# int64 (8 bytes).  A typical mask_mod creates ~4 simultaneous intermediates, so
# we budget ~8 bytes per (q, kv) element when sizing each stripe.
_BYTES_PER_MASK_ELEMENT = 8

# Tile size used by the kernel-based mask generation path.
MASK_BLOCK_SIZE = TILE_BLOCK_SIZE


# -- Utility helpers ---------------------------------------------------------
def _round_up_to_multiple(x, multiple):
    """Round *x* up to the nearest multiple of *multiple*."""
    return (x + multiple - 1) // multiple * multiple


def _get_num_vector_core():
    """Return the number of vector cores on the current NPU device (fallback 1)."""
    try:
        dev = torch.npu.current_device()
        props = triton.runtime.driver.active.utils.get_device_properties(dev)
        return max(int(props.get("num_vectorcore", 1)), 1)
    except Exception:
        return 1


# ============================================================================
# Kernel: create_mask_kernel
# ============================================================================
@triton.jit
def create_mask_kernel(
    OUT, stride_ob, stride_oh, stride_oq, stride_ok: tl.constexpr,
    BLOCK_FLAGS, stride_bf_q, stride_bf_k,
    TABLE1, stride_t1, TABLE2, stride_t2, TABLE3, stride_t3,
    Q_LEN, KV_LEN, W, G,
    Q_OFFSET,
    MASK_TYPE: tl.constexpr, TILE: tl.constexpr,
    STORE_MASK: tl.constexpr, CLASSIFY: tl.constexpr,
):
    pid_q = tl.program_id(0).to(tl.int32)
    pid_k = tl.program_id(1).to(tl.int32)
    q_off = Q_OFFSET + pid_q * TILE + tl.arange(0, TILE)
    k_off = pid_k * TILE + tl.arange(0, TILE)
    q_idx = q_off[:, None]
    k_idx = k_off[None, :]

    if MASK_TYPE == 0:
        seg_q = tl.load(TABLE1 + q_idx * stride_t1, mask=q_idx < Q_LEN, other=0)
        seg_k = tl.load(TABLE1 + k_idx * stride_t1, mask=k_idx < KV_LEN, other=-1)
        same_doc = seg_q == seg_k
        causal = q_idx >= k_idx
        window = causal & ((q_idx - k_idx) <= W)
        ds_q = tl.load(TABLE2 + q_idx * stride_t2, mask=q_idx < Q_LEN, other=0)
        glob = causal & (k_idx >= ds_q) & (k_idx < ds_q + G)
        sparse = same_doc & (window | glob)
        mod_q = tl.load(TABLE3 + q_idx * stride_t3, mask=q_idx < Q_LEN, other=-1)
        mod_k = tl.load(TABLE3 + k_idx * stride_t3, mask=k_idx < KV_LEN, other=-2)
        is_img = mod_q > 0
        same_img = is_img & (mod_q == mod_k)
        result = sparse | same_img
    elif MASK_TYPE == 1:
        vid_q = tl.load(TABLE1 + q_idx * stride_t1, mask=q_idx < Q_LEN, other=-1)
        vid_k = tl.load(TABLE1 + k_idx * stride_t1, mask=k_idx < KV_LEN, other=-2)
        same_doc = vid_q == vid_k
        fid_q = tl.load(TABLE2 + q_idx * stride_t2, mask=q_idx < Q_LEN, other=0)
        fid_k = tl.load(TABLE2 + k_idx * stride_t2, mask=k_idx < KV_LEN, other=-1)
        frame_causal = fid_q >= fid_k
        result = same_doc & frame_causal
    elif MASK_TYPE == 2:
        vid_q = tl.load(TABLE1 + q_idx * stride_t1, mask=q_idx < Q_LEN, other=-1)
        vid_k = tl.load(TABLE1 + k_idx * stride_t1, mask=k_idx < KV_LEN, other=-2)
        same_video = vid_q == vid_k
        fid_q = tl.load(TABLE2 + q_idx * stride_t2, mask=q_idx < Q_LEN, other=0)
        fid_k = tl.load(TABLE2 + k_idx * stride_t2, mask=k_idx < KV_LEN, other=-1)
        same_frame = fid_q == fid_k
        prev_frame = fid_q > fid_k
        result = same_video & (same_frame | prev_frame)
    elif MASK_TYPE == 3:
        causal = q_idx >= k_idx
        mod_q = tl.load(TABLE1 + q_idx * stride_t1, mask=q_idx < Q_LEN, other=-1)
        mod_k = tl.load(TABLE1 + k_idx * stride_t1, mask=k_idx < KV_LEN, other=-2)
        is_video = mod_q > 0
        same_video = is_video & (mod_q == mod_k)
        result = causal | same_video
    elif MASK_TYPE == 4:
        seg_q = tl.load(TABLE1 + q_idx * stride_t1, mask=q_idx < Q_LEN, other=-1)
        seg_k = tl.load(TABLE1 + k_idx * stride_t1, mask=k_idx < KV_LEN, other=-2)
        same_doc = seg_q == seg_k
        causal = q_idx >= k_idx
        samedoc_causal = same_doc & causal
        mod_q = tl.load(TABLE3 + q_idx * stride_t3, mask=q_idx < Q_LEN, other=-1)
        mod_k = tl.load(TABLE3 + k_idx * stride_t3, mask=k_idx < KV_LEN, other=-2)
        is_img = mod_q > 0
        same_img = is_img & (mod_q == mod_k)
        result = samedoc_causal | same_img
    else:
        result = tl.full([TILE, TILE], False, tl.int1)

    valid = (q_idx < Q_LEN) & (k_idx < KV_LEN)

    if STORE_MASK:
        q_store = (pid_q * TILE + tl.arange(0, TILE))[:, None]
        ptrs = OUT + q_store * stride_oq + k_idx * stride_ok
        tl.store(ptrs, result, mask=valid)

    if CLASSIFY:
        result_i = tl.where(valid, result.to(tl.int32), 0)
        has_one = tl.max(tl.max(result_i, axis=1), axis=0) != 0
        all_one = tl.min(tl.min(result_i, axis=1), axis=0) != 0
        flag = tl.where(all_one, 2, tl.where(has_one, 1, 0))
        tl.store(BLOCK_FLAGS + pid_q * stride_bf_q + pid_k * stride_bf_k, flag.to(tl.int8))


_MASK_TYPE_MAP = {
    "sparse": 0, "stair": 1, "video_stair": 2,
    "cross_sample_causal_video_bidir": 3, "full": 4,
}


def _get_mask_kernel_tables(problem, mt):
    """Extract table tensors, strides, and W/G values for create_mask_kernel based on mask type."""
    device = problem["q"].device
    t1 = t2 = t3 = torch.empty(0, device=device)
    s1 = s2 = s3 = 0
    W_val = G_val = 0

    if mt == 0:
        t1, t2, t3 = problem["segment_ids"], problem["doc_start"], problem["modality"]
        s1, s2, s3 = t1.stride(0), t2.stride(0), t3.stride(0)
        W_val = problem["sliding_window"]
        G_val = problem["global_window"]
    elif mt in (1, 2):
        t1, t2 = problem["video_ids"], problem["frame_ids"]
        s1, s2 = t1.stride(0), t2.stride(0)
    elif mt == 3:
        t1 = problem["modality"]
        s1 = t1.stride(0)
    elif mt == 4:
        t1, t3 = problem["segment_ids"], problem["modality"]
        s1, s3 = t1.stride(0), t3.stride(0)

    return t1, s1, t2, s2, t3, s3, W_val, G_val


def triton_create_mask(problem, mask_type, tile_size=MASK_BLOCK_SIZE):
    """Generate a dense ``[1, 1, SEQ_LEN, SEQ_LEN]`` bool mask via create_mask_kernel."""
    SEQ_LEN = problem["total_s"]
    device = problem["q"].device
    out = torch.empty(1, 1, SEQ_LEN, SEQ_LEN, dtype=torch.bool, device=device)
    mt = _MASK_TYPE_MAP[mask_type]
    t1, s1, t2, s2, t3, s3, W_val, G_val = _get_mask_kernel_tables(problem, mt)

    n_tiles = (SEQ_LEN + tile_size - 1) // tile_size
    dummy_flags = torch.empty(0, dtype=torch.int8, device=device)
    create_mask_kernel[(n_tiles, n_tiles)](
        out, out.stride(0), out.stride(1), out.stride(2), out.stride(3),
        dummy_flags, 0, 0,
        t1, s1, t2, s2, t3, s3,
        SEQ_LEN, SEQ_LEN, W_val, G_val,
        Q_OFFSET=0,
        MASK_TYPE=mt, TILE=tile_size,
        STORE_MASK=True, CLASSIFY=False,
    )
    return out


def _run_create_mask_stripe(
    problem,
    mask_type,
    q_start,
    q_height,
    kv_len_padded,
    out_buffer,
    flags_buffer=None,
    tile_size=MASK_BLOCK_SIZE,
):
    """Run create_mask_kernel for a stripe.

    If flags_buffer is provided, also classify blocks (CLASSIFY=True).
    Otherwise only generate the dense mask (CLASSIFY=False).
    """
    SEQ_LEN = problem["total_s"]
    device = problem["q"].device
    mt = _MASK_TYPE_MAP[mask_type]
    t1, s1, t2, s2, t3, s3, W_val, G_val = _get_mask_kernel_tables(problem, mt)

    n_tiles_q = q_height // tile_size
    n_tiles_k = kv_len_padded // tile_size

    if flags_buffer is not None:
        create_mask_kernel[(n_tiles_q, n_tiles_k)](
            out_buffer, out_buffer.stride(0), out_buffer.stride(1), out_buffer.stride(2), out_buffer.stride(3),
            flags_buffer, flags_buffer.stride(0), flags_buffer.stride(1),
            t1, s1, t2, s2, t3, s3,
            SEQ_LEN, SEQ_LEN, W_val, G_val,
            Q_OFFSET=q_start,
            MASK_TYPE=mt, TILE=tile_size,
            STORE_MASK=True, CLASSIFY=True,
        )
    else:
        dummy_flags = torch.empty(0, dtype=torch.int8, device=device)
        create_mask_kernel[(n_tiles_q, n_tiles_k)](
            out_buffer, out_buffer.stride(0), out_buffer.stride(1), out_buffer.stride(2), out_buffer.stride(3),
            dummy_flags, 0, 0,
            t1, s1, t2, s2, t3, s3,
            SEQ_LEN, SEQ_LEN, W_val, G_val,
            Q_OFFSET=q_start,
            MASK_TYPE=mt, TILE=tile_size,
            STORE_MASK=True, CLASSIFY=False,
        )


# ============================================================================
# Kernel: block_classify_kernel
# ============================================================================
@triton.jit(
    do_not_specialize=["stride_mq", "Q_NUM_BLOCKS", "KV_NUM_BLOCKS", "NUM_TASKS"]
)
def block_classify_kernel(
    DENSE_MASK, stride_mb, stride_mh, stride_mq, stride_mk: tl.constexpr,
    BLOCK_FLAGS, stride_fb, stride_fh, stride_fqb, stride_fkb,
    Q_LEN, KV_LEN, NUM_TASKS,
    H: tl.constexpr, Q_NUM_BLOCKS, KV_NUM_BLOCKS,
    Q_BLOCK_SIZE: tl.constexpr, KV_BLOCK_SIZE: tl.constexpr,
):
    pid = tl.program_id(0).to(tl.int32)
    num_core = tl.num_programs(0).to(tl.int32)
    num_blocks_per_bh = Q_NUM_BLOCKS * KV_NUM_BLOCKS
    TILE_M: tl.constexpr = 64
    TILE_N: tl.constexpr = 64

    for task_id in range(pid, NUM_TASKS, num_core):
        off_bh = task_id // num_blocks_per_bh
        off_inner = task_id % num_blocks_per_bh
        off_b = (off_bh // H).to(tl.int64)
        off_h = (off_bh % H).to(tl.int64)
        off_qb = (off_inner // KV_NUM_BLOCKS).to(tl.int64)
        off_kb = (off_inner % KV_NUM_BLOCKS).to(tl.int64)

        has_one = tl.full((), 0, dtype=tl.int32)
        all_one = tl.full((), 1, dtype=tl.int32)
        mask_base = DENSE_MASK + off_b * stride_mb + off_h * stride_mh

        for m0 in range(0, Q_BLOCK_SIZE, TILE_M):
            offs_m = off_qb * Q_BLOCK_SIZE + m0 + tl.arange(0, TILE_M)
            valid_m = offs_m < Q_LEN
            for n0 in range(0, KV_BLOCK_SIZE, TILE_N):
                offs_n = off_kb * KV_BLOCK_SIZE + n0 + tl.arange(0, TILE_N)
                valid_n = offs_n < KV_LEN
                valid = valid_m[:, None] & valid_n[None, :]
                ptrs = mask_base + offs_m[:, None] * stride_mq + offs_n[None, :] * stride_mk
                vals = tl.load(ptrs, mask=valid, other=0).to(tl.int32)
                tile_any = tl.max(tl.max(tl.where(valid, vals, 0), axis=1), axis=0)
                tile_all = tl.min(tl.min(tl.where(valid, vals, 0), axis=1), axis=0)
                has_one = tl.where(tile_any != 0, 1, has_one)
                all_one = tl.where(tile_all == 0, 0, all_one)

        partial = (has_one == 1) & (all_one == 0)
        full = all_one == 1
        flag = tl.where(full, 2, tl.where(partial, 1, 0))
        out_ptr = BLOCK_FLAGS + off_b * stride_fb + off_h * stride_fh + off_qb * stride_fqb + off_kb * stride_fkb
        tl.store(out_ptr, flag.to(tl.int8))


def _classify_stripe_from_hbm(stripe_buffer, q_height, kv_len, flags_buf, Q_BLOCK_SIZE, KV_BLOCK_SIZE):
    """Decoupled classify: read dense mask from HBM and classify block flags.

    Uses block_classify_kernel (separate from mask generation).
    """
    Q_NUM_BLOCKS = _round_up_to_multiple(q_height, Q_BLOCK_SIZE) // Q_BLOCK_SIZE
    KV_NUM_BLOCKS = _round_up_to_multiple(kv_len, KV_BLOCK_SIZE) // KV_BLOCK_SIZE
    num_tasks = Q_NUM_BLOCKS * KV_NUM_BLOCKS
    grid = (min(_get_num_vector_core(), max(num_tasks, 1)),)
    block_classify_kernel[grid](
        stripe_buffer,
        stripe_buffer.stride(0), stripe_buffer.stride(1), stripe_buffer.stride(2), stripe_buffer.stride(3),
        flags_buf, 0, 0, flags_buf.stride(0), flags_buf.stride(1),
        q_height, kv_len, NUM_TASKS=num_tasks, H=1,
        Q_NUM_BLOCKS=Q_NUM_BLOCKS, KV_NUM_BLOCKS=KV_NUM_BLOCKS,
        Q_BLOCK_SIZE=Q_BLOCK_SIZE, KV_BLOCK_SIZE=KV_BLOCK_SIZE,
    )


# ============================================================================
# Kernel: pack_partial_blocks_kernel
# ============================================================================
@triton.jit(
    do_not_specialize=[
        "stride_mq", "stride_mk", "stride_offset_q",
        "stride_local_q", "stride_local_k",
        "stride_flag_q", "stride_flag_k",
        "stride_table_q", "stride_table_k",
        "Q_NUM_BLOCKS", "KV_NUM_BLOCKS", "TOTAL_PARTIAL",
    ]
)
def pack_partial_blocks_kernel(
    DENSE_MASK, stride_mb, stride_mh, stride_mq, stride_mk: tl.constexpr,
    BLOCK_FLAGS, stride_flag_q, stride_flag_k: tl.constexpr,
    PARTIAL_OFFSETS, stride_offset_q,
    LOCAL_IDX, stride_local_q, stride_local_k,
    PACKED_MASK, stride_packed_p, stride_packed_m, stride_packed_n: tl.constexpr,
    BLOCK_TABLE, stride_table_q, stride_table_k: tl.constexpr,
    Q_LEN, KV_LEN, Q_NUM_BLOCKS, KV_NUM_BLOCKS, TOTAL_PARTIAL,
    Q_BLOCK_SIZE: tl.constexpr, KV_BLOCK_SIZE: tl.constexpr,
):
    pid_q = tl.program_id(0).to(tl.int64)
    if pid_q >= Q_NUM_BLOCKS:
        return

    row_offset = tl.load(PARTIAL_OFFSETS + pid_q * stride_offset_q).to(tl.int32)
    offs_m_local = tl.arange(0, Q_BLOCK_SIZE)[:, None].to(tl.int64)
    offs_n_local = tl.arange(0, KV_BLOCK_SIZE)[None, :].to(tl.int64)

    for kv_idx in range(KV_NUM_BLOCKS):
        flag = tl.load(BLOCK_FLAGS + pid_q * stride_flag_q + kv_idx * stride_flag_k).to(tl.int32)
        is_partial = flag == 1
        if is_partial:
            local_idx = tl.load(LOCAL_IDX + pid_q * stride_local_q + kv_idx * stride_local_k).to(tl.int32)
            packed_idx = (row_offset + local_idx - 1).to(tl.int64)
            offs_m = (pid_q * Q_BLOCK_SIZE + tl.arange(0, Q_BLOCK_SIZE))[:, None].to(tl.int64)
            offs_n = (kv_idx * KV_BLOCK_SIZE + tl.arange(0, KV_BLOCK_SIZE))[None, :].to(tl.int64)
            valid_src = (offs_m < Q_LEN) & (offs_n < KV_LEN)
            src_ptrs = DENSE_MASK + offs_m * stride_mq + offs_n * stride_mk
            block = tl.load(src_ptrs, mask=valid_src, other=0)
            dst_ptrs = (
                PACKED_MASK + packed_idx * stride_packed_p
                + offs_m_local * stride_packed_m + offs_n_local * stride_packed_n
            )
            tl.store(dst_ptrs, block)
            tl.store(BLOCK_TABLE + pid_q * stride_table_q + kv_idx * stride_table_k, packed_idx.to(tl.int32))


# ============================================================================
# Strategy 1: Kernel-based streaming packed BlockMask builder
# ============================================================================
def _build_packed_block_mask_streaming(
    mask_type_str,
    problem,
    SEQ_LEN,
    Q_BLOCK_SIZE,
    KV_BLOCK_SIZE,
    stripe_q_blocks=None,
    classify_strategy="decoupled",
):
    """Build a packed BlockMask using custom Triton kernels with streaming stripes.

    Args:
        mask_type_str: Mask type string key into ``_MASK_TYPE_MAP``
            (e.g. "sparse", "full", "stair", "video_stair",
            "cross_sample_causal_video_bidir").
        problem: Problem dict containing q/k/v tensors and index tables
            (segment_ids, modality, doc_start, video_ids, frame_ids, etc.).
        SEQ_LEN: Total sequence length (Q and KV are assumed equal).
        Q_BLOCK_SIZE: Sparse block size along the query dimension.
        KV_BLOCK_SIZE: Sparse block size along the key/value dimension.
        stripe_q_blocks: Number of Q blocks per streaming stripe.  If None,
            auto-computed to target ~256 MB per stripe.
        classify_strategy: "fused" (classify inside create_mask_kernel) or
            "decoupled" (separate block_classify_kernel pass).

    Returns:
        BlockMask with ``packed_partial_mask``, ``partial_mask_offsets``,
        and ``partial_block_table`` attributes set.
    """
    device = problem["q"].device
    if classify_strategy == "fused" and (
        MASK_BLOCK_SIZE != Q_BLOCK_SIZE or MASK_BLOCK_SIZE != KV_BLOCK_SIZE
    ):
        raise ValueError(
            "fused mask classification requires MASK_BLOCK_SIZE to equal the BlockMask "
            f"tile size, got mask={MASK_BLOCK_SIZE}, block=({Q_BLOCK_SIZE}, {KV_BLOCK_SIZE}); "
            "use classify_strategy='decoupled'"
        )
    Q_NUM_BLOCKS = _round_up_to_multiple(SEQ_LEN, Q_BLOCK_SIZE) // Q_BLOCK_SIZE
    KV_NUM_BLOCKS = _round_up_to_multiple(SEQ_LEN, KV_BLOCK_SIZE) // KV_BLOCK_SIZE
    KV_LEN_PADDED = KV_NUM_BLOCKS * KV_BLOCK_SIZE

    if stripe_q_blocks is None:
        max_rows = max(1, _STRIPE_TARGET_BYTES // KV_LEN_PADDED)
        stripe_q_blocks = max(1, max_rows // Q_BLOCK_SIZE)
    stripe_q_blocks = min(stripe_q_blocks, Q_NUM_BLOCKS)

    max_stripe_height = stripe_q_blocks * Q_BLOCK_SIZE
    stripe_buffer = torch.zeros(1, 1, max_stripe_height, KV_LEN_PADDED, dtype=torch.bool, device=device)

    block_flags = torch.zeros((1, 1, Q_NUM_BLOCKS, KV_NUM_BLOCKS), device=device, dtype=torch.int8)
    flags_stripe_buf = torch.empty((stripe_q_blocks, KV_NUM_BLOCKS), device=device, dtype=torch.int8)
    partial_block_table = torch.full((Q_NUM_BLOCKS, KV_NUM_BLOCKS), -1, dtype=torch.int32, device=device)
    global_B = torch.zeros(Q_NUM_BLOCKS, dtype=torch.int32, device=device)

    stripe_caches = []
    stripe_meta = []
    running_total = 0

    for qs_block in range(0, Q_NUM_BLOCKS, stripe_q_blocks):
        qe_block = min(qs_block + stripe_q_blocks, Q_NUM_BLOCKS)
        q_start = qs_block * Q_BLOCK_SIZE
        q_height = (qe_block - qs_block) * Q_BLOCK_SIZE
        stripe_q_nb = qe_block - qs_block

        if qe_block >= Q_NUM_BLOCKS:
            stripe_buffer.zero_()

        if classify_strategy == "fused":
            _run_create_mask_stripe(
                problem, mask_type_str, q_start, q_height, KV_LEN_PADDED,
                stripe_buffer, flags_stripe_buf, tile_size=MASK_BLOCK_SIZE
            )
        elif classify_strategy == "decoupled":
            _run_create_mask_stripe(
                problem, mask_type_str, q_start, q_height, KV_LEN_PADDED, stripe_buffer, tile_size=MASK_BLOCK_SIZE
            )
            _classify_stripe_from_hbm(
                stripe_buffer, q_height, SEQ_LEN, flags_stripe_buf, Q_BLOCK_SIZE, KV_BLOCK_SIZE,
            )
        else:
            raise ValueError(f"Unknown classify_strategy: {classify_strategy}")

        block_flags[:, :, qs_block:qe_block, :] = flags_stripe_buf[:stripe_q_nb, :].unsqueeze(0).unsqueeze(0)

        flags_stripe = flags_stripe_buf[:stripe_q_nb, :].contiguous()
        A_stripe = (flags_stripe == 1).to(torch.int32).cumsum(dim=-1)
        B_stripe = A_stripe.max(dim=-1).values
        stripe_partial_count = int(B_stripe.sum().item())
        global_B[qs_block:qe_block] = B_stripe.to(torch.int32)

        if stripe_partial_count > 0:
            stripe_cache = torch.zeros(
                (stripe_partial_count, Q_BLOCK_SIZE, KV_BLOCK_SIZE), dtype=torch.bool, device=device,
            )
            row_offset_local = (B_stripe.cumsum(dim=-1) - B_stripe).to(torch.int32).contiguous()
            local_idx_stripe = A_stripe.contiguous()
            table_stripe = partial_block_table[qs_block:qe_block, :]

            pack_partial_blocks_kernel[(stripe_q_nb,)](
                stripe_buffer,
                stripe_buffer.stride(0), stripe_buffer.stride(1), stripe_buffer.stride(2), stripe_buffer.stride(3),
                flags_stripe, flags_stripe.stride(0), flags_stripe.stride(1),
                row_offset_local, row_offset_local.stride(0),
                local_idx_stripe, local_idx_stripe.stride(0), local_idx_stripe.stride(1),
                stripe_cache, stripe_cache.stride(0), stripe_cache.stride(1), stripe_cache.stride(2),
                table_stripe, table_stripe.stride(0), table_stripe.stride(1),
                q_height, SEQ_LEN,
                Q_NUM_BLOCKS=stripe_q_nb, KV_NUM_BLOCKS=KV_NUM_BLOCKS,
                TOTAL_PARTIAL=stripe_partial_count,
                Q_BLOCK_SIZE=Q_BLOCK_SIZE, KV_BLOCK_SIZE=KV_BLOCK_SIZE,
            )
            stripe_caches.append(stripe_cache)
        else:
            stripe_caches.append(
                torch.zeros((0, Q_BLOCK_SIZE, KV_BLOCK_SIZE), dtype=torch.bool, device=device)
            )

        stripe_meta.append((qs_block, qe_block, running_total))
        running_total += stripe_partial_count

    del stripe_buffer

    total_partial = running_total

    if total_partial > 0:
        packed_partial_mask = torch.cat(stripe_caches, dim=0)
        for qs_block_i, qe_block_i, cache_offset_i in stripe_meta:
            if cache_offset_i > 0:
                table_slice = partial_block_table[qs_block_i:qe_block_i, :]
                valid = table_slice >= 0
                if valid.any():
                    table_slice[valid] += cache_offset_i
    else:
        packed_partial_mask = torch.zeros(
            (0, Q_BLOCK_SIZE, KV_BLOCK_SIZE), dtype=torch.bool, device=device,
        )

    del stripe_caches

    partial_mask_offsets_3d = (global_B.cumsum(dim=-1) - global_B).view(1, 1, Q_NUM_BLOCKS).contiguous()

    partial_bm = (block_flags == 1).to(dtype=torch.int8)
    full_bm = (block_flags == 2).to(dtype=torch.int8)
    packed_block_mask = _create_sparse_block_from_block_mask(
        (partial_bm, full_bm), 2, (SEQ_LEN, SEQ_LEN), Q_BLOCK_SIZE, KV_BLOCK_SIZE,
    )
    packed_block_mask.packed_partial_mask = packed_partial_mask
    packed_block_mask.partial_mask_offsets = partial_mask_offsets_3d
    packed_block_mask.partial_block_table = partial_block_table

    del block_flags, global_B, partial_bm, full_bm
    return packed_block_mask


# ============================================================================
# Strategy 2: mask_mod-based streaming packed BlockMask builder
# ============================================================================
# Pipeline (per Q-block stripe):
#   1. _generate_stripe_mask       - evaluate mask_mod for a stripe of Q rows
#   2. _classify_stripe_blocks     - classify each (Q, KV) block as full/partial/empty
#   3. _pack_stripe_partial_blocks - extract partial blocks into packed cache + table
#   4. _assemble_packed_block_mask - merge all stripes into final BlockMask


def _generate_stripe_mask(mask_mod, q_start, actual_q, KV_LEN, B, H, device):
    """Evaluate ``mask_mod`` for a horizontal stripe of Q rows.

    Returns a bool tensor of shape ``[B, H, actual_q, KV_LEN]``.

    For the common B=1/H=1 case we call ``mask_mod`` directly with 2-D index
    tensors, which avoids the Python overhead of ``create_mask``'s vmap stack.
    For multi-batch/multi-head we fall back to ``create_mask`` with a shifted
    mask_mod closure.
    """
    if B == 1 and H == 1:
        q_idx = torch.arange(q_start, q_start + actual_q, device=device, dtype=torch.int64)[:, None]
        kv_idx = torch.arange(0, KV_LEN, device=device, dtype=torch.int64)[None, :]
        mask_2d = mask_mod(0, 0, q_idx, kv_idx)
        return mask_2d.view(1, 1, actual_q, KV_LEN)

    def _shifted_mm(b, h, q_idx, kv_idx, _mm=mask_mod, _offset=q_start):
        return _mm(b, h, q_idx + _offset, kv_idx)

    return _torch_create_mask(_shifted_mm, B, H, actual_q, KV_LEN, device=device)


def _classify_stripe_blocks(stripe_mask, Q_BLOCK_SIZE, KV_BLOCK_SIZE):
    """Classify each (Q-block, KV-block) tile as full / partial / empty.

    Args:
        stripe_mask: bool tensor ``[B, H, stripe_q, KV_LEN_PADDED]`` whose Q and
            KV dimensions are already padded to multiples of block sizes.

    Returns:
        flags: int8 tensor ``[stripe_q_nb, KV_num_blocks]`` where
            0 = empty, 1 = partial, 2 = full.
    """
    stripe_q_nb = stripe_mask.shape[2] // Q_BLOCK_SIZE
    kv_num_blocks = stripe_mask.shape[3] // KV_BLOCK_SIZE

    partial_dense, full_dense = _convert_mask_to_block_mask(
        stripe_mask,
        Q_BLOCK_SIZE=Q_BLOCK_SIZE,
        KV_BLOCK_SIZE=KV_BLOCK_SIZE,
        separate_full_blocks=True,
    )

    flags = torch.zeros((stripe_q_nb, kv_num_blocks), dtype=torch.int8, device=stripe_mask.device)
    flags[partial_dense[0, 0] == 1] = 1
    flags[full_dense[0, 0] == 1] = 2
    return flags


def _pack_stripe_partial_blocks(
    stripe_mask,
    flags,
    qs_block,
    Q_BLOCK_SIZE,
    KV_BLOCK_SIZE,
    running_total,
    partial_block_table,
):
    """Extract partial blocks from a stripe into the packed cache.

    For every (Q-block, KV-block) classified as partial, copy the
    ``[Q_BLOCK_SIZE, KV_BLOCK_SIZE]`` tile from ``stripe_mask`` into a flat list
    and record its packed index in ``partial_block_table``.

    Returns:
        packed_tiles: ``[num_partial, Q_BLOCK_SIZE, KV_BLOCK_SIZE]`` bool tensor.
        num_partial:  count of partial blocks in this stripe.
    """
    partial_bool = (flags == 1)
    num_partial = int(partial_bool.sum().item())
    if num_partial == 0:
        empty = torch.zeros((0, Q_BLOCK_SIZE, KV_BLOCK_SIZE), dtype=torch.bool, device=stripe_mask.device)
        return empty, 0

    stripe_q_nb = flags.shape[0]
    kv_num_blocks = flags.shape[1]

    # Locate partial (q_blk, kv_blk) positions within this stripe.
    sq_idx, kv_blk_idx = partial_bool.nonzero(as_tuple=True)

    # Gather the actual [Q_BLOCK_SIZE, KV_BLOCK_SIZE] tiles.
    blocks = stripe_mask.view(stripe_q_nb, Q_BLOCK_SIZE, kv_num_blocks, KV_BLOCK_SIZE)
    packed_tiles = blocks[sq_idx, :, kv_blk_idx, :]

    # Compute the global packed index for each partial block.
    # Layout: partial blocks are packed row-major; each Q-block row's partial
    # count is cumulated so that row_offset_local[q] gives the starting index
    # of that row's partials within the stripe.
    cumsum_per_row = partial_bool.to(torch.int32).cumsum(dim=-1)
    per_row_count = cumsum_per_row.max(dim=-1).values
    row_offset_local = per_row_count.cumsum(dim=-1) - per_row_count
    local_idx = cumsum_per_row[sq_idx, kv_blk_idx] - 1
    packed_idx = (row_offset_local[sq_idx] + local_idx + running_total).to(torch.int32)

    # Record packed indices into the global table (offset by stripe's Q-block start).
    partial_block_table[qs_block + sq_idx, kv_blk_idx] = packed_idx

    return packed_tiles, num_partial


def _assemble_packed_block_mask(
    block_flags,
    packed_partial_mask,
    partial_block_table,
    global_per_row_count,
    Q_LEN,
    KV_LEN,
    Q_BLOCK_SIZE,
    KV_BLOCK_SIZE,
):
    """Assemble the final BlockMask from streaming stripe outputs.

    Args:
        block_flags:          ``[B, H, Q_nb, KV_nb]`` int8 (0/1/2).
        packed_partial_mask:  ``[total_partial, Q_BLOCK_SIZE, KV_BLOCK_SIZE]`` bool.
        partial_block_table:  ``[Q_nb, KV_nb]`` int32 (packed index or -1).
        global_per_row_count: ``[Q_nb]`` int32, partial count per Q-block row.
    """
    Q_num_blocks = block_flags.shape[2]

    # partial_mask_offsets[q] = cumulative partial count before row q.
    partial_mask_offsets = (
        (global_per_row_count.cumsum(dim=-1) - global_per_row_count)
        .view(1, 1, Q_num_blocks).contiguous()
    )

    partial_bm = (block_flags == 1).to(dtype=torch.int8)
    full_bm = (block_flags == 2).to(dtype=torch.int8)

    packed_block_mask = _create_sparse_block_from_block_mask(
        (partial_bm, full_bm), 2, (Q_LEN, KV_LEN), Q_BLOCK_SIZE, KV_BLOCK_SIZE,
    )
    packed_block_mask.packed_partial_mask = packed_partial_mask
    packed_block_mask.partial_mask_offsets = partial_mask_offsets
    packed_block_mask.partial_block_table = partial_block_table
    return packed_block_mask


def create_block_mask_patched(
    mask_mod,
    B=1,
    H=1,
    Q_LEN=None,
    KV_LEN=None,
    device=None,
    BLOCK_SIZE=128,
    stripe_q_blocks=None,
):
    """Build a packed BlockMask with streaming stripe processing.

    Parameters are aligned with ``torch.nn.attention.flex_attention.create_block_mask``.

    The mask is built incrementally: Q rows are processed in horizontal stripes,
    each stripe small enough to keep peak HBM bounded. For every stripe we
    evaluate ``mask_mod``, classify blocks (full/partial/empty), and immediately
    pack partial blocks into a flat cache. This avoids materialising the full
    ``[Q_LEN, KV_LEN]`` dense mask at any point.

    Args:
        mask_mod: A mask_mod callable ``(b, h, q_idx, kv_idx) -> bool``.
            Supports any flexible mask pattern, e.g. ``_full_mask_mod``,
            ``_cross_sample_causal_video_bidir_mask_mod``, ``_sparse_mask_mod``, etc.
        B: Batch size (default 1).
        H: Number of heads (default 1).
        Q_LEN: Query sequence length. If None, inferred from KV_LEN.
        KV_LEN: Key/value sequence length. If None, inferred from Q_LEN.
        device: Device for tensor allocation. If None, uses NPU/CUDA.
        BLOCK_SIZE: Block size as int (square) or ``(Q_BLOCK_SIZE, KV_BLOCK_SIZE)`` tuple.
        stripe_q_blocks: Number of Q blocks per streaming stripe. If None, auto-computed
            to target ~256MB per stripe. Controls HBM peak consumption.

    Returns:
        BlockMask with ``packed_partial_mask``, ``partial_mask_offsets``,
        and ``partial_block_table`` attributes set.
    """
    # ---- Resolve parameters --------------------------------------------------
    if B != 1 or H != 1:
        raise NotImplementedError(
            "NPU packed BlockMask currently supports only batch/head-independent masks "
            "with B=1 and H=1"
        )
    if device is None:
        device = _get_torch_device()
    if Q_LEN is None and KV_LEN is not None:
        Q_LEN = KV_LEN
    if KV_LEN is None and Q_LEN is not None:
        KV_LEN = Q_LEN
    assert Q_LEN is not None and KV_LEN is not None, "Q_LEN and KV_LEN must be provided"

    if isinstance(BLOCK_SIZE, int):
        Q_BLOCK_SIZE, KV_BLOCK_SIZE = BLOCK_SIZE, BLOCK_SIZE
    else:
        Q_BLOCK_SIZE, KV_BLOCK_SIZE = BLOCK_SIZE

    Q_num_blocks = _round_up_to_multiple(Q_LEN, Q_BLOCK_SIZE) // Q_BLOCK_SIZE
    KV_num_blocks = _round_up_to_multiple(KV_LEN, KV_BLOCK_SIZE) // KV_BLOCK_SIZE
    KV_LEN_padded = KV_num_blocks * KV_BLOCK_SIZE

    # ---- Determine stripe size (controls HBM peak) ---------------------------
    if stripe_q_blocks is None:
        max_rows = max(1, _STRIPE_TARGET_BYTES // (KV_LEN_padded * _BYTES_PER_MASK_ELEMENT))
        stripe_q_blocks = max(1, max_rows // Q_BLOCK_SIZE)
    stripe_q_blocks = min(stripe_q_blocks, Q_num_blocks)

    # ---- Allocate accumulators ----------------------------------------------
    block_flags = torch.zeros((B, H, Q_num_blocks, KV_num_blocks), device=device, dtype=torch.int8)
    partial_block_table = torch.full((Q_num_blocks, KV_num_blocks), -1, dtype=torch.int32, device=device)
    global_per_row_count = torch.zeros(Q_num_blocks, dtype=torch.int32, device=device)
    packed_tiles_list = []
    running_total = 0

    # ---- Process stripes -----------------------------------------------------
    for qs_block in range(0, Q_num_blocks, stripe_q_blocks):
        qe_block = min(qs_block + stripe_q_blocks, Q_num_blocks)
        q_start = qs_block * Q_BLOCK_SIZE
        stripe_q = (qe_block - qs_block) * Q_BLOCK_SIZE
        actual_q = min(stripe_q, Q_LEN - q_start)

        # Step 1: generate dense mask for this stripe's Q rows.
        stripe_mask = _generate_stripe_mask(mask_mod, q_start, actual_q, KV_LEN, B, H, device)

        # Pad Q/KV to block boundaries so classification is exact.
        pad_q = stripe_q - actual_q
        pad_kv = KV_LEN_padded - KV_LEN
        if pad_q > 0 or pad_kv > 0:
            stripe_mask = _F.pad(stripe_mask, (0, pad_kv, 0, pad_q))

        # Step 2: classify each (Q-block, KV-block) tile.
        flags = _classify_stripe_blocks(stripe_mask, Q_BLOCK_SIZE, KV_BLOCK_SIZE)
        block_flags[:, :, qs_block:qe_block, :] = flags

        # Record per-row partial counts for offset computation later.
        partial_bool = (flags == 1)
        per_row_count = partial_bool.to(torch.int32).cumsum(dim=-1).max(dim=-1).values
        global_per_row_count[qs_block:qe_block] = per_row_count.to(torch.int32)

        # Step 3: pack partial blocks into flat cache + update table.
        packed_tiles, num_partial = _pack_stripe_partial_blocks(
            stripe_mask, flags, qs_block, Q_BLOCK_SIZE, KV_BLOCK_SIZE,
            running_total, partial_block_table,
        )
        packed_tiles_list.append(packed_tiles)
        running_total += num_partial

        del stripe_mask, flags, partial_bool, per_row_count

    # ---- Merge stripe caches -------------------------------------------------
    if running_total > 0:
        packed_partial_mask = torch.cat(packed_tiles_list, dim=0)
    else:
        packed_partial_mask = torch.zeros(
            (0, Q_BLOCK_SIZE, KV_BLOCK_SIZE), dtype=torch.bool, device=device,
        )
    del packed_tiles_list

    # Step 4: assemble final BlockMask with packed attributes.
    packed_block_mask = _assemble_packed_block_mask(
        block_flags, packed_partial_mask, partial_block_table,
        global_per_row_count, Q_LEN, KV_LEN, Q_BLOCK_SIZE, KV_BLOCK_SIZE,
    )

    del block_flags, global_per_row_count
    return packed_block_mask


@torch.library.custom_op("mojo_npu_triton_a5::flex_attention_v2_forward", mutates_args=("outputs",))
def _flex_attention_v2_forward_leaf(inputs: list[torch.Tensor], outputs: list[torch.Tensor],
                 integers: list[int], floats: list[float], flags: list[bool],
                 grid_sizes: list[int]) -> None:
    grid = tuple(grid_sizes)
    flex_attention_kernel[grid](
        inputs[0],
        inputs[1],
        inputs[2],
        inputs[3],
        inputs[4],
        inputs[5],
        inputs[6],
        inputs[7],
        integers[0],
        integers[1],
        inputs[8],
        inputs[9],
        integers[2],
        integers[3],
        integers[4],
        integers[5],
        outputs[0],
        outputs[1],
        integers[6],
        integers[7],
        integers[8],
        integers[9],
        integers[10],
        integers[11],
        integers[12],
        integers[13],
        integers[14],
        integers[15],
        integers[16],
        integers[17],
        integers[18],
        integers[19],
        integers[20],
        integers[21],
        integers[22],
        integers[23],
        integers[24],
        integers[25],
        SM_SCALE=floats[0],
        QK_HEAD_DIM=integers[26],
        V_HEAD_DIM=integers[27],
        BLOCK_M=integers[28],
        BLOCK_N=integers[29],
        NUM_TASKS=integers[30],
        NUM_Q_BLOCKS=integers[31],
        Q_HEAD=integers[32],
        SPARSE_Q_BLOCK_SIZE=integers[33],
        SPARSE_KV_BLOCK_SIZE=integers[34],
        Q_LEN=integers[35],
        KV_LEN=integers[36],
        GQA_SHARED_HEADS=integers[37],
        HAS_FULL_BLOCKS=flags[1],
        USE_PACKED_PARTIAL_MASK=flags[0],
        DROPOUT_VALUES=inputs[10], DROPOUT_TABLE=inputs[11],
        NUM_DROPOUT_BLOCKS=integers[38], DROPOUT_THRESHOLD=integers[39],
        DROPOUT_SCALE=floats[1], HAS_DROPOUT=flags[2], DROPOUT_BITPACKED=flags[3],
        AUX_OUT=outputs[2] if flags[4] else outputs[0], WRITE_AUX_OUT=flags[4],
        limit_auto_multi_buffer_buffer='no-limit',
        hfusion_enable_multiple_consumer_fusion=True,
        intra_cache_num=3,
        # Legacy compilers corrupt persistent dropout outputs with double buffering.
        inter_cache_num=_DQ_INTER_CACHE_NUM if flags[2] else 2,
        enable_cross_if_fusion=True,
        enable_buffer_insert_optimization=True,
        enable_ub_refine_opt=True
    )

@_flex_attention_v2_forward_leaf.register_fake
def _flex_attention_v2_forward_leaf_fake(inputs, outputs, integers, floats, flags, grid_sizes):
    return None


@torch.library.custom_op("mojo_npu_triton_a5::flex_attention_v2_dq", mutates_args=("outputs",))
def _flex_attention_v2_dq_leaf(inputs: list[torch.Tensor], outputs: list[torch.Tensor],
                 integers: list[int], floats: list[float], flags: list[bool],
                 grid_sizes: list[int]) -> None:
    grid = tuple(grid_sizes)
    flex_attention_backward_dq_kernel[grid](
        inputs[0],
        inputs[1],
        inputs[2],
        inputs[3],
        inputs[4],
        inputs[5],
        inputs[6],
        inputs[7],
        inputs[8],
        inputs[9],
        inputs[10],
        integers[0],
        integers[1],
        inputs[11],
        inputs[12],
        inputs[13],
        integers[2],
        integers[3],
        integers[4],
        integers[5],
        integers[6],
        integers[7],
        outputs[0],
        integers[8],
        integers[9],
        integers[10],
        integers[11],
        integers[12],
        integers[13],
        integers[14],
        integers[15],
        integers[16],
        integers[17],
        integers[18],
        integers[19],
        integers[20],
        integers[21],
        integers[22],
        integers[23],
        integers[24],
        integers[25],
        integers[26],
        integers[27],
        integers[28],
        integers[29],
        integers[30],
        integers[31],
        integers[32],
        integers[33],
        integers[34],
        SM_SCALE=floats[0],
        QK_HEAD_DIM=integers[35],
        V_HEAD_DIM=integers[36],
        BLOCK_M=integers[37],
        BLOCK_N=integers[38],
        NUM_KV_SUB_BLOCKS=integers[39],
        NUM_TASKS=integers[40],
        NUM_Q_BLOCKS=integers[41],
        Q_HEAD=integers[42],
        SPARSE_Q_BLOCK_SIZE=integers[43],
        SPARSE_KV_BLOCK_SIZE=integers[44],
        Q_LEN=integers[45],
        KV_LEN=integers[46],
        GQA_SHARED_HEADS=integers[47],
        HAS_FULL_BLOCKS=flags[1],
        USE_PACKED_PARTIAL_MASK=flags[0],
        DROPOUT_VALUES=inputs[14], DROPOUT_TABLE=inputs[15],
        NUM_DROPOUT_BLOCKS=integers[48], DROPOUT_THRESHOLD=integers[49],
        DROPOUT_SCALE=floats[1], HAS_DROPOUT=flags[2], DROPOUT_BITPACKED=flags[3],
        limit_auto_multi_buffer_buffer='no-limit',
        hfusion_enable_multiple_consumer_fusion=True,
        enable_select_analysis=False,
        limit_auto_multi_buffer_of_local_buffer='no-l0c',
        intra_cache_num=1 if flags[2] else _DQ_INTRA_CACHE_NUM,
        inter_cache_num=_DQ_INTER_CACHE_NUM
    )

@_flex_attention_v2_dq_leaf.register_fake
def _flex_attention_v2_dq_leaf_fake(inputs, outputs, integers, floats, flags, grid_sizes):
    return None


@torch.library.custom_op("mojo_npu_triton_a5::flex_attention_v2_dkdv", mutates_args=("outputs",))
def _flex_attention_v2_dkdv_leaf(inputs: list[torch.Tensor], outputs: list[torch.Tensor],
                 integers: list[int], floats: list[float], flags: list[bool],
                 grid_sizes: list[int]) -> None:
    grid = tuple(grid_sizes)
    flex_attention_backward_dkdv_kernel[grid](
        inputs[0],
        inputs[1],
        inputs[2],
        inputs[3],
        inputs[4],
        inputs[5],
        inputs[6],
        inputs[7],
        inputs[8],
        inputs[9],
        inputs[10],
        integers[0],
        integers[1],
        inputs[11],
        inputs[12],
        inputs[13],
        integers[2],
        integers[3],
        integers[4],
        integers[5],
        integers[6],
        integers[7],
        inputs[14],
        outputs[0],
        outputs[1],
        integers[8],
        integers[9],
        integers[10],
        integers[11],
        integers[12],
        integers[13],
        integers[14],
        integers[15],
        integers[16],
        integers[17],
        integers[18],
        integers[19],
        integers[20],
        integers[21],
        integers[22],
        integers[23],
        integers[24],
        integers[25],
        integers[26],
        integers[27],
        integers[28],
        integers[29],
        integers[30],
        integers[31],
        integers[32],
        integers[33],
        integers[34],
        integers[35],
        integers[36],
        integers[37],
        integers[38],
        SM_SCALE=floats[0],
        QK_HEAD_DIM=integers[39],
        V_HEAD_DIM=integers[40],
        BLOCK_M=integers[41],
        BLOCK_N=integers[42],
        NUM_KV_SUB_BLOCKS=integers[43],
        NUM_TASKS=integers[44],
        NUM_KV_BLOCKS=integers[45],
        KV_HEAD=integers[46],
        SPARSE_Q_BLOCK_SIZE=integers[47],
        SPARSE_KV_BLOCK_SIZE=integers[48],
        Q_LEN=integers[49],
        KV_LEN=integers[50],
        GQA_SHARED_HEADS=integers[51],
        HAS_FULL_BLOCKS=flags[1],
        USE_PACKED_PARTIAL_MASK=flags[0],
        DROPOUT_VALUES=inputs[15], DROPOUT_TABLE=inputs[16],
        NUM_DROPOUT_BLOCKS=integers[52], DROPOUT_THRESHOLD=integers[53],
        DROPOUT_SCALE=floats[1], HAS_DROPOUT=flags[2], DROPOUT_BITPACKED=flags[3],
        DKV_SCHEDULE=inputs[17], NUM_SCHEDULES=integers[54], SPLIT_DKV=flags[4],
        limit_auto_multi_buffer_buffer='no-limit',
        hfusion_enable_multiple_consumer_fusion=True,
        limit_auto_multi_buffer_of_local_buffer='no-l0c',
        intra_cache_num=integers[55],
        inter_cache_num=1,
        # Keep the GQA-head load/add/store dependency ordered. Dynamic CV pipelining
        # corrupts full-block dKV with these dependencies on 3.6.0.post1, even at p=0.
        enable_dynamic_cv_pipeline=False,
    )

@_flex_attention_v2_dkdv_leaf.register_fake
def _flex_attention_v2_dkdv_leaf_fake(inputs, outputs, integers, floats, flags, grid_sizes):
    return None

def flex_attention_v2_fwd(q, k, v, block_mask, scale=None, *, dropout=None):
    if dropout is None:
        return flex_attention_fwd_impl(q, k, v, block_mask, scale)
    # Keep FP32 O for delta: BF16 rounding otherwise accumulates in shared dK.
    # The same forward kernel also writes the user-visible Q-dtype output.
    output = None
    if dropout.dropout_p:
        output = torch.empty((*q.shape[:-1], v.shape[-1]), dtype=q.dtype, device=q.device)
    saved_output, lse = flex_attention_fwd_impl(
        q, k, v, block_mask, scale, dropout=dropout,
        output_dtype=torch.float32 if dropout.dropout_p else q.dtype, aux_output=output,
    )
    return saved_output if output is None else output, lse, saved_output


flex_attention_v2_fwd.supports_dropout = True
flex_attention_v2_bwd = flex_attention_bwd_impl
flex_attention_v2_fwd.create_block_mask = create_block_mask_patched

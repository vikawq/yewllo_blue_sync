from typing import Optional

import torch
import triton
import triton.language as tl

from .utils import _block_size_n_pow2
from .utils import COL_BLOCKING_THRESHOLD
from .utils import ilu_grid_dim_from_row_tasks
from .utils import layer_norm_fwd_heuristics
# from .utils import libentry
from mojo_opset.kernels._triton_utils import ceil_div
from mojo_opset.kernels._triton_utils import torch_to_triton_dtype


def _layernorm_fwd_grid_n_programs(n_rows: int, n_cols: int) -> int:
    block_m = layer_norm_fwd_heuristics({"n_cols": n_cols})
    n_tasks = triton.cdiv(n_rows, block_m)
    return ilu_grid_dim_from_row_tasks(n_tasks)


@triton.heuristics({"BLOCK_SIZE_M": layer_norm_fwd_heuristics})
# @libentry()
@triton.jit
def _layernorm_fwd_kernel(
    X_ptr,
    Y_ptr,
    W_ptr,
    B_ptr,
    Mean_ptr,
    RSTD_ptr,
    stride_x_row,
    stride_y_row,
    n_rows,
    eps,
    N_COLS: tl.constexpr,
    BLOCK_SIZE_N: tl.constexpr,
    BLOCK_SIZE_M: tl.constexpr,
):
    pid = tl.program_id(0)
    num_row_tasks = (n_rows + BLOCK_SIZE_M - 1) // BLOCK_SIZE_M
    task_mask = pid < num_row_tasks

    block_start_row = pid * BLOCK_SIZE_M
    rows_off = block_start_row + tl.arange(0, BLOCK_SIZE_M)
    rows_mask = task_mask & (rows_off < n_rows)

    if N_COLS <= BLOCK_SIZE_N:
        # Single-tile path: the whole row fits in one tile, so load X once,
        # keep it in registers and reuse it for stats + output (1 read + 1 write).
        cols_off = tl.arange(0, BLOCK_SIZE_N)
        cols_mask = cols_off < N_COLS
        block_mask = rows_mask[:, None] & cols_mask[None, :]

        x_chunk = tl.load(
            X_ptr + rows_off[:, None] * stride_x_row + cols_off[None, :], mask=block_mask, other=0.0
        ).to(tl.float32)

        mean = tl.sum(x_chunk, axis=1) / N_COLS
        x_centered = tl.where(cols_mask[None, :], x_chunk - mean[:, None], 0.0)
        var = tl.sum(x_centered * x_centered, axis=1) / N_COLS
        rstd = tl.rsqrt(var + eps)

        tl.store(Mean_ptr + rows_off, mean, mask=rows_mask)
        tl.store(RSTD_ptr + rows_off, rstd, mask=rows_mask)

        w_chunk = tl.load(W_ptr + cols_off, mask=cols_mask, other=0.0).to(tl.float32)
        b_chunk = tl.load(B_ptr + cols_off, mask=cols_mask, other=0.0).to(tl.float32)

        y_chunk = x_centered * rstd[:, None] * w_chunk[None, :] + b_chunk[None, :]

        tl.store(
            Y_ptr + rows_off[:, None] * stride_y_row + cols_off[None, :],
            y_chunk,
            mask=block_mask,
        )
    else:
        # Multi-tile path: cannot keep the whole row in registers, so use a
        # two-pass scheme. Pass 1 accumulates sum(x) and sum(x^2) together to
        # derive both mean and variance in a single read; pass 2 normalizes.
        sum_acc = tl.zeros((BLOCK_SIZE_M,), dtype=tl.float32)
        sumsq_acc = tl.zeros((BLOCK_SIZE_M,), dtype=tl.float32)

        for col_offset in range(0, N_COLS, BLOCK_SIZE_N):
            cols_off = col_offset + tl.arange(0, BLOCK_SIZE_N)
            cols_mask = cols_off < N_COLS
            block_mask = rows_mask[:, None] & cols_mask[None, :]

            x_chunk = tl.load(
                X_ptr + rows_off[:, None] * stride_x_row + cols_off[None, :], mask=block_mask, other=0.0
            ).to(tl.float32)

            sum_acc += tl.sum(x_chunk, axis=1)
            sumsq_acc += tl.sum(x_chunk * x_chunk, axis=1)

        mean = sum_acc / N_COLS
        # E[x^2] - mean^2 can dip slightly below 0 from fp roundoff when the true
        # variance is near zero; clamp to keep rsqrt finite (avoid NaN/inf).
        var = tl.maximum(sumsq_acc / N_COLS - mean * mean, 0.0)
        rstd = tl.rsqrt(var + eps)

        tl.store(Mean_ptr + rows_off, mean, mask=rows_mask)
        tl.store(RSTD_ptr + rows_off, rstd, mask=rows_mask)

        for col_offset in range(0, N_COLS, BLOCK_SIZE_N):
            cols_off = col_offset + tl.arange(0, BLOCK_SIZE_N)
            cols_mask = cols_off < N_COLS
            block_mask = rows_mask[:, None] & cols_mask[None, :]

            x_chunk = tl.load(
                X_ptr + rows_off[:, None] * stride_x_row + cols_off[None, :], mask=block_mask, other=0.0
            ).to(tl.float32)

            w_chunk = tl.load(W_ptr + cols_off, mask=cols_mask, other=0.0).to(tl.float32)
            b_chunk = tl.load(B_ptr + cols_off, mask=cols_mask, other=0.0).to(tl.float32)

            x_centered = x_chunk - mean[:, None]
            y_chunk = x_centered * rstd[:, None] * w_chunk[None, :] + b_chunk[None, :]

            tl.store(
                Y_ptr + rows_off[:, None] * stride_y_row + cols_off[None, :],
                y_chunk,
                mask=block_mask,
            )


@triton.heuristics({"BLOCK_SIZE_M": lambda args: ceil_div(4096, args.get("n_cols", args.get("N_COLS")))})
# @libentry()
@triton.jit
def _layernorm_bwd_kernel(
    DY_ptr,
    DX_ptr,
    DW_ptr,
    DB_ptr,
    X_ptr,
    W_ptr,
    Mean_ptr,
    RSTD_ptr,
    stride_dy_row,
    stride_dx_row,
    stride_x_row,
    n_rows,
    n_cols,
    X_dtype: tl.constexpr,
    BLOCK_SIZE_N: tl.constexpr,
    BLOCK_SIZE_M: tl.constexpr,
):
    pid = tl.program_id(0)
    num_row_tasks = (n_rows + BLOCK_SIZE_M - 1) // BLOCK_SIZE_M
    task_mask = pid < num_row_tasks

    cols_off = tl.arange(0, BLOCK_SIZE_N)
    cols_mask = cols_off < n_cols

    dW_acc = tl.zeros((BLOCK_SIZE_N,), dtype=tl.float32)
    dB_acc = tl.zeros((BLOCK_SIZE_N,), dtype=tl.float32)

    w = tl.load(W_ptr + cols_off, mask=cols_mask, other=0.0).to(tl.float32)

    block_start_row = pid * BLOCK_SIZE_M
    rows_off = block_start_row + tl.arange(0, BLOCK_SIZE_M)
    rows_mask = task_mask & (rows_off < n_rows)
    block_mask = rows_mask[:, None] & cols_mask[None, :]

    mean = tl.load(Mean_ptr + rows_off, mask=rows_mask, other=0.0).to(tl.float32)
    rstd = tl.load(RSTD_ptr + rows_off, mask=rows_mask, other=0.0).to(tl.float32)

    dy = tl.load(DY_ptr + rows_off[:, None] * stride_dy_row + cols_off[None, :], mask=block_mask, other=0.0).to(
        tl.float32
    )

    x = tl.load(X_ptr + rows_off[:, None] * stride_x_row + cols_off[None, :], mask=block_mask, other=0.0).to(
        tl.float32
    )

    x_hat = (x - mean[:, None]) * rstd[:, None]

    dW_acc += tl.sum(dy * x_hat, axis=0)
    dB_acc += tl.sum(dy, axis=0)

    wdy = w[None, :] * dy
    c1 = tl.sum(x_hat * wdy, axis=1) / n_cols
    c2 = tl.sum(wdy, axis=1) / n_cols
    dx = (wdy - (x_hat * c1[:, None] + c2[:, None])) * rstd[:, None]

    tl.store(DX_ptr + rows_off[:, None] * stride_dx_row + cols_off[None, :], dx.to(X_dtype), mask=block_mask)

    tl.atomic_add(DW_ptr + cols_off, dW_acc, mask=cols_mask)
    tl.atomic_add(DB_ptr + cols_off, dB_acc, mask=cols_mask)


# @libentry()
@triton.jit
def _layernorm_bwd_large_cols_kernel(
    DY_ptr,
    DX_ptr,
    DW_ptr,
    DB_ptr,
    X_ptr,
    W_ptr,
    Mean_ptr,
    RSTD_ptr,
    stride_dy_row,
    stride_dx_row,
    stride_x_row,
    n_rows,
    X_dtype: tl.constexpr,
    N_COLS: tl.constexpr,
    BLOCK_SIZE_N: tl.constexpr,
    BLOCK_SIZE_M: tl.constexpr,
):
    pid = tl.program_id(0)
    num_row_tasks = (n_rows + BLOCK_SIZE_M - 1) // BLOCK_SIZE_M
    task_mask = pid < num_row_tasks

    block_start_row = pid * BLOCK_SIZE_M
    rows_off = block_start_row + tl.arange(0, BLOCK_SIZE_M)
    rows_mask = task_mask & (rows_off < n_rows)

    mean = tl.load(Mean_ptr + rows_off, mask=rows_mask, other=0.0).to(tl.float32)
    rstd = tl.load(RSTD_ptr + rows_off, mask=rows_mask, other=0.0).to(tl.float32)

    c1_acc = tl.zeros((BLOCK_SIZE_M,), dtype=tl.float32)
    c2_acc = tl.zeros((BLOCK_SIZE_M,), dtype=tl.float32)

    for col_offset in range(0, N_COLS, BLOCK_SIZE_N):
        cols_off = col_offset + tl.arange(0, BLOCK_SIZE_N)
        cols_mask = cols_off < N_COLS
        block_mask = rows_mask[:, None] & cols_mask[None, :]

        dy = tl.load(DY_ptr + rows_off[:, None] * stride_dy_row + cols_off[None, :], mask=block_mask, other=0.0).to(
            tl.float32
        )

        x = tl.load(X_ptr + rows_off[:, None] * stride_x_row + cols_off[None, :], mask=block_mask, other=0.0).to(
            tl.float32
        )

        w = tl.load(W_ptr + cols_off, mask=cols_mask, other=0.0).to(tl.float32)

        x_hat = (x - mean[:, None]) * rstd[:, None]
        wdy = w[None, :] * dy

        c1_acc += tl.sum(x_hat * wdy, axis=1)
        c2_acc += tl.sum(wdy, axis=1)

    c1 = c1_acc / N_COLS
    c2 = c2_acc / N_COLS

    for col_offset in range(0, N_COLS, BLOCK_SIZE_N):
        cols_off = col_offset + tl.arange(0, BLOCK_SIZE_N)
        cols_mask = cols_off < N_COLS
        block_mask = rows_mask[:, None] & cols_mask[None, :]

        dy = tl.load(DY_ptr + rows_off[:, None] * stride_dy_row + cols_off[None, :], mask=block_mask, other=0.0).to(
            tl.float32
        )

        x = tl.load(X_ptr + rows_off[:, None] * stride_x_row + cols_off[None, :], mask=block_mask, other=0.0).to(
            tl.float32
        )

        w = tl.load(W_ptr + cols_off, mask=cols_mask, other=0.0).to(tl.float32)

        x_hat = (x - mean[:, None]) * rstd[:, None]
        wdy = w[None, :] * dy

        dW_chunk = tl.sum(dy * x_hat, axis=0)
        dB_chunk = tl.sum(dy, axis=0)

        dx = (wdy - (x_hat * c1[:, None] + c2[:, None])) * rstd[:, None]

        tl.store(DX_ptr + rows_off[:, None] * stride_dx_row + cols_off[None, :], dx.to(X_dtype), mask=block_mask)

        tl.atomic_add(DW_ptr + cols_off, dW_chunk, mask=cols_mask)
        tl.atomic_add(DB_ptr + cols_off, dB_chunk, mask=cols_mask)


def layernorm_infer_impl(
    hidden_states: torch.Tensor,
    weight: torch.Tensor,
    bias: torch.Tensor,
    eps: float,
) -> torch.Tensor:
    shape = hidden_states.shape
    dim = shape[-1]
    x_2d = hidden_states.reshape(-1, dim)
    n_rows, n_cols = x_2d.shape

    if n_cols > COL_BLOCKING_THRESHOLD:
        BLOCK_SIZE_N = 2048
    else:
        BLOCK_SIZE_N = _block_size_n_pow2(n_cols)

    grid = (_layernorm_fwd_grid_n_programs(n_rows, n_cols),)

    y = torch.empty_like(x_2d)
    mean = torch.empty(n_rows, dtype=hidden_states.dtype, device=hidden_states.device)
    rstd = torch.empty(n_rows, dtype=hidden_states.dtype, device=hidden_states.device)

    _layernorm_fwd_kernel[grid](
        x_2d,
        y,
        weight,
        bias,
        mean,
        rstd,
        x_2d.stride(0),
        y.stride(0),
        n_rows,
        eps,
        N_COLS=n_cols,
        BLOCK_SIZE_N=BLOCK_SIZE_N,
    )

    return y.reshape(*shape)


def layernorm_fwd_impl(x, w, b, eps):
    shape = x.shape
    dim = shape[-1]
    x_2d = x.reshape(-1, dim)
    n_rows, n_cols = x_2d.shape

    if n_cols > COL_BLOCKING_THRESHOLD:
        BLOCK_SIZE_N = 2048
    else:
        BLOCK_SIZE_N = _block_size_n_pow2(n_cols)

    grid = (_layernorm_fwd_grid_n_programs(n_rows, n_cols),)

    y = torch.empty_like(x_2d)
    mean = torch.empty(n_rows, dtype=x.dtype, device=x.device)
    rstd = torch.empty(n_rows, dtype=x.dtype, device=x.device)

    _layernorm_fwd_kernel[grid](
        x_2d,
        y,
        w,
        b,
        mean,
        rstd,
        x_2d.stride(0),
        y.stride(0),
        n_rows,
        eps,
        N_COLS=n_cols,
        BLOCK_SIZE_N=BLOCK_SIZE_N,
    )

    return y.reshape(*shape), x_2d, mean, rstd


def layernorm_bwd_impl(dy, x_2d, w, b, mean, rstd):
    shape = dy.shape
    dim = shape[-1]
    dy_2d = dy.reshape(-1, dim)
    n_rows, n_cols = dy_2d.shape

    if n_cols > COL_BLOCKING_THRESHOLD:
        BLOCK_SIZE_N = 2048
    else:
        BLOCK_SIZE_N = _block_size_n_pow2(n_cols)

    dx = torch.empty_like(dy_2d)

    if n_cols <= COL_BLOCKING_THRESHOLD:
        grid = (ilu_grid_dim_from_row_tasks(triton.cdiv(n_rows, ceil_div(4096, n_cols))),)
        dw = torch.zeros(n_cols, dtype=torch.float32, device=w.device)
        db = torch.zeros(n_cols, dtype=torch.float32, device=b.device)

        _layernorm_bwd_kernel[grid](
            dy_2d,
            dx,
            dw,
            db,
            x_2d,
            w,
            mean,
            rstd,
            dy_2d.stride(0),
            dx.stride(0),
            x_2d.stride(0),
            n_rows,
            n_cols,
            torch_to_triton_dtype[x_2d.dtype],
            BLOCK_SIZE_N=BLOCK_SIZE_N,
        )
    else:
        grid = (ilu_grid_dim_from_row_tasks(triton.cdiv(n_rows, 2)),)
        dw = torch.zeros(n_cols, dtype=torch.float32, device=w.device)
        db = torch.zeros(n_cols, dtype=torch.float32, device=b.device)

        _layernorm_bwd_large_cols_kernel[grid](
            dy_2d,
            dx,
            dw,
            db,
            x_2d,
            w,
            mean,
            rstd,
            dy_2d.stride(0),
            dx.stride(0),
            x_2d.stride(0),
            n_rows,
            torch_to_triton_dtype[x_2d.dtype],
            N_COLS=n_cols,
            BLOCK_SIZE_N=BLOCK_SIZE_N,
            BLOCK_SIZE_M=2,
        )

    dw = dw.to(w.dtype)
    db = db.to(b.dtype)

    return dx.reshape(*shape), dw, db


@torch.library.custom_op("mojo_ilu_triton::layer_norm_infer", mutates_args=())
def layer_norm_infer_fwd(
    x: torch.Tensor, weight: Optional[torch.Tensor], bias: Optional[torch.Tensor], eps: float,
) -> torch.Tensor:
    weight = x.new_ones(x.shape[-1]) if weight is None else weight.contiguous()
    bias = x.new_zeros(x.shape[-1]) if bias is None else bias.contiguous()
    return layernorm_infer_impl(x.contiguous(), weight, bias, eps)


@layer_norm_infer_fwd.register_fake
def _layer_norm_infer_fake(x, weight, bias, eps):
    return torch.empty_like(x, memory_format=torch.contiguous_format)

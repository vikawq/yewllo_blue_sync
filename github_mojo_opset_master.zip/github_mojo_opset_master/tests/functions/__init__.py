"""Public operator tests."""

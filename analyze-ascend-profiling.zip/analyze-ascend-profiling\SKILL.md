---
name: analyze-ascend-profiling
description: Analyze large local Ascend/PyTorch Profiler exports in place and generate Chinese, evidence-backed reports. Use for ASCEND_PROFILER_OUTPUT, operator_details.csv, kernel_details.csv, op_statistic.csv, step_trace_time.csv, communication.json, communication_matrix.json, trace_view.json, analysis.db, profiler metadata, multi-rank DP/TP/EP/PP/CP/DCP comparison, PyTorch operator and call-stack hotspots, execution-operator input/output shapes, communication message/wait/transit analysis, memory, phase, rank imbalance, and recording/replay causality.
---

# 分析 Ascend Profiling

在原地分析大型 Profiling 数据，不复制、不修改原始导出，也不把大文件整体放入模型上下文。最终报告必须使用中文；算子名、字段名、路径和代码符号保留原文。

## 必须执行的流程

1. 确认 Profiling 根目录和位于根目录之外的输出目录。
2. 完整阅读 [references/report-contract.md](references/report-contract.md)。
3. 完整阅读 [references/analysis-playbook.md](references/analysis-playbook.md)。
4. 发现所有 `ASCEND_PROFILER_OUTPUT`，从目录名和元数据提取 global rank、local rank、device 以及 DP/TP/EP/PP/CP/DCP 坐标；缺失值保持 `未知`，不得按 rank 编号猜测。
5. 运行流式汇总器：

```powershell
python scripts/summarize_ascend_profile.py `
  --input "<profiling-root>" `
  --output "<analysis-output>/extracted" `
  --top 200
```

6. 先读 `extracted/summary.md`、`rank_topology.csv`、`source_coverage_all_ranks.csv`，判断可分析范围。
7. 按以下优先级读取紧凑证据：
   - PyTorch 主线：`pytorch_operators_all_ranks.csv`、`pytorch_operator_rank_comparison.csv` 和各 rank 的 `pytorch_operator_shapes.csv`、`pytorch_operator_shape_variants.csv`；
   - 执行算子：`device_operators_all_ranks.csv`、`device_operator_rank_comparison.csv`；
   - 通信：`communication_ops_all_ranks.csv`、`communication_matrix_all_ranks.csv`、`communication_rank_comparison.csv` 和各 rank 的 `communication_kernel_shapes.csv`、`communication_context.csv`；
   - 墙钟/内存：`step_trace_all_ranks.csv`、`memory_peaks_all_ranks.csv`；
   - CANN/API/PMU 仅在解释 PyTorch 热点的设备实现、launch、runtime、内存或硬件异常时读取。
8. 在 `<analysis-output>/reports` 生成报告契约规定的五份中文报告。
9. 每个数字都引用确切的相对文件以及 key、行、列或过滤条件。完成后运行引用存在性、单位、分母、rank 坐标和时间窗口检查。
10. 即使数据不完整也要完成报告；把无法证明的结论标为 `未知`，并给出最小的补采项。

## 分析主线

始终从 PyTorch 语义向设备实现下钻：

```text
运行/模型/请求/阶段 + DP/TP/EP/PP/CP/DCP
  -> PyTorch operator / module / call stack / input shape
  -> device execution operator / input-output shape / stream / duration
  -> communication group / peer / message / wait / transit / overlap
  -> step wall-clock / rank imbalance / memory
  -> 根因、优化候选和 recording/replay 影响
```

不要把 CANN `op_statistic.csv` 或 kernel Top 列表当作报告主线。只有 PyTorch 证据缺失时才退化为设备算子报告，并在摘要首段明确说明退化。

## Shape 口径

- `operator_details.csv` 是 PyTorch 算子主证据，原生提供输入 Shape、调用栈和 Host/Device self/total，但不提供输出 Shape。
- `kernel_details.csv` 在启用 all-kernel headers 时可提供设备执行算子的输入/输出 Shape、dtype 和 format。
- 不得把某个 device kernel 的输出 Shape 自动写成 PyTorch operator 的输出 Shape，除非 `trace_view.json` flow、`analysis.db` 关联或框架日志建立了明确映射。
- Shape 缺失时写 `未知（未采集）`，并建议下一次启用 `record_shapes=True` 与包含 all-kernel headers 的导出配置。
- 同时报告 Shape、调用数、累计/平均/最大耗时和 rank/并行坐标；不能只列 Shape。

## 通信口径

- 使用 `communication.json` 分离调用数、消息量、transit、wait、synchronization 和 bandwidth。
- 使用 `communication_matrix.json` 验证 peer/link/transport；只有完整坐标和链路能唯一对应时，才把通信标为 TP/DP/EP/PP/CP/DCP。
- 使用 `communication_kernel_shapes.csv` 报告通信执行算子的输入/输出 Shape，但不得把 HCCL kernel duration 当成链路传输时间。
- 使用 `step_trace_time.csv` 报告 communication-not-overlapped；没有该文件时，不得声称通信阻塞了多少墙钟时间。
- 通过 `communication_context.csv` 观察通信前后的计算算子；该文件只证明时间邻近，依赖关系仍需 flow、调用栈或框架代码验证。

## 大文件纪律

- 大 CSV 逐行聚合；不要粘贴完整内容。
- 不要整体打开 `trace_view.json`。先用已抽取表；确需关联时按 event name、flow id、rank 和时间范围做流式过滤。
- 不要广泛查询 `analysis.db`。先查 `sqlite_master` 和 `PRAGMA table_info`，再做有界聚合。
- 输出目录必须在原始 Profiling 根目录之外。
- 报告包默认控制在 5 MB 内；大明细保留为 CSV，不复制原始 trace。

## 交付前验证

- 五份报告全部存在且正文为中文。
- PyTorch 算子在前，CANN/设备统计只作为下钻证据。
- 重要计算和通信表均包含 rank、DP/TP/EP/PP/CP/DCP、算子名、Shape、count 和 time；缺失字段明确为未知。
- 百分比带分子、分母、单位和来源；self/total、kernel sum/wall-clock、wait/transit 均未混用。
- rank 比较覆盖同一阶段和采集窗口；不从 TP=2 外推大规模行为。
- 所有证据链接存在，原始数据未修改。

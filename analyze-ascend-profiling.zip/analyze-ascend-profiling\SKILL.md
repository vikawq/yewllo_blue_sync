---
name: analyze-ascend-profiling
description: Analyze large local Ascend/PyTorch profiler exports without moving raw data, including ASCEND_PROFILER_OUTPUT, kernel_details.csv, operator_details.csv, op_statistic.csv, step_trace_time.csv, communication.json, communication_matrix.json, trace_view.json, and profiler metadata. Use when an AI must stream and aggregate multi-rank NPU profiling data, compare TP/DP/EP/PP/CP ranks, explain operator shapes and communication, identify evidence for recording/replay causality, or generate compact Markdown reports that can be transferred off an isolated machine.
---

# Analyze Ascend Profiling

Analyze profiling in place. Do not copy, mutate, or fully load large raw exports into model context. Produce compact evidence-backed reports for transfer.

## Required workflow

1. Resolve the profiling root and a separate output directory.
2. Read [references/report-contract.md](references/report-contract.md) completely.
3. Read [references/analysis-playbook.md](references/analysis-playbook.md) completely.
4. Discover every `ASCEND_PROFILER_OUTPUT` below the root and map it to rank coordinates from directory names and metadata.
5. Run the bundled streaming summarizer:

```powershell
python scripts/summarize_ascend_profile.py `
  --input "<profiling-root>" `
  --output "<analysis-output>/extracted" `
  --top 200
```

6. Read `extracted/summary.md`, `summary.json`, `rank_kernel_comparison.csv`, and each rank's compact files. Read `interesting_events.csv`, `shape_variants.csv`, communication metrics, and metadata summaries only as needed.
7. Generate the five reports required by the report contract under `<analysis-output>/reports`.
8. Cross-check every number against a compact extracted file. Cite the exact relative file and key, row, column, or filter.
9. Finish even when data is incomplete. Mark unsupported conclusions as `未知` and list the smallest next capture needed.

## Analysis order

Follow one causal storyline instead of writing isolated answers:

```text
model + topology + request/state
  -> per-rank ownership and prepared workload
  -> operator sequence and shape variants
  -> index/count/length-dependent work
  -> collective and rank balance
  -> graph/kernel/tiling evidence
  -> recording/replay implications
```

Start with the run and topology. Do not interpret a local shape before identifying rank, TP/DP/EP/PP/CP/DCP, graph/eager mode, and capture window.

## Evidence rules

- Prefix material conclusions with `事实`、`推断`、or `未知`.
- Never equate summed kernel duration with wall-clock latency when streams overlap.
- Never equate `HcclLaunchAicpuKernel` duration with wire transfer time without checking both ranks and communication exports.
- Treat an empty `Step` column as an aggregated profiling window unless other evidence identifies step boundaries.
- Separate warmup, graph capture, prefill, and steady decode when possible. If impossible, say so.
- Compare the same time window and semantic phase across ranks.
- Report both count and duration. A long total may come from many calls rather than one slow call.
- For dynamic shapes, report distinct signatures, frequency, total time, and the operator/path correlated with each signature.
- Do not claim that equal shapes imply equal values, addresses, routing, state, or workload.
- Do not infer 64/128-card behavior directly from TP=2. Use TP=2 only to validate dependency edges and rank asymmetry.

## Large-file discipline

- Do not paste full CSV/JSON content into chat or reports.
- Prefer the bundled script, streaming CSV readers, SQLite aggregation, or filtered line ranges.
- Do not open `trace_view.json` in full. Filter by event name and time range or use extracted events.
- Do not query `analysis.db` broadly. Inspect tables with `sqlite_master` and `PRAGMA table_info`, then issue bounded aggregate queries.
- Keep generated reports and extracted summaries outside the raw profiling root.

## Minimum acceptable result

Even for a single-rank or incomplete capture, produce:

- a run inventory;
- quantified top operators and shapes;
- an explicit statement of whether phase/rank comparison is possible;
- a list of facts the profiler proves;
- a list of replay questions it cannot answer without framework metadata;
- a next-run instrumentation list limited to the missing causal fields.

## Validation

Before delivery:

- Verify that all five reports exist.
- Verify that every referenced extracted file exists.
- Check percentage denominators and units.
- Check rank labels and time-window alignment.
- Check that source data was not modified.
- Ensure the executive report is understandable without reading the raw tables.

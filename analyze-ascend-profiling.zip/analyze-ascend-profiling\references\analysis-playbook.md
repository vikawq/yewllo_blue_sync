# Ascend/PyTorch Profiling 分析手册

## 目录

1. 数据分层与文件路由
2. PyTorch 算子主线
3. 执行算子与 Shape
4. 通信算子与并行维度
5. 时间语义、阶段与跨 rank 比较
6. 内存、API 与硬件指标
7. 端到端归因与优化
8. Recording/replay 映射
9. 数据缺失与失败模式

## 1. 数据分层与文件路由

按语义层级使用证据，不要把所有文件混成一张 Top 表。

| 层级 | 主文件 | 主要用途 | 重要限制 |
|---|---|---|---|
| PyTorch/框架 | `operator_details.csv` | operator、输入 Shape、调用栈、Host/Device self/total | 没有输出 Shape；total 可能包含子节点 |
| 框架-设备关联 | `trace_view.json`、`analysis.db` | flow、线程、stream、operator 到 kernel 关联 | 文件大；必须过滤或有界查询 |
| 设备执行 | `kernel_details.csv` | kernel/op、I/O Shape、dtype、format、stream、duration/wait | Shape 列取决于 all-kernel headers；duration sum 非墙钟 |
| 设备汇总 | `op_statistic.csv` | 设备/CANN op type 构成 | 丢失 PyTorch 语义、序列和 Shape；只作辅助 |
| 墙钟分解 | `step_trace_time.csv` | compute、communication、overlap、free、stage | 空 Step 常表示聚合窗口 |
| 通信语义 | `communication.json` | collective/P2P、group、message、transit、wait、sync | schema 随版本变化；不含 Tensor Shape |
| 通信拓扑 | `communication_matrix.json` | peer/link/transport/bandwidth | 可能是 top/middle/bottom/total 汇总；避免重复求和 |
| 内存 | `memory_record.csv`、`operator_memory.csv` | 内存水位、算子申请 | 仅在 profile_memory=True 时存在 |
| CANN/API | `api_statistic.csv`、`task_time.csv` | launch/runtime/同步开销 | 不应替代 PyTorch 主线 |
| 硬件 | `l2_cache.csv`、`soc_pmu.csv`、`hccs.csv`、`pcie.csv`、`roce.csv` | cache、pipe、互联、带宽 | 只有相应采集开关开启才有数据 |
| 运行元数据 | `profiler_info_*.json`、`profiler_metadata.json` | schedule、activity、版本、用户字段 | 字段随版本和用户 hook 变化 |

## 2. PyTorch 算子主线

### 2.1 排序口径

分别回答以下问题：

- `Device Self`：该 PyTorch 节点直接归属的设备工作量，适合算子构成；
- `Device Total`：节点及子节点设备工作量，适合端到端 scope，但不同父子节点不能直接相加；
- `Host Self`：Python/C++ operator 自身 host 开销；
- `Host Total`：包含子 scope 的 host 开销；
- `count` 与 `max`：区分“大量小调用”和“少量长尾调用”。

每个热点至少报告：operator、namespace/family、rank/并行坐标、input Shape、call stack/module、count、self total/avg/max。不要只给总时长。

### 2.2 Shape 和调用栈

对同一 operator 分组时，至少保留以下签名：

```text
(operator name, input shape, call-stack id, rank, phase/step)
```

检查：

1. Shape 变化发生在 step、phase、layer 还是 rank；
2. 相同 Shape 是否来自不同 call stack/module；
3. Shape 变化是否伴随 device kernel、通信 message 或 count 变化；
4. 是否形成稳定 bucket；
5. 热点来自单次变慢还是调用数增多。

`operator_details.csv` 不含 PyTorch 输出 Shape。保持未知，除非 flow/DB/框架日志能把 PyTorch event 与具体 device execution event 一一关联。

### 2.3 PyTorch 语义不足时

缺少 `operator_details.csv` 时允许退化为 device-only 分析，但必须：

- 在执行摘要首段标为“缺少 PyTorch 语义的设备侧退化分析”；
- 不把 kernel name 当作 Python module/branch；
- 下一次采集建议包含 CPU+NPU activity、`record_shapes=True`、`with_stack=True` 或 `with_modules=True`。

## 3. 执行算子与 Shape

使用 `device_operator_shapes.csv` 下钻 PyTorch 热点或查找动态 ABI。关键签名：

```text
(rank coordinates, step, device op/kernel name, type/core,
 input shapes+dtypes+formats, output shapes+dtypes+formats)
```

对每个重要算子回答：

- 调用数、累计/平均/最大 duration 与 wait；
- 输入/输出 Shape、dtype、format 是否随 rank/phase 变化；
- kernel 实现名是否随 Shape 切换；
- 是否与 PyTorch call stack 有明确 flow，还是仅名称/时间邻近；
- 相同 Shape 下耗时差异是否可能来自 placement、频率、cache、tiling、contention。

不要用相同 Shape 推断相同 value、address、expert route、token validity、block table 或 cache version。

### 3.1 常见路径线索

| 路径 | 设备侧线索 | 仍需的 PyTorch/框架证据 |
|---|---|---|
| Attention | flash/attention、QKV GEMM、softmax、rope、KV cache | layer/module、prefill/decode、q/kv length、mask |
| MoE | router/topk、permute、all-to-all、grouped GEMM | expert id/count、capacity、split vector |
| Dense MLP | matmul/GEMM、activation、norm | module/layer、TP shard、batch/token extent |
| KV | cache/slot/block/index kernel | block table、slot mapping、cache version |
| Graph | graph launch/固定序列/稳定 bucket | graph key、capture/replay 标志、buffer plan |

这些只用于定位证据，不自动构成根因。

## 4. 通信算子与并行维度

### 4.1 分离六类指标

```text
launch/kernel count
Tensor I/O Shape（kernel_details）
message/transit size（communication.json/matrix）
transit time
wait/synchronization time
communication-not-overlapped（step_trace_time.csv）
```

只有这些字段来自同一 rank、step、group/instance 且能可靠对齐时才放在同一行；否则用两张表并说明 join key 和不确定性。

### 4.2 判定 TP/DP/EP/PP/CP/DCP

优先级：

1. 框架显式 process-group 名称和成员；
2. profiler metadata 中的 group/member；
3. communication matrix 的 peer rank，加上完整 rank 坐标；
4. operator 序列的语义推断。

若一个 group 的成员只在某一个坐标轴上变化，可把该轴标为 `事实`。若多个坐标同时变化或坐标不完整，写 `未知`。常见序列只能作为 `推断`：

- projection GEMM -> AllReduce/ReduceScatter：可能是 TP；
- router/permute -> AllToAll -> grouped GEMM：可能是 EP/MoE；
- gradient bucket -> AllReduce/ReduceScatter：可能是 DP；
- send/recv 位于不同 layer region：可能是 PP；
- AllGather -> attention：可能是 CP/SP/TP，需 group 证据区分。

### 4.3 Matrix 去重

新版本通信矩阵可能包含 `top1`、`middle`、`bottom1/2/3`、`total`。当 `total` 存在时，仅用 `total` 做累计；其他行用于分布/长尾观察，不能再次求和。

### 4.4 时间邻近不是依赖

`communication_context.csv` 的前后算子仅证明时间邻近。要声称 producer/consumer 依赖，至少需要以下之一：

- trace flow/correlation id；
- 同一 PyTorch call stack/module scope；
- 框架代码或显式标记；
- 稳定重复序列加上 Shape/message 的共同变化，并标为推断。

## 5. 时间语义、阶段与跨 rank 比较

始终写清分母：

```text
profiling window = last event end - first event start
summed kernel time = sum(selected kernel durations)
operator self/total = profiler-defined exclusive/inclusive aggregate
stage wall-clock = step_trace Stage
communication total = step_trace Communication
non-overlapped communication = step_trace Communication(Not Overlapped)
wire/transit = communication export Transit Time
```

多 stream 时 kernel duration 可以重叠，不等于延迟。

常用比例：

```text
non-overlapped communication share = communication_not_overlapped / stage
rank imbalance = max(same metric) / min(same metric)
shape variability = distinct signatures / calls
message bandwidth = transit_size / transit_time
```

### 5.1 阶段识别

按以下证据顺序识别 warmup/capture/prefill/decode/backward/optimizer：

1. 用户 metadata、Profiler Step、显式 range/marker；
2. 独立输出目录或请求日志；
3. 稳定算子序列与明确的输入/输出长度；
4. 仅凭 shape/kernel 模式的推断。

第 4 类必须标为推断。无 Step 时把数据称为“完整采集窗口”，不要擅自叫稳态 decode。

### 5.2 跨 rank 可比性检查

依次检查：schedule/起止、Step、阶段、operator count、kernel span、communication count、local Shape、placement。只比较同语义窗口。

| 观察 | 候选解释 | 必查替代解释 |
|---|---|---|
| count 相同，一侧 wait 更长 | 同步或慢 peer | 窗口、频率、stream、placement |
| count 不同 | workload/control path | capture 窗口不齐 |
| 同 operator 不同 local Shape | shard/padding/routing | 不同请求/阶段 |
| Shape/count 相同但时长不同 | placement/cache/tiling/contention | 单位、频率、采样噪声 |
| message size 不同 | ragged route/workload | group/step 对齐错误 |

## 6. 内存、API 与硬件指标

内存报告至少区分 allocated、reserved、active 和 operator allocation。峰值来自 `memory_record.csv`，不能把各时间点求和。算子申请总量可以大于峰值，因为内存会释放和复用。

API、L2、PMU、HCCS、PCIe、ROCE 只在回答具体问题时使用：

- Host Self 高且 Device Self 低：检查 launch/API/同步/大量小调用；
- 相同 kernel/Shape 不同耗时：检查 PMU、cache、频率、placement；
- transit 异常：检查 matrix transport、HCCS/PCIe/ROCE；
- reserved 显著高于 active：检查缓存分配器与碎片，但不能仅凭差值断言碎片根因。

## 7. 端到端归因与优化

每个根因候选必须写成可证伪链：

```text
上游 workload/topology 事实
-> PyTorch operator/call stack/input Shape
-> device execution/input-output Shape/count
-> communication/message/wait/transit 或 memory
-> step wall-clock 后果
-> 替代解释
-> 最小 A/B 实验与预期指标变化
```

优化候选按“可影响的未重叠墙钟 × 证据置信度 × 实施成本”排序。kernel 累计时间很大但完全重叠时，不应给出同等优先级。

常见候选类别：

- 减少大量小 PyTorch/Host launch；
- Shape bucket/padding/graph 稳定化；
- TP/EP/DP group 或 shard 负载均衡；
- 通信计算重叠与 collective 选择；
- MoE route/capacity/split 平衡；
- 内存复用、workspace、峰值或碎片；
- kernel/tiling/format/dtype 优化。

## 8. Recording/replay 映射

| Profiler 观察 | Recording/replay 含义 |
|---|---|
| 固定 PyTorch input Shape | graph bucket 候选，不证明 graph reuse |
| 多个 local Shape | 记录 bucket/length source/branch |
| rank 间 Shape 不同 | 记录拓扑与 local ownership |
| ragged message size | 记录 count/split vector 或其生产者 |
| 相同 Shape 不同 transit/wait | 记录 placement、group、topology、physical plan |
| KV kernel 可见但 slot 值不可见 | 增加 slot/block/cache-version hook |
| MoE kernel 可见但 expert count 不可见 | 增加 router histogram/rank split hook |
| graph kernel 可见但 key/address 不可见 | 增加 graph key 与 buffer-plan hook |

Profiler 通常能证明某个依赖有性能后果，但不能恢复 scheduler decision、token value、expert id、slot mapping、address 或 cache version。

## 9. 数据缺失与失败模式

### 只有一个 rank

完成单 rank 报告；把 peer、通信轴和平衡写为未知。建议补采相同 schedule 的所有 rank。

### 缺少 operator_details.csv

退化为设备侧报告，不输出虚假的 PyTorch module/branch。补采 CPU+NPU activity、record_shapes 和 stack/module。

### PyTorch Shape 为空

检查 profiler 配置中的 `record_shapes=True`。调用栈为空时检查 `with_stack=True` 或 `with_modules=True`。

### device I/O Shape 为空

说明 `kernel_details.csv` 未包含 all-kernel headers。下一次启用相应导出；不要从 op name 猜 Shape。

### 没有 Step

分析完整窗口并寻找重复序列，但不命名为 decode/steady state，除非有 metadata/marker。

### communication total 与 op/kernel 不一致

检查单位、wait/sync、overlap、窗口和 group/step 对齐。不要任选一个指标当“真实通信时间”。

### 报告又变成 Top kernel 列表

重写为至少一个完整实例：

```text
PyTorch operator/call stack/input Shape
-> device I/O Shape/count
-> communication/message 或 memory
-> wall-clock
-> 根因/优化/重放字段
```

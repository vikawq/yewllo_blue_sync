# Analysis Playbook

## Contents

1. File routing
2. Time semantics
3. Rank comparison
4. Shape and path analysis
5. Communication analysis
6. Recording/replay mapping
7. Failure modes

## 1. File routing

| File | Primary use | Important limitation |
|---|---|---|
| `profiler_info_*.json` | profiler settings, activities, schedule | may omit framework topology |
| `profiler_metadata.json` | environment and user metadata | fields vary by version |
| `op_statistic.csv` | fast operator-type composition | aggregated; loses sequence and shape |
| `kernel_details.csv` | kernel, shape, dtype, format, stream, timing | kernel duration is not wall time |
| `operator_details.csv` | framework operator and call-stack association | device totals can be inclusive |
| `step_trace_time.csv` | compute/communication/free decomposition | blank Step can represent whole window |
| `task_time.csv` | device task ordering | weak model semantics |
| `communication.json` | collective timing/bandwidth details | schema varies; wait may dominate |
| `communication_matrix.json` | peer/rank matrix and link behavior | absent for some captures |
| `trace_view.json` | complete timeline and correlation | too large to load unfiltered |
| `analysis.db` | queryable integrated facts | inspect schema before querying |

## 2. Time semantics

Always name the denominator.

```text
profiling window = last event end - first event start
summed kernel time = sum(duration of selected kernels)
operator total = profiler-defined aggregate, possibly inclusive
non-overlapped communication = step trace metric
wire/transit time = communication export metric when available
```

Do not add overlapping streams and call the result latency.

Useful ratios:

```text
communication share of stage
  = communication / stage

non-overlapped communication share
  = communication_not_overlapped / stage

rank duration imbalance
  = max(rank metric) / min(rank metric)

shape variability
  = distinct signatures / calls
```

For each ratio, report numerator, denominator, unit, and source file.

## 3. Rank comparison

Compare ranks only when they cover the same semantic window.

Check in order:

1. profiler start/end and schedule;
2. number of kernel rows and time span;
3. step identifiers;
4. operator counts;
5. communication call counts;
6. local shapes;
7. total and maximum duration;
8. rank-to-node placement.

Classify imbalance:

| Pattern | Candidate explanation |
|---|---|
| Same counts, one rank longer communication wait | synchronization or slower peer |
| Different counts | capture windows or control paths differ |
| Same op, different local shape | sharding, padding, or workload distribution |
| Same shape/count, different duration | placement, contention, frequency, cache, tiling |
| HCCL count equal, message sizes unequal | ragged routing or local workload |

Do not diagnose root cause until alternatives are checked.

## 4. Shape and path analysis

Use `shape_variants.csv` to find operators with multiple signatures. Then use `interesting_events.csv` to determine ordering and correlation with communication.

For each variant answer:

```text
Is the change across steps, phases, layers, or ranks?
Does dtype or format change with shape?
Does a different kernel name appear?
Does communication count/size change?
Does the variant repeat as a stable bucket?
```

Interpret roles:

| Role | Examples | Why shape alone is insufficient |
|---|---|---|
| payload | activation, weight | values affect numerical output |
| length | seq/query length | values set valid extent and masks |
| index | sparse top-k, expert ID | values select addresses or destinations |
| count | expert/rank histogram | values set communication and GEMM workload |
| address | block table, slot mapping | values select KV memory |
| state | cache/index/spec version | meaning depends on prior step |

Profiler shape data usually proves local ABI, not index values or cache versions.

## 5. Communication analysis

Separate:

```text
launch count
message size
transit time
wait/synchronization time
non-overlapped time
rank imbalance
```

Correlate communication events with the nearest preceding/following compute kernels. Typical interpretations:

- matmul -> AllReduce/ReduceScatter: TP projection path;
- permute/route -> All-to-All -> grouped GEMM: MoE path;
- AllGather -> attention: sequence/head gathering;
- send/recv between layer regions: PP path.

Treat these as inferences until operator names, call stacks, groups, or framework logs confirm them.

## 6. Recording/replay mapping

Map observations to trace fields:

| Profiler observation | Record/replay implication |
|---|---|
| repeated fixed shape | candidate graph bucket, not proof of graph reuse |
| multiple local shapes | record bucket/length source and branch |
| different rank shapes | record topology and local ownership |
| ragged communication sizes | record count/split vector or its producer |
| identical shape with different communication duration | record placement/topology and physical plan |
| KV/cache kernels visible but no slot values | add framework slot/block/state hook |
| MoE kernels visible but no expert counts | add router histogram and rank split hook |
| graph kernels visible but no descriptor/address | add graph key and buffer-plan hook |

The profiler can validate that a dependency has a performance consequence. It usually cannot reconstruct scheduler decisions, token values, expert IDs, slot mappings, or cache versions without framework instrumentation.

## 7. Failure modes

### Only rank0 exists

Produce single-rank reports. Mark rank balance and collective peer behavior unknown. Request rank1 with the same profiler schedule.

### No step markers

Analyze the complete window and search for repeated operator subsequences. Do not label a repeated segment as decode without supporting evidence.

### Communication dominates step trace but not op statistics

Check units, wait/sync fields, overlap semantics, and whether step trace covers a larger interval. Do not select one metric as authoritative without reconciliation.

### Shape fields are empty

Use operator details, call stacks, metadata, or bounded `analysis.db` queries. Recommend enabling shape recording on the next run.

### Reports become another operator list

Rewrite around one complete example:

```text
input/topology fact
-> observed local shape/path
-> communication or kernel consequence
-> required recording field
-> replay compatibility conclusion
```

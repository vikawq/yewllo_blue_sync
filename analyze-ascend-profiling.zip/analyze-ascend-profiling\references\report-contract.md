# Report Contract

Generate exactly five Markdown reports. Keep the total package small enough to transfer; target less than 5 MB unless the user asks otherwise.

## 00_executive_summary.md

Audience: engineers and technical leads who will not inspect raw profiler files.

Required sections:

1. Run identity and topology
2. What was actually captured
3. Five most important findings
4. One end-to-end causal example from this run
5. What the run proves for recording/replay
6. What it does not prove
7. Next three actions

Use concrete numbers and plain language. Explain the difference between profiling-window time, summed kernel time, and communication metrics.

## 01_run_and_topology.md

Required sections:

- Source directory and export inventory
- Framework/runtime/SoC versions found in metadata
- Rank table: global rank, local rank, device, DP/TP/EP/PP/CP/DCP coordinates
- Requested versus discovered ranks
- Capture schedule, warmup, active window, repeat count
- Step/phase identification: warmup, capture, prefill, decode, mixed, or unknown
- Missing topology and workload metadata

Include an evidence table:

| Finding | Status | Evidence file | Field/query | Value |
|---|---|---|---|---|

## 02_operator_shape_path.md

Required sections:

- Operator and kernel time composition by rank
- Top operators by total time, average, maximum, and count
- Shape signatures with more than one observed variant
- Likely attention, MoE, KV, GEMM, graph, and padding paths
- Rank-local shape comparison
- Operator sequence evidence around key communication events
- Distinction between payload shapes and decision/address/workload tensors

For each important dynamic operator, include:

| Operator | Rank | Shape variants | Calls | Total time | Path/replay implication | Evidence |
|---|---:|---:|---:|---:|---|---|

Do not claim a Python control-flow branch solely from a kernel name. Phrase it as an implementation/path observation unless framework logs or code prove the guard.

## 03_communication_and_rank_balance.md

Required sections:

- Communication types, counts, groups, message sizes, and durations where available
- Per-rank HCCL/communication kernel comparison
- Compute/communication/free time by rank
- Non-overlapped versus overlapped communication
- Rank imbalance table
- Candidate causes: unequal workload, synchronization, launch overhead, topology, or capture-window mismatch
- Confidence and alternative explanations

Required warning:

> HCCL AICPU duration may include wait/synchronization and is not automatically equal to link transfer time.

When only one rank exists, do not estimate the missing rank. State that dual-rank balance is unverified.

## 04_record_replay_implications.md

Organize around four causal chains:

1. Scheduler/workload -> raw and padded token extents -> graph
2. Routing/index/count -> communication split -> local GEMM workload
3. Block/slot/address -> KV state
4. TP/DP/EP/PP/CP -> local ownership -> collective/operator ABI

For each chain, write:

| Observed evidence | Proven dependency | Required trace field | Can recompute? | Missing evidence |
|---|---|---|---|---|

Conclude with:

- fields to record exactly;
- fields to record as distributions/digests;
- fields that can be recomputed from topology/config;
- physical-plan fields needed for performance replay;
- proposed framework hooks for the next run;
- whether this run supports numerical, path, performance, or operator-only replay conclusions.

## Evidence labels

Use these labels consistently:

- `事实` — directly present in profiler/metadata/log output.
- `推断` — derived from multiple facts; state the reasoning.
- `未知` — not observable from the provided capture.
- `建议` — a next action, not a finding.

Never convert an inference into a fact merely because it is plausible.

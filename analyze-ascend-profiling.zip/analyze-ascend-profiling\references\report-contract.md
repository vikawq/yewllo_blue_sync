# 中文报告契约

必须生成且只生成以下五份 Markdown 主报告。正文、标题、表头、结论和建议使用中文；算子名、代码符号、字段名与证据路径保留原文。默认整个报告包小于 5 MB，详细明细放在抽取 CSV 中。

## 通用要求

每份报告开头写明：Profiling 标识、rank 范围、采集阶段/窗口、可用主证据、缺失主证据。所有重要结论使用以下标签：

- `事实`：原始 Profiler、元数据或日志直接给出；
- `推断`：由多个事实推导，必须写出推理链和备选解释；
- `未知`：当前数据不可观测；
- `建议`：下一步动作，不是已发生的事实。

所有性能表至少包含：rank、DP/TP/EP/PP/CP/DCP 坐标、阶段或 Step、算子/通信名称、调用数、累计/平均/最大耗时、Shape、证据。不存在的坐标或 Shape 写 `未知`，不得留空导致读者误判。

每个百分比同时写出分子、分母、单位和证据。不得混用：

- Host self 与 Host total；
- Device self 与 Device total；
- kernel duration 求和与墙钟时间；
- HCCL/AICPU duration 与通信 transit；
- communication total 与 communication-not-overlapped；
- PyTorch operator 输入 Shape 与 device kernel 输入/输出 Shape。

## 00_executive_summary.md

受众：不会阅读原始 Profiler 表的工程师和技术负责人。

必须包含：

1. 一段话说明运行、模型/工作负载、并行拓扑、rank、阶段和采集完整度；
2. 五个最重要发现，至少覆盖 PyTorch 热点、动态 Shape/路径、通信、跨 rank 平衡、墙钟或内存；
3. 一个本次运行中的端到端实例：`PyTorch operator/call stack -> 执行算子与 I/O Shape -> 通信 -> Step/墙钟后果`；
4. 三个有量化收益假设的优化候选，以及验证每个候选所需的最小实验；
5. 本次数据可以证明和不能证明的内容；
6. 下一步三项行动。

首段必须明确报告属于以下哪一级：

- `完整 PyTorch+设备+通信分析`；
- `缺少通信细节的 PyTorch+设备分析`；
- `缺少 PyTorch 语义的设备侧退化分析`；
- `仅清单/采集诊断`。

## 01_run_and_topology.md

必须包含：

- 源目录、导出文件清单、每个 rank 的关键文件大小；
- PyTorch/torch_npu/CANN/驱动/固件/SoC 版本（存在才报告）；
- 模型、请求、batch、sequence、prefill/decode、训练/推理、图/动态图等元数据；
- rank 表：global/local rank、device、node、DP/TP/EP/PP/CP/DCP 坐标与坐标来源；
- 请求的 world size/并行度与实际发现值；
- schedule 的 wait/warmup/active/repeat、采集起止与 Step；
- 阶段判定：warmup、graph capture、prefill、decode、backward、optimizer、mixed 或 unknown；
- 按 rank 的采集完整度矩阵，以及每个缺失文件造成的分析限制；
- 可比性结论：哪些 rank/step/phase 可直接比较，哪些不可比较。

证据表：

| 发现 | 标签 | 证据文件 | 字段/查询/过滤条件 | 值 |
|---|---|---|---|---|

## 02_operator_shape_path.md

本报告必须以 PyTorch operator 为主体，不得从 CANN Top 列表起笔。

必须包含：

1. 各 rank 的 PyTorch operator 构成：Name、namespace/family、call stack/module、input Shape、count、Host self/total、Device self/total；
2. 按 Device Self、Host Self、平均、最大和调用数分别识别热点，说明排序口径；
3. 动态输入 Shape：distinct signature、频次、累计时间、阶段/step/rank 关联；
4. 跨 DP/TP/EP/PP/CP/DCP 坐标的同算子 Shape、count 和耗时对比；
5. 设备执行算子下钻：kernel/op name、input/output Shape、dtype、format、count、累计/平均/最大时长；
6. attention、MoE、KV、GEMM、norm、embedding、padding、graph 等路径的证据；
7. PyTorch 算子与设备执行算子无法直接关联时，明确分开两层，不得按名称相似强行绑定；
8. CANN/API/PMU 仅作为解释热点的附录，正文不超过本报告内容的 20%。

PyTorch 主表：

| PyTorch 算子 | Rank/并行坐标 | Input Shape | Output Shape | Calls | Device Self 总/均/最大 | Host Self 总/均/最大 | Call stack/module | 证据 |
|---|---|---|---|---:|---|---|---|---|

其中 PyTorch `Output Shape` 通常应写 `未知（operator_details.csv 不提供）`。只有 flow、DB 或框架日志建立直接映射时才可填写，并注明关联方法。

设备执行表：

| 执行算子 | Rank/并行坐标 | Input Shape/dtype/format | Output Shape/dtype/format | Calls | 总/均/最大时长 | 对应 PyTorch 路径 | 关联置信度 | 证据 |
|---|---|---|---|---:|---|---|---|---|

不要仅凭 kernel 名称声称 Python 控制流分支。没有框架日志或代码 guard 时，只能写“实现路径/算子序列观察”。

## 03_communication_and_rank_balance.md

必须包含：

- 集合通信与 P2P 类型、实例名、group、peer/link/transport、调用数；
- rank 及 DP/TP/EP/PP/CP/DCP 坐标；只有 group/link 与完整坐标唯一对应时才标注并行轴；
- communication.json 的 message size、transit、wait、synchronization、bandwidth；
- 通信执行算子的 input/output Shape、dtype/format、kernel count/duration；
- communication_matrix 的链路方向、peer、transport 与带宽异常；
- step_trace 的 communication、not-overlapped、overlapped、stage 和 free；
- 通信前后计算算子序列，以及“时间邻近”与“依赖关系”的区别；
- 同语义窗口的跨 rank count/size/transit/wait/not-overlapped/Shape 对比；
- 不平衡候选：工作量不均、同步、launch、拓扑、路由、capture 窗口不齐，并列出替代解释与置信度。

通信主表：

| 通信算子/类型 | Rank/并行坐标/通信轴 | Group/Peer | Input/Output Shape | Calls | Message | Transit | Wait/Sync | Not-overlapped | 证据 |
|---|---|---|---|---:|---:|---:|---:|---:|---|

必须原样包含警告：

> HCCL AICPU duration 可能包含等待或同步，不等同于链路传输时间；链路口径应以 communication.json/matrix 为准。

只有一个 rank 时，不估计缺失 rank，写明通信对端和平衡未经验证。

## 04_record_replay_implications.md

把全量分析收束为可验证的因果链、优化和 recording/replay 影响。至少覆盖：

1. scheduler/workload -> raw/padded token extent -> PyTorch operator input Shape -> device graph/kernel；
2. router/index/count -> communication split/message -> local grouped GEMM Shape/workload；
3. block/slot/address -> KV operator/path/state；
4. DP/TP/EP/PP/CP/DCP -> local ownership -> collective/operator ABI；
5. PyTorch launch/call stack -> device execution -> communication overlap -> Step wall-clock；
6. allocation/operator -> memory peak/fragmentation/possible synchronization。

对每条链使用：

| 上游事实 | PyTorch 证据 | 执行/通信证据 | 墙钟/内存后果 | 已证明依赖 | 替代解释 | 缺失证据 | 置信度 |
|---|---|---|---|---|---|---|---|

随后给出：

- 经量化排序的根因候选；
- 优化候选、预期影响的指标、风险和最小 A/B 实验；
- 必须精确记录的字段；
- 可记录为分布/摘要的字段；
- 可由拓扑/配置重算的字段；
- 性能 replay 所需物理计划字段；
- 下一次采集的框架 hook/metadata；
- 本次运行支持 numerical、path、performance、communication、operator-only 中哪些 replay 结论。

严禁把“趋势存在”写成“优化一定有效”，或把相同 Shape 写成相同 value、address、routing、cache state、workload。

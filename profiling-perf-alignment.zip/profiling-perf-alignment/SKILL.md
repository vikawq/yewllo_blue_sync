---
name: profiling-perf-alignment
description: 昇腾 NPU 真机 vs 仿真的**性能**对齐分析：用不带 CPU 采集的 profiling 评估仿真器的时延建模误差（每类算子估快了还是估慢了、差多少），再借用带 CPU 采集那次的 kernel→代码映射，把性能热点归因到具体的 Python 函数与代码行。当用户提到仿真性能准不准、仿真时延建模误差、真机与仿真耗时对比、算子耗时对比、性能热点归因、关掉 CPU 采集后的 profiling、"CPU 采集影响性能数据"、两阶段 profiling（先带 CPU 再不带 CPU）时，都要使用本 skill。只做耗时/性能，控制流与算子结构差异请用 profiling-alignment-analysis。Use for Ascend NPU real-vs-simulator performance alignment, simulator latency-model error, kernel timing comparison, hotspot attribution to source code, two-phase profiling with and without CPU activity.
---

# 真机 vs 仿真 性能对齐分析（两阶段方法）

## 这个 skill 解决的矛盾

要把性能热点落到代码上，就得知道每个 kernel 是哪行 Python 下发的——那需要 CPU 采集
（`python_function` + `aten` 事件 + flow 连线）。但 CPU 采集本身会显著抬高 host 开销、改变下发
节奏，采出来的耗时**不是真实性能**。

两阶段方法把这对矛盾拆开：

| 阶段 | 采集方式 | 只取什么 | 绝对不能取什么 |
| --- | --- | --- | --- |
| **A** | 开 CPU activity + `with_stack=True` | **结构**：kernel 叫什么、什么 shape、由哪个 Python 函数下发 | 耗时 |
| **B** | 关掉 CPU activity | **耗时**：同样的 kernel 真正跑了多久 | 代码归因（这份里没有 Python 事件） |

B 缺的代码信息，用 A 的映射补上。桥梁是 `(归一化 kernel 名, 输入 shape)`——不用时间戳、
不用 uid，所以能跨运行使用。**前提是两次跑的是同一个 workload**，这一点必须先校验。

## 与 profiling-alignment-analysis 的分工

| 问题 | 用哪个 skill |
| --- | --- |
| 两边算子对不上、走了不同分支、哪行 `if` 翻了 | `profiling-alignment-analysis` |
| 仿真的耗时估得准不准、热点在哪、归因到哪行代码 | **本 skill** |

两者互补：本 skill 第 5 节列出的"只在一侧出现的算子"是结构性差异，**不算建模误差**，
它的原因要去另一个 skill 的结论里找。写最终报告时两边的结论要合起来。

## phase A 用哪一侧的数据？

**主映射一律用真机那份**（真机带 CPU 采集）。理由和控制流分析一致：分析以真机为基准，
仿真只回答『它和真机差多少』；而且性能对比里绝大多数算子两侧都执行，真机映射就够用。

但真机映射有个盲区：**仅在仿真出现的算子**（仿真桩下发的 `DAVID_EVENT_*`、`*_mock` 里
发的 kernel）在真机映射里根本不存在，归因会是空的。所以如果手上有**仿真带 CPU 采集**
的那份 trace，也给它建一份映射，用 `--map-sim` 传进去——它只用于第 5 节里 sim-only 的行，
且结果会标注『来自仿真侧映射』，不会把仿真的东西说成真机代码干的。

| 用途 | 用哪份 | 参数 |
| --- | --- | --- |
| 两侧都执行的算子、真机独有的算子 | 真机带 CPU | `--map` |
| 仅在仿真出现的算子 | 仿真带 CPU | `--map-sim`（可选，没有就显示 `-`） |

## 开工前

1. phase A：带 CPU 采集的 trace。**真机那份必需**；仿真那份可选（用于 sim-only 归因）
2. phase B：不带 CPU 采集的 **真机** + **仿真** 两份 trace
3. 模型仓库根（路径归一化用）
4. 如果已经跑过 `profiling-alignment-analysis`，把它的 `pytrace.md` / `branches.md` 也拿来

缺哪个直接问用户。约定：

```bash
SK="<本 skill 目录>/scripts"; WS="pf_out"; mkdir -p "$WS"
```

脚本只用标准库。

---

## Step 0 — 先校验，别急着分析

```bash
python "$SK/pf_verify.py" --cpu <A 真机带CPU> --nocpu <B 真机不带CPU> --sim <B 仿真不带CPU> \
  --out "$WS/verify.md"
```

它检查三件事，任一不过就别往下走：

1. phase A **有** python_function（否则建不出映射）；
2. phase B **没有** python_function（否则耗时被采集开销污染，不是性能真值）；
3. phase A 与 phase B 的 **device kernel 构成重合度**。低于 70% 说明两次跑的多半不是同一个
   workload，映射套过去会张冠李戴：kernel 名字对得上，来源却不是同一处。

第 3 条是这套方法唯一的硬前提。CPU 采集会改变下发节奏，但**不会**改变 kernel 的种类和数量——
这正是两阶段方法成立的基础，也是可以用重合度来验证它的原因。

## Step 1 — 用 phase A 建 kernel → 代码 映射

```bash
python "$SK/pf_map.py" --trace <A 真机带CPU> --repo <模型仓库> \
  --extra-root <torch_npu 源码根> --step -2 --out "$WS/kernel_code_map.json"

# 可选：仿真带 CPU，只为给『仅在仿真出现』的算子归因
python "$SK/pf_map.py" --trace <A 仿真带CPU> --repo <模型仓库> \
  --step -2 --out "$WS/kernel_code_map_sim.json"
```

靠 flow 事件（`cat=async_npu`）把 device kernel 连回下发它的 `aten::` 算子，再取该算子所在的
Python 调用栈。输出会报**连通率**：低于 30% 说明 flow 事件稀疏，映射会有大量空洞，
多半是采集时 CPU activity 没开全。

只取结构，不取耗时——这份数据的时间数字在本 skill 里从头到尾不出现。

## Step 2 — 用 phase B 比性能

```bash
python "$SK/pf_compare.py" --real <B 真机> --sim <B 仿真> \
  --map "$WS/kernel_code_map.json" --map-sim "$WS/kernel_code_map_sim.json" \
  --step -2 --out "$WS/perf.md"
```

**先看第 0 节的可信度检查，再看数字。** 报告的口径固定为三个，引用时必须带上：

- **设备忙时间** = 各 device stream 上 kernel 时长之和。stream 之间是并行的，所以它**不是墙钟**，
  是"设备侧总工作量"。跨两次运行比这个才有意义。
- **墙钟** = 窗口内首尾跨度。仿真的墙钟是模型算出来的，它只说明"仿真器认为这一步要多久"，
  **不是加速比**，不要写进结论。
- **建模比 = 仿真均值 / 真机均值**。这是评价仿真器的核心指标：>1 估慢了，<1 估快了。
  评价仿真器要看这个，不要看"仿真比真机快几倍"——那个数字没有意义。

各节的读法：

| 节 | 回答什么 |
| --- | --- |
| 2 分类耗时 | 哪一类（attention / matmul / comm / …）整体估偏了 |
| 3 建模误差 Top | 具体哪个 kernel + shape 估得最离谱，按"偏差 × 权重"排序 |
| 4 总耗时差 Top | 哪个 kernel 贡献了最大的绝对时间差 |
| 5 只在一侧出现 | **结构性差异，不算建模误差**，去控制流那边找原因 |
| 6 stream 维度 | 计算流 / 通信流各自的偏差，通信流通常是重灾区 |

**按 (kernel, shape) 分组，不要只按 kernel 名。** 同一个 `MatMulV3` 在不同 shape 下耗时差一个
数量级，混在一起算均值毫无意义——脚本已经按 shape 分组，报告里也要连 shape 一起引用。

## Step 3 — 合并控制流结论

第 5 节"只在一侧出现的算子"和第 2 节里次数不同的类别，**都不是性能问题**。它们的原因在
`profiling-alignment-analysis` 的结论里：仿真桩、分支翻转、H2D 拷贝退化。把两份结论合起来：

> 仿真总时间少了 X%，其中 Y% 来自结构性缺失（视觉塔被 mock，见控制流报告 D1/D2），
> 剩下 Z% 才是时延建模误差，主要集中在通信类（建模比 0.30x，严重低估）。

**不做这一步的性能报告是错的**——把"少算了一整段"和"每个算子估快了一点"混为一谈，
会得出"仿真整体偏快 40%"这种既不解释原因也无法指导改进的结论。

## Step 4 — 出报告

按 `references/report-template.md` 写。硬要求：

1. 每个数字都带口径（设备忙时间 / 墙钟 / 建模比）和窗口；
2. 结构性差异与建模误差分开算，各自给出占比；
3. 每个热点带代码归因（来自 Step 1 的映射），归因不上的显式写 `-`，不要编。

---

## 判读纪律

- **phase A 的耗时永远不引用**。它只提供结构。报告里出现 phase A 的时间数字就是错的。
- **仿真的墙钟不是加速比**。它是仿真器的输出，不是测量值。
- **建模比要带 shape**。`MatMulV3` 在 `2,4096,8192` 和 `2,512,8192` 下是两个完全不同的问题。
- **结构性差异不算建模误差**。只在一侧出现的算子先扣掉，再谈仿真估得准不准。
- **通信类单独看**。仿真器对 HCCL 的建模方式通常和真机完全不同（NOTIFY/UBDMA vs
  event+memcpy），它的"误差"往往不是精度问题而是实现不同，要单独说明。
- **归因不上就写 `-`**。映射连通率不会是 100%，空洞是正常的，编一个代码位置比留空更糟。

## 参考资料

| 文件 | 什么时候读 |
| --- | --- |
| `references/method.md` | 两阶段方法的原理、采集参数怎么配、常见坑 |
| `references/report-template.md` | 写最终报告 |

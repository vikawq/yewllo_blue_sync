#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""pf_verify.py -- 两阶段数据是否可以放在一起用？跑分析之前先过这一关。

    python pf_verify.py --cpu <带CPU采集的 trace_view.json> \\
        --nocpu <不带CPU采集的真机 trace_view.json> [--sim <不带CPU的仿真 trace_view.json>]

这个两阶段方法有两个隐含前提，任一不成立结论就是错的：

1. **带 CPU 那份必须真的有 python_function**，否则建不出 kernel→代码 的映射；
   **不带 CPU 那份必须真的没有**，否则性能数字被采集开销污染了。
2. **两次跑的必须是同一个 workload**。代码、配置、输入只要有一样变了，
   phase A 建的映射套到 phase B 上就是张冠李戴——kernel 名字对得上，来源却不是同一处。

第 2 条没法直接验证，但可以用 device kernel 的构成做强校验：同一 workload 的每步
kernel 种类和数量应该高度一致。这里给出重合度，低了就别往下做。
"""
from __future__ import annotations

import argparse
import glob
import json
import os
import sys
from collections import Counter

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from pa_common import force_utf8, load_trace, normalize_name, parse_pyfunc, find_steps  # noqa: E402

_SKIP = ("ProfilerStep", "Iteration", "Computing", "Communication", "Free")


def profile(path):
    tr = load_trace(path)
    steps = find_steps(tr)
    n_py = sum(1 for tk in tr.tracks.values() for e in tk.events if parse_pyfunc(e["name"]))
    kern = Counter()
    for tk in tr.tracks_by_side("device"):
        for e in tk.events:
            n = normalize_name(e["name"])
            if n in _SKIP:
                continue
            kern[n] += 1
    cfg = {}
    d = os.path.dirname(os.path.abspath(path))
    for _ in range(4):
        hits = glob.glob(os.path.join(d, "profiler_info*.json"))
        if hits:
            try:
                with open(hits[0], "r", encoding="utf-8") as fh:
                    cfg = json.load(fh)
            except Exception:
                cfg = {}
            break
        d = os.path.dirname(d)
    return {"path": path, "n_py": n_py, "steps": len(steps), "kernels": kern, "cfg": cfg}


def overlap(a, b):
    """kernel 构成的重合度：按每种 kernel 取次数的较小值，除以较大侧总数。"""
    ta, tb = sum(a.values()), sum(b.values())
    if not ta or not tb:
        return 0.0
    inter = sum(min(a[k], b.get(k, 0)) for k in a)
    return 100.0 * inter / max(ta, tb)


def main():
    force_utf8()
    ap = argparse.ArgumentParser(description=__doc__,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--cpu", required=True, help="phase A：带 CPU 采集")
    ap.add_argument("--nocpu", required=True, help="phase B：不带 CPU 采集（真机）")
    ap.add_argument("--sim", default="", help="phase B：不带 CPU 采集（仿真）")
    ap.add_argument("--min-overlap", type=float, default=70.0)
    ap.add_argument("--out", default="")
    args = ap.parse_args()

    A = profile(args.cpu)
    B = profile(args.nocpu)
    S = profile(args.sim) if args.sim else None

    L = ["# 两阶段数据校验", "",
         "| 项 | phase A（带 CPU） | phase B 真机（不带 CPU） | phase B 仿真 |",
         "| --- | --- | --- | --- |",
         "| python_function 事件 | %d | %d | %s |" % (
             A["n_py"], B["n_py"], S["n_py"] if S else "-"),
         "| step 数 | %d | %d | %s |" % (A["steps"], B["steps"], S["steps"] if S else "-"),
         "| device kernel 事件 | %d | %d | %s |" % (
             sum(A["kernels"].values()), sum(B["kernels"].values()),
             sum(S["kernels"].values()) if S else "-"),
         "| kernel 种类 | %d | %d | %s |" % (
             len(A["kernels"]), len(B["kernels"]), len(S["kernels"]) if S else "-"),
         ""]

    ok = True
    if A["n_py"] == 0:
        ok = False
        L += ["- ❌ **phase A 没有 python_function**，建不出 kernel→代码 映射。"
              "这一份必须开 CPU activity + `with_stack=True` 重采。", ""]
    else:
        L += ["- ✅ phase A 有 %d 条 python_function，可以建映射。" % A["n_py"]]
    if B["n_py"] > 0:
        ok = False
        L += ["- ❌ **phase B 真机侧含 %d 条 python_function**，说明 CPU 采集没关掉，"
              "耗时被采集开销污染，不能当性能真值。关掉 CPU activity 重采。" % B["n_py"]]
    else:
        L += ["- ✅ phase B 真机侧没有 python_function，耗时可用。"]
    if S is not None:
        if S["n_py"] > 0:
            ok = False
            L += ["- ❌ **phase B 仿真侧含 %d 条 python_function**，同上。" % S["n_py"]]
        else:
            L += ["- ✅ phase B 仿真侧没有 python_function，耗时可用。"]
    L.append("")

    ov = overlap(A["kernels"], B["kernels"])
    L += ["## workload 一致性（phase A vs phase B 真机）", "",
          "- device kernel 构成重合度：**%.1f%%**" % ov, ""]
    if ov < args.min_overlap:
        ok = False
        L += ["> ❌ 重合度低于 %.0f%%，说明两次跑的很可能**不是同一个 workload**"
              "（代码、配置或输入变了）。phase A 建的映射套到 phase B 上会张冠李戴："
              "kernel 名字对得上，来源却不是同一处。先确认两次运行完全一致再重来。"
              % args.min_overlap, ""]
        diff = [(k, A["kernels"].get(k, 0), B["kernels"].get(k, 0))
                for k in set(A["kernels"]) | set(B["kernels"])]
        diff.sort(key=lambda x: -abs(x[1] - x[2]))
        L += ["| kernel | phase A 次数 | phase B 次数 |", "| --- | --- | --- |"]
        for k, a, b in diff[:15]:
            L.append("| `%s` | %d | %d |" % (k, a, b))
        L.append("")
    else:
        L += ["> ✅ 构成一致，映射可以跨这两份数据使用。"
              "（注意：CPU 采集会改变**下发节奏**，所以 phase A 的耗时仍然不可用，"
              "但 kernel 的种类和数量不受影响——这正是这套方法成立的基础。）", ""]

    L += ["## 结论", "", "**%s**" % ("可以继续：先 pf_map.py 建映射，再 pf_compare.py 比性能"
                                    if ok else "先修上面标 ❌ 的问题，再继续"), ""]
    md = "\n".join(L)
    print(md)
    if args.out:
        os.makedirs(os.path.dirname(os.path.abspath(args.out)) or ".", exist_ok=True)
        with open(args.out, "w", encoding="utf-8") as fh:
            fh.write(md)
    sys.exit(0 if ok else 2)


if __name__ == "__main__":
    main()

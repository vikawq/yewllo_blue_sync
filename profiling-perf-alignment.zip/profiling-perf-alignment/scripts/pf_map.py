#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""pf_map.py -- 从"带 CPU 采集"的那份 profiling 里，提炼出 device kernel → 模型代码 的映射。

    python pf_map.py --trace <带CPU采集的 trace_view.json> --repo <模型仓库> \\
        --step -2 --out out/kernel_code_map.json

为什么要单独做这一步
--------------------
CPU 采集（python_function + aten 层）会显著抬高 host 侧开销，采出来的耗时不能用来做性能结论。
但它是**唯一**能把 device 上的 kernel 连回 Python 代码的数据：flow 事件把
`aten::matmul` 和它下发的 `MatMulV3` 连起来，而 `aten::matmul` 又嵌套在
`modeling_xxx.py(438): forward` 里面。

所以分工是：
- 带 CPU 的那次 → 只取**结构**：kernel 叫什么、什么 shape、由哪个 Python 函数下发的；
- 不带 CPU 的那次 → 只取**耗时**：同样的 kernel 真正跑了多久。

这个脚本产出前者，`pf_compare.py` 拿它给后者的热点加代码归因。映射的键是
`(归一化 kernel 名, 输入 shape)`——不用时间戳、不用 uid，因为两次运行之间它们毫无可比性。
"""
from __future__ import annotations

import argparse
import os
import sys
from collections import Counter, defaultdict

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from pa_common import (force_utf8, load_trace, link_flows, normalize_name, shape_of,  # noqa: E402
                       find_steps, parse_pyfunc, norm_pypath, write_json, categorize)


def _enclosing_pyfuncs(track, ev, roots, limit=6):
    """host 事件所在的 Python 调用栈（由外到内），用来回答"这个 kernel 是谁下发的"。"""
    out = []
    for e in track.events:
        if e["ts"] > ev["ts"]:
            break
        if e["ts"] <= ev["ts"] <= e["ts"] + e["dur"]:
            pf = parse_pyfunc(e["name"])
            if pf:
                f, line, fn = pf
                out.append("%s:%d %s" % (norm_pypath(f, roots), line, fn))
    return out[-limit:]


def _short_stack(stack, n=2):
    """只留最内层几帧，且文件名压到 basename —— 最外层永远是 train_step，没信息量。"""
    parts = []
    for fr in stack[-n:]:
        path, _sep, rest = fr.partition(":")
        parts.append("%s:%s" % (os.path.basename(path), rest))
    return " > ".join(parts)


def build_map(trace_path, roots, step=None):
    tr = load_trace(trace_path)
    dev2host, _ = link_flows(tr)
    t0 = t1 = None
    window = "整段 trace"
    steps = find_steps(tr)
    if step is not None and steps:
        i = step if step >= 0 else len(steps) + step
        i = max(0, min(i, len(steps) - 1))
        window, t0, t1 = steps[i]
        window = "step %s" % window

    entries = defaultdict(lambda: {"count": 0, "pyfunc": Counter(), "host_op": Counter(),
                                   "stream": Counter(), "cat": ""})
    n_dev = n_linked = 0
    host_tracks = {k: t for k, t in tr.tracks.items() if t.side == "host"}
    for tk in tr.tracks_by_side("device"):
        for ev in tk.events:
            if t0 is not None and not (t0 <= ev["ts"] < t1):
                continue
            n_dev += 1
            key = (normalize_name(ev["name"]), shape_of(ev))
            e = entries[key]
            e["count"] += 1
            e["stream"][tk.thread] += 1
            e["cat"] = categorize(ev["name"])
            h_uid = dev2host.get(ev["uid"])
            if h_uid is None:
                continue
            n_linked += 1
            host = tr.by_uid[h_uid]
            e["host_op"][normalize_name(host["name"])] += 1
            h_tk = host_tracks.get((host["pid"], host["tid"]))
            if h_tk is not None:
                stack = _enclosing_pyfuncs(h_tk, host, roots)
                if stack:
                    e["pyfunc"][_short_stack(stack)] += 1

    out = []
    for (name, shape), e in entries.items():
        out.append({
            "kernel": name, "shape": shape, "cat": e["cat"], "count": e["count"],
            "streams": [s for s, _n in e["stream"].most_common(3)],
            "host_ops": [{"op": o, "n": n} for o, n in e["host_op"].most_common(3)],
            "pyfunc_stacks": [{"stack": s, "n": n} for s, n in e["pyfunc"].most_common(3)],
        })
    out.sort(key=lambda x: -x["count"])
    return {
        "source_trace": trace_path, "window": window,
        "device_events": n_dev, "linked_to_host": n_linked,
        "link_rate": round(100.0 * n_linked / max(1, n_dev), 1),
        "has_python": any(x["pyfunc_stacks"] for x in out),
        "entries": out,
    }


def to_md(m):
    L = ["# kernel → 代码 映射（取自带 CPU 采集的那次运行）", "",
         "- 来源 trace：`%s`" % m["source_trace"],
         "- 窗口：%s" % m["window"],
         "- device 事件 %d 条，其中 %d 条连上了 host 算子（%.1f%%）"
         % (m["device_events"], m["linked_to_host"], m["link_rate"]), ""]
    if m["link_rate"] < 30:
        L += ["> ⚠️ 连通率偏低。trace 里的 flow 事件（`cat=async_npu`）可能缺失，"
              "映射会很稀疏。检查采集是否开了 CPU activity；只有 host/device 两侧都采到，"
              "才连得起来。", ""]
    if not m["has_python"]:
        L += ["> ⚠️ 一条 Python 调用栈都没提取到：这份 trace 没有 python_function 事件。"
              "**它不能用来建映射**——建映射必须用带 CPU 采集（`with_stack=True` + CPU activity）"
              "的那一次。", ""]
    L += ["## 出现最多的 kernel 及其代码归属", "",
          "| kernel | shape | 类别 | 次数 | 下发它的 host 算子 | Python 调用栈 |",
          "| --- | --- | --- | --- | --- | --- |"]
    for e in m["entries"][:60]:
        ops = ", ".join("`%s`×%d" % (o["op"], o["n"]) for o in e["host_ops"]) or "-"
        st = e["pyfunc_stacks"][0]["stack"] if e["pyfunc_stacks"] else "-"
        L.append("| `%s` | %s | %s | %d | %s | %s |" % (
            e["kernel"][:44], (e["shape"] or "-")[:30].replace("|", "/"), e["cat"],
            e["count"], ops[:60], st[:90]))
    L.append("")
    return "\n".join(L)


def main():
    force_utf8()
    ap = argparse.ArgumentParser(description=__doc__,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--trace", required=True, help="带 CPU 采集的 trace_view.json")
    ap.add_argument("--repo", default="", help="模型仓库根，用于路径归一化")
    ap.add_argument("--extra-root", action="append", default=[])
    ap.add_argument("--step", type=int, default=None)
    ap.add_argument("--out", required=True, help="输出 json（同名 .md 也会写一份）")
    args = ap.parse_args()

    roots = [r for r in ([args.repo] + args.extra_root) if r]
    print("building map from %s ..." % args.trace, file=sys.stderr)
    m = build_map(args.trace, roots, args.step)
    write_json(args.out, m)
    md = to_md(m)
    with open(os.path.splitext(args.out)[0] + ".md", "w", encoding="utf-8") as fh:
        fh.write(md)
    print(md)
    print("\nwrote %s" % args.out, file=sys.stderr)


if __name__ == "__main__":
    main()

#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""pf_compare.py -- 真机 vs 仿真的性能对齐（用**不带 CPU 采集**的那份数据）。

    python pf_compare.py --real REAL_nocpu/trace_view.json --sim SIM_nocpu/trace_view.json \\
        --map out/kernel_code_map.json --step -2 --out out/perf.md

口径（先说清楚，否则数字没法引用）
----------------------------------
- **设备忙时间**：各 device track 上 kernel `dur` 之和。多条 stream 会并行，所以它**不是**墙钟，
  是"设备侧总工作量"。跨两次运行比它才有意义。
- **墙钟**：所选 step 的时间跨度。仿真的墙钟是模型算出来的，拿它和真机比只能得到
  "仿真器认为这一步要多久"，别当成加速比。
- **建模误差**：`仿真均值 / 真机均值`。这才是评价仿真器的核心指标——不是"仿真快多少倍"，
  而是"仿真对每一类算子的时延估得准不准"。>1 说明仿真估得偏慢，<1 偏快。

为什么必须用不带 CPU 的数据
----------------------------
CPU 采集会给每个算子套上 python_function / aten 事件，host 侧开销被显著抬高，device 侧也会
因为下发节奏改变而失真。带 CPU 那份只用来建 kernel→代码 的映射（见 pf_map.py），
性能结论一律以这份为准。脚本会自己检查：这份数据里要是发现了 python_function，会直接警告。
"""
from __future__ import annotations

import argparse
import json
import os
import sys
from collections import Counter, defaultdict

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from pa_common import (force_utf8, load_trace, normalize_name, shape_of, find_steps,  # noqa: E402
                       parse_pyfunc, write_json, categorize)

# Overlap Analysis 这类派生 track 是 profiler 自己算的占比，正好用来看计算/通信/空闲
_OVERLAP_KEYS = ("computing", "communication", "free", "uncovered", "not overlapped")


def _pct(a, b):
    return "%+.1f%%" % (100.0 * (b - a) / a) if a else "n/a"


def collect(trace_path, step=None):
    tr = load_trace(trace_path)
    steps = find_steps(tr)
    t0 = t1 = None
    window = "整段 trace"
    if step is not None and steps:
        i = step if step >= 0 else len(steps) + step
        i = max(0, min(i, len(steps) - 1))
        nm, t0, t1 = steps[i]
        window = "%s [%.0f, %.0f]" % (nm, t0, t1)

    per_kernel = defaultdict(lambda: {"count": 0, "sum": 0.0, "max": 0.0, "cat": ""})
    per_cat = defaultdict(lambda: {"count": 0, "sum": 0.0})
    per_stream = defaultdict(lambda: {"count": 0, "sum": 0.0})
    overlap = Counter()
    n_py = 0
    lo, hi = None, None

    for tk in tr.tracks.values():
        for ev in tk.events:
            if t0 is not None and not (t0 <= ev["ts"] < t1):
                continue
            if parse_pyfunc(ev["name"]):
                n_py += 1
            if tk.kind == "derived":
                low = ev["name"].strip().lower()
                for k in _OVERLAP_KEYS:
                    if low.startswith(k):
                        overlap[ev["name"].strip()] += ev["dur"]
                        break
                continue
            if tk.side != "device":
                continue
            name = normalize_name(ev["name"])
            # ProfilerStep / Computing 这类是标记和统计条，不是 kernel。
            # 把它们算进耗时会凭空多出一个"最耗时算子"，还会把总量翻倍。
            if name in ("ProfilerStep", "Iteration") or name.strip().lower() in _OVERLAP_KEYS:
                continue
            key = (name, shape_of(ev))
            k = per_kernel[key]
            k["count"] += 1
            k["sum"] += ev["dur"]
            k["max"] = max(k["max"], ev["dur"])
            k["cat"] = categorize(ev["name"])
            c = per_cat[k["cat"]]
            c["count"] += 1
            c["sum"] += ev["dur"]
            s = per_stream[tk.label]
            s["count"] += 1
            s["sum"] += ev["dur"]
            lo = ev["ts"] if lo is None else min(lo, ev["ts"])
            hi = ev["ts"] + ev["dur"] if hi is None else max(hi, ev["ts"] + ev["dur"])

    return {
        "path": trace_path, "window": window, "n_steps": len(steps),
        "python_events": n_py,
        "device_busy_us": sum(v["sum"] for v in per_kernel.values()),
        "wall_us": (hi - lo) if (lo is not None and hi is not None) else 0.0,
        "per_kernel": per_kernel, "per_cat": per_cat, "per_stream": per_stream,
        "overlap": overlap,
    }


def _load_map(path):
    if not path or not os.path.isfile(path):
        return {}, None
    with open(path, "r", encoding="utf-8") as fh:
        m = json.load(fh)
    idx = {}
    for e in m.get("entries") or []:
        stack = e["pyfunc_stacks"][0]["stack"] if e.get("pyfunc_stacks") else ""
        op = e["host_ops"][0]["op"] if e.get("host_ops") else ""
        idx[(e["kernel"], e.get("shape") or "")] = (op, stack)
        idx.setdefault((e["kernel"], "*"), (op, stack))
    return idx, m


def attribute(idx_real, idx_sim, name, shape, prefer="real"):
    """按 (kernel, shape) 查代码归属；查不到再退回只按 kernel 名。

    默认用**真机**那份映射（分析以真机为基准）。但仿真独有的算子在真机映射里根本不存在——
    它们往往正是仿真器的桩产生的（`*_mock` 下发的 kernel）。所以仿真独有的行优先查仿真映射，
    并在结果里标出这条归因来自哪一侧，避免把仿真的东西说成真机代码干的。
    """
    order = [("sim", idx_sim), ("real", idx_real)] if prefer == "sim" else             [("real", idx_real), ("sim", idx_sim)]
    for side, idx in order:
        if not idx:
            continue
        hit = idx.get((name, shape)) or idx.get((name, "*"))
        if hit:
            tag = "" if side == prefer else "（来自%s侧映射）" % ("仿真" if side == "sim" else "真机")
            return (hit[0] or "-"), ((hit[1] or "-") + tag)
    return "-", "-"


def build_report(R, S, idx, idx_sim, mapmeta, mapmeta_sim, top):
    L = ["# 性能对齐报告：真机 vs 仿真（不带 CPU 采集）", ""]

    L += ["## 0. 数据可信度", "",
          "| 项 | real | sim |", "| --- | --- | --- |",
          "| trace | `%s` | `%s` |" % (os.path.basename(os.path.dirname(R["path"])),
                                       os.path.basename(os.path.dirname(S["path"]))),
          "| 窗口 | %s | %s |" % (R["window"], S["window"]),
          "| step 数 | %d | %d |" % (R["n_steps"], S["n_steps"]),
          "| python_function 事件 | %d | %d |" % (R["python_events"], S["python_events"]),
          ""]
    bad = [n for n, d in (("real", R), ("sim", S)) if d["python_events"] > 0]
    if bad:
        L += ["> ⚠️ **%s 侧含 python_function 事件，说明这份是带 CPU 采集的**。"
              "CPU 采集会抬高 host 开销、改变下发节奏，据此得出的耗时结论不可信。"
              "性能对比请换用关掉 CPU activity 的那一份；这一份只该拿去 pf_map.py 建代码映射。"
              % "/".join(bad), ""]
    if R["n_steps"] != S["n_steps"]:
        L += ["> ⚠️ 两侧 step 数不同（%d vs %d），确认 `--step` 选的是同一个位置；"
              "别拿真机的稳态步去比仿真的首步。" % (R["n_steps"], S["n_steps"]), ""]

    L += ["## 1. 总量对照", "",
          "口径：**设备忙时间** = 各 device stream 上 kernel 时长之和（stream 间并行，"
          "所以它不是墙钟，是设备侧总工作量）；**墙钟** = 窗口内首尾跨度。", "",
          "| 指标 | real (us) | sim (us) | 相对差 |", "| --- | --- | --- | --- |",
          "| 设备忙时间 | %.0f | %.0f | %s |" % (R["device_busy_us"], S["device_busy_us"],
                                                _pct(R["device_busy_us"], S["device_busy_us"])),
          "| 墙钟 | %.0f | %.0f | %s |" % (R["wall_us"], S["wall_us"],
                                          _pct(R["wall_us"], S["wall_us"])),
          "", "**仿真的墙钟是模型算出来的**，上面这行只说明『仿真器认为这一步要多久』，"
          "不是加速比，不要当性能结论用。", ""]

    if R["overlap"] or S["overlap"]:
        L += ["### 计算 / 通信 / 空闲（来自 Overlap Analysis）", "",
              "| 项 | real (us) | sim (us) | 相对差 |", "| --- | --- | --- | --- |"]
        for k in sorted(set(R["overlap"]) | set(S["overlap"])):
            a, b = R["overlap"].get(k, 0.0), S["overlap"].get(k, 0.0)
            L.append("| %s | %.0f | %.0f | %s |" % (k, a, b, _pct(a, b)))
        L.append("")

    L += ["## 2. 分类耗时对照", "",
          "| 类别 | real 次数 | real 总时长 | sim 次数 | sim 总时长 | 时长差 | 建模比(sim/real 均值) |",
          "| --- | --- | --- | --- | --- | --- | --- |"]
    for cat in sorted(set(R["per_cat"]) | set(S["per_cat"]),
                      key=lambda c: -(R["per_cat"].get(c, {}).get("sum", 0))):
        a, b = R["per_cat"].get(cat, {"count": 0, "sum": 0.0}), S["per_cat"].get(cat, {"count": 0, "sum": 0.0})
        ma = a["sum"] / a["count"] if a["count"] else 0.0
        mb = b["sum"] / b["count"] if b["count"] else 0.0
        ratio = ("%.2fx" % (mb / ma)) if ma else "n/a"
        L.append("| %s | %d | %.0f | %d | %.0f | %s | %s |" % (
            cat, a["count"], a["sum"], b["count"], b["sum"], _pct(a["sum"], b["sum"]), ratio))
    L.append("")

    rows = []
    for key in set(R["per_kernel"]) | set(S["per_kernel"]):
        a = R["per_kernel"].get(key, {"count": 0, "sum": 0.0, "cat": ""})
        b = S["per_kernel"].get(key, {"count": 0, "sum": 0.0, "cat": ""})
        ma = a["sum"] / a["count"] if a["count"] else 0.0
        mb = b["sum"] / b["count"] if b["count"] else 0.0
        rows.append({"kernel": key[0], "shape": key[1], "cat": a["cat"] or b["cat"],
                     "rc": a["count"], "rs": a["sum"], "rm": ma,
                     "sc": b["count"], "ss": b["sum"], "sm": mb,
                     "dsum": b["sum"] - a["sum"],
                     "ratio": (mb / ma) if ma else None})

    L += ["## 3. 仿真时延建模误差最大的算子（两侧都执行过）", "",
          "只看两侧都跑过的算子，按**单次均值比**排序——这是仿真器建模准不准的直接体现。"
          "次数不同的另见第 5 节。", "",
          "| kernel | shape | 类别 | real 均值 | sim 均值 | 建模比 | real 次数 | 下发它的代码 |",
          "| --- | --- | --- | --- | --- | --- | --- | --- |"]
    both = [r for r in rows if r["rc"] and r["sc"] and r["rs"] > 0]
    both.sort(key=lambda r: -abs((r["ratio"] or 1) - 1) * r["rs"])
    for r in both[:top]:
        op, stack = attribute(idx, idx_sim, r["kernel"], r["shape"])
        L.append("| `%s` | %s | %s | %.1f | %.1f | **%.2fx** | %d | %s |" % (
            r["kernel"][:40], (r["shape"] or "-")[:24].replace("|", "/"), r["cat"],
            r["rm"], r["sm"], r["ratio"] or 0, r["rc"], (stack or op)[:70]))
    L.append("")

    L += ["## 4. 总耗时差最大的算子", "",
          "| kernel | shape | real 总时长 | sim 总时长 | 差值 | 次数 real/sim | 下发它的代码 |",
          "| --- | --- | --- | --- | --- | --- | --- |"]
    for r in sorted(rows, key=lambda x: -abs(x["dsum"]))[:top]:
        op, stack = attribute(idx, idx_sim, r["kernel"], r["shape"])
        L.append("| `%s` | %s | %.0f | %.0f | %+.0f | %d / %d | %s |" % (
            r["kernel"][:40], (r["shape"] or "-")[:24].replace("|", "/"),
            r["rs"], r["ss"], r["dsum"], r["rc"], r["sc"], (stack or op)[:70]))
    L.append("")

    only_r = [r for r in rows if r["rc"] and not r["sc"]]
    only_s = [r for r in rows if r["sc"] and not r["rc"]]
    only_r.sort(key=lambda r: -r["rs"])
    only_s.sort(key=lambda r: -r["ss"])
    L += ["## 5. 只在一侧出现的算子（结构性差异，不是性能问题）", "",
          "这些差异要去**控制流对齐**那边找原因（profiling-alignment-analysis 的结论），"
          "在性能报告里只做登记：它们造成的时间差不能算进『仿真建模误差』。", "",
          "| 只在 | kernel | shape | 次数 | 总时长 | 下发它的代码 |",
          "| --- | --- | --- | --- | --- | --- |"]
    for r in only_r[:top // 2 or 10]:
        op, stack = attribute(idx, idx_sim, r["kernel"], r["shape"])
        L.append("| real | `%s` | %s | %d | %.0f | %s |" % (
            r["kernel"][:40], (r["shape"] or "-")[:24].replace("|", "/"), r["rc"], r["rs"],
            (stack or op)[:70]))
    for r in only_s[:top // 2 or 10]:
        op, stack = attribute(idx, idx_sim, r["kernel"], r["shape"], prefer="sim")
        L.append("| sim | `%s` | %s | %d | %.0f | %s |" % (
            r["kernel"][:40], (r["shape"] or "-")[:24].replace("|", "/"), r["sc"], r["ss"],
            (stack or op)[:70]))
    L.append("")

    L += ["## 6. stream 维度", "",
          "| stream | real 次数 | real 总时长 | sim 次数 | sim 总时长 |",
          "| --- | --- | --- | --- | --- |"]
    for lb in sorted(set(R["per_stream"]) | set(S["per_stream"]),
                     key=lambda x: -(R["per_stream"].get(x, {}).get("sum", 0)))[:12]:
        a = R["per_stream"].get(lb, {"count": 0, "sum": 0.0})
        b = S["per_stream"].get(lb, {"count": 0, "sum": 0.0})
        L.append("| `%s` | %d | %.0f | %d | %.0f |" % (lb, a["count"], a["sum"],
                                                       b["count"], b["sum"]))
    L.append("")

    if mapmeta:
        L += ["## 7. 代码归因的来源", "",
              "上面各表的『下发它的代码』一列来自 `%s`（带 CPU 采集的那次运行，"
              "device 事件 %d 条 / 连上 host %d 条，连通率 %.1f%%）。"
              "键是 (kernel 名, 输入 shape)，与时间戳无关，所以可以跨运行使用。"
              "**主映射取真机侧**：分析以真机为基准，仿真只回答『它和真机差多少』。" % (
                  mapmeta.get("source_trace", "?"), mapmeta.get("device_events", 0),
                  mapmeta.get("linked_to_host", 0), mapmeta.get("link_rate", 0)), ""]
        if mapmeta_sim:
            L += ["另外传了仿真侧映射 `%s`（连通率 %.1f%%），只用于给第 5 节里"
                  "**仅在仿真出现**的算子做归因——它们在真机映射里查不到，"
                  "多半是仿真器的桩下发的。这类归因会标注『来自仿真侧映射』。" % (
                      mapmeta_sim.get("source_trace", "?"), mapmeta_sim.get("link_rate", 0)), ""]
        else:
            L += ["> 没传 `--map-sim`。第 5 节里『仅在仿真出现』的算子会归因不上（显示 `-`），"
                  "因为真机映射里没有它们。想知道那些算子是仿真侧哪段代码下发的，"
                  "就对**仿真的带 CPU 采集**那份也跑一次 pf_map.py，用 `--map-sim` 传进来。", ""]
        if mapmeta.get("link_rate", 0) < 30:
            L.append("> ⚠️ 映射连通率低，很多热点会显示 `-`。补救：建映射那次要开 CPU activity "
                     "和 `with_stack=True`，并确认 trace 里有 `cat=async_npu` 的 flow 事件。")
            L.append("")
    else:
        L += ["## 7. 代码归因", "",
              "> 没有传 `--map`，所以没有代码归因。先用带 CPU 采集的那份跑 `pf_map.py` 生成映射，"
              "再回来加上 `--map`——否则热点只有 kernel 名字，落不到代码上。", ""]
    return "\n".join(L), rows


def main():
    force_utf8()
    ap = argparse.ArgumentParser(description=__doc__,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--real", required=True, help="真机（不带 CPU 采集）trace_view.json")
    ap.add_argument("--sim", required=True, help="仿真（不带 CPU 采集）trace_view.json")
    ap.add_argument("--map", default="",
                    help="真机侧 pf_map.py 产出的 kernel_code_map.json（主映射）")
    ap.add_argument("--map-sim", default="",
                    help="仿真侧的映射（可选）：只用来给『仅在仿真出现』的算子做归因，"
                         "那些算子在真机映射里查不到")
    ap.add_argument("--step", type=int, default=None)
    ap.add_argument("--top", type=int, default=25)
    ap.add_argument("--out", default="")
    args = ap.parse_args()

    print("loading real ...", file=sys.stderr)
    R = collect(args.real, args.step)
    print("loading sim ...", file=sys.stderr)
    S = collect(args.sim, args.step)
    idx, mapmeta = _load_map(args.map)
    idx_sim, mapmeta_sim = _load_map(args.map_sim)
    md, rows = build_report(R, S, idx, idx_sim, mapmeta, mapmeta_sim, args.top)
    print(md)
    if args.out:
        os.makedirs(os.path.dirname(os.path.abspath(args.out)) or ".", exist_ok=True)
        with open(args.out, "w", encoding="utf-8") as fh:
            fh.write(md)
        write_json(os.path.splitext(args.out)[0] + ".json", {
            "real": {"path": R["path"], "window": R["window"],
                     "device_busy_us": R["device_busy_us"], "wall_us": R["wall_us"],
                     "python_events": R["python_events"]},
            "sim": {"path": S["path"], "window": S["window"],
                    "device_busy_us": S["device_busy_us"], "wall_us": S["wall_us"],
                    "python_events": S["python_events"]},
            "kernels": rows,
        })
        print("\nwrote %s" % args.out, file=sys.stderr)


if __name__ == "__main__":
    main()

# 两阶段方法：原理、采集参数、常见坑

## 为什么必须分两次采

CPU 采集（`ProfilerActivity.CPU` + `with_stack=True`）给每一次 Python 调用、每一个 aten 算子
都插了事件。代价是：

- host 侧开销显著上升，下发变慢；
- device 侧因此出现本来没有的空隙，kernel 之间的排布被改变；
- 整体墙钟被拉长，且拉长的比例在不同算子上不一样。

所以带 CPU 那份的耗时**不能**当性能真值。但它是唯一能把 device kernel 连回 Python 代码的数据。
两阶段就是把"结构"和"耗时"分别从两次运行里取，再用一个跨运行稳定的键拼起来。

## 为什么 kernel 构成不受影响

CPU 采集改变的是**时间**，不是**做了什么**。同一份代码、同一份输入，两次运行下发的 kernel
种类和数量应当一致（除非模型里有依赖时间/随机性的控制流）。`pf_verify.py` 用 kernel 构成
重合度来验证这一点——重合度高，说明可以把 A 的映射套到 B 上。

## 采集参数

phase A（建映射）：

```python
torch_npu.profiler.profile(
    activities=[torch_npu.profiler.ProfilerActivity.CPU,
                torch_npu.profiler.ProfilerActivity.NPU],
    with_stack=True, with_modules=True, record_shapes=True,
    experimental_config=torch_npu.profiler._ExperimentalConfig(
        profiler_level=torch_npu.profiler.ProfilerLevel.Level1),
)
```

phase B（测性能）：

```python
torch_npu.profiler.profile(
    activities=[torch_npu.profiler.ProfilerActivity.NPU],   # 关键：不要 CPU
    with_stack=False, record_shapes=True,                   # shape 要留着，它是映射的键
    experimental_config=torch_npu.profiler._ExperimentalConfig(
        profiler_level=torch_npu.profiler.ProfilerLevel.Level1),
)
```

**`record_shapes=True` 在 phase B 也要开。** 映射的键是 `(kernel 名, 输入 shape)`；
phase B 少了 shape，就只能退化成按 kernel 名匹配，同名不同 shape 的算子会被混在一起，
均值失真。

两次运行的模型代码、配置、输入必须完全一致，包括随机种子和数据顺序。

## 常见坑

**把 phase A 的耗时写进报告。** 最常见也最致命。`pf_compare.py` 见到 python_function
就会警告，但报告是人写的，得自己盯住。

**只按 kernel 名聚合。** `MatMulV3` 在 `2,4096,8192` 和 `2,512,8192` 下差一个数量级，
混在一起的均值没有任何意义。永远带 shape。

**把结构性差异算成建模误差。** 仿真少跑了一整段（桩、分支翻转），少掉的时间不是"估快了"。
先把只在一侧出现的算子扣掉，再算建模比。

**拿墙钟比。** 仿真的墙钟是模型输出，不是测量值。"仿真比真机快 3 倍"这句话没有信息量。

**通信类当成精度问题。** 仿真器对 HCCL 的实现方式常常和真机根本不同（真机
`NOTIFY_WAIT_SQE` / `UBDMA`，仿真 `DAVID_EVENT_*` / `MEMCPY_ASYNC`）。
这时"建模比"衡量的是两种实现的差距，不是同一实现的估计精度，要单独说明。

**映射连通率低。** flow 事件（`cat=async_npu`）缺失时，kernel 连不回 host 算子。
检查 phase A 是不是真的开了 CPU activity；`pf_map.py` 会把连通率打出来。

## 结果怎么用

- 建模比集中偏离 1 的**类别**，就是仿真器该优先改进的建模方向；
- 建模比接近 1 但绝对时间大的算子，说明仿真器在这里是准的，可以放心用；
- 只在一侧出现的算子，交给控制流分析（`profiling-alignment-analysis`）；
- 归因到的代码位置，是"这段代码的性能在仿真里不可信"的清单，可以直接交给模型开发。

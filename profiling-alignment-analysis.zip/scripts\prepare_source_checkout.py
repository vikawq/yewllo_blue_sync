#!/usr/bin/env python3
"""Prepare a non-executed, clean Git source checkout for profiling analysis.

Only HTTP(S) Git URLs are accepted.  Repository hooks, credential helpers,
LFS smudge filters, submodule recursion, and non-HTTP transports are disabled
for every Git subprocess.  Repository code is never imported or executed.
"""

from __future__ import annotations

import argparse
import json
import os
import re
import shutil
import subprocess
import sys
import tempfile
import uuid
from dataclasses import dataclass
from pathlib import Path, PurePosixPath
from typing import Any, Sequence
from urllib.parse import parse_qsl, unquote, urlsplit, urlunsplit


MANIFEST_NAME = "source_checkout_manifest.json"
GIT_TIMEOUT_SECONDS = 300
SENSITIVE_QUERY_RE = re.compile(
    r"(?:^|[_-])(?:access[_-]?token|api[_-]?key|auth|authorization|credential|"
    r"jwt|oauth|pass(?:word)?|private[_-]?token|secret|signature|sig|token)(?:$|[_-])",
    re.IGNORECASE,
)
SAFE_FILE_QUERY_KEYS = {"plain", "raw", "ref_type"}
REVISION_RE = re.compile(r"^[A-Za-z0-9][A-Za-z0-9._/@+-]{0,511}$")


class SourceCheckoutError(RuntimeError):
    """A fail-closed validation or Git preparation error."""


@dataclass(frozen=True)
class ParsedSourceURL:
    provider: str
    kind: str
    repository_url: str
    url_ref: str | None
    entry_path: str | None
    sanitized_source_url: str


def _contains_control(value: str) -> bool:
    return any(ord(char) < 32 or ord(char) == 127 for char in value)


def _validate_query(query: str, *, file_url: bool) -> None:
    if not query:
        return
    pairs = parse_qsl(query, keep_blank_values=True, strict_parsing=False)
    if not pairs:
        raise SourceCheckoutError("URL query is malformed")
    for key, _value in pairs:
        normalized = key.strip().lower()
        if not normalized or SENSITIVE_QUERY_RE.search(normalized):
            raise SourceCheckoutError("URL query contains a sensitive or empty key")
        if not file_url or normalized not in SAFE_FILE_QUERY_KEYS:
            raise SourceCheckoutError("URL query is not permitted for this source URL")


def _decoded_segments(path: str) -> list[str]:
    if "\\" in path or _contains_control(path):
        raise SourceCheckoutError("URL path contains an unsafe character")
    decoded = unquote(path)
    if "\\" in decoded or _contains_control(decoded):
        raise SourceCheckoutError("URL path contains an unsafe encoded character")
    if "//" in decoded:
        raise SourceCheckoutError("URL path contains an empty segment")
    segments = [part for part in decoded.split("/") if part]
    if not segments or any(part in {".", ".."} for part in segments):
        raise SourceCheckoutError("URL path is empty or traverses outside the repository")
    return segments


def _normalize_entry(value: str | None) -> str | None:
    if value is None:
        return None
    value = unquote(value.strip())
    if not value:
        raise SourceCheckoutError("entry path must not be empty")
    if "\\" in value or _contains_control(value):
        raise SourceCheckoutError("entry path contains an unsafe character")
    path = PurePosixPath(value)
    if path.is_absolute() or any(part in {"", ".", ".."} for part in path.parts):
        raise SourceCheckoutError("entry path must stay below the repository root")
    if path.parts and re.match(r"^[A-Za-z]:", path.parts[0]):
        raise SourceCheckoutError("entry path must not contain a drive prefix")
    return path.as_posix()


def _repository_url(scheme: str, host: str, port: int | None, parts: Sequence[str]) -> str:
    if not parts:
        raise SourceCheckoutError("repository path is empty")
    repo_parts = list(parts)
    repo_parts[-1] = repo_parts[-1][:-4] if repo_parts[-1].lower().endswith(".git") else repo_parts[-1]
    if not repo_parts[-1]:
        raise SourceCheckoutError("repository name is empty")
    netloc_host = f"[{host}]" if ":" in host else host
    netloc = f"{netloc_host}:{port}" if port is not None else netloc_host
    return urlunsplit((scheme, netloc, "/" + "/".join(repo_parts) + ".git", "", ""))


def parse_source_url(source_url: str) -> ParsedSourceURL:
    """Parse a repository or supported provider blob URL without network I/O."""

    if not source_url or source_url != source_url.strip() or _contains_control(source_url):
        raise SourceCheckoutError("source URL is empty or contains whitespace/control characters")
    try:
        parsed = urlsplit(source_url)
    except ValueError as exc:
        raise SourceCheckoutError("source URL is malformed") from exc
    scheme = parsed.scheme.lower()
    if scheme not in {"http", "https"}:
        raise SourceCheckoutError("only http/https source URLs are allowed")
    if parsed.username is not None or parsed.password is not None or "@" in parsed.netloc:
        raise SourceCheckoutError("source URL userinfo is forbidden")
    try:
        parsed_hostname = parsed.hostname
    except ValueError as exc:
        raise SourceCheckoutError("source URL hostname is malformed") from exc
    if not parsed_hostname:
        raise SourceCheckoutError("source URL has no hostname")
    try:
        port = parsed.port
    except ValueError as exc:
        raise SourceCheckoutError("source URL has an invalid port") from exc

    host = parsed_hostname.lower().rstrip(".")
    provider_host = host[4:] if host.startswith("www.") else host
    provider = {
        "github.com": "github",
        "gitcode.com": "gitcode",
        "gitlab.com": "gitlab",
    }.get(provider_host, "generic")
    segments = _decoded_segments(parsed.path)

    marker_index: int | None = None
    marker_width = 0
    if provider in {"gitlab", "gitcode"}:
        for index in range(len(segments) - 1):
            if segments[index] == "-" and segments[index + 1].lower() in {"blob", "file"}:
                marker_index = index
                marker_width = 2
                break
    if (
        marker_index is None
        and provider in {"github", "gitcode"}
        and len(segments) > 2
        and segments[2].lower() in {"blob", "file"}
    ):
        marker_index = 2
        marker_width = 1

    if marker_index is not None:
        repo_parts = segments[:marker_index]
        tail = segments[marker_index + marker_width :]
        if len(repo_parts) < 2 or len(tail) < 2:
            raise SourceCheckoutError("blob/file URL must include repository, ref, and entry path")
        url_ref = tail[0]
        entry_path = _normalize_entry("/".join(tail[1:]))
        kind = "file"
        _validate_query(parsed.query, file_url=True)
    else:
        repo_parts = segments
        url_ref = None
        entry_path = None
        kind = "repository"
        _validate_query(parsed.query, file_url=False)
        if provider in {"github", "gitcode"} and len(repo_parts) != 2:
            raise SourceCheckoutError("provider repository URL must identify exactly owner/repository")
        if provider == "gitlab" and len(repo_parts) < 2:
            raise SourceCheckoutError("GitLab repository URL must identify namespace/repository")
        if provider == "generic" and not repo_parts[-1].lower().endswith(".git"):
            raise SourceCheckoutError("generic HTTP(S) Git URLs must end in .git")

    repo_url = _repository_url(scheme, host, port, repo_parts)
    sanitized = urlunsplit((scheme, parsed.netloc, parsed.path, "", ""))
    return ParsedSourceURL(
        provider=provider,
        kind=kind,
        repository_url=repo_url,
        url_ref=url_ref,
        entry_path=entry_path,
        sanitized_source_url=sanitized,
    )


def _validate_revision(revision: str | None) -> str | None:
    if revision is None:
        return None
    revision = revision.strip()
    if (
        not revision
        or revision.startswith("-")
        or not REVISION_RE.fullmatch(revision)
        or ".." in revision
        or "//" in revision
        or revision.endswith((".", "/", ".lock"))
    ):
        raise SourceCheckoutError("commit/ref contains an unsafe character")
    return revision


def _git_environment() -> dict[str, str]:
    env = os.environ.copy()
    env.update(
        {
            "GIT_TERMINAL_PROMPT": "0",
            "GCM_INTERACTIVE": "Never",
            "GIT_LFS_SKIP_SMUDGE": "1",
            "GIT_CONFIG_NOSYSTEM": "1",
            "GIT_CONFIG_GLOBAL": os.devnull,
            "LC_ALL": "C",
            "LANG": "C",
        }
    )
    return env


def _git_prefix(hooks_dir: Path) -> list[str]:
    return [
        "git",
        "-c",
        f"core.hooksPath={hooks_dir}",
        "-c",
        "credential.helper=",
        "-c",
        "core.askPass=",
        "-c",
        "filter.lfs.smudge=",
        "-c",
        "filter.lfs.process=",
        "-c",
        "filter.lfs.required=false",
        "-c",
        "submodule.recurse=false",
        "-c",
        "fetch.recurseSubmodules=false",
        "-c",
        "protocol.allow=never",
        "-c",
        "protocol.http.allow=always",
        "-c",
        "protocol.https.allow=always",
        "-c",
        "http.followRedirects=initial",
    ]


def run_git(
    args: Sequence[str],
    *,
    hooks_dir: Path,
    cwd: Path,
    check: bool = True,
) -> subprocess.CompletedProcess[str]:
    command = [*_git_prefix(hooks_dir), *args]
    try:
        result = subprocess.run(
            command,
            cwd=cwd,
            env=_git_environment(),
            capture_output=True,
            text=True,
            encoding="utf-8",
            errors="replace",
            timeout=GIT_TIMEOUT_SECONDS,
            check=False,
            shell=False,
        )
    except (OSError, subprocess.TimeoutExpired) as exc:
        raise SourceCheckoutError(f"Git command could not complete: {args[0]}") from exc
    if check and result.returncode != 0:
        detail = (result.stderr or result.stdout).strip().replace("\r", " ").replace("\n", " ")
        raise SourceCheckoutError(f"Git {args[0]} failed: {detail[:500] or 'no diagnostic'}")
    return result


def _rev_parse(repo: Path, revision: str, hooks_dir: Path) -> str | None:
    result = run_git(
        ["rev-parse", "--verify", "--end-of-options", f"{revision}^{{commit}}"],
        hooks_dir=hooks_dir,
        cwd=repo,
        check=False,
    )
    if result.returncode != 0:
        return None
    value = result.stdout.strip().splitlines()[0] if result.stdout.strip() else ""
    return value if re.fullmatch(r"[0-9a-fA-F]{40,64}", value) else None


def _resolve_revision(
    repo: Path,
    *,
    requested_commit: str | None,
    url_ref: str | None,
    hooks_dir: Path,
) -> tuple[str, str]:
    selector = requested_commit or url_ref or "HEAD"
    candidates: list[str]
    if requested_commit:
        candidates = [requested_commit]
    elif url_ref:
        candidates = [f"refs/remotes/origin/{url_ref}", f"origin/{url_ref}", url_ref]
    else:
        candidates = ["HEAD", "refs/remotes/origin/HEAD"]
    for candidate in candidates:
        resolved = _rev_parse(repo, candidate, hooks_dir)
        if resolved:
            return selector, resolved

    if selector == "HEAD":
        raise SourceCheckoutError("cloned repository has no resolvable default HEAD")
    run_git(
        ["fetch", "--no-tags", "--no-recurse-submodules", "origin", selector],
        hooks_dir=hooks_dir,
        cwd=repo,
    )
    resolved = _rev_parse(repo, "FETCH_HEAD", hooks_dir)
    if not resolved:
        raise SourceCheckoutError("requested commit/ref did not resolve to a commit")
    return selector, resolved


def _is_link_like(path: Path) -> bool:
    if path.is_symlink():
        return True
    is_junction = getattr(path, "is_junction", None)
    return bool(is_junction and is_junction())


def _validate_output(output: Path) -> tuple[Path, bool]:
    output = Path(os.path.abspath(os.fspath(output.expanduser())))
    existed_empty = output.exists()
    if existed_empty:
        if _is_link_like(output) or not output.is_dir():
            raise SourceCheckoutError("output must be a real directory, not a file or symlink")
        try:
            if next(output.iterdir(), None) is not None:
                raise SourceCheckoutError("output directory must be absent or empty")
        except OSError as exc:
            raise SourceCheckoutError("output directory cannot be inspected") from exc
    parent = output.parent
    parent.mkdir(parents=True, exist_ok=True)
    if not parent.is_dir():
        raise SourceCheckoutError("output parent is not a directory")
    return output, existed_empty


def _entry_on_disk(repo: Path, entry: str | None) -> tuple[str | None, Path | None]:
    if entry is None:
        return None, None
    normalized = _normalize_entry(entry)
    assert normalized is not None
    root = repo.resolve(strict=True)
    candidate = repo.joinpath(*PurePosixPath(normalized).parts)
    try:
        resolved = candidate.resolve(strict=True)
    except OSError as exc:
        raise SourceCheckoutError(f"entry does not exist in resolved checkout: {normalized}") from exc
    try:
        resolved.relative_to(root)
    except ValueError as exc:
        raise SourceCheckoutError("entry resolves outside the repository root") from exc
    return normalized, resolved


def _ignore_manifest(repo: Path) -> None:
    exclude = repo / ".git" / "info" / "exclude"
    exclude.parent.mkdir(parents=True, exist_ok=True)
    existing = exclude.read_text(encoding="utf-8", errors="replace") if exclude.exists() else ""
    rule = f"/{MANIFEST_NAME}"
    if rule not in {line.strip() for line in existing.splitlines()}:
        separator = "" if not existing or existing.endswith("\n") else "\n"
        exclude.write_text(existing + separator + rule + "\n", encoding="utf-8", newline="\n")


def _status(repo: Path, hooks_dir: Path) -> str:
    return run_git(
        ["status", "--porcelain=v1", "--untracked-files=all"],
        hooks_dir=hooks_dir,
        cwd=repo,
    ).stdout.strip()


def prepare_checkout(
    *,
    source_url: str,
    output: Path,
    commit: str | None = None,
    entry: str | None = None,
) -> dict[str, Any]:
    parsed = parse_source_url(source_url)
    requested_commit = _validate_revision(commit)
    url_ref = _validate_revision(parsed.url_ref)
    explicit_entry = _normalize_entry(entry) if entry is not None else None
    selected_entry = explicit_entry or parsed.entry_path
    entry_source = "--entry" if explicit_entry is not None else ("source-url" if parsed.entry_path else "none")
    output, existed_empty = _validate_output(output)

    token = uuid.uuid4().hex
    staging = Path(tempfile.mkdtemp(prefix=f".prepare-source-checkout-{token}-", dir=output.parent))
    hooks_dir = Path(tempfile.mkdtemp(prefix=f".prepare-source-hooks-{token}-", dir=output.parent))
    published = False
    try:
        run_git(
            [
                "clone",
                "--no-checkout",
                "--filter=blob:none",
                "--no-tags",
                parsed.repository_url,
                str(staging),
            ],
            hooks_dir=hooks_dir,
            cwd=output.parent,
        )
        selector, resolved_head = _resolve_revision(
            staging,
            requested_commit=requested_commit,
            url_ref=url_ref,
            hooks_dir=hooks_dir,
        )
        run_git(
            ["checkout", "--detach", "--force", resolved_head, "--"],
            hooks_dir=hooks_dir,
            cwd=staging,
        )
        actual_head = run_git(
            ["rev-parse", "--verify", "HEAD"], hooks_dir=hooks_dir, cwd=staging
        ).stdout.strip()
        if actual_head.lower() != resolved_head.lower():
            raise SourceCheckoutError("detached checkout HEAD does not equal the resolved commit")
        tree_hash = run_git(
            ["rev-parse", "--verify", "HEAD^{tree}"], hooks_dir=hooks_dir, cwd=staging
        ).stdout.strip()
        remote = run_git(
            ["remote", "get-url", "origin"], hooks_dir=hooks_dir, cwd=staging
        ).stdout.strip()
        normalized_entry, _staging_entry = _entry_on_disk(staging, selected_entry)
        if (staging / MANIFEST_NAME).exists():
            raise SourceCheckoutError(f"repository already contains reserved artifact: {MANIFEST_NAME}")
        _ignore_manifest(staging)
        before_publish_status = _status(staging, hooks_dir)
        if before_publish_status:
            raise SourceCheckoutError("checkout worktree is not clean before publication")

        if output.exists():
            if _is_link_like(output) or not output.is_dir() or next(output.iterdir(), None) is not None:
                raise SourceCheckoutError("output changed while checkout was being prepared")
            output.rmdir()
        os.replace(staging, output)
        published = True

        final_status = _status(output, hooks_dir)
        if final_status:
            raise SourceCheckoutError("published checkout worktree is not clean")
        resolved_entry_path = (
            str(output.joinpath(*PurePosixPath(normalized_entry).parts).resolve(strict=True))
            if normalized_entry
            else None
        )
        manifest: dict[str, Any] = {
            "schema_version": 1,
            "status": "complete" if requested_commit is not None else "partial",
            "binding_status": "verified" if requested_commit is not None else "unverified",
            "source_url": parsed.sanitized_source_url,
            "source_url_kind": parsed.kind,
            "provider": parsed.provider,
            "repository_url": parsed.repository_url,
            "requested_commit": requested_commit,
            "url_ref": parsed.url_ref,
            "checkout_selector": selector,
            "resolved_head": actual_head,
            "tree_hash": tree_hash,
            "remote": remote,
            "entry": normalized_entry,
            "entry_source": entry_source,
            "resolved_entry": resolved_entry_path,
            "entry_exists": normalized_entry is None or resolved_entry_path is not None,
            "checkout_root": str(output),
            "manifest_path": str(output / MANIFEST_NAME),
            "worktree_clean": True,
            "worktree_status": "",
            "repository_code_executed": False,
            "safety_policy": {
                "allowed_source_schemes": ["http", "https"],
                "userinfo_forbidden": True,
                "sensitive_query_forbidden": True,
                "subprocess_shell": False,
                "git_hooks": "disabled-via-command-line-core.hooksPath",
                "credential_helpers": "disabled",
                "interactive_credentials": "disabled",
                "lfs_smudge": "disabled",
                "submodules": "not-initialized",
                "clone_options": ["--no-checkout", "--filter=blob:none", "--no-tags"],
                "protocol_policy": "deny-by-default; http/https only",
                "repository_imported_or_executed": False,
            },
        }
        manifest_path = output / MANIFEST_NAME
        manifest_path.write_text(
            json.dumps(manifest, ensure_ascii=False, indent=2) + "\n",
            encoding="utf-8",
            newline="\n",
        )
        after_manifest_status = _status(output, hooks_dir)
        if after_manifest_status:
            raise SourceCheckoutError("manifest exclusion failed; worktree is not clean")
        return manifest
    finally:
        if not published and staging.exists():
            shutil.rmtree(staging, ignore_errors=True)
        if existed_empty and not published and not output.exists():
            output.mkdir(parents=False, exist_ok=True)
        shutil.rmtree(hooks_dir, ignore_errors=True)


def self_test() -> int:
    github = parse_source_url("https://github.com/acme/model/blob/main/src/model.py#L10")
    assert github.repository_url == "https://github.com/acme/model.git"
    assert github.url_ref == "main"
    assert github.entry_path == "src/model.py"
    gitlab = parse_source_url("https://gitlab.com/group/sub/repo/-/blob/v1/launch.sh?plain=1")
    assert gitlab.repository_url == "https://gitlab.com/group/sub/repo.git"
    assert gitlab.entry_path == "launch.sh"
    for bad in (
        "file:///tmp/repo.git",
        "https://user:pass@github.com/acme/model.git",
        "https://github.com/acme/model.git?access_token=secret",
    ):
        try:
            parse_source_url(bad)
        except SourceCheckoutError:
            pass
        else:
            raise AssertionError(f"unsafe URL accepted: {bad}")
    print(json.dumps({"status": "pass", "checks": 5}, ensure_ascii=False))
    return 0


def parse_args(argv: list[str] | None = None) -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--source-url", help="HTTP(S) Git repository or supported blob/file URL")
    parser.add_argument("--output", type=Path, help="Absent or empty destination directory")
    parser.add_argument("--commit", help="Optional exact commit/ref; enables verified binding")
    parser.add_argument("--entry", help="Optional repository-relative analysis entry path")
    parser.add_argument("--self-test", action="store_true", help="Run parser safety self-test")
    args = parser.parse_args(argv)
    if not args.self_test and (not args.source_url or args.output is None):
        parser.error("--source-url and --output are required unless --self-test is used")
    return args


def main(argv: list[str] | None = None) -> int:
    args = parse_args(argv)
    if args.self_test:
        return self_test()
    try:
        manifest = prepare_checkout(
            source_url=args.source_url,
            output=args.output,
            commit=args.commit,
            entry=args.entry,
        )
    except (SourceCheckoutError, OSError) as exc:
        print(json.dumps({"status": "error", "error": str(exc)}, ensure_ascii=False), file=sys.stderr)
        return 2
    print(json.dumps(manifest, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

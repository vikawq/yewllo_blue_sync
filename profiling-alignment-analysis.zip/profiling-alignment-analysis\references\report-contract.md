# Profiling Alignment 中文报告契约

最终只生成一份主报告 `profiling_alignment_report.md`，并保留脚本产生的 CSV/JSON/HTML 证据目录。正文、标题、表头、结论与建议用中文；算子、源码符号、字段、路径和 URL 保留原文。

报告开头必须声明：

```text
reference = 真机
candidate = 仿真
本报告只分析算子结构、顺序、嵌套、Shape 与控制流；不分析耗时或性能。
ts/dur 仅在解析器内部用于排序、B/E 配对、嵌套和 direct flow 端点恢复。
```

统一标签：

- `真机事实`：真机 Profiler/metadata/marker 直接给出；
- `仿真事实`：仿真产物直接给出；
- `源码事实`：固定版本源码直接存在；
- `强关联推断`：运行结构与源码 guard 同时吻合；
- `静态候选`：仅静态可达或运行绑定不足；
- `未知`：当前不可观测；
- `建议`：最小补证或 A/B。

禁止出现性能排序、耗时、延迟、利用率、重叠、空闲、带宽、duration ratio 或“仿真比真机快/慢”。如果原始文件含时间字段，也不复制到主报告。

报告必须是有效 UTF-8，并通过 raw-text C0 控制字符扫描。只允许 LF 或成对 CRLF 行尾；TAB、BEL、FF、token 内 standalone CR、其余 `U+0000..U+001F` 与 `U+007F` 均是阻断项。尤其不能把 Python/JSON 字符串中的 `\a`、`\t`、`\f`、`\r` 误解释后写坏 `aten`、`torch`、`forward_*`、`record_*` 或 Windows 路径。不要凭显示结果猜修，回到结构化证据重新生成。

## 1. 执行摘要

必须包含：

1. 两侧路径、模型/workload/phase/schedule、源码版本；
2. 两侧采集格式门禁：integrated text export / raw msprof / DB-only，及 collection contract 的 complete/partial/unsupported；
3. 真机/仿真 Rank 清单、实际比较的同号交集、metadata/目录 Rank 冲突与未配对 Rank；
4. framework Host、Host launch、Device lane 数，以及 matched/ambiguous/real-only/sim-only 数；
5. 每 Rank 是否出现结构分叉；必须逐 Rank 独立列证据，不能只写“Rank 0–3 通用”；
6. 最重要的 3–5 条稳定分叉，优先首次 framework Host 分叉；
7. 已证实、强关联、静态候选、未知各自数量；
8. 能否判定仿真 tensor 计算错误；若不能，必须写“当前证据无法判定/未证实”，不能把它写成“否”；
9. 三个最小验证动作。

执行摘要中的每条 `强关联控制流分叉` 或 `已证实控制流分叉` 必须在同一单元格写出 `evidence_id=<...>`；普通结构分叉必须写 `divergence_id=<...>`。不得把某一个 Rank 或 Thread 外推成全部 Rank。Rank 身份为 `directory order`/枚举顺序时不允许进入 paired 表，必须列为 unknown/unpaired。跨 Rank、Thread、stream 的 aggregate calls 可另列 coverage 摘要，但不能替代逐 Rank/lane 行，也不能成为首次分叉或控制流强度证据。

## 2. Rank 与 Thread 覆盖

Rank 主表：

| Rank pair | 真机 trace/hash | 仿真 trace/hash | DP/TP/EP/PP/CP/DCP | 身份/拓扑门禁 | Framework/launch lanes 真/仿 | Device lanes 真/仿 | 状态 |
|---|---|---|---|---|---:|---:|---|

Thread/lane 主表：

| Rank | Domain | Semantic layer | 真机 lane | 仿真 lane | 方法 | Score/Margin | 置信度 | 状态 | 允许结论 |
|---|---|---|---|---|---|---|---|---|---|

逐项列出 ambiguous、real-only、sim-only，不只汇总数量。说明 PID/TID/stream 是环境内标识，跨环境配对依赖语义指纹。

`N/A`、`unknown` 或缺失 Stream ID 只能列为 `lane_observability=rank-only` 的 Device coverage，不计入 Device stream lane 数，不与另一侧 stream 配对。

## 3. Host 算子序列与首次分叉

每个 matched Host Thread 至少给一行；无差异也要写 `exact/no divergence`。

| divergence_id / Rank/Thread pair | 前/后 anchor 数与门禁 | 最后共同 anchor | 真机首差异算子/Shape/calls | 仿真首差异算子/Shape/calls | 下一共同 anchor | 三视图边界/重复歧义 | Stack/module | event IDs |
|---|---|---|---|---|---|---|---|---|

对重大分叉展示前后少量 `event_alignment.csv` 上下文，保留 `alignment_column`、relation 和 event ID。不要用长 equal 前缀淹没首差异。

`boundary_stability=stable` 必须逐项引用 op-only、op+metadata、tree-aware 三个边界都存在且相同（或三者都无差异），并引用 anchor/repeated/nesting gates。只检查两个视图时必须写 `unstable/insufficient`。调用数必须按当前 Rank/Thread 展示；全局 `216`、`109 vs 79` 之类聚合值不能代替 lane 内 `real_run_calls/sim_run_calls`。

结构热力图必须标为“序位热力图”：x 轴是 lane 内 event ordinal，不是时间。可嵌入或链接 `structural_heatmap.html`，但结论引用逐事件表。

## 4. Device 序列与 Host→Device

Device 表：

| Rank/stream pair | 真机首差异 kernel/Shape/dtype/format | 仿真首差异 | 边界稳定性 | 证据来源 | Host link 状态 |
|---|---|---|---|---|---|

Host→Device 表：

| Rank/环境 | Host event/operator+layer | Device event/kernel | Link 类型/namespace | Endpoint match | ID hash | Causal eligible | 证据 |
|---|---|---|---|---|---|---|---|

没有 direct flow/correlation 时，明确写“Host 与 Device 差异尚未形成直接因果边”，禁止用时间邻近补链。

Host launch/kernel 总数、二者比例、Device kernel 类别总数及百分比只是 coverage-dependent 聚合观察。没有合格 direct link 时，不得据此推断“某 Host/FSDP 分支产生了这些 Device kernel”或“额外 workload”。

另列 `host_launch` bridge 表，明确 CANN/AscendCL/GE/Runtime/enqueue/dequeue 均为 Host。每条 Host→Device 因果应显示 flow namespace、ID kind、端点匹配方式与唯一性；ambiguous group 只作观察，不进入 direct link 表。

## 5. 控制流与代码证据

对每个高价值 Host 分叉给出最短证据链：

```text
.sh/argv/config
  -> Python entry/main/forward
  -> file:symbol:if/elif/else predicate
  -> 真机 arm / 仿真 arm
  -> 两侧 branch-exclusive Host operators
  -> direct-linked Device kernels（若有）
```

Guard 主表：

| evidence_id / Rank/Thread | divergence_id | Lane/anchor/入口/源码门禁 | guard_id + predicate | Repo@commit | File/symbol/guard+arm lines | 真机 arm+算子 | 仿真 arm+算子 | Coverage/Precision | Runtime 绑定 | 强度 |
|---|---|---|---|---|---|---|---|---|---|---|

每条代码证据引用 repo、commit/ref、path、symbol、紧凑行范围、permalink 和 runtime binding。源码版本冲突时只作参考，不给运行因果。

Stack 到函数/调用点只是 source-navigation clue，不是 guard。Guard 行必须来自 AST 产物并具备 `guard_id`、原始 predicate、guard kind、guard/arm 精确行范围，以及两侧 branch-exclusive operator 映射。若候选位于 TorchNPU/FSDP patch，必须分别绑定两侧该依赖源码/构建版本；模型仓 commit 不能替代依赖版本。`runtime_binding=unverified/conflict`、两侧 `analyzed_source` 非 verified-equal 或只解析了一侧版本时，最多为 `静态候选`。

每条 `强关联控制流分叉`/`已证实控制流分叉` 还必须引用 `python_guard_snapshots.json` 的同一 `evidence_id`，并把 `python_guard_snapshots.md` 中该 ID 对应的完整静态 HTML 片段直接嵌入主 Markdown。片段至少显示 repository、完整 commit/tree、`.py` path、symbol、guard/real arm/sim arm 行范围、source SHA、snippet SHA；代码逐行放入 HTML-escaped `<code>` 单元格，左侧保留原始 1-based 行号，并分别标记 predicate、真机 arm、仿真 arm。不能只给 C/C++ stack、函数名、网页链接或无行号代码块；`.cc/.cpp/.h` 只能另列为 backend/bridge 线索。HTML 禁止 `<script>`、事件属性、外部样式/资源和可执行导出。

主报告禁止 HTML comments、Unicode `Cf`（零宽/双向等隐藏格式字符）以及快照以外的 raw HTML。不要用 comment、零宽字符、HTML entity、Markdown emphasis 或物理换行拆开强度名称、Perfetto 状态、evidence ID 或算子 token；验证器按可见 Markdown 规范化，并把同一普通段落的任意数量 soft-wrap 行作为一个逻辑记录。每条升级结论及其完整 ID 必须位于同一表格行或同一逻辑段落。

## 6. Predicate tensor 与 producer

表：

| Guard | Operand | 类型 | 真机直接值/result | 仿真直接值/result | 静态 producer | Producer Host event | Device link | 证据状态 | 缺失补证 |
|---|---|---|---|---|---|---|---|---|---|

严格区分：

- `直接 runtime value`；
- `直接 Shape/dtype metadata`；
- `最近静态 assignment`；
- `从下游算子推测`（不能作值证据）；
- `未知`。

如果缺少 predicate operand 值，不得写“仿真把该 tensor 算错”；只能写 guard 与不同算子 arm 强关联，并给最小 hook schema。

## 7. Perfetto 内容复核

每个 Rank 两侧各一行；注明 Perfetto 只交叉复核 Host framework/launch track，Device 顺序与 flow 的主证据来自本地结构解析：

| Rank/环境 | Trace SHA | Lane batch 覆盖 | Offline/SW/localOnly 门禁 | HTML/text/SQL 已读 | 观察 | Screenshot 已看 | Canvas 结论 |
|---|---|---|---|---|---|---|---|

必须拆开：

1. 页面/SQL 自动产物；
2. 分析代理实际读取 HTML/text/SQL 的内容复核；
3. 可选 Canvas 截图复核。

未查看 PNG 时 `Screenshot 已看=否`、`Canvas 结论=未评价`。即使看了截图，也不能从条宽或空白推断耗时。

Perfetto 未执行原因只能来自在线授权/数据政策、`ui.perfetto.dev` 网络、浏览器、Playwright 或 UI 自动化条件。GitHub/GitCode 源码站不可达只影响源码绑定，不能写成 Perfetto 未执行原因。“采样了全部事件”是矛盾表述：要么给逐 Rank/lane coverage 并写“穷举解析可观测事件”，要么明确 sampled/partial。

## 8. 结论强度与替代解释

逐条列，并引用 `divergence_id` 或 `control_flow_guard_candidates.csv.evidence_id`：

- `已证实控制流分叉`；
- `强关联控制流分叉`；
- `静态候选`；
- `仿真计算错误已证实`（通常需要额外受控复现）；
- `未知`。

强度名称必须逐字采用上述规范词；不要用“强关联控制流分歧”“高置信路径差异”“已确认分支差异”等近义词规避结构化 candidate、源码绑定或 Python 快照门禁。验证器会把这类升级措辞按相应等级处理并以非规范名称阻断。

每条推断都列至少一个替代解释，例如：采集窗口不同、workload/Shape 不同、线程错配、backend lowering、图捕获、instrumentation 缺失、代码版本冲突。

## 9. 最小验证动作

按成本排序给出：

1. 对哪个 `guard_id` 增加什么 predicate/operand marker；
2. 哪个 Rank/Thread/step 需要重采；
3. 哪个 producer operator/tensor 需要 hash/scalar/min/max/nonzero_count；
4. 哪个 Host→Device correlation 需要补采；
5. 什么 A/B（固定输入/seed/config/commit）能证伪候选；
6. 修正后应观察哪些 operator 序列重新汇合。

## 10. 附录与证据可追溯性

列出所有主证据相对/绝对路径、SHA（适用时）、schema/algorithm version、parser warnings、预算截断、源码 issues。确认原始 Profiling 与源码仓未修改。

## 11. 强制交付门禁

生成报告后运行 `scripts/validate_alignment_report.py --python-snapshots-dir <python-guard-snapshots-dir> --perfetto-review-dir <perfetto-review-dir>`。必须保留并实际读取：

```text
python-guard-snapshots/python_guard_snapshots.json
python-guard-snapshots/python_guard_snapshots.csv
python-guard-snapshots/python_guard_snapshots.md
python-guard-snapshots/python_guard_snapshots.html
perfetto-review/perfetto_batch_manifest.json
perfetto-review/perfetto_batch_manifest.csv
perfetto-review/perfetto_content_review.json
report-validation/report_validation.json
report-validation/report_validation.csv
```

命令还必须传 `--perfetto-review-dir <perfetto-review-dir>`；即使在线复核未获授权，也要让 batch wrapper 写出可验证的 `not-executed` manifest/content review。只有 `status=pass` 且 `blocking_error_count=0` 才能交付。验证器是最低门槛，不替代人工证据复核；不得删除结构化产物、手改验证 JSON 或以“报告看起来合理”绕过非零退出码。

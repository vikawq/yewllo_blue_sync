#!/usr/bin/env python3
"""Render static, evidence-bound snapshots for selected Python guard candidates.

Only three kinds of input are read: ``control_flow_guard_candidates.csv``,
``source_analysis_manifest.json``, and the selected ``.py`` files below ``--repo-root``.
Repository code is treated as bytes/text; it is never imported, compiled, or executed.
"""

from __future__ import annotations

import argparse
import csv
import hashlib
import html
import io
import json
import os
import re
import stat
import sys
import tempfile
import tokenize
from pathlib import Path, PurePosixPath
from typing import Any, Iterable, Sequence


SCHEMA_VERSION = 1
ALGORITHM_VERSION = "python-guard-snapshot-v1"
CANDIDATE_NAME = "control_flow_guard_candidates.csv"
MANIFEST_NAME = "source_analysis_manifest.json"
OUTPUT_NAMES = (
    "python_guard_snapshots.md",
    "python_guard_snapshots.html",
    "python_guard_snapshots.json",
    "python_guard_snapshots.csv",
)
REQUIRED_CANDIDATE_FIELDS = {
    "evidence_id",
    "candidate_rank",
    "guard_path",
    "guard_symbol",
    "guard_lines",
    "real_arm",
    "real_arm_lines",
    "sim_arm",
    "sim_arm_lines",
    "repository",
    "commit",
    "run_contract_sha256",
    "indexed_head_commit",
    "indexed_tree_hash",
}
CSV_FIELDS = [
    "schema_version",
    "evidence_id",
    "selection_reason",
    "candidate_rank",
    "divergence_id",
    "rank_pair_id",
    "thread_pair_id",
    "source_component",
    "candidate_strength",
    "analyzed_source_gate_passed",
    "dependency_source_gate_passed",
    "repository",
    "repo_root",
    "commit",
    "tree_hash",
    "run_contract_sha256",
    "path",
    "symbol",
    "guard_range",
    "real_arm",
    "real_arm_range",
    "sim_arm",
    "sim_arm_range",
    "source_encoding",
    "source_file_sha256",
    "snippet_sha256",
    "snippet_start_line",
    "snippet_end_line",
    "context_before_lines",
    "context_after_lines",
    "line_number",
    "line_role",
    "css_class",
    "code",
]
HEX_40_OR_64 = re.compile(r"(?:[0-9a-fA-F]{40}|[0-9a-fA-F]{64})\Z")
SHA256 = re.compile(r"[0-9a-fA-F]{64}\Z")
DRIVE_PREFIX = re.compile(r"[A-Za-z]:")


class SnapshotError(ValueError):
    """A fail-closed input, identity, path, or output-contract violation."""


def sha256_bytes(value: bytes) -> str:
    return hashlib.sha256(value).hexdigest()


def _require_mapping(value: Any, label: str) -> dict[str, Any]:
    if not isinstance(value, dict):
        raise SnapshotError(f"{label} must be a JSON object")
    return value


def _require_text(value: Any, label: str, *, allow_empty: bool = False) -> str:
    if not isinstance(value, str):
        raise SnapshotError(f"{label} must be a string")
    result = value.strip()
    if not result and not allow_empty:
        raise SnapshotError(f"{label} must not be empty")
    return result


def _require_hex(value: Any, label: str, *, sha256: bool = False) -> str:
    result = _require_text(value, label)
    matcher = SHA256 if sha256 else HEX_40_OR_64
    if not matcher.fullmatch(result):
        expected = "64 hexadecimal characters" if sha256 else "40 or 64 hexadecimal characters"
        raise SnapshotError(f"{label} must contain {expected}")
    return result.casefold()


def _normalized_path_text(path: Path) -> str:
    return os.path.normcase(str(path))


def _same_path(left: Path, right: Path) -> bool:
    return _normalized_path_text(left) == _normalized_path_text(right)


def _is_within(path: Path, root: Path) -> bool:
    try:
        path.relative_to(root)
        return True
    except ValueError:
        return False


def _is_linklike(path: Path) -> bool:
    """Treat symlinks and Windows junction/reparse entries as unsafe indirection."""
    try:
        if path.is_symlink():
            return True
        attributes = getattr(path.lstat(), "st_file_attributes", 0)
        return bool(attributes & getattr(stat, "FILE_ATTRIBUTE_REPARSE_POINT", 0))
    except OSError:
        return False


def _repository_key(value: str) -> str:
    normalized = value.strip().replace("\\", "/").rstrip("/")
    if normalized.casefold().endswith(".git"):
        normalized = normalized[:-4]
    return normalized.casefold()


def _read_inputs(source_causality_dir: Path) -> tuple[bytes, list[dict[str, str]], dict[str, Any]]:
    if _is_linklike(source_causality_dir):
        raise SnapshotError("source-causality directory must not be a symlink")
    try:
        source_dir = source_causality_dir.resolve(strict=True)
    except OSError as exc:
        raise SnapshotError(f"source-causality directory is unavailable: {exc}") from exc
    if not source_dir.is_dir():
        raise SnapshotError("source-causality path is not a directory")

    candidate_path = source_dir / CANDIDATE_NAME
    manifest_path = source_dir / MANIFEST_NAME
    for path in (candidate_path, manifest_path):
        if _is_linklike(path):
            raise SnapshotError(f"input artifact must not be a symlink: {path.name}")
        if not path.is_file():
            raise SnapshotError(f"required input artifact is missing: {path.name}")
        if path.resolve(strict=True).parent != source_dir:
            raise SnapshotError(f"input artifact resolved outside source-causality directory: {path.name}")

    candidate_raw = candidate_path.read_bytes()
    manifest_raw = manifest_path.read_bytes()
    try:
        manifest = json.loads(manifest_raw.decode("utf-8-sig"))
    except (UnicodeDecodeError, json.JSONDecodeError) as exc:
        raise SnapshotError(f"invalid {MANIFEST_NAME}: {exc}") from exc
    manifest = _require_mapping(manifest, MANIFEST_NAME)

    try:
        candidate_text = candidate_raw.decode("utf-8-sig")
    except UnicodeDecodeError as exc:
        raise SnapshotError(f"invalid UTF-8 in {CANDIDATE_NAME}: {exc}") from exc
    reader = csv.DictReader(io.StringIO(candidate_text, newline=""))
    fields = reader.fieldnames
    if fields is None:
        raise SnapshotError(f"{CANDIDATE_NAME} has no header")
    if len(fields) != len(set(fields)):
        raise SnapshotError(f"{CANDIDATE_NAME} contains duplicate header fields")
    missing_fields = sorted(REQUIRED_CANDIDATE_FIELDS - set(fields))
    if missing_fields:
        raise SnapshotError(
            f"{CANDIDATE_NAME} is missing required fields: {', '.join(missing_fields)}"
        )
    rows: list[dict[str, str]] = []
    try:
        for row_number, row in enumerate(reader, 2):
            if None in row:
                raise SnapshotError(f"{CANDIDATE_NAME} row {row_number} has extra columns")
            rows.append({key: value or "" for key, value in row.items()})
    except csv.Error as exc:
        raise SnapshotError(f"invalid {CANDIDATE_NAME}: {exc}") from exc
    return candidate_raw, rows, manifest


def _validate_artifact_integrity(candidate_raw: bytes, manifest: dict[str, Any]) -> None:
    artifacts = manifest.get("artifacts")
    if not isinstance(artifacts, list) or CANDIDATE_NAME not in artifacts:
        raise SnapshotError(f"manifest artifacts does not declare {CANDIDATE_NAME}")
    integrity = _require_mapping(manifest.get("artifact_integrity"), "manifest artifact_integrity")
    entry = _require_mapping(
        integrity.get(CANDIDATE_NAME), f"manifest artifact_integrity.{CANDIDATE_NAME}"
    )
    expected_sha = _require_hex(
        entry.get("sha256"), f"artifact_integrity.{CANDIDATE_NAME}.sha256", sha256=True
    )
    actual_sha = sha256_bytes(candidate_raw)
    if expected_sha != actual_sha:
        raise SnapshotError(
            f"{CANDIDATE_NAME} SHA-256 conflict: manifest={expected_sha}, actual={actual_sha}"
        )
    expected_bytes = entry.get("bytes")
    if isinstance(expected_bytes, bool) or not isinstance(expected_bytes, int):
        raise SnapshotError(f"artifact_integrity.{CANDIDATE_NAME}.bytes must be an integer")
    if expected_bytes != len(candidate_raw):
        raise SnapshotError(
            f"{CANDIDATE_NAME} byte-count conflict: manifest={expected_bytes}, actual={len(candidate_raw)}"
        )
    if entry.get("nonempty") is not True or not candidate_raw:
        raise SnapshotError(f"{CANDIDATE_NAME} must be bound as a nonempty artifact")


def _validate_repository_identity(repo_root: Path, manifest: dict[str, Any]) -> dict[str, str]:
    if _is_linklike(repo_root):
        raise SnapshotError("repo root must not be a symlink")
    try:
        root = repo_root.resolve(strict=True)
    except OSError as exc:
        raise SnapshotError(f"repo root is unavailable: {exc}") from exc
    if not root.is_dir():
        raise SnapshotError("repo root is not a directory")

    manifest_root_text = _require_text(manifest.get("repo_root"), "manifest repo_root")
    manifest_root_path = Path(manifest_root_text)
    if not manifest_root_path.is_absolute():
        raise SnapshotError("manifest repo_root must be absolute")
    try:
        manifest_root = manifest_root_path.resolve(strict=True)
    except OSError as exc:
        raise SnapshotError(f"manifest repo_root is unavailable: {exc}") from exc
    if not _same_path(root, manifest_root):
        raise SnapshotError(
            f"repo-root conflict: CLI={root}, manifest={manifest_root}"
        )

    snapshot = _require_mapping(
        manifest.get("indexed_source_snapshot"), "manifest indexed_source_snapshot"
    )
    if snapshot.get("binding_status") != "verified":
        raise SnapshotError("indexed source snapshot binding_status must be verified")
    if snapshot.get("is_git_repository") is not True:
        raise SnapshotError("indexed source snapshot must identify a Git repository")
    if snapshot.get("worktree_dirty") != "no":
        raise SnapshotError("indexed source snapshot worktree must be clean")
    commit = _require_hex(snapshot.get("head_commit"), "indexed source head_commit")
    tree_hash = _require_hex(snapshot.get("tree_hash"), "indexed source tree_hash")
    snapshot_resolved = _require_hex(
        snapshot.get("resolved_commit"), "indexed source resolved_commit"
    )
    if snapshot_resolved != commit:
        raise SnapshotError("indexed source resolved_commit conflicts with head_commit")
    manifest_resolved = _require_hex(manifest.get("resolved_commit"), "manifest resolved_commit")
    if manifest_resolved != commit:
        raise SnapshotError("manifest resolved_commit conflicts with indexed head_commit")

    manifest_repository = _require_text(
        manifest.get("repository", ""), "manifest repository", allow_empty=True
    )
    snapshot_repository = _require_text(
        snapshot.get("remote", ""), "indexed source remote", allow_empty=True
    )
    if manifest_repository and snapshot_repository:
        if _repository_key(manifest_repository) != _repository_key(snapshot_repository):
            raise SnapshotError("manifest repository conflicts with indexed source remote")
    repository = manifest_repository or snapshot_repository or str(root)

    run_comparability = _require_mapping(
        manifest.get("run_comparability"), "manifest run_comparability"
    )
    run_contract_sha = _require_text(
        run_comparability.get("sha256", ""), "run_comparability.sha256", allow_empty=True
    )
    if run_contract_sha:
        if not SHA256.fullmatch(run_contract_sha):
            raise SnapshotError("run_comparability.sha256 must contain 64 hexadecimal characters")
        run_contract_sha = run_contract_sha.casefold()

    return {
        "repo_root": str(root),
        "repository": repository,
        "commit": commit,
        "tree_hash": tree_hash,
        "run_contract_sha256": run_contract_sha,
        "binding_status": "verified",
    }


def _candidate_rank(row: dict[str, str], row_number: int) -> int:
    value = row.get("candidate_rank", "").strip()
    if not re.fullmatch(r"[1-9][0-9]*", value):
        raise SnapshotError(f"candidate row {row_number} has invalid candidate_rank: {value!r}")
    return int(value)


def _select_candidates(
    rows: list[dict[str, str]], requested_evidence_ids: Iterable[str]
) -> list[tuple[dict[str, str], int, str]]:
    requested_list = [value.strip() for value in requested_evidence_ids]
    if any(not value for value in requested_list):
        raise SnapshotError("--evidence-id must not be empty")
    if len(requested_list) != len(set(requested_list)):
        raise SnapshotError("--evidence-id values must be unique")
    requested = set(requested_list)

    seen_evidence: dict[str, int] = {}
    selected: list[tuple[dict[str, str], int, str]] = []
    found_requested: set[str] = set()
    for row_number, row in enumerate(rows, 2):
        evidence_id = row.get("evidence_id", "").strip()
        if not evidence_id:
            raise SnapshotError(f"candidate row {row_number} has empty evidence_id")
        if evidence_id in seen_evidence:
            raise SnapshotError(
                f"duplicate evidence_id {evidence_id!r} in rows {seen_evidence[evidence_id]} and {row_number}"
            )
        seen_evidence[evidence_id] = row_number
        rank = _candidate_rank(row, row_number)
        rank_one = rank == 1
        explicitly_selected = evidence_id in requested
        if explicitly_selected:
            found_requested.add(evidence_id)
        if rank_one or explicitly_selected:
            if rank_one and explicitly_selected:
                reason = "candidate_rank=1+selected_evidence_id"
            elif rank_one:
                reason = "candidate_rank=1"
            else:
                reason = "selected_evidence_id"
            selected.append((row, rank, reason))

    missing = sorted(requested - found_requested)
    if missing:
        raise SnapshotError(f"requested evidence_id not found: {', '.join(missing)}")
    if not selected:
        raise SnapshotError("no candidate_rank=1 or explicitly selected evidence_id rows were found")
    return selected


def _parse_range(value: str, label: str) -> tuple[int, int]:
    text = value.strip()
    parsed: Any
    if text.startswith("["):
        try:
            parsed = json.loads(text)
        except json.JSONDecodeError as exc:
            raise SnapshotError(f"{label} is not a valid line range: {value!r}") from exc
        if not isinstance(parsed, list) or len(parsed) != 2:
            raise SnapshotError(f"{label} must be a two-element line range")
        start, end = parsed
    else:
        match = re.fullmatch(r"\s*([0-9]+)(?:\s*-\s*([0-9]+))?\s*", text)
        if not match:
            raise SnapshotError(f"{label} is not a valid line range: {value!r}")
        start = int(match.group(1))
        end = int(match.group(2) or match.group(1))
    if isinstance(start, bool) or isinstance(end, bool) or not isinstance(start, int) or not isinstance(end, int):
        raise SnapshotError(f"{label} line numbers must be integers")
    if start < 1 or end < start:
        raise SnapshotError(f"{label} must use an ordered, positive 1-based line range")
    return start, end


def _format_range(value: tuple[int, int]) -> str:
    return f"{value[0]}-{value[1]}"


def _validate_candidate_identity(row: dict[str, str], identity: dict[str, str]) -> None:
    evidence_id = row["evidence_id"].strip()
    row_commit = _require_hex(row.get("commit"), f"{evidence_id}.commit")
    indexed_commit = _require_hex(
        row.get("indexed_head_commit"), f"{evidence_id}.indexed_head_commit"
    )
    indexed_tree = _require_hex(
        row.get("indexed_tree_hash"), f"{evidence_id}.indexed_tree_hash"
    )
    if row_commit != identity["commit"] or indexed_commit != identity["commit"]:
        raise SnapshotError(f"{evidence_id} commit conflicts with source manifest")
    if indexed_tree != identity["tree_hash"]:
        raise SnapshotError(f"{evidence_id} tree hash conflicts with source manifest")

    row_contract = _require_text(
        row.get("run_contract_sha256", ""),
        f"{evidence_id}.run_contract_sha256",
        allow_empty=True,
    )
    if row_contract:
        if not SHA256.fullmatch(row_contract):
            raise SnapshotError(f"{evidence_id}.run_contract_sha256 is not a SHA-256")
        row_contract = row_contract.casefold()
    if row_contract != identity["run_contract_sha256"]:
        raise SnapshotError(f"{evidence_id} run-contract hash conflicts with source manifest")

    row_repository = _require_text(
        row.get("repository", ""), f"{evidence_id}.repository", allow_empty=True
    )
    if row_repository and _repository_key(row_repository) != _repository_key(identity["repository"]):
        raise SnapshotError(f"{evidence_id} repository conflicts with source manifest")


def _resolve_python_source(repo_root: Path, guard_path: str) -> tuple[Path, str]:
    path_text = guard_path.strip().replace("\\", "/")
    if not path_text:
        raise SnapshotError("guard_path must not be empty")
    if "\x00" in path_text or path_text.startswith("/") or DRIVE_PREFIX.match(path_text):
        raise SnapshotError(f"guard_path must be a relative repository path: {guard_path!r}")
    raw_parts = path_text.split("/")
    if any(part in {"", ".", ".."} for part in raw_parts):
        raise SnapshotError(f"guard_path contains an unsafe path segment: {guard_path!r}")
    relative = PurePosixPath(*raw_parts)
    if relative.suffix.casefold() != ".py":
        raise SnapshotError(
            f"primary guard snapshots only accept .py sources, not {relative.suffix or 'extensionless paths'}: {guard_path!r}"
        )

    current = repo_root
    for part in relative.parts:
        current = current / part
        if _is_linklike(current):
            raise SnapshotError(f"guard_path traverses a symlink: {guard_path!r}")
        if not current.exists():
            raise SnapshotError(f"guard source file is missing: {guard_path!r}")
    try:
        resolved = current.resolve(strict=True)
    except OSError as exc:
        raise SnapshotError(f"guard source file cannot be resolved: {guard_path!r}: {exc}") from exc
    if not _is_within(resolved, repo_root):
        raise SnapshotError(f"guard source resolves outside repo root: {guard_path!r}")
    if not resolved.is_file():
        raise SnapshotError(f"guard source is not a regular file: {guard_path!r}")
    return resolved, relative.as_posix()


def _read_python_source(path: Path, relative_path: str) -> dict[str, Any]:
    raw = path.read_bytes()
    try:
        encoding, _ = tokenize.detect_encoding(io.BytesIO(raw).readline)
        text = raw.decode(encoding)
    except (SyntaxError, UnicodeDecodeError, LookupError) as exc:
        raise SnapshotError(f"cannot decode Python source {relative_path!r}: {exc}") from exc
    text_lines = text.splitlines(keepends=True)
    raw_lines = raw.splitlines(keepends=True)
    if len(text_lines) != len(raw_lines):
        raise SnapshotError(f"line decoding is ambiguous for Python source {relative_path!r}")
    return {
        "raw": raw,
        "raw_lines": raw_lines,
        "text_lines": text_lines,
        "resolved_path": path,
        "encoding": encoding,
        "sha256": sha256_bytes(raw),
    }


def _line_role(
    number: int,
    guard_range: tuple[int, int],
    real_range: tuple[int, int],
    sim_range: tuple[int, int],
) -> tuple[str, str]:
    in_guard = guard_range[0] <= number <= guard_range[1]
    in_real = real_range[0] <= number <= real_range[1]
    in_sim = sim_range[0] <= number <= sim_range[1]
    classes = ["line-guard" if in_guard else "line-context"]
    roles = ["guard" if in_guard else "context"]
    if in_real:
        classes.append("line-real-arm")
        roles.append("real-arm")
    if in_sim:
        classes.append("line-sim-arm")
        roles.append("sim-arm")
    return "+".join(roles), " ".join(classes)


def _build_snapshot(
    row: dict[str, str],
    rank: int,
    selection_reason: str,
    identity: dict[str, str],
    source: dict[str, Any],
    relative_path: str,
    context_lines: int,
) -> dict[str, Any]:
    evidence_id = row["evidence_id"].strip()
    guard_range = _parse_range(row.get("guard_lines", ""), f"{evidence_id}.guard_lines")
    real_range = _parse_range(row.get("real_arm_lines", ""), f"{evidence_id}.real_arm_lines")
    sim_range = _parse_range(row.get("sim_arm_lines", ""), f"{evidence_id}.sim_arm_lines")
    line_count = len(source["text_lines"])
    for label, value in (
        ("guard_lines", guard_range),
        ("real_arm_lines", real_range),
        ("sim_arm_lines", sim_range),
    ):
        if value[1] > line_count:
            raise SnapshotError(
                f"{evidence_id}.{label} ends at {value[1]}, beyond {relative_path} line count {line_count}"
            )
    if not (
        guard_range[0] <= real_range[0] <= real_range[1] <= guard_range[1]
        and guard_range[0] <= sim_range[0] <= sim_range[1] <= guard_range[1]
    ):
        raise SnapshotError(f"{evidence_id} real/sim arm ranges must be contained by guard_lines")
    if max(real_range[0], sim_range[0]) <= min(real_range[1], sim_range[1]):
        raise SnapshotError(f"{evidence_id} real/sim arm ranges must not overlap")
    real_arm = _require_text(row.get("real_arm"), f"{evidence_id}.real_arm")
    sim_arm = _require_text(row.get("sim_arm"), f"{evidence_id}.sim_arm")
    if real_arm == sim_arm:
        raise SnapshotError(f"{evidence_id} real_arm and sim_arm must be distinct")

    snippet_start = max(1, guard_range[0] - context_lines)
    snippet_end = min(line_count, guard_range[1] + context_lines)
    snippet_raw = b"".join(source["raw_lines"][snippet_start - 1 : snippet_end])
    guard_text = _format_range(guard_range)
    real_text = _format_range(real_range)
    sim_text = _format_range(sim_range)
    symbol = row.get("guard_symbol", "").strip()
    lines: list[dict[str, Any]] = []
    for number in range(snippet_start, snippet_end + 1):
        code = source["text_lines"][number - 1].rstrip("\r\n")
        role, css_class = _line_role(number, guard_range, real_range, sim_range)
        lines.append(
            {
                "line_number": number,
                "path": relative_path,
                "symbol": symbol,
                "guard_range": guard_text,
                "real_arm_range": real_text,
                "sim_arm_range": sim_text,
                "line_role": role,
                "css_class": css_class,
                "code": code,
            }
        )

    return {
        "evidence_id": evidence_id,
        "selection_reason": selection_reason,
        "candidate_rank": rank,
        "divergence_id": row.get("divergence_id", "").strip(),
        "rank_pair_id": row.get("rank_pair_id", "").strip(),
        "thread_pair_id": row.get("thread_pair_id", "").strip(),
        "source_component": row.get("source_component", "").strip(),
        "candidate_strength": row.get("strength", "").strip(),
        "source_gates": {
            "analyzed_source_gate_passed": row.get("analyzed_source_gate_passed", "").strip(),
            "dependency_source_gate_passed": row.get("dependency_source_gate_passed", "").strip(),
            "dependency_source_gate_field": row.get("dependency_source_gate_field", "").strip(),
        },
        "repository": identity["repository"],
        "repo_root": identity["repo_root"],
        "commit": identity["commit"],
        "tree_hash": identity["tree_hash"],
        "run_contract_sha256": identity["run_contract_sha256"],
        "path": relative_path,
        "symbol": symbol,
        "guard": {"start_line": guard_range[0], "end_line": guard_range[1], "range": guard_text},
        "real_arm": {
            "name": real_arm,
            "start_line": real_range[0],
            "end_line": real_range[1],
            "range": real_text,
        },
        "sim_arm": {
            "name": sim_arm,
            "start_line": sim_range[0],
            "end_line": sim_range[1],
            "range": sim_text,
        },
        "source_encoding": source["encoding"],
        "source_file_sha256": source["sha256"],
        "snippet_sha256": sha256_bytes(snippet_raw),
        "snippet_sha256_basis": "exact source bytes for snippet_start_line..snippet_end_line inclusive",
        "snippet_start_line": snippet_start,
        "snippet_end_line": snippet_end,
        "context_before_lines": guard_range[0] - snippet_start,
        "context_after_lines": snippet_end - guard_range[1],
        "lines": lines,
    }


def _escape(value: Any) -> str:
    return html.escape(str(value), quote=True)


def _snapshot_details(snapshot: dict[str, Any]) -> str:
    metadata = [
        ("Evidence ID", snapshot["evidence_id"]),
        ("Selection", snapshot["selection_reason"]),
        ("Candidate rank", snapshot["candidate_rank"]),
        ("Repository", snapshot["repository"]),
        ("Commit", snapshot["commit"]),
        ("Tree", snapshot["tree_hash"]),
        ("Path", snapshot["path"]),
        ("Symbol", snapshot["symbol"]),
        ("Guard range", snapshot["guard"]["range"]),
        ("Real arm", f"{snapshot['real_arm']['name']} [{snapshot['real_arm']['range']}]"),
        ("Simulation arm", f"{snapshot['sim_arm']['name']} [{snapshot['sim_arm']['range']}]"),
        ("Analyzed-source gate", snapshot["source_gates"]["analyzed_source_gate_passed"]),
        ("Dependency-source gate", snapshot["source_gates"]["dependency_source_gate_passed"]),
        ("Source file SHA-256", snapshot["source_file_sha256"]),
        ("Snippet SHA-256", snapshot["snippet_sha256"]),
        ("Context", f"before={snapshot['context_before_lines']}, after={snapshot['context_after_lines']}"),
    ]
    metadata_rows = "\n".join(
        f"<tr><th>{_escape(label)}</th><td>{_escape(value)}</td></tr>" for label, value in metadata
    )
    line_rows = []
    for line in snapshot["lines"]:
        line_rows.append(
            "<tr class=\"{css_attr}\"><td>{number}</td><td>{path}</td><td>{symbol}</td>"
            "<td>{guard}</td><td>{real}</td><td>{sim}</td><td>{css_text}</td>"
            "<td><pre><code>{code}</code></pre></td></tr>".format(
                css_attr=_escape(line["css_class"]),
                number=_escape(line["line_number"]),
                path=_escape(line["path"]),
                symbol=_escape(line["symbol"]),
                guard=_escape(line["guard_range"]),
                real=_escape(line["real_arm_range"]),
                sim=_escape(line["sim_arm_range"]),
                css_text=_escape(line["css_class"]),
                code=_escape(line["code"]),
            )
        )
    summary = (
        f"{snapshot['evidence_id']} | {snapshot['path']}:{snapshot['guard']['range']} | "
        f"{snapshot['symbol']}"
    )
    return "\n".join(
        [
            "<details open>",
            f"<summary>{_escape(summary)}</summary>",
            "<table>",
            "<thead><tr><th>Field</th><th>Value</th></tr></thead>",
            f"<tbody>{metadata_rows}</tbody>",
            "</table>",
            "<table>",
            "<thead><tr><th>Line</th><th>Path</th><th>Symbol</th><th>Guard</th>"
            "<th>Real arm</th><th>Simulation arm</th><th>CSS class</th><th>Code</th></tr></thead>",
            f"<tbody>{''.join(line_rows)}</tbody>",
            "</table>",
            "</details>",
        ]
    )


def _render_html(document: dict[str, Any]) -> str:
    details = "\n".join(_snapshot_details(snapshot) for snapshot in document["snapshots"])
    repository = document["repository"]
    result = "\n".join(
        [
            "<!doctype html>",
            '<html lang="en">',
            "<head>",
            '<meta charset="utf-8">',
            '<meta http-equiv="Content-Security-Policy" content="default-src \'none\'; '
            "script-src 'none'; style-src 'none'; img-src 'none'; connect-src 'none'; "
            "font-src 'none'; media-src 'none'; object-src 'none'; frame-src 'none'; "
            "base-uri 'none'; form-action 'none'\">",
            "<title>Python Guard Snapshots</title>",
            "</head>",
            "<body>",
            "<h1>Python Guard Snapshots</h1>",
            f"<p><strong>Repository:</strong> {_escape(repository['repository'])}</p>",
            f"<p><strong>Repo root:</strong> {_escape(repository['repo_root'])}</p>",
            f"<p><strong>Commit:</strong> {_escape(repository['commit'])}</p>",
            f"<p><strong>Tree:</strong> {_escape(repository['tree_hash'])}</p>",
            "<p>Static source text only. Candidate strength and source gates are reproduced without promotion.</p>",
            details,
            "</body>",
            "</html>",
            "",
        ]
    )
    _assert_static_html(result)
    return result


def _render_markdown(document: dict[str, Any]) -> str:
    repository = document["repository"]
    details = "\n\n".join(_snapshot_details(snapshot) for snapshot in document["snapshots"])
    result = "\n".join(
        [
            "# Python Guard Snapshots",
            "",
            f"<p><strong>Repository:</strong> {_escape(repository['repository'])}</p>",
            f"<p><strong>Repo root:</strong> {_escape(repository['repo_root'])}</p>",
            f"<p><strong>Commit:</strong> {_escape(repository['commit'])}</p>",
            f"<p><strong>Tree:</strong> {_escape(repository['tree_hash'])}</p>",
            "<p>Static source text only. Candidate strength and source gates are reproduced without promotion.</p>",
            "",
            details,
            "",
        ]
    )
    _assert_static_html(result)
    return result


def _assert_static_html(value: str) -> None:
    if re.search(r"<\s*(?:script|style|link)\b", value, re.IGNORECASE):
        raise SnapshotError("rendered markup contains a forbidden script/style/link tag")
    if re.search(r"<\s*(?:iframe|object|embed|base|form)\b", value, re.IGNORECASE):
        raise SnapshotError("rendered markup contains a forbidden active-content tag")
    if re.search(r"<[^>]*\s(?:on[a-z0-9_-]+|href|src)\s*=", value, re.IGNORECASE):
        raise SnapshotError("rendered markup contains an event handler or external-resource attribute")


def _render_csv(snapshots: list[dict[str, Any]]) -> bytes:
    buffer = io.StringIO(newline="")
    writer = csv.DictWriter(buffer, fieldnames=CSV_FIELDS, lineterminator="\n")
    writer.writeheader()
    for snapshot in snapshots:
        common = {
            "schema_version": SCHEMA_VERSION,
            "evidence_id": snapshot["evidence_id"],
            "selection_reason": snapshot["selection_reason"],
            "candidate_rank": snapshot["candidate_rank"],
            "divergence_id": snapshot["divergence_id"],
            "rank_pair_id": snapshot["rank_pair_id"],
            "thread_pair_id": snapshot["thread_pair_id"],
            "source_component": snapshot["source_component"],
            "candidate_strength": snapshot["candidate_strength"],
            "analyzed_source_gate_passed": snapshot["source_gates"]["analyzed_source_gate_passed"],
            "dependency_source_gate_passed": snapshot["source_gates"]["dependency_source_gate_passed"],
            "repository": snapshot["repository"],
            "repo_root": snapshot["repo_root"],
            "commit": snapshot["commit"],
            "tree_hash": snapshot["tree_hash"],
            "run_contract_sha256": snapshot["run_contract_sha256"],
            "path": snapshot["path"],
            "symbol": snapshot["symbol"],
            "guard_range": snapshot["guard"]["range"],
            "real_arm": snapshot["real_arm"]["name"],
            "real_arm_range": snapshot["real_arm"]["range"],
            "sim_arm": snapshot["sim_arm"]["name"],
            "sim_arm_range": snapshot["sim_arm"]["range"],
            "source_encoding": snapshot["source_encoding"],
            "source_file_sha256": snapshot["source_file_sha256"],
            "snippet_sha256": snapshot["snippet_sha256"],
            "snippet_start_line": snapshot["snippet_start_line"],
            "snippet_end_line": snapshot["snippet_end_line"],
            "context_before_lines": snapshot["context_before_lines"],
            "context_after_lines": snapshot["context_after_lines"],
        }
        for line in snapshot["lines"]:
            writer.writerow(
                {
                    **common,
                    "line_number": line["line_number"],
                    "line_role": line["line_role"],
                    "css_class": line["css_class"],
                    "code": line["code"],
                }
            )
    return ("\ufeff" + buffer.getvalue()).encode("utf-8")


def _write_outputs_atomically(output: Path, contents: dict[str, bytes]) -> None:
    if _is_linklike(output):
        raise SnapshotError("output directory must not be a symlink")
    if output.exists() and not output.is_dir():
        raise SnapshotError("output path exists and is not a directory")
    existing = [
        name
        for name in OUTPUT_NAMES
        if (output / name).exists() or _is_linklike(output / name)
    ]
    if existing:
        raise SnapshotError(
            "refusing to overwrite existing snapshot artifacts: " + ", ".join(existing)
        )

    output.parent.mkdir(parents=True, exist_ok=True)
    output.mkdir(parents=True, exist_ok=True)
    created: list[Path] = []
    try:
        with tempfile.TemporaryDirectory(prefix=".python-guard-snapshot-", dir=str(output.parent)) as temporary:
            staging = Path(temporary)
            for name in OUTPUT_NAMES:
                (staging / name).write_bytes(contents[name])
            for name in OUTPUT_NAMES:
                destination = output / name
                os.replace(staging / name, destination)
                created.append(destination)
    except Exception:
        for path in created:
            try:
                path.unlink()
            except OSError:
                pass
        raise


def render_python_guard_snapshots(
    repo_root: Path,
    source_causality_dir: Path,
    output: Path,
    *,
    evidence_ids: Iterable[str] = (),
    context_lines: int = 3,
) -> dict[str, Any]:
    """Validate, render, and atomically write all four snapshot artifacts."""
    if isinstance(context_lines, bool) or not isinstance(context_lines, int) or context_lines < 0:
        raise SnapshotError("context_lines must be a nonnegative integer")
    requested_evidence_ids = list(evidence_ids)
    candidate_raw, rows, manifest = _read_inputs(source_causality_dir)
    _validate_artifact_integrity(candidate_raw, manifest)
    identity = _validate_repository_identity(repo_root, manifest)
    resolved_repo = Path(identity["repo_root"])
    output_resolved = output.resolve(strict=False)
    if _is_within(output_resolved, resolved_repo):
        raise SnapshotError("output must be outside the read-only source repository")

    selected = _select_candidates(rows, requested_evidence_ids)
    snapshots: list[dict[str, Any]] = []
    source_cache: dict[str, dict[str, Any]] = {}
    for row, rank, selection_reason in selected:
        _validate_candidate_identity(row, identity)
        source_path, relative_path = _resolve_python_source(resolved_repo, row.get("guard_path", ""))
        if relative_path not in source_cache:
            source_cache[relative_path] = _read_python_source(source_path, relative_path)
        snapshots.append(
            _build_snapshot(
                row,
                rank,
                selection_reason,
                identity,
                source_cache[relative_path],
                relative_path,
                context_lines,
            )
        )

    # Re-resolve and re-hash immediately before rendering/writing so a concurrent
    # replacement, symlink swap, or byte mutation cannot silently enter the artifact.
    for relative_path, source in source_cache.items():
        verified_path, verified_relative = _resolve_python_source(resolved_repo, relative_path)
        if verified_relative != relative_path or not _same_path(
            verified_path, source["resolved_path"]
        ):
            raise SnapshotError(f"guard source path changed during rendering: {relative_path!r}")
        current_sha = sha256_bytes(verified_path.read_bytes())
        if current_sha != source["sha256"]:
            raise SnapshotError(f"guard source SHA-256 changed during rendering: {relative_path!r}")

    document: dict[str, Any] = {
        "schema_version": SCHEMA_VERSION,
        "algorithm_version": ALGORITHM_VERSION,
        "artifact_kind": "python_guard_snapshots",
        "status": "complete",
        "safety": (
            "Static source bytes/text only; repository code was not imported, compiled, or executed. "
            "HTML/Markdown contain no script, style, link, or active-content tags."
        ),
        "identity_basis": (
            "candidate CSV SHA-256 is bound by source_analysis_manifest.json; selected candidate "
            "repository/commit/tree/run-contract fields agree with that manifest; source and snippet "
            "bytes are hashed at render time; Git is not invoked"
        ),
        "source_manifest_schema_version": manifest.get("schema_version"),
        "repository": identity,
        "selection": {
            "rule": "candidate_rank=1 OR evidence_id explicitly selected",
            "requested_evidence_ids": requested_evidence_ids,
        },
        "context_lines_requested": context_lines,
        "snapshot_count": len(snapshots),
        "snapshots": snapshots,
        "artifacts": list(OUTPUT_NAMES),
    }
    json_bytes = (json.dumps(document, ensure_ascii=False, indent=2) + "\n").encode("utf-8")
    contents = {
        "python_guard_snapshots.md": _render_markdown(document).encode("utf-8"),
        "python_guard_snapshots.html": _render_html(document).encode("utf-8"),
        "python_guard_snapshots.json": json_bytes,
        "python_guard_snapshots.csv": _render_csv(snapshots),
    }
    _write_outputs_atomically(output_resolved, contents)
    return document


def _fixture_csv_bytes(rows: list[dict[str, str]]) -> bytes:
    fields = [
        "evidence_id",
        "candidate_rank",
        "divergence_id",
        "rank_pair_id",
        "thread_pair_id",
        "guard_path",
        "guard_symbol",
        "guard_lines",
        "real_arm",
        "real_arm_lines",
        "sim_arm",
        "sim_arm_lines",
        "source_component",
        "strength",
        "analyzed_source_gate_passed",
        "dependency_source_gate_passed",
        "dependency_source_gate_field",
        "repository",
        "commit",
        "run_contract_sha256",
        "indexed_head_commit",
        "indexed_tree_hash",
    ]
    buffer = io.StringIO(newline="")
    writer = csv.DictWriter(buffer, fieldnames=fields, lineterminator="\n")
    writer.writeheader()
    writer.writerows(rows)
    return ("\ufeff" + buffer.getvalue()).encode("utf-8")


def _write_self_test_fixture(
    root: Path,
    *,
    guard_path: str = "model.py",
    create_source: bool = True,
    source_suffix: str = ".py",
) -> tuple[Path, Path, Path]:
    repo = root / "repo"
    source_dir = root / "source-causality"
    output = root / "output"
    repo.mkdir(parents=True)
    source_dir.mkdir(parents=True)
    if create_source:
        source_name = "model" + source_suffix
        (repo / source_name).write_text(
            "def forward(x):\n"
            "    marker = \"<script>alert('x')</script>\"\n"
            "    if x > 0:\n"
            "        return x + 1\n"
            "    else:\n"
            "        return x - 1\n"
            "after = 1\n",
            encoding="utf-8",
        )
    commit = "a" * 40
    tree_hash = "b" * 40
    contract_hash = "c" * 64
    repository = "https://example.invalid/repo.git"
    row = {
        "evidence_id": "evidence-<img src=x onerror=alert(1)>",
        "candidate_rank": "1",
        "divergence_id": "div-1",
        "rank_pair_id": "rank0",
        "thread_pair_id": "thread-7",
        "guard_path": guard_path,
        "guard_symbol": "forward.<img src=x onerror=alert(1)>",
        "guard_lines": "3-6",
        "real_arm": "if",
        "real_arm_lines": "[4,4]",
        "sim_arm": "else",
        "sim_arm_lines": "[6,6]",
        "source_component": "model",
        "strength": "静态候选",
        "analyzed_source_gate_passed": "false",
        "dependency_source_gate_passed": "true",
        "dependency_source_gate_field": "model-source",
        "repository": repository,
        "commit": commit,
        "run_contract_sha256": contract_hash,
        "indexed_head_commit": commit,
        "indexed_tree_hash": tree_hash,
    }
    candidate_raw = _fixture_csv_bytes([row])
    (source_dir / CANDIDATE_NAME).write_bytes(candidate_raw)
    manifest = {
        "schema_version": 4,
        "repo_root": str(repo.resolve()),
        "repository": repository,
        "resolved_commit": commit,
        "indexed_source_snapshot": {
            "is_git_repository": True,
            "head_commit": commit,
            "resolved_commit": commit,
            "tree_hash": tree_hash,
            "binding_status": "verified",
            "remote": repository,
            "worktree_dirty": "no",
        },
        "run_comparability": {"sha256": contract_hash},
        "artifacts": [CANDIDATE_NAME],
        "artifact_integrity": {
            CANDIDATE_NAME: {
                "sha256": sha256_bytes(candidate_raw),
                "bytes": len(candidate_raw),
                "nonempty": True,
            }
        },
    }
    (source_dir / MANIFEST_NAME).write_text(
        json.dumps(manifest, ensure_ascii=False), encoding="utf-8"
    )
    return repo, source_dir, output


def _expect_snapshot_failure(callback: Any, expected_text: str, output: Path) -> None:
    try:
        callback()
    except SnapshotError as exc:
        if expected_text.casefold() not in str(exc).casefold():
            raise AssertionError(f"expected {expected_text!r} in {exc!r}") from exc
    else:
        raise AssertionError(f"expected SnapshotError containing {expected_text!r}")
    if output.exists() and any((output / name).exists() for name in OUTPUT_NAMES):
        raise AssertionError("failed render left snapshot artifacts behind")


def run_self_test() -> int:
    with tempfile.TemporaryDirectory(prefix="python-guard-snapshot-selftest-") as directory:
        root = Path(directory)

        valid_root = root / "valid"
        repo, source_dir, output = _write_self_test_fixture(valid_root)
        document = render_python_guard_snapshots(
            repo, source_dir, output, context_lines=2
        )
        assert set(path.name for path in output.iterdir()) == set(OUTPUT_NAMES)
        assert document["snapshot_count"] == 1
        snapshot = document["snapshots"][0]
        assert [line["line_number"] for line in snapshot["lines"]] == [1, 2, 3, 4, 5, 6, 7]
        by_line = {line["line_number"]: line for line in snapshot["lines"]}
        assert by_line[1]["css_class"] == "line-context"
        assert by_line[3]["css_class"] == "line-guard"
        assert by_line[4]["css_class"] == "line-guard line-real-arm"
        assert by_line[6]["css_class"] == "line-guard line-sim-arm"
        markup = (output / "python_guard_snapshots.html").read_text(encoding="utf-8")
        markdown = (output / "python_guard_snapshots.md").read_text(encoding="utf-8")
        for rendered in (markup, markdown):
            assert "<script>" not in rendered.casefold()
            assert "<img " not in rendered.casefold()
            assert "&lt;script&gt;" in rendered
            assert "&lt;img src=x onerror=alert(1)&gt;" in rendered
            _assert_static_html(rendered)

        traversal_root = root / "traversal"
        traversal_repo, traversal_source, traversal_output = _write_self_test_fixture(
            traversal_root, guard_path="../outside.py"
        )
        (traversal_root / "outside.py").write_text("pass\n", encoding="utf-8")
        _expect_snapshot_failure(
            lambda: render_python_guard_snapshots(
                traversal_repo, traversal_source, traversal_output
            ),
            "unsafe path segment",
            traversal_output,
        )

        missing_root = root / "missing"
        missing_repo, missing_source, missing_output = _write_self_test_fixture(
            missing_root, guard_path="missing.py", create_source=False
        )
        _expect_snapshot_failure(
            lambda: render_python_guard_snapshots(missing_repo, missing_source, missing_output),
            "missing",
            missing_output,
        )

        conflict_root = root / "hash-conflict"
        conflict_repo, conflict_source, conflict_output = _write_self_test_fixture(conflict_root)
        with (conflict_source / CANDIDATE_NAME).open("ab") as handle:
            handle.write(b"\n")
        _expect_snapshot_failure(
            lambda: render_python_guard_snapshots(
                conflict_repo, conflict_source, conflict_output
            ),
            "SHA-256 conflict",
            conflict_output,
        )

        cpp_root = root / "cpp"
        cpp_repo, cpp_source, cpp_output = _write_self_test_fixture(
            cpp_root, guard_path="model.cpp", source_suffix=".cpp"
        )
        _expect_snapshot_failure(
            lambda: render_python_guard_snapshots(cpp_repo, cpp_source, cpp_output),
            "only accept .py",
            cpp_output,
        )
    print("self-test: ok")
    return 0


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description="Render static Python guard snapshots from source-causality evidence."
    )
    parser.add_argument("--repo-root", type=Path, help="Read-only repository root")
    parser.add_argument(
        "--source-causality-dir",
        type=Path,
        help="Directory containing control_flow_guard_candidates.csv and source_analysis_manifest.json",
    )
    parser.add_argument("--output", type=Path, help="Output directory outside the source repository")
    parser.add_argument(
        "--evidence-id",
        action="append",
        default=[],
        help="Also render this evidence_id; repeat for multiple selections",
    )
    parser.add_argument(
        "--context-lines",
        type=int,
        default=3,
        help="Maximum source lines before and after each guard (default: 3)",
    )
    parser.add_argument("--self-test", action="store_true", help="Run isolated security/contract tests")
    return parser


def main(argv: Sequence[str] | None = None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)
    if args.self_test:
        if args.repo_root or args.source_causality_dir or args.output or args.evidence_id:
            parser.error("--self-test cannot be combined with render inputs")
        return run_self_test()
    missing = [
        flag
        for flag, value in (
            ("--repo-root", args.repo_root),
            ("--source-causality-dir", args.source_causality_dir),
            ("--output", args.output),
        )
        if value is None
    ]
    if missing:
        parser.error("the following arguments are required: " + ", ".join(missing))
    try:
        document = render_python_guard_snapshots(
            args.repo_root,
            args.source_causality_dir,
            args.output,
            evidence_ids=args.evidence_id,
            context_lines=args.context_lines,
        )
    except (SnapshotError, OSError) as exc:
        print(f"error: {exc}", file=sys.stderr)
        return 2
    print(
        json.dumps(
            {
                "status": document["status"],
                "snapshot_count": document["snapshot_count"],
                "output": str(args.output.resolve()),
                "artifacts": list(OUTPUT_NAMES),
            },
            ensure_ascii=False,
        )
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

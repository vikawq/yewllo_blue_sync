# Profiling Alignment 中文报告契约

## 目录

1. 执行摘要
2. Rank 与 Thread 覆盖
3. Host 算子序列与首次分叉
4. Device 序列与 Host→Device
5. 控制流与代码证据
6. Predicate tensor 与 producer
7. Perfetto 内容复核
8. 结论强度与替代解释
9. 最小验证动作
10. 附录与证据可追溯性
11. 强制汇编与交付门禁

最终面向用户只交付 `<output>/profiling_alignment_report.md`。它必须是一份大型、自包含、证据驱动的分析报告，而不是 README、guide、文件索引或“如何继续分析”的操作清单。脚本产生的 CSV/JSON/JSONL/辅助 HTML 全部放入 `<output>/evidence/`，只作机器追溯附件；关键 Rank/lane、分叉上下文、算子路线、Python guard、代码快照、结论和建议必须在主报告正文完整展开，读者不打开 CSV 也能理解结论。正文、标题、表头、结论与建议用中文；算子、源码符号、字段、路径和 URL 保留原文。

固定交付布局：

```text
<output>/
  profiling_alignment_report.md
  evidence/
    run_comparability_contract.json
    preflight/
    alignment/
    source-entrypoints/
    source-causality/
    python-guard-snapshots/
    perfetto-review/
    report-validation/
    source-checkouts/          # 仅在缺少本地 owner 源码时
```

根目录不散落 CSV/JSON。主报告可以在附录引用 evidence 相对路径与 hash，但正文不得以“详见附件”替代实质内容。禁止只交付 `Key Finding + Outputs + Recommendations`、九个空洞章节、产物路径表或命令指南。报告规模由实际数据决定：每个同号 Rank、每个可观测 lane、每个首次稳定分叉和每个重大代码候选都必须产生对应正文；相同模式也先逐 Rank 给证据，再给聚合摘要。

报告开头必须声明：

```text
reference = 真机
candidate = 仿真
本报告只分析算子结构、顺序、嵌套、Shape 与控制流；不分析耗时或性能。
ts/dur 仅在解析器内部用于排序、B/E 配对、嵌套和 direct flow 端点恢复。
```

统一标签：

- `真机事实`：真机 Profiler/metadata/marker 直接给出；
- `仿真事实`：仿真产物直接给出；
- `源码事实`：固定版本源码直接存在；
- `强关联推断`：运行结构与源码 guard 同时吻合；
- `静态候选`：仅静态可达或运行绑定不足；
- `未知`：当前不可观测；
- `建议`：最小补证或 A/B。

禁止出现性能排序、耗时、延迟、利用率、重叠、空闲、带宽、duration ratio 或“仿真比真机快/慢”。如果原始文件含时间字段，也不复制到主报告。

真机是 reference 基线。Python 解释器版本和已安装 PyTorch 包版本允许不一致，在“环境事实”中最多作为 `informational/ignored` 一行记录；它们不参与结构可比性、控制流强度、根因排序或默认修复建议。禁止把“对齐 Python/PyTorch 版本”列为建议。不要混淆安装版本与源码证据：当实际 guard 属于 `torch/` 时仍须引用准确 torch 源码快照；当 guard 属于 `torch_npu/` 时，TorchNPU 版本、commit、build 与两侧实现差异仍可成为关键证据。

`run_comparability_contract.json` 顶层必须含 `source_roots.model/pytorch/torch_npu`。三个 canonical owner 分别是 `model`（显示名 MindSpeed）、`pytorch`（显示名 torch）和 `torch_npu`；结构化证据、候选与 manifest 必须使用 canonical 值。每个源码根条目必须有非空 `path/role/binding_side/status/evidence`。当前目录只有一份 `torch/` 或 `torch_npu/` 时，`role=reference-source-baseline`、`binding_side=real/reference`，不得把它写成 shared 或仿真实际绑定。报告在同一源码根记录中展开 path、role、binding_side 与 status；evidence 可在附录给短引用和 hash。

报告必须是有效 UTF-8，并通过 raw-text C0 控制字符扫描。只允许 LF 或成对 CRLF 行尾；TAB、BEL、FF、token 内 standalone CR、其余 `U+0000..U+001F` 与 `U+007F` 均是阻断项。尤其不能把 Python/JSON 字符串中的 `\a`、`\t`、`\f`、`\r` 误解释后写坏 `aten`、`torch`、`forward_*`、`record_*` 或 Windows 路径。不要凭显示结果猜修，回到结构化证据重新生成。

## 1. 执行摘要

必须包含：

1. 两侧路径、模型/workload/phase/schedule，以及 `source_roots.model/pytorch/torch_npu` 对应的 MindSpeed/torch/torch_npu 三个本地源码根；每根在同一行给出 path、role、binding_side、status，真机是 reference 基线；
2. 两侧采集格式门禁：integrated text export / raw msprof / DB-only，及 collection contract 的 complete/partial/unsupported；
3. 真机/仿真 Rank 清单、实际比较的同号交集、metadata/目录 Rank 冲突与未配对 Rank；
4. framework Host、Host launch、Device lane 数，以及 matched/ambiguous/real-only/sim-only 数；
5. 每 Rank 是否出现结构分叉；必须逐 Rank 独立列证据，不能只写“Rank 0–3 通用”；
6. 最重要的 3–5 条稳定分叉，优先首次 framework Host 分叉；
7. 已证实、强关联、静态候选、未知各自数量；
8. 能否判定仿真 tensor 计算错误；若不能，必须写“当前证据无法判定/未证实”，不能把它写成“否”；
9. 三个最小验证动作。

执行摘要不是整份报告。它只能压缩后续正文已经逐项展开并可追溯的事实；不得在摘要中给出正文没有对应 Rank/lane/divergence/代码证据的“大结论”。环境表把 Python/PyTorch 安装版本放到 `ignored informational` 列，不得把差异写进“最重要分叉”或建议。单份 `torch/`、`torch_npu/` 必须标“真机 reference 源码基线；仿真运行绑定未知”，不能写“双方源码”。

执行摘要中的每条 `强关联控制流分叉` 或 `已证实控制流分叉` 必须在同一单元格写出 `evidence_id=<...>`；普通结构分叉必须写 `divergence_id=<...>`。不得把某一个 Rank 或 Thread 外推成全部 Rank。Rank 身份为 `directory order`/枚举顺序时不允许进入 paired 表，必须列为 unknown/unpaired。跨 Rank、Thread、stream 的 aggregate calls 可另列 coverage 摘要，但不能替代逐 Rank/lane 行，也不能成为首次分叉或控制流强度证据。

## 2. Rank 与 Thread 覆盖

Rank 主表：

| Rank pair | 真机 trace/hash | 仿真 trace/hash | DP/TP/EP/PP/CP/DCP | 身份/拓扑门禁 | Framework/launch lanes 真/仿 | Device lanes 真/仿 | 状态 |
|---|---|---|---|---|---:|---:|---|

Thread/lane 主表：

| Rank | Domain | Semantic layer | 真机 lane | 仿真 lane | 方法 | Score/Margin | 置信度 | 状态 | 允许结论 |
|---|---|---|---|---|---|---|---|---|---|

逐项列出 ambiguous、real-only、sim-only，不只汇总数量。说明 PID/TID/stream 是环境内标识，跨环境配对依赖语义指纹。

`N/A`、`unknown` 或缺失 Stream ID 只能列为 `lane_observability=rank-only` 的 Device coverage，不计入 Device stream lane 数，不与另一侧 stream 配对。

表后必须逐 Rank 写简短但具体的覆盖解释：该 Rank 实际观察到哪些 framework/launch/device lane、哪些成功配对、哪些因何降级，以及这会限制哪类结论。不得用一个全局 lane 数字代替逐 Rank 正文。

## 3. Host 算子序列与首次分叉

每个 matched Host Thread 至少给一行；无差异也要写 `exact/no divergence`。

| divergence_id / Rank/Thread pair | 前/后 anchor 数与门禁 | 最后共同 anchor | 真机首差异算子/Shape/calls | 仿真首差异算子/Shape/calls | 下一共同 anchor | 三视图边界/重复歧义 | Stack/module | event IDs |
|---|---|---|---|---|---|---|---|---|

对重大分叉展示前后少量 `event_alignment.csv` 上下文，保留 `alignment_column`、relation 和 event ID。不要用长 equal 前缀淹没首差异。

`boundary_stability=stable` 必须逐项引用 op-only、op+metadata、tree-aware 三个边界都存在且相同（或三者都无差异），并引用 anchor/repeated/nesting gates。只检查两个视图时必须写 `unstable/insufficient`。调用数必须按当前 Rank/Thread 展示；全局 `216`、`109 vs 79` 之类聚合值不能代替 lane 内 `real_run_calls/sim_run_calls`。

结构热力图必须标为“序位热力图”：x 轴是 lane 内 event ordinal，不是时间。可嵌入或链接 `structural_heatmap.html`，但结论引用逐事件表。

每个有差异的 Host lane 必须在正文紧接表格展开至少一个“分叉窗口”小节，逐行列出最后共同 anchor、真机路线、仿真路线、下一共同 anchor、Shape/calls、stack/module 与 event ID，并用自然语言解释两条路线为什么在结构上不同。只写 `divergence_id` 或“见 event_alignment.csv”不算展开。无差异 lane 也要明确说明其比较范围和 `exact` 证据。

## 4. Device 序列与 Host→Device

Device 表：

| Rank/stream pair | 真机首差异 kernel/Shape/dtype/format | 仿真首差异 | 边界稳定性 | 证据来源 | Host link 状态 |
|---|---|---|---|---|---|

Host→Device 表：

| Rank/环境 | Host event/operator+layer | Device event/kernel | Link 类型/namespace | Endpoint match | ID hash | Causal eligible | 证据 |
|---|---|---|---|---|---|---|---|

没有 direct flow/correlation 时，明确写“Host 与 Device 差异尚未形成直接因果边”，禁止用时间邻近补链。

Host launch/kernel 总数、二者比例、Device kernel 类别总数及百分比只是 coverage-dependent 聚合观察。没有合格 direct link 时，不得据此推断“某 Host/FSDP 分支产生了这些 Device kernel”或“额外 workload”。

另列 `host_launch` bridge 表，明确 CANN/AscendCL/GE/Runtime/enqueue/dequeue 均为 Host。每条 Host→Device 因果应显示 flow namespace、ID kind、端点匹配方式与唯一性；ambiguous group 只作观察，不进入 direct link 表。

每个有差异的 Device lane 同样写独立路线说明；如果不能与 Host 建立 direct link，就把 Host 与 Device 分成两个并列观察，不要因为二者都出现在同一 Rank 就合并成因果故事。Device task 数量差可以作为结构 coverage，但禁止写成性能倍数；例如 `52885 vs 7141` 应写“调用数/任务数结构差”，不能写“7.4x 性能差异”。

## 5. 控制流与代码证据

对每个高价值 Host 分叉给出最短证据链：

```text
.sh/argv/config
  -> Python entry/main/forward
  -> file:symbol:if/elif/else predicate
  -> 真机 arm / 仿真 arm
  -> 两侧 branch-exclusive Host operators
  -> direct-linked Device kernels（若有）
```

这条证据链必须在正文展开成完整分析，而不是只保留箭头摘要。先说明算子路线证据，再说明候选 owner 与 repo 选择，再展示 AST guard、两个 arm、predicate/producer，最后说明哪些证据尚缺。代码段必须直接可见。

Guard 主表：

| evidence_id / Rank/Thread | divergence_id | Lane/anchor/入口/源码门禁 | guard_id + predicate | Repo@commit | File/symbol/guard+arm lines | 真机 arm+算子 | 仿真 arm+算子 | Coverage/Precision | Runtime 绑定 | 强度 |
|---|---|---|---|---|---|---|---|---|---|---|

每条代码证据引用 repo、commit/ref、path、symbol、紧凑行范围、permalink 和 runtime binding。源码版本冲突时只作参考，不给运行因果。

先按文件归属选择源码根：MindSpeed 负责模型/训练 Python，`torch/` 负责 PyTorch/FSDP 核心，`torch_npu/` 负责 TorchNPU patch/lowering。模型 `.sh` 入口只从 MindSpeed 解析。报告必须写明本次首要分叉 owner；一次 validation 的 `source-causality/` 与 `python-guard-snapshots/` 只承载这个主 owner 的升级候选。其它 owner 的代码可作为源码事实或静态导航，不能未经独立门禁混成第二组强结论。

公共目录只有一份 `torch/` 或 `torch_npu/` 时，快照标题必须写“真机 reference 源码基线”；仿真侧代码绑定写 `unknown/unverified`。不得把这份快照同时标为 real/sim，也不得用它证明双方 guard 同构。可选仿真侧 checkout 只有与仿真 runtime/build evidence 绑定后才进入双侧源码比较。

Stack 到函数/调用点只是 source-navigation clue，不是 guard。Guard 行必须来自 AST 产物并具备 `guard_id`、原始 predicate、guard kind、guard/arm 精确行范围，以及两侧 branch-exclusive operator 映射。若候选位于 TorchNPU/FSDP patch，必须分别绑定两侧该依赖源码/构建版本；模型仓 commit 不能替代依赖版本。若候选位于 PyTorch 源码，同样绑定实际 guard 源码，而不是比较 `torch.__version__`。`runtime_binding=unverified/conflict`、两侧 `analyzed_source` 非 verified-equal 或只解析了一侧版本时，最多为 `静态候选`。Python 解释器和 PyTorch 安装版本不同本身不会触发这个降级。

每条 `强关联控制流分叉`/`已证实控制流分叉` 还必须引用 `python_guard_snapshots.json` 的同一 `evidence_id`，并把 `python_guard_snapshots.md` 中该 ID 对应的完整静态 HTML 片段直接嵌入主 Markdown。片段至少显示 repository、完整 commit/tree、`.py` path、symbol、guard/real arm/sim arm 行范围、source SHA、snippet SHA；代码逐行放入 HTML-escaped `<code>` 单元格，左侧保留原始 1-based 行号，并分别标记 predicate、真机 arm、仿真 arm。不能只给 C/C++ stack、函数名、网页链接或无行号代码块；`.cc/.cpp/.h` 只能另列为 backend/bridge 线索。HTML 禁止 `<script>`、事件属性、外部样式/资源和可执行导出。

主报告禁止 HTML comments、Unicode `Cf`（零宽/双向等隐藏格式字符）以及快照以外的 raw HTML。不要用 comment、零宽字符、HTML entity、Markdown emphasis 或物理换行拆开强度名称、Perfetto 状态、evidence ID 或算子 token；验证器按可见 Markdown 规范化，并把同一普通段落的任意数量 soft-wrap 行作为一个逻辑记录。每条升级结论及其完整 ID 必须位于同一表格行或同一逻辑段落。

## 6. Predicate tensor 与 producer

表：

| Guard | Operand | 类型 | 真机直接值/result | 仿真直接值/result | 静态 producer | Producer Host event | Device link | 证据状态 | 缺失补证 |
|---|---|---|---|---|---|---|---|---|---|

严格区分：

- `直接 runtime value`；
- `直接 Shape/dtype metadata`；
- `最近静态 assignment`；
- `从下游算子推测`（不能作值证据）；
- `未知`。

如果缺少 predicate operand 值，不得写“仿真把该 tensor 算错”；只能写 guard 与不同算子 arm 强关联，并给最小 hook schema。

## 7. Perfetto 内容复核

每个 Rank 两侧各一行；注明 Perfetto 只交叉复核 Host framework/launch track，Device 顺序与 flow 的主证据来自本地结构解析：

| Rank/环境 | Trace SHA | Lane batch 覆盖 | Offline/SW/localOnly 门禁 | HTML/text/SQL 已读 | 观察 | Screenshot 已看 | Canvas 结论 |
|---|---|---|---|---|---|---|---|

必须拆开：

1. 页面/SQL 自动产物；
2. 分析代理实际读取 HTML/text/SQL 的内容复核；
3. 可选 Canvas 截图复核。

未查看 PNG 时 `Screenshot 已看=否`、`Canvas 结论=未评价`。即使看了截图，也不能从条宽或空白推断耗时。

Perfetto 未执行原因只能来自在线授权/数据政策、`ui.perfetto.dev` 网络、浏览器、Playwright 或 UI 自动化条件。GitHub/GitCode 源码站不可达只影响源码绑定，不能写成 Perfetto 未执行原因。“采样了全部事件”是矛盾表述：要么给逐 Rank/lane coverage 并写“穷举解析可观测事件”，要么明确 sampled/partial。

## 8. 结论强度与替代解释

逐条列，并引用 `divergence_id` 或 `control_flow_guard_candidates.csv.evidence_id`：

- `已证实控制流分叉`；
- `强关联控制流分叉`；
- `静态候选`；
- `仿真计算错误已证实`（通常需要额外受控复现）；
- `未知`。

强度名称必须逐字采用上述规范词；不要用“强关联控制流分歧”“高置信路径差异”“已确认分支差异”等近义词规避结构化 candidate、源码绑定或 Python 快照门禁。验证器会把这类升级措辞按相应等级处理并以非规范名称阻断。

每条推断都列至少一个替代解释，例如：采集窗口不同、workload/Shape 不同、线程错配、backend lowering、图捕获、instrumentation 缺失、guard owner 源码/构建冲突。不要把 Python/PyTorch 安装版本差异作为兜底替代解释。

## 9. 最小验证动作

按成本排序给出：

1. 对哪个 `guard_id` 增加什么 predicate/operand marker；
2. 哪个 Rank/Thread/step 需要重采；
3. 哪个 producer operator/tensor 需要 hash/scalar/min/max/nonzero_count；
4. 哪个 Host→Device correlation 需要补采；
5. 什么 A/B（固定输入/seed/config/commit）能证伪候选；
6. 修正后应观察哪些 operator 序列重新汇合。

不要建议对齐 Python 解释器或已安装 PyTorch 包版本。若证据指向 TorchNPU owner，可以建议在不改变真机 reference 的前提下，用固定输入对仿真 TorchNPU patch/build 做针对性 A/B；必须说明这是 guard 实现验证，不是泛化地追求两套环境 100% 一致。

## 10. 附录与证据可追溯性

列出所有主证据的 `evidence/` 相对路径、SHA（适用时）、schema/algorithm version、parser warnings、预算截断、源码 issues。确认原始 Profiling 与源码仓未修改。附录保持简洁，不能让证据文件清单压过逐 Rank/lane 和代码因果正文；绝对路径只在确有审计需要时列一次。

## 11. 强制汇编与交付门禁

先运行汇编器，不能从空模板手写一份 guide：

```powershell
python scripts/build_alignment_report.py `
  --alignment-output "<output>/evidence/alignment" `
  --preflight-dir "<output>/evidence/preflight" `
  --run-contract "<output>/evidence/run_comparability_contract.json" `
  --source-causality-dir "<output>/evidence/source-causality" `
  --python-snapshots-dir "<output>/evidence/python-guard-snapshots" `
  --perfetto-review-dir "<output>/evidence/perfetto-review" `
  --output "<output>/profiling_alignment_report.md"
```

汇编器必须把结构化数据展开到正文。代理随后实际读取整份报告与关键 evidence，补充因果解释、替代解释和最小验证动作；不得删除逐 Rank/lane/divergence 章节。整份报告、标题、表格、证据 ID 和 Python `<details>` 快照都必须处于正常 Markdown flow；fenced code block 与四空格缩进代码块中的文本一律不能满足报告门禁。最后运行 `scripts/validate_alignment_report.py --python-snapshots-dir <output>/evidence/python-guard-snapshots --perfetto-review-dir <output>/evidence/perfetto-review`。必须保留并实际读取：

```text
python-guard-snapshots/python_guard_snapshots.json
python-guard-snapshots/python_guard_snapshots.csv
python-guard-snapshots/python_guard_snapshots.md
python-guard-snapshots/python_guard_snapshots.html
perfetto-review/perfetto_batch_manifest.json
perfetto-review/perfetto_batch_manifest.csv
perfetto-review/perfetto_content_review.json
report-validation/report_validation.json
report-validation/report_validation.csv
```

以上路径均相对 `<output>/evidence/`。命令还必须传 `--perfetto-review-dir <output>/evidence/perfetto-review`；即使在线复核未获授权，也要让 batch wrapper 写出可验证的 `not-executed` manifest/content review。只有 `status=pass` 且 `blocking_error_count=0` 才能交付。验证器是最低门槛，不替代人工证据复核；“PASS”不能证明报告有足够正文。不得删除结构化产物、手改验证 JSON、只交付 Outputs 路径表或以“报告看起来合理”绕过非零退出码。

#!/usr/bin/env python3
"""Read-only preflight for Ascend/TorchNPU profiling alignment inputs.

The only fully supported input contract is a TorchNPU-integrated text export.
The canonical layout uses an ``ASCEND_PROFILER_OUTPUT`` directory, but the same
artifact set may be flattened directly into a rank directory.  Raw msprof trees
and analysis.db-only exports are detected explicitly and reported as
unsupported; their absence of text events is never represented as a zero-event
observation.

This module uses only the Python standard library.  It never imports or runs
model/source code, never mutates input roots, and writes only the requested
``collection_contract.csv`` and ``collection_contract.json`` artifacts.
"""

from __future__ import annotations

import argparse
import csv
import io
import json
import os
import re
import sys
from collections import defaultdict
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Iterable, Iterator, Sequence


SCHEMA_VERSION = 1
SUPPORTED_FORMAT = (
    "TorchNPU integrated text export "
    "(ASCEND_PROFILER_OUTPUT or equivalent flattened artifact directory)"
)
MAX_JSON_VALUE_CHARS = 64 * 1024 * 1024
MAX_CONFIG_FILE_BYTES = 16 * 1024 * 1024
MAX_SOURCE_FILE_BYTES = 2 * 1024 * 1024
MAX_SOURCE_TOTAL_BYTES = 16 * 1024 * 1024
MAX_DISCOVERED_FILES = 4096

UNKNOWN = "unknown"
ENABLED = "enabled"
DISABLED = "disabled"
CONFLICT = "conflict"
OBSERVED = "observed"

TEXT_EXPORT_FILES = ("trace_view.json", "operator_details.csv", "kernel_details.csv")
INTEGRATED_DIRECTORY_NAME = "ascend_profiler_output"
RAW_MSPROF_DIRECTORY_NAMES = {"mindstudio_profiler_output"}
RAW_PROF_DIRECTORY_PATTERN = re.compile(r"^prof_", re.IGNORECASE)
RAW_MSPROF_DIRECTORY_PATTERN = re.compile(r"^msprof_", re.IGNORECASE)
RAW_MSPROF_JSON_PATTERN = re.compile(r"^msprof_.*\.json$", re.IGNORECASE)
METADATA_PATTERNS = (
    "profiler_info*.json",
    "profiler_metadata*.json",
    "metadata*.json",
    "profiler_config*.json",
    "profile_config*.json",
)
SOURCE_SUFFIXES = {".py", ".sh", ".yaml", ".yml", ".toml"}
SOURCE_NAME_PATTERN = re.compile(r"prof(?:ile|iler)|config|launch|run", re.IGNORECASE)
RANK_PATTERN = re.compile(
    r"(?:^|[_\-.])(?:global[_-]?)?rank[_:=\-]?(\d+)(?:$|[_\-.])",
    re.IGNORECASE,
)
KNOWN_HOST_PREFIXES = (
    "aten::",
    "torch::",
    "torch_npu::",
    "npu::",
    "prims::",
    "quantized::",
    "c10d::",
    "distributed::",
)

CSV_FIELDS = (
    "environment",
    "role",
    "side_root",
    "profile_path",
    "profile_format",
    "format_support",
    "status",
    "status_reason",
    "supported_contract",
    "event_observation",
    "trace_view_path",
    "trace_parse_status",
    "operator_details_path",
    "kernel_details_path",
    "analysis_db_paths",
    "profiler_info_paths",
    "trace_event_count",
    "host_operator_count",
    "host_thread_count",
    "acl_event_count",
    "runtime_event_count",
    "kernel_trace_event_count",
    "kernel_csv_event_count",
    "operator_details_row_count",
    "kernel_start_field",
    "missing_stream_count",
    "host_kernel_bridge",
    "acl_runtime_bridge",
    "runtime_kernel_bridge",
    "rank_status",
    "rank_id",
    "metadata_rank_values",
    "directory_rank_values",
    "rank_conflict",
    "activities_cpu",
    "activities_npu",
    "activity_evidence",
    "record_shapes",
    "with_stack",
    "with_modules",
    "profiler_level",
    "schedule",
    "collection_window",
    "child_thread_registration",
    "config_evidence",
    "issues",
    "zero_event_claim",
)


def normalized_key(value: Any) -> str:
    return re.sub(r"[^a-z0-9]", "", str(value).casefold())


def compact_json(value: Any) -> str:
    return json.dumps(value, ensure_ascii=False, separators=(",", ":"), sort_keys=True)


def unique_text(values: Iterable[Any]) -> list[str]:
    return sorted({str(value).strip() for value in values if str(value).strip()})


def parse_bool(value: Any) -> str | None:
    if isinstance(value, bool):
        return ENABLED if value else DISABLED
    if isinstance(value, int) and value in (0, 1):
        return ENABLED if value else DISABLED
    if isinstance(value, str):
        token = value.strip().casefold()
        if token in {"true", "yes", "on", "enabled", "enable", "1"}:
            return ENABLED
        if token in {"false", "no", "off", "disabled", "disable", "0"}:
            return DISABLED
    return None


def parse_int(value: Any) -> int | None:
    if isinstance(value, bool):
        return None
    text = str(value).strip()
    if not re.fullmatch(r"[-+]?\d+", text):
        return None
    try:
        return int(text)
    except ValueError:
        return None


def ensure_within(path: Path, root: Path) -> bool:
    try:
        path.resolve().relative_to(root.resolve())
        return True
    except (OSError, ValueError):
        return False


def path_is_within(path: Path, parent: Path) -> bool:
    try:
        path.resolve().relative_to(parent.resolve())
        return True
    except (OSError, ValueError):
        return False


def safe_stat_size(path: Path) -> int | None:
    try:
        return path.stat().st_size
    except OSError:
        return None


def read_text_bounded(path: Path, limit: int) -> str | None:
    size = safe_stat_size(path)
    if size is None or size > limit:
        return None
    try:
        return path.read_text(encoding="utf-8-sig", errors="strict")
    except (OSError, UnicodeError):
        return None


class JSONCharReader:
    """Buffered reader used to inspect very large Chrome trace JSON files."""

    def __init__(self, handle: Any, chunk_size: int = 1024 * 1024) -> None:
        self.handle = handle
        self.chunk_size = chunk_size
        self.buffer = ""
        self.position = 0
        self.absolute_position = 0
        self.eof = False

    def _compact(self) -> None:
        if self.position > self.chunk_size and self.position > len(self.buffer) // 2:
            self.buffer = self.buffer[self.position :]
            self.position = 0

    def _fill(self, count: int = 1) -> None:
        while len(self.buffer) - self.position < count and not self.eof:
            self._compact()
            chunk = self.handle.read(self.chunk_size)
            if chunk == "":
                self.eof = True
                break
            self.buffer += chunk

    def peek(self) -> str:
        self._fill(1)
        return self.buffer[self.position] if self.position < len(self.buffer) else ""

    def get(self) -> str:
        character = self.peek()
        if character:
            self.position += 1
            self.absolute_position += 1
        return character

    def skip_ws(self) -> None:
        while self.peek() and self.peek().isspace():
            self.get()

    def expect(self, expected: str) -> None:
        self.skip_ws()
        actual = self.get()
        if actual != expected:
            raise ValueError(
                f"JSON position {self.absolute_position}: expected {expected!r}, got {actual!r}"
            )

    def read_raw_value(self, capture: bool = True) -> str:
        self.skip_ws()
        first = self.peek()
        if not first:
            raise ValueError(f"JSON position {self.absolute_position}: unexpected EOF")
        effective_capture = capture or first not in "[{"
        output = io.StringIO() if effective_capture else None
        captured = 0

        def append(character: str) -> None:
            nonlocal captured
            if effective_capture:
                captured += len(character)
                if captured > MAX_JSON_VALUE_CHARS:
                    raise ValueError("single JSON value exceeds 64 MiB safety limit")
                assert output is not None
                output.write(character)

        if first in "[{":
            stack: list[str] = []
            in_string = False
            escaped = False
            while True:
                character = self.get()
                if not character:
                    raise ValueError("compound JSON value is not closed")
                append(character)
                if in_string:
                    if escaped:
                        escaped = False
                    elif character == "\\":
                        escaped = True
                    elif character == '"':
                        in_string = False
                    continue
                if character == '"':
                    in_string = True
                elif character in "[{":
                    stack.append("}" if character == "{" else "]")
                elif character in "]}":
                    if not stack or character != stack[-1]:
                        raise ValueError("mismatched JSON closing delimiter")
                    stack.pop()
                    if not stack:
                        break
            return "" if output is None else output.getvalue()

        if first == '"':
            escaped = False
            first_character = True
            while True:
                character = self.get()
                if not character:
                    raise ValueError("JSON string is not closed")
                append(character)
                if first_character:
                    first_character = False
                elif escaped:
                    escaped = False
                elif character == "\\":
                    escaped = True
                elif character == '"':
                    break
            return "" if output is None else output.getvalue()

        while self.peek() and self.peek() not in ",]}" and not self.peek().isspace():
            append(self.get())
        if captured == 0:
            raise ValueError("empty JSON value")
        return "" if output is None else output.getvalue()

    def read_value(self) -> Any:
        return json.loads(self.read_raw_value(capture=True))

    def skip_value(self, depth: int = 0) -> None:
        if depth > 1000:
            raise ValueError("JSON nesting exceeds safety limit")
        self.skip_ws()
        first = self.peek()
        if first == "{":
            self.get()
            self.skip_ws()
            if self.peek() == "}":
                self.get()
                return
            while True:
                if not isinstance(self.read_value(), str):
                    raise ValueError("JSON object key is not a string")
                self.expect(":")
                self.skip_value(depth + 1)
                self.skip_ws()
                separator = self.get()
                if separator == "}":
                    return
                if separator != ",":
                    raise ValueError("JSON object member lacks separator")
        elif first == "[":
            self.get()
            self.skip_ws()
            if self.peek() == "]":
                self.get()
                return
            while True:
                self.skip_value(depth + 1)
                self.skip_ws()
                separator = self.get()
                if separator == "]":
                    return
                if separator != ",":
                    raise ValueError("JSON array element lacks separator")
        else:
            json.loads(self.read_raw_value(capture=True))


def iter_json_array(reader: JSONCharReader) -> Iterator[Any]:
    reader.expect("[")
    reader.skip_ws()
    if reader.peek() == "]":
        reader.get()
        return
    while True:
        yield reader.read_value()
        reader.skip_ws()
        separator = reader.get()
        if separator == "]":
            return
        if separator != ",":
            raise ValueError("JSON array element lacks ',' or ']'")


def iter_trace_events(path: Path) -> Iterator[dict[str, Any]]:
    with path.open("r", encoding="utf-8-sig", errors="strict") as handle:
        reader = JSONCharReader(handle)
        reader.skip_ws()
        first = reader.peek()
        if first == "[":
            for value in iter_json_array(reader):
                yield value if isinstance(value, dict) else {}
            reader.skip_ws()
            if reader.peek():
                raise ValueError("extra content after top-level JSON array")
            return
        if first != "{":
            raise ValueError("trace must be an array or an object containing traceEvents")
        reader.expect("{")
        found = False
        reader.skip_ws()
        if reader.peek() == "}":
            reader.get()
        else:
            while True:
                key = reader.read_value()
                if not isinstance(key, str):
                    raise ValueError("top-level JSON key is not a string")
                reader.expect(":")
                if key == "traceEvents" and not found:
                    found = True
                    for value in iter_json_array(reader):
                        yield value if isinstance(value, dict) else {}
                else:
                    reader.skip_value()
                reader.skip_ws()
                separator = reader.get()
                if separator == "}":
                    break
                if separator != ",":
                    raise ValueError("top-level JSON member lacks separator")
        if not found:
            raise ValueError("top-level JSON object has no traceEvents array")


def event_args(event: dict[str, Any]) -> dict[str, Any]:
    value = event.get("args")
    return value if isinstance(value, dict) else {}


def arg_value(args: dict[str, Any], *aliases: str) -> Any:
    index = {normalized_key(key): value for key, value in args.items()}
    for alias in aliases:
        key = normalized_key(alias)
        if key in index:
            return index[key]
    return None


def canonical_id(value: Any) -> str:
    if value is None or isinstance(value, bool):
        return ""
    if isinstance(value, (dict, list, tuple)):
        return ""
    return str(value).strip()


@dataclass
class TraceFacts:
    parse_status: str = "missing"
    parse_error: str = ""
    total_events: int = 0
    host_operator_count: int = 0
    host_threads: set[tuple[str, str]] = field(default_factory=set)
    acl_event_count: int = 0
    runtime_event_count: int = 0
    kernel_event_count: int = 0
    missing_stream_count: int = 0
    input_dims_observed: bool = False
    call_stack_observed: bool = False
    module_hierarchy_observed: bool = False
    step_ids: set[str] = field(default_factory=set)
    flow_event_count: int = 0
    ids_by_layer: dict[str, set[str]] = field(
        default_factory=lambda: defaultdict(set)
    )


def classify_trace_layer(event: dict[str, Any]) -> str:
    name = str(event.get("name") or "").strip()
    lower_name = name.casefold()
    category = str(event.get("cat") or "").casefold()
    tokens = {token.strip() for token in category.split(",") if token.strip()}
    args = event_args(event)
    if "cpu_op" in tokens and (
        lower_name.startswith(KNOWN_HOST_PREFIXES) or lower_name == "record_param_comms"
    ):
        return "host"
    if "runtime" in category or lower_name.startswith("aclrt"):
        return "runtime"
    if "ascendcl" in category or lower_name.startswith(("aclnn", "aclop", "aclmdl")):
        return "acl"
    if (
        "kernel" in category
        or "task scheduler" in category
        or "aicore" in category
        or "aicpu" in category
        or arg_value(args, "Task Type") is not None
    ):
        return "kernel"
    return "other"


def inspect_trace(path: Path | None) -> TraceFacts:
    facts = TraceFacts()
    if path is None or not path.is_file():
        return facts
    facts.parse_status = "success"
    try:
        for event in iter_trace_events(path):
            facts.total_events += 1
            phase = str(event.get("ph") or "")
            if phase in {"s", "t", "f"}:
                facts.flow_event_count += 1
                continue
            if phase not in {"X", "B", "E"}:
                continue
            layer = classify_trace_layer(event)
            args = event_args(event)
            if layer == "host":
                facts.host_operator_count += 1
                facts.host_threads.add((str(event.get("pid") or ""), str(event.get("tid") or "")))
                if arg_value(args, "Input Dims", "Input Shapes", "Input Shape") is not None:
                    facts.input_dims_observed = True
                if arg_value(args, "Call stack", "Call Stack", "Stack") not in (None, "", []):
                    facts.call_stack_observed = True
                if arg_value(args, "Module Hierarchy", "Module", "Module hierarchy") not in (None, "", []):
                    facts.module_hierarchy_observed = True
            elif layer == "acl":
                facts.acl_event_count += 1
            elif layer == "runtime":
                facts.runtime_event_count += 1
            elif layer == "kernel":
                facts.kernel_event_count += 1
                stream = arg_value(args, "Stream ID", "Stream Id", "Stream", "stream_id")
                if stream in (None, ""):
                    facts.missing_stream_count += 1
            if layer in {"host", "acl", "runtime", "kernel"}:
                for raw_id in (
                    arg_value(args, "External id", "External ID", "ExternalId"),
                    arg_value(args, "correlation", "Correlation id", "Correlation ID", "CorrelationId"),
                ):
                    identity = canonical_id(raw_id)
                    if identity and len(facts.ids_by_layer[layer]) < 200_000:
                        facts.ids_by_layer[layer].add(identity)
            step = arg_value(args, "Step Id", "Step ID", "Step", "Profiler Step")
            if step not in (None, "") and len(facts.step_ids) < 10_000:
                facts.step_ids.add(str(step))
            name = str(event.get("name") or "")
            match = re.search(r"ProfilerStep#?\s*(\d+)", name, re.IGNORECASE)
            if match and len(facts.step_ids) < 10_000:
                facts.step_ids.add(match.group(1))
    except (OSError, UnicodeError, ValueError, json.JSONDecodeError) as error:
        facts.parse_status = "failure"
        facts.parse_error = f"{type(error).__name__}: {error}"
    return facts


@dataclass
class CSVFacts:
    parse_status: str = "missing"
    parse_error: str = ""
    row_count: int = 0
    headers: list[str] = field(default_factory=list)
    start_field: str = ""
    missing_stream_count: int = 0
    shape_observed: bool = False
    stack_observed: bool = False
    step_ids: set[str] = field(default_factory=set)


def inspect_csv(path: Path | None, kind: str) -> CSVFacts:
    facts = CSVFacts()
    if path is None or not path.is_file():
        return facts
    facts.parse_status = "success"
    try:
        with path.open("r", encoding="utf-8-sig", errors="strict", newline="") as handle:
            reader = csv.DictReader(handle)
            facts.headers = list(reader.fieldnames or [])
            normalized_headers = {normalized_key(value): value for value in facts.headers}
            for alias in ("Start Time(us)", "Start Time", "Start(us)", "Start", "Timestamp"):
                actual = normalized_headers.get(normalized_key(alias))
                if actual:
                    facts.start_field = actual
                    break
            stream_field = next(
                (
                    normalized_headers[key]
                    for key in ("streamid", "stream")
                    if key in normalized_headers
                ),
                "",
            )
            input_shape_field = next(
                (
                    normalized_headers[key]
                    for key in ("inputshapes", "inputshape")
                    if key in normalized_headers
                ),
                "",
            )
            output_shape_field = next(
                (
                    normalized_headers[key]
                    for key in ("outputshapes", "outputshape")
                    if key in normalized_headers
                ),
                "",
            )
            stack_field = next(
                (
                    normalized_headers[key]
                    for key in ("callstack", "stack")
                    if key in normalized_headers
                ),
                "",
            )
            step_field = next(
                (
                    normalized_headers[key]
                    for key in ("stepid", "step")
                    if key in normalized_headers
                ),
                "",
            )
            name_field = next(
                (
                    normalized_headers[key]
                    for key in ("name", "opname", "operator", "kernelname", "taskname")
                    if key in normalized_headers
                ),
                "",
            )
            for row in reader:
                if kind == "kernel" and name_field and not str(row.get(name_field) or "").strip():
                    continue
                facts.row_count += 1
                if kind == "kernel" and (not stream_field or not str(row.get(stream_field) or "").strip()):
                    facts.missing_stream_count += 1
                if input_shape_field and str(row.get(input_shape_field) or "").strip():
                    facts.shape_observed = True
                if output_shape_field and str(row.get(output_shape_field) or "").strip():
                    facts.shape_observed = True
                if stack_field and str(row.get(stack_field) or "").strip():
                    facts.stack_observed = True
                if step_field:
                    step = str(row.get(step_field) or "").strip()
                    if step and len(facts.step_ids) < 10_000:
                        facts.step_ids.add(step)
    except (OSError, UnicodeError, csv.Error) as error:
        facts.parse_status = "failure"
        facts.parse_error = f"{type(error).__name__}: {error}"
    return facts


@dataclass
class ConfigFacts:
    observations: dict[str, list[tuple[str, str]]] = field(
        default_factory=lambda: defaultdict(list)
    )
    metadata_rank_values: set[int] = field(default_factory=set)
    profiler_info_paths: set[str] = field(default_factory=set)
    sources: set[str] = field(default_factory=set)

    def add(self, field_name: str, value: str, evidence: str) -> None:
        if value:
            item = (value, evidence)
            if item not in self.observations[field_name]:
                self.observations[field_name].append(item)
            self.sources.add(evidence.split(":", 1)[0])

    def resolved(self, field_name: str) -> str:
        values = unique_text(value for value, _ in self.observations.get(field_name, []))
        if not values:
            return UNKNOWN
        if len(values) == 1:
            return values[0]
        return CONFLICT

    def evidence(self, fields: Sequence[str] | None = None) -> list[str]:
        selected = fields or tuple(self.observations)
        result: list[str] = []
        for field_name in selected:
            for value, source in self.observations.get(field_name, []):
                result.append(f"{field_name}={value}@{source}")
        return sorted(set(result))


def iter_json_nodes(value: Any, path: tuple[str, ...] = (), depth: int = 0) -> Iterator[tuple[tuple[str, ...], Any]]:
    if depth > 12:
        return
    yield path, value
    if isinstance(value, dict):
        for raw_key, child in list(value.items())[:10_000]:
            yield from iter_json_nodes(child, (*path, str(raw_key)), depth + 1)
    elif isinstance(value, list):
        for index, child in enumerate(value[:10_000]):
            yield from iter_json_nodes(child, (*path, str(index)), depth + 1)


def parse_activity_tokens(value: Any) -> set[str]:
    if isinstance(value, (list, tuple, set)):
        text = " ".join(str(item) for item in value)
    else:
        text = str(value)
    result: set[str] = set()
    if re.search(r"(?:ProfilerActivity\.)?CPU\b", text, re.IGNORECASE):
        result.add("CPU")
    if re.search(r"(?:ProfilerActivity\.)?(?:NPU|PRIVATEUSE1)\b", text, re.IGNORECASE):
        result.add("NPU")
    return result


def collect_json_config(path: Path, facts: ConfigFacts) -> None:
    text = read_text_bounded(path, MAX_CONFIG_FILE_BYTES)
    if text is None:
        return
    try:
        payload = json.loads(text)
    except json.JSONDecodeError:
        return
    evidence_path = str(path.resolve())
    if path.name.casefold().startswith("profiler_info"):
        facts.profiler_info_paths.add(evidence_path)
    schedule_values: dict[str, str] = {}
    for node_path, value in iter_json_nodes(payload):
        if not node_path:
            continue
        key = normalized_key(node_path[-1])
        evidence = f"{evidence_path}:{'.'.join(node_path)}"
        if key in {"globalrank", "rankid"}:
            rank = parse_int(value)
            if rank is not None:
                facts.metadata_rank_values.add(rank)
        if key in {"activities", "profileractivities", "activity"}:
            tokens = parse_activity_tokens(value)
            if tokens:
                facts.add("activities_cpu", ENABLED if "CPU" in tokens else DISABLED, evidence)
                facts.add("activities_npu", ENABLED if "NPU" in tokens else DISABLED, evidence)
        if key == "recordshapes":
            parsed = parse_bool(value)
            if parsed:
                facts.add("record_shapes", parsed, evidence)
        if key == "withstack":
            parsed = parse_bool(value)
            if parsed:
                facts.add("with_stack", parsed, evidence)
        if key in {"withmodules", "withmodule"}:
            parsed = parse_bool(value)
            if parsed:
                facts.add("with_modules", parsed, evidence)
        if key in {"profilerlevel", "profilelevel"} and not isinstance(value, (dict, list)):
            facts.add("profiler_level", str(value).strip(), evidence)
        if key in {"exporttype", "profilerexporttype"} and not isinstance(value, (dict, list)):
            facts.add("export_type", str(value).strip(), evidence)
        if key in {
            "childthreadprofiler",
            "enableprofilerinchildthread",
            "childthreadregistration",
        }:
            parsed = parse_bool(value)
            if parsed:
                facts.add("child_thread_registration", parsed, evidence)
        if key in {"wait", "warmup", "active", "repeat", "skipfirst", "skipfirstwait"}:
            if any(normalized_key(part) in {"schedule", "profilerschedule"} for part in node_path[:-1]):
                schedule_values[key] = str(value)
    if schedule_values:
        facts.add("schedule", compact_json(schedule_values), evidence_path)


def source_line_number(text: str, start: int) -> int:
    return text.count("\n", 0, start) + 1


def collect_source_config(path: Path, facts: ConfigFacts) -> None:
    text = read_text_bounded(path, MAX_SOURCE_FILE_BYTES)
    if text is None:
        return
    source = str(path.resolve())

    activity_context = re.search(r"activities\s*=\s*[\[(].{0,1000}?[\])]", text, re.IGNORECASE | re.DOTALL)
    if activity_context:
        activity_tokens = parse_activity_tokens(activity_context.group(0))
    else:
        activity_tokens = set()
    if activity_tokens:
        evidence = f"{source}:{source_line_number(text, activity_context.start())}"
        facts.add("activities_cpu", ENABLED if "CPU" in activity_tokens else DISABLED, evidence)
        facts.add("activities_npu", ENABLED if "NPU" in activity_tokens else DISABLED, evidence)

    for field_name, spelling in (
        ("record_shapes", "record_shapes"),
        ("with_stack", "with_stack"),
        ("with_modules", "with_modules"),
    ):
        pattern = re.compile(rf"\b{re.escape(spelling)}\s*=\s*(True|False|true|false|0|1)\b")
        for match in pattern.finditer(text):
            parsed = parse_bool(match.group(1))
            if parsed:
                facts.add(field_name, parsed, f"{source}:{source_line_number(text, match.start())}")

    level_match = re.search(
        r"\bprofiler_level\s*=\s*([A-Za-z0-9_\.]+|['\"][^'\"]+['\"])", text
    )
    if level_match:
        facts.add(
            "profiler_level",
            level_match.group(1).strip("'\""),
            f"{source}:{source_line_number(text, level_match.start())}",
        )
    export_match = re.search(
        r"\bexport_type\s*=\s*([A-Za-z0-9_\.]+|['\"][^'\"]+['\"])", text
    )
    if export_match:
        facts.add(
            "export_type",
            export_match.group(1).strip("'\""),
            f"{source}:{source_line_number(text, export_match.start())}",
        )
    for match in re.finditer(r"(?:torch_npu\.profiler\.)?schedule\s*\(([^)]*)\)", text, re.DOTALL):
        arguments: dict[str, str] = {}
        for key, value in re.findall(
            r"\b(wait|warmup|active|repeat|skip_first|skip_first_wait)\s*=\s*([^,\n)]+)",
            match.group(1),
        ):
            arguments[normalized_key(key)] = value.strip()
        if arguments:
            facts.add(
                "schedule",
                compact_json(arguments),
                f"{source}:{source_line_number(text, match.start())}",
            )
    enable_match = re.search(r"\benable_profiler_in_child_thread\s*\(", text)
    if enable_match:
        facts.add(
            "child_thread_registration",
            ENABLED,
            f"{source}:{source_line_number(text, enable_match.start())}",
        )


def discover_config_files(profile_dir: Path, side_root: Path) -> tuple[list[Path], list[Path]]:
    json_paths: set[Path] = set()
    source_paths: set[Path] = set()
    locations = [profile_dir, profile_dir.parent, profile_dir.parent.parent, side_root]
    for location in locations:
        if not location.is_dir() or not ensure_within(location, side_root):
            continue
        for pattern in METADATA_PATTERNS:
            for path in location.glob(pattern):
                if path.is_file() and ensure_within(path, side_root):
                    json_paths.add(path.resolve())
    source_bytes = 0
    try:
        candidates = side_root.rglob("*")
        for path in candidates:
            if len(json_paths) + len(source_paths) >= MAX_DISCOVERED_FILES:
                break
            if not path.is_file() or not ensure_within(path, side_root):
                continue
            if path.suffix.casefold() not in SOURCE_SUFFIXES or not SOURCE_NAME_PATTERN.search(path.name):
                continue
            size = safe_stat_size(path)
            if size is None or size > MAX_SOURCE_FILE_BYTES or source_bytes + size > MAX_SOURCE_TOTAL_BYTES:
                continue
            source_bytes += size
            source_paths.add(path.resolve())
    except OSError:
        pass
    return sorted(json_paths), sorted(source_paths)


def collect_config_facts(profile_dir: Path, side_root: Path) -> ConfigFacts:
    facts = ConfigFacts()
    json_paths, source_paths = discover_config_files(profile_dir, side_root)
    for path in json_paths:
        collect_json_config(path, facts)
    for path in source_paths:
        collect_source_config(path, facts)
    return facts


def directory_rank_values(profile_dir: Path, side_root: Path) -> set[int]:
    values: set[int] = set()
    # A flattened export commonly is itself named rank_0.  Start at the
    # artifact directory, then walk only ancestors inside the declared side.
    current = profile_dir
    while ensure_within(current, side_root):
        for match in RANK_PATTERN.finditer(current.name):
            values.add(int(match.group(1)))
        if current.resolve() == side_root.resolve() or current.parent == current:
            break
        current = current.parent
    return values


def rank_contract(metadata_values: set[int], directory_values: set[int]) -> dict[str, Any]:
    metadata = sorted(metadata_values)
    directory = sorted(directory_values)
    conflict = bool(metadata and directory and set(metadata) != set(directory))
    if conflict or len(metadata) > 1 or (not metadata and len(directory) > 1):
        return {
            "rank_status": CONFLICT,
            "rank_id": None,
            "metadata_rank_values": metadata,
            "directory_rank_values": directory,
            "rank_conflict": True,
        }
    if len(metadata) == 1:
        status = "metadata"
        rank_id: int | None = metadata[0]
    elif len(directory) == 1:
        status = "directory"
        rank_id = directory[0]
    else:
        status = UNKNOWN
        rank_id = None
    return {
        "rank_status": status,
        "rank_id": rank_id,
        "metadata_rank_values": metadata,
        "directory_rank_values": directory,
        "rank_conflict": False,
    }


def bridge_status(left: set[str], right: set[str]) -> str:
    return OBSERVED if left & right else "not-observed"


def issue(code: str, severity: str, message: str, evidence: str = "") -> dict[str, str]:
    return {"code": code, "severity": severity, "message": message, "evidence": evidence}


def supported_profile_contract(
    environment: str,
    role: str,
    side_root: Path,
    output_dir: Path,
) -> dict[str, Any]:
    trace_path = output_dir / "trace_view.json"
    operator_path = output_dir / "operator_details.csv"
    kernel_path = output_dir / "kernel_details.csv"
    analysis_dbs = sorted(path.resolve() for path in output_dir.glob("*.db") if path.is_file())
    has_text = any((output_dir / name).is_file() for name in TEXT_EXPORT_FILES)
    if not has_text:
        raw_msprof = discover_raw_msprof(output_dir)
        if raw_msprof:
            return unsupported_contract(
                environment,
                role,
                side_root,
                output_dir,
                "raw_msprof",
                "ASCEND_PROFILER_OUTPUT contains only raw msprof/PROF_* data; events were not counted",
                analysis_dbs,
            )
        if analysis_dbs:
            return unsupported_contract(
                environment,
                role,
                side_root,
                output_dir,
                "torchnpu_analysis_db_only",
                "analysis.db-only export is not readable by the text-export alignment parser",
                analysis_dbs,
            )

    trace = inspect_trace(trace_path if trace_path.is_file() else None)
    operator = inspect_csv(operator_path if operator_path.is_file() else None, "operator")
    kernel = inspect_csv(kernel_path if kernel_path.is_file() else None, "kernel")
    config = collect_config_facts(output_dir, side_root)
    rank = rank_contract(config.metadata_rank_values, directory_rank_values(output_dir, side_root))
    issues: list[dict[str, str]] = []

    if not trace_path.is_file():
        issues.append(issue("trace_view_missing", "error", "trace_view.json is missing; Host lanes are unknown"))
    elif trace.parse_status == "failure":
        issues.append(issue("trace_view_unreadable", "error", trace.parse_error, str(trace_path)))
    if not operator_path.is_file():
        issues.append(issue("operator_details_missing", "warning", "operator_details.csv is missing"))
    elif operator.parse_status == "failure":
        issues.append(issue("operator_details_unreadable", "error", operator.parse_error, str(operator_path)))
    if not kernel_path.is_file():
        issues.append(issue("kernel_details_missing", "warning", "kernel_details.csv is missing"))
    elif kernel.parse_status == "failure":
        issues.append(issue("kernel_details_unreadable", "error", kernel.parse_error, str(kernel_path)))
    if not config.profiler_info_paths:
        issues.append(issue("profiler_info_missing", "warning", "no readable profiler_info*.json was found"))
    if rank["rank_conflict"]:
        issues.append(
            issue(
                "rank_metadata_conflict",
                "error",
                "metadata rank and directory rank markers conflict; no rank was selected",
                compact_json(
                    {
                        "metadata": rank["metadata_rank_values"],
                        "directory": rank["directory_rank_values"],
                    }
                ),
            )
        )
    elif rank["rank_status"] == UNKNOWN:
        issues.append(issue("rank_unknown", "warning", "global rank cannot be recovered without guessing"))

    host_count: int | None = trace.host_operator_count if trace.parse_status == "success" else None
    kernel_count = kernel.row_count if kernel.parse_status == "success" else None
    kernel_observed = trace.kernel_event_count + (kernel_count or 0)
    if trace.parse_status == "success" and trace.host_operator_count == 0:
        issues.append(issue("host_operator_not_observed", "warning", "no confirmed Host PyTorch operator was observed"))
    if kernel_observed == 0 and (trace.parse_status == "success" or kernel.parse_status == "success"):
        issues.append(issue("kernel_not_observed", "warning", "no NPU Kernel row/event was observed"))
    missing_stream = trace.missing_stream_count + kernel.missing_stream_count
    if missing_stream:
        issues.append(
            issue(
                "kernel_stream_missing",
                "error",
                f"{missing_stream} Kernel row/event(s) lack explicit Stream ID evidence",
            )
        )
    if kernel.parse_status == "success" and kernel.row_count and not kernel.start_field:
        issues.append(
            issue(
                "kernel_start_field_unknown",
                "error",
                "kernel_details.csv has rows but no recognized Start Time(us) field",
                compact_json(kernel.headers),
            )
        )

    activity_cpu = config.resolved("activities_cpu")
    activity_npu = config.resolved("activities_npu")
    for field_name, value in (("activities_cpu", activity_cpu), ("activities_npu", activity_npu)):
        if value == UNKNOWN:
            issues.append(
                issue(
                    f"{field_name}_unknown",
                    "warning",
                    f"{field_name} is unknown: events are not used to guess profiler activity configuration",
                )
            )
        elif value == CONFLICT:
            issues.append(issue(f"{field_name}_conflict", "error", f"conflicting {field_name} evidence"))

    def observed_setting(field_name: str, observed: bool) -> str:
        configured = config.resolved(field_name)
        if configured != UNKNOWN:
            return configured
        return OBSERVED if observed else UNKNOWN

    record_shapes = observed_setting(
        "record_shapes", trace.input_dims_observed or operator.shape_observed
    )
    with_stack = observed_setting("with_stack", trace.call_stack_observed or operator.stack_observed)
    with_modules = observed_setting("with_modules", trace.module_hierarchy_observed)
    for field_name, value in (
        ("record_shapes", record_shapes),
        ("with_stack", with_stack),
        ("with_modules", with_modules),
    ):
        if value == UNKNOWN:
            issues.append(issue(f"{field_name}_unknown", "warning", f"{field_name} evidence is unknown"))
        elif value == CONFLICT:
            issues.append(issue(f"{field_name}_conflict", "error", f"conflicting {field_name} evidence"))

    profiler_level = config.resolved("profiler_level")
    schedule = config.resolved("schedule")
    child_registration = config.resolved("child_thread_registration")
    if profiler_level == UNKNOWN:
        issues.append(issue("profiler_level_unknown", "warning", "profiler level is unknown"))
    if schedule == UNKNOWN:
        issues.append(issue("schedule_unknown", "warning", "profiler schedule configuration is unknown"))
    if child_registration == UNKNOWN:
        issues.append(
            issue(
                "child_thread_registration_unknown",
                "warning",
                "no explicit enable_profiler_in_child_thread or metadata evidence was found",
            )
        )
    elif child_registration == CONFLICT:
        issues.append(issue("child_thread_registration_conflict", "error", "conflicting child-thread registration evidence"))

    step_ids = sorted(trace.step_ids | kernel.step_ids)
    collection_window = compact_json({"observed_step_ids": step_ids}) if step_ids else UNKNOWN
    blocking = any(item["severity"] in {"error", "warning"} for item in issues)
    status = "partial" if blocking else "complete"
    format_support = "full" if has_text else "degraded"
    status_reason = "collection contract verified" if status == "complete" else "; ".join(item["code"] for item in issues)

    return {
        "environment": environment,
        "role": role,
        "side_root": str(side_root),
        "profile_path": str(output_dir.resolve()),
        "profile_format": "torchnpu_integrated_text",
        "format_support": format_support,
        "status": status,
        "status_reason": status_reason,
        "supported_contract": SUPPORTED_FORMAT,
        "event_observation": "observed-from-supported-text-export",
        "trace_view_path": str(trace_path.resolve()) if trace_path.is_file() else "",
        "trace_parse_status": trace.parse_status,
        "operator_details_path": str(operator_path.resolve()) if operator_path.is_file() else "",
        "kernel_details_path": str(kernel_path.resolve()) if kernel_path.is_file() else "",
        "analysis_db_paths": [str(path) for path in analysis_dbs],
        "profiler_info_paths": sorted(config.profiler_info_paths),
        "trace_event_count": trace.total_events if trace.parse_status == "success" else None,
        "host_operator_count": host_count,
        "host_thread_count": len(trace.host_threads) if trace.parse_status == "success" else None,
        "acl_event_count": trace.acl_event_count if trace.parse_status == "success" else None,
        "runtime_event_count": trace.runtime_event_count if trace.parse_status == "success" else None,
        "kernel_trace_event_count": trace.kernel_event_count if trace.parse_status == "success" else None,
        "kernel_csv_event_count": kernel_count,
        "operator_details_row_count": operator.row_count if operator.parse_status == "success" else None,
        "kernel_start_field": kernel.start_field or UNKNOWN,
        "missing_stream_count": missing_stream,
        "host_kernel_bridge": bridge_status(trace.ids_by_layer["host"], trace.ids_by_layer["kernel"]),
        "acl_runtime_bridge": bridge_status(trace.ids_by_layer["acl"], trace.ids_by_layer["runtime"]),
        "runtime_kernel_bridge": bridge_status(trace.ids_by_layer["runtime"], trace.ids_by_layer["kernel"]),
        **rank,
        "activities_cpu": activity_cpu,
        "activities_npu": activity_npu,
        "activity_evidence": config.evidence(("activities_cpu", "activities_npu")),
        "record_shapes": record_shapes,
        "with_stack": with_stack,
        "with_modules": with_modules,
        "profiler_level": profiler_level,
        "schedule": schedule,
        "collection_window": collection_window,
        "child_thread_registration": child_registration,
        "config_evidence": config.evidence(),
        "issues": issues,
        "zero_event_claim": False,
    }


def unsupported_contract(
    environment: str,
    role: str,
    side_root: Path,
    profile_path: Path,
    profile_format: str,
    reason: str,
    analysis_dbs: Sequence[Path] = (),
) -> dict[str, Any]:
    return {
        "environment": environment,
        "role": role,
        "side_root": str(side_root),
        "profile_path": str(profile_path.resolve()),
        "profile_format": profile_format,
        "format_support": "unsupported",
        "status": "unsupported",
        "status_reason": reason,
        "supported_contract": SUPPORTED_FORMAT,
        "event_observation": "not-counted-unsupported-format",
        "trace_view_path": "",
        "trace_parse_status": "not-applicable",
        "operator_details_path": "",
        "kernel_details_path": "",
        "analysis_db_paths": [str(path.resolve()) for path in analysis_dbs],
        "profiler_info_paths": [],
        "trace_event_count": None,
        "host_operator_count": None,
        "host_thread_count": None,
        "acl_event_count": None,
        "runtime_event_count": None,
        "kernel_trace_event_count": None,
        "kernel_csv_event_count": None,
        "operator_details_row_count": None,
        "kernel_start_field": UNKNOWN,
        "missing_stream_count": None,
        "host_kernel_bridge": UNKNOWN,
        "acl_runtime_bridge": UNKNOWN,
        "runtime_kernel_bridge": UNKNOWN,
        "rank_status": UNKNOWN,
        "rank_id": None,
        "metadata_rank_values": [],
        "directory_rank_values": [],
        "rank_conflict": False,
        "activities_cpu": UNKNOWN,
        "activities_npu": UNKNOWN,
        "activity_evidence": [],
        "record_shapes": UNKNOWN,
        "with_stack": UNKNOWN,
        "with_modules": UNKNOWN,
        "profiler_level": UNKNOWN,
        "schedule": UNKNOWN,
        "collection_window": UNKNOWN,
        "child_thread_registration": UNKNOWN,
        "config_evidence": [],
        "issues": [issue("unsupported_format", "error", reason, str(profile_path.resolve()))],
        "zero_event_claim": False,
    }


def immediate_file_names(directory: Path) -> set[str]:
    try:
        return {
            child.name.casefold()
            for child in directory.iterdir()
            if child.is_file()
        }
    except OSError:
        return set()


def has_integrated_content_signature(directory: Path) -> bool:
    """Recognize one integrated export from files directly in *directory*.

    ``trace_view.json`` is mandatory.  At least one independent TorchNPU text
    artifact must accompany it: an operator/kernel details CSV or
    ``profiler_info*.json``.  Direct-child inspection is intentional: a parent
    is not promoted merely because a descendant contains an export.
    """

    names = immediate_file_names(directory)
    if "trace_view.json" not in names:
        return False
    return bool(
        {"operator_details.csv", "kernel_details.csv"} & names
        or any(name.startswith("profiler_info") and name.endswith(".json") for name in names)
    )


def is_raw_msprof_context(directory: Path, root: Path) -> bool:
    """Return true for PROF_*/MindStudio/msprof locations within *root*."""

    try:
        resolved = directory.resolve()
        boundary = root.resolve()
        relative = resolved.relative_to(boundary)
    except (OSError, ValueError):
        return True
    component_names = [boundary.name, *relative.parts]
    if any(
        RAW_PROF_DIRECTORY_PATTERN.match(name)
        or RAW_MSPROF_DIRECTORY_PATTERN.match(name)
        or name.casefold() in RAW_MSPROF_DIRECTORY_NAMES
        for name in component_names
    ):
        return True
    return any(RAW_MSPROF_JSON_PATTERN.match(name) for name in immediate_file_names(resolved))


def deduplicate_profile_directories(paths: Iterable[Path]) -> list[Path]:
    """Deduplicate recursively discovered exports, preferring the deepest leaf.

    Exact duplicates arise when an ASCEND_PROFILER_OUTPUT directory also
    satisfies the content signature.  If both an ancestor and descendant are
    candidates, the descendant is the concrete export boundary and the
    ancestor is suppressed so one physical rank export is not audited twice.
    """

    unique: set[Path] = set()
    for path in paths:
        try:
            unique.add(path.resolve())
        except OSError:
            continue
    kept: list[Path] = []
    for candidate in sorted(
        unique,
        key=lambda path: (len(path.parts), str(path).casefold()),
        reverse=True,
    ):
        if any(candidate != child and candidate in child.parents for child in kept):
            continue
        kept.append(candidate)
    return sorted(kept, key=lambda path: str(path).casefold())


def discover_integrated_outputs(root: Path) -> list[Path]:
    """Find named and flattened TorchNPU integrated text export directories."""

    candidates: list[Path] = []
    if (
        root.is_dir()
        and root.name.casefold() == INTEGRATED_DIRECTORY_NAME
        and not is_raw_msprof_context(root, root)
    ):
        candidates.append(root)
    try:
        for path in root.rglob("ASCEND_PROFILER_OUTPUT"):
            if len(candidates) >= MAX_DISCOVERED_FILES:
                break
            if (
                path.is_dir()
                and ensure_within(path, root)
                and not is_raw_msprof_context(path, root)
            ):
                candidates.append(path)
        for trace_path in root.rglob("trace_view.json"):
            if len(candidates) >= MAX_DISCOVERED_FILES:
                break
            directory = trace_path.parent
            if (
                trace_path.is_file()
                and ensure_within(trace_path, root)
                and not is_raw_msprof_context(directory, root)
                and has_integrated_content_signature(directory)
            ):
                candidates.append(directory)
    except OSError:
        pass
    return deduplicate_profile_directories(candidates)


def discover_raw_msprof(root: Path) -> list[Path]:
    candidates: list[Path] = []
    if root.is_dir() and (
        RAW_PROF_DIRECTORY_PATTERN.match(root.name)
        or RAW_MSPROF_DIRECTORY_PATTERN.match(root.name)
        or root.name.casefold() in RAW_MSPROF_DIRECTORY_NAMES
    ):
        candidates.append(root.resolve())
    try:
        for path in root.rglob("PROF_*"):
            if len(candidates) >= MAX_DISCOVERED_FILES:
                break
            if not path.is_dir() or not ensure_within(path, root):
                continue
            candidates.append(path.resolve())
        for path in root.rglob("mindstudio_profiler_output"):
            if len(candidates) >= MAX_DISCOVERED_FILES:
                break
            if path.is_dir() and ensure_within(path, root):
                candidates.append(path.resolve())
        for path in root.rglob("msprof_*"):
            if len(candidates) >= MAX_DISCOVERED_FILES:
                break
            if path.is_dir() and ensure_within(path, root):
                candidates.append(path.resolve())
        for path in root.rglob("msprof_*.json"):
            if len(candidates) >= MAX_DISCOVERED_FILES:
                break
            if path.is_file() and ensure_within(path, root):
                candidates.append(path.parent.resolve())
    except OSError:
        pass
    # For raw trees report the outer collection root once rather than every
    # nested MindStudio/msprof child.
    unique = sorted(set(candidates), key=lambda path: (len(path.parts), str(path).casefold()))
    result: list[Path] = []
    for candidate in unique:
        if any(candidate == parent or parent in candidate.parents for parent in result):
            continue
        result.append(candidate)
    return result


def discover_analysis_dbs(root: Path) -> list[Path]:
    result: list[Path] = []
    try:
        for path in root.rglob("analysis.db"):
            if len(result) >= MAX_DISCOVERED_FILES:
                break
            if path.is_file() and ensure_within(path, root):
                result.append(path.resolve())
    except OSError:
        pass
    return sorted(set(result))


def audit_side(root: Path, environment: str, role: str) -> dict[str, Any]:
    contracts: list[dict[str, Any]] = []
    integrated = discover_integrated_outputs(root)
    if integrated:
        for output_dir in integrated:
            contracts.append(supported_profile_contract(environment, role, root, output_dir))
    else:
        raw = discover_raw_msprof(root)
        databases = discover_analysis_dbs(root)
        if raw:
            for path in raw:
                contracts.append(
                    unsupported_contract(
                        environment,
                        role,
                        root,
                        path,
                        "raw_msprof",
                        "raw msprof/PROF_* input is not a TorchNPU-integrated text export; events were not counted",
                    )
                )
        elif databases:
            by_parent: dict[Path, list[Path]] = defaultdict(list)
            for path in databases:
                by_parent[path.parent].append(path)
            for parent, paths in sorted(by_parent.items()):
                contracts.append(
                    unsupported_contract(
                        environment,
                        role,
                        root,
                        parent,
                        "torchnpu_analysis_db_only",
                        "analysis.db-only input is unsupported by the text-export alignment parser; events were not counted",
                        paths,
                    )
                )
        else:
            contracts.append(
                unsupported_contract(
                    environment,
                    role,
                    root,
                    root,
                    "unrecognized",
                    "no TorchNPU-integrated text export (named or flattened) was found; events were not counted",
                )
            )
    statuses = {contract["status"] for contract in contracts}
    if statuses == {"complete"}:
        status = "complete"
    elif statuses == {"unsupported"}:
        status = "unsupported"
    else:
        status = "partial"
    return {
        "environment": environment,
        "role": role,
        "root": str(root),
        "status": status,
        "contract_count": len(contracts),
        "complete_count": sum(item["status"] == "complete" for item in contracts),
        "partial_count": sum(item["status"] == "partial" for item in contracts),
        "unsupported_count": sum(item["status"] == "unsupported" for item in contracts),
        "contracts": contracts,
    }


def csv_value(value: Any) -> Any:
    if value is None:
        return ""
    if isinstance(value, (list, dict, tuple, set)):
        return compact_json(list(value) if isinstance(value, set) else value)
    if isinstance(value, bool):
        return "true" if value else "false"
    return value


def write_outputs(output: Path, payload: dict[str, Any]) -> None:
    output.mkdir(parents=True, exist_ok=True)
    json_path = output / "collection_contract.json"
    csv_path = output / "collection_contract.csv"
    json_path.write_text(json.dumps(payload, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    contracts = [*payload["real"]["contracts"], *payload["sim"]["contracts"]]
    with csv_path.open("w", encoding="utf-8-sig", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(CSV_FIELDS), extrasaction="ignore")
        writer.writeheader()
        for contract in contracts:
            writer.writerow({key: csv_value(contract.get(key)) for key in CSV_FIELDS})


def validate_paths(real: Path, sim: Path, output: Path) -> tuple[Path, Path, Path]:
    real = real.resolve()
    sim = sim.resolve()
    output = output.resolve()
    if not real.is_dir():
        raise ValueError(f"real/reference root is not a directory: {real}")
    if not sim.is_dir():
        raise ValueError(f"sim/candidate root is not a directory: {sim}")
    if real == sim:
        raise ValueError("real/reference and sim/candidate roots must differ")
    if path_is_within(output, real) or path_is_within(output, sim):
        raise ValueError("output must be outside both profiling input roots")
    return real, sim, output


def preflight(real_root: Path, sim_root: Path, output: Path) -> dict[str, Any]:
    real_root, sim_root, output = validate_paths(real_root, sim_root, output)
    real = audit_side(real_root, "real/reference/真机", "reference")
    sim = audit_side(sim_root, "sim/candidate/仿真", "candidate")
    if "unsupported" in {real["status"], sim["status"]}:
        overall = "unsupported"
    elif real["status"] == sim["status"] == "complete":
        overall = "complete"
    else:
        overall = "partial"
    payload = {
        "schema_version": SCHEMA_VERSION,
        "status": overall,
        "supported_contract": SUPPORTED_FORMAT,
        "support_policy": {
            "fully_supported": (
                "TorchNPU-integrated text export in ASCEND_PROFILER_OUTPUT or an "
                "equivalent flattened content-signature directory"
            ),
            "unsupported": ["raw msprof/PROF_*", "analysis.db-only", "unrecognized input"],
            "activity_policy": "CPU/NPU activity settings require observable metadata or source config; event presence is never used to guess them",
            "unsupported_event_policy": "unsupported formats are not parsed and are never reported as zero events",
            "read_only_inputs": True,
        },
        "real": real,
        "sim": sim,
        "artifacts": ["collection_contract.csv", "collection_contract.json"],
    }
    write_outputs(output, payload)
    return payload


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description="Read-only Ascend collection-format preflight before structural alignment"
    )
    parser.add_argument("--real", required=True, type=Path, help="真机/reference profiling root")
    parser.add_argument("--sim", required=True, type=Path, help="仿真/candidate profiling root")
    parser.add_argument("--output", required=True, type=Path, help="output directory outside both inputs")
    return parser


def main(argv: Sequence[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    try:
        payload = preflight(args.real, args.sim, args.output)
    except (OSError, ValueError) as error:
        print(f"preflight failed: {error}", file=sys.stderr)
        return 2
    print(json.dumps(payload, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

# 推荐输入模板

```text
请用 $profiling-alignment-analysis 分析：

公共工作目录：<可选；目录内同时包含三个源码仓、两侧 profiling 与独立输出目录>
MindSpeed 源码根：<本地只读 checkout；模型 .sh 入口只从这里解析>
torch 源码根：<本地只读 checkout；默认标记为真机 reference 源码基线>
torch_npu 源码根：<本地只读 checkout；默认标记为真机 reference 源码基线>
可选仿真 torch 源码根：<只有确有另一份 checkout 且能绑定仿真实际运行时填写>
可选仿真 torch_npu 源码根：<同上>
真机 Profiling（reference）：<绝对目录>
仿真 Profiling（candidate）：<绝对目录>
分析输出目录：<公共目录下独立 output 子目录；不得位于任何源码或 profiling 内>
采集类型：<优先 TorchNPU integrated ASCEND_PROFILER_OUTPUT text export；若为 raw msprof/analysis.db 请明确>

模型/权重/配置：<标识或文件>
Workload：<batch、input/output length、请求/数据集、并发>
阶段：<prefill/decode/train/...>
Profiler schedule/窗口：<wait/warmup/active/repeat、step/request 标识>
Profiler 采集配置：<CPU/NPU activities、record_shapes、with_stack、with_modules、profiler level>
子线程算子：<是否使用 enable_profiler_in_child_thread 或等价注册；未知可留空>
并行拓扑：<world size、DP/TP/EP/PP/CP/DCP>

MindSpeed commit/tree：<优先完整 commit 与 tree hash>
torch commit/tree：<真机 reference 基线；优先完整 commit 与 tree hash>
torch_npu commit/tree：<真机 reference 基线；优先完整 commit、tree hash 与 build evidence>
模型入口：<一个或多个 .sh；绝对路径或相对 MindSpeed 源码根；也可给全是 .sh 的目录>
真机运行版本证据：<metadata/log/build ID>
仿真运行版本证据：<metadata/log/build ID>
本次候选 guard 所属源码组件：<可留空，由 stack/path 判定为 MindSpeed / torch / torch_npu / third-party patch>
真机 analyzed_source：<component；repository；完整 commit；完整 tree_hash；可选 build_id；status；证据>
仿真 analyzed_source：<component；repository；完整 commit；完整 tree_hash；可选 build_id；status；证据>
真机/仿真 torch_npu 版本与 commit/build：<guard 属于 torch_npu 时分别填写；这是关键源码证据>
Python 解释器与已安装 PyTorch 包版本：<可记录；差异固定为 informational/ignored，不要求对齐>

Rank 身份证据：<profiler rank_id/global_rank 或明确 rank_N 目录标记；禁止 directory order>

可选 runtime guard 证据：<CSV/JSONL>
可选明确 Thread 映射：<每 Rank 的 real pid/tid -> sim pid/tid 与依据>
在线 Perfetto 是否符合数据政策：<是/否；否时使用本地降级>
是否需要 Canvas 截图：<默认否>

交付要求：只把 profiling_alignment_report.md 作为面向用户的主交付；报告须逐 Rank、逐 lane、逐 divergence 自包含展开并内嵌 Python 行号快照；CSV/JSON/JSONL/辅助 HTML 只放 output/evidence/ 供机器追溯。
```

如果只给两个 Profiling 目录却没有明确真机/仿真角色，只询问角色，不运行比较。其余缺失项不必阻塞结构提取，但必须降低对应结论强度并列出最小补证。

公共目录只是路径容器，不是 Rank/角色证据。必须把三个源码根、两个 Profiling 根与输出根解析为互不覆盖的绝对路径。推荐布局：

```text
<work-root>/
  MindSpeed/
  torch/
  torch_npu/
  real-profiling/
  simulation-profiling/
  output/
    profiling_alignment_report.md
    evidence/
```

Prompt 中的相对 `.sh` 只从 `MindSpeed 源码根` 解析；越界、symlink/reparse 越出 repo 或入口不存在时 fail closed，不改从当前 shell 目录猜入口。候选代码按 owner 选择源码根：模型/训练逻辑用 MindSpeed，PyTorch/FSDP 核心用 torch，TorchNPU patch/lowering 用 torch_npu。

只要相应本地 checkout 已存在，就直接只读使用，不再 clone。只有 owner 源码缺失且用户给了 HTTPS Git URL 时，才运行 `prepare_source_checkout.py` 写入 `output/evidence/source-checkouts/`。没有固定完整 commit 时，远端 HEAD 只能用于代码导航，源码因果保持 unverified。不要执行仓库中的 Bash/Python/C++、Git hooks、submodule 或 LFS 内容。

单份 `torch/` 和 `torch_npu/` 默认只是真机 reference 源码基线。它们可以解释真机路径并提供候选代码，但不能伪称仿真实际运行绑定。只有显式提供仿真侧源码 checkout 与 runtime/build evidence 时，才声称双侧源码相同或不同。Python 解释器版本与已安装 PyTorch 包版本差异不参与结构可比性、控制流强度或默认修复建议；不得建议为了本分析去对齐它们。若实际 guard 属于 torch，则绑定准确 torch 源码；若属于 torch_npu，则逐侧 TorchNPU 源码/构建仍是关键证据。

把上述运行身份写入 `<output>/evidence/run_comparability_contract.json`；每侧至少包含：

```json
{
  "schema_version": 1,
  "source_roots": {
    "model": {
      "path": "<absolute MindSpeed checkout>",
      "role": "model-entry-and-owner",
      "binding_side": "shared",
      "status": "verified",
      "evidence": "<path/Git identity evidence>"
    },
    "pytorch": {
      "path": "<absolute torch checkout>",
      "role": "reference-source-baseline",
      "binding_side": "real/reference",
      "status": "verified",
      "evidence": "<path/Git identity evidence>"
    },
    "torch_npu": {
      "path": "<absolute torch_npu checkout>",
      "role": "reference-source-baseline",
      "binding_side": "real/reference",
      "status": "verified",
      "evidence": "<path/Git identity evidence>"
    }
  },
  "real": {
    "analyzed_source": {
      "component": "model|pytorch|torch_npu|dependency:<name>",
      "repository": "https://.../repo",
      "commit": "<full git commit>",
      "tree_hash": "<full git tree hash>",
      "build_id": "<optional runtime build id>",
      "status": "verified",
      "evidence": "<runtime/build evidence>"
    },
    "model_code": {"value": "repo@commit", "status": "verified", "evidence": "..."},
    "dependency_code": {"value": "dependency@commit/build", "status": "unknown", "evidence": "..."},
    "python_version": {"value": "...", "status": "verified", "evidence": "informational; ignored for structural gates"},
    "pytorch_version": {"value": "...", "status": "verified", "evidence": "informational; ignored for structural gates"},
    "torch_npu_version": {"value": "...", "status": "verified", "evidence": "..."},
    "cann_version": {"value": "...", "status": "verified", "evidence": "..."},
    "workload": {"value": "...", "status": "user-declared", "evidence": "..."},
    "profiler_schedule": {"value": "...", "status": "verified", "evidence": "..."},
    "parallel_topology": {"value": "...", "status": "verified", "evidence": "..."}
  },
  "sim": {"<same per-side fields>": "..."}
}
```

`source_roots` 是顶层机器契约，不放入 `real` 或 `sim`。三个 canonical owner 键固定为 `model`（显示名 MindSpeed）、`pytorch`（显示名 torch）和 `torch_npu`；不得用 `MindSpeed`、`torch` 等显示别名替代 JSON 键。每项必须有非空 `path/role/binding_side/status/evidence`。单份 `torch/` 与 `torch_npu/` 的 `binding_side` 固定为 `real/reference`；只有另有仿真 checkout 和运行绑定证据时，才另行登记仿真源码事实。完整文件顶层为 `schema_version`、`source_roots`、`real`、`sim`。未观测项写 `status=unknown`，不得省略后在报告中补猜。

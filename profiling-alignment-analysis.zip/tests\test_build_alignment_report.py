from __future__ import annotations

import csv
import importlib.util
import io
import json
import subprocess
import sys
import tempfile
import unittest
from contextlib import redirect_stdout
from pathlib import Path


SCRIPT = Path(__file__).resolve().parents[1] / "scripts" / "build_alignment_report.py"
SPEC = importlib.util.spec_from_file_location("build_alignment_report_test", SCRIPT)
assert SPEC and SPEC.loader
REPORT = importlib.util.module_from_spec(SPEC)
sys.modules[SPEC.name] = REPORT
SPEC.loader.exec_module(REPORT)
VALIDATOR_SCRIPT = SCRIPT.with_name("validate_alignment_report.py")
VALIDATOR_SPEC = importlib.util.spec_from_file_location(
    "validate_alignment_report_builder_test", VALIDATOR_SCRIPT
)
assert VALIDATOR_SPEC and VALIDATOR_SPEC.loader
VALIDATOR = importlib.util.module_from_spec(VALIDATOR_SPEC)
sys.modules[VALIDATOR_SPEC.name] = VALIDATOR
VALIDATOR_SPEC.loader.exec_module(VALIDATOR)


class AlignmentReportBuilderTests(unittest.TestCase):
    def setUp(self) -> None:
        self.temporary = tempfile.TemporaryDirectory(prefix="alignment-report-builder-test-")
        self.root = Path(self.temporary.name)
        self.paths = REPORT._write_self_test_fixture(self.root)

    def tearDown(self) -> None:
        self.temporary.cleanup()

    def build(self) -> dict[str, object]:
        return REPORT.build_report(
            self.paths["alignment"],
            self.paths["output"],
            preflight_dir=self.paths["preflight"],
            run_contract=self.paths["contract"],
            source_causality_dir=self.paths["source"],
            python_snapshots_dir=self.paths["snapshots"],
            perfetto_review_dir=self.paths["perfetto"],
        )

    def test_embedded_self_test_and_cli(self) -> None:
        with redirect_stdout(io.StringIO()) as stdout:
            self.assertEqual(REPORT.run_self_test(), 0)
        self.assertIn("self-test: ok", stdout.getvalue())

        completed = subprocess.run(
            [sys.executable, str(SCRIPT), "--self-test"],
            check=False,
            capture_output=True,
            text=True,
        )
        self.assertEqual(completed.returncode, 0, completed.stderr)
        self.assertIn("self-test: ok", completed.stdout)

    def test_builds_one_substantive_deterministic_markdown(self) -> None:
        report_root = self.paths["output"].parent
        before = {path.resolve() for path in report_root.rglob("*") if path.is_file()}

        first_result = self.build()
        first = self.paths["output"].read_bytes()
        second_result = self.build()
        second = self.paths["output"].read_bytes()
        after = {path.resolve() for path in report_root.rglob("*") if path.is_file()}
        text = second.decode("utf-8")

        self.assertEqual(first, second)
        self.assertEqual(first_result["sha256"], second_result["sha256"])
        self.assertEqual(after - before, {self.paths["output"].resolve()})
        self.assertEqual(first_result["artifact_count"], 1)
        self.assertEqual(first_result["source_owner_count"], 1)
        self.assertEqual(first_result["snapshot_owner_count"], 1)

        for required in (
            "## 1. 执行摘要",
            "### 1.1 源码 owner 身份",
            "## 2. Rank 与 Thread 覆盖",
            "### 2.2 全量 lane 清单",
            "## 3. Host 算子序列与首次分叉",
            "### 3.4 每个首分叉的受控对齐上下文",
            "## 4. Device 序列与 Host→Device",
            "## 5. 控制流与代码证据",
            "### 5.90 带原始行号的 Python HTML 代码快照",
            "## 6. Predicate tensor 与 producer",
            "## 7. Perfetto 内容复核",
            "## 8. 结论强度与替代解释",
            "## 9. 最小验证动作",
            "## 10. 附录与证据可追溯性",
            "rank-0000",
            "real-fw",
            "real-launch",
            "stream-7",
            "divergence_id=div-fw",
            "divergence_id=div-launch",
            "divergence_id=div-device",
            "alignment_column",
            "HostToDevice",
            "evidence_id=evidence-ms",
            "guard-MindSpeed",
            "use_new_path",
            "train.sh",
            "pretrain.py",
            "reference-baseline",
            "Perfetto 内容复核未执行",
        ):
            self.assertIn(required, text)

        self.assertNotIn("duration", text.casefold())
        self.assertNotIn("ignored-real-version", text)
        self.assertNotIn("ignored-sim-version", text)
        self.assertNotIn("canonical-sentinel-not-for-report", text)

    def test_embeds_each_snapshot_block_byte_for_byte(self) -> None:
        self.build()
        report = self.paths["output"].read_text(encoding="utf-8")
        markdown = (self.paths["snapshots"] / "python_guard_snapshots.md").read_text(
            encoding="utf-8"
        )
        blocks = REPORT.DETAILS_PATTERN.findall(markdown)
        self.assertEqual(len(blocks), 1)
        self.assertEqual(report.count(blocks[0]), 1)

    def test_flat_source_enabled_report_passes_formal_validator(self) -> None:
        self.build()
        result = VALIDATOR.validate(
            self.paths["output"], self.paths["alignment"], self.paths["source"],
            self.paths["contract"], self.paths["snapshots"], self.paths["perfetto"],
        )
        self.assertEqual(
            result["status"], "pass",
            json.dumps(result["findings"], ensure_ascii=False, indent=2),
        )

    def test_nested_or_multi_owner_source_fails_closed(self) -> None:
        source_path = self.paths["source"] / "control_flow_guard_candidates.csv"
        nested = self.paths["source"] / "torch_npu"
        nested.mkdir()
        source_path.replace(nested / source_path.name)

        with self.assertRaisesRegex(REPORT.ReportBuildError, "flat primary-owner"):
            self.build()
        self.assertFalse(self.paths["output"].exists())

    def test_promoted_candidate_without_snapshot_fails_closed(self) -> None:
        missing = self.paths["snapshots"]
        for path in list(missing.iterdir()):
            path.unlink()

        with self.assertRaisesRegex(REPORT.ReportBuildError, "no .*snapshot"):
            self.build()
        self.assertFalse(self.paths["output"].exists())

    def test_non_top_candidate_is_never_promoted_or_snapshot_required(self) -> None:
        source_path = self.paths["source"] / "control_flow_guard_candidates.csv"
        with source_path.open("r", encoding="utf-8-sig", newline="") as handle:
            reader = csv.DictReader(handle)
            fields = list(reader.fieldnames or [])
            rows = list(reader)
        second = dict(rows[0])
        second.update(
            evidence_id="evidence-rank2",
            candidate_rank="2",
            strength="已证实控制流分叉",
            guard_id="guard-rank2",
        )
        rows.append(second)
        with source_path.open("w", encoding="utf-8", newline="") as handle:
            writer = csv.DictWriter(handle, fieldnames=fields, lineterminator="\n")
            writer.writeheader()
            writer.writerows(rows)

        self.build()
        report = self.paths["output"].read_text(encoding="utf-8")
        self.assertIn("evidence_id=evidence-rank2", report)
        self.assertIn("未晋级静态备选", report)
        self.assertNotIn("evidence-rank2 |", report)

    def test_output_layout_and_filename_are_fail_closed(self) -> None:
        with self.assertRaisesRegex(REPORT.ReportBuildError, "named exactly"):
            REPORT.build_report(
                self.paths["alignment"],
                self.paths["output"].with_name("summary.md"),
            )

        unsafe = self.paths["alignment"] / REPORT.REPORT_NAME
        with self.assertRaisesRegex(REPORT.ReportBuildError, "outside evidence/alignment"):
            REPORT.build_report(self.paths["alignment"], unsafe)

        flat_alignment = self.root / "flat-alignment"
        flat_alignment.mkdir()
        with self.assertRaisesRegex(REPORT.ReportBuildError, "evidence/alignment layout"):
            REPORT.build_report(flat_alignment, self.root / REPORT.REPORT_NAME)

    def test_cli_requires_both_required_arguments(self) -> None:
        completed = subprocess.run(
            [sys.executable, str(SCRIPT), "--alignment-output", str(self.paths["alignment"])],
            check=False,
            capture_output=True,
            text=True,
        )
        self.assertEqual(completed.returncode, 2)
        self.assertIn("--alignment-output and --output are required", completed.stderr)


if __name__ == "__main__":
    unittest.main()

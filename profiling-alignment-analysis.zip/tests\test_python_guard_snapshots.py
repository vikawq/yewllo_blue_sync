from __future__ import annotations

import csv
import importlib.util
import io
import json
import os
import sys
import tempfile
import unittest
from contextlib import redirect_stdout
from pathlib import Path


SCRIPT = Path(__file__).resolve().parents[1] / "scripts" / "render_python_guard_snapshots.py"
SPEC = importlib.util.spec_from_file_location("render_python_guard_snapshots_test", SCRIPT)
assert SPEC and SPEC.loader
SNAPSHOTS = importlib.util.module_from_spec(SPEC)
sys.modules[SPEC.name] = SNAPSHOTS
SPEC.loader.exec_module(SNAPSHOTS)


class PythonGuardSnapshotTests(unittest.TestCase):
    def setUp(self) -> None:
        self.temporary = tempfile.TemporaryDirectory(prefix="python-guard-snapshot-test-")
        self.root = Path(self.temporary.name)

    def tearDown(self) -> None:
        self.temporary.cleanup()

    def fixture(self, name: str = "case", **kwargs: object) -> tuple[Path, Path, Path]:
        return SNAPSHOTS._write_self_test_fixture(self.root / name, **kwargs)

    def candidate_rows(self, source_dir: Path) -> list[dict[str, str]]:
        with (source_dir / SNAPSHOTS.CANDIDATE_NAME).open(
            "r", encoding="utf-8-sig", newline=""
        ) as handle:
            return list(csv.DictReader(handle))

    def rewrite_candidates(self, source_dir: Path, rows: list[dict[str, str]]) -> None:
        raw = SNAPSHOTS._fixture_csv_bytes(rows)
        (source_dir / SNAPSHOTS.CANDIDATE_NAME).write_bytes(raw)
        manifest_path = source_dir / SNAPSHOTS.MANIFEST_NAME
        manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
        manifest["artifact_integrity"][SNAPSHOTS.CANDIDATE_NAME] = {
            "sha256": SNAPSHOTS.sha256_bytes(raw),
            "bytes": len(raw),
            "nonempty": True,
        }
        manifest_path.write_text(json.dumps(manifest, ensure_ascii=False), encoding="utf-8")

    def rewrite_manifest(self, source_dir: Path, mutate: object) -> None:
        manifest_path = source_dir / SNAPSHOTS.MANIFEST_NAME
        manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
        mutate(manifest)
        manifest_path.write_text(json.dumps(manifest, ensure_ascii=False), encoding="utf-8")

    def assert_no_artifacts(self, output: Path) -> None:
        self.assertFalse(
            any((output / name).exists() for name in SNAPSHOTS.OUTPUT_NAMES),
            f"unexpected artifacts under {output}",
        )

    def test_embedded_self_test(self) -> None:
        with redirect_stdout(io.StringIO()) as stdout:
            result = SNAPSHOTS.run_self_test()
        self.assertEqual(result, 0)
        self.assertIn("self-test: ok", stdout.getvalue())

    def test_outputs_escape_html_and_preserve_original_lines_and_arms(self) -> None:
        repo, source_dir, output = self.fixture("valid")
        document = SNAPSHOTS.render_python_guard_snapshots(
            repo, source_dir, output, context_lines=2
        )

        self.assertEqual(set(SNAPSHOTS.OUTPUT_NAMES), {path.name for path in output.iterdir()})
        self.assertEqual(document["snapshot_count"], 1)
        snapshot = document["snapshots"][0]
        self.assertEqual(snapshot["candidate_strength"], "静态候选")
        self.assertEqual(snapshot["source_gates"]["analyzed_source_gate_passed"], "false")
        self.assertEqual(snapshot["snapshot_role"], SNAPSHOTS.REFERENCE_SNAPSHOT_ROLE)
        self.assertEqual(snapshot["real_run_binding_status"], "reference-baseline-only")
        self.assertEqual(snapshot["sim_run_binding_status"], "unknown")
        self.assertEqual(snapshot["source_binding_notice"], SNAPSHOTS.REFERENCE_BINDING_NOTICE)
        self.assertEqual(snapshot["real_arm"]["label"], SNAPSHOTS.REFERENCE_REAL_ARM_LABEL)
        self.assertEqual(snapshot["sim_arm"]["label"], SNAPSHOTS.REFERENCE_SIM_ARM_LABEL)
        self.assertEqual(snapshot["guard"]["range"], "3-6")
        self.assertEqual(snapshot["real_arm"]["range"], "4-4")
        self.assertEqual(snapshot["sim_arm"]["range"], "6-6")
        self.assertEqual(snapshot["snippet_start_line"], 1)
        self.assertEqual(snapshot["snippet_end_line"], 7)
        self.assertRegex(snapshot["source_file_sha256"], r"^[0-9a-f]{64}$")
        self.assertRegex(snapshot["snippet_sha256"], r"^[0-9a-f]{64}$")

        lines = {row["line_number"]: row for row in snapshot["lines"]}
        self.assertEqual(sorted(lines), [1, 2, 3, 4, 5, 6, 7])
        self.assertEqual(lines[1]["css_class"], "line-context")
        self.assertEqual(lines[3]["css_class"], "line-guard")
        self.assertEqual(lines[4]["css_class"], "line-guard line-real-arm")
        self.assertEqual(lines[4]["line_role"], "guard+real-arm")
        self.assertEqual(lines[6]["css_class"], "line-guard line-sim-arm")
        self.assertEqual(lines[6]["line_role"], "guard+sim-arm")
        for row in lines.values():
            self.assertEqual(row["path"], "model.py")
            self.assertIn("<img", row["symbol"])
            self.assertEqual(row["guard_range"], "3-6")
            self.assertEqual(row["real_arm_range"], "4-4")
            self.assertEqual(row["sim_arm_range"], "6-6")

        html_text = (output / "python_guard_snapshots.html").read_text(encoding="utf-8")
        md_text = (output / "python_guard_snapshots.md").read_text(encoding="utf-8")
        for rendered in (html_text, md_text):
            lowered = rendered.casefold()
            self.assertNotIn("<script", lowered)
            self.assertNotIn("<style", lowered)
            self.assertNotIn("<link", lowered)
            self.assertNotIn("<img ", lowered)
            self.assertIn("&lt;script&gt;", rendered)
            self.assertIn("&lt;img src=x onerror=alert(1)&gt;", rendered)
            self.assertIn('<tr class="line-guard line-real-arm">', rendered)
            self.assertIn("<details open>", rendered)
            self.assertIn(SNAPSHOTS.REFERENCE_BINDING_NOTICE, rendered)
            self.assertIn(SNAPSHOTS.REFERENCE_REAL_ARM_LABEL, rendered)
            self.assertIn(SNAPSHOTS.REFERENCE_SIM_ARM_LABEL, rendered)

        with (output / "python_guard_snapshots.csv").open(
            "r", encoding="utf-8-sig", newline=""
        ) as handle:
            csv_rows = list(csv.DictReader(handle))
        self.assertEqual([int(row["line_number"]) for row in csv_rows], [1, 2, 3, 4, 5, 6, 7])
        self.assertEqual(csv_rows[3]["css_class"], "line-guard line-real-arm")
        self.assertEqual(csv_rows[5]["css_class"], "line-guard line-sim-arm")
        self.assertEqual(csv_rows[0]["source_file_sha256"], snapshot["source_file_sha256"])
        self.assertEqual(csv_rows[0]["snapshot_role"], SNAPSHOTS.REFERENCE_SNAPSHOT_ROLE)
        self.assertEqual(csv_rows[0]["sim_run_binding_status"], "unknown")
        self.assertEqual(csv_rows[0]["source_binding_notice"], SNAPSHOTS.REFERENCE_BINDING_NOTICE)

    def test_reference_only_torch_npu_checkout_never_claims_sim_execution(self) -> None:
        repo, source_dir, output = self.fixture("reference-torch-npu")
        rows = self.candidate_rows(source_dir)
        rows[0]["source_component"] = "torch_npu"
        rows[0]["analyzed_source_gate_passed"] = "false"
        rows[0]["dependency_source_gate_passed"] = "false"
        rows[0]["dependency_source_gate_field"] = "torch_npu_version"
        self.rewrite_candidates(source_dir, rows)

        def bind_reference_only(manifest: dict[str, object]) -> None:
            manifest["source_component"] = "torch_npu"
            run = manifest["run_comparability"]
            assert isinstance(run, dict)
            run.update(
                {
                    "status": "partial",
                    "analyzed_source_gate_passed": False,
                    "fields": {
                        "analyzed_source": {
                            "comparison": "unknown",
                            "real": {
                                "status": "verified",
                                "evidence": "real profiler metadata",
                                "component": "torch_npu",
                                "repository": manifest["repository"],
                                "commit": manifest["resolved_commit"],
                                "tree_hash": manifest["indexed_source_snapshot"]["tree_hash"],
                            },
                            "sim": {
                                "status": "unknown",
                                "evidence": "",
                                "component": "torch_npu",
                                "repository": "",
                                "commit": "",
                                "tree_hash": "",
                            },
                        }
                    },
                }
            )

        self.rewrite_manifest(source_dir, bind_reference_only)
        document = SNAPSHOTS.render_python_guard_snapshots(repo, source_dir, output)
        snapshot = document["snapshots"][0]
        self.assertEqual(snapshot["snapshot_role"], SNAPSHOTS.REFERENCE_SNAPSHOT_ROLE)
        self.assertEqual(snapshot["real_run_binding_status"], "verified-exact")
        self.assertEqual(snapshot["sim_run_binding_status"], "unknown")
        self.assertTrue(snapshot["source_binding_derivation"]["real_source_fact_exact"])
        self.assertFalse(snapshot["source_binding_derivation"]["sim_source_fact_exact"])
        self.assertEqual(snapshot["sim_arm"]["label"], SNAPSHOTS.REFERENCE_SIM_ARM_LABEL)

        rendered = (output / "python_guard_snapshots.md").read_text(encoding="utf-8")
        self.assertIn("真机 reference 源码基线；仿真运行绑定未知", rendered)
        self.assertIn("仿真观测对应候选 arm（该源码未绑定仿真运行）", rendered)
        self.assertNotIn(SNAPSHOTS.BILATERAL_BINDING_NOTICE, rendered)

    def test_verified_bilateral_source_uses_bilateral_arm_labels(self) -> None:
        repo, source_dir, output = self.fixture("bilateral")
        rows = self.candidate_rows(source_dir)
        rows[0]["source_component"] = "torch_npu"
        rows[0]["analyzed_source_gate_passed"] = "true"
        rows[0]["dependency_source_gate_passed"] = "true"
        rows[0]["dependency_source_gate_field"] = "torch_npu_version"
        self.rewrite_candidates(source_dir, rows)

        def bind_both_sides(manifest: dict[str, object]) -> None:
            manifest["source_component"] = "torch_npu"
            fact = {
                "status": "verified",
                "component": "torch_npu",
                "repository": manifest["repository"],
                "commit": manifest["resolved_commit"],
                "tree_hash": manifest["indexed_source_snapshot"]["tree_hash"],
            }
            run = manifest["run_comparability"]
            assert isinstance(run, dict)
            run.update(
                {
                    "status": "complete",
                    "analyzed_source_gate_passed": True,
                    "fields": {
                        "analyzed_source": {
                            "comparison": "verified-equal",
                            "real": {**fact, "evidence": "real profiler metadata"},
                            "sim": {**fact, "evidence": "sim profiler metadata"},
                        }
                    },
                }
            )

        self.rewrite_manifest(source_dir, bind_both_sides)
        document = SNAPSHOTS.render_python_guard_snapshots(repo, source_dir, output)
        snapshot = document["snapshots"][0]
        self.assertEqual(snapshot["snapshot_role"], SNAPSHOTS.BILATERAL_SNAPSHOT_ROLE)
        self.assertEqual(snapshot["real_run_binding_status"], "verified-exact")
        self.assertEqual(snapshot["sim_run_binding_status"], "verified-exact")
        self.assertEqual(snapshot["source_binding_notice"], SNAPSHOTS.BILATERAL_BINDING_NOTICE)
        self.assertEqual(snapshot["real_arm"]["label"], SNAPSHOTS.BILATERAL_REAL_ARM_LABEL)
        self.assertEqual(snapshot["sim_arm"]["label"], SNAPSHOTS.BILATERAL_SIM_ARM_LABEL)

        rendered = (output / "python_guard_snapshots.html").read_text(encoding="utf-8")
        self.assertIn(SNAPSHOTS.BILATERAL_BINDING_NOTICE, rendered)
        self.assertIn(SNAPSHOTS.BILATERAL_REAL_ARM_LABEL, rendered)
        self.assertIn(SNAPSHOTS.BILATERAL_SIM_ARM_LABEL, rendered)
        self.assertNotIn(SNAPSHOTS.REFERENCE_BINDING_NOTICE, rendered)

        with (output / "python_guard_snapshots.csv").open(
            "r", encoding="utf-8-sig", newline=""
        ) as handle:
            csv_rows = list(csv.DictReader(handle))
        self.assertEqual(csv_rows[0]["snapshot_role"], SNAPSHOTS.BILATERAL_SNAPSHOT_ROLE)
        self.assertEqual(csv_rows[0]["sim_run_binding_status"], "verified-exact")

    def test_explicit_evidence_id_is_union_with_rank_one(self) -> None:
        repo, source_dir, output = self.fixture("explicit")
        rows = self.candidate_rows(source_dir)
        second = dict(rows[0])
        second["evidence_id"] = "evidence-rank-2"
        second["candidate_rank"] = "2"
        second["guard_symbol"] = "forward.rank_two"
        self.rewrite_candidates(source_dir, [rows[0], second])

        document = SNAPSHOTS.render_python_guard_snapshots(
            repo,
            source_dir,
            output,
            evidence_ids=["evidence-rank-2"],
            context_lines=0,
        )
        self.assertEqual(document["snapshot_count"], 2)
        reasons = {row["evidence_id"]: row["selection_reason"] for row in document["snapshots"]}
        self.assertEqual(reasons[rows[0]["evidence_id"]], "candidate_rank=1")
        self.assertEqual(reasons["evidence-rank-2"], "selected_evidence_id")

    def test_out_of_root_and_non_python_paths_fail_closed(self) -> None:
        cases = [
            ("traversal", {"guard_path": "../outside.py"}, "unsafe path segment"),
            ("absolute", {"guard_path": "C:/outside.py"}, "relative repository path"),
            ("cpp", {"guard_path": "model.cpp", "source_suffix": ".cpp"}, "only accept .py"),
        ]
        for name, kwargs, expected in cases:
            with self.subTest(name=name):
                repo, source_dir, output = self.fixture(name, **kwargs)
                with self.assertRaisesRegex(SNAPSHOTS.SnapshotError, expected):
                    SNAPSHOTS.render_python_guard_snapshots(repo, source_dir, output)
                self.assert_no_artifacts(output)

    def test_missing_file_and_candidate_hash_conflict_fail_closed(self) -> None:
        missing_repo, missing_source, missing_output = self.fixture(
            "missing", guard_path="missing.py", create_source=False
        )
        with self.assertRaisesRegex(SNAPSHOTS.SnapshotError, "missing"):
            SNAPSHOTS.render_python_guard_snapshots(
                missing_repo, missing_source, missing_output
            )
        self.assert_no_artifacts(missing_output)

        repo, source_dir, output = self.fixture("hash-conflict")
        with (source_dir / SNAPSHOTS.CANDIDATE_NAME).open("ab") as handle:
            handle.write(b"\n")
        with self.assertRaisesRegex(SNAPSHOTS.SnapshotError, "SHA-256 conflict"):
            SNAPSHOTS.render_python_guard_snapshots(repo, source_dir, output)
        self.assert_no_artifacts(output)

    def test_manifest_candidate_identity_conflict_fails_closed(self) -> None:
        repo, source_dir, output = self.fixture("identity-conflict")
        rows = self.candidate_rows(source_dir)
        rows[0]["indexed_tree_hash"] = "d" * 40
        self.rewrite_candidates(source_dir, rows)
        with self.assertRaisesRegex(SNAPSHOTS.SnapshotError, "tree hash conflicts"):
            SNAPSHOTS.render_python_guard_snapshots(repo, source_dir, output)
        self.assert_no_artifacts(output)

    def test_out_of_bounds_lines_fail_closed(self) -> None:
        repo, source_dir, output = self.fixture("range")
        rows = self.candidate_rows(source_dir)
        rows[0]["guard_lines"] = "3-99"
        self.rewrite_candidates(source_dir, rows)
        with self.assertRaisesRegex(SNAPSHOTS.SnapshotError, "beyond"):
            SNAPSHOTS.render_python_guard_snapshots(repo, source_dir, output)
        self.assert_no_artifacts(output)

    def test_symlink_source_path_is_blocked_when_supported(self) -> None:
        repo, source_dir, output = self.fixture(
            "symlink", guard_path="linked/model.py", create_source=False
        )
        external = self.root / "external"
        external.mkdir()
        (external / "model.py").write_text(
            "def forward(x):\n\n    if x:\n        return 1\n    else:\n        return 0\n",
            encoding="utf-8",
        )
        try:
            os.symlink(external, repo / "linked", target_is_directory=True)
        except (OSError, NotImplementedError) as exc:
            self.skipTest(f"directory symlink creation unavailable: {exc}")
        with self.assertRaisesRegex(SNAPSHOTS.SnapshotError, "symlink"):
            SNAPSHOTS.render_python_guard_snapshots(repo, source_dir, output)
        self.assert_no_artifacts(output)

    def test_output_inside_repo_is_rejected(self) -> None:
        repo, source_dir, _ = self.fixture("output-scope")
        output = repo / "generated"
        with self.assertRaisesRegex(SNAPSHOTS.SnapshotError, "outside"):
            SNAPSHOTS.render_python_guard_snapshots(repo, source_dir, output)
        self.assert_no_artifacts(output)

    def test_missing_explicit_evidence_id_fails_closed(self) -> None:
        repo, source_dir, output = self.fixture("missing-id")
        with self.assertRaisesRegex(SNAPSHOTS.SnapshotError, "not found"):
            SNAPSHOTS.render_python_guard_snapshots(
                repo, source_dir, output, evidence_ids=["does-not-exist"]
            )
        self.assert_no_artifacts(output)


if __name__ == "__main__":
    unittest.main()

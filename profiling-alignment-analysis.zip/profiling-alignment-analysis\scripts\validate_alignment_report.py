#!/usr/bin/env python3
"""Validate a final profiling-alignment Markdown report against machine evidence.

The report is presentation, never an authority.  This gate reads the structural
artifacts emitted by ``align_profiles.py`` and, when available, the source
causality and run-comparability artifacts.  It rejects evidence upgrades that
cannot be reproduced from those artifacts.  It does not inspect or emit timing
or performance metrics.
"""

from __future__ import annotations

import argparse
import csv
import hashlib
import html
import io
import json
import re
import tempfile
import tokenize
import unicodedata
from dataclasses import dataclass, asdict
from pathlib import Path
from typing import Any, Iterable


SCHEMA_VERSION = 1
ALGORITHM_VERSION = "profiling-alignment-report-gate-v1"
CSV_FIELDS = [
    "severity", "code", "line", "message", "evidence", "remediation",
]
STRENGTH_LEVEL = {
    "静态候选": 0,
    "强关联推断": 1,
    "强关联控制流分叉": 1,
    "已证实控制流分叉": 2,
    "仿真计算错误已证实": 3,
}
STRENGTH_ALIASES = {
    "强关联控制流分歧": "强关联控制流分叉",
    "强关联控制流差异": "强关联控制流分叉",
    "强相关控制流分叉": "强关联控制流分叉",
    "强相关控制流分歧": "强关联控制流分叉",
    "强相关控制流差异": "强关联控制流分叉",
    "高置信控制流分叉": "强关联控制流分叉",
    "高置信控制流分歧": "强关联控制流分叉",
    "高置信控制流差异": "强关联控制流分叉",
    "已证实控制流分歧": "已证实控制流分叉",
    "已证实控制流差异": "已证实控制流分叉",
    "已确认控制流分叉": "已证实控制流分叉",
    "已确认控制流分歧": "已证实控制流分叉",
    "已确认控制流差异": "已证实控制流分叉",
    "控制流分叉已证实": "已证实控制流分叉",
    "控制流分歧已证实": "已证实控制流分叉",
    "控制流差异已证实": "已证实控制流分叉",
    "已确认仿真计算错误": "仿真计算错误已证实",
    "仿真计算错误已确认": "仿真计算错误已证实",
}
REPORT_STRENGTH_LEVEL = {
    **STRENGTH_LEVEL,
    **{alias: STRENGTH_LEVEL[canonical] for alias, canonical in STRENGTH_ALIASES.items()},
}
STRONG_LABELS = tuple(
    label for label, level in REPORT_STRENGTH_LEVEL.items() if level >= 1
)
PROMOTION_HINT_PATTERN = re.compile(
    r"(?:(?:强关联|强相关|高度关联|高置信|很可能|已证实|已确认|已确定|确认存在|确定存在)"
    r".{0,40}(?:控制流|分支|执行路径|算子(?:路线|路径)|仿真(?:tensor)?计算错误)|"
    r"(?:控制流|分支|执行路径|算子(?:路线|路径)|仿真(?:tensor)?计算错误)"
    r".{0,40}(?:强关联|强相关|高度关联|高置信|很可能|已证实|已确认|已确定|确认存在|确定存在))",
    re.I,
)
DIRECT_LINK_STATUSES = {"direct-id", "direct-flow"}
NEGATING_WORDS = (
    "不得", "不能", "不可", "禁止", "不应", "未声称", "未判定", "尚不能",
    "不足以", "不构成", "不支持", "不能认定", "不是强关联", "并非强关联",
    "not allowed", "must not", "cannot", "never", "not established",
)
SOURCE_REACHABILITY_WORDS = ("github", "gitcode", "源码", "source repo", "repository", "仓库")
UNREACHABLE_WORDS = ("不可达", "无法访问", "unreachable", "not reachable", "访问失败")


@dataclass(frozen=True)
class Finding:
    severity: str
    code: str
    line: int | str
    message: str
    evidence: str = ""
    remediation: str = ""


def clean(value: Any, limit: int = 4000) -> str:
    if value is None:
        return ""
    if isinstance(value, (dict, list, tuple)):
        value = json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"))
    text = str(value).replace("\r", "\\r").replace("\n", "\\n")
    return text if len(text) <= limit else text[: limit - 3] + "..."


def truthy(value: Any) -> bool:
    if isinstance(value, bool):
        return value
    return str(value).strip().casefold() in {"1", "true", "yes", "y", "是", "通过", "pass", "passed"}


def false_or_resolved(value: Any) -> bool:
    if isinstance(value, bool):
        return not value
    return str(value).strip().casefold() in {
        "", "0", "false", "no", "n", "否", "无", "none", "resolved", "not-observed",
    }


def is_negated(clause: str, anchor: str = "") -> bool:
    folded = clause.casefold()
    if anchor:
        compact = re.sub(r"\s+", "", folded)
        folded_anchor = re.sub(r"\s+", "", anchor.casefold())
        position = compact.find(folded_anchor)
        if position >= 0:
            folded = compact[max(0, position - 14) : position + len(folded_anchor) + 10]
    return any(word in folded for word in NEGATING_WORDS)


def identifier_in_text(text: str, identifier: str) -> bool:
    """Match a structured evidence token without accepting a longer ID prefix."""
    if not identifier:
        return False
    return bool(
        re.search(
            rf"(?<![A-Za-z0-9_-]){re.escape(identifier)}(?![A-Za-z0-9_-])",
            text,
        )
    )


def report_logical_records(lines: list[str]) -> list[dict[str, Any]]:
    """Return Markdown rows/headings or unbounded soft-wrapped prose paragraphs."""
    records: list[dict[str, Any]] = []
    index = 0
    while index < len(lines):
        if not lines[index].strip():
            index += 1
            continue
        start = index
        stripped = lines[index].lstrip()
        standalone = (
            stripped.startswith(("#", "- ", "* ", ">", "```", "~~~"))
            or bool(re.match(r"\d+[.)]\s", stripped))
            or "|" in lines[index]
        )
        parts = [lines[index]]
        index += 1
        if not standalone and not re.search(r"[。.!?！？；;]\s*$", parts[-1]):
            while index < len(lines) and lines[index].strip():
                following = lines[index]
                following_stripped = following.lstrip()
                if (
                    following_stripped.startswith(("#", "- ", "* ", ">", "```", "~~~"))
                    or bool(re.match(r"\d+[.)]\s", following_stripped))
                    or "|" in following
                ):
                    break
                parts.append(following)
                index += 1
                if re.search(r"[。.!?！？；;]\s*$", following):
                    break
        records.append(
            {"line": start + 1, "end_line": start + len(parts), "text": "\n".join(parts)}
        )
    return records


def environment_side(value: Any) -> str:
    normalized = str(value).casefold()
    if any(token in normalized for token in ("real", "reference", "真机")):
        return "real"
    if any(token in normalized for token in ("sim", "candidate", "仿真")):
        return "sim"
    return ""


def read_csv(path: Path) -> list[dict[str, str]]:
    if not path.is_file():
        return []
    with path.open("r", encoding="utf-8-sig", newline="") as handle:
        return list(csv.DictReader(handle))


def read_json(path: Path) -> Any:
    with path.open("r", encoding="utf-8-sig") as handle:
        return json.load(handle)


def read_jsonl(path: Path) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    if not path.is_file():
        return rows
    with path.open("r", encoding="utf-8-sig") as handle:
        for line_number, line in enumerate(handle, 1):
            if not line.strip():
                continue
            value = json.loads(line)
            if not isinstance(value, dict):
                raise ValueError(f"{path.name}:{line_number} 不是 JSON object")
            rows.append(value)
    return rows


def canonical_boundary(value: Any) -> str:
    return json.dumps(value, sort_keys=True, ensure_ascii=False, separators=(",", ":"))


def strong_boundary_evidence(row: dict[str, Any]) -> bool:
    boundaries = row.get("alignment_boundaries")
    if not isinstance(boundaries, dict) or not {"op", "metadata", "tree"}.issubset(boundaries):
        return False
    values = [boundaries.get(name) for name in ("op", "metadata", "tree")]
    if any(value is None for value in values):
        return False
    if len({canonical_boundary(value) for value in values}) != 1:
        return False
    anchor_gate = truthy(row.get("anchor_gate_passed")) or (
        int_or_zero(row.get("anchors_before")) >= 3 and int_or_zero(row.get("anchors_after")) >= 3
    )
    return all(
        (
            row.get("boundary_stability") == "stable",
            row.get("lane_match_status") == "matched",
            str(row.get("lane_match_confidence", "")).casefold() == "high",
            anchor_gate,
            truthy(row.get("nesting_gate_passed")),
            not truthy(row.get("repeated_anchor_ambiguous")),
            false_or_resolved(row.get("earlier_unresolved")),
        )
    )


def int_or_zero(value: Any) -> int:
    try:
        return int(str(value).strip())
    except (TypeError, ValueError):
        return 0


def rank_from_pair_id(value: str) -> int | None:
    match = re.fullmatch(r"rank-(\d+)", value.strip())
    return int(match.group(1)) if match else None


def line_context(lines: list[str], index: int, radius: int = 2) -> str:
    start = max(0, index - radius)
    end = min(len(lines), index + radius + 1)
    return "\n".join(lines[start:end])


def prose_lines_without_snapshot_blocks(
    lines: list[str], allowed_blocks: set[str] | None = None,
) -> list[str]:
    """Blank only exact renderer artifacts, preserving all report line numbers."""
    output = list(lines)
    allowed = allowed_blocks or set()
    index = 0
    while index < len(lines):
        if not re.search(r"<details\s+open>", lines[index], re.I):
            index += 1
            continue
        end = index
        while end < len(lines) and not re.search(r"</details>", lines[end], re.I):
            end += 1
        if end >= len(lines):
            index += 1
            continue
        block = "\n".join(lines[index : end + 1])
        if block in allowed:
            for cursor in range(index, end + 1):
                output[cursor] = ""
        index = end + 1
    return output


def redact_trusted_snapshot_code(
    value: str, trusted_blocks: set[str] | None = None,
) -> str:
    """Redact only source-code cell contents from exact trusted snapshots.

    Summary and metadata stay visible to all semantic claim/status scanners.  The
    full block allowlist is used separately only for the raw-HTML exemption.
    """
    output = value
    for block in trusted_blocks or set():
        redacted = re.sub(
            r"(<pre><code>)(.*?)(</code></pre>)",
            lambda match: (
                match.group(1)
                + preserve_only_newlines(match.group(2))
                + match.group(3)
            ),
            block,
            flags=re.I | re.S,
        )
        output = output.replace(block, redacted)
    return output


def preserve_only_newlines(value: str) -> str:
    return "".join("\n" for character in value if character == "\n")


def strip_html_comments(value: str) -> str:
    return re.sub(
        r"<!--[\s\S]*?(?:-->|$)",
        lambda match: preserve_only_newlines(match.group(0)),
        value,
    ).replace("-->", "")


def normalize_visible_markdown(value: str) -> str:
    """Normalize visible inline Markdown without executing/rendering HTML."""
    normalized = html.unescape(value)
    normalized = re.sub(r"!\[([^\]]*)\]\([^\n)]*\)", r"\1", normalized)
    normalized = re.sub(r"\[([^\]]+)\]\([^\n)]*\)", r"\1", normalized)
    normalized = re.sub(r"</?[A-Za-z][^>\n]*>", "", normalized)
    normalized = re.sub(r"[*~`]", "", normalized)
    normalized = re.sub(r"(?<=[\u3400-\u9fff])_+|_+(?=[\u3400-\u9fff])", "", normalized)
    return normalized


def markdown_cells(line: str) -> list[str]:
    if "|" not in line:
        return []
    return [cell.strip() for cell in line.strip().strip("|").split("|")]


def markdown_column_values(lines: list[str], header_token: str) -> list[str]:
    token = header_token.casefold()
    values: list[str] = []
    for index, line in enumerate(lines):
        cells = markdown_cells(line)
        positions = [i for i, cell in enumerate(cells) if token in cell.casefold()]
        if not positions:
            continue
        column = positions[0]
        cursor = index + 1
        if cursor < len(lines) and re.fullmatch(r"[|:\-\s]+", lines[cursor]):
            cursor += 1
        while cursor < len(lines):
            row = markdown_cells(lines[cursor])
            if not row or column >= len(row):
                break
            value = row[column].strip(" `")
            if value and not re.fullmatch(r"[:\-\s]+", value):
                values.append(value)
            cursor += 1
    return values


def strength_claims(lines: list[str]) -> list[dict[str, Any]]:
    claims: list[dict[str, Any]] = []
    records = report_logical_records(lines)
    seen: set[tuple[int, int, str, int | None]] = set()
    for record in records:
        record_text = record["text"]
        # A heading can itself assert a conclusion.  Clause-local negation avoids
        # letting an unrelated "不得" earlier on the line suppress a later claim.
        clauses = [part.strip() for part in re.split(r"[|。；;!?！？，,]", record_text) if part.strip()]
        for clause in clauses:
            compact = re.sub(r"\s+", "", clause)
            matches = [
                (label, level) for label, level in REPORT_STRENGTH_LEVEL.items()
                if label in compact
            ]
            noncanonical = False
            if matches:
                matched_label, level = max(matches, key=lambda item: (item[1], len(item[0])))
                canonical_label = STRENGTH_ALIASES.get(matched_label, matched_label)
                noncanonical = matched_label != canonical_label
            else:
                promotion_match = PROMOTION_HINT_PATTERN.search(compact)
                if not promotion_match:
                    continue
                matched_label = promotion_match.group(0)
                noncanonical = True
                if re.search(r"仿真(?:tensor)?计算错误", matched_label, re.I):
                    level = 3
                    canonical_label = "仿真计算错误已证实"
                elif re.search(r"已证实|已确认|已确定|确认存在|确定存在", matched_label, re.I):
                    level = 2
                    canonical_label = "已证实控制流分叉"
                else:
                    level = 1
                    canonical_label = "强关联控制流分叉"
            if is_negated(clause, matched_label):
                continue
            count: int | None = None
            cells = markdown_cells(record_text)
            if cells:
                for cell_index, cell in enumerate(cells):
                    if matched_label not in re.sub(r"\s+", "", cell):
                        continue
                    for later in cells[cell_index + 1 :]:
                        match = re.fullmatch(r"\s*(\d+)\s*(?:条|项|个)?\s*", later)
                        if match:
                            count = int(match.group(1))
                            break
                    break
            if count is None:
                count_match = re.search(
                    re.escape(matched_label) + r"\s*[:=：]?\s*(\d+)\s*(?:条|项|个)?",
                    compact,
                )
                if count_match:
                    count = int(count_match.group(1))
            if count == 0:
                continue
            key = (record["line"], record["end_line"], canonical_label, count)
            if key in seen:
                continue
            seen.add(key)
            claims.append(
                {
                    "line": record["line"],
                    "end_line": record["end_line"],
                    "text": record_text,
                    "clause": clause,
                    "label": canonical_label,
                    "matched_label": matched_label,
                    "level": level,
                    "count": count,
                    "noncanonical": noncanonical,
                }
            )
    return claims


def candidate_top_rows(rows: list[dict[str, str]]) -> list[dict[str, str]]:
    by_divergence: dict[str, dict[str, str]] = {}
    for row in rows:
        divergence_id = row.get("divergence_id", "")
        if not divergence_id:
            continue
        current = by_divergence.get(divergence_id)
        rank = int_or_zero(row.get("candidate_rank")) or 999999
        current_rank = int_or_zero(current.get("candidate_rank")) if current else 999999
        current_rank = current_rank or 999999
        if current is None or rank < current_rank:
            by_divergence[divergence_id] = row
    return list(by_divergence.values())


def actual_guard(row: dict[str, str]) -> bool:
    required = (
        "guard_id", "guard_path", "guard_symbol", "guard_lines", "guard_kind",
        "predicate_text", "predicate_ast_hash", "real_arm", "real_arm_lines",
        "sim_arm", "sim_arm_lines",
    )
    if not all(row.get(field, "").strip() for field in required):
        return False
    if not row.get("guard_path", "").replace("\\", "/").casefold().endswith(".py"):
        return False
    if row.get("real_arm") == row.get("sim_arm"):
        return False
    try:
        real_lines = json.loads(row.get("real_arm_lines", ""))
        sim_lines = json.loads(row.get("sim_arm_lines", ""))
    except json.JSONDecodeError:
        return False
    if not all(
        isinstance(value, list) and len(value) == 2
        and all(isinstance(item, int) and item > 0 for item in value)
        and value[0] <= value[1]
        for value in (real_lines, sim_lines)
    ):
        return False
    predicate = row.get("predicate_text", "").strip().casefold()
    return predicate not in {"condition", "条件", "unknown", "未知", "unverified"}


def candidate_references(context: str, candidates: list[dict[str, str]]) -> list[dict[str, str]]:
    matches: list[dict[str, str]] = []
    for row in candidates:
        # A divergence ID binds the structural window, not the source guard.  An
        # upgraded conclusion must cite an exact source evidence/guard token.
        identifiers = (row.get("evidence_id", ""), row.get("guard_id", ""))
        if any(identifier_in_text(context, identifier) for identifier in identifiers if identifier):
            matches.append(row)
    return matches


def candidate_reference(context: str, candidates: list[dict[str, str]]) -> dict[str, str] | None:
    matches = candidate_references(context, candidates)
    return matches[0] if len(matches) == 1 else None


def contract_entry(contract: dict[str, Any], side: str, field: str) -> tuple[Any, str, str]:
    section = contract.get(side, {})
    if not isinstance(section, dict):
        return None, "unknown", ""
    entry = section.get(field)
    if isinstance(entry, dict):
        if field == "analyzed_source":
            value = {
                "component": clean(entry.get("component", "")).casefold(),
                "repository": clean(entry.get("repository", "")),
                "commit": clean(entry.get("commit", "")).casefold(),
                "tree_hash": clean(entry.get("tree_hash", "")).casefold(),
                "build_id": clean(entry.get("build_id", "")),
            }
        else:
            value = entry.get("value")
        return value, str(entry.get("status", "unknown")), clean(entry.get("evidence", ""))
    if entry is None:
        return None, "unknown", ""
    return entry, "unknown", ""


def comparison_state(contract: dict[str, Any], field: str) -> str:
    comparisons = contract.get("comparisons", {})
    if not isinstance(comparisons, dict):
        return "unknown"
    value = comparisons.get(field)
    if isinstance(value, dict):
        value = value.get("comparison", value.get("result", value.get("status", value.get("value"))))
    folded = str(value or "unknown").strip().casefold()
    if folded in {"equal", "same", "verified-equal", "一致", "相同"}:
        return "equal"
    if folded in {"different", "conflict", "mismatch", "不同", "冲突"}:
        return "different"
    return "unknown"


def verified_equal(contract: dict[str, Any], field: str) -> tuple[bool, str]:
    real_value, real_status, real_evidence = contract_entry(contract, "real", field)
    sim_value, sim_status, sim_evidence = contract_entry(contract, "sim", field)
    statuses_ok = real_status.casefold() == "verified" and sim_status.casefold() == "verified"
    if field == "analyzed_source":
        required = ("component", "repository", "commit", "tree_hash")
        nonempty = all(real_value.get(key) and sim_value.get(key) for key in required)
    else:
        nonempty = real_value not in (None, "") and sim_value not in (None, "")
    values_equal = canonical_boundary(real_value) == canonical_boundary(sim_value) and nonempty
    evidence_ok = bool(real_evidence and sim_evidence)
    comparison = comparison_state(contract, field)
    if comparison == "different":
        values_equal = False
    elif comparison == "equal" and real_value is not None and sim_value is not None:
        values_equal = values_equal and True
    detail = (
        f"real(status={real_status},value={clean(real_value)},evidence={bool(real_evidence)}); "
        f"sim(status={sim_status},value={clean(sim_value)},evidence={bool(sim_evidence)}); "
        f"comparison={comparison}"
    )
    return statuses_ok and values_equal and evidence_ok, detail


def guard_owner_component(guard_path: str) -> str:
    path = guard_path.replace("\\", "/").casefold()
    if "torch_npu" in path or "_add_fsdp_patch" in path:
        return "torch_npu"
    if (
        path.startswith("torch/")
        or "/torch/" in path
        or path.startswith("torch/distributed/fsdp/")
        or "/torch/distributed/fsdp/" in path
        or path.startswith("torch/distributed/_composable/fsdp/")
        or "/torch/distributed/_composable/fsdp/" in path
        or path.startswith("_fsdp_")
        or "/_fsdp_" in path
    ):
        return "pytorch"
    if "site-packages" in path:
        return "dependency"
    return "unknown"


def candidate_owner_component(candidate: dict[str, str]) -> str:
    path_owner = guard_owner_component(candidate.get("guard_path", ""))
    if path_owner != "unknown":
        return path_owner
    declared = candidate.get("source_component", "").strip().casefold()
    if declared in {"model", "torch_npu", "pytorch"}:
        return declared
    if declared == "dependency" or declared.startswith("dependency:"):
        return "dependency"
    return "unknown"


def candidate_source_contract_gate(
    candidate: dict[str, str], contract: dict[str, Any]
) -> tuple[bool, str]:
    source_ok, detail = verified_equal(contract, "analyzed_source")
    if not source_ok:
        return False, detail
    real_source, _, _ = contract_entry(contract, "real", "analyzed_source")
    owner = candidate_owner_component(candidate)
    component = str(real_source.get("component", "")).casefold()
    owner_ok = component == owner or (owner == "dependency" and component.startswith("dependency:"))
    exact_candidate_snapshot = (
        candidate.get("source_component", "").casefold() == component
        and candidate.get("indexed_head_commit", "").casefold() == real_source.get("commit", "")
        and candidate.get("indexed_tree_hash", "").casefold() == real_source.get("tree_hash", "")
    )
    if not owner_ok or not exact_candidate_snapshot:
        return False, (
            f"owner={owner}; component={component}; candidate_component="
            f"{candidate.get('source_component')}; candidate_head={candidate.get('indexed_head_commit')}; "
            f"candidate_tree={candidate.get('indexed_tree_hash')}"
        )
    return True, detail


def parsed_json(value: Any, fallback: Any) -> Any:
    if isinstance(value, (dict, list)):
        return value
    try:
        return json.loads(str(value))
    except (TypeError, ValueError, json.JSONDecodeError):
        return fallback


def float_or_zero(value: Any) -> float:
    try:
        return float(str(value).strip())
    except (TypeError, ValueError):
        return 0.0


def independently_recomputed_candidate_level(
    candidate: dict[str, str], divergence: dict[str, Any]
) -> tuple[int, list[str]]:
    """Recompute promotion gates instead of trusting ``candidate.strength``."""
    failures: list[str] = []
    if not actual_guard(candidate):
        failures.append("not-a-valid-python-ast-guard")
    if not divergence:
        failures.append("missing-divergence")
        return 0, failures
    for field in ("divergence_id", "rank_pair_id", "thread_pair_id", "semantic_layer"):
        if str(candidate.get(field, "")) != str(divergence.get(field, "")):
            failures.append(f"candidate-divergence-{field}-mismatch")
    if candidate.get("semantic_layer") != "framework_op" or divergence.get("domain") != "host":
        failures.append("not-framework-host")
    if int_or_zero(candidate.get("candidate_rank")) != 1:
        failures.append("not-top-candidate")
    if not strong_boundary_evidence(divergence):
        failures.append("alignment-gates-failed")
    if not all(
        (
            candidate.get("boundary_stability") == divergence.get("boundary_stability") == "stable",
            truthy(candidate.get("lane_high_confidence")),
            truthy(candidate.get("anchor_gate_passed")),
            truthy(candidate.get("nesting_gate_passed")),
            not truthy(candidate.get("repeated_anchor_ambiguous")),
        )
    ):
        failures.append("candidate-alignment-fields-failed")
    fingerprint = parsed_json(candidate.get("branch_fingerprint"), {})
    if not isinstance(fingerprint, dict):
        fingerprint = {}
    coverage = float_or_zero(fingerprint.get("coverage"))
    precision = float_or_zero(fingerprint.get("precision"))
    if canonical_boundary(fingerprint.get("real_operators", [])) != canonical_boundary(
        divergence.get("real_operators", [])
    ) or canonical_boundary(fingerprint.get("sim_operators", [])) != canonical_boundary(
        divergence.get("sim_operators", [])
    ):
        failures.append("fingerprint-operators-mismatch")
    real_stack = int_or_zero(candidate.get("real_stack_binding_level"))
    sim_stack = int_or_zero(candidate.get("sim_stack_binding_level"))
    stack = min(real_stack, sim_stack)
    if int_or_zero(candidate.get("stack_binding_level")) != stack:
        failures.append("stack-binding-level-mismatch")
    entry = int_or_zero(candidate.get("entrypoint_binding_level"))
    launch_bound = entry > 0 or stack >= 2
    common = all(
        (
            not failures,
            candidate.get("runtime_binding") == "verified",
            truthy(candidate.get("analyzed_source_gate_passed")),
            truthy(candidate.get("dependency_source_gate_passed")),
            truthy(candidate.get("source_scan_complete")),
            stack >= 1,
            launch_bound,
            coverage >= 0.60,
            precision >= 0.70,
        )
    )
    if not common:
        if candidate.get("runtime_binding") != "verified":
            failures.append("runtime-binding-not-verified")
        if not truthy(candidate.get("analyzed_source_gate_passed")):
            failures.append("analyzed-source-gate-failed")
        if not truthy(candidate.get("dependency_source_gate_passed")):
            failures.append("dependency-source-gate-failed")
        if not truthy(candidate.get("source_scan_complete")):
            failures.append("source-scan-truncated")
        if stack < 1:
            failures.append("two-sided-stack-binding-insufficient")
        if not launch_bound:
            failures.append("entrypoint-or-line-stack-missing")
        if coverage < 0.60 or precision < 0.70:
            failures.append(f"fingerprint-threshold-failed:{coverage:.6f}/{precision:.6f}")
        return 0, sorted(set(failures))
    confirmed = all(
        (
            stack >= 2,
            coverage >= 0.80,
            precision >= 0.90,
            truthy(candidate.get("predicate_results_opposite")),
            truthy(candidate.get("direct_operand_values_observed")),
        )
    )
    return (2 if confirmed else 1), []


def validate_candidate_gate(
    findings: list[Finding],
    candidate: dict[str, str],
    claim_level: int,
    line_number: int | str,
    divergence_by_id: dict[str, dict[str, Any]],
    run_contract: dict[str, Any],
    source_manifest: dict[str, Any],
    run_contract_sha256: str,
) -> None:
    declared_level = STRENGTH_LEVEL.get(candidate.get("strength", ""), -1)
    divergence = divergence_by_id.get(candidate.get("divergence_id", ""), {})
    recomputed_level, recompute_failures = independently_recomputed_candidate_level(
        candidate, divergence
    )
    if declared_level > recomputed_level:
        add(
            findings, "error", "CANDIDATE_STRENGTH_NOT_REPRODUCIBLE", line_number,
            "candidate.strength 无法由 divergence/AST/fingerprint/双侧 stack 字段独立重算",
            {
                "declared": candidate.get("strength"),
                "recomputed_level": recomputed_level,
                "failures": recompute_failures,
                "evidence_id": candidate.get("evidence_id"),
            },
        )
    if claim_level > recomputed_level:
        add(
            findings, "error", "CLAIM_STRENGTH_EXCEEDS_EVIDENCE", line_number,
            "Markdown 结论强度高于独立重算的结构化证据", {
                "claim_level": claim_level, "candidate": candidate.get("strength"),
                "recomputed_level": recomputed_level, "failures": recompute_failures,
                "evidence_id": candidate.get("evidence_id"),
            }, "采用 candidate 的结构化强度或先补齐缺失证据。",
        )
    if candidate.get("runtime_binding", "") != "verified":
        add(
            findings, "error", "SOURCE_BINDING_UNVERIFIED", line_number,
            "Runtime/source binding 非 verified，不能写强关联/已证实控制流分叉", {
                "runtime_binding": candidate.get("runtime_binding"),
                "evidence_id": candidate.get("evidence_id"),
            },
        )
    if not actual_guard(candidate):
        add(
            findings, "error", "STACK_CALLSITE_IS_NOT_GUARD", line_number,
            "候选缺少实际 AST guard/predicate/arm 行范围；函数 stack/callsite 不能冒充 guard",
            candidate.get("evidence_id", ""),
        )
    if not strong_boundary_evidence(divergence):
        add(
            findings, "error", "CLAIM_ALIGNMENT_GATES_FAILED", line_number,
            "强度升级所依赖的 divergence 未通过三视图/lane/anchor/nesting 门禁",
            candidate.get("divergence_id", ""),
        )
    if run_contract:
        source_ok, source_detail = candidate_source_contract_gate(candidate, run_contract)
        if not source_ok or not truthy(candidate.get("analyzed_source_gate_passed")):
            add(
                findings, "error", "ANALYZED_SOURCE_NOT_VERIFIED_EQUAL", line_number,
                "实际 guard owning component/snapshot 未在两侧 verified-equal 且绑定本次索引",
                source_detail,
            )
        owner = candidate_owner_component(candidate)
        runtime_field = {
            "torch_npu": "torch_npu_version",
            "pytorch": "pytorch_version",
            "dependency": "dependency_code",
        }.get(owner)
        if runtime_field:
            runtime_ok, runtime_detail = verified_equal(run_contract, runtime_field)
            if not runtime_ok or not truthy(candidate.get("dependency_source_gate_passed")):
                add(
                    findings, "error", "DEPENDENCY_SOURCE_NOT_VERIFIED_EQUAL", line_number,
                    f"guard owner={owner}，但 {runtime_field} 未 verified-equal",
                    runtime_detail,
                )
    if source_manifest:
        snapshot = source_manifest.get("indexed_source_snapshot", {})
        manifest_contract = source_manifest.get("run_comparability", {})
        source_scan = source_manifest.get("source_scan", {})
        manifest_ok = all(
            (
                int_or_zero(source_manifest.get("schema_version")) >= 4,
                source_manifest.get("status") == "complete",
                source_manifest.get("promotion_status") == "eligible",
                isinstance(snapshot, dict) and snapshot.get("binding_status") == "verified",
                isinstance(manifest_contract, dict)
                and manifest_contract.get("sha256") == run_contract_sha256,
                candidate.get("run_contract_sha256") == run_contract_sha256,
                candidate.get("indexed_head_commit") == snapshot.get("head_commit"),
                candidate.get("indexed_tree_hash") == snapshot.get("tree_hash"),
                isinstance(source_scan, dict) and source_scan.get("truncated") is False,
                truthy(candidate.get("source_scan_complete")),
            )
        )
        if not manifest_ok:
            add(
                findings, "error", "SOURCE_MANIFEST_GATE_FAILED", line_number,
                "candidate/contract 未绑定本次 source_analysis_manifest 的 HEAD/tree/hash/promotion",
                {
                    "manifest_status": source_manifest.get("status"),
                    "promotion_status": source_manifest.get("promotion_status"),
                    "manifest_contract_sha": (
                        manifest_contract.get("sha256") if isinstance(manifest_contract, dict) else ""
                    ),
                    "actual_contract_sha": run_contract_sha256,
                    "candidate_contract_sha": candidate.get("run_contract_sha256"),
                    "source_scan": source_scan,
                },
            )


def add(
    findings: list[Finding], severity: str, code: str, line: int | str, message: str,
    evidence: Any = "", remediation: str = "",
) -> None:
    finding = Finding(severity, code, line, message, clean(evidence), remediation)
    if finding not in findings:
        findings.append(finding)


def file_sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def resolved_child(root: Path, value: Any) -> Path | None:
    try:
        path = Path(str(value)).resolve(strict=True)
        path.relative_to(root.resolve())
        return path
    except (OSError, ValueError):
        return None


def perfetto_job_key(row: dict[str, Any]) -> tuple[str, str, str]:
    output_dir = str(row.get("output_dir", ""))
    batch = str(row.get("batch", "") or (Path(output_dir).name if output_dir else ""))
    return str(row.get("rank_pair_id", "")), str(row.get("environment", "")), batch


def validate_perfetto_review(
    findings: list[Finding],
    review_dir: Path | None,
    report_lines: list[str],
    rank_pairs: list[dict[str, str]],
) -> dict[str, Any]:
    records = report_logical_records(report_lines)
    perfetto_records = [record for record in records if re.search(r"perfetto", record["text"], re.I)]
    complete_records = [
        record for record in perfetto_records
        if re.search(
            r"(?:(?:内容复核|manifest|html|text|sql|dom|页面)[^\n]{0,60}"
            r"(?:已完成|完成|complete|已读取|均已读|全部已读|已复核|成功加载)|"
            r"perfetto[^\n]{0,60}(?:复核成功|复核完成|已完成|status\s*[:=]\s*complete|\bcomplete\b))",
            record["text"], re.I,
        )
        and not re.search(r"未执行|not[- ]executed|未完成|partial|部分", record["text"], re.I)
    ]
    not_executed_records = [
        record for record in perfetto_records
        if re.search(r"未执行|not[- ]executed|未加载|没有执行", record["text"], re.I)
    ]
    partial_records = [
        record for record in perfetto_records
        if re.search(r"partial|部分(?:完成|复核)|未完成", record["text"], re.I)
    ]
    global_complete_records = [
        record for record in complete_records
        if re.search(
            r"perfetto\s*内容复核\s*(?:已完成|完成|[:：=]\s*complete)|"
            r"perfetto[^\n]{0,30}(?:全部|所有)[^\n]{0,30}(?:已读|已复核|完成)",
            record["text"], re.I,
        )
    ]
    report_state = (
        "conflict" if global_complete_records and not_executed_records
        else "partial" if complete_records and not_executed_records and partial_records
        else "conflict" if complete_records and not_executed_records
        else "complete" if complete_records
        else "not-executed" if not_executed_records
        else "partial" if partial_records
        else "missing"
    )
    if report_state == "missing":
        add(
            findings, "error", "PERFETTO_STATUS_MISSING", "",
            "主报告没有明确 Perfetto complete/partial/not-executed 状态", "",
        )
    if report_state == "conflict":
        add(
            findings, "error", "PERFETTO_STATUS_CONFLICT", "",
            "主报告同时声称 Perfetto 内容复核完成和未执行", [r["text"] for r in perfetto_records],
        )
    if review_dir is None:
        add(
            findings, "error", "PERFETTO_REVIEW_DIR_REQUIRED", "",
            "交付门禁必须提供 --perfetto-review-dir（包括未授权/降级场景）", report_state,
        )
        return {"report_state": report_state, "artifact_state": "missing"}
    review_dir = review_dir.resolve()
    required = {
        "batch_json": review_dir / "perfetto_batch_manifest.json",
        "batch_csv": review_dir / "perfetto_batch_manifest.csv",
        "content": review_dir / "perfetto_content_review.json",
    }
    missing = [name for name, path in required.items() if not path.is_file()]
    if missing:
        add(
            findings, "error", "PERFETTO_REVIEW_ARTIFACT_MISSING", "",
            "Perfetto batch/content-review 根产物不完整", missing,
        )
        return {"report_state": report_state, "artifact_state": "missing"}
    try:
        batch_raw = required["batch_json"].read_bytes()
        batch = json.loads(batch_raw.decode("utf-8-sig"))
        batch_csv_rows = read_csv(required["batch_csv"])
        content = read_json(required["content"])
        if not isinstance(batch, dict) or not isinstance(content, dict):
            raise ValueError("Perfetto manifest/content root must be objects")
    except (OSError, UnicodeError, ValueError, json.JSONDecodeError, csv.Error) as error:
        add(
            findings, "error", "PERFETTO_REVIEW_ARTIFACT_INVALID", "",
            "Perfetto batch/content-review 产物无法解析", error,
        )
        return {"report_state": report_state, "artifact_state": "invalid"}
    jobs = batch.get("jobs", [])
    if int_or_zero(batch.get("schema_version")) < 2 or not isinstance(jobs, list):
        add(
            findings, "error", "PERFETTO_REVIEW_ARTIFACT_INVALID", "",
            "perfetto_batch_manifest schema/jobs 无效", batch.get("schema_version"),
        )
        jobs = []
    if len(batch_csv_rows) != len(jobs):
        add(
            findings, "error", "PERFETTO_REVIEW_ARTIFACT_INVALID", "",
            "Perfetto batch CSV/JSON job 行数不一致", {
                "csv": len(batch_csv_rows), "json": len(jobs),
            },
        )
    expected_sides = {
        (row.get("rank_pair_id", ""), side)
        for row in rank_pairs for side in ("real", "sim")
        if row.get("rank_pair_id")
    }
    actual_sides = {
        (str(row.get("rank_pair_id", "")), str(row.get("environment", "")))
        for row in jobs if isinstance(row, dict)
    }
    if actual_sides != expected_sides:
        add(
            findings, "error", "PERFETTO_RANK_SIDE_COVERAGE", "",
            "Perfetto jobs 未精确覆盖每个 compared Rank 的 real/sim", {
                "expected": sorted(expected_sides), "actual": sorted(actual_sides),
            },
        )
    batch_sha = hashlib.sha256(batch_raw).hexdigest()
    content_status = str(content.get("status", ""))
    artifact_state = "partial"
    if report_state == "not-executed":
        legal_reason = str(batch.get("execution_block_reason", "")).strip()
        allowed_reason = bool(re.search(
            r"authoriz|data\s*policy|organization\s*policy|perfetto|network|browser|playwright|"
            r"automation|授权|数据政策|组织政策|网络|浏览器|自动化|依赖",
            legal_reason, re.I,
        ))
        jobs_not_executed = bool(jobs) and all(
            row.get("run_status") == "not-executed"
            and row.get("content_review_status") == "not-executed"
            for row in jobs if isinstance(row, dict)
        )
        reviewed_jobs = content.get("reviewed_jobs", [])
        reviewed_sides = {
            (str(row.get("rank_pair_id", "")), str(row.get("environment", "")))
            for row in reviewed_jobs if isinstance(row, dict) and row.get("status") == "not-executed"
        } if isinstance(reviewed_jobs, list) else set()
        reviewed_job_sides = sorted(
            (str(row.get("rank_pair_id", "")), str(row.get("environment", "")))
            for row in reviewed_jobs if isinstance(row, dict) and row.get("status") == "not-executed"
        ) if isinstance(reviewed_jobs, list) else []
        expected_job_sides = sorted(
            (str(row.get("rank_pair_id", "")), str(row.get("environment", "")))
            for row in jobs if isinstance(row, dict)
        )
        valid = all(
            (
                batch.get("status") == "partial",
                bool(legal_reason),
                allowed_reason,
                not any(word in legal_reason.casefold() for word in ("github", "gitcode", "源码仓", "source repo")),
                jobs_not_executed,
                int_or_zero(content.get("schema_version")) >= 1,
                content_status == "not-executed",
                content.get("reviewed_artifacts") == [],
                reviewed_sides == expected_sides,
                reviewed_job_sides == expected_job_sides,
                content.get("canvas_review") == "not-executed",
            )
        )
        if not valid:
            add(
                findings, "error", "PERFETTO_NOT_EXECUTED_CONTRACT_INVALID", "",
                "Perfetto 未执行声明没有标准化 batch/content-review 证据", {
                    "batch_status": batch.get("status"), "reason": legal_reason,
                    "jobs_not_executed": jobs_not_executed,
                    "content_status": content_status, "reviewed_sides": sorted(reviewed_sides),
                    "reviewed_job_sides": reviewed_job_sides,
                },
            )
        artifact_state = "not-executed" if valid else "invalid"
        return {"report_state": report_state, "artifact_state": artifact_state}

    if report_state != "complete":
        if content_status not in {"partial", "not-executed"}:
            add(
                findings, "error", "PERFETTO_STATUS_CONFLICT", "",
                "报告为 partial/unknown，但 content review 状态不一致", content_status,
            )
        return {"report_state": report_state, "artifact_state": "partial"}

    expected_sha = {
        (row.get("rank_pair_id", ""), side): row.get(f"{side}_trace_sha256", "").lower()
        for row in rank_pairs for side in ("real", "sim")
    }
    root_gates = all(
        (
            batch.get("status") == "complete",
            batch.get("online_authorized") is True,
            not batch.get("execution_block_reason"),
            batch.get("device_evidence") == "local-parser-only",
            batch.get("duration_metrics_emitted") is False,
        )
    )
    union_rows = batch.get("lane_batch_union", [])
    union_keys = {
        (str(row.get("rank_pair_id", "")), str(row.get("environment", "")))
        for row in union_rows if isinstance(row, dict) and row.get("complete") is True
    } if isinstance(union_rows, list) else set()
    independent_union_ok = True
    for pair_side in expected_sides:
        group = [
            row for row in jobs if isinstance(row, dict)
            and (str(row.get("rank_pair_id", "")), str(row.get("environment", ""))) == pair_side
        ]
        source_sets = [parsed_json(row.get("source_lane_keys_json"), []) for row in group]
        batch_keys = [
            str(key) for row in group for key in parsed_json(row.get("batch_lane_keys_json"), [])
        ]
        nonempty_sources = [list(map(str, values)) for values in source_sets if values]
        independent_union_ok = independent_union_ok and bool(nonempty_sources)
        independent_union_ok = independent_union_ok and all(
            values == nonempty_sources[0] for values in nonempty_sources
        )
        independent_union_ok = independent_union_ok and len(batch_keys) == len(set(batch_keys))
        independent_union_ok = independent_union_ok and set(batch_keys) == set(nonempty_sources[0])
    if not root_gates or union_keys != expected_sides or not independent_union_ok:
        add(
            findings, "error", "PERFETTO_LANE_UNION_INCOMPLETE", "",
            "Perfetto batch 根门禁或逐 Rank/side lane union 未完成", {
                "root_gates": root_gates, "union_keys": sorted(union_keys),
                "independent_union_ok": independent_union_ok,
            },
        )
    reviewed_jobs = content.get("reviewed_jobs", [])
    reviewed_by_key = {
        perfetto_job_key(row): row for row in reviewed_jobs if isinstance(row, dict)
    } if isinstance(reviewed_jobs, list) else {}
    methods = {str(value).casefold() for value in content.get("review_methods", [])}
    content_root_ok = all(
        (
            int_or_zero(content.get("schema_version")) >= 1,
            content_status == "complete",
            content.get("batch_manifest_sha256") == batch_sha,
            {"manifest", "html", "text", "sql", "browser-log"}.issubset(methods),
            isinstance(content.get("observations"), list) and bool(content.get("observations")),
            content.get("canvas_claims_made") is False or content.get("screenshot_reviewed") is True,
        )
    )
    canvas_report_claim = any(
        re.search(r"canvas|颜色|几何|轨道形状|热力图", record["text"], re.I)
        and not re.search(r"未评价|未查看|未复核|not reviewed", record["text"], re.I)
        for record in perfetto_records
    )
    if canvas_report_claim and not (
        content.get("screenshot_reviewed") is True and content.get("canvas_claims_made") is True
    ):
        add(
            findings, "error", "PERFETTO_CANVAS_CLAIM_UNSUPPORTED", "",
            "报告评价了 Perfetto Canvas，但 content review 没有确认实际查看截图", "",
        )
    if not content_root_ok:
        add(
            findings, "error", "PERFETTO_CONTENT_REVIEW_INCOMPLETE", "",
            "Perfetto content review 未绑定 batch hash、完整阅读方法、观察或 Canvas 门禁", {
                "status": content_status, "methods": sorted(methods),
                "batch_hash_match": content.get("batch_manifest_sha256") == batch_sha,
            },
        )
    trace_hash_cache: dict[str, str] = {}
    expected_query_ids = {
        "operator_counts", "track_inventory", "host_launch_context",
        "structural_sequence", "completeness_summary",
    }
    for job in jobs:
        if not isinstance(job, dict):
            continue
        key = perfetto_job_key(job)
        job_ok = all(
            (
                job.get("planned_status") == "ready",
                job.get("run_status") == "success",
                int_or_zero(job.get("return_code")) == 0,
                job.get("auto_artifact_gate") == "auto-artifacts-ready",
                job.get("lane_batch_union_complete") is True,
            )
        )
        renderer_manifest_path = resolved_child(review_dir, job.get("manifest_path", ""))
        renderer_manifest: dict[str, Any] = {}
        if renderer_manifest_path is None or not renderer_manifest_path.is_file():
            job_ok = False
        else:
            try:
                loaded = read_json(renderer_manifest_path)
                renderer_manifest = loaded if isinstance(loaded, dict) else {}
            except (OSError, ValueError, json.JSONDecodeError):
                job_ok = False
        output_dir = resolved_child(review_dir, job.get("output_dir", ""))
        artifact_paths: dict[str, Path | None] = {
            "manifest": renderer_manifest_path,
            "html": output_dir / "perfetto_ui_frame.html" if output_dir else None,
            "text": output_dir / "perfetto_ui_text.txt" if output_dir else None,
            "browser-log": output_dir / "perfetto_browser.log" if output_dir else None,
        }
        if (
            batch.get("screenshot_requested") is True
            or content.get("screenshot_reviewed") is True
            or content.get("canvas_claims_made") is True
        ):
            artifact_paths["screenshot"] = output_dir / "perfetto_ui.png" if output_dir else None
        perfetto = renderer_manifest.get("perfetto", {}) if renderer_manifest else {}
        network = perfetto.get("network_isolation", {}) if isinstance(perfetto, dict) else {}
        sql = renderer_manifest.get("sql", {}) if renderer_manifest else {}
        query_results = sql.get("query_results", []) if isinstance(sql, dict) else []
        query_ids = {str(row.get("query_id", "")) for row in query_results if isinstance(row, dict)}
        completeness = sql.get("completeness", {}) if isinstance(sql, dict) else {}
        renderer_gates = all(
            (
                int_or_zero(renderer_manifest.get("schema_version")) >= 3,
                renderer_manifest.get("status") == "success",
                perfetto.get("ui_origin") == "https://ui.perfetto.dev",
                perfetto.get("local_only") is True,
                perfetto.get("message_origin_enforced") is True,
                network.get("offline_before_trace_post") is True,
                network.get("service_worker_count_after_render") == 0,
                network.get("service_worker_guard_visible_in_perfetto_frame") is True,
                network.get("post_offline_successful_response_count") == 0,
                sql.get("duration_metrics_emitted") is False,
                sql.get("global_row_limit") is None,
                completeness.get("complete") is True,
                completeness.get("truncated") is False,
                expected_query_ids == query_ids,
                all(
                    row.get("completed") is True
                    and isinstance(row.get("row_count"), int)
                    and row.get("row_count") >= 0
                    and not row.get("error")
                    for row in query_results if isinstance(row, dict)
                ),
            )
        )
        pair_side = (key[0], key[1])
        trace_path = Path(str(job.get("trace_path", "")))
        actual_trace_sha = ""
        try:
            trace_key = str(trace_path.resolve(strict=True))
            if trace_key not in trace_hash_cache:
                trace_hash_cache[trace_key] = file_sha256(trace_path)
            actual_trace_sha = trace_hash_cache[trace_key]
        except OSError:
            pass
        sha_values = {
            expected_sha.get(pair_side, ""), str(job.get("expected_trace_sha256", "")).lower(),
            actual_trace_sha.lower(), str((renderer_manifest.get("trace", {}) or {}).get("sha256", "")).lower(),
        }
        sha_ok = len(sha_values) == 1 and "" not in sha_values
        batch_lane_keys = set(parsed_json(job.get("batch_lane_keys_json"), []))
        selection = renderer_manifest.get("selection", {}) if renderer_manifest else {}
        actual_lane_keys = {
            f"{row.get('pid')}/{row.get('tid')}" for row in selection.get("lanes", [])
            if isinstance(row, dict)
        } if isinstance(selection, dict) else set()
        lanes_ok = (
            selection.get("domain") == "host"
            and selection.get("device_evidence") == "local-parser-only"
            and batch_lane_keys == actual_lane_keys
            and bool(batch_lane_keys)
        )
        review_row = reviewed_by_key.get(key, {})
        reviewed_artifacts = {
            str(row.get("kind", "")): row
            for row in review_row.get("artifacts", []) if isinstance(row, dict)
        } if isinstance(review_row, dict) else {}
        review_ok = all(
            (
                review_row.get("status") == "complete",
                review_row.get("renderer_run_id") == renderer_manifest.get("run_id"),
                set(artifact_paths) == set(reviewed_artifacts),
            )
        )
        for kind, path in artifact_paths.items():
            entry = reviewed_artifacts.get(kind, {})
            if path is None or not path.is_file() or path.stat().st_size <= 0:
                review_ok = False
                continue
            if resolved_child(review_dir, entry.get("path", "")) != path:
                review_ok = False
            if int_or_zero(entry.get("bytes")) != path.stat().st_size:
                review_ok = False
            if str(entry.get("sha256", "")).lower() != file_sha256(path):
                review_ok = False
        if not job_ok or not renderer_gates or not sha_ok or not lanes_ok or not review_ok:
            add(
                findings, "error", "PERFETTO_JOB_GATE_FAILED", "",
                "Perfetto complete 声明存在未通过的逐 job 自动/离线/SQL/hash/content 门禁", {
                    "job": key, "job_ok": job_ok, "renderer_gates": renderer_gates,
                    "sha_ok": sha_ok, "lanes_ok": lanes_ok, "review_ok": review_ok,
                },
            )
    expected_job_keys = {perfetto_job_key(row) for row in jobs if isinstance(row, dict)}
    if (
        set(reviewed_by_key) != expected_job_keys
        or len(reviewed_by_key) != len(reviewed_jobs)
        or len(expected_job_keys) != len(jobs)
    ):
        add(
            findings, "error", "PERFETTO_CONTENT_REVIEW_INCOMPLETE", "",
            "content review 未逐 batch 精确覆盖全部 Perfetto jobs", {
                "expected": sorted(perfetto_job_key(row) for row in jobs if isinstance(row, dict)),
                "actual": sorted(reviewed_by_key),
            },
        )
    artifact_state = "complete" if not any(
        row.code.startswith("PERFETTO_") and row.severity == "error" for row in findings
    ) else "invalid"
    return {"report_state": report_state, "artifact_state": artifact_state}


def validate_python_snapshot_bundle(
    findings: list[Finding],
    snapshot_dir: Path | None,
    required_candidates: list[dict[str, str]],
    report_text: str,
    source_manifest: dict[str, Any],
    run_contract_sha256: str,
) -> set[str]:
    """Validate the complete renderer bundle before trusting any embedded block.

    The returned set is an allowlist of exact ``<details>`` blocks that may be
    removed from the report's prose view.  It is deliberately empty when there
    are no report candidates, or when *any* bundle/source/candidate check fails.
    """
    if not required_candidates:
        return set()
    initial_error_count = sum(row.severity == "error" for row in findings)
    if snapshot_dir is None:
        add(
            findings, "error", "PYTHON_SNAPSHOT_REQUIRED", "",
            "强关联/已证实结论缺少带原始行号的 Python guard HTML/Markdown 快照", "",
            "运行 render_python_guard_snapshots.py，并把对应 <details> 片段嵌入主报告。",
        )
        return set()
    snapshot_dir = snapshot_dir.resolve()
    paths = {
        suffix: snapshot_dir / f"python_guard_snapshots.{suffix}"
        for suffix in ("md", "html", "json", "csv")
    }
    missing = [path.name for path in paths.values() if not path.is_file()]
    if missing:
        add(
            findings, "error", "PYTHON_SNAPSHOT_ARTIFACT_MISSING", "",
            "Python guard 快照产物不完整", missing,
        )
        return set()
    try:
        markdown = paths["md"].read_text(encoding="utf-8-sig")
        html_document = paths["html"].read_text(encoding="utf-8-sig")
        document = read_json(paths["json"])
        csv_rows = read_csv(paths["csv"])
        if not isinstance(document, dict):
            raise ValueError("snapshot JSON root is not object")
    except (OSError, UnicodeError, ValueError, json.JSONDecodeError, csv.Error) as error:
        add(
            findings, "error", "PYTHON_SNAPSHOT_ARTIFACT_INVALID", "",
            "Python guard 快照产物无法解析", error,
        )
        return set()
    for name, markup in (("markdown", markdown), ("html", html_document)):
        if re.search(r"<\s*(?:script|style|link|iframe|object|embed|base|form)\b", markup, re.I):
            add(
                findings, "error", "PYTHON_SNAPSHOT_ACTIVE_HTML", "",
                f"{name} 快照含可执行/外部 HTML", "",
            )
        if re.search(r"<[^>]*\s(?:on[a-z0-9_-]+|href|src)\s*=", markup, re.I):
            add(
                findings, "error", "PYTHON_SNAPSHOT_ACTIVE_ATTRIBUTE", "",
                f"{name} 快照含事件处理器或外部资源属性", "",
            )
    if not all(
        (
            int_or_zero(document.get("schema_version")) >= 1,
            document.get("artifact_kind") == "python_guard_snapshots",
            document.get("status") == "complete",
        )
    ):
        add(
            findings, "error", "PYTHON_SNAPSHOT_SCHEMA_INVALID", "",
            "Python guard snapshot JSON schema/status 无效", {
                "schema_version": document.get("schema_version"),
                "artifact_kind": document.get("artifact_kind"),
                "status": document.get("status"),
            },
        )
    repository = document.get("repository", {})
    indexed = source_manifest.get("indexed_source_snapshot", {})
    if not isinstance(repository, dict) or not isinstance(indexed, dict) or not all(
        (
            repository.get("commit") == indexed.get("head_commit"),
            repository.get("tree_hash") == indexed.get("tree_hash"),
            repository.get("run_contract_sha256") == run_contract_sha256,
            repository.get("binding_status") == "verified",
        )
    ):
        add(
            findings, "error", "PYTHON_SNAPSHOT_IDENTITY_MISMATCH", "",
            "Python 快照未绑定本次 source manifest 的 commit/tree/run-contract", {
                "repository": repository, "indexed_source_snapshot": indexed,
                "run_contract_sha256": run_contract_sha256,
            },
        )
    snapshots = document.get("snapshots", [])
    if not isinstance(snapshots, list):
        snapshots = []
    snapshot_ids = [
        str(row.get("evidence_id", ""))
        for row in snapshots if isinstance(row, dict)
    ]
    snapshot_by_id = {
        str(row.get("evidence_id", "")): row
        for row in snapshots if isinstance(row, dict) and row.get("evidence_id")
    }
    csv_ids = {row.get("evidence_id", "") for row in csv_rows if row.get("evidence_id")}
    blocks = re.findall(r"<details\s+open>.*?</details>", markdown, flags=re.I | re.S)
    html_blocks = re.findall(r"<details\s+open>.*?</details>", html_document, flags=re.I | re.S)
    if (
        not re.search(r"<!doctype\s+html>", html_document, re.I)
        or "Content-Security-Policy" not in html_document
        or len(blocks) != len(snapshots)
        or html_blocks != blocks
    ):
        add(
            findings, "error", "PYTHON_SNAPSHOT_HTML_CONTENT_MISMATCH", "",
            "独立 HTML 未逐字包含 JSON/Markdown 对应的全部静态 guard 片段或缺少 CSP",
            {
                "json_snapshots": len(snapshots),
                "markdown_blocks": len(blocks),
                "html_blocks": len(html_blocks),
                "doctype": bool(re.search(r"<!doctype\s+html>", html_document, re.I)),
                "csp": "Content-Security-Policy" in html_document,
            },
            "重新运行 render_python_guard_snapshots.py；不得用空 HTML 或手工导出替换产物。",
        )
    if (
        int_or_zero(document.get("snapshot_count")) != len(snapshots)
        or any(not value for value in snapshot_ids)
        or len(set(snapshot_ids)) != len(snapshot_ids)
        or csv_ids != set(snapshot_ids)
    ):
        add(
            findings, "error", "PYTHON_SNAPSHOT_BUNDLE_INDEX_MISMATCH", "",
            "Python snapshot JSON/CSV 的完整 evidence 索引不一致或包含重复 ID", {
                "declared_snapshot_count": document.get("snapshot_count"),
                "json_ids": snapshot_ids,
                "csv_ids": sorted(csv_ids),
            },
        )
    normalized_report = report_text.replace("\r\n", "\n")
    repo_root_text = repository.get("repo_root", "") if isinstance(repository, dict) else ""
    repo_root = Path(repo_root_text).resolve() if repo_root_text else Path()
    verified_blocks: set[str] = set()
    for candidate in required_candidates:
        evidence_id = candidate.get("evidence_id", "")
        snapshot = snapshot_by_id.get(evidence_id)
        if not isinstance(snapshot, dict) or evidence_id not in csv_ids:
            add(
                findings, "error", "PYTHON_SNAPSHOT_EVIDENCE_MISSING", "",
                "升级结论缺少对应 evidence_id 的 Python 快照", evidence_id,
            )
            continue
        expected_ranges = {
            "guard": candidate.get("guard_lines", ""),
            "real": "-".join(str(value) for value in parsed_json(candidate.get("real_arm_lines"), [])),
            "sim": "-".join(str(value) for value in parsed_json(candidate.get("sim_arm_lines"), [])),
        }
        source_gates = snapshot.get("source_gates", {})
        expected_repository = str(
            source_manifest.get("repository")
            or indexed.get("remote")
            or source_manifest.get("repo_root")
            or ""
        ).strip()
        expected_repo_root_text = str(source_manifest.get("repo_root", "")).strip()
        try:
            expected_repo_root = str(Path(expected_repo_root_text).resolve(strict=True))
        except OSError:
            expected_repo_root = ""
        selection_reason = snapshot.get("selection_reason", "")
        identity_ok = all(
            (
                snapshot.get("evidence_id") == evidence_id,
                int_or_zero(snapshot.get("candidate_rank"))
                == int_or_zero(candidate.get("candidate_rank")),
                snapshot.get("divergence_id") == candidate.get("divergence_id"),
                snapshot.get("rank_pair_id") == candidate.get("rank_pair_id"),
                snapshot.get("thread_pair_id") == candidate.get("thread_pair_id"),
                snapshot.get("source_component") == candidate.get("source_component"),
                snapshot.get("path", "").replace("\\", "/")
                == candidate.get("guard_path", "").replace("\\", "/"),
                snapshot.get("symbol") == candidate.get("guard_symbol"),
                snapshot.get("candidate_strength") == candidate.get("strength"),
                selection_reason in {
                    "candidate_rank=1", "candidate_rank=1+selected_evidence_id",
                },
                snapshot.get("repository") == expected_repository,
                snapshot.get("repo_root") == expected_repo_root,
                snapshot.get("commit") == candidate.get("indexed_head_commit"),
                snapshot.get("tree_hash") == candidate.get("indexed_tree_hash"),
                snapshot.get("run_contract_sha256") == candidate.get("run_contract_sha256"),
                isinstance(source_gates, dict),
                isinstance(source_gates, dict)
                and source_gates.get("analyzed_source_gate_passed")
                == candidate.get("analyzed_source_gate_passed", ""),
                isinstance(source_gates, dict)
                and source_gates.get("dependency_source_gate_passed")
                == candidate.get("dependency_source_gate_passed", ""),
                isinstance(source_gates, dict)
                and source_gates.get("dependency_source_gate_field")
                == candidate.get("dependency_source_gate_field", ""),
                isinstance(snapshot.get("guard"), dict)
                and snapshot["guard"].get("range") == expected_ranges["guard"],
                isinstance(snapshot.get("real_arm"), dict)
                and snapshot["real_arm"].get("name") == candidate.get("real_arm")
                and snapshot["real_arm"].get("range") == expected_ranges["real"],
                isinstance(snapshot.get("sim_arm"), dict)
                and snapshot["sim_arm"].get("name") == candidate.get("sim_arm")
                and snapshot["sim_arm"].get("range") == expected_ranges["sim"],
            )
        )
        if not identity_ok:
            add(
                findings, "error", "PYTHON_SNAPSHOT_CANDIDATE_MISMATCH", "",
                "Python 快照与 guard candidate 的 rank/thread/path/arm/identity 不一致",
                evidence_id,
            )
            continue
        relative = Path(str(snapshot.get("path", "")))
        try:
            source_path = (repo_root / relative).resolve(strict=True)
            source_path.relative_to(repo_root)
            if relative.is_absolute() or ".." in relative.parts or source_path.suffix.casefold() != ".py":
                raise ValueError("unsafe or non-Python snapshot path")
            source_raw = source_path.read_bytes()
        except (OSError, ValueError) as error:
            add(
                findings, "error", "PYTHON_SNAPSHOT_SOURCE_INVALID", "",
                "Python 快照源码路径缺失、越界或不是 .py", {"evidence_id": evidence_id, "error": str(error)},
            )
            continue
        if hashlib.sha256(source_raw).hexdigest() != snapshot.get("source_file_sha256"):
            add(
                findings, "error", "PYTHON_SNAPSHOT_SOURCE_HASH_MISMATCH", "",
                "Python 快照 source SHA 与当前固定源码不一致", evidence_id,
            )
            continue
        start = int_or_zero(snapshot.get("snippet_start_line"))
        end = int_or_zero(snapshot.get("snippet_end_line"))
        raw_lines = source_raw.splitlines(keepends=True)
        if start < 1 or end < start or end > len(raw_lines):
            add(
                findings, "error", "PYTHON_SNAPSHOT_LINE_RANGE_INVALID", "",
                "Python 快照 snippet 行范围越界", {"evidence_id": evidence_id, "start": start, "end": end},
            )
            continue
        snippet_raw = b"".join(raw_lines[start - 1:end])
        if hashlib.sha256(snippet_raw).hexdigest() != snapshot.get("snippet_sha256"):
            add(
                findings, "error", "PYTHON_SNAPSHOT_SNIPPET_HASH_MISMATCH", "",
                "Python 快照 snippet SHA 与固定源码行范围不一致", evidence_id,
            )
            continue
        try:
            encoding, _ = tokenize.detect_encoding(io.BytesIO(source_raw).readline)
            text_lines = source_raw.decode(encoding).splitlines(keepends=True)
        except (SyntaxError, UnicodeError, LookupError) as error:
            add(
                findings, "error", "PYTHON_SNAPSHOT_SOURCE_INVALID", "",
                "Python 快照源码无法按声明编码解码", error,
            )
            continue
        rendered_lines = snapshot.get("lines", [])
        expected_numbers = list(range(start, end + 1))
        actual_numbers = [int_or_zero(row.get("line_number")) for row in rendered_lines] if isinstance(rendered_lines, list) else []
        codes_match = isinstance(rendered_lines, list) and all(
            isinstance(row, dict)
            and row.get("code") == text_lines[number - 1].rstrip("\r\n")
            and row.get("path") == snapshot.get("path")
            for row, number in zip(rendered_lines, expected_numbers)
        ) and len(rendered_lines) == len(expected_numbers)
        if actual_numbers != expected_numbers or not codes_match:
            add(
                findings, "error", "PYTHON_SNAPSHOT_LINES_NOT_ORIGINAL", "",
                "Python 快照行号/代码文本不是固定源码的原始逐行内容", evidence_id,
            )
            continue
        candidate_csv_rows = [
            row for row in csv_rows if row.get("evidence_id", "") == evidence_id
        ]
        csv_identity_fields = {
            "divergence_id": snapshot.get("divergence_id"),
            "rank_pair_id": snapshot.get("rank_pair_id"),
            "thread_pair_id": snapshot.get("thread_pair_id"),
            "candidate_strength": snapshot.get("candidate_strength"),
            "commit": snapshot.get("commit"),
            "tree_hash": snapshot.get("tree_hash"),
            "run_contract_sha256": snapshot.get("run_contract_sha256"),
            "path": snapshot.get("path"),
            "source_file_sha256": snapshot.get("source_file_sha256"),
            "snippet_sha256": snapshot.get("snippet_sha256"),
        }
        csv_matches = len(candidate_csv_rows) == len(rendered_lines) and all(
            all(row.get(field, "") == str(expected or "") for field, expected in csv_identity_fields.items())
            and int_or_zero(row.get("line_number")) == int_or_zero(rendered.get("line_number"))
            and row.get("line_role", "") == str(rendered.get("line_role", ""))
            and row.get("css_class", "") == str(rendered.get("css_class", ""))
            and row.get("code", "") == str(rendered.get("code", ""))
            for row, rendered in zip(candidate_csv_rows, rendered_lines)
        )
        if not csv_matches:
            add(
                findings, "error", "PYTHON_SNAPSHOT_CSV_CONTENT_MISMATCH", "",
                "Python snapshot CSV 未逐行、逐身份字段绑定 JSON/source", evidence_id,
            )
            continue
        escaped_id = html.escape(evidence_id, quote=True)
        matching_blocks = [block for block in blocks if f"<summary>{escaped_id} |" in block]
        if len(matching_blocks) != 1:
            add(
                findings, "error", "PYTHON_SNAPSHOT_MARKDOWN_BLOCK_MISSING", "",
                "snapshot Markdown 中没有唯一 evidence HTML block", evidence_id,
            )
            continue
        block = matching_blocks[0].replace("\r\n", "\n")
        try:
            from render_python_guard_snapshots import _snapshot_details

            expected_block = _snapshot_details(snapshot).replace("\r\n", "\n")
        except (ImportError, AttributeError, KeyError, TypeError, ValueError) as error:
            add(
                findings, "error", "PYTHON_SNAPSHOT_RENDER_REBUILD_FAILED", "",
                "无法用受信 renderer 从 JSON/source/candidate 重建 Python snapshot block", {
                    "evidence_id": evidence_id, "error": str(error),
                },
            )
            continue
        if block != expected_block:
            add(
                findings, "error", "PYTHON_SNAPSHOT_RENDER_MISMATCH", "",
                "Python snapshot whole <details> 不是 JSON/source/candidate 的确定性 renderer 输出", evidence_id,
                "禁止在 summary、metadata、line rows 或 closing markup 添加可见文本。",
            )
            continue
        if block not in normalized_report:
            add(
                findings, "error", "PYTHON_SNAPSHOT_NOT_EMBEDDED", "",
                "主 Markdown 未嵌入该 evidence_id 的完整静态 HTML 代码快照", evidence_id,
                "从 python_guard_snapshots.md 复制对应 <details>...</details> 原文。",
            )
            continue
        verified_blocks.add(block)

    final_error_count = sum(row.severity == "error" for row in findings)
    if (
        final_error_count != initial_error_count
        or len(verified_blocks) != len(required_candidates)
    ):
        return set()
    return verified_blocks


def validate(
    report: Path,
    alignment_output: Path,
    source_causality_dir: Path | None = None,
    run_contract_path: Path | None = None,
    python_snapshots_dir: Path | None = None,
    perfetto_review_dir: Path | None = None,
) -> dict[str, Any]:
    findings: list[Finding] = []
    report = report.resolve()
    alignment_output = alignment_output.resolve()
    source_causality_dir = source_causality_dir.resolve() if source_causality_dir else None
    run_contract_path = run_contract_path.resolve() if run_contract_path else None
    python_snapshots_dir = python_snapshots_dir.resolve() if python_snapshots_dir else None
    perfetto_review_dir = perfetto_review_dir.resolve() if perfetto_review_dir else None

    try:
        raw = report.read_bytes()
    except OSError as error:
        raw = b""
        add(findings, "error", "REPORT_UNREADABLE", "", "无法读取主报告", error)
    try:
        report_text = raw.decode("utf-8-sig")
    except UnicodeDecodeError as error:
        report_text = raw.decode("utf-8", errors="replace")
        add(findings, "error", "REPORT_NOT_UTF8", "", "主报告不是有效 UTF-8", error)

    # Discover promotion claims from the completely untrusted report view first.
    # In particular, do not read python_guard_snapshots.md to construct an
    # allowlist: an attacker-controlled details block must remain visible unless
    # the JSON/CSV/MD/HTML/source/candidate bundle passes every trust gate below.
    discovery_text = normalize_visible_markdown(
        "".join(
            character for character in strip_html_comments(report_text)
            if unicodedata.category(character) != "Cf"
        )
    )
    preliminary_candidates: list[dict[str, str]] = []
    preliminary_source_manifest: dict[str, Any] = {}
    preliminary_run_contract_sha256 = ""
    if source_causality_dir:
        preliminary_candidate_path = source_causality_dir / "control_flow_guard_candidates.csv"
        preliminary_manifest_path = source_causality_dir / "source_analysis_manifest.json"
        try:
            if preliminary_candidate_path.is_file():
                preliminary_candidates = read_csv(preliminary_candidate_path)
        except (OSError, UnicodeError, csv.Error):
            preliminary_candidates = []
        try:
            if preliminary_manifest_path.is_file():
                loaded_preliminary_manifest = read_json(preliminary_manifest_path)
                if isinstance(loaded_preliminary_manifest, dict):
                    preliminary_source_manifest = loaded_preliminary_manifest
        except (OSError, UnicodeError, ValueError, json.JSONDecodeError):
            preliminary_source_manifest = {}
    try:
        if run_contract_path and run_contract_path.is_file():
            preliminary_run_contract_sha256 = hashlib.sha256(
                run_contract_path.read_bytes()
            ).hexdigest()
    except OSError:
        preliminary_run_contract_sha256 = ""
    preliminary_top_candidates = candidate_top_rows(preliminary_candidates)
    preliminary_required_snapshot_candidates: dict[str, dict[str, str]] = {}
    for discovery_claim in strength_claims(discovery_text.splitlines()):
        if discovery_claim["level"] < 1:
            continue
        for candidate in candidate_references(
            str(discovery_claim["text"]), preliminary_top_candidates
        ):
            evidence_id = candidate.get("evidence_id", "")
            if evidence_id:
                preliminary_required_snapshot_candidates[evidence_id] = candidate
    allowed_snapshot_blocks = validate_python_snapshot_bundle(
        findings,
        python_snapshots_dir,
        list(preliminary_required_snapshot_candidates.values()),
        report_text,
        preliminary_source_manifest,
        preliminary_run_contract_sha256,
    )
    if re.search(r"<!--|-->", report_text):
        add(
            findings, "error", "REPORT_HTML_COMMENT_FORBIDDEN", "",
            "主报告禁止 HTML comment；隐藏文本不能参与结论、状态或 evidence 绑定", "",
        )
    comment_free = strip_html_comments(report_text)
    format_controls = [
        (offset, character) for offset, character in enumerate(comment_free)
        if unicodedata.category(character) == "Cf"
    ]
    for offset, character in format_controls:
        add(
            findings, "error", "FORMAT_CONTROL_CHARACTER", comment_free.count("\n", 0, offset) + 1,
            f"报告含禁止的 Unicode format control U+{ord(character):04X}",
            f"character_offset={offset}",
            "删除零宽/双向等隐藏格式字符，从原始 UTF-8 证据重新生成。",
        )
    visible_base = "".join(
        character for character in comment_free if unicodedata.category(character) != "Cf"
    )
    normalized_visible_base = "\n".join(visible_base.splitlines())
    prose_base_lines = prose_lines_without_snapshot_blocks(
        normalized_visible_base.splitlines(), allowed_snapshot_blocks
    )
    prose_base_text = "\n".join(prose_base_lines)
    if re.search(r"</?[A-Za-z][^>\n]*>", html.unescape(prose_base_text)):
        add(
            findings, "error", "REPORT_RAW_HTML_FORBIDDEN", "",
            "除已验证的 Python <details> 快照外，主报告 prose 禁止 raw HTML", "",
            "使用普通 Markdown；代码快照只能逐字复制 renderer 产物。",
        )
    # The whole-block allowlist exempts only trusted renderer HTML from the raw
    # HTML rule.  Semantic scanners retain summary/metadata/line annotations and
    # redact only the actual source-code cells, so metadata cannot hide a claim.
    semantic_base_text = redact_trusted_snapshot_code(
        normalized_visible_base, allowed_snapshot_blocks
    )
    prose_text = normalize_visible_markdown(semantic_base_text)
    lines = prose_text.splitlines()

    # C0 bytes are never repaired heuristically. Tabs, carriage returns, bell and
    # form-feed are especially likely to be accidental Python escape expansion.
    for offset, character in enumerate(report_text):
        codepoint = ord(character)
        windows_newline_cr = character == "\r" and offset + 1 < len(report_text) and report_text[offset + 1] == "\n"
        if ((0 <= codepoint <= 31 and character != "\n" and not windows_newline_cr) or codepoint == 127):
            line_number = report_text.count("\n", 0, offset) + 1
            add(
                findings, "error", "CONTROL_CHARACTER", line_number,
                f"报告含禁止的 C0/DEL 控制字符 U+{codepoint:04X}",
                f"character_offset={offset}",
                "回到原始 UTF-8 证据重新生成；不要猜测或自动替换转义字符。",
            )

    mandatory = (
        "reference = 真机",
        "candidate = 仿真",
        "本报告只分析算子结构、顺序、嵌套、Shape 与控制流；不分析耗时或性能。",
        "ts/dur 仅在解析器内部用于排序、B/E 配对、嵌套和 direct flow 端点恢复。",
    )
    for statement in mandatory:
        if statement not in prose_text:
            add(
                findings, "error", "MANDATORY_DECLARATION_MISSING", "",
                "报告开头缺少固定声明", statement,
                "按 report-contract.md 原样加入声明。",
            )

    required_paths = {
        "analysis_manifest.json": alignment_output / "analysis_manifest.json",
        "rank_pairs.csv": alignment_output / "rank_pairs.csv",
        "unpaired_ranks.csv": alignment_output / "unpaired_ranks.csv",
        "thread_pairs.csv": alignment_output / "thread_pairs.csv",
        "canonical_events.csv": alignment_output / "canonical_events.csv",
        "event_alignment.csv": alignment_output / "event_alignment.csv",
        "divergence_windows.jsonl": alignment_output / "divergence_windows.jsonl",
        "host_device_links.csv": alignment_output / "host_device_links.csv",
    }
    for name, path in required_paths.items():
        if not path.is_file():
            add(findings, "error", "ALIGNMENT_ARTIFACT_MISSING", "", f"缺少结构化产物 {name}", path)

    try:
        manifest = read_json(required_paths["analysis_manifest.json"]) if required_paths["analysis_manifest.json"].is_file() else {}
        if not isinstance(manifest, dict):
            raise ValueError("manifest root is not object")
    except (OSError, ValueError, json.JSONDecodeError) as error:
        manifest = {}
        add(findings, "error", "ALIGNMENT_ARTIFACT_INVALID", "", "analysis_manifest.json 无效", error)
    try:
        rank_pairs = read_csv(required_paths["rank_pairs.csv"])
        thread_pairs = read_csv(required_paths["thread_pairs.csv"])
        divergences = read_jsonl(required_paths["divergence_windows.jsonl"])
        links = read_csv(required_paths["host_device_links.csv"])
    except (OSError, ValueError, json.JSONDecodeError, csv.Error) as error:
        rank_pairs, thread_pairs, divergences, links = [], [], [], []
        add(findings, "error", "ALIGNMENT_ARTIFACT_INVALID", "", "结构化对齐产物无法解析", error)

    critical_alignment_names = set(required_paths) - {"analysis_manifest.json"}
    declared_alignment_artifacts = set(manifest.get("artifacts", [])) if isinstance(
        manifest.get("artifacts"), list
    ) else set()
    alignment_integrity = manifest.get("artifact_integrity", {})
    if int_or_zero(manifest.get("schema_version")) < 3:
        add(
            findings, "error", "ALIGNMENT_MANIFEST_SCHEMA_STALE", "",
            "alignment manifest 不支持逐产物完整性绑定", manifest.get("schema_version"),
        )
    if not critical_alignment_names.issubset(declared_alignment_artifacts) or not isinstance(
        alignment_integrity, dict
    ):
        add(
            findings, "error", "ALIGNMENT_ARTIFACT_SET_INCOMPLETE", "",
            "alignment manifest 未声明报告门禁所需的完整产物集合",
            sorted(critical_alignment_names - declared_alignment_artifacts),
        )
    for name in sorted(critical_alignment_names):
        path = required_paths[name]
        if not path.is_file():
            continue
        raw_artifact = path.read_bytes()
        record = alignment_integrity.get(name, {}) if isinstance(alignment_integrity, dict) else {}
        actual_sha = hashlib.sha256(raw_artifact).hexdigest()
        if not isinstance(record, dict) or (
            record.get("sha256") != actual_sha
            or int_or_zero(record.get("bytes")) != len(raw_artifact)
            or bool(record.get("nonempty")) != bool(raw_artifact)
        ):
            add(
                findings, "error", "ALIGNMENT_ARTIFACT_INTEGRITY_FAILED", "",
                f"对齐产物与 analysis manifest 的 hash/bytes 不一致: {name}",
                {"expected": record, "actual_sha256": actual_sha, "actual_bytes": len(raw_artifact)},
            )

    compared_ids = manifest.get("compared_rank_ids", []) if isinstance(manifest, dict) else []
    if not isinstance(compared_ids, list):
        compared_ids = []
    expected_pair_ids = [f"rank-{int(rank):04d}" for rank in compared_ids if str(rank).isdigit()]
    row_pair_ids = {row.get("rank_pair_id", "") for row in rank_pairs}
    for pair_id in expected_pair_ids:
        if pair_id not in row_pair_ids:
            add(
                findings, "error", "RANK_PAIR_EVIDENCE_MISSING", "",
                f"manifest 的 {pair_id} 不在 rank_pairs.csv", pair_id,
            )
        if pair_id not in prose_text:
            add(
                findings, "error", "REPORT_RANK_EVIDENCE_MISSING", "",
                f"报告没有 {pair_id} 的独立证据标识", pair_id,
                "为每个同号 Rank 写独立行，并引用 rank_pair_id。",
            )

    # Every inventory row needs a machine-identifiable mention. Matched rows use
    # thread_pair_id; union-only rows use the concrete environment-local lane ID.
    for row in thread_pairs:
        status = row.get("status", "")
        thread_pair_id = row.get("thread_pair_id", "")
        if status in {"matched", "matched-degraded"} and thread_pair_id and thread_pair_id not in prose_text:
            add(
                findings, "error", "REPORT_LANE_EVIDENCE_MISSING", "",
                "报告漏掉 matched lane 的独立证据行", thread_pair_id,
                "逐 lane 引用 thread_pair_id；不得用 main thread 或 Rank 范围汇总代替。",
            )
        elif status in {"ambiguous", "real-only", "sim-only"}:
            lane_id = row.get("real_lane_id") or row.get("sim_lane_id") or ""
            if lane_id and lane_id not in prose_text:
                add(
                    findings, "error", "REPORT_LANE_EVIDENCE_MISSING", "",
                    f"报告漏掉 {status} lane", lane_id,
                    "逐项列出 ambiguous/real-only/sim-only lane。",
                )

    divergence_by_id = {str(row.get("divergence_id", "")): row for row in divergences if row.get("divergence_id")}
    framework_divergences = [
        row for row in divergences
        if row.get("domain") == "host" and row.get("semantic_layer") == "framework_op"
    ]
    for row in framework_divergences:
        divergence_id = str(row.get("divergence_id", ""))
        if divergence_id and not identifier_in_text(prose_text, divergence_id):
            add(
                findings, "error", "REPORT_DIVERGENCE_EVIDENCE_MISSING", "",
                "报告没有逐 lane 引用 framework Host 首次分叉", divergence_id,
            )

    # A range summary is legal only after every Rank is independently reported and
    # its machine divergence signature is actually identical.
    range_pattern = re.compile(
        r"(?:rank\s*)?\d+\s*[-–—~至]\s*\d+[^\n]*(?:通用|共同模式|全部一致|common|same)", re.I
    )
    signatures_by_rank: dict[int, list[str]] = {}
    for row in framework_divergences:
        rank = rank_from_pair_id(str(row.get("rank_pair_id", "")))
        if rank is None:
            continue
        signature = canonical_boundary(
            {
                "real": row.get("real_operators", []), "sim": row.get("sim_operators", []),
                "real_calls": row.get("real_run_calls", []), "sim_calls": row.get("sim_run_calls", []),
                "boundary": row.get("alignment_boundaries", {}),
            }
        )
        signatures_by_rank.setdefault(rank, []).append(signature)
    independent_rank_evidence = all(
        identifier_in_text(prose_text, pair_id) for pair_id in expected_pair_ids
    )
    common_signatures = bool(signatures_by_rank) and len(
        {canonical_boundary(sorted(values)) for values in signatures_by_rank.values()}
    ) == 1 and set(signatures_by_rank) == {int(value) for value in compared_ids if str(value).isdigit()}
    for index, line in enumerate(lines):
        if range_pattern.search(line) and not (independent_rank_evidence and common_signatures):
            add(
                findings, "error", "RANK_RANGE_GENERALIZATION", index + 1,
                "Rank 范围被外推为共同结论，但逐 Rank 结构化证据不完整或不相同", line,
                "先逐 Rank/Thread 报告，再仅对完全相同的结构化 signature 添加摘要。",
            )

    for index, line in enumerate(lines):
        folded = line.casefold()
        if (
            "directory order" in folded
            or re.search(r"(?:按|依据|使用)?目录(?:顺序|枚举序号|枚举)", line)
        ) and not is_negated(line):
            add(
                findings, "error", "RANK_IDENTITY_DIRECTORY_ORDER", index + 1,
                "报告把目录顺序/枚举序号当成 Rank 身份证据", line,
                "只接受 profiler metadata 或明确 Rank 目录标记；冲突必须 unresolved。",
            )

    two_view_pattern = re.compile(
        r"(?:op[- ]?only|op\s*视图).*(?:op\+metadata|metadata\s*视图).*(?:两|2)\s*(?:个)?视图",
        re.I,
    )
    for index, line in enumerate(lines):
        context = line_context(lines, index, 1)
        if two_view_pattern.search(context) and re.search(r"stable|稳定", context, re.I):
            add(
                findings, "error", "BOUNDARY_TWO_VIEW_ONLY", index + 1,
                "仅凭 op-only 与 op+metadata 两视图声称边界稳定", context,
                "必须由 op-only、op+metadata、tree-aware 三视图得到同一边界。",
            )
        if re.search(r"(?:边界|boundary)[^\n]*(?:stable|稳定)", line, re.I):
            referenced = [
                row for key, row in divergence_by_id.items()
                if identifier_in_text(context, key)
            ]
            if not referenced:
                add(
                    findings, "error", "UNBOUND_STABILITY_CLAIM", index + 1,
                    "边界稳定声明未引用 divergence_id", line,
                    "引用 divergence_windows.jsonl 的 divergence_id 与三视图字段。",
                )
            for row in referenced:
                if not strong_boundary_evidence(row):
                    add(
                        findings, "error", "BOUNDARY_STABILITY_NOT_SUPPORTED", index + 1,
                        "报告的 stable 声明未通过三视图/lane/anchor/nesting 门禁",
                        {"divergence_id": row.get("divergence_id"), "alignment_boundaries": row.get("alignment_boundaries")},
                    )

    valid_links = [
        row for row in links
        if row.get("link_status") in DIRECT_LINK_STATUSES and truthy(row.get("causal_eligible"))
    ]
    for index, line in enumerate(lines):
        folded = line.casefold()
        if re.search(r"\b\d+\s*(?:streams?|lanes?)\b", folded) and re.search(
            r"(?:n\s*/?\s*a|unknown|未知)", folded
        ) and not is_negated(line):
            add(
                findings, "error", "UNKNOWN_STREAM_AS_LANE", index + 1,
                "N/A/unknown stream 被计入可比较 Device lane", line,
                "无 Stream ID 的 kernel 只保留 Rank 级 coverage。",
            )
        ratio = bool(re.search(r"(?:\b\d+(?:\.\d+)?\s*%|\b\d+\s*/\s*\d+\b|比例|ratio|=\s*\d+\.\d+)", line, re.I))
        aggregate = bool(re.search(r"(?:total|总(?:数|量|调用)|跨\s*rank|aggregate|kernel\s*count|launch\s*ops)", line, re.I))
        causal_words = bool(re.search(
            r"(?:暗示|说明|证明|强关联推断|imply|caus|控制流|额外.*工作负载|extra workload)",
            line, re.I,
        ))
        if (ratio or aggregate) and causal_words and not is_negated(line):
            add(
                findings, "error", "AGGREGATE_CAUSAL_INFERENCE", index + 1,
                "aggregate kernel/launch/calls 或比例被用作控制流、额外 workload 或跨层因果", line,
                "把总量降为 coverage 观察；因果必须引用逐 Rank/lane 首次分叉或 direct link。",
            )
        if re.search(r"采样[^\n]{0,40}(?:全部|所有).*事件|(?:全部|所有)[^\n]{0,40}事件[^\n]{0,20}采样", line):
            add(
                findings, "error", "SAMPLING_COVERAGE_CONTRADICTION", index + 1,
                "同一陈述混用“采样”和“全部事件”", line,
                "明确是全量逐 lane 解析，或标出采样范围并禁止外推。",
            )

    device_strong_lines: list[tuple[int, str]] = []
    # Device claims are validated after source-causality artifacts are loaded. A
    # global direct link is never sufficient: each claim must bind its own
    # divergence and both real/sim branch-device rows.

    for index, line in enumerate(lines):
        if not re.search(r"perfetto", line, re.I) or not re.search(
            r"未执行|not[- ]executed|未加载|没有执行", line, re.I
        ):
            continue
        context = line_context(lines, index, 2).casefold()
        if any(word in context for word in SOURCE_REACHABILITY_WORDS) and any(
            word in context for word in UNREACHABLE_WORDS
        ):
            add(
                findings, "error", "PERFETTO_REASON_SOURCE_REACHABILITY", index + 1,
                "Perfetto 未执行理由错误地依赖 GitHub/GitCode/源码仓可达性", line_context(lines, index, 2),
                "Perfetto 只可因数据政策、官方 UI 网络、浏览器或依赖状态降级；源码可达性另列。",
            )

    perfetto_review_status = validate_perfetto_review(
        findings, perfetto_review_dir, lines, rank_pairs
    )

    candidates: list[dict[str, str]] = []
    branch_device_rows: list[dict[str, str]] = []
    source_manifest: dict[str, Any] = {}
    if source_causality_dir:
        candidate_path = source_causality_dir / "control_flow_guard_candidates.csv"
        source_manifest_path = source_causality_dir / "source_analysis_manifest.json"
        if not candidate_path.is_file():
            add(
                findings, "error", "SOURCE_CAUSALITY_ARTIFACT_MISSING", "",
                "指定了 source-causality-dir，但缺少 control_flow_guard_candidates.csv", candidate_path,
            )
        else:
            try:
                candidates = read_csv(candidate_path)
            except (OSError, csv.Error) as error:
                add(findings, "error", "SOURCE_CAUSALITY_ARTIFACT_INVALID", "", "guard candidates CSV 无效", error)
        if not source_manifest_path.is_file():
            add(
                findings, "error", "SOURCE_CAUSALITY_ARTIFACT_MISSING", "",
                "指定了 source-causality-dir，但缺少 source_analysis_manifest.json",
                source_manifest_path,
            )
        else:
            try:
                loaded_manifest = read_json(source_manifest_path)
                if not isinstance(loaded_manifest, dict):
                    raise ValueError("source manifest root is not object")
                source_manifest = loaded_manifest
            except (OSError, ValueError, json.JSONDecodeError) as error:
                add(
                    findings, "error", "SOURCE_CAUSALITY_ARTIFACT_INVALID", "",
                    "source_analysis_manifest.json 无效", error,
                )
        required_candidate_fields = {
            "evidence_id", "candidate_rank", "divergence_id", "guard_id", "guard_kind",
            "predicate_ast_hash", "real_arm_lines", "sim_arm_lines", "runtime_binding",
            "analyzed_source_gate_passed", "dependency_source_gate_passed",
            "source_component", "run_contract_sha256", "indexed_head_commit",
            "indexed_tree_hash", "source_scan_complete", "strength",
        }
        for row_number, candidate in enumerate(candidates, 2):
            if not required_candidate_fields.issubset(candidate):
                add(
                    findings, "error", "SOURCE_CANDIDATE_SCHEMA_STALE", row_number,
                    "guard candidate schema 缺少当前 promotion gate 字段",
                    sorted(required_candidate_fields - set(candidate)),
                )
        expected_source_artifacts = {
            "control_flow_guard_candidates.csv", "control_flow_evidence.jsonl",
            "predicate_tensor_evidence.csv", "event_source_map.csv",
            "branch_device_evidence.csv", "source_evidence.csv",
            "source_entrypoint_chain.csv", "source_analysis_issues.csv",
        }
        declared_artifacts = set(source_manifest.get("artifacts", [])) if isinstance(
            source_manifest.get("artifacts"), list
        ) else set()
        integrity = source_manifest.get("artifact_integrity", {})
        if int_or_zero(source_manifest.get("schema_version")) < 4:
            add(
                findings, "error", "SOURCE_MANIFEST_SCHEMA_STALE", "",
                "source manifest 不支持逐产物完整性绑定", source_manifest.get("schema_version"),
            )
        if not expected_source_artifacts.issubset(declared_artifacts) or not isinstance(integrity, dict):
            add(
                findings, "error", "SOURCE_ARTIFACT_SET_INCOMPLETE", "",
                "source manifest 未声明完整的源码因果产物集合",
                sorted(expected_source_artifacts - declared_artifacts),
            )
        for name in sorted(expected_source_artifacts):
            path = source_causality_dir / name
            record = integrity.get(name, {}) if isinstance(integrity, dict) else {}
            if not path.is_file():
                add(
                    findings, "error", "SOURCE_CAUSALITY_ARTIFACT_MISSING", "",
                    f"缺少 source manifest 声明的产物 {name}", path,
                )
                continue
            raw_artifact = path.read_bytes()
            actual_sha = hashlib.sha256(raw_artifact).hexdigest()
            if not isinstance(record, dict) or (
                record.get("sha256") != actual_sha
                or int_or_zero(record.get("bytes")) != len(raw_artifact)
                or bool(record.get("nonempty")) != bool(raw_artifact)
            ):
                add(
                    findings, "error", "SOURCE_ARTIFACT_INTEGRITY_FAILED", "",
                    f"源码因果产物与 source manifest 的 hash/bytes 不一致: {name}",
                    {"expected": record, "actual_sha256": actual_sha, "actual_bytes": len(raw_artifact)},
                )
        branch_device_path = source_causality_dir / "branch_device_evidence.csv"
        if branch_device_path.is_file():
            try:
                branch_device_rows = read_csv(branch_device_path)
            except (OSError, csv.Error) as error:
                add(
                    findings, "error", "SOURCE_CAUSALITY_ARTIFACT_INVALID", "",
                    "branch_device_evidence.csv 无效", error,
                )
    top_candidates = candidate_top_rows(candidates)
    claims = strength_claims(lines)
    for claim in claims:
        if not claim.get("noncanonical"):
            continue
        add(
            findings, "error", "NONCANONICAL_STRENGTH_LABEL", claim["line"],
            "报告使用了升级含义但未采用 report-contract 的规范强度名称",
            claim.get("matched_label", ""),
            f"改用规范名称“{claim['label']}”；规范名称仍须通过全部结构化证据与 Python 快照门禁。",
        )

    device_strong_lines = [
        (int(claim["line"]), str(claim["text"]))
        for claim in claims
        if claim["level"] >= 1
        and re.search(r"device|kernel|通信|npu", str(claim["text"]), re.I)
    ]

    alignment_link_keys = {
        (row.get("host_event_id", ""), row.get("device_event_id", ""))
        for row in valid_links
        if row.get("host_event_id") and row.get("device_event_id")
    }
    for line_number, line in device_strong_lines:
        context = line
        referenced_divergences = {
            divergence_id for divergence_id in divergence_by_id
            if identifier_in_text(context, divergence_id)
        }
        for candidate in top_candidates:
            if any(
                identifier_in_text(context, identifier)
                for identifier in (candidate.get("evidence_id", ""), candidate.get("guard_id", ""))
                if identifier
            ):
                referenced_divergences.add(candidate.get("divergence_id", ""))
        referenced_divergences.discard("")
        if not referenced_divergences:
            add(
                findings, "error", "DEVICE_CLAIM_UNBOUND_TO_DIVERGENCE", line_number,
                "Device 强结论未绑定自己的 divergence_id/evidence_id", line,
                "引用 framework divergence 的 evidence_id，并由 branch_device_evidence.csv 逐侧绑定。",
            )
            continue
        for divergence_id in sorted(referenced_divergences):
            divergence = divergence_by_id.get(divergence_id, {})
            eligible_rows = [
                row for row in branch_device_rows
                if row.get("divergence_id") == divergence_id
                and row.get("rank_pair_id") == divergence.get("rank_pair_id")
                and row.get("thread_pair_id") == divergence.get("thread_pair_id")
                and row.get("link_status") in DIRECT_LINK_STATUSES
                and truthy(row.get("causal_eligible"))
                and (row.get("host_event_id", ""), row.get("device_event_id", ""))
                in alignment_link_keys
            ]
            sides = {environment_side(row.get("environment")) for row in eligible_rows}
            if not {"real", "sim"}.issubset(sides):
                add(
                    findings, "error", "HOST_DEVICE_NO_DIRECT_LINK", line_number,
                    "该 Device 强结论没有逐 divergence、逐真机/仿真的 causal-eligible direct link",
                    {
                        "divergence_id": divergence_id,
                        "eligible_sides": sorted(sides - {""}),
                        "eligible_rows": len(eligible_rows),
                        "global_alignment_links": len(valid_links),
                    },
                    "Host 与 Device 分别陈述结构观察；补齐该 divergence 两侧唯一端点 direct correlation 后再升级。",
                )

    run_contract_sha256 = ""
    try:
        if run_contract_path and run_contract_path.is_file():
            run_contract_raw = run_contract_path.read_bytes()
            run_contract_sha256 = hashlib.sha256(run_contract_raw).hexdigest()
            run_contract = json.loads(run_contract_raw.decode("utf-8-sig"))
        else:
            run_contract = {}
        if run_contract and not isinstance(run_contract, dict):
            raise ValueError("run contract root is not object")
    except (OSError, ValueError, json.JSONDecodeError) as error:
        run_contract = {}
        add(findings, "error", "RUN_CONTRACT_INVALID", "", "run-comparability contract 无效", error)
    if run_contract_path and not run_contract_path.is_file():
        add(findings, "error", "RUN_CONTRACT_MISSING", "", "指定的 run contract 不存在", run_contract_path)

    positive_claims = [claim for claim in claims if claim["level"] >= 1]
    if positive_claims and not run_contract:
        add(
            findings, "error", "RUN_CONTRACT_REQUIRED", "",
            "强关联/已证实结论缺少 run_comparability_contract.json", "",
            "记录两侧 analyzed_source 的 component/repository/commit/tree_hash/status/evidence；普通字段使用 value/status/evidence。",
        )
    elif not run_contract:
        add(
            findings, "warning", "RUN_CONTRACT_NOT_PROVIDED", "",
            "未提供 run comparability contract；结论最多为结构事实/静态候选",
        )

    checked_candidate_levels: dict[str, int] = {}
    required_snapshot_candidates: dict[str, dict[str, str]] = {}
    for claim in positive_claims:
        line_number = int(claim["line"])
        context = str(claim["text"])
        referenced_candidates = candidate_references(context, top_candidates)
        if claim["count"] is not None:
            if len(referenced_candidates) != claim["count"]:
                add(
                    findings, "error", "CLAIM_SUMMARY_IDS_MISMATCH", line_number,
                    f"{claim['label']} 汇总数量没有在同一逻辑记录中列出等量、精确的 evidence_id/guard_id",
                    {
                        "report_count": claim["count"],
                        "bound_ids": [row.get("evidence_id") for row in referenced_candidates],
                    },
                    "在同一表格行或同一段落显式列出每个 candidate_rank=1 的完整 ID；附录远距引用无效。",
                )
            candidates_for_claim = referenced_candidates
        elif len(referenced_candidates) == 1:
            candidates_for_claim = referenced_candidates
        else:
            code = "CLAIM_NOT_BOUND_TO_CANDIDATE" if not referenced_candidates else "CLAIM_AMBIGUOUS_CANDIDATE"
            add(
                findings, "error", code, line_number,
                f"{claim['label']} 必须在同一逻辑记录中精确绑定一个 evidence_id/guard_id",
                {
                    "text": claim["text"],
                    "bound_ids": [row.get("evidence_id") for row in referenced_candidates],
                },
                "每条升级结论只绑定自己的完整结构化 candidate ID；不要依赖邻行或附录。",
            )
            continue
        for candidate in candidates_for_claim:
            identifier = candidate.get("evidence_id", "") or candidate.get("guard_id", "")
            if not identifier:
                continue
            if claim["level"] > checked_candidate_levels.get(identifier, -1):
                validate_candidate_gate(
                    findings, candidate, claim["level"], line_number, divergence_by_id,
                    run_contract, source_manifest, run_contract_sha256,
                )
                checked_candidate_levels[identifier] = claim["level"]
            if candidate.get("evidence_id"):
                required_snapshot_candidates[candidate["evidence_id"]] = candidate

    if set(required_snapshot_candidates) != set(preliminary_required_snapshot_candidates):
        add(
            findings, "error", "PYTHON_SNAPSHOT_DISCOVERY_MISMATCH", "",
            "可信快照隔离前后的 promotion candidate 集合不一致；报告快照不得改变结论发现结果", {
                "untrusted_view_ids": sorted(preliminary_required_snapshot_candidates),
                "trusted_view_ids": sorted(required_snapshot_candidates),
            },
        )

    # Explicit unverified rows are blocked even when the prose occurrence was in a
    # Markdown table that the generic claim parser could not bind locally.
    for index, line in enumerate(lines):
        if "unverified" in line.casefold() and any(label in line for label in STRONG_LABELS):
            add(
                findings, "error", "SOURCE_BINDING_UNVERIFIED", index + 1,
                "同一报告行把 unverified runtime/source binding 写成强结论", line,
            )

    # Absence of direct values/oracle means "not established", not a proof that
    # simulation computation error is false.  Reports must preserve that epistemic
    # distinction instead of writing a binary "否" verdict.
    for index, line in enumerate(lines):
        if not re.search(r"仿真(?:\s*tensor)?计算错误(?:判定|结论)?", line, re.I):
            continue
        verdict_context = "\n".join(lines[index:index + 4])
        if re.search(r"(?:无法判定|未证实|证据不足|unknown|undetermined)", verdict_context, re.I):
            continue
        if re.search(
            r"(?:[:：|]\s*\*{0,2}否\*{0,2}(?:\s*[|。]|\s*$)|判定为?\s*否|"
            r"(?:判定|结论)?[^\n]*\n\s*\*{0,2}否\*{0,2}(?:\s*[。|]|\s*$))",
            verdict_context,
        ):
            add(
                findings, "error", "SIMULATION_ERROR_FALSE_NEGATIVE", index + 1,
                "缺少 direct operand/producer/oracle 时不能把仿真计算错误判定为‘否’",
                verdict_context,
                "改为‘当前证据无法判定/未证实’，并列出最小补证。",
            )

    # A version table is independent evidence of a dependency conflict.  In
    # particular, an FSDP patch guard belongs to torch_npu/PyTorch dependency code,
    # so a model repository commit cannot substitute for this binding.
    torch_versions = {
        value.strip() for value in markdown_column_values(lines, "torch_npu")
        if value.strip() and value.strip().casefold() not in {"unknown", "未知"}
    }
    report_dependency_guard = bool(re.search(r"_add_fsdp_patch|torch_npu[^\n]*guard|fsdp[^\n]*guard", prose_text, re.I))
    if len(torch_versions) > 1 and positive_claims and report_dependency_guard:
        add(
            findings, "error", "DEPENDENCY_VERSION_CONFLICT", "",
            "报告显示两侧 torch_npu 版本不同，却把依赖 patch/callsite 升级为同一 guard 控制流因果",
            sorted(torch_versions),
            "绑定并比较两侧实际依赖源码；在 verified-equal 前只保留结构观察/静态候选。",
        )

    # Aggregate calls are structural coverage only. A strong claim must be bound
    # to a per-rank/thread candidate, not to a global calls delta.
    for index, line in enumerate(lines):
        if re.search(r"(?:总调用|跨\s*Rank|all\s*ranks|aggregate\s*calls)", line, re.I) and any(
            label in line for label in STRONG_LABELS
        ) and not is_negated(line):
            add(
                findings, "error", "AGGREGATE_CALLS_AS_DIVERGENCE", index + 1,
                "跨 Rank 聚合 calls 被当成首次分叉/控制流强证据", line,
                "逐 rank_pair_id/thread_pair_id 引用 event_alignment 与 divergence。",
            )

    # Simulation-computation-error claims need a much stronger run contract and
    # direct runtime operand evidence than an ordinary control-flow claim.
    sim_error_claims = [claim for claim in claims if claim["level"] == 3]
    if sim_error_claims:
        required_equal = (
            "model_code", "dependency_code", "workload", "phase", "input", "weights",
            "seed", "config", "parallel_topology",
        )
        failures = [field for field in required_equal if not verified_equal(run_contract, field)[0]] if run_contract else list(required_equal)
        direct_values = any(
            truthy(row.get("direct_operand_values_observed"))
            and truthy(row.get("predicate_results_opposite"))
            and row.get("runtime_binding") == "verified"
            for row in top_candidates
        )
        if failures or not direct_values:
            for claim in sim_error_claims:
                add(
                    findings, "error", "SIMULATION_ERROR_GATE_FAILED", claim["line"],
                    "“仿真计算错误已证实”缺少受控可比性或直接 predicate operand 证据",
                    {"run_contract_failures": failures, "direct_values": direct_values},
                )

    findings.sort(key=lambda item: (0 if item.severity == "error" else 1, str(item.line), item.code, item.message))
    errors = sum(item.severity == "error" for item in findings)
    warnings = sum(item.severity == "warning" for item in findings)
    return {
        "schema_version": SCHEMA_VERSION,
        "algorithm_version": ALGORITHM_VERSION,
        "status": "fail" if errors else "pass",
        "blocking_error_count": errors,
        "warning_count": warnings,
        "report": str(report),
        "alignment_output": str(alignment_output),
        "source_causality_dir": str(source_causality_dir) if source_causality_dir else "",
        "run_contract": str(run_contract_path) if run_contract_path else "",
        "python_snapshots_dir": str(python_snapshots_dir) if python_snapshots_dir else "",
        "perfetto_review_dir": str(perfetto_review_dir) if perfetto_review_dir else "",
        "evidence_summary": {
            "compared_rank_ids": compared_ids,
            "rank_pair_rows": len(rank_pairs),
            "thread_inventory_rows": len(thread_pairs),
            "divergence_rows": len(divergences),
            "framework_host_divergence_rows": len(framework_divergences),
            "causal_eligible_direct_links": len(valid_links),
            "top_guard_candidates": len(top_candidates),
            "strong_or_higher_report_claims": len(positive_claims),
            "perfetto_review": perfetto_review_status,
        },
        "policy": {
            "markdown_is_authority": False,
            "duration_metrics_checked_or_emitted": False,
            "blocking_exit_code": 2,
            "warning_exit_code": 0,
        },
        "findings": [asdict(item) for item in findings],
    }


def write_csv(path: Path, rows: Iterable[dict[str, Any]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8-sig", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=CSV_FIELDS, extrasaction="ignore")
        writer.writeheader()
        writer.writerows(rows)


def write_outputs(output: Path, payload: dict[str, Any]) -> None:
    output.mkdir(parents=True, exist_ok=True)
    with (output / "report_validation.json").open("w", encoding="utf-8") as handle:
        json.dump(payload, handle, ensure_ascii=False, indent=2)
    write_csv(output / "report_validation.csv", payload.get("findings", []))


def write_fixture_csv(path: Path, rows: list[dict[str, Any]]) -> None:
    fields: list[str] = []
    for row in rows:
        for key in row:
            if key not in fields:
                fields.append(key)
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8-sig", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields or ["message"])
        writer.writeheader()
        writer.writerows(rows)


def self_test() -> int:
    semantic_snapshot_fixture = """<details open>
<summary>cf-meta：已证实控制流分叉</summary>
<table><tbody><tr><td>metadata-visible</td></tr></tbody></table>
<td><pre><code>Perfetto 内容复核已完成</code></pre></td>
</details>"""
    semantic_snapshot_text = normalize_visible_markdown(
        redact_trusted_snapshot_code(
            semantic_snapshot_fixture, {semantic_snapshot_fixture}
        )
    )
    assert "已证实控制流分叉" in semantic_snapshot_text
    assert "metadata-visible" in semantic_snapshot_text
    assert "Perfetto 内容复核已完成" not in semantic_snapshot_text
    assert strength_claims(semantic_snapshot_text.splitlines())[0]["level"] == 2
    composable_fsdp = "torch/distributed/_composable/fsdp/fully_shard.py"
    assert guard_owner_component(composable_fsdp) == "pytorch"
    assert candidate_owner_component(
        {"guard_path": composable_fsdp, "source_component": "model"}
    ) == "pytorch"
    alias_claim = strength_claims(["cf-x：强关联控制流分歧。"])
    fallback_claim = strength_claims(["cf-y：高度关联的算子路径差异。"])
    heading_claim = strength_claims(["# cf-z：已证实控制流分叉"])
    split_claim = strength_claims(["cf-s：强关联", "控制流分叉"])
    four_line_claim = strength_claims(["cf-4：强", "关", "联", "控制流分叉。"])
    contrast_claim = strength_claims(["不得无证据升级，但 cf-c 本结论为已证实控制流分叉。"])
    emphasized_claim = strength_claims(
        normalize_visible_markdown("cf-e：强关联控**制**流分叉。").splitlines()
    )
    assert alias_claim and alias_claim[0]["level"] == 1 and alias_claim[0]["noncanonical"]
    assert fallback_claim and fallback_claim[0]["level"] == 1 and fallback_claim[0]["noncanonical"]
    assert heading_claim and heading_claim[0]["level"] == 2
    assert split_claim and split_claim[0]["level"] == 1 and split_claim[0]["end_line"] == 2
    assert four_line_claim and four_line_claim[0]["level"] == 1 and four_line_claim[0]["end_line"] == 4
    assert contrast_claim and contrast_claim[0]["level"] == 2
    assert emphasized_claim and emphasized_claim[0]["level"] == 1
    assert identifier_in_text("cf-0 / guard-0", "cf-0")
    assert not identifier_in_text("cf-00 / guard-00", "cf-0")
    with tempfile.TemporaryDirectory(prefix="alignment-report-gate-selftest-") as directory:
        root = Path(directory)
        alignment = root / "alignment"
        source = root / "source-causality"
        alignment.mkdir()
        source.mkdir()
        manifest = {
            "schema_version": 3,
            "roles": {"real": "reference/真机", "sim": "candidate/仿真"},
            "compared_rank_ids": [0, 1],
            "duration_metrics_emitted": False,
        }
        (alignment / "analysis_manifest.json").write_text(
            json.dumps(manifest, ensure_ascii=False), encoding="utf-8"
        )
        trace_dir = root / "traces"
        trace_dir.mkdir()
        rank_rows = []
        for rank in (0, 1):
            trace_paths: dict[str, Path] = {}
            trace_hashes: dict[str, str] = {}
            for side in ("real", "sim"):
                trace_path = trace_dir / f"rank-{rank:04d}-{side}.json"
                trace_path.write_text("[]\n", encoding="utf-8")
                trace_paths[side] = trace_path
                trace_hashes[side] = file_sha256(trace_path)
            rank_rows.append(
                {
                    "rank_pair_id": f"rank-{rank:04d}", "real_rank": rank,
                    "sim_rank": rank, "pair_rule": "exact-global-rank-intersection",
                    "status": "ready", "real_trace_path": str(trace_paths["real"]),
                    "sim_trace_path": str(trace_paths["sim"]),
                    "real_trace_sha256": trace_hashes["real"],
                    "sim_trace_sha256": trace_hashes["sim"],
                }
            )
        thread_rows: list[dict[str, Any]] = []
        divergence_rows: list[dict[str, Any]] = []
        candidate_rows: list[dict[str, Any]] = []
        link_rows: list[dict[str, Any]] = []
        branch_rows: list[dict[str, Any]] = []
        for rank in (0, 1):
            pair_id = f"rank-{rank:04d}"
            thread_id = f"{pair_id}:host:framework-0000"
            device_thread_id = f"{pair_id}:device:stream-0007"
            divergence_id = f"{thread_id}:first"
            thread_rows.extend(
                [
                    {"rank_pair_id": pair_id, "thread_pair_id": thread_id, "domain": "host",
                     "semantic_layer": "framework_op", "status": "matched", "confidence": "high"},
                    {"rank_pair_id": pair_id, "thread_pair_id": device_thread_id, "domain": "device",
                     "semantic_layer": "device_task", "status": "matched", "confidence": "high"},
                ]
            )
            divergence_rows.append(
                {
                    "divergence_id": divergence_id, "rank_pair_id": pair_id,
                    "thread_pair_id": thread_id, "domain": "host", "semantic_layer": "framework_op",
                    "lane_match_status": "matched", "lane_match_confidence": "high",
                    "anchors_before": 3, "anchors_after": 3, "anchor_gate_passed": True,
                    "nesting_gate_passed": True, "boundary_stability": "stable",
                    "alignment_boundaries": {"op": [3, 3], "metadata": [3, 3], "tree": [3, 3]},
                    "repeated_anchor_ambiguous": False, "earlier_unresolved": "否",
                    "real_operators": ["aten::matmul"], "sim_operators": ["aten::where"],
                    "real_run_calls": [1], "sim_run_calls": [1],
                }
            )
            evidence_id = f"cf-{rank}"
            candidate_rows.append(
                {
                    "evidence_id": evidence_id, "candidate_rank": 1, "divergence_id": divergence_id,
                    "rank_pair_id": pair_id, "thread_pair_id": thread_id,
                    "semantic_layer": "framework_op", "guard_id": f"guard-{rank}",
                    "guard_path": "model.py", "guard_symbol": "forward", "guard_lines": "10-14",
                    "guard_kind": "if", "predicate_text": "score > 0", "predicate_ast_hash": f"ast-{rank}",
                    "real_arm": "if", "real_arm_lines": "[11,12]", "sim_arm": "else",
                    "sim_arm_lines": "[13,14]", "boundary_stability": "stable",
                    "branch_fingerprint": json.dumps(
                        {
                            "real_operators": ["aten::matmul"],
                            "sim_operators": ["aten::where"],
                            "coverage": 1.0, "precision": 1.0, "contradictions": [],
                        },
                        ensure_ascii=False,
                    ),
                    "stack_binding_level": 1,
                    "real_stack_binding_level": 1,
                    "sim_stack_binding_level": 1,
                    "lane_high_confidence": "是",
                    "anchor_gate_passed": "是",
                    "repeated_anchor_ambiguous": "否",
                    "nesting_gate_passed": "是",
                    "entrypoint_binding_level": 1,
                    "runtime_binding": "verified", "strength": "强关联控制流分叉",
                }
            )
            link_rows.extend(
                [
                    {"environment": "real/reference/真机", "rank": rank,
                     "host_event_id": f"rh-{rank}", "device_event_id": f"rd-{rank}",
                     "link_status": "direct-flow", "causal_eligible": "是"},
                    {"environment": "sim/candidate/仿真", "rank": rank,
                     "host_event_id": f"sh-{rank}", "device_event_id": f"sd-{rank}",
                     "link_status": "direct-flow", "causal_eligible": "是"},
                ]
            )
            branch_rows.extend(
                [
                    {"divergence_id": divergence_id, "rank_pair_id": pair_id,
                     "thread_pair_id": thread_id, "environment": "real/reference/真机",
                     "host_event_id": f"rh-{rank}", "device_event_id": f"rd-{rank}",
                     "device_operator": "kernel_real", "link_status": "direct-flow",
                     "causal_eligible": "是"},
                    {"divergence_id": divergence_id, "rank_pair_id": pair_id,
                     "thread_pair_id": thread_id, "environment": "sim/candidate/仿真",
                     "host_event_id": f"sh-{rank}", "device_event_id": f"sd-{rank}",
                     "device_operator": "kernel_sim", "link_status": "direct-flow",
                     "causal_eligible": "是"},
                ]
            )
        write_fixture_csv(alignment / "rank_pairs.csv", rank_rows)
        write_fixture_csv(alignment / "unpaired_ranks.csv", [])
        write_fixture_csv(alignment / "thread_pairs.csv", thread_rows)
        write_fixture_csv(alignment / "canonical_events.csv", [])
        write_fixture_csv(alignment / "event_alignment.csv", [])
        write_fixture_csv(alignment / "host_device_links.csv", link_rows)
        (alignment / "divergence_windows.jsonl").write_text(
            "\n".join(json.dumps(row, ensure_ascii=False) for row in divergence_rows) + "\n", encoding="utf-8"
        )
        alignment_artifact_names = [
            "rank_pairs.csv", "unpaired_ranks.csv", "thread_pairs.csv",
            "canonical_events.csv", "event_alignment.csv", "divergence_windows.jsonl",
            "host_device_links.csv",
        ]
        manifest["artifacts"] = alignment_artifact_names
        manifest["artifact_integrity"] = {}
        for name in alignment_artifact_names:
            artifact_raw = (alignment / name).read_bytes()
            manifest["artifact_integrity"][name] = {
                "sha256": hashlib.sha256(artifact_raw).hexdigest(),
                "bytes": len(artifact_raw),
                "nonempty": bool(artifact_raw),
            }
        (alignment / "analysis_manifest.json").write_text(
            json.dumps(manifest, ensure_ascii=False), encoding="utf-8"
        )
        fixture_commit = "a" * 40
        fixture_tree = "b" * 40
        fixture_repository = "https://example.invalid/model"
        repo = root / "repo"
        repo.mkdir()
        (repo / "model.py").write_text(
            """# 1
# 2
# 3
# 4
# 5
# 6
# 7
# 8
score = 1
if score > 0:
    y = matmul(x)
    return y
else:
    return where(x)
""",
            encoding="utf-8",
        )
        contract = {
            "real": {
                "analyzed_source": {
                    "component": "model", "repository": fixture_repository,
                    "commit": fixture_commit, "tree_hash": fixture_tree,
                    "status": "verified", "evidence": "real build manifest",
                },
                "model_code": {"value": "abc", "status": "verified", "evidence": "build"},
                "torch_npu_version": {"value": "2.7.1.post7", "status": "verified", "evidence": "metadata"},
            },
            "sim": {
                "analyzed_source": {
                    "component": "model", "repository": fixture_repository,
                    "commit": fixture_commit, "tree_hash": fixture_tree,
                    "status": "verified", "evidence": "sim build manifest",
                },
                "model_code": {"value": "abc", "status": "verified", "evidence": "build"},
                "torch_npu_version": {"value": "2.7.1.post7", "status": "verified", "evidence": "metadata"},
            },
            "comparisons": {"analyzed_source": "equal", "model_code": "equal", "torch_npu_version": "equal"},
        }
        contract_path = root / "run_comparability_contract.json"
        contract_path.write_text(json.dumps(contract, ensure_ascii=False), encoding="utf-8")
        contract_sha256 = hashlib.sha256(contract_path.read_bytes()).hexdigest()
        for row in candidate_rows:
            row.update(
                {
                    "analyzed_source_gate_passed": True,
                    "dependency_source_gate_passed": True,
                    "source_component": "model",
                    "run_contract_sha256": contract_sha256,
                    "indexed_head_commit": fixture_commit,
                    "indexed_tree_hash": fixture_tree,
                    "source_scan_complete": True,
                    "repository": fixture_repository,
                    "commit": fixture_commit,
                }
            )
        write_fixture_csv(source / "control_flow_guard_candidates.csv", candidate_rows)
        (source / "control_flow_evidence.jsonl").write_text(
            "\n".join(
                json.dumps({"evidence_id": row["evidence_id"]}, ensure_ascii=False)
                for row in candidate_rows
            ) + "\n",
            encoding="utf-8",
        )
        write_fixture_csv(source / "predicate_tensor_evidence.csv", [])
        write_fixture_csv(source / "event_source_map.csv", [])
        write_fixture_csv(source / "branch_device_evidence.csv", branch_rows)
        write_fixture_csv(source / "source_evidence.csv", [])
        write_fixture_csv(source / "source_entrypoint_chain.csv", [])
        write_fixture_csv(source / "source_analysis_issues.csv", [])
        source_artifact_names = [
            "control_flow_guard_candidates.csv", "control_flow_evidence.jsonl",
            "predicate_tensor_evidence.csv", "event_source_map.csv",
            "branch_device_evidence.csv", "source_evidence.csv",
            "source_entrypoint_chain.csv", "source_analysis_issues.csv",
        ]
        source_integrity = {}
        for name in source_artifact_names:
            artifact_raw = (source / name).read_bytes()
            source_integrity[name] = {
                "sha256": hashlib.sha256(artifact_raw).hexdigest(),
                "bytes": len(artifact_raw),
                "nonempty": bool(artifact_raw),
            }
        (source / "source_analysis_manifest.json").write_text(
            json.dumps(
                {
                    "schema_version": 4,
                    "status": "complete",
                    "promotion_status": "eligible",
                    "repo_root": str(repo.resolve()),
                    "repository": fixture_repository,
                    "resolved_commit": fixture_commit,
                    "indexed_source_snapshot": {
                        "binding_status": "verified",
                        "is_git_repository": True,
                        "worktree_dirty": "no",
                        "head_commit": fixture_commit,
                        "resolved_commit": fixture_commit,
                        "tree_hash": fixture_tree,
                        "remote": fixture_repository,
                    },
                    "source_scan": {"truncated": False},
                    "run_comparability": {"sha256": contract_sha256},
                    "artifacts": source_artifact_names,
                    "artifact_integrity": source_integrity,
                },
                ensure_ascii=False,
            ),
            encoding="utf-8",
        )
        def refresh_source_integrity() -> None:
            manifest_payload = json.loads(
                (source / "source_analysis_manifest.json").read_text(encoding="utf-8")
            )
            refreshed = {}
            for artifact_name in source_artifact_names:
                artifact_raw = (source / artifact_name).read_bytes()
                refreshed[artifact_name] = {
                    "sha256": hashlib.sha256(artifact_raw).hexdigest(),
                    "bytes": len(artifact_raw),
                    "nonempty": bool(artifact_raw),
                }
            manifest_payload["artifact_integrity"] = refreshed
            (source / "source_analysis_manifest.json").write_text(
                json.dumps(manifest_payload, ensure_ascii=False), encoding="utf-8"
            )
        from render_python_guard_snapshots import render_python_guard_snapshots
        snapshots_dir = root / "python-snapshots"
        render_python_guard_snapshots(repo, source, snapshots_dir, context_lines=1)
        snapshot_details_md = "\n\n".join(
            re.findall(
                r"<details\s+open>.*?</details>",
                (snapshots_dir / "python_guard_snapshots.md").read_text(encoding="utf-8"),
                flags=re.I | re.S,
            )
        )
        perfetto_dir = root / "perfetto-review"
        perfetto_dir.mkdir()
        perfetto_jobs = [
            {
                "rank_pair_id": f"rank-{rank:04d}", "environment": side,
                "planned_status": "ready", "run_status": "not-executed",
                "content_review_status": "not-executed", "output_dir": "",
            }
            for rank in (0, 1) for side in ("real", "sim")
        ]
        perfetto_batch = {
            "schema_version": 2, "status": "partial", "jobs": perfetto_jobs,
            "online_authorized": False,
            "execution_block_reason": "online Perfetto review was not authorized by data policy",
            "device_evidence": "local-parser-only", "duration_metrics_emitted": False,
            "lane_batch_union": [],
        }
        (perfetto_dir / "perfetto_batch_manifest.json").write_text(
            json.dumps(perfetto_batch, ensure_ascii=False), encoding="utf-8"
        )
        write_fixture_csv(perfetto_dir / "perfetto_batch_manifest.csv", perfetto_jobs)
        (perfetto_dir / "perfetto_content_review.json").write_text(
            json.dumps(
                {
                    "schema_version": 1, "status": "not-executed",
                    "reviewed_artifacts": [],
                    "reviewed_jobs": [
                        {
                            "rank_pair_id": row["rank_pair_id"],
                            "environment": row["environment"], "status": "not-executed",
                        }
                        for row in perfetto_jobs
                    ],
                    "canvas_review": "not-executed",
                },
                ensure_ascii=False,
            ),
            encoding="utf-8",
        )
        complete_perfetto_dir = root / "perfetto-review-complete"
        complete_perfetto_dir.mkdir()
        complete_jobs: list[dict[str, Any]] = []
        reviewed_complete_jobs: list[dict[str, Any]] = []
        lane_unions: list[dict[str, Any]] = []
        for rank_row in rank_rows:
            pair_id = rank_row["rank_pair_id"]
            for side_index, side in enumerate(("real", "sim")):
                batch_name = "batch_000"
                job_output = complete_perfetto_dir / "perfetto" / pair_id / side / batch_name
                job_output.mkdir(parents=True)
                for artifact_name in (
                    "perfetto_ui_frame.html", "perfetto_ui_text.txt", "perfetto_browser.log"
                ):
                    (job_output / artifact_name).write_text(
                        f"{pair_id}/{side}/{artifact_name}\n", encoding="utf-8"
                    )
                pid, tid = int(pair_id[-4:]) + 1, side_index + 10
                lane_key = f"{pid}/{tid}"
                trace_path = Path(rank_row[f"{side}_trace_path"])
                trace_sha = rank_row[f"{side}_trace_sha256"]
                run_id = f"00000000-0000-4000-8000-{int(pair_id[-4:]) * 2 + side_index + 1:012d}"
                renderer_manifest = {
                    "schema_version": 3, "status": "success", "run_id": run_id,
                    "trace": {"sha256": trace_sha},
                    "selection": {
                        "domain": "host", "device_evidence": "local-parser-only",
                        "lanes": [{"pid": pid, "tid": tid}], "skipped_lanes": [],
                    },
                    "perfetto": {
                        "ui_origin": "https://ui.perfetto.dev", "local_only": True,
                        "message_origin_enforced": True,
                        "network_isolation": {
                            "offline_before_trace_post": True,
                            "service_worker_count_after_render": 0,
                            "service_worker_guard_visible_in_perfetto_frame": True,
                            "post_offline_successful_response_count": 0,
                        },
                    },
                    "sql": {
                        "duration_metrics_emitted": False, "global_row_limit": None,
                        "query_results": [
                            {"query_id": query_id, "completed": True, "row_count": 1, "error": None}
                            for query_id in (
                                "operator_counts", "track_inventory", "host_launch_context",
                                "structural_sequence", "completeness_summary",
                            )
                        ],
                        "completeness": {"complete": True, "truncated": False},
                    },
                }
                renderer_manifest_path = job_output / "perfetto_manifest.json"
                renderer_manifest_path.write_text(
                    json.dumps(renderer_manifest, ensure_ascii=False), encoding="utf-8"
                )
                job = {
                    "rank_pair_id": pair_id, "environment": side,
                    "trace_path": str(trace_path), "expected_trace_sha256": trace_sha,
                    "source_lane_keys_json": json.dumps([lane_key]),
                    "batch_lane_keys_json": json.dumps([lane_key]),
                    "output_dir": str(job_output), "manifest_path": str(renderer_manifest_path),
                    "planned_status": "ready", "run_status": "success", "return_code": 0,
                    "auto_artifact_gate": "auto-artifacts-ready",
                    "lane_batch_union_complete": True,
                }
                complete_jobs.append(job)
                artifact_paths = {
                    "manifest": renderer_manifest_path,
                    "html": job_output / "perfetto_ui_frame.html",
                    "text": job_output / "perfetto_ui_text.txt",
                    "browser-log": job_output / "perfetto_browser.log",
                }
                reviewed_complete_jobs.append(
                    {
                        "rank_pair_id": pair_id, "environment": side, "batch": batch_name,
                        "renderer_run_id": run_id, "status": "complete",
                        "artifacts": [
                            {
                                "kind": kind, "path": str(path), "bytes": path.stat().st_size,
                                "sha256": file_sha256(path),
                            }
                            for kind, path in artifact_paths.items()
                        ],
                    }
                )
                lane_unions.append(
                    {"rank_pair_id": pair_id, "environment": side, "complete": True}
                )
        complete_batch = {
            "schema_version": 2, "status": "complete", "jobs": complete_jobs,
            "online_authorized": True, "execution_block_reason": "",
            "device_evidence": "local-parser-only", "duration_metrics_emitted": False,
            "lane_batch_union": lane_unions,
        }
        complete_batch_path = complete_perfetto_dir / "perfetto_batch_manifest.json"
        complete_batch_path.write_text(
            json.dumps(complete_batch, ensure_ascii=False), encoding="utf-8"
        )
        write_fixture_csv(
            complete_perfetto_dir / "perfetto_batch_manifest.csv", complete_jobs
        )
        (complete_perfetto_dir / "perfetto_content_review.json").write_text(
            json.dumps(
                {
                    "schema_version": 1, "status": "complete",
                    "batch_manifest_sha256": file_sha256(complete_batch_path),
                    "review_methods": ["manifest", "html", "text", "sql", "browser-log"],
                    "reviewed_jobs": reviewed_complete_jobs,
                    "observations": ["synthetic structural query evidence reviewed"],
                    "screenshot_reviewed": False, "canvas_claims_made": False,
                },
                ensure_ascii=False,
            ),
            encoding="utf-8",
        )
        good_report = root / "good.md"
        good_report.write_text(
            """reference = 真机
candidate = 仿真
本报告只分析算子结构、顺序、嵌套、Shape 与控制流；不分析耗时或性能。
ts/dur 仅在解析器内部用于排序、B/E 配对、嵌套和 direct flow 端点恢复。

rank-0000 / rank-0000:host:framework-0000 / rank-0000:host:framework-0000:first：边界 stable，op-only/op+metadata/tree-aware 三视图一致。
rank-0000 / rank-0000:device:stream-0007：Device lane 已覆盖。
cf-0 / guard-0 / rank-0000:host:framework-0000:first：强关联控制流分叉。
rank-0001 / rank-0001:host:framework-0000 / rank-0001:host:framework-0000:first：边界 stable，op-only/op+metadata/tree-aware 三视图一致。
rank-0001 / rank-0001:device:stream-0007：Device lane 已覆盖。
cf-1 / guard-1 / rank-0001:host:framework-0000:first：强关联控制流分叉。
强关联控制流分叉: 2（evidence_id: cf-0, cf-1）
Perfetto 内容复核未执行：数据政策尚未授权。
""" + snapshot_details_md,
            encoding="utf-8",
        )
        good = validate(
            good_report, alignment, source, contract_path, snapshots_dir, perfetto_dir
        )
        assert good["status"] == "pass", json.dumps(good["findings"], ensure_ascii=False, indent=2)
        good_output = root / "good-validation"
        write_outputs(good_output, good)
        assert (good_output / "report_validation.json").is_file()
        assert (good_output / "report_validation.csv").is_file()

        # Coordinated mutation of MD + HTML + the main report must still fail:
        # the exact whole block has to be reproducible by the trusted renderer.
        snapshot_markdown_path = snapshots_dir / "python_guard_snapshots.md"
        snapshot_html_path = snapshots_dir / "python_guard_snapshots.html"
        snapshot_markdown_original = snapshot_markdown_path.read_text(encoding="utf-8")
        snapshot_html_original = snapshot_html_path.read_text(encoding="utf-8")
        trusted_snapshot_block = re.findall(
            r"<details\s+open>.*?</details>", snapshot_markdown_original,
            flags=re.I | re.S,
        )[0]
        coordinated_mutations = {
            "summary-strong": trusted_snapshot_block.replace(
                "</summary>", " | 已证实控制流分叉</summary>", 1
            ),
            "metadata-perfetto": trusted_snapshot_block.replace(
                "</tbody>",
                "<tr><th>Injected</th><td>Perfetto 内容复核已完成</td></tr></tbody>",
                1,
            ),
        }
        for mutation_name, mutated_block in coordinated_mutations.items():
            snapshot_markdown_path.write_text(
                snapshot_markdown_original.replace(
                    trusted_snapshot_block, mutated_block, 1
                ),
                encoding="utf-8",
            )
            snapshot_html_path.write_text(
                snapshot_html_original.replace(trusted_snapshot_block, mutated_block, 1),
                encoding="utf-8",
            )
            mutated_report = root / f"coordinated-snapshot-{mutation_name}.md"
            mutated_report.write_text(
                good_report.read_text(encoding="utf-8").replace(
                    trusted_snapshot_block, mutated_block, 1
                ),
                encoding="utf-8",
            )
            mutated_result = validate(
                mutated_report, alignment, source, contract_path,
                snapshots_dir, perfetto_dir,
            )
            mutated_codes = {row["code"] for row in mutated_result["findings"]}
            assert mutated_result["status"] == "fail"
            assert (2 if mutated_result["blocking_error_count"] else 0) == 2
            assert "PYTHON_SNAPSHOT_RENDER_MISMATCH" in mutated_codes
            assert "REPORT_RAW_HTML_FORBIDDEN" in mutated_codes
            if mutation_name == "metadata-perfetto":
                assert "PERFETTO_STATUS_CONFLICT" in mutated_codes
        snapshot_markdown_path.write_text(snapshot_markdown_original, encoding="utf-8")
        snapshot_html_path.write_text(snapshot_html_original, encoding="utf-8")

        # Regression: an external Markdown file is not a trust source.  With no
        # source-causality candidate and no run contract, required_candidates is
        # empty, so even an exact matching open-details block must stay visible.
        forged_snapshots_dir = root / "forged-python-snapshots"
        forged_snapshots_dir.mkdir()
        static_report_prefix = """reference = 真机
candidate = 仿真
本报告只分析算子结构、顺序、嵌套、Shape 与控制流；不分析耗时或性能。
ts/dur 仅在解析器内部用于排序、B/E 配对、嵌套和 direct flow 端点恢复。

rank-0000 / rank-0000:host:framework-0000 / rank-0000:host:framework-0000:first：结构分叉事实，边界 stable，op-only/op+metadata/tree-aware 三视图一致。
rank-0000 / rank-0000:device:stream-0007：Device lane 已覆盖。
rank-0001 / rank-0001:host:framework-0000 / rank-0001:host:framework-0000:first：结构分叉事实，边界 stable，op-only/op+metadata/tree-aware 三视图一致。
rank-0001 / rank-0001:device:stream-0007：Device lane 已覆盖。
Perfetto 内容复核未执行：数据政策尚未授权。
"""
        forged_blocks = {
            "strong": """<details open>
<summary>forged strong conclusion</summary>
<p>已证实控制流分叉。</p>
</details>""",
            "perfetto": """<details open>
<summary>forged Perfetto status</summary>
<p>Perfetto 内容复核已完成。</p>
</details>""",
        }
        for forged_name, forged_block in forged_blocks.items():
            (forged_snapshots_dir / "python_guard_snapshots.md").write_text(
                forged_block, encoding="utf-8"
            )
            forged_report = root / f"forged-open-details-{forged_name}.md"
            forged_report.write_text(
                static_report_prefix + forged_block + "\n", encoding="utf-8"
            )
            forged_result = validate(
                forged_report, alignment, None, None,
                forged_snapshots_dir, perfetto_dir,
            )
            forged_codes = {row["code"] for row in forged_result["findings"]}
            assert forged_result["status"] == "fail"
            assert (2 if forged_result["blocking_error_count"] else 0) == 2
            assert "REPORT_RAW_HTML_FORBIDDEN" in forged_codes
            if forged_name == "strong":
                assert forged_result["evidence_summary"]["strong_or_higher_report_claims"] >= 1
                assert "RUN_CONTRACT_REQUIRED" in forged_codes
            else:
                assert "PERFETTO_STATUS_CONFLICT" in forged_codes

        complete_perfetto_report = root / "complete-perfetto.md"
        complete_perfetto_report.write_text(
            good_report.read_text(encoding="utf-8").replace(
                "Perfetto 内容复核未执行：数据政策尚未授权。",
                "Perfetto 内容复核已完成：manifest/HTML/text/SQL 均已读取。",
            ),
            encoding="utf-8",
        )
        complete_perfetto = validate(
            complete_perfetto_report, alignment, source, contract_path,
            snapshots_dir, complete_perfetto_dir,
        )
        assert complete_perfetto["status"] == "pass", json.dumps(
            complete_perfetto["findings"], ensure_ascii=False, indent=2
        )
        tampered_perfetto_html = (
            complete_perfetto_dir / "perfetto" / "rank-0000" / "real" /
            "batch_000" / "perfetto_ui_frame.html"
        )
        tampered_perfetto_original = tampered_perfetto_html.read_text(encoding="utf-8")
        tampered_perfetto_html.write_text(
            tampered_perfetto_original.replace("rank-0000", "rank-9999"), encoding="utf-8"
        )
        tampered_perfetto = validate(
            complete_perfetto_report, alignment, source, contract_path,
            snapshots_dir, complete_perfetto_dir,
        )
        assert "PERFETTO_JOB_GATE_FAILED" in {
            row["code"] for row in tampered_perfetto["findings"]
        }
        tampered_perfetto_html.write_text(tampered_perfetto_original, encoding="utf-8")

        false_perfetto_report = root / "false-perfetto-complete.md"
        false_perfetto_report.write_text(
            complete_perfetto_report.read_text(encoding="utf-8"), encoding="utf-8"
        )
        false_perfetto = validate(
            false_perfetto_report, alignment, source, contract_path,
            snapshots_dir, perfetto_dir,
        )
        false_perfetto_codes = {row["code"] for row in false_perfetto["findings"]}
        assert false_perfetto["status"] == "fail"
        assert "PERFETTO_LANE_UNION_INCOMPLETE" in false_perfetto_codes
        assert "PERFETTO_CONTENT_REVIEW_INCOMPLETE" in false_perfetto_codes

        hidden_perfetto_report = root / "hidden-perfetto-status.md"
        hidden_perfetto_report.write_text(
            good_report.read_text(encoding="utf-8").replace(
                "Perfetto 内容复核未执行：数据政策尚未授权。",
                "Perfetto 内容复核完<!--x-->成。 <!-- Perfetto 未执行 -->",
            ),
            encoding="utf-8",
        )
        hidden_perfetto = validate(
            hidden_perfetto_report, alignment, source, contract_path,
            snapshots_dir, perfetto_dir,
        )
        hidden_perfetto_codes = {row["code"] for row in hidden_perfetto["findings"]}
        assert hidden_perfetto["status"] == "fail"
        assert "REPORT_HTML_COMMENT_FORBIDDEN" in hidden_perfetto_codes
        assert "PERFETTO_LANE_UNION_INCOMPLETE" in hidden_perfetto_codes

        four_line_report = root / "four-line-strength.md"
        four_line_report.write_text(
            good_report.read_text(encoding="utf-8").replace(
                "强关联控制流分叉", "强\n关\n联\n控制流分叉", 1
            ),
            encoding="utf-8",
        )
        four_line_result = validate(
            four_line_report, alignment, source, contract_path, snapshots_dir, perfetto_dir
        )
        assert four_line_result["status"] == "pass", json.dumps(
            four_line_result["findings"], ensure_ascii=False, indent=2
        )

        comment_strength_report = root / "comment-strength.md"
        comment_strength_report.write_text(
            good_report.read_text(encoding="utf-8").replace(
                "强关联控制流分叉", "强关联控<!--x-->制流分叉", 1
            ),
            encoding="utf-8",
        )
        comment_strength = validate(
            comment_strength_report, alignment, source, contract_path,
            snapshots_dir, perfetto_dir,
        )
        assert "REPORT_HTML_COMMENT_FORBIDDEN" in {
            row["code"] for row in comment_strength["findings"]
        }
        assert comment_strength["evidence_summary"]["strong_or_higher_report_claims"] >= 1

        format_strength_report = root / "format-strength.md"
        format_strength_report.write_text(
            good_report.read_text(encoding="utf-8").replace(
                "强关联控制流分叉", "强关联控\u200b制流分叉", 1
            ),
            encoding="utf-8",
        )
        format_strength = validate(
            format_strength_report, alignment, source, contract_path,
            snapshots_dir, perfetto_dir,
        )
        assert "FORMAT_CONTROL_CHARACTER" in {
            row["code"] for row in format_strength["findings"]
        }
        assert format_strength["evidence_summary"]["strong_or_higher_report_claims"] >= 1

        # Semantically equivalent promotion wording must not bypass the upgraded
        # claim and Python snapshot gates. The report contract intentionally has
        # canonical strength labels, but validators still fail closed on aliases.
        alias_report = root / "alias-promotion.md"
        alias_report.write_text(
            good_report.read_text(encoding="utf-8").replace(
                "强关联控制流分叉", "强关联控制流分歧"
            ),
            encoding="utf-8",
        )
        alias_result = validate(
            alias_report, alignment, source, contract_path, None, perfetto_dir
        )
        alias_codes = {row["code"] for row in alias_result["findings"]}
        assert alias_result["status"] == "fail"
        assert "NONCANONICAL_STRENGTH_LABEL" in alias_codes
        assert "PYTHON_SNAPSHOT_REQUIRED" in alias_codes

        substring_report = root / "substring-id.md"
        substring_report.write_text(
            good_report.read_text(encoding="utf-8").replace("cf-0", "cf-00").replace(
                "guard-0", "guard-00"
            ),
            encoding="utf-8",
        )
        substring_result = validate(
            substring_report, alignment, source, contract_path, snapshots_dir, perfetto_dir
        )
        substring_codes = {row["code"] for row in substring_result["findings"]}
        assert substring_result["status"] == "fail"
        assert "CLAIM_NOT_BOUND_TO_CANDIDATE" in substring_codes
        assert "CLAIM_SUMMARY_IDS_MISMATCH" in substring_codes

        distant_summary_report = root / "distant-summary.md"
        distant_summary_report.write_text(
            good_report.read_text(encoding="utf-8").replace(
                "强关联控制流分叉: 2（evidence_id: cf-0, cf-1）",
                "强关联控制流分叉: 2\n\n附录候选库存：cf-0、cf-1",
            ),
            encoding="utf-8",
        )
        distant_result = validate(
            distant_summary_report, alignment, source, contract_path, snapshots_dir, perfetto_dir
        )
        assert "CLAIM_SUMMARY_IDS_MISMATCH" in {
            row["code"] for row in distant_result["findings"]
        }

        snapshot_html_path = snapshots_dir / "python_guard_snapshots.html"
        snapshot_html_original = snapshot_html_path.read_text(encoding="utf-8")
        snapshot_html_path.write_text(
            '<!doctype html><html><head><meta http-equiv="Content-Security-Policy" '
            'content="default-src \'none\'"></head><body></body></html>\n',
            encoding="utf-8",
        )
        empty_html_result = validate(
            good_report, alignment, source, contract_path, snapshots_dir, perfetto_dir
        )
        assert "PYTHON_SNAPSHOT_HTML_CONTENT_MISMATCH" in {
            row["code"] for row in empty_html_result["findings"]
        }
        snapshot_html_path.write_text(snapshot_html_original, encoding="utf-8")

        tampered_candidates = [dict(row) for row in candidate_rows]
        tampered_fingerprint = json.loads(tampered_candidates[0]["branch_fingerprint"])
        tampered_fingerprint["coverage"] = 0.1
        tampered_candidates[0]["branch_fingerprint"] = json.dumps(
            tampered_fingerprint, ensure_ascii=False
        )
        write_fixture_csv(source / "control_flow_guard_candidates.csv", tampered_candidates)
        refresh_source_integrity()
        tampered = validate(
            good_report, alignment, source, contract_path, snapshots_dir, perfetto_dir
        )
        assert "CANDIDATE_STRENGTH_NOT_REPRODUCIBLE" in {
            row["code"] for row in tampered["findings"]
        }
        write_fixture_csv(source / "control_flow_guard_candidates.csv", candidate_rows)
        refresh_source_integrity()

        # An unrelated valid link from another Rank/divergence must not authorize
        # a Device claim for cf-0.
        write_fixture_csv(
            source / "branch_device_evidence.csv",
            [row for row in branch_rows if row["divergence_id"].endswith("framework-0000:first")
             and row["rank_pair_id"] == "rank-0001"],
        )
        refresh_source_integrity()
        unrelated_device_report = root / "unrelated-device.md"
        unrelated_device_report.write_text(
            good_report.read_text(encoding="utf-8")
            + "\ncf-0 / rank-0000:host:framework-0000:first：Device kernel 强关联推断。\n",
            encoding="utf-8",
        )
        unrelated = validate(
            unrelated_device_report, alignment, source, contract_path, snapshots_dir, perfetto_dir
        )
        assert "HOST_DEVICE_NO_DIRECT_LINK" in {row["code"] for row in unrelated["findings"]}
        write_fixture_csv(source / "branch_device_evidence.csv", branch_rows)
        refresh_source_integrity()

        # Downgrade machine evidence and remove direct links for the deliberately
        # bad report. Every listed regression came from a real-world report review.
        bad_candidates = [
            dict(
                row,
                runtime_binding="unverified",
                strength="静态候选",
                guard_kind="",
                predicate_ast_hash="",
                real_arm_lines="",
                sim_arm_lines="",
            )
            for row in candidate_rows
        ]
        write_fixture_csv(source / "control_flow_guard_candidates.csv", bad_candidates)
        write_fixture_csv(alignment / "host_device_links.csv", [])
        bad_contract = json.loads(json.dumps(contract))
        bad_contract["sim"]["analyzed_source"]["component"] = "torch_npu"
        bad_contract["sim"]["analyzed_source"]["commit"] = "c" * 40
        bad_contract["sim"]["torch_npu_version"]["value"] = "2.7.1.post4.dev20260421"
        bad_contract["comparisons"]["analyzed_source"] = "different"
        bad_contract["comparisons"]["torch_npu_version"] = "different"
        contract_path.write_text(json.dumps(bad_contract, ensure_ascii=False), encoding="utf-8")
        bad_report = root / "bad.md"
        bad_report.write_text(
            """reference = 真机
candidate = 仿真
本报告只分析算子结构、顺序、嵌套、Shape 与控制流；不分析耗时或性能。
ts/dur 仅在解析器内部用于排序、B/E 配对、嵌套和 direct flow 端点恢复。

| 角色 | torch_npu 版本 |
|---|---|
| 真机 | 2.7.1.post7 |
| 仿真 | 2.7.1.post4.dev20260421 |

Rank 0-1 通用：rank-0000:host:framework-0000:first 的边界 stable（op-only、op+metadata 两视图一致）。
Rank 1 身份证据为 directory order。
Device 有 6 streams (26, 27, N/A)。
cf-0 / guard-0：Stack 到 _add_fsdp_patch.py:153，因此 _get_param_all_gather_inputs 条件是 guard；Runtime 绑定=unverified；强关联控制流分叉。
Host launch 7241 / Device kernel 7999 = 0.91，暗示额外工作负载和控制流因果。
Host 与 Device 尚未形成 direct flow；Device communication kernel 是强关联控制流分叉。
Perfetto 在线 UI 加载未执行（GitCode/GitHub 不可达）。
跨 Rank 总调用 aten::_foreach_copy_ 216 次，属于强关联控制流分叉。
采样了 Host cpu_op 段的全部可用事件。
### 仿真计算错误判定
**否**。
污染算子：\a ten::mm
""".replace("\a ", "\a"),
            encoding="utf-8",
        )
        bad = validate(
            bad_report, alignment, source, contract_path, snapshots_dir, perfetto_dir
        )
        codes = {row["code"] for row in bad["findings"] if row["severity"] == "error"}
        expected = {
            "CONTROL_CHARACTER", "RANK_RANGE_GENERALIZATION", "RANK_IDENTITY_DIRECTORY_ORDER",
            "BOUNDARY_TWO_VIEW_ONLY", "UNKNOWN_STREAM_AS_LANE", "CLAIM_STRENGTH_EXCEEDS_EVIDENCE",
            "SOURCE_BINDING_UNVERIFIED", "STACK_CALLSITE_IS_NOT_GUARD", "AGGREGATE_CAUSAL_INFERENCE",
            "HOST_DEVICE_NO_DIRECT_LINK", "PERFETTO_REASON_SOURCE_REACHABILITY",
            "AGGREGATE_CALLS_AS_DIVERGENCE", "SAMPLING_COVERAGE_CONTRADICTION",
            "DEPENDENCY_VERSION_CONFLICT", "SIMULATION_ERROR_FALSE_NEGATIVE",
        }
        missing = expected - codes
        assert not missing, f"self-test did not exercise: {sorted(missing)}; got={sorted(codes)}"
        assert bad["status"] == "fail" and bad["blocking_error_count"] >= len(expected)
        bad_output = root / "bad-validation"
        write_outputs(bad_output, bad)
        assert json.loads((bad_output / "report_validation.json").read_text(encoding="utf-8"))["status"] == "fail"
    print("self-test: ok")
    return 0


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--report", type=Path, help="最终 profiling_alignment_report.md")
    parser.add_argument("--alignment-output", type=Path, help="align_profiles.py 输出目录")
    parser.add_argument("--source-causality-dir", type=Path, help="analyze_control_flow.py 输出目录")
    parser.add_argument("--run-contract", type=Path, help="run_comparability_contract.json")
    parser.add_argument(
        "--python-snapshots-dir", type=Path,
        help="render_python_guard_snapshots.py 输出目录；强关联/已证实结论必需",
    )
    parser.add_argument(
        "--perfetto-review-dir", type=Path,
        help="render_perfetto_batch.py 输出目录；complete/partial/not-executed 均必需",
    )
    parser.add_argument("--output", type=Path, help="验证产物目录；默认 <alignment-output>/report-validation")
    parser.add_argument("--self-test", action="store_true")
    return parser


def main() -> int:
    args = build_parser().parse_args()
    if args.self_test:
        return self_test()
    if not args.report or not args.alignment_output:
        raise SystemExit("--report 与 --alignment-output 必填（或使用 --self-test）")
    output = args.output or args.alignment_output / "report-validation"
    payload = validate(
        args.report, args.alignment_output, args.source_causality_dir,
        args.run_contract, args.python_snapshots_dir, args.perfetto_review_dir,
    )
    write_outputs(output.resolve(), payload)
    print(
        json.dumps(
            {
                "status": payload["status"],
                "blocking_error_count": payload["blocking_error_count"],
                "warning_count": payload["warning_count"],
                "json": str((output.resolve() / "report_validation.json")),
                "csv": str((output.resolve() / "report_validation.csv")),
            },
            ensure_ascii=False,
        )
    )
    return 2 if payload["blocking_error_count"] else 0


if __name__ == "__main__":
    raise SystemExit(main())

# 推荐输入模板

```text
请用 $profiling-alignment-analysis 分析：

公共工作目录：<可选；目录内同时包含 MindSpeed、真机 profiling、仿真 profiling 与独立输出目录>
MindSpeed 源码根：<公共目录下的本地只读 checkout；若没有本地源码才填 HTTPS Git URL>
真机 Profiling（reference）：<绝对目录>
仿真 Profiling（candidate）：<绝对目录>
分析输出目录：<公共目录下第四个独立子目录；不得位于源码或任一 profiling 内>
采集类型：<优先 TorchNPU integrated ASCEND_PROFILER_OUTPUT text export；若为 raw msprof/analysis.db 请明确>

模型/权重/配置：<标识或文件>
Workload：<batch、input/output length、请求/数据集、并发>
阶段：<prefill/decode/train/...>
Profiler schedule/窗口：<wait/warmup/active/repeat、step/request 标识>
Profiler 采集配置：<CPU/NPU activities、record_shapes、with_stack、with_modules、profiler level>
子线程算子：<是否使用 enable_profiler_in_child_thread 或等价注册；未知可留空>
并行拓扑：<world size、DP/TP/EP/PP/CP/DCP>

模型源码：<同 MindSpeed 源码根；也可另给 HTTPS Git 仓库 URL 或 GitHub/GitCode/GitLab blob/file URL>
源码 commit/tag/branch：<优先完整 commit>
模型入口：<一个或多个 .sh；绝对路径或相对 MindSpeed 源码根；也可给全是 .sh 的目录>
真机运行版本证据：<metadata/log/build ID>
仿真运行版本证据：<metadata/log/build ID>
本次候选 guard 所属源码组件：<model repo / PyTorch / torch_npu / third-party patch>
真机 analyzed_source：<component；repository；完整 commit；完整 tree_hash；可选 build_id；status；证据>
仿真 analyzed_source：<component；repository；完整 commit；完整 tree_hash；可选 build_id；status；证据>
真机/仿真 torch_npu 版本与 commit/build：<分别填写，不只写一侧>

Rank 身份证据：<profiler rank_id/global_rank 或明确 rank_N 目录标记；禁止 directory order>

可选 runtime guard 证据：<CSV/JSONL>
可选明确 Thread 映射：<每 Rank 的 real pid/tid -> sim pid/tid 与依据>
在线 Perfetto 是否符合数据政策：<是/否；否时使用本地降级>
是否需要 Canvas 截图：<默认否>
```

如果只给两个 Profiling 目录却没有明确真机/仿真角色，只询问角色，不运行比较。其余缺失项不必阻塞结构提取，但必须降低对应结论强度并列出最小补证。

公共目录只是路径容器，不是 Rank/角色证据。必须把三个输入子树解析为互不覆盖的绝对路径，并确认输出是第四个独立子树。Prompt 中的相对 `.sh` 从 `MindSpeed 源码根` 解析；越界、symlink/reparse 越出 repo 或入口不存在时 fail closed，不改从当前 shell 目录猜入口。

URL 输入先运行 `prepare_source_checkout.py` 写入专用 `source-checkouts/`，读取 `source_checkout_manifest.json` 后再静态解析入口。没有固定完整 commit 时，远端 HEAD 只能用于代码导航，源码因果保持 unverified。不要执行仓库中的 Bash/Python/C++、Git hooks、submodule 或 LFS 内容。

把上述运行身份写入 `run_comparability_contract.json`；每侧至少包含：

```json
{
  "analyzed_source": {
    "component": "model|torch_npu|pytorch|dependency:<name>",
    "repository": "https://.../repo",
    "commit": "<full git commit>",
    "tree_hash": "<full git tree hash>",
    "build_id": "<optional runtime build id>",
    "status": "verified",
    "evidence": "<runtime/build evidence>"
  },
  "model_code": {"value": "repo@commit", "status": "verified", "evidence": "..."},
  "dependency_code": {"value": "dependency@commit/build", "status": "unknown", "evidence": "..."},
  "pytorch_version": {"value": "...", "status": "verified", "evidence": "..."},
  "torch_npu_version": {"value": "...", "status": "verified", "evidence": "..."},
  "cann_version": {"value": "...", "status": "verified", "evidence": "..."},
  "workload": {"value": "...", "status": "user-declared", "evidence": "..."},
  "profiler_schedule": {"value": "...", "status": "verified", "evidence": "..."},
  "parallel_topology": {"value": "...", "status": "verified", "evidence": "..."}
}
```

完整文件顶层为 `schema_version`、`real`、`sim`。未观测项写 `status=unknown`，不得省略后在报告中补猜。

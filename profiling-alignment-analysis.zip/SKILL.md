---
name: profiling-alignment-analysis
description: Align real-machine and simulation Huawei Ascend TorchNPU integrated Profiler exports across every same-numbered Rank and observable Host thread/NPU stream without timing analysis. Distinguish PyTorch framework Host operators, CANN/AscendCL/Runtime Host launch bridges, and Device tasks; compare structural operator order, nesting, Shapes, calls, ordinal heatmaps, and direct Host-to-Device links. Trace stable framework divergences through MindSpeed .sh launchers and local MindSpeed/torch/torch_npu checkouts to Python if/elif/else guards, predicate tensors/producers, and line-numbered HTML code snapshots. Produce one large self-contained Chinese Markdown report while keeping CSV/JSON as machine evidence under evidence/. Use for Ascend real-vs-simulator alignment, divergent heatmap paths or control flow, incorrect simulated predicate values, trace_view.json comparison, and code-backed operator-route explanations. Preflight raw msprof or analysis.db-only inputs and degrade explicitly.
---

# 真机 / 仿真 Profiling 控制流对齐

固定 `reference=真机`、`candidate=仿真`。最终报告使用中文；算子名、代码符号、字段、路径和 URL 保留原文。

## 角色与安全门禁

要求用户明确写出：

```text
真机 Profiling（reference）：<目录>
仿真 Profiling（candidate）：<目录>
```

支持在一个公共工作目录内同时放置源码和两侧采集，例如：

```text
<work-root>/
  MindSpeed/                 # 模型/训练入口源码，只读
  torch/                     # PyTorch 源码；默认是真机 reference 基线，只读
  torch_npu/                 # TorchNPU 源码；默认是真机 reference 基线，只读
  real-profiling/            # 真机 reference
  simulation-profiling/      # 仿真 candidate
  output/                    # 本 Skill 唯一写入目录
```

Prompt 必须分别给出 `MindSpeed 源码根`、`torch 源码根`、`torch_npu 源码根`、两侧 Profiling、输出根和模型入口 `.sh`；不能仅给公共目录后按子目录名猜角色。入口只允许从 MindSpeed 根解析。已有任一本地源码 checkout 时直接只读使用，不再 clone。输出根必须与三个源码仓及两侧 Profiling 互不包含。

公共目录里只有一份 `torch/` 或 `torch_npu/` 时，默认把它声明为真机 reference 的源码基线，用于解释真机路线和定位候选代码；不得把它伪称为仿真实际运行绑定，也不得据此声称两侧源码一致。只有用户另给可验证的仿真侧 checkout（例如 `torch-sim/`、`torch_npu-sim/`）及运行绑定证据时，才做双侧源码等价或差异结论。

面向用户的唯一主交付固定为 `<output>/profiling_alignment_report.md`。所有 CSV、JSON、JSONL 和辅助 HTML 只放在 `<output>/evidence/` 下作为机器证据与追溯附件；不得把一串产物路径或下一步操作写成主报告正文来代替分析。

若只有两个目录但角色不明确，停止并只询问角色；不得按路径名、时间戳、事件数或性能猜测。

把原始 Profiling 和源码仓视为只读。把输出放在两侧 Profiling 与源码仓之外；不执行 `.sh`、不 import/运行模型代码、不修改 checkout、不点击 Perfetto Share、不生成公开 trace 链接。

## 本 Skill 的硬约束

- 比较 `sorted(real_global_rank_ids ∩ sim_global_rank_ids)` 的每个同号 Rank。真机 0–7、仿真 0–3 时比较 0、1、2、3；不重编号、不左移、不抽样一个 Rank。
- 分析每个 Rank 内全部含算子的 Host Thread 与 Device stream。不得随机选一个线程代表该 Rank。
- 固定三层语义：`framework_op`（PyTorch/custom `cpu_op`）、`host_launch`（CANN/AscendCL/GE/Runtime/enqueue/dequeue）、`device_task`（Ascend Hardware kernel/HCCL/memcpy/task）。前两层都在 Host；不得因事件名或 args 含 `ACL/CANN/Runtime/Device Id/Stream Id` 就把 Host launch 误判成 Device。
- Host 主键为 `rank+semantic_layer+pid+tid+track`，Device 主键为 `rank+device+stream+track`。只有 namespace 正确且端点唯一的 direct flow/correlation 才建立跨层因果边；`correlation_id` 与 `external_id` 不共享命名空间。
- 只分析 operator presence、calls、顺序、嵌套、Shape/dtype/format、序位位置和控制路径。禁止输出或解释 duration、latency、self/total time、利用率、重叠、空闲、带宽、快慢、性能比率或时间误差。
- 允许解析器内部用 `ts/dur` 配对 `X/B/E`、确定 lane 内顺序/嵌套并恢复 direct flow 端点；不得把这些时间值写入公开证据或报告。
- 把算子“热力图”定义为序位热力图：横轴是 lane 内归一化 event ordinal，不是时间桶。格宽、色块面积和空白不得作性能解释。
- 区分 Shape、tensor identity 与 tensor value。Shape 一致不能证明值一致；缺少直接 predicate operand value 时不得声称“仿真把 tensor 算错”。
- 当前完整输入契约是 TorchNPU 已整合生成的 text export。目录可以名为 `ASCEND_PROFILER_OUTPUT`，也可以是同时含 `trace_view.json` 与 integrated CSV/metadata 的扁平 Rank 目录；必须按内容签名识别并去重，不能只按目录名。`PROF_*/mindstudio_profiler_output/msprof_*.json`、`analysis.db` only 或缺少逐事件 trace 的输入必须标 `unsupported/partial`，先转换或重采，不得解释为零算子。
- Rank 身份只接受 profiler metadata 或明确的 Rank 目录标记；`directory order`/枚举序号永远不是身份证据。逐 Rank、逐 lane 保留 calls；跨 Rank 总 calls 和 kernel/launch 总量只可作 coverage 观察，不能充当首次分叉、guard、Host→Device 或额外 workload 的因果证据。
- Runtime stack 到某个函数或 callsite 只证明该函数可观测，不等于已经识别 `if/elif/else`。只有 AST 中实际存在的 `guard_id + predicate + arm line range` 且两侧 branch-exclusive 算子映射通过门禁，才可称 guard。
- Python 解释器版本和已安装 PyTorch 包版本只作信息记录，默认忽略其差异：它们不阻断结构可比性、不降低控制流证据强度，也不得成为默认根因或“请先对齐版本”的修复建议。真机 reference 是路线与期望行为基线。若 guard 实际属于 `torch/` 源码，仍须绑定该 guard 的准确源码快照；若 guard 属于 `torch_npu/`，两侧 TorchNPU 源码/构建差异仍是关键证据。这里绑定的是 guard 所属代码，不是泛化的安装版本一致性要求。

## 必须执行的工作流

### 1. 固定输入身份

记录两侧绝对路径、三个源码根、模型/权重/配置、workload、phase、Profiler schedule、world size、DP/TP/EP/PP/CP/DCP、运行版本。把证据写入 `<output>/evidence/run_comparability_contract.json`。顶层必须有 `source_roots.model/pytorch/torch_npu`；canonical owner 固定为 `model`（MindSpeed）、`pytorch`（torch）、`torch_npu`，每项必须记录非空 `path/role/binding_side/status/evidence`。单份 `torch/` 和 `torch_npu/` 的 `binding_side` 是 `real/reference`，不能写成 shared 或仿真绑定。至少逐侧记录 `analyzed_source`、`model_code`、`pytorch_version`、`torch_npu_version`、`cann_version`、workload/phase/schedule、input/weights/seed/config、parallel topology；第三方 guard 还要记录 `dependency_code`。普通字段使用 `value/status/evidence`；`analyzed_source` 必须直接包含 `component/repository/commit/tree_hash/build_id/status/evidence`。status 仅为 `verified/user-declared/unknown/conflict`。用户未提供时继续结构提取，但写 `unknown`，不得从报告 prose 反推 verified。把 `pytorch_version` 和 Python 解释器版本标为 `informational/ignored-for-structural-gates`；它们不参与控制流强度门禁。

`analyzed_source` 指本次 `analyze_control_flow.py` 实际索引的源码组件。若候选 guard 位于 TorchNPU/FSDP patch，模型仓 commit 不能替代 TorchNPU 源码/构建绑定。只有两侧 `component/repository/commit/tree_hash` 完全一致、均 `verified`、均有非空 evidence，并与分析器只读取得的实际 Git HEAD/tree/remote 绑定时，才通过源码门禁；否则控制流候选最多为 `静态候选`。

对每个候选按 canonical owner 选择源码根：`model`（MindSpeed）负责模型/训练逻辑，`pytorch`（torch）负责 PyTorch/FSDP 核心，`torch_npu` 负责 TorchNPU patch/lowering。结构化字段始终写 canonical 值，MindSpeed/torch 只作人类可读显示名。`.sh` 入口链始终只从 MindSpeed 解析；不得在 `torch/` 或 `torch_npu/` 中猜模型入口。公共目录已有相应本地 checkout 时优先只读复用，不再 clone。只有所需 owner 源码缺失且用户给出 HTTPS Git 地址时，才把仓库 clone 到 `<output>/evidence/source-checkouts/` 下的新目录。若两侧依赖源码不同且都要作双侧运行绑定，分别准备两个快照；单份 reference 快照只能证明真机基线。完整输入模板见 [references/prompt-template.md](references/prompt-template.md)。

对 URL 使用随 Skill 提供的安全 checkout 工具，不用临时拼接的 `git clone` 命令：

```powershell
python scripts/prepare_source_checkout.py `
  --source-url "<https-repository-or-blob-url>" `
  --commit "<full-commit>" `
  --entry "<optional-entry-sh-or-python>" `
  --output "<output>/evidence/source-checkouts/<unique-checkout>"
```

实际读取 checkout 根下的 `source_checkout_manifest.json`，把 `resolved_head`、`tree_hash`、`repository_url`、`entry` 和 `binding_status` 写入运行契约。未给固定 commit 时工具只允许输出 `partial/unverified` 的导航快照；即使远端 HEAD 成功解析，也不能据此升级本次运行的源码因果。checkout 输出目录必须不存在或为空，并固定使用 `<output>/evidence/source-checkouts/` 这个专用子树；不得放进任一 Profiling、用户源码仓或其它 evidence 子目录。

### 2. 完整读取对齐与报告规范

完整读取 [references/alignment-playbook.md](references/alignment-playbook.md) 和 [references/report-contract.md](references/report-contract.md)，再运行任何分析命令。

### 3. 先做 Ascend 采集与格式预检

```powershell
python scripts/preflight_ascend_profiles.py `
  --real "<real-profile-root>" `
  --sim "<simulation-profile-root>" `
  --output "<output>/evidence/preflight"
```

实际读取 `collection_contract.json` 与 `collection_contract.csv`。确认两侧是否为 integrated text export，以及 `trace_view.json`、`operator_details.csv`、`kernel_details.csv`、`profiler_info*.json` 的可观测性。兼容 integrated 文件直接位于 `rank_0/` 等扁平目录；不得因此误判为空。检查 CPU/NPU activities、`record_shapes`、`with_stack`、`with_modules`、profiler level、schedule/window 与子线程注册证据；文件无法证明的字段写 `unknown`，不猜测。`unsupported` 不继续做完整对齐；`partial` 可继续提取，但报告必须保留门禁与最小重采要求。

### 4. 对齐全部同号 Rank 与全部 lane

运行：

```powershell
python scripts/align_profiles.py `
  --real "<real-profile-root>" `
  --sim "<simulation-profile-root>" `
  --output "<output>/evidence/alignment" `
  --heatmap-bins 64
```

先审计：

```text
analysis_manifest.json
rank_pairs.csv
unpaired_ranks.csv
thread_pairs.csv
parser_warnings.csv
```

确认 `duration_metrics_emitted=false`，`compared_rank_ids` 恰为同号交集，每个 Rank 的 Host/Device lane union 均已登记，ambiguous/unmatched 未被强配。

再读：

```text
canonical_events.csv
event_alignment.csv
divergence_windows.jsonl
host_device_links.csv
structural_heatmap.csv/html
```

按每个 matched lane 报告首次稳定分叉；没有 direct flow 时分别报告 Host 与 Device 差异，不按时间最近补链。

读取 `host_device_links.csv` 时，只有 `causal_eligible=是` 且 `link_status=direct-id/direct-flow` 的唯一端点行可作跨层因果；`degraded-flow-containment` 只作导航线索。

只允许 profiler metadata 的 `rank_id/global_rank` 作为权威 Rank；目录名仅作 fallback。二者冲突时该目录必须进入 `unpaired_ranks.csv`，不得静默择一。`kernel_details.csv` 缺少 Stream ID 时只保留 Rank 级 Device coverage，禁止构造 `stream=unknown` 的可比 lane。

### 5. 获取源码并静态解析 `.sh` 入口

完整读取 [references/source-causality.md](references/source-causality.md)。若输入是 URL，先按第 1 步运行 `prepare_source_checkout.py`；若是本地 checkout，保持只读。然后静态解析一个或多个 `.sh` 或 `.sh` 目录：

```powershell
python scripts/resolve_source_entrypoints.py `
  --repo-root "<MindSpeed-source-root>" `
  --entry "<entry-sh-or-directory>" `
  --output "<output>/evidence/source-entrypoints" `
  --environment "shared-or-real-or-sim"
```

可重复 `--entry`。读取入口候选、shell launch chain、Python target、配置脱敏和 unresolved issues。静态可达性不等于实际运行；结合 argv/log/marker 后才升级。

`resolve_source_entrypoints.py` 只负责从 MindSpeed 的 Bash/launcher 找到 Python 入口，不把 Shell、C++ 或 `torch_npu` lowering 函数当作最终 guard。后续候选若越过 repo 边界，按 stack/path/module owner 切换到明确给出的 `torch` 或 `torch_npu` 根做 AST 与快照；不要把入口脚本复制到依赖仓重新解析。URL 源码必须先成为固定本地快照才能做 AST 与行号证据；网页片段只作导航，不得生成强结论。私有仓不可访问时不索要凭据，继续完成 Profiler-only 分析并列最小缺失文件。

### 6. 把首次 framework Host 分叉映射到 if-else

运行：

```powershell
python scripts/analyze_control_flow.py `
  --repo-root "<owner-source-root: MindSpeed|torch|torch_npu>" `
  --alignment-output "<output>/evidence/alignment" `
  --source-analysis-dir "<output>/evidence/source-entrypoints" `
  --entry "<仅 model owner 使用的 MindSpeed entry-sh-or-python>" `
  --repository-url "<repo-url>" `
  --commit "<full-commit>" `
  --runtime-binding "verified|user-declared|unverified|conflict" `
  --run-contract "<output>/evidence/run_comparability_contract.json" `
  --output "<output>/evidence/source-causality"
```

当 owner 是 `pytorch` 或 `torch_npu` 时省略 `--entry`；依赖源码候选只消费 MindSpeed 的 `--source-analysis-dir` 入口链与两侧 runtime stack，不能把依赖仓中的 guard 文件本身伪装成用户入口。

先为本报告拟升级的首要分叉确定唯一 owner，只在对应源码根中索引 AST，不把一个仓的行号套到另一个仓，并把这一组平铺产物写入 `evidence/source-causality/`。其它 owner 可作源码事实与静态导航；当前一次验证不得把多个 owner 的强结论混装到同一目录。确需升级多个 owner 时，分别生成并验证独立报告或等待工具扩展。若已采集 guard 值，追加 `--runtime-values <csv>`。实际读取：

对 `torch/`、`torch_npu/` 这类大仓，分析器会先从 Profiler stack 提取仓内 `.py` 路径并完整索引这些 scoped 文件，再执行有预算的补充扫描；补充扫描截断不能否定已经完整读取的目标 guard。若 stack 中的路径不完整，可对每个已由 stack/入口证据指向的仓内 Python 文件重复追加 `--include-python <repo-relative.py>`。该参数拒绝绝对路径、越界、symlink/reparse、非 `.py`、缺失文件和解析失败；不得为了找候选而盲目解除整个仓库的文件/字节预算。

```text
control_flow_guard_candidates.csv
control_flow_evidence.jsonl
predicate_tensor_evidence.csv
event_source_map.csv
branch_device_evidence.csv
source_entrypoint_chain.csv
source_evidence.csv
source_analysis_issues.csv
```

只处理 `semantic_layer=framework_op` 的首个 Host 差异；`host_launch` 只能作为框架算子与 NPU task 之间的 bridge 证据，不能直接映射模型 if-else。从 call stack/module/operator 反查固定 Python 源码；stack 的函数帧本身不是 guard。必须输出 `.py` AST `guard_id`、原始 predicate、guard/arm 行范围，确认真机与仿真 callsite 位于同一 guard 的不同 arm，再回溯 predicate operand 的最近静态 producer。C/C++ 只能作为 backend/bridge 导航证据，不能成为模型控制流结论的主代码段。Device 算子只通过唯一 direct link 追加。

强度升级必须同时通过 lane 高置信配对、op-only/op+metadata/tree-aware 三视图同边界、分叉前后 exact anchor 门禁、无更早 unresolved、`.sh`/launcher 入口绑定或行级 stack，以及 guard 所属源码的双侧运行绑定门禁。缺任一项保留为静态候选；公共目录中的单份 `torch/` 或 `torch_npu/` 默认只绑定真机 reference，不能冒充仿真绑定。Python 解释器版本和安装的 PyTorch 包版本不同不影响该门禁；但 guard 若属于 TorchNPU/FSDP patch，TorchNPU 源码/构建差异必须逐侧处理，不能用单侧源码升级。重复层/重复算子导致锚点歧义时不得用 `SequenceMatcher` 的任意平移结果冒充首次因果分叉。

采用且不得混淆四级结论：`已证实控制流分叉`、`强关联控制流分叉`、`静态候选`、`仿真计算错误已证实`。最后一级需要同输入/权重/seed/config/code/rank state、直接 operand 值、最早 producer、语义 oracle 和可重复 A/B 全部成立。

### 7. 用 Perfetto 逐 Rank 内容复核

完整读取 [references/perfetto-review.md](references/perfetto-review.md)。调用 workspace dependency discovery 定位受信 Node.js 和 `playwright-core`，再运行：

```powershell
$env:PERFETTO_PLAYWRIGHT_NODE_MODULES = "<trusted-node_modules>"
python scripts/render_perfetto_batch.py `
  --alignment-output "<output>/evidence/alignment" `
  --output "<output>/evidence/perfetto-review" `
  --online-authorized `
  --node "<trusted-node-executable>"
```

只有用户明确确认数据政策允许时才加 `--online-authorized`。这会对每个同号 Rank 的真机/仿真 `trace_view.json` 分别加载官方 UI；准确语义是“联网获取官方 UI 代码，再离线后把 trace 放入浏览器本地内存”，不是把 trace 文件上传到 Perfetto 服务。默认不截图。只有需要评价 Canvas 颜色/轨道几何时加 `--screenshot`，并实际使用图像查看工具检查 PNG；即使查看也不得从条宽推断耗时。

逐 job 验证官方 origin、`localOnly`、message origin、offline-before-post、Service Worker=0、trace SHA、lane batch 与无 duration SQL。必须实际读取 HTML/text/SQL/manifest/browser log 并写 `perfetto_content_review.json`；其中绑定 `perfetto_batch_manifest.json` SHA，并逐 batch 记录 renderer run_id 以及 manifest/HTML/text/browser-log 的 path/bytes/SHA。只写 Rank/side 而漏掉同侧其它 batch 不算完成；自动产物成功不等于内容复核完成。网络、浏览器、依赖或数据政策阻止时，用同一命令加 `--degraded-reason "<具体原因>"` 写出标准 `not-executed` 记录；明确标“Perfetto 内容复核未执行”，不伪称页面已加载。

### 8. 形成代码证据链

先把每个拟升级的 Python guard 渲染为可审计代码快照：

```powershell
python scripts/render_python_guard_snapshots.py `
  --repo-root "<owner-source-root>" `
  --source-causality-dir "<output>/evidence/source-causality" `
  --output "<output>/evidence/python-guard-snapshots"
```

默认渲染每组 `candidate_rank=1`；报告还要升级其它候选时，对每个候选重复追加 `--evidence-id <id>`。必须实际读取 `python_guard_snapshots.json/csv/md/html`。只从 `python_guard_snapshots.md` 复制对应 `evidence_id` 的完整 `<details open>...</details>` 静态 HTML 片段到主 Markdown，不改代码、行号或 metadata。代码表必须来自真实 `.py` 文件，逐行显示原始 1-based 行号，并区分 predicate、真机 arm、仿真 arm；C/C++ 只能另列为 backend/bridge 线索。渲染器拒绝路径越界、symlink/reparse、非 `.py`、HEAD/tree/源码 SHA/契约冲突；失败时该候选不能保留 `强关联` 或 `已证实`。

每个重大分叉给出：

```text
Rank/Host Thread
  -> 最后共同 operator anchor
  -> 真机/仿真首个不同 operator+Shape
  -> fixed repo@commit file:symbol:guard lines
  -> 真机 arm / 仿真 arm
  -> predicate operand 与静态/runtime producer
  -> branch-exclusive Host operators
  -> direct-linked Device kernels（若有）
```

同时列替代解释：采集窗口、workload/Shape、lane 错配、backend lowering、图捕获、instrumentation、guard owner 源码/构建冲突。不要把 Python/PyTorch 安装版本差异列为兜底解释。没有直接 tensor value 时给最小 runtime hook，不补造值。

### 9. 汇编、解释并交付一份大型中文主报告

主报告是唯一面向用户的主交付，不是 README、guide 或产物索引。先用汇编器把全部结构化证据写入 `<output>/profiling_alignment_report.md`：

```powershell
python scripts/build_alignment_report.py `
  --alignment-output "<output>/evidence/alignment" `
  --preflight-dir "<output>/evidence/preflight" `
  --run-contract "<output>/evidence/run_comparability_contract.json" `
  --source-causality-dir "<output>/evidence/source-causality" `
  --python-snapshots-dir "<output>/evidence/python-guard-snapshots" `
  --perfetto-review-dir "<output>/evidence/perfetto-review" `
  --output "<output>/profiling_alignment_report.md"
```

实际读取汇编后的 Markdown，再由代理补充证据解释、替代解释和最小验证动作；不得删掉汇编器生成的逐 Rank、逐 lane、逐 divergence 正文，也不得把正文包进 fenced code block 或四空格缩进代码块。Python `<details>` 快照必须位于正常 Markdown flow，不能放在代码围栏里伪装成已嵌入。报告必须自包含：正文内完整展开每个同号 Rank、全部 matched/ambiguous/unmatched Host/Device lane、每 lane 首次分叉上下文、序位热力图摘要、Host→Device 证据、源码入口链、每个重大 Python guard 快照、predicate tensor/producer、结论强度与建议。每个 Rank 必须有独立证据段；只有逐 Rank 结构化结果都相同，才能另加“Rank 0–3 共同模式”摘要。CSV/JSON/JSONL/辅助 HTML 只存在于 `<output>/evidence/`，正文可以用短证据引用追溯，但不能要求读者打开附件才能知道关键事实、代码段或结论。

报告不得只写 Key Finding、Outputs、Recommendations 三段，不得用大量“见某 CSV/目录”占位，也不得把命令、文件清单和补证步骤写成正文主体。正文篇幅由实际 Rank/lane/divergence 数量驱动；没有实质分析内容时不允许以 validation pass 作为交付理由。

最后运行机器门禁；非零退出码时先修报告或降级结论，不得交付失败版本：

```powershell
python scripts/validate_alignment_report.py `
  --report "<output>/profiling_alignment_report.md" `
  --alignment-output "<output>/evidence/alignment" `
  --source-causality-dir "<output>/evidence/source-causality" `
  --run-contract "<output>/evidence/run_comparability_contract.json" `
  --python-snapshots-dir "<output>/evidence/python-guard-snapshots" `
  --perfetto-review-dir "<output>/evidence/perfetto-review" `
  --output "<output>/evidence/report-validation"
```

实际读取 `report_validation.json` 与 `report_validation.csv`，确认 `status=pass`、`blocking_error_count=0`。报告若含 C0 控制字符、Unicode `Cf` 零宽/双向字符或 HTML comment 必须阻断；只允许 LF 或成对 CRLF 行尾，不允许 TAB、BEL、FF 或 token 内 standalone CR。除逐字复制且已验证的 Python `<details>` 快照外，prose 不使用 raw HTML。不要自动猜测 `\a`、`\t`、`\f`、`\r` 原本想表示的算子或路径，回到原始 UTF-8 证据重新生成。

## 交付前检查

- 公共工作目录中的 MindSpeed、torch、torch_npu、真机 Profiling、仿真 Profiling 和输出六个子树身份明确且互不包含；相对 `.sh` 只从 MindSpeed 根解析。
- run contract 顶层存在 `source_roots.model/pytorch/torch_npu`，每项均有 `path/role/binding_side/status/evidence`；owner 结构化值使用 `model`（MindSpeed）、`pytorch`（torch）、`torch_npu`。
- 已有本地源码 checkout 时未重复 clone；单份 torch/torch_npu 只标为真机 reference 基线，未伪称仿真运行绑定。
- 真机/仿真角色和源码版本绑定全程一致。
- 所有同号 Rank 均分析；额外 Rank 明确列为 unpaired。
- 每 Rank 的全部 operator-bearing Host/Device lane 均在 union 中；未随机抽样。
- Host 与 Device 分表；跨域结论都有 direct flow/correlation。
- `framework_op`、`host_launch`、`device_task` 分层展示；Host bridge 不冒充 NPU kernel，也不冒充模型算子。
- 重复调用数作为结构事实保留；真机 2 次与仿真 3 次同名连续调用不得判 `exact`。
- 主报告是根目录唯一用户交付；CSV/JSON/JSONL/辅助 HTML 全部位于 `evidence/`，且报告已逐 Rank/lane/divergence 自包含展开而不是产物目录或操作指南。
- 报告和 evidence 表不含 duration/latency/性能比率或快慢判断。
- Python 解释器和已安装 PyTorch 包版本差异仅作 informational，未参与结构/强度门禁，也未被建议强行对齐；guard owner 源码仍按实际组件绑定。
- 序位热力图未被称为时间热力图。
- 每条 guard 结论可回到 rank/thread/event/operator/Shape/source line。
- 每条 `强关联/已证实` 结论都能回到结构化 candidate 的同等强度、AST guard、两侧 verified-equal `analyzed_source`，而非 stack 函数名或聚合 calls。
- 每条 `强关联/已证实` 结论都引用同一 `evidence_id` 的 Python 快照，且主 Markdown 内嵌了带原始行号的完整静态 HTML 片段；只有 C/C++ 代码时必须降级。
- `directory order` 未被用作 Rank 身份；`N/A/unknown` stream 未被计为 matched Device lane。
- 报告无 C0/Unicode format control、HTML comment 或未验证 raw HTML，且 `report_validation.json` 为 pass。
- 没有直接 predicate operand value 时未声称仿真数值错误。
- Perfetto HTML/text/SQL 由代理实际读取；未看 PNG 时未评价 Canvas。
- 报告中的 Perfetto complete/partial/not-executed 与 `--perfetto-review-dir` 的 batch/content-review 状态逐 Rank/side/job 一致，complete 产物 hash 未变化。
- 原始 Profiling、源码 checkout 和远端仓库均未修改。

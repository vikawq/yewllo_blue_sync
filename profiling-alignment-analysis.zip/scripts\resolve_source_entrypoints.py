#!/usr/bin/env python3
"""Conservatively resolve shell launch entrypoints without executing repository code.

The resolver reads only files below ``--repo-root``. It never sources shell files,
evaluates substitutions, imports project Python modules, or invokes repository
commands. Dynamic constructs are preserved as unresolved evidence.
"""

from __future__ import annotations

import argparse
import csv
import hashlib
import json
import os
import re
import shlex
import sys
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Iterable
from urllib.parse import urlsplit, urlunsplit


CANDIDATE_FIELDS = [
    "candidate_id",
    "environment",
    "entry_path",
    "entry_kind",
    "discovered_from",
    "source_location",
    "score",
    "selection_status",
    "selection_reason",
    "runtime_binding",
    "content_sha256",
    "evidence_ids",
    "confidence",
    "limitations",
]

CHAIN_FIELDS = [
    "chain_id",
    "environment",
    "step_index",
    "source_path",
    "line_start",
    "line_end",
    "node_kind",
    "edge_type",
    "target",
    "guard_or_config",
    "symbolic_cwd",
    "normalized_command_redacted",
    "resolution_status",
    "evidence_ids",
    "confidence",
    "notes",
]

LAUNCH_FIELDS = [
    "candidate_id",
    "chain_id",
    "environment",
    "source_path",
    "line_start",
    "line_end",
    "launcher",
    "wrapper_chain",
    "python_mode",
    "python_target",
    "argv_keys",
    "config_paths",
    "environment_keys",
    "topology_keys",
    "selection_status",
    "runtime_match",
    "evidence_ids",
    "confidence",
    "limitations",
]

CONFIG_FIELDS = [
    "environment",
    "chain_id",
    "config_key",
    "value_redacted",
    "value_origin",
    "source_location",
    "runtime_observed",
    "evidence_ids",
    "confidence",
]

ISSUE_FIELDS = [
    "issue_id",
    "environment",
    "chain_id",
    "source_location",
    "issue_kind",
    "expression_redacted",
    "impact",
    "status",
    "minimum_user_input",
]

SENSITIVE_RE = re.compile(
    r"(?:token|pass(?:word)?|secret|api[_-]?key|private[_-]?key|cookie|credential|auth(?:orization)?)",
    re.IGNORECASE,
)
ASSIGNMENT_RE = re.compile(r"^([A-Za-z_][A-Za-z0-9_]*)=(.*)$", re.DOTALL)
PYTHON_RE = re.compile(r"^python(?:\d+(?:\.\d+)*)?$", re.IGNORECASE)
TOPOLOGY_RE = re.compile(
    r"(?:^|[-_])(?:world[-_]?size|nproc|nnodes|node[-_]?rank|local[-_]?rank|"
    r"tensor[-_]?parallel|pipeline[-_]?parallel|expert[-_]?parallel|data[-_]?parallel|"
    r"context[-_]?parallel|tp|dp|ep|pp|cp|dcp)(?:$|[-_])",
    re.IGNORECASE,
)
DYNAMIC_MARKERS = ("$(", "`", "${!", "<(", ">(", "$(<", "$((")

SIMPLE_WRAPPERS = {
    "nohup",
    "timeout",
    "taskset",
    "numactl",
    "nice",
    "stdbuf",
    "setsid",
}
SHELLS = {"bash", "sh", "dash", "zsh", "ksh"}
LAUNCHERS = {
    "torchrun",
    "deepspeed",
    "msrun",
    "srun",
    "mpirun",
    "mpiexec",
}
PYTHON_FLAG_WITH_VALUE = {"-W", "-X"}
PYTHON_FLAG_NO_VALUE = {"-u", "-O", "-OO", "-B", "-E", "-s", "-S", "-v", "-q", "-I"}


def is_within(path: Path, root: Path) -> bool:
    try:
        path.relative_to(root)
        return True
    except ValueError:
        return False


def sanitize_url(value: str) -> str:
    if not re.match(r"^https?://", value, re.IGNORECASE):
        return value
    try:
        parts = urlsplit(value)
    except ValueError:
        return "<invalid-url>"
    host = parts.hostname or ""
    if parts.port:
        host = f"{host}:{parts.port}"
    fragment = parts.fragment if re.fullmatch(r"L\d+(?:-L\d+)?", parts.fragment or "") else ""
    return urlunsplit((parts.scheme, host, parts.path, "", fragment))


def redact_text(value: str) -> str:
    value = re.sub(
        r"(?i)\b([A-Za-z_][A-Za-z0-9_]*(?:TOKEN|PASS(?:WORD)?|SECRET|API[_-]?KEY|COOKIE|CREDENTIAL|AUTH)[A-Za-z0-9_]*)\s*=\s*(?:\"[^\"]*\"|'[^']*'|[^\s;]+)",
        lambda match: f"{match.group(1)}=[REDACTED]",
        value,
    )
    value = re.sub(
        r"(?i)(--(?:token|password|pass|secret|api[-_]?key|cookie|credential|auth))(?:=|\s+)(?:\"[^\"]*\"|'[^']*'|[^\s;]+)",
        lambda match: f"{match.group(1)}=[REDACTED]",
        value,
    )
    return re.sub(r"https?://[^\s'\"]+", lambda match: sanitize_url(match.group(0)), value)


def redact_tokens(tokens: Iterable[str]) -> list[str]:
    result: list[str] = []
    redact_next = False
    for token in tokens:
        if redact_next:
            result.append("[REDACTED]")
            redact_next = False
            continue
        if token.startswith("--"):
            key, separator, _ = token.partition("=")
            if SENSITIVE_RE.search(key):
                result.append(f"{key}=[REDACTED]" if separator else key)
                redact_next = not bool(separator)
                continue
        assignment = ASSIGNMENT_RE.match(token)
        if assignment and SENSITIVE_RE.search(assignment.group(1)):
            result.append(f"{assignment.group(1)}=[REDACTED]")
            continue
        result.append(sanitize_url(token))
    return result


def write_csv(path: Path, fieldnames: list[str], rows: list[dict[str, Any]]) -> None:
    with path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fieldnames, extrasaction="ignore")
        writer.writeheader()
        writer.writerows(rows)


@dataclass
class Budgets:
    max_files: int
    max_bytes: int
    max_depth: int
    files_read: int = 0
    bytes_read: int = 0


class Resolver:
    def __init__(
        self,
        repo_root: Path,
        output: Path,
        environment: str,
        budgets: Budgets,
    ) -> None:
        self.repo_root = repo_root.resolve(strict=True)
        self.output = output.resolve(strict=False)
        self.environment = environment
        self.budgets = budgets
        self.file_cache: dict[Path, str] = {}
        self.candidates: list[dict[str, Any]] = []
        self.chain_rows: list[dict[str, Any]] = []
        self.launch_rows: list[dict[str, Any]] = []
        self.config_rows: list[dict[str, Any]] = []
        self.issue_rows: list[dict[str, Any]] = []
        self._chain_steps: dict[str, int] = {}
        self._issue_count = 0
        self._config_keys_seen: set[tuple[str, ...]] = set()
        self._launch_keys_seen: set[tuple[str, ...]] = set()
        self._candidate_by_path: dict[Path, dict[str, Any]] = {}
        self._partial = False

    def rel(self, path: Path | None) -> str:
        if path is None:
            return "未知"
        try:
            return path.resolve(strict=False).relative_to(self.repo_root).as_posix() or "."
        except ValueError:
            return "<仓库外>"

    def add_issue(
        self,
        kind: str,
        *,
        chain_id: str = "",
        source: str = "",
        expression: str = "",
        impact: str,
        minimum: str = "无需补充；保留为未知",
    ) -> None:
        self._issue_count += 1
        self.issue_rows.append(
            {
                "issue_id": f"issue-{self._issue_count:04d}",
                "environment": self.environment,
                "chain_id": chain_id,
                "source_location": source,
                "issue_kind": kind,
                "expression_redacted": redact_text(expression),
                "impact": impact,
                "status": "unresolved",
                "minimum_user_input": minimum,
            }
        )

    def _has_symlink_component(self, path: Path) -> bool:
        try:
            # Do not call resolve() here: resolving first would hide a symlink in
            # an intermediate component, which is exactly what this guard checks.
            lexical = Path(os.path.abspath(path))
            relative = lexical.relative_to(self.repo_root)
        except ValueError:
            return True
        current = self.repo_root
        for part in relative.parts:
            current = current / part
            try:
                if current.is_symlink():
                    return True
            except OSError:
                return True
        return False

    def normalize_entry(self, value: str) -> Path | None:
        raw = Path(value)
        path = raw if raw.is_absolute() else self.repo_root / raw
        resolved = path.resolve(strict=False)
        if not is_within(resolved, self.repo_root):
            self.add_issue(
                "outside_repo",
                source=value,
                expression=value,
                impact="入口位于仓库边界之外，拒绝读取",
                minimum="提供仓库内相对路径",
            )
            return None
        if self._has_symlink_component(path):
            self.add_issue(
                "symlink_rejected",
                source=self.rel(path),
                expression=value,
                impact="入口路径包含 symlink，拒绝跟随",
                minimum="提供固定 commit 中的普通文件路径",
            )
            return None
        if not resolved.exists():
            self.add_issue(
                "entry_not_found",
                source=self.rel(resolved),
                expression=value,
                impact="无法枚举入口候选",
                minimum="提供存在的 .sh 文件或目录",
            )
            return None
        return resolved

    def read_text(self, path: Path, chain_id: str = "") -> str | None:
        path = path.resolve(strict=False)
        if path in self.file_cache:
            return self.file_cache[path]
        source = self.rel(path)
        if not is_within(path, self.repo_root):
            self.add_issue(
                "outside_repo",
                chain_id=chain_id,
                source=source,
                expression=str(path),
                impact="目标位于仓库外，停止静态追踪",
                minimum="提供仓库内目标文件",
            )
            return None
        if self._has_symlink_component(path) or path.is_symlink():
            self.add_issue(
                "symlink_rejected",
                chain_id=chain_id,
                source=source,
                expression=source,
                impact="拒绝跟随 symlink",
                minimum="提供普通文件快照",
            )
            return None
        if not path.is_file():
            self.add_issue(
                "target_not_file",
                chain_id=chain_id,
                source=source,
                expression=source,
                impact="目标不是可读普通文件",
                minimum="提供普通文本文件",
            )
            return None
        if self.budgets.files_read >= self.budgets.max_files:
            self._partial = True
            self.add_issue(
                "file_budget_exceeded",
                chain_id=chain_id,
                source=source,
                expression=source,
                impact="达到文件预算，后续入口链不完整",
                minimum="缩小入口目录或提高 --max-files",
            )
            return None
        try:
            size = path.stat().st_size
        except OSError as exc:
            self.add_issue(
                "read_error",
                chain_id=chain_id,
                source=source,
                expression=str(exc),
                impact="无法读取目标文件",
                minimum="提供可读文件",
            )
            return None
        if self.budgets.bytes_read + size > self.budgets.max_bytes:
            self._partial = True
            self.add_issue(
                "byte_budget_exceeded",
                chain_id=chain_id,
                source=source,
                expression=f"size={size}",
                impact="达到字节预算，后续入口链不完整",
                minimum="缩小入口目录或提高 --max-bytes",
            )
            return None
        try:
            data = path.read_bytes()
        except OSError as exc:
            self.add_issue(
                "read_error",
                chain_id=chain_id,
                source=source,
                expression=str(exc),
                impact="无法读取目标文件",
                minimum="提供可读文件",
            )
            return None
        self.budgets.files_read += 1
        self.budgets.bytes_read += len(data)
        text = data.decode("utf-8-sig", errors="replace")
        if "\ufffd" in text:
            self.add_issue(
                "decode_replacement",
                chain_id=chain_id,
                source=source,
                expression="UTF-8 replacement characters present",
                impact="部分字符无法精确解析",
            )
        self.file_cache[path] = text
        return text

    def discover(self, entry_values: list[str]) -> None:
        discovered: dict[Path, str] = {}
        stop = False
        for entry_value in entry_values:
            entry = self.normalize_entry(entry_value)
            if entry is None:
                continue
            if entry.is_file():
                if entry.suffix.lower() != ".sh":
                    self.add_issue(
                        "unsupported_entry_type",
                        source=self.rel(entry),
                        expression=self.rel(entry),
                        impact="当前解析器只把 .sh 作为 shell 入口候选",
                        minimum="提供 .sh 文件或目录",
                    )
                    continue
                discovered[entry] = entry_value
                continue
            for current, dirnames, filenames in os.walk(entry, followlinks=False):
                current_path = Path(current)
                kept_dirs: list[str] = []
                for dirname in sorted(dirnames):
                    child = current_path / dirname
                    if dirname in {".git", ".venv", "venv", "node_modules", "__pycache__"}:
                        continue
                    if is_within(self.output, child.resolve(strict=False)) or child.is_symlink():
                        continue
                    kept_dirs.append(dirname)
                dirnames[:] = kept_dirs
                for filename in sorted(filenames):
                    if not filename.lower().endswith(".sh"):
                        continue
                    path = (current_path / filename).resolve(strict=False)
                    if path.is_symlink() or not is_within(path, self.repo_root):
                        self.add_issue(
                            "symlink_rejected",
                            source=self.rel(path),
                            expression=self.rel(path),
                            impact="候选是 symlink 或越过仓库边界，拒绝读取",
                        )
                        continue
                    discovered.setdefault(path, entry_value)
                    if len(discovered) >= self.budgets.max_files:
                        self._partial = True
                        self.add_issue(
                            "candidate_budget_exceeded",
                            source=self.rel(entry),
                            expression=f"max_files={self.budgets.max_files}",
                            impact="候选目录被截断，可能遗漏启动脚本",
                            minimum="缩小 --entry 范围或提高 --max-files",
                        )
                        stop = True
                        break
                if stop:
                    break
            if stop:
                break

        ranked: list[tuple[int, str, Path, str, str, str]] = []
        for path, discovered_from in sorted(discovered.items(), key=lambda item: self.rel(item[0])):
            text = self.read_text(path)
            score, reasons = self.score_candidate(path, text)
            digest = hashlib.sha256(redact_text(text or "").encode("utf-8")).hexdigest() if text is not None else ""
            ranked.append((score, self.rel(path), path, discovered_from, "; ".join(reasons), digest))

        if not ranked:
            self.add_issue(
                "no_shell_candidates",
                impact="没有可分析的 .sh 入口候选",
                minimum="提供仓库内 .sh 文件或包含 .sh 的目录",
            )
            return

        ranked.sort(key=lambda item: (-item[0], item[1]))
        best_score = ranked[0][0]
        ties = [item for item in ranked if item[0] == best_score]
        if len(ties) > 1:
            self.add_issue(
                "entrypoint_tie",
                expression=", ".join(item[1] for item in ties[:20]),
                impact="多个脚本静态得分相同；确定性选择仅用于分析导航，不证明实际执行",
                minimum="提供 runtime argv、启动日志或明确入口脚本",
            )

        for index, (score, relpath, path, discovered_from, reasons, digest) in enumerate(ranked, 1):
            selected = index == 1
            row = {
                "candidate_id": f"entry-{index:04d}",
                "environment": self.environment,
                "entry_path": relpath,
                "entry_kind": "shell_file",
                "discovered_from": sanitize_url(discovered_from),
                "source_location": f"{relpath}:1",
                "score": score,
                "selection_status": "analysis_selected" if selected else "candidate",
                "selection_reason": reasons or "未发现已知 launcher；按路径确定性排序",
                "runtime_binding": "static_candidate",
                "content_sha256": digest,
                "evidence_ids": "",
                "confidence": "静态候选" if digest else "未知",
                "limitations": "静态发现不证明该脚本在本次 Profiling 中实际执行",
            }
            self.candidates.append(row)
            self._candidate_by_path[path] = row

    @staticmethod
    def score_candidate(path: Path, text: str | None) -> tuple[int, list[str]]:
        if text is None:
            return -1000, ["内容未读取"]
        score = 0
        reasons: list[str] = []
        checks = [
            (r"\btorchrun\b|python(?:\d+(?:\.\d+)*)?\s+-m\s+torch\.distributed\.(?:run|launch)", 70, "分布式 PyTorch launcher"),
            (r"\b(?:deepspeed|msrun|srun|mpirun|mpiexec)\b|\baccelerate\s+launch\b", 55, "分布式/并行 launcher"),
            (r"\bpython(?:\d+(?:\.\d+)*)?\b[^\n]*(?:-m\s+[A-Za-z_]|\.py\b)", 40, "Python 入口"),
            (r"\b(?:bash|sh)\b[^\n]*\.sh\b", 20, "嵌套 shell"),
        ]
        for pattern, points, reason in checks:
            if re.search(pattern, text, re.IGNORECASE):
                score += points
                reasons.append(reason)
        lowered_name = path.name.lower()
        if re.search(r"(?:run|start|launch|infer|serve|generate|profile|train)", lowered_name):
            score += 12
            reasons.append("入口型文件名")
        if re.search(r"(?:install|setup|build|clean|test|env)", lowered_name):
            score -= 25
            reasons.append("安装/构建/环境型文件名降权")
        if text.startswith("#!"):
            score += 2
        return score, reasons

    @staticmethod
    def _ends_with_continuation(line: str) -> bool:
        stripped = line.rstrip("\r\n")
        count = 0
        for char in reversed(stripped):
            if char == "\\":
                count += 1
            else:
                break
        return count % 2 == 1

    def logical_statements(self, path: Path, text: str, chain_id: str) -> list[tuple[str, int, int]]:
        result: list[tuple[str, int, int]] = []
        buffer: list[str] = []
        start_line = 1
        heredoc_end: str | None = None
        heredoc_strip_tabs = False
        for line_number, physical in enumerate(text.splitlines(), 1):
            if heredoc_end is not None:
                candidate = physical.lstrip("\t") if heredoc_strip_tabs else physical
                if candidate.strip() == heredoc_end:
                    heredoc_end = None
                continue
            if not buffer:
                start_line = line_number
            continuation = self._ends_with_continuation(physical)
            buffer.append(physical.rstrip()[:-1] if continuation else physical)
            if continuation:
                continue
            statement = " ".join(part.strip() for part in buffer).strip()
            buffer = []
            if not statement:
                continue
            heredoc = re.search(r"<<(-?)\s*(['\"]?)([A-Za-z_][A-Za-z0-9_]*)\2", statement)
            if heredoc:
                heredoc_end = heredoc.group(3)
                heredoc_strip_tabs = bool(heredoc.group(1))
                self.add_issue(
                    "heredoc_unresolved",
                    chain_id=chain_id,
                    source=f"{self.rel(path)}:{start_line}",
                    expression=statement,
                    impact="heredoc 内容被跳过且不会交给解释器执行",
                )
            result.append((statement, start_line, line_number))
        if buffer:
            self.add_issue(
                "unterminated_continuation",
                chain_id=chain_id,
                source=f"{self.rel(path)}:{start_line}",
                expression=" ".join(buffer),
                impact="未终止续行无法可靠解析",
                minimum="提供完整脚本快照",
            )
        if heredoc_end is not None:
            self.add_issue(
                "unterminated_heredoc",
                chain_id=chain_id,
                source=f"{self.rel(path)}:{start_line}",
                expression=heredoc_end,
                impact="未终止 heredoc，后续内容未解析",
                minimum="提供完整脚本快照",
            )
        return result

    @staticmethod
    def tokenize(statement: str) -> list[str]:
        lexer = shlex.shlex(statement, posix=True, punctuation_chars=";&|()<>")
        lexer.whitespace_split = True
        lexer.commenters = "#"
        return list(lexer)

    @staticmethod
    def split_commands(tokens: list[str]) -> list[list[str]]:
        result: list[list[str]] = []
        current: list[str] = []
        separators = {";", "&&", "||", "|", "&", "(", ")", "{", "}"}
        for token in tokens:
            if token in separators:
                if current:
                    result.append(current)
                    current = []
                continue
            current.append(token)
        if current:
            result.append(current)
        return result

    def _record_config(
        self,
        chain_id: str,
        key: str,
        value: str,
        origin: str,
        source: str,
        confidence: str,
    ) -> None:
        redacted = "[REDACTED]" if SENSITIVE_RE.search(key) else redact_text(value)
        unique = (chain_id, key, redacted, origin, source)
        if unique in self._config_keys_seen:
            return
        self._config_keys_seen.add(unique)
        self.config_rows.append(
            {
                "environment": self.environment,
                "chain_id": chain_id,
                "config_key": key,
                "value_redacted": redacted,
                "value_origin": origin,
                "source_location": source,
                "runtime_observed": "否",
                "evidence_ids": "",
                "confidence": confidence,
            }
        )

    def _next_step(self, chain_id: str) -> int:
        self._chain_steps[chain_id] = self._chain_steps.get(chain_id, 0) + 1
        return self._chain_steps[chain_id]

    def _add_chain(
        self,
        chain_id: str,
        path: Path,
        line_start: int,
        line_end: int,
        node_kind: str,
        edge_type: str,
        target: str,
        command_tokens: list[str],
        resolution: str,
        *,
        cwd: Path | None,
        guard: str = "",
        notes: str = "",
    ) -> None:
        self.chain_rows.append(
            {
                "chain_id": chain_id,
                "environment": self.environment,
                "step_index": self._next_step(chain_id),
                "source_path": self.rel(path),
                "line_start": line_start,
                "line_end": line_end,
                "node_kind": node_kind,
                "edge_type": edge_type,
                "target": sanitize_url(target),
                "guard_or_config": redact_text(guard),
                "symbolic_cwd": self.rel(cwd) if cwd is not None else "未知",
                "normalized_command_redacted": " ".join(redact_tokens(command_tokens)),
                "resolution_status": resolution,
                "evidence_ids": "",
                "confidence": "静态候选" if resolution == "resolved" else "未知",
                "notes": notes,
            }
        )

    def _expand_static(self, value: str, variables: dict[str, str | None]) -> tuple[str | None, str]:
        if any(marker in value for marker in DYNAMIC_MARKERS):
            return None, "dynamic_expression"

        used_default = False

        def default_repl(match: re.Match[str]) -> str:
            nonlocal used_default
            name, default = match.group(1), match.group(2)
            known = variables.get(name)
            if known is not None:
                return known
            used_default = True
            return default

        expanded = re.sub(r"\$\{([A-Za-z_][A-Za-z0-9_]*)[:-]-(.*?)\}", default_repl, value)
        unresolved = False

        def variable_repl(match: re.Match[str]) -> str:
            nonlocal unresolved
            name = match.group(1) or match.group(2)
            known = variables.get(name)
            if known is None:
                unresolved = True
                return match.group(0)
            return known

        expanded = re.sub(r"\$\{([A-Za-z_][A-Za-z0-9_]*)\}|\$([A-Za-z_][A-Za-z0-9_]*)", variable_repl, expanded)
        if unresolved or "$" in expanded or "`" in expanded:
            return None, "unknown_variable"
        return expanded, "shell_default" if used_default else "shell_literal"

    def _record_assignment(
        self,
        token: str,
        variables: dict[str, str | None],
        chain_id: str,
        source: str,
    ) -> None:
        match = ASSIGNMENT_RE.match(token)
        if not match:
            return
        name, raw_value = match.group(1), match.group(2)
        if SENSITIVE_RE.search(name):
            variables[name] = None
            self._record_config(chain_id, name, "[REDACTED]", "shell_assignment", source, "已脱敏")
            return
        expanded, origin = self._expand_static(raw_value, variables)
        variables[name] = expanded
        self._record_config(
            chain_id,
            name,
            expanded if expanded is not None else "<unresolved>",
            origin if expanded is not None else "dynamic_shell_expression",
            source,
            "静态候选" if expanded is not None else "未知",
        )

    def _try_script_dir_anchor(
        self,
        statement: str,
        path: Path,
        variables: dict[str, str | None],
        chain_id: str,
        source: str,
    ) -> bool:
        match = re.match(r"^(?:export\s+)?([A-Za-z_][A-Za-z0-9_]*)=(.*)$", statement, re.DOTALL)
        if not match:
            return False
        expression = match.group(2)
        if (
            not expression.strip().endswith(")")
            or "dirname" not in expression
            or not re.search(r"(?:\$0|BASH_SOURCE\s*\[\s*0\s*\])", expression)
        ):
            return False
        name = match.group(1)
        variables[name] = str(path.parent.resolve(strict=False))
        self._record_config(chain_id, name, f"<script-dir:{self.rel(path.parent)}>", "recognized_script_dir_idiom", source, "静态候选")
        return True

    def _resolve_repo_path(
        self,
        raw: str,
        variables: dict[str, str | None],
        current_file: Path,
        cwd: Path | None,
    ) -> tuple[Path | None, str]:
        expanded, reason = self._expand_static(raw, variables)
        if expanded is None:
            return None, reason
        candidate = Path(expanded)
        attempts: list[Path] = []
        if candidate.is_absolute():
            attempts = [candidate]
        elif cwd is not None:
            attempts = [cwd / candidate]
        else:
            attempts = [current_file.parent / candidate, self.repo_root / candidate]
        valid: list[Path] = []
        for attempt in attempts:
            resolved = attempt.resolve(strict=False)
            if not is_within(resolved, self.repo_root):
                continue
            if self._has_symlink_component(attempt):
                continue
            if resolved.exists():
                valid.append(resolved)
        unique = sorted(set(valid), key=lambda item: self.rel(item))
        if len(unique) == 1:
            return unique[0], "resolved"
        if len(unique) > 1:
            return None, "ambiguous_cwd"
        for attempt in attempts:
            resolved = attempt.resolve(strict=False)
            if not is_within(resolved, self.repo_root):
                return None, "outside_repo"
        return None, "not_found"

    @staticmethod
    def _first_non_option(tokens: list[str], start: int = 0) -> int | None:
        index = start
        while index < len(tokens):
            token = tokens[index]
            if token == "--":
                return index + 1 if index + 1 < len(tokens) else None
            if token.startswith("-"):
                index += 1
                continue
            return index
        return None

    @staticmethod
    def _find_command_token(tokens: list[str], start: int = 0) -> int | None:
        for index in range(start, len(tokens)):
            token = tokens[index]
            base = Path(token).name.lower()
            if (
                PYTHON_RE.match(base)
                or base in SHELLS
                or base in LAUNCHERS
                or base in SIMPLE_WRAPPERS
                or base in {"accelerate", "uv", "poetry", "conda"}
                or token.lower().endswith((".py", ".sh"))
            ):
                return index
        return None

    def _record_cli_configs(
        self,
        tokens: list[str],
        variables: dict[str, str | None],
        chain_id: str,
        source: str,
    ) -> tuple[list[str], list[str], list[str]]:
        argv_keys: set[str] = set()
        config_paths: set[str] = set()
        topology_keys: set[str] = set()
        index = 0
        while index < len(tokens):
            token = tokens[index]
            if not token.startswith("--"):
                index += 1
                continue
            key, separator, value = token.partition("=")
            if not separator and index + 1 < len(tokens) and not tokens[index + 1].startswith("-"):
                value = tokens[index + 1]
                index += 1
            argv_keys.add(key)
            if not value:
                value = "<flag>"
            expanded, origin = self._expand_static(value, variables)
            safe_value = expanded if expanded is not None else "<unresolved>"
            self._record_config(
                chain_id,
                key,
                "[REDACTED]" if SENSITIVE_RE.search(key) else safe_value,
                "cli_arg" if expanded is not None else "dynamic_cli_arg",
                source,
                "静态候选" if expanded is not None else "未知",
            )
            if "config" in key.lower() and safe_value not in {"<flag>", "<unresolved>"}:
                config_paths.add(redact_text(safe_value))
            if TOPOLOGY_RE.search(key):
                topology_keys.add(key)
            index += 1
        return sorted(argv_keys), sorted(config_paths), sorted(topology_keys)

    def _record_launch(
        self,
        candidate_id: str,
        chain_id: str,
        path: Path,
        line_start: int,
        line_end: int,
        launcher: str,
        wrappers: list[str],
        python_mode: str,
        python_target: str,
        args: list[str],
        variables: dict[str, str | None],
        limitation: str = "静态入口链不证明本次运行实际经过该调用",
    ) -> None:
        source = f"{self.rel(path)}:{line_start}-{line_end}"
        argv_keys, config_paths, topology_keys = self._record_cli_configs(args, variables, chain_id, source)
        key = (candidate_id, chain_id, source, launcher, python_mode, python_target)
        if key in self._launch_keys_seen:
            return
        self._launch_keys_seen.add(key)
        candidate = next((item for item in self.candidates if item["candidate_id"] == candidate_id), None)
        confidence = "未知" if "$" in python_target or "<unresolved>" in python_target else "静态候选"
        self.launch_rows.append(
            {
                "candidate_id": candidate_id,
                "chain_id": chain_id,
                "environment": self.environment,
                "source_path": self.rel(path),
                "line_start": line_start,
                "line_end": line_end,
                "launcher": launcher,
                "wrapper_chain": " -> ".join(wrappers),
                "python_mode": python_mode,
                "python_target": python_target,
                "argv_keys": ";".join(argv_keys),
                "config_paths": ";".join(config_paths),
                "environment_keys": ";".join(sorted(variables)),
                "topology_keys": ";".join(topology_keys),
                "selection_status": candidate["selection_status"] if candidate else "candidate",
                "runtime_match": "未验证",
                "evidence_ids": "",
                "confidence": confidence,
                "limitations": limitation,
            }
        )

    def _handle_python(
        self,
        tokens: list[str],
        variables: dict[str, str | None],
        path: Path,
        cwd: Path | None,
        line_start: int,
        line_end: int,
        chain_id: str,
        candidate_id: str,
        wrappers: list[str],
    ) -> None:
        source = f"{self.rel(path)}:{line_start}-{line_end}"
        index = 1
        while index < len(tokens):
            token = tokens[index]
            if token in PYTHON_FLAG_NO_VALUE:
                index += 1
                continue
            if token in PYTHON_FLAG_WITH_VALUE:
                index += 2
                continue
            break
        if index >= len(tokens):
            self.add_issue(
                "python_target_unresolved",
                chain_id=chain_id,
                source=source,
                expression=" ".join(redact_tokens(tokens)),
                impact="Python 启动命令没有静态目标",
                minimum="提供完整启动参数或 runtime argv",
            )
            return
        if tokens[index] == "-c":
            self.add_issue(
                "python_c_rejected",
                chain_id=chain_id,
                source=source,
                expression=f"{tokens[0]} -c <dynamic-code-redacted>",
                impact="拒绝解析或执行 python -c 动态代码",
                minimum="提供对应的仓库内 Python 文件或模块",
            )
            self._add_chain(
                chain_id,
                path,
                line_start,
                line_end,
                "python_target",
                "module_entry",
                "python -c",
                [tokens[0], "-c", "<dynamic-code-redacted>"],
                "unresolved",
                cwd=cwd,
            )
            return
        if tokens[index] == "-m" and index + 1 < len(tokens):
            module, reason = self._expand_static(tokens[index + 1], variables)
            if module is None:
                self.add_issue(
                    "python_module_dynamic",
                    chain_id=chain_id,
                    source=source,
                    expression=tokens[index + 1],
                    impact="无法静态确定 Python module",
                    minimum="提供展开后的 module 名或 runtime argv",
                )
                return
            remainder = tokens[index + 2 :]
            if module in {"torch.distributed.run", "torch.distributed.launch"}:
                target_index = self._find_command_token(remainder)
                if target_index is not None:
                    target_tokens = remainder[target_index:]
                    if target_tokens and target_tokens[0].lower().endswith(".py"):
                        resolved, status = self._resolve_repo_path(target_tokens[0], variables, path, cwd)
                        target = self.rel(resolved) if resolved else target_tokens[0]
                        self._add_chain(chain_id, path, line_start, line_end, "launcher", "launcher_target", target, tokens, status, cwd=cwd)
                        self._record_launch(candidate_id, chain_id, path, line_start, line_end, f"python -m {module}", wrappers, "script", target, target_tokens[1:], variables)
                        return
                self.add_issue(
                    "launcher_target_unresolved",
                    chain_id=chain_id,
                    source=source,
                    expression=" ".join(redact_tokens(tokens)),
                    impact="分布式 Python launcher 的训练脚本无法静态确定",
                    minimum="提供展开后的 runtime argv",
                )
                return
            self._add_chain(chain_id, path, line_start, line_end, "python_target", "module_entry", module, tokens, "resolved", cwd=cwd)
            self._record_launch(candidate_id, chain_id, path, line_start, line_end, "python", wrappers, "module", module, remainder, variables)
            return
        script_token = tokens[index]
        resolved, status = self._resolve_repo_path(script_token, variables, path, cwd)
        target = self.rel(resolved) if resolved else script_token
        self._add_chain(chain_id, path, line_start, line_end, "python_target", "module_entry", target, tokens, status, cwd=cwd)
        if resolved is None:
            self.add_issue(
                "python_target_unresolved",
                chain_id=chain_id,
                source=source,
                expression=script_token,
                impact=f"Python script 无法静态解析：{status}",
                minimum="提供仓库内脚本路径、工作目录或 runtime argv",
            )
        self._record_launch(candidate_id, chain_id, path, line_start, line_end, "python", wrappers, "script", target, tokens[index + 1 :], variables)

    def _handle_launcher(
        self,
        tokens: list[str],
        variables: dict[str, str | None],
        path: Path,
        cwd: Path | None,
        line_start: int,
        line_end: int,
        chain_id: str,
        candidate_id: str,
        wrappers: list[str],
        depth: int,
        stack: set[Path],
    ) -> None:
        launcher = Path(tokens[0]).name.lower()
        start = 1
        if launcher == "accelerate" and len(tokens) > 1 and tokens[1] == "launch":
            launcher = "accelerate launch"
            start = 2
        command_index = self._find_command_token(tokens, start)
        source = f"{self.rel(path)}:{line_start}-{line_end}"
        if command_index is None and launcher == "torchrun" and any(token in {"-m", "--module"} for token in tokens[start:]):
            module_options_with_values = {
                "--nnodes", "--nproc-per-node", "--nproc_per_node", "--rdzv-backend", "--rdzv_backend",
                "--rdzv-endpoint", "--rdzv_endpoint", "--rdzv-id", "--rdzv_id", "--rdzv-conf",
                "--max-restarts", "--max_restarts", "--monitor-interval", "--monitor_interval",
                "--start-method", "--start_method", "--role", "--log-dir", "--log_dir",
                "--redirects", "--tee", "--local-ranks-filter", "--local_ranks_filter",
                "--node-rank", "--node_rank", "--master-addr", "--master_addr", "--master-port",
                "--master_port", "--local-addr", "--local_addr", "--logs-specs", "--logs_specs",
            }
            boolean_options = {"-m", "--module", "--standalone", "--no-python", "--no_python", "--run-path", "--run_path"}
            scan = start
            module_target: str | None = None
            while scan < len(tokens):
                token = tokens[scan]
                key = token.split("=", 1)[0]
                if key in boolean_options or "=" in token:
                    scan += 1
                    continue
                if key in module_options_with_values:
                    scan += 2
                    continue
                if token.startswith("-"):
                    scan += 1
                    continue
                module_target = token
                command_index = scan
                break
            if module_target is not None:
                expanded, status = self._expand_static(module_target, variables)
                target = expanded if expanded is not None else module_target
                self._add_chain(chain_id, path, line_start, line_end, "launcher", "module_entry", target, tokens, "resolved" if expanded is not None else status, cwd=cwd)
                self._record_launch(candidate_id, chain_id, path, line_start, line_end, launcher, wrappers, "module", target, tokens[command_index + 1 :], variables)
                return
        if command_index is None:
            self._add_chain(chain_id, path, line_start, line_end, "launcher", "launcher_target", "<unresolved>", tokens, "unresolved", cwd=cwd)
            self.add_issue(
                "launcher_target_unresolved",
                chain_id=chain_id,
                source=source,
                expression=" ".join(redact_tokens(tokens)),
                impact=f"{launcher} 后没有可静态识别的 Python/shell 目标",
                minimum="提供展开后的 runtime argv",
            )
            return
        inner = tokens[command_index:]
        first = Path(inner[0]).name.lower()
        if PYTHON_RE.match(first):
            self._add_chain(chain_id, path, line_start, line_end, "launcher", "launcher_target", inner[0], tokens, "resolved", cwd=cwd)
            self._handle_python(inner, variables, path, cwd, line_start, line_end, chain_id, candidate_id, wrappers + [launcher])
            return
        if first in SHELLS:
            self._add_chain(chain_id, path, line_start, line_end, "launcher", "launcher_target", inner[0], tokens, "resolved", cwd=cwd)
            self._handle_shell(inner, variables, path, cwd, line_start, line_end, chain_id, candidate_id, wrappers + [launcher], depth, stack)
            return
        if inner[0].lower().endswith(".py"):
            resolved, status = self._resolve_repo_path(inner[0], variables, path, cwd)
            target = self.rel(resolved) if resolved else inner[0]
            self._add_chain(chain_id, path, line_start, line_end, "launcher", "launcher_target", target, tokens, status, cwd=cwd)
            self._record_launch(candidate_id, chain_id, path, line_start, line_end, launcher, wrappers, "script", target, inner[1:], variables)
            return
        if inner[0].lower().endswith(".sh"):
            self._add_chain(chain_id, path, line_start, line_end, "launcher", "launcher_target", inner[0], tokens, "resolved", cwd=cwd)
            self._handle_shell(["bash", *inner], variables, path, cwd, line_start, line_end, chain_id, candidate_id, wrappers + [launcher], depth, stack)

    def _strip_wrapper(self, tokens: list[str]) -> list[str]:
        wrapper = Path(tokens[0]).name.lower()
        if wrapper == "timeout":
            index = 1
            while index < len(tokens) and tokens[index].startswith("-"):
                index += 1
            if index < len(tokens):
                index += 1
            return tokens[index:]
        command_index = self._find_command_token(tokens, 1)
        return tokens[command_index:] if command_index is not None else []

    def _handle_shell(
        self,
        tokens: list[str],
        variables: dict[str, str | None],
        path: Path,
        cwd: Path | None,
        line_start: int,
        line_end: int,
        chain_id: str,
        candidate_id: str,
        wrappers: list[str],
        depth: int,
        stack: set[Path],
    ) -> None:
        source = f"{self.rel(path)}:{line_start}-{line_end}"
        if len(tokens) > 1 and tokens[1] in {"-c", "-s"}:
            self.add_issue(
                "dynamic_shell_rejected",
                chain_id=chain_id,
                source=source,
                expression=f"{tokens[0]} {tokens[1]} <dynamic-shell-redacted>",
                impact="拒绝解析或执行动态 shell 字符串/标准输入",
                minimum="提供仓库内脚本文件",
            )
            return
        index = self._first_non_option(tokens, 1)
        if index is None:
            self.add_issue(
                "nested_shell_target_unresolved",
                chain_id=chain_id,
                source=source,
                expression=" ".join(redact_tokens(tokens)),
                impact="shell 调用没有静态脚本目标",
                minimum="提供展开后的脚本路径",
            )
            return
        target_token = tokens[index]
        if target_token in {"-c", "-s"}:
            self.add_issue(
                "dynamic_shell_rejected",
                chain_id=chain_id,
                source=source,
                expression=" ".join(redact_tokens(tokens)),
                impact="拒绝解析或执行动态 shell 字符串/标准输入",
                minimum="提供仓库内脚本文件",
            )
            return
        resolved, status = self._resolve_repo_path(target_token, variables, path, cwd)
        target = self.rel(resolved) if resolved else target_token
        self._add_chain(chain_id, path, line_start, line_end, "shell_call", "shell_exec", target, tokens, status, cwd=cwd)
        if resolved is None:
            self.add_issue(
                "nested_shell_target_unresolved",
                chain_id=chain_id,
                source=source,
                expression=target_token,
                impact=f"嵌套 shell 无法静态解析：{status}",
                minimum="提供仓库内脚本路径或工作目录",
            )
            return
        self.parse_shell(resolved, chain_id, candidate_id, depth + 1, dict(variables), cwd, wrappers, stack)

    def _process_command(
        self,
        tokens: list[str],
        statement: str,
        path: Path,
        cwd: Path | None,
        variables: dict[str, str | None],
        line_start: int,
        line_end: int,
        chain_id: str,
        candidate_id: str,
        depth: int,
        stack: set[Path],
    ) -> Path | None:
        if not tokens:
            return cwd
        source = f"{self.rel(path)}:{line_start}-{line_end}"
        while tokens and tokens[0] in {"then", "do", "else", "elif", "if", "while", "until"}:
            tokens = tokens[1:]
        if not tokens:
            return cwd
        if tokens[0] in {"export", "local", "declare", "readonly"}:
            for token in tokens[1:]:
                if ASSIGNMENT_RE.match(token):
                    self._record_assignment(token, variables, chain_id, source)
            return cwd
        while tokens and ASSIGNMENT_RE.match(tokens[0]):
            self._record_assignment(tokens[0], variables, chain_id, source)
            tokens = tokens[1:]
        if not tokens:
            return cwd

        command = "." if tokens[0] == "." else Path(tokens[0]).name.lower()
        if command == "eval":
            self._add_chain(chain_id, path, line_start, line_end, "dynamic", "shell_exec", "eval", ["eval", "<dynamic-expression-redacted>"], "unresolved", cwd=cwd)
            self.add_issue(
                "eval_rejected",
                chain_id=chain_id,
                source=source,
                expression="eval <dynamic-expression-redacted>",
                impact="eval 不会执行或展开，后续入口保持未知",
                minimum="提供 eval 展开后的实际命令或 runtime argv",
            )
            return cwd
        if any(marker in statement for marker in DYNAMIC_MARKERS):
            self.add_issue(
                "dynamic_expression",
                chain_id=chain_id,
                source=source,
                expression=statement,
                impact="命令包含未执行的动态 shell 表达式；仅解析可独立确定的 token",
                minimum="提供展开后的 runtime argv（若该表达式决定入口）",
            )

        if command == "cd":
            target = tokens[1] if len(tokens) > 1 else ""
            resolved, status = self._resolve_repo_path(target, variables, path, cwd)
            self._add_chain(chain_id, path, line_start, line_end, "cwd", "config_guard", self.rel(resolved) if resolved else target, tokens, status, cwd=cwd)
            if resolved is not None and resolved.is_dir():
                return resolved
            self.add_issue(
                "cwd_unresolved",
                chain_id=chain_id,
                source=source,
                expression=target,
                impact=f"工作目录无法静态确定：{status}",
                minimum="提供脚本启动工作目录或 runtime argv",
            )
            return cwd

        if command in {"source", "."}:
            if len(tokens) < 2:
                self.add_issue(
                    "source_target_unresolved",
                    chain_id=chain_id,
                    source=source,
                    expression=statement,
                    impact="source 没有目标文件",
                    minimum="提供被 source 的文件",
                )
                return cwd
            resolved, status = self._resolve_repo_path(tokens[1], variables, path, cwd)
            target = self.rel(resolved) if resolved else tokens[1]
            self._add_chain(chain_id, path, line_start, line_end, "include", "shell_source", target, tokens, status, cwd=cwd)
            if resolved is None:
                self.add_issue(
                    "source_target_unresolved",
                    chain_id=chain_id,
                    source=source,
                    expression=tokens[1],
                    impact=f"source 目标无法静态读取：{status}",
                    minimum="提供仓库内 source 文件或展开后的路径",
                )
                return cwd
            self.parse_shell(resolved, chain_id, candidate_id, depth + 1, variables, cwd, [], stack)
            return cwd

        if command == "exec":
            return self._process_command(tokens[1:], statement, path, cwd, variables, line_start, line_end, chain_id, candidate_id, depth, stack)

        if command == "env":
            remainder = tokens[1:]
            while remainder and (remainder[0].startswith("-") or ASSIGNMENT_RE.match(remainder[0])):
                if ASSIGNMENT_RE.match(remainder[0]):
                    self._record_assignment(remainder[0], variables, chain_id, source)
                remainder = remainder[1:]
            return self._dispatch_launch(remainder, statement, path, cwd, variables, line_start, line_end, chain_id, candidate_id, depth, stack, ["env"])

        return self._dispatch_launch(tokens, statement, path, cwd, variables, line_start, line_end, chain_id, candidate_id, depth, stack, [])

    def _dispatch_launch(
        self,
        tokens: list[str],
        statement: str,
        path: Path,
        cwd: Path | None,
        variables: dict[str, str | None],
        line_start: int,
        line_end: int,
        chain_id: str,
        candidate_id: str,
        depth: int,
        stack: set[Path],
        wrappers: list[str],
    ) -> Path | None:
        if not tokens:
            return cwd
        command = Path(tokens[0]).name.lower()
        if command in SIMPLE_WRAPPERS:
            remainder = self._strip_wrapper(tokens)
            if not remainder:
                self.add_issue(
                    "wrapper_target_unresolved",
                    chain_id=chain_id,
                    source=f"{self.rel(path)}:{line_start}-{line_end}",
                    expression=statement,
                    impact=f"{command} 后的命令无法静态确定",
                    minimum="提供展开后的 runtime argv",
                )
                return cwd
            return self._dispatch_launch(remainder, statement, path, cwd, variables, line_start, line_end, chain_id, candidate_id, depth, stack, wrappers + [command])
        if command in {"uv", "poetry", "conda"} and "run" in tokens[1:3]:
            run_index = tokens.index("run", 1, min(len(tokens), 3))
            return self._dispatch_launch(tokens[run_index + 1 :], statement, path, cwd, variables, line_start, line_end, chain_id, candidate_id, depth, stack, wrappers + [f"{command} run"])
        if command in SHELLS:
            self._handle_shell(tokens, variables, path, cwd, line_start, line_end, chain_id, candidate_id, wrappers, depth, stack)
            return cwd
        if PYTHON_RE.match(command):
            self._handle_python(tokens, variables, path, cwd, line_start, line_end, chain_id, candidate_id, wrappers)
            return cwd
        if command in LAUNCHERS or (command == "accelerate" and len(tokens) > 1 and tokens[1] == "launch"):
            self._handle_launcher(tokens, variables, path, cwd, line_start, line_end, chain_id, candidate_id, wrappers, depth, stack)
            return cwd
        return cwd

    def parse_shell(
        self,
        path: Path,
        chain_id: str,
        candidate_id: str,
        depth: int,
        variables: dict[str, str | None],
        cwd: Path | None,
        wrappers: list[str],
        stack: set[Path],
    ) -> None:
        path = path.resolve(strict=False)
        if depth > self.budgets.max_depth:
            self._partial = True
            self.add_issue(
                "depth_budget_exceeded",
                chain_id=chain_id,
                source=self.rel(path),
                expression=f"depth={depth}",
                impact="达到 include/嵌套 shell 深度预算，链路不完整",
                minimum="提高 --max-depth 或提供更具体入口",
            )
            return
        if path in stack:
            self.add_issue(
                "shell_cycle",
                chain_id=chain_id,
                source=self.rel(path),
                expression=" -> ".join([*(self.rel(item) for item in stack), self.rel(path)]),
                impact="检测到 source/嵌套 shell 循环，停止递归",
            )
            return
        text = self.read_text(path, chain_id)
        if text is None:
            return
        new_stack = set(stack)
        new_stack.add(path)
        for statement, line_start, line_end in self.logical_statements(path, text, chain_id):
            source = f"{self.rel(path)}:{line_start}-{line_end}"
            if self._try_script_dir_anchor(statement, path, variables, chain_id, source):
                continue
            try:
                tokens = self.tokenize(statement)
            except ValueError as exc:
                self.add_issue(
                    "shell_parse_error",
                    chain_id=chain_id,
                    source=source,
                    expression=statement,
                    impact=f"shell token 化失败：{exc}",
                    minimum="提供语法完整的脚本快照",
                )
                continue
            for command_tokens in self.split_commands(tokens):
                cwd = self._process_command(
                    command_tokens,
                    statement,
                    path,
                    cwd,
                    variables,
                    line_start,
                    line_end,
                    chain_id,
                    candidate_id,
                    depth,
                    new_stack,
                )

    def analyze(self) -> None:
        for candidate in self.candidates:
            path = self.repo_root / candidate["entry_path"]
            chain_id = f"chain-{candidate['candidate_id'].split('-')[-1]}"
            self.parse_shell(path, chain_id, candidate["candidate_id"], 0, {}, None, [], set())
        selected = next((row for row in self.candidates if row["selection_status"] == "analysis_selected"), None)
        if selected and not any(row["candidate_id"] == selected["candidate_id"] for row in self.launch_rows):
            self.add_issue(
                "selected_entry_has_no_launch",
                chain_id=f"chain-{selected['candidate_id'].split('-')[-1]}",
                source=selected["source_location"],
                expression=selected["entry_path"],
                impact="选定静态入口中未恢复 Python/launcher 目标",
                minimum="提供 runtime argv、被调用脚本或更具体入口",
            )

    def write_outputs(self) -> dict[str, Any]:
        self.output.mkdir(parents=True, exist_ok=True)
        write_csv(self.output / "source_entrypoint_candidates.csv", CANDIDATE_FIELDS, self.candidates)
        write_csv(self.output / "shell_launch_chain.csv", CHAIN_FIELDS, self.chain_rows)
        write_csv(self.output / "launch_command_candidates.csv", LAUNCH_FIELDS, self.launch_rows)
        write_csv(self.output / "source_runtime_config.csv", CONFIG_FIELDS, self.config_rows)
        write_csv(self.output / "source_resolution_issues.csv", ISSUE_FIELDS, self.issue_rows)
        selected = next((row for row in self.candidates if row["selection_status"] == "analysis_selected"), None)
        summary = {
            "schema_version": 1,
            "environment": self.environment,
            "repo_root": str(self.repo_root),
            "analysis_selected_entry": selected["entry_path"] if selected else None,
            "runtime_binding": "未验证",
            "static_analysis_only": True,
            "repository_code_executed": False,
            "partial": self._partial,
            "counts": {
                "entrypoint_candidates": len(self.candidates),
                "chain_edges": len(self.chain_rows),
                "launch_candidates": len(self.launch_rows),
                "runtime_config_records": len(self.config_rows),
                "resolution_issues": len(self.issue_rows),
            },
            "budgets": {
                "max_files": self.budgets.max_files,
                "max_bytes": self.budgets.max_bytes,
                "max_depth": self.budgets.max_depth,
                "files_read": self.budgets.files_read,
                "bytes_read": self.budgets.bytes_read,
            },
            "outputs": [
                "source_entrypoint_candidates.csv",
                "shell_launch_chain.csv",
                "launch_command_candidates.csv",
                "source_runtime_config.csv",
                "source_resolution_issues.csv",
            ],
            "limitations": [
                "静态候选不证明本次 Profiling 实际执行路径",
                "命令替换、eval、动态 shell、仓库外文件和未知变量不会被展开",
                "解析器不会执行/source/eval/import 任何仓库代码",
            ],
        }
        (self.output / "source_entrypoint_summary.json").write_text(
            json.dumps(summary, ensure_ascii=False, indent=2) + "\n",
            encoding="utf-8",
        )
        return summary


def parse_args(argv: list[str] | None = None) -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--repo-root", required=True, type=Path, help="只读源码仓库根目录")
    parser.add_argument(
        "--entry",
        action="append",
        default=[],
        help="仓库内 .sh 文件或目录，可重复；省略时扫描仓库根",
    )
    parser.add_argument("--output", required=True, type=Path, help="仓库外的解析输出目录")
    parser.add_argument("--environment", required=True, help="环境标签，如 real/reference/真机")
    parser.add_argument("--max-files", type=int, default=200, help="最多读取文件数，默认 200")
    parser.add_argument("--max-bytes", type=int, default=2 * 1024 * 1024, help="最多读取总字节数，默认 2 MiB")
    parser.add_argument("--max-depth", type=int, default=8, help="source/嵌套 shell 最大深度，默认 8")
    args = parser.parse_args(argv)
    if args.max_files <= 0 or args.max_bytes <= 0 or args.max_depth < 0:
        parser.error("预算参数必须为正数（--max-depth 可为 0）")
    return args


def main(argv: list[str] | None = None) -> int:
    args = parse_args(argv)
    try:
        repo_root = args.repo_root.resolve(strict=True)
    except OSError as exc:
        print(f"错误：无法读取 --repo-root：{exc}", file=sys.stderr)
        return 2
    if not repo_root.is_dir():
        print("错误：--repo-root 必须是目录", file=sys.stderr)
        return 2
    output = args.output.resolve(strict=False)
    if is_within(output, repo_root):
        print("错误：--output 必须位于源码仓库之外，保证仓库只读", file=sys.stderr)
        return 2
    resolver = Resolver(
        repo_root,
        output,
        args.environment,
        Budgets(args.max_files, args.max_bytes, args.max_depth),
    )
    resolver.discover(args.entry or ["."])
    resolver.analyze()
    summary = resolver.write_outputs()
    print(json.dumps(summary, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

from __future__ import annotations

import csv
import importlib.util
import json
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path


SCRIPT = Path(__file__).resolve().parents[1] / "scripts" / "preflight_ascend_profiles.py"
SPEC = importlib.util.spec_from_file_location("preflight_ascend_profiles", SCRIPT)
assert SPEC and SPEC.loader
PREFLIGHT = importlib.util.module_from_spec(SPEC)
sys.modules[SPEC.name] = PREFLIGHT
SPEC.loader.exec_module(PREFLIGHT)


def write_json(path: Path, value: object) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, ensure_ascii=False), encoding="utf-8")


def write_csv(path: Path, fieldnames: list[str], rows: list[dict[str, object]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(rows)


def profile_dir(root: Path, worker: str = "worker_rank0_ascend_pt") -> Path:
    output = root / worker / "ASCEND_PROFILER_OUTPUT"
    output.mkdir(parents=True, exist_ok=True)
    return output


def trace_events(
    pid: int,
    *,
    kernel_stream: int | None = 7,
    include_acl_runtime: bool = True,
) -> list[dict[str, object]]:
    events: list[dict[str, object]] = [
        {
            "ph": "X",
            "cat": "cpu_op",
            "name": "aten::mm",
            "pid": pid,
            "tid": pid + 1,
            "ts": 100,
            "dur": 40,
            "args": {
                "External id": 501,
                "Input Dims": [[2, 3], [3, 4]],
                "Input type": ["float", "float"],
                "Call stack": "model.py(10): forward",
                "Module Hierarchy": "Model.mm",
                "Step Id": 3,
            },
        }
    ]
    if include_acl_runtime:
        events.extend(
            [
                {
                    "ph": "X",
                    "cat": "AscendCL",
                    "name": "aclnnMm",
                    "pid": pid,
                    "tid": pid + 2,
                    "ts": 110,
                    "dur": 8,
                    "args": {"correlation": 77, "Device Id": 0},
                },
                {
                    "ph": "X",
                    "cat": "Runtime",
                    "name": "aclrtLaunchKernel",
                    "pid": pid,
                    "tid": pid + 3,
                    "ts": 120,
                    "dur": 5,
                    "args": {"correlation": 77, "Stream Id": 7, "Device Id": 0},
                },
            ]
        )
    kernel_args: dict[str, object] = {
        "External id": 501,
        "correlation": 77,
        "Device Id": 0,
        "Task Id": 9,
        "Task Type": "AI_CORE",
        "Input Shapes": [[2, 3], [3, 4]],
        "Output Shapes": [[2, 4]],
    }
    if kernel_stream is not None:
        kernel_args["Stream Id"] = kernel_stream
    events.append(
        {
            "ph": "X",
            "cat": "Kernel",
            "name": "MatMulV2_0",
            "pid": 0,
            "tid": kernel_stream if kernel_stream is not None else 99,
            "ts": 130,
            "dur": 10,
            "args": kernel_args,
        }
    )
    return events


def write_complete_profile(
    root: Path,
    *,
    pid: int,
    metadata_rank: int = 0,
    worker: str = "worker_rank0_ascend_pt",
    kernel_stream: int | None = 7,
) -> Path:
    output = profile_dir(root, worker)
    write_json(
        output.parent / "profiler_info_0.json",
        {
            "global_rank": metadata_rank,
            "activities": ["CPU", "NPU"],
            "record_shapes": True,
            "with_stack": True,
            "with_modules": True,
            "profiler_level": "ProfilerLevel.Level1",
            "schedule": {"wait": 1, "warmup": 1, "active": 2, "repeat": 1},
            "child_thread_registration": True,
        },
    )
    write_json(output / "trace_view.json", {"schemaVersion": 1, "traceEvents": trace_events(pid, kernel_stream=kernel_stream)})
    write_csv(
        output / "operator_details.csv",
        ["Name", "Input Shapes", "Call Stack"],
        [{"Name": "aten::mm", "Input Shapes": "[[2,3],[3,4]]", "Call Stack": "model.py:10"}],
    )
    write_csv(
        output / "kernel_details.csv",
        [
            "Device_id",
            "Task ID",
            "Stream ID",
            "Name",
            "Type",
            "Start Time(us)",
            "Input Shapes",
            "Output Shapes",
        ],
        [
            {
                "Device_id": 0,
                "Task ID": 9,
                "Stream ID": "" if kernel_stream is None else kernel_stream,
                "Name": "MatMulV2_0",
                "Type": "MatMulV2",
                "Start Time(us)": 130,
                "Input Shapes": "[[2,3],[3,4]]",
                "Output Shapes": "[[2,4]]",
            }
        ],
    )
    return output


class AscendCollectionContractTests(unittest.TestCase):
    def setUp(self) -> None:
        self.temp = tempfile.TemporaryDirectory()
        self.root = Path(self.temp.name)

    def tearDown(self) -> None:
        self.temp.cleanup()

    def run_preflight(self, real: Path, sim: Path) -> tuple[dict[str, object], Path]:
        output = self.root / "contract-output"
        payload = PREFLIGHT.preflight(real, sim, output)
        return payload, output

    def test_cli_writes_both_side_contracts_and_recognizes_official_start_field(self) -> None:
        real = self.root / "real"
        sim = self.root / "sim"
        write_complete_profile(real, pid=1000)
        write_complete_profile(sim, pid=2000)
        output = self.root / "cli-output"

        completed = subprocess.run(
            [
                sys.executable,
                str(SCRIPT),
                "--real",
                str(real),
                "--sim",
                str(sim),
                "--output",
                str(output),
            ],
            check=False,
            capture_output=True,
            text=True,
        )

        self.assertEqual(completed.returncode, 0, completed.stderr)
        payload = json.loads((output / "collection_contract.json").read_text(encoding="utf-8"))
        with (output / "collection_contract.csv").open("r", encoding="utf-8-sig", newline="") as handle:
            rows = list(csv.DictReader(handle))
        self.assertEqual(payload["status"], "complete")
        self.assertEqual({row["environment"] for row in rows}, {"real/reference/真机", "sim/candidate/仿真"})
        self.assertTrue(all(row["kernel_start_field"] == "Start Time(us)" for row in rows))
        self.assertTrue(all(row["activities_cpu"] == "enabled" for row in rows))
        self.assertTrue(all(row["activities_npu"] == "enabled" for row in rows))
        self.assertTrue(all(row["child_thread_registration"] == "enabled" for row in rows))

    def test_acl_runtime_kernel_bridges_are_observed(self) -> None:
        real = self.root / "real"
        sim = self.root / "sim"
        write_complete_profile(real, pid=3000)
        write_complete_profile(sim, pid=4000)

        payload, _ = self.run_preflight(real, sim)
        contract = payload["real"]["contracts"][0]

        self.assertEqual(contract["host_kernel_bridge"], "observed")
        self.assertEqual(contract["acl_runtime_bridge"], "observed")
        self.assertEqual(contract["runtime_kernel_bridge"], "observed")
        self.assertEqual(contract["acl_event_count"], 1)
        self.assertEqual(contract["runtime_event_count"], 1)
        self.assertEqual(contract["kernel_trace_event_count"], 1)
        self.assertEqual(contract["record_shapes"], "enabled")
        self.assertEqual(contract["with_stack"], "enabled")
        self.assertEqual(contract["with_modules"], "enabled")

    def test_missing_stream_is_partial_not_silently_accepted(self) -> None:
        real = self.root / "real"
        sim = self.root / "sim"
        write_complete_profile(real, pid=5000, kernel_stream=None)
        write_complete_profile(sim, pid=6000, kernel_stream=None)

        payload, _ = self.run_preflight(real, sim)
        contract = payload["real"]["contracts"][0]
        codes = {item["code"] for item in contract["issues"]}

        self.assertEqual(payload["status"], "partial")
        self.assertEqual(contract["status"], "partial")
        self.assertEqual(contract["missing_stream_count"], 2)
        self.assertIn("kernel_stream_missing", codes)

    def test_rank_metadata_conflict_is_reported_without_selecting_a_rank(self) -> None:
        real = self.root / "real"
        sim = self.root / "sim"
        write_complete_profile(real, pid=7000, metadata_rank=0, worker="worker_rank7_ascend_pt")
        write_complete_profile(sim, pid=8000, metadata_rank=0, worker="worker_rank7_ascend_pt")

        payload, _ = self.run_preflight(real, sim)
        contract = payload["real"]["contracts"][0]
        codes = {item["code"] for item in contract["issues"]}

        self.assertEqual(payload["status"], "partial")
        self.assertEqual(contract["rank_status"], "conflict")
        self.assertIsNone(contract["rank_id"])
        self.assertEqual(contract["metadata_rank_values"], [0])
        self.assertEqual(contract["directory_rank_values"], [7])
        self.assertIn("rank_metadata_conflict", codes)

    def test_raw_msprof_is_unsupported_and_never_zero_events(self) -> None:
        real = self.root / "real"
        sim = self.root / "sim"
        for root in (real, sim):
            raw = root / "PROF_000001_20260813120000000_ABCDEF"
            (raw / "host").mkdir(parents=True)
            (raw / "device_0").mkdir()
            (raw / "host" / "api_trace.bin").write_bytes(b"raw-msprof")

        payload, output = self.run_preflight(real, sim)
        contract = payload["real"]["contracts"][0]
        with (output / "collection_contract.csv").open("r", encoding="utf-8-sig", newline="") as handle:
            rows = list(csv.DictReader(handle))

        self.assertEqual(payload["status"], "unsupported")
        self.assertEqual(contract["profile_format"], "raw_msprof")
        self.assertEqual(contract["event_observation"], "not-counted-unsupported-format")
        self.assertIsNone(contract["trace_event_count"])
        self.assertFalse(contract["zero_event_claim"])
        self.assertTrue(all(row["trace_event_count"] == "" for row in rows))

    def test_analysis_db_only_is_unsupported_and_activities_remain_unknown(self) -> None:
        real = self.root / "real"
        sim = self.root / "sim"
        for root in (real, sim):
            root.mkdir()
            (root / "analysis.db").write_bytes(b"SQLite format 3\x00")

        payload, _ = self.run_preflight(real, sim)
        contract = payload["real"]["contracts"][0]

        self.assertEqual(payload["status"], "unsupported")
        self.assertEqual(contract["profile_format"], "torchnpu_analysis_db_only")
        self.assertEqual(contract["activities_cpu"], "unknown")
        self.assertEqual(contract["activities_npu"], "unknown")
        self.assertIsNone(contract["host_operator_count"])

    def test_supported_trace_does_not_imply_activity_configuration(self) -> None:
        real = self.root / "real"
        sim = self.root / "sim"
        for root, pid in ((real, 9000), (sim, 10000)):
            output = profile_dir(root)
            write_json(output.parent / "profiler_info_0.json", {"global_rank": 0})
            write_json(
                output / "trace_view.json",
                {"schemaVersion": 1, "traceEvents": trace_events(pid)},
            )

        payload, _ = self.run_preflight(real, sim)
        contract = payload["real"]["contracts"][0]

        self.assertEqual(payload["status"], "partial")
        self.assertGreater(contract["host_operator_count"], 0)
        self.assertGreater(contract["kernel_trace_event_count"], 0)
        self.assertEqual(contract["activities_cpu"], "unknown")
        self.assertEqual(contract["activities_npu"], "unknown")


if __name__ == "__main__":
    unittest.main()

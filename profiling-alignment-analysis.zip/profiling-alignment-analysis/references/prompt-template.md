# 推荐输入模板

```text
请用 $profiling-alignment-analysis 分析：

真机 Profiling（reference）：<绝对目录>
仿真 Profiling（candidate）：<绝对目录>
采集类型：<优先 TorchNPU integrated ASCEND_PROFILER_OUTPUT text export；若为 raw msprof/analysis.db 请明确>

模型/权重/配置：<标识或文件>
Workload：<batch、input/output length、请求/数据集、并发>
阶段：<prefill/decode/train/...>
Profiler schedule/窗口：<wait/warmup/active/repeat、step/request 标识>
Profiler 采集配置：<CPU/NPU activities、record_shapes、with_stack、with_modules、profiler level>
子线程算子：<是否使用 enable_profiler_in_child_thread 或等价注册；未知可留空>
并行拓扑：<world size、DP/TP/EP/PP/CP/DCP>

模型源码：<本地 checkout 或 GitHub/GitCode URL>
源码 commit/tag/branch：<优先完整 commit>
入口：<一个或多个 .sh；也可给全是 .sh 的目录>
真机运行版本证据：<metadata/log/build ID>
仿真运行版本证据：<metadata/log/build ID>

可选 runtime guard 证据：<CSV/JSONL>
可选明确 Thread 映射：<每 Rank 的 real pid/tid -> sim pid/tid 与依据>
在线 Perfetto 是否符合数据政策：<是/否；否时使用本地降级>
是否需要 Canvas 截图：<默认否>
```

如果只给两个 Profiling 目录却没有明确真机/仿真角色，只询问角色，不运行比较。其余缺失项不必阻塞结构提取，但必须降低对应结论强度并列出最小补证。

# 仿真 vs 真机 控制流分叉模式速查（PyTorch + torch_npu + MindSpeed/Megatron）

拿到分歧算子后**先查这张表**，命中的话直接去代码里核对，能省掉大量翻源码的时间。
文件路径按 MindSpeed-LLM / Megatron-LM 的常见布局给出，版本之间会挪位置，
所以每条都附了 grep 模式——**以 grep 到的实际代码为准，不要照抄行号**。

## 反查索引：先按算子现象找模式

| 算子层面看到的现象 | 最可能的模式 |
| --- | --- |
| 仿真少了 `ApplyAdamW`/`FusedAdamW`/`Muls` 一整段，多了 `ZerosLike` 或什么都没有 | ① 溢出跳步 |
| 两边都有优化器段，但仿真少/多了一次 `Muls`、`ForeachMul` | ② 梯度裁剪系数分支 |
| `hcom_alltoall*` 的数量或 shape 不同、`GroupedMatmul`/专家 MatMul 数量不同 | ③ MoE 路由 |
| `FlashAttentionScore` 的 shape 不同、attention 段算子数不同 | ④ 动态序列长度 / mask |
| 仿真整段 forward kernel 重复出现（或真机重复而仿真不重复） | ⑤ 重计算策略 |
| 迭代次数本身不同、decode 段长度不同 | ⑥ early exit / 生成停止判定 |
| 缺失整层或整段 layer | ⑦ 并行切分/层分配（多半是配置问题） |
| 只在某个 rank 上多出 D2H + 文件 IO | ⑧ rank0 专属分支（日志/保存，通常无害） |
| 算子完全一致，只有 shape 有微小差别 | ⑨ 数值/RNG 差异，还没造成控制流分叉 |

---

## ① 溢出检测导致跳过优化器更新（最常见）

fp16/bf16 训练里，梯度是否溢出由设备算出，再回到 host 决定"这一步要不要更新权重"。
仿真器的数值一旦不准，`found_inf` 就可能翻转，整个优化器段凭空消失或凭空出现。

- 判据 tensor：`found_inf` / `float_status` / `grad_scaler` 的 scale
- 算子特征：`aten::_amp_foreach_non_finite_check_and_unscale_`、`NPUGetFloatStatus`、
  `NPUClearFloatStatus`，紧跟着 `aten::_local_scalar_dense`（`.item()`）
- 代码位置：

```bash
grep -rn "found_inf\|float_status\|_amp_foreach_non_finite\|update_successful\|found_inf_flag" \
  megatron/core/optimizer/ mindspeed*/optimizer/ 2>/dev/null
```

  Megatron 的 `MixedPrecisionOptimizer.step()` 里形如
  `found_inf_flag = self._unscale_main_grads_and_check_for_nan(); if found_inf_flag: return False, None, None`
- 验证：Step 7 探针，或在该 if 前后打印 `found_inf.item()`

## ② 梯度裁剪的系数分支

`clip_coeff = max_norm / (total_norm + eps)`，然后 `if clip_coeff < 1.0: 缩放所有梯度`。
`total_norm` 来自设备（还常常带一次 all-reduce），仿真数值不同 → 缩放这一段有无。

- 判据 tensor：`total_norm` / `grad_norm`
- 算子特征：`aten::_foreach_norm`、`ClipByNormNoDivSum`、`ReduceSumD` + `hcom_allReduce`，
  之后是否出现 `Muls` / `ForeachMulScalar`
- 代码位置：

```bash
grep -rn "clip_coeff\|clip_grad_norm\|total_norm\|get_grad_norm" megatron/core/optimizer/ mindspeed*/
```

## ③ MoE 路由与 token 分发（分歧最"壮观"的一类）

router 的 logits 决定 top-k 专家；每个专家收到多少 token 是设备算出来的，而 all-to-all
的通信量必须回到 host 才能建通信描述，于是这里天然有 `.cpu()` / `.tolist()` 同步点。
仿真里 router 数值一变，专家分配、丢弃(drop)、容量填充(pad) 全变，通信和分组矩阵乘全变。

- 判据 tensor：`router_logits` / `topk_idx` / `tokens_per_expert` / `capacity`
- 算子特征：`hcom_alltoall*` 的次数与 shape、`GatherV2`/`IndexSelect`、`GroupedMatmul`
  或每专家一个 MatMul、`SortV2`/`TopKV2`
- 代码位置：

```bash
grep -rn "tokens_per_expert\|topk\|routing_map\|capacity_factor\|drop_and_pad\|\.tolist()\|\.cpu()" \
  megatron/core/transformer/moe/ mindspeed*/moe/
```

  重点看 `router.py`（top-k、aux loss）与 `token_dispatcher.py`（all-to-all 前对
  `tokens_per_expert` 的同步读取）。
- 附加线索：`pa_align.py` 第 4 节的"同名算子 shape 不一致"，MoE 场景下通常在这里先亮。

## ④ 动态序列长度 / packing / mask

- 判据 tensor：`actual_seq_len` / `seq_lens` / `attention_mask` / `position_ids`
- 算子特征：`FlashAttentionScore` 的 `Input Shapes` 两边不同；attention 段算子数量不同；
  `reset_position_ids` 相关的 `NonZero`、`CumSum`、`MaskedSelect`
- 代码位置：

```bash
grep -rn "actual_seq_len\|variable_seq_lengths\|reset_position_ids\|reset_attention_mask\|eod_mask" \
  mindspeed*/ megatron/
```

- 注意：`nonzero` / `masked_select` 产生**数据相关的动态 shape**，它本身就是仿真最容易失真的地方。

## ⑤ 重计算 / 自适应内存策略

MindSpeed 的 adaptive recompute / swap-attention 会根据"当前显存占用"在线决定要不要重算，
而仿真器报告的内存数字和真机不一样，于是 backward 里 forward kernel 重放与否发生变化。

- 判据 tensor / 值：`torch_npu.npu.memory_allocated()`、内存阈值、profile 出来的层耗时
- 算子特征：backward 段里整段 forward kernel（`RmsNorm`+`MatMulV3`+`FlashAttentionScore`）
  重复出现；两边重复次数不同
- 代码位置：

```bash
grep -rn "adaptive_recompute\|recompute_granularity\|swap_attention\|memory_allocated\|checkpoint(" \
  mindspeed*/ megatron/core/transformer/
```

- **先看启动参数**：`--recompute-granularity/-method/-num-layers`、`--adaptive-recompute-device-size`
  不同就是配置问题，不是仿真数值问题。

## ⑥ early exit / 生成停止判定（推理场景）

- 判据 tensor：`eos_mask` / `finished` / `unfinished_sequences` / 采样出的 token id
- 算子特征：decode 段整体重复次数不同——两边算子种类完全一样，但数量成比例差异
- 代码位置：

```bash
grep -rn "eos_token\|is_finished\|unfinished\|max_new_tokens\|while.*finished" <repo>
```

## ⑦ 并行切分 / 层分配差异

world size、TP/PP/EP/CP、`--num-layer-list`、`--noop-layers` 不同 ⇒ 同一个 rank 号承担的层
或专家不同。这类差异**不是仿真 bug**，必须在报告开头就排除掉，否则后面全是伪结论。
用 `pa_shargs.py --diff` 对比两侧启动脚本。

## ⑧ rank 相关的旁路分支

`if torch.distributed.get_rank() == 0:` 的日志、保存、评估分支会带来额外的 D2H 与文件 IO。
通常无害，但会在对齐结果里制造"仿真少了几个算子"的噪声，识别出来直接标注即可。

## ⑨ 数值差异但控制流还没分叉

两边算子序列完全一致、只有 shape/数值不同：说明仿真的数值误差还没有传播到任何分支上。
此时结论应该是"控制流未分叉"，并把 shape 不一致的位置作为**风险点**列出——它们是下一步
最可能翻转的地方。需要 tensor 级比对时，用昇腾的精度工具 msprobe 采集两侧张量再比对，
本 skill 只负责指出该比哪几个 tensor。

---

## 通用的"可疑 if"识别法

不在上表里的情况，回到第一性原理：**能让仿真走岔的 if，判据一定来自设备**。
在 `pa_evidence.py` 给出的同步点里，按这几个特征挑：

1. 每个 step 只执行 1-2 次（不是逐算子的例行拷贝）
2. 调用栈落在模型仓库代码里，而不是 torch/torch_npu 内部
3. 紧跟着出现算子构成的变化（分歧点就在它之后不远）
4. 判据是标量或很小的 tensor（`[1]`、`[8]`），因为要拿回 host 做判断

四条都满足的，基本就是它。

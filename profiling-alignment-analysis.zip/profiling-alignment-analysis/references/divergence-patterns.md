# 仿真 vs 真机 差异模式速查（PyTorch + torch_npu + MindSpeed/Megatron/MindSpeed-MM）

先分类（A 环境版本 / B 仿真器桩 / C 配置数据 / D 数值导致的控制流分叉），
再按类查表。**实测下来 A/B/C 才是差异的大头，D 往往被它们淹没**，所以顺序不能反。

---

# 第一部分：A / B / C 类 —— 先解释掉，否则 D 类结论不成立

## A1. 行号不同 ≠ 版本不同：先看偏移量的形状

`pa_pytrace.py` 第 3.0 节按文件给判定，三种情况处理方式完全不同：

| 判定 | 现象 | 含义 | 处理 |
| --- | --- | --- | --- |
| ✅ 整体平移 | 一个文件里所有函数偏移量相同（如全 +61 行） | 同一份代码，只是头部增删了几行——仿真侧打 patch 的常见形态 | 忽略，行号以真机为准 |
| ⚠️ 偏移不一致 | 同一文件里偏移 8、13、8… | 版本不同 | `pip show` 对比，对齐后重采 |
| ❗ 执行到不同定义 | 同名函数两侧对应不同的定义行（真机独有 306 行、仿真独有 1056 行） | 两边**真的执行了不同的函数体** | 这才是要追的，去看那两个定义各属于哪个类 |

最后一种最有价值：同一个 `forward` 名字，真机执行到了视觉块的定义、仿真执行到了别的定义，
说明某段模块整体没跑——通常是被 patch 跳过或被桩替换了。

**基准永远是真机代码。** 仿真侧一般是在真机代码上打 patch，读行号、定位源码、写结论都用真机
那一份，仿真侧只用来回答"它少做了什么"。

## A2. patch 没被加载

- 现象：真机走 `xxx_patch.py::某函数`，仿真走库里的原始实现（或反过来）。
- 定位：`pa_pytrace.py` 第 1/2 节；再去 `patch_manager` / `apply_patches` 里看开关是哪个配置项。

## B1. 仿真器把函数换成了桩

- 现象：仿真侧出现 `*_mock` / `*_stub` / `simulator_patch/*` / `fake_*`（pa_pytrace 会打 ⚑）。
  典型如 `get_grad_norm_fp32_mock` 顶替 `get_grad_norm_fp32_async`：真机那一段的
  `multi_tensor_applier(l2_norm)` + `all_reduce` + `.item()` + 裁剪算子在仿真侧整段消失。
- 含义：**仿真器没实现真实逻辑**，不是模型数值问题。
- 处理：单独成一类列出，说明"这部分无法用于评估仿真精度"。

## B2. 通信/同步原语被替换

- 现象：device 侧真机是 `NOTIFY_WAIT_SQE` / `NOTIFY_RECORD_SQE` / `UBDMA` / `SDMA_SQE`，
  仿真是 `DAVID_EVENT_WAIT` / `DAVID_EVENT_RECORD` / `MEMCPY_ASYNC`；所有 stream 从头错位。
- 含义：HCCL 后端实现不同，**不是控制流分叉**。device 侧对齐率会因此接近 0，
  这时 device 序列对齐没有意义，要把结论建立在 host 侧。

## B4. 显存受限导致 H2D 拷贝失效 → 关键融合算子走不到（实测踩过）

仿真环境的显存/内存限制会让 host→device 的拷贝悄悄失效：张量没真正搬上 device，
后面依赖它的融合算子（如 `aclnnFlashAttentionScoreV4`）的入口条件不满足，于是走了别的实现
或者干脆不执行。**这不是模型分支，是仿真基础设施失真，但它会把后面的一切都带偏。**

- 签名一：`pa_pytrace.py` 第 0b 节里"注意力(融合)"这一类在仿真侧为 0。
- 签名二：**拷贝退化**——同一处 `aten::to` / `aten::copy_` / `_to_copy`，真机搬的是
  `880,72` 这样的张量，仿真搬的是 `1` 或空。0b 节会单独列出这类行。
- 签名三：`aten::_foreach_copy_` / `aclnnForeachCopy` 在仿真侧为 0，同时出现
  `*_foreach_copy_*_mock` 这样的桩函数。
- 处理：先确认仿真的显存配置，把这一类失真修掉再谈控制流；在它存在期间，
  所有"仿真少了哪些算子"的结论都要标注为受此影响。

## B3. 整段计算在仿真侧不存在

- 现象：真机某条 stream 有完整 Embedding→Attention→FFN→Optimizer 流水，仿真只剩几个 event。
- 先分清是 B1（桩）还是 D（分支跳过）：看 host 侧对应的 Python 函数是"被换掉了"还是"没被调用"。
  pa_pytrace 第 1/2 节能直接区分。

## C1. world size / 并行切分不同

- 8 卡 vs 4 卡时 DP 组大小不同 ⇒ `grad_norm` 等 all-reduce 结果本来就不同 ⇒
  依赖它的分支翻转是**预期内**的，不能算仿真 bug。
- 同理 TP/PP/EP/CP 不同会让同一个 rank 号承担不同的层/专家。

## C2. 输入数据不同

- 现象：所有同名算子 shape 差一点点（如 `[394,32,128]` vs `[400,32,128]`）。
- 含义：两侧喂的样本不是同一条，序列长度不同。后续所有 shape 差异都由它派生。
- 处理：统一输入（固定 sample、固定 seed、关掉 shuffle）后重采。
- **不要对 shape 里的数字做算术推断**：`151936` 是 Qwen3 的 vocab_size，
  `[1,400,151936]` 就是 logits，不是什么 "37×4096+2304"。解释 shape 要回去查模型配置。

## C3. 采集配置不同

`with_stack` / `record_shapes` / `profiler_level` / `skip_first_wait` 不一致，会让一侧"没采到"
被误读成"没执行"。

---

# 第二部分：D 类 —— 数值导致的控制流分叉

拿到分歧算子后**先查这张表**，命中的话直接去代码里核对，能省掉大量翻源码的时间。
文件路径按 MindSpeed-LLM / Megatron-LM 的常见布局给出，版本之间会挪位置，
所以每条都附了 grep 模式——**以 grep 到的实际代码为准，不要照抄行号**。

## 反查索引：先按算子现象找模式

| 算子层面看到的现象 | 最可能的模式 |
| --- | --- |
| 仿真少了 `ApplyAdamW`/`FusedAdamW`/`Muls` 一整段，多了 `ZerosLike` 或什么都没有 | ① 溢出跳步 |
| 两边都有优化器段，但仿真少/多了一次 `Muls`、`ForeachMul` | ② 梯度裁剪系数分支 |
| `hcom_alltoall*` 的数量或 shape 不同、`GroupedMatmul`/专家 MatMul 数量不同 | ③ MoE 路由 |
| `FlashAttentionScore` 的 shape 不同、attention 段算子数不同 | ④ 动态序列长度 / mask |
| 仿真整段 forward kernel 重复出现（或真机重复而仿真不重复） | ⑤ 重计算策略 |
| 迭代次数本身不同、decode 段长度不同 | ⑥ early exit / 生成停止判定 |
| 缺失整层或整段 layer | ⑦ 并行切分/层分配（多半是配置问题） |
| 只在某个 rank 上多出 D2H + 文件 IO | ⑧ rank0 专属分支（日志/保存，通常无害） |
| 算子完全一致，只有 shape 有微小差别 | ⑨ 数值/RNG 差异，还没造成控制流分叉 |

---

## ① 溢出检测导致跳过优化器更新（最常见）

fp16/bf16 训练里，梯度是否溢出由设备算出，再回到 host 决定"这一步要不要更新权重"。
仿真器的数值一旦不准，`found_inf` 就可能翻转，整个优化器段凭空消失或凭空出现。

- 判据 tensor：`found_inf` / `float_status` / `grad_scaler` 的 scale
- 算子特征：`aten::_amp_foreach_non_finite_check_and_unscale_`、`NPUGetFloatStatus`、
  `NPUClearFloatStatus`，紧跟着 `aten::_local_scalar_dense`（`.item()`）
- 代码位置：

```bash
grep -rn "found_inf\|float_status\|_amp_foreach_non_finite\|update_successful\|found_inf_flag" \
  megatron/core/optimizer/ mindspeed*/optimizer/ 2>/dev/null
```

  Megatron 的 `MixedPrecisionOptimizer.step()` 里形如
  `found_inf_flag = self._unscale_main_grads_and_check_for_nan(); if found_inf_flag: return False, None, None`
- 验证：Step 7 探针，或在该 if 前后打印 `found_inf.item()`

## ② 梯度裁剪的系数分支

`clip_coeff = max_norm / (total_norm + eps)`，然后 `if clip_coeff < 1.0: 缩放所有梯度`。
`total_norm` 来自设备（还常常带一次 all-reduce），仿真数值不同 → 缩放这一段有无。

- 判据 tensor：`total_norm` / `grad_norm`
- 算子特征：`aten::_foreach_norm`、`ClipByNormNoDivSum`、`ReduceSumD` + `hcom_allReduce`，
  之后是否出现 `Muls` / `ForeachMulScalar`
- 代码位置：

```bash
grep -rn "clip_coeff\|clip_grad_norm\|total_norm\|get_grad_norm" megatron/core/optimizer/ mindspeed*/
```

## ③ MoE 路由与 token 分发（分歧最"壮观"的一类）

router 的 logits 决定 top-k 专家；每个专家收到多少 token 是设备算出来的，而 all-to-all
的通信量必须回到 host 才能建通信描述，于是这里天然有 `.cpu()` / `.tolist()` 同步点。
仿真里 router 数值一变，专家分配、丢弃(drop)、容量填充(pad) 全变，通信和分组矩阵乘全变。

- 判据 tensor：`router_logits` / `topk_idx` / `tokens_per_expert` / `capacity`
- 算子特征：`hcom_alltoall*` 的次数与 shape、`GatherV2`/`IndexSelect`、`GroupedMatmul`
  或每专家一个 MatMul、`SortV2`/`TopKV2`
- 代码位置：

```bash
grep -rn "tokens_per_expert\|topk\|routing_map\|capacity_factor\|drop_and_pad\|\.tolist()\|\.cpu()" \
  megatron/core/transformer/moe/ mindspeed*/moe/
```

  重点看 `router.py`（top-k、aux loss）与 `token_dispatcher.py`（all-to-all 前对
  `tokens_per_expert` 的同步读取）。
- 附加线索：`pa_align.py` 第 4 节的"同名算子 shape 不一致"，MoE 场景下通常在这里先亮。

## ④ 动态序列长度 / packing / mask

- 判据 tensor：`actual_seq_len` / `seq_lens` / `attention_mask` / `position_ids`
- 算子特征：`FlashAttentionScore` 的 `Input Shapes` 两边不同；attention 段算子数量不同；
  `reset_position_ids` 相关的 `NonZero`、`CumSum`、`MaskedSelect`
- 代码位置：

```bash
grep -rn "actual_seq_len\|variable_seq_lengths\|reset_position_ids\|reset_attention_mask\|eod_mask" \
  mindspeed*/ megatron/
```

- 注意：`nonzero` / `masked_select` 产生**数据相关的动态 shape**，它本身就是仿真最容易失真的地方。
- **形状驱动的分支要单独看（pa_srcbranch 的 🟠 档）**：`x.ndim == 2`、`layout == "TND"`、
  `actual_seq_len is not None` 这类判据不需要把设备值搬回 host，但只要两侧输入长度不同就会翻。
  典型后果是同一个 Linear 在一侧走 `aten::mm`/`aclnnMm`、另一侧走 `aten::matmul`/`aclnnMatmul`，
  连反向都从 `MmBackward` 变成 `MatmulBackward0`——热力图会大面积错位，但根因是形状不是数值。
- 若差异出现在一个**没有任何 if 的函数**里（如只做 padding 的 `pad_out`），说明判据在调用方，
  要往上一层找。

## ⑤ 重计算 / 自适应内存策略

MindSpeed 的 adaptive recompute / swap-attention 会根据"当前显存占用"在线决定要不要重算，
而仿真器报告的内存数字和真机不一样，于是 backward 里 forward kernel 重放与否发生变化。

- 判据 tensor / 值：`torch_npu.npu.memory_allocated()`、内存阈值、profile 出来的层耗时
- 算子特征：backward 段里整段 forward kernel（`RmsNorm`+`MatMulV3`+`FlashAttentionScore`）
  重复出现；两边重复次数不同
- 代码位置：

```bash
grep -rn "adaptive_recompute\|recompute_granularity\|swap_attention\|memory_allocated\|checkpoint(" \
  mindspeed*/ megatron/core/transformer/
```

- **先看启动参数**：`--recompute-granularity/-method/-num-layers`、`--adaptive-recompute-device-size`
  不同就是配置问题，不是仿真数值问题。

## ⑥ early exit / 生成停止判定（推理场景）

- 判据 tensor：`eos_mask` / `finished` / `unfinished_sequences` / 采样出的 token id
- 算子特征：decode 段整体重复次数不同——两边算子种类完全一样，但数量成比例差异
- 代码位置：

```bash
grep -rn "eos_token\|is_finished\|unfinished\|max_new_tokens\|while.*finished" <repo>
```

## ⑦ 并行切分 / 层分配差异

world size、TP/PP/EP/CP、`--num-layer-list`、`--noop-layers` 不同 ⇒ 同一个 rank 号承担的层
或专家不同。这类差异**不是仿真 bug**，必须在报告开头就排除掉，否则后面全是伪结论。
用 `pa_shargs.py --diff` 对比两侧启动脚本。

## ⑧ rank 相关的旁路分支

`if torch.distributed.get_rank() == 0:` 的日志、保存、评估分支会带来额外的 D2H 与文件 IO。
通常无害，但会在对齐结果里制造"仿真少了几个算子"的噪声，识别出来直接标注即可。

## ⑨ 数值差异但控制流还没分叉

两边算子序列完全一致、只有 shape/数值不同：说明仿真的数值误差还没有传播到任何分支上。
此时结论应该是"控制流未分叉"，并把 shape 不一致的位置作为**风险点**列出——它们是下一步
最可能翻转的地方。需要 tensor 级比对时，用昇腾的精度工具 msprobe 采集两侧张量再比对，
本 skill 只负责指出该比哪几个 tensor。

---

## 全量枚举分支的机械做法（不靠经验，也不靠猜）

上面的表是"常见嫌疑人"，但要做到**不漏**，用这三步机械地跑一遍：

1. `pa_pytrace.py` 给出两侧实际执行到的所有 Python 函数、调用边、以及每个函数发出的算子。
   凡是次数不同的边，caller 里就一定存在一个走向不同的分支——这是一个**完备**的候选集，
   因为调用次数不同不可能没有分支来决定。
2. `pa_srcbranch.py --from-pytrace` 把这些 caller 全部 AST 展开，得到守卫条件链、
   判据表达式、判据变量、以及变量的赋值来源。
3. `pa_srcbranch.py --scan-file` 对每个涉及的文件做全量分支枚举，按数值敏感度排序，
   补上"这次没走到、但下次可能翻转"的分支。

第 1 步保证不漏掉**已经发生**的分歧，第 3 步保证不漏掉**潜在**的分歧。

## 通用的"可疑 if"识别法

不在上表里的情况，回到第一性原理：**能让仿真走岔的 if，判据一定来自设备**。
在 `pa_evidence.py` 给出的同步点里，按这几个特征挑：

1. 每个 step 只执行 1-2 次（不是逐算子的例行拷贝）
2. 调用栈落在模型仓库代码里，而不是 torch/torch_npu 内部
3. 紧跟着出现算子构成的变化（分歧点就在它之后不远）
4. 判据是标量或很小的 tensor（`[1]`、`[8]`），因为要拿回 host 做判断

四条都满足的，基本就是它。

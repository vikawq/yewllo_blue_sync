# 报告模板

结论要能被别人复核，所以每条判断后面都要挂得上证据：算子名、shape、`file:line`、
或者探针日志。推测可以写，但必须标成推测并给出验证方法。

```markdown
# 真机 vs 仿真 Profiling 对齐分析报告（rank N）

## 0. 结论

**先给分类账，再给根因。** 差异必须归到 A/B/C/D 四类之一：

| 类 | 条数 | 是否阻断 D 类结论 | 摘要 |
| --- | --- | --- | --- |
| A 环境/版本不一致 | | 是 | |
| B 仿真器桩实现 | | 否（但要单列） | |
| C 配置/数据不一致 | | 是 | |
| D 数值导致的控制流分叉 | | — | |

- 是否存在阻断项（A 或 C）：是 / 否 → **若是，本报告 D 类结论全部标注为待验证**
- D 类分叉点：`<file>:<line>` 的 `<判据表达式>`
- 判据依赖的 tensor：`<tensor 名>`（shape，由哪次计算/算子产生）
- 后果：真机走 <分支A> 产生 `<算子列表>`；仿真走 <分支B> 产生 `<算子列表>`

## 0b. 全量分支清单（本次分析的完备性交代）

说明用什么方法保证"没漏"，并给出数量：

- `pa_pytrace.py` 发现调用次数不同的边 N 条 → 每条对应至少一个走向不同的分支
- `pa_srcbranch.py` 对这些 caller 展开出守卫条件 M 个，其中 🔴（判据来自设备数值）K 个
- `pa_srcbranch.py --scan-file` 对涉及的 F 个文件做了全量枚举，🔴 分支共 P 个（含本次未翻转的）

| # | 分类 | 代码位置 | 判据表达式 | 判据变量的完整来源链 | 真机分支 | 仿真分支 | **让仿真走真机侧的条件** | 涉及算子 |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 1 | D | `optimizer.py:412` | `if found_inf_flag:` | `found_inf_flag` ←L410 `found_inf_flag = self._check_nan()` ← `main_grads` ←L402 ... ←【根：函数参数 params】 | else | then | `found_inf_flag` 必须为假，即 `self._check_nan()` 返回 False | -ApplyAdamW ×399 |

「让仿真走真机侧的条件」这一列由 `pa_srcbranch.py` 直接给出（then/else 两个方向各一条，
并拆成逐变量要求）。**没有这一列的 D 类结论是不完整的**——只说"这里翻转了"没法落地，
要说清楚哪个变量得满足什么才能修。

统计口径：本报告引用的所有事件计数都注明 track、事件类别、窗口三项，取自 `alignment.md`
第 0 节。不要出现没有口径的"算子数 N 万"。

## 1. 数据与配置核对（排除伪分歧）

| 项 | 真机 | 仿真 | 是否影响结论 |
| --- | --- | --- | --- |
| rank 集合 / 本次对比 rank | 0-7 / 0 | 0-3 / 0 | ... |
| 并行配置 TP/PP/CP/EP | | | |
| 关键启动参数差异 | | | |
| profiler 配置(with_stack/record_shapes/level) | | | |
| 对齐所用 step | | | |

结论：以上差异 <已排除 / 解释了 X 部分差异>。

## 2. 算子序列对齐总览

按 thread 列出，host 与 device 分开：

| 侧 | track（真机 ↔ 仿真） | 算子数 | 对齐率 | 首个分歧位置 |
| --- | --- | --- | --- | --- |
| host/framework | python3 / Thread 1 ↔ ... | | | |
| host/CANN | | | | |
| device | Ascend Hardware / Stream N | | | |

关键判断：分歧首先出现在 <host framework / device> 层，因此这是
<控制流问题 / 算子选择或调度问题>。

## 3. 分歧点明细（Top N）

### 分歧 1：<一句话描述>

- 位置：real#<i> / sim#<j>，位于 <模块名> 段
- 最后共同算子：`...`
- 真机侧：`op1 -> op2 -> ...`（shape）
- 仿真侧：`op3 -> ...`（shape）
- 关联 device kernel / stream：
- tensor 线索：<同名算子 shape 不一致的位置>

## 4. 代码证据

| 证据类型 | 内容 |
| --- | --- |
| 同步点（值回到 host） | `file:line` `aten::_local_scalar_dense`，每 step 1 次 |
| 判定语句 | ```python\nif found_inf_flag:\n    return False, None, None\n``` |
| 判据 tensor | `found_inf`，由 `NPUGetFloatStatus` 产生 |
| 调用栈 | `.../optimizer.py:xxx` → `.../training.py:xxx` |
| 探针验证（若做了 Step 7） | `optimizer.py:412>413`(real) vs `412>420`(sim)，第 2 次迭代起分叉 |

## 5. 受影响的算子与 tensor 清单

| 算子 | 侧 | 真机 | 仿真 | 差异来源分支 |
| --- | --- | --- | --- | --- |
| `ApplyAdamW` | device | 3 | 2 | 溢出跳步 |
| `hcom_alltoall` | device | 18 | 27 | MoE 路由 |

| tensor | 产生位置 | 为什么怀疑它不准 |
| --- | --- | --- |

## 6. 复现与验证建议

1. <重采 profiling 时需要打开的开关>
2. <用 pa_branch_probe 复跑的具体命令>
3. <建议用 msprobe 比对的 tensor 列表>

## 附录

- 热力图：`pa_out/rank0/heatmap.html`
- 对齐明细：`pa_out/rank0/alignment.md`
- 证据链：`pa_out/rank0/evidence.md`
- Perfetto 合并 trace：`pa_out/merged_rank0.json`（打开方式见 references/perfetto-workflow.md）
```

## 写报告时容易犯的错

- 把"仿真多了 9 个 alltoall"直接写成结论。差异是现象，结论必须是那一行 if。
- 忘了标注哪些差异其实来自启动参数、版本、rank 角色不同（A/C 类）。
- 把仿真器的桩实现（B 类）写成"模型走了不同分支"。桩不是分支。
- 混着写 host 和 device 的差异，读者分不清是"下发不同"还是"执行不同"。
- 写耗时。本分析里耗时没有意义，出现时间数字只应是为了说明先后顺序。
- **把工具产物当成发现**：正好等于 `--limit-events` 的算子数是截断；对齐率 0 的 track 是
  配对/窗口问题。这类数字进了报告等于报告作废，提交前逐个核一遍。
- 对 shape 里的数字做算术凑等式。回去查模型配置（vocab_size / hidden_size / heads / seq_len）。

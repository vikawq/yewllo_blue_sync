# 报告模板

结论要能被别人复核，所以每条判断后面都要挂得上证据：算子名、shape、`file:line`、
或者探针日志。推测可以写，但必须标成推测并给出验证方法。

```markdown
# 真机 vs 仿真 Profiling 对齐分析报告（rank N）

## 0. 结论

- 控制流是否分叉：是 / 否
- 分叉点：`<file>:<line>` 的 `<判据表达式>`
- 判据依赖的 tensor：`<tensor 名>`（shape，来自哪个算子）
- 后果：真机走 <分支A> 产生 `<算子列表>`；仿真走 <分支B> 产生 `<算子列表>`
- 一句话原因：<仿真侧该 tensor 的值不准，导致判定翻转>

## 1. 数据与配置核对（排除伪分歧）

| 项 | 真机 | 仿真 | 是否影响结论 |
| --- | --- | --- | --- |
| rank 集合 / 本次对比 rank | 0-7 / 0 | 0-3 / 0 | ... |
| 并行配置 TP/PP/CP/EP | | | |
| 关键启动参数差异 | | | |
| profiler 配置(with_stack/record_shapes/level) | | | |
| 对齐所用 step | | | |

结论：以上差异 <已排除 / 解释了 X 部分差异>。

## 2. 算子序列对齐总览

按 thread 列出，host 与 device 分开：

| 侧 | track（真机 ↔ 仿真） | 算子数 | 对齐率 | 首个分歧位置 |
| --- | --- | --- | --- | --- |
| host/framework | python3 / Thread 1 ↔ ... | | | |
| host/CANN | | | | |
| device | Ascend Hardware / Stream N | | | |

关键判断：分歧首先出现在 <host framework / device> 层，因此这是
<控制流问题 / 算子选择或调度问题>。

## 3. 分歧点明细（Top N）

### 分歧 1：<一句话描述>

- 位置：real#<i> / sim#<j>，位于 <模块名> 段
- 最后共同算子：`...`
- 真机侧：`op1 -> op2 -> ...`（shape）
- 仿真侧：`op3 -> ...`（shape）
- 关联 device kernel / stream：
- tensor 线索：<同名算子 shape 不一致的位置>

## 4. 代码证据

| 证据类型 | 内容 |
| --- | --- |
| 同步点（值回到 host） | `file:line` `aten::_local_scalar_dense`，每 step 1 次 |
| 判定语句 | ```python\nif found_inf_flag:\n    return False, None, None\n``` |
| 判据 tensor | `found_inf`，由 `NPUGetFloatStatus` 产生 |
| 调用栈 | `.../optimizer.py:xxx` → `.../training.py:xxx` |
| 探针验证（若做了 Step 7） | `optimizer.py:412>413`(real) vs `412>420`(sim)，第 2 次迭代起分叉 |

## 5. 受影响的算子与 tensor 清单

| 算子 | 侧 | 真机 | 仿真 | 差异来源分支 |
| --- | --- | --- | --- | --- |
| `ApplyAdamW` | device | 3 | 2 | 溢出跳步 |
| `hcom_alltoall` | device | 18 | 27 | MoE 路由 |

| tensor | 产生位置 | 为什么怀疑它不准 |
| --- | --- | --- |

## 6. 复现与验证建议

1. <重采 profiling 时需要打开的开关>
2. <用 pa_branch_probe 复跑的具体命令>
3. <建议用 msprobe 比对的 tensor 列表>

## 附录

- 热力图：`pa_out/rank0/heatmap.html`
- 对齐明细：`pa_out/rank0/alignment.md`
- 证据链：`pa_out/rank0/evidence.md`
- Perfetto 合并 trace：`pa_out/merged_rank0.json`（打开方式见 references/perfetto-workflow.md）
```

## 写报告时容易犯的错

- 把"仿真多了 9 个 alltoall"直接写成结论。差异是现象，结论必须是那一行 if。
- 忘了标注哪些差异其实来自启动参数或 rank 角色不同。
- 混着写 host 和 device 的差异，读者分不清是"下发不同"还是"执行不同"。
- 写耗时。本分析里耗时没有意义，出现时间数字只应是为了说明先后顺序。

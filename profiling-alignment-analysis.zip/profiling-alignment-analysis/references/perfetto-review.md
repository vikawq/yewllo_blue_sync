# Perfetto 官方 UI 内容复核

## 目录

1. 加载语义与隐私边界
2. 批量执行
3. 结构查询与禁止项
4. HTML/文本/SQL 与截图边界
5. 完成门禁
6. 失败与降级

## 1. 加载语义与隐私边界

只有用户明确确认该 trace 符合组织数据政策时，才允许在线访问并使用 `--online-authorized`。未授权默认写 `not-executed/partial`，继续本地解析，不静默联网。用户称“上传到 Perfetto 网站”时，准确执行和表述为：

1. 浏览器联网加载 `https://ui.perfetto.dev/` 官方 UI 代码；
2. localhost host page 把本地 `trace_view.json` 读入主页面内存；
3. 校验 PING/PONG 的精确 `event.origin` 与 `event.source`；
4. 阻断 Service Worker，并在浏览器 context 切换 offline；
5. 只有 `offline_before_trace_post=true` 后，才把 trace `ArrayBuffer` 以 `localOnly=true` 发送给已加载 UI；
6. 不点击 Share、不生成 permalink、不使用 URL `url=` 让 UI 主动抓 trace。

Perfetto 官方 embedding API 说明 posted trace 默认 `localOnly=true`，禁用下载/分享；walkthrough 说明 trace buffer 只在浏览器内存处理。仍需注意：

- `localOnly` 不是单独的机密性边界；
- 浏览器先联网获取滚动更新的官方 UI，网站会看到普通网页访问/IP 元数据；
- trace 内容的额外保护来自“offline 早于 trace post + Service Worker 为 0 + 精确 origin”；
- HTML、文本、log、manifest、可选 PNG 可能含算子名、线程名和本地路径，按原 trace 等级保护；
- 如果组织政策不允许第三方网页代码接触 trace，改用固定版本自托管 UI 或本地 `trace_processor`，并明确在线复核未执行。

实现依据：

- [Perfetto UI](https://perfetto.dev/docs/visualization/perfetto-ui)
- [Embedding API reference](https://perfetto.dev/docs/visualization/embedding-api-reference)
- [Embedding the UI](https://perfetto.dev/docs/visualization/embedding-the-ui)
- [Commands/automation](https://perfetto.dev/docs/visualization/commands-automation-reference)
- [PerfettoSQL](https://perfetto.dev/docs/analysis/perfetto-sql-getting-started)
- [Other trace formats](https://perfetto.dev/docs/getting-started/other-formats)

Ascend `trace_view.json` 的 Chrome Trace JSON 基本可由 Perfetto 读取，但 Perfetto 将该格式视为 legacy/best-effort。因而官方 UI 是逐 Rank 的二次交叉复核，本地 Ascend-aware parser 与 CSV/JSON 证据仍是完整结构结论的主基准。

## 2. 批量执行

每个同号 Rank 的真机与仿真 `trace_view.json` 都要独立加载，不把多个 Rank 合并到同一 timeline。每个 trace 使用独立 SHA-256、输出目录和 manifest。

先调用 workspace dependency discovery，找到受信 Node.js 与 `playwright-core`。`PERFETTO_PLAYWRIGHT_NODE_MODULES` 必须显式指向 Codex/受信运行时的绝对 `node_modules`，不得指向模型代码仓、当前目录或 `NODE_PATH`。

运行：

```powershell
$env:PERFETTO_PLAYWRIGHT_NODE_MODULES = "<trusted-node_modules>"
python scripts/render_perfetto_batch.py `
  --alignment-output "<alignment-output>" `
  --output "<alignment-output>/perfetto-review" `
  --online-authorized `
  --node "<trusted-node-executable>"
```

默认串行以控制大 trace 的内存峰值。一个 Rank 的全部 renderer-compatible `framework_op` 与 `host_launch` lanes 尽量一次查询；超过 128 时由 wrapper 确定性分批。两层在结果中保持独立，不把 launch bridge 称为 PyTorch 算子。非数字或超出 JavaScript safe integer 的 PID/TID 标受限，不截断、不强转；本地 `canonical_events.csv` 仍保留其结构证据。Device lanes 不用 Host thread SQL 伪装复核，仍以本地 parser 为主证据。

只在确实需要 Canvas 像素/轨道几何时追加 `--screenshot`。截图不是内容复核硬门禁。

## 3. 结构查询与禁止项

`render_perfetto_trace.mjs` 的公开 SQL 表只查询：

- Host PID/TID/process/thread；
- lane 内 event ordinal；
- nesting depth；
- category/operator；
- operator calls。

序号 SQL 必须使用 `ROW_NUMBER() OVER (PARTITION BY pid,tid ORDER BY ts,depth,id)`；跨 lane 的全局 ordinal 无效。保留 `track_id/track_name/parent_id` 并检测同一 pid/tid 的 multi-track/overflow。查询不得以全局 `LIMIT 20000` 静默截断；若实现上必须分页，则 manifest 为每 lane 记录 `total/emitted/truncated`，任何 truncated 都使 job `partial`。

内部 debug slice track 必须使用 `ts/dur` 才能让 UI 画 slice，但这些字段只用于 UI 导航，不进入数值表或报告。

禁止：

- 按 `SUM(dur)` 排热点；
- 输出 total/avg/max/self duration；
- 从 Canvas 条块宽度、空白或颜色面积解释耗时；
- 用网页像素代替本地结构 CSV；
- 把 Perfetto Host thread SQL 当作 Device stream 证据；
- 按时间最近把 Host 与 Device 关联。

Device 顺序来自本地 trace parser 或 `kernel_details.csv`；Host→Device 只用 direct flow/correlation。Perfetto UI 用于复核 Host track、顺序、嵌套、operator、调用数和页面状态。

## 4. HTML/文本/SQL 与截图边界

每个 job 产生：

```text
perfetto_ui_frame.html
perfetto_ui_text.txt
perfetto_browser.log
perfetto_manifest.json
perfetto_ui.png（仅 --screenshot）
```

分析代理必须实际读取：

- `perfetto_manifest.json` 的 selection、trace hash、SQL、offline gate；
- `perfetto_ui_text.txt` 或静态解析 `perfetto_ui_frame.html`；
- manifest 中可见 query grid rows；
- browser log 的 error/request 状态。

导出的 HTML 只作为静态 DOM/text 快照读取，不要再次打开执行。Perfetto timeline 主体是 Canvas，HTML 不包含完整颜色块和几何。因此：

| 证据 | 可以评价 | 不可以评价 |
|---|---|---|
| 本地 CSV/JSON | 完整 operator 序列、Shape、首次差异、calls、flow | Canvas 视觉布局 |
| Perfetto HTML/text/SQL | 页面已加载、track/查询状态、可见 operator/ordinal/calls | Canvas 色块、条宽、空白区 |
| 实际查看 PNG | 可见 Canvas 颜色/轨道几何 | 任何 duration/性能含义 |

UI query grid 可能虚拟化，只保存可见行；完整数值以本地 parser CSV 为准。HTML/SQL 是交叉复核，不是唯一数据源。

## 5. 完成门禁

自动产物只有同时满足以下条件才写 `auto-artifacts-ready`：

```text
manifest.status == success
online_authorized == true
ui_origin == https://ui.perfetto.dev
local_only == true
offline_before_trace_post == true
service_worker_count_after_render == 0
service_worker_guard_visible_in_perfetto_frame == true
successful_responses_after_offline == 0
duration_metrics_emitted == false
trace SHA-256 == rank_pairs.csv 对应本地 trace
selection lanes == 该 Rank/side lane batch
per-lane total == emitted 且 truncated == false
query error 为空且 row count 可核验
run_id/started_at 属于本次新运行
HTML/text/log/manifest 存在
```

`auto-artifacts-ready` 不等于内容复核完成。实际读取后维护 `perfetto_content_review.json`，至少记录：

```json
{
  "status": "complete",
  "review_methods": ["manifest", "html", "text", "sql"],
  "reviewed_rank_sides": ["rank-0000/real", "rank-0000/sim"],
  "observations": ["..."],
  "screenshot_reviewed": false,
  "canvas_claims_made": false
}
```

每个 `rank_pairs.csv` pair 的两侧都要有 job；失败、skipped、not-run、缺 trace 或缺 lane coverage 不妨碍其它 Rank 继续，但总状态必须为 partial，并逐项列原因。wrapper 要实际重算 trace SHA、检查 artifact 非空、验证 lane batch 并集恰好覆盖期望 lanes，并拒绝旧 run_id/残留 artifact；不能只信 renderer manifest 自报。

## 6. 失败与降级

### 无网络/浏览器/Playwright

运行批处理命令并加 `--degraded-reason "<具体原因>"`，写出标准 `perfetto_content_review.json`；继续用本地流式 parser 完成全部 Rank/Thread 结构分析。不得伪称已读页面。

### 网络政策或机密门禁不允许

不请求绕过政策。改用固定自托管 UI 或本地 trace processor；报告说明没有访问官方在线 UI。

### UI 更新导致 automation 失败

保存 browser log、frame text 和 manifest；记录官方 UI 是滚动版本。需要可复现时固定自托管 build，并记录 build hash。

### lane 太多

确定性分批，保持同一个 Rank/side 与 trace SHA；batch union 必须覆盖全部兼容 Host lane。不能静默只看一个线程。

### 页面只返回部分可见行

不把可见 DOM 行当完整数据；用 `canonical_events.csv` 与 `event_alignment.csv` 为基准，Perfetto 只确认可见内容和查询执行状态。

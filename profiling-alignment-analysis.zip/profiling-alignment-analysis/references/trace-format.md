# 昇腾 profiling 数据结构速查

版本之间字段会变，所以**先探测再假设**：`pa_common.py` 的分类结果会打印出来，
不确定时用下面的一行命令直接看这份 trace 里到底有哪些进程和线程。

```bash
python -c "import sys;sys.path.insert(0,r'<SK>');from pa_common import load_trace;
t=load_trace(r'<trace_view.json>');[print(r) for r in t.summary()[:25]]"
```

## 1. 目录结构（torch_npu.profiler，PyTorch + torch_npu）

```
{worker}_{timestamp}_ascend_pt/          ← 一个 rank 一个这样的目录
├── ASCEND_PROFILER_OUTPUT/              ← 解析后的结果，分析主要看这里
│   ├── trace_view.json                  ← chrome trace 格式的时间线（本 skill 主输入）
│   ├── kernel_details.csv               ← device 侧 kernel 明细（含 Input Shapes）
│   ├── operator_details.csv             ← framework 算子明细（含 Call stack，需 with_stack）
│   ├── op_statistic.csv / api_statistic.csv
│   ├── step_trace_time.csv
│   ├── communication.json / communication_matrix.json
│   ├── profiler_metadata.json
│   └── ascend_pytorch_profiler_{rank}.db   ← export_type=db 时才有
├── FRAMEWORK/                           ← 框架层原始数据
├── PROF_XXXXXX_XXXXXXXX/                ← CANN 原始采集
│   ├── device_{id}/  host/  mindstudio_profiler_output/
├── logs/
└── profiler_info_{rank}.json            ← rank 号 + 采集配置（activities/with_stack/level）
```

判 rank 号优先看 `profiler_info_{rank}.json` 的文件名，其次看 `ascend_pytorch_profiler_{rank}.db`，
最后才看目录名里的 `rank_N`。注意 `PROF_*/device_{id}` 里的 id 是**设备号不是 rank**。

MindSpore 侧结构不同（`rank_{n}/profiler/ascend_timeline_display_{rank}.json`），`pa_discover.py`
能认出来，但本 skill 的启发式规则是按 PyTorch 栈写的，遇到 MindSpore 要额外确认。

## 2. trace_view.json 的结构

标准 Chrome Trace Event Format：一个 JSON 数组（少数版本是 `{"traceEvents": [...]}`）。

| ph | 含义 | 本 skill 怎么用 |
| --- | --- | --- |
| `M` | metadata：`process_name` / `thread_name` | 建立 track 名字，判 host/device |
| `X` | 完整事件（有 ts + dur） | 算子本体，序列对齐的原料 |
| `s` / `f` | flow 起点/终点，靠 `id` 配对，`cat` 常见为 `async_npu` | host 下发 → device kernel 的连线 |
| `C` | counter（内存、频率） | 忽略 |

典型的进程分组（名字随版本变化，务必以实际探测为准）：

| process_name | 侧 | 里面是什么 |
| --- | --- | --- |
| `python3` / `Python` | host / framework | `aten::*`、`torch_npu::*`、`c10d::*`、`nn.Module: *`、`Optimizer.*`、`ProfilerStep#N` |
| `CANN` | host / runtime | `aclnn*`、`AscendCL@aclrt*`、`Node@launch`、`Model@*` |
| `Ascend Hardware` | device | 线程 = `Stream N`，事件是真正执行的 kernel（`MatMulV3`、`FlashAttentionScore`、`RmsNorm`…） |
| `HCCL` | device | 集合通信任务：`hcom_allReduce__*`、`Notify_Wait`、`RDMASend` |
| `Overlap Analysis` | 派生 | `Computing` / `Communication` / `Free`，是统计不是算子，**不参与对齐** |

`args` 里常见且有用的键（不同版本命名不一致，脚本对多个候选都做了兼容）：

- shape：`Input Dims` / `Input Shapes`
- dtype：`Input type` / `Input Data Types`
- 调用栈：`Call stack`（形如 `/path/file.py(123): func_name`，`;` 分隔），需要采集时
  `with_stack=True`
- device kernel：`Task Type`（`AI_CORE` / `AI_VECTOR_CORE` / `MIX_AIC` / `AI_CPU` / `COMMUNICATION`）、
  `Stream Id`、`Task Id`

## 2b. python_function 事件（本分析最有价值的事件）

`with_stack=True` 时，torch profiler 会给**每一次 Python 调用**发一个 `X` 事件，名字就是：

```
/abs/path/mindspeed_mm/patchs/adaptive_clip_grad_patch.py(331): get_grad_norm_fp32_async
```

它们按调用关系天然嵌套，等价于一棵完整的调用树。`pa_pytrace.py` 就是靠它做两侧比对的：
函数集合差 → 谁没走到 / 谁是桩；同函数行号差 → 版本不一致；调用边计数差 → 分支走向不同；
函数下挂的算子差 → 分支造成的算子差异。

注意两侧的**绝对路径几乎一定不同**（不同环境、不同 checkout），比较前必须归一化：
`pa_common.norm_pypath()` 会在 `site-packages/` / `dist-packages/` 处截断，或按 `--repo` /
`--extra-root` 给的前缀截断。忘了归一化会得到"每个函数都只在一侧出现"的荒谬结论。

没有这类事件 = 采集时没开 `with_stack`。此时只能退回算子序列层面做粗定位，
应当明确建议用户重采：`with_stack=True, with_modules=True, record_shapes=True`。

## 3. host 侧 / device 侧怎么分，为什么必须分开

- **host 侧**回答"框架下发了什么"。控制流分叉的原因**只可能出现在 host 侧**，因为 `if` 是
  Python 执行的。
- **device 侧**回答"硬件实际执行了什么"。同一批下发在设备上可能因为算子选择、融合、多流调度
  而排布不同。

因此：host 一致 + device 不同 ⇒ 不是控制流问题（多半是算子选择/融合/调度）；
host 就不同 ⇒ 才是本 skill 要追的那类问题。

flow 事件（`ph:s`/`ph:f`）把两侧连起来：`pa_evidence.py` 用它把一个可疑的 device kernel
反查到下发它的 `aten::` 算子，再从那里拿调用栈。如果 trace 里没有 flow 事件，退回用
`kernel_details.csv` 的 `Correlation Id` / 同 step 内序号对应。

## 4. CSV 补充信息（trace 里没有时去查）

- `kernel_details.csv`：`Name, Type, Accelerator Core, Task ID, Stream ID, Input Shapes,
  Input Data Types, Output Shapes, Block Dim, ...`。当 trace 的 device 事件缺 shape 时，
  用这里的 `Input Shapes` 补齐 tensor 级证据。
- `operator_details.csv`：framework 算子 + `Call stack`，比从 trace 里抠调用栈更整齐，
  适合批量 grep 代码位置。

## 5. 采集配置对分析的影响（务必核对）

| 配置 | 不开会怎样 |
| --- | --- |
| `with_stack=True` | 没有调用栈，Step 6 只能靠 `nn.Module:` 模块栈粗定位 |
| `with_modules=True` | 没有 `nn.Module: xxx` 层级，定位更难 |
| `record_shapes=True` | 没有 shape，看不到"同名算子不同 tensor"这条最有价值的线索 |
| `profiler_level` | Level0 只有粗粒度，device 侧算子可能缺失 |

两侧配置不一致时，**先统一再比**；否则会把"没采到"误判成"没执行"。

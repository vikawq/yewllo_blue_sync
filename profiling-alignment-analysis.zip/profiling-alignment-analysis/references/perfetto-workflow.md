# 用 ui.perfetto.dev 看 trace

Perfetto 在这套流程里的定位：**给人看的直观证据**。它擅长"一眼看出两边从哪里开始不一样"，
以及用 SQL 快速交叉验证脚本的结论。分析结论仍然以本 skill 的脚本输出为准。

## 1. 标准流程

```bash
python "$SK/pa_perfetto.py" merge --real <real trace> --sim <sim trace> \
    --out "$WS/merged_rank0.json" --step -2
python "$SK/pa_perfetto.py" serve --file "$WS/merged_rank0.json" --port 9001
```

merge 做了三件事：两侧各自平移到 t=0（耗时不可比，对齐起点才能上下对照）、进程名加
`[REAL]` / `[SIM]` 前缀、仿真侧 pid 挪到独立区间避免撞车。只切一个 step 能让文件小到浏览器
秒开——整段 trace 动辄几百 MB，加载慢且没必要。

serve 打印两个链接：

1. `https://ui.perfetto.dev/#!/?url=http://127.0.0.1:9001/merged_rank0.json`
2. `http://127.0.0.1:9001/pa_open_perfetto.html`

## 2. 两个必须知道的坑（实测确认）

**端口只能是 9001。** ui.perfetto.dev 的 CSP 里 `connect-src` 对本地明文 http 只放行
`http://127.0.0.1:9001`。换成 9002/9223 之类，控制台会直接报
`Connecting to 'http://127.0.0.1:9223/...' violates the following Content Security Policy directive`。

**有些浏览器环境会整体拦截 https 页面对 127.0.0.1 的请求。** 表现是 Perfetto 弹
`Could not load local trace TypeError: Failed to fetch`，而本地服务器日志里**看不到任何请求**
（用 `curl http://127.0.0.1:9001/xxx.json` 能通，说明服务器没问题）。Chrome 的 Private
Network Access 会为这类请求加预检，`pa_perfetto.py` 已经回了
`Access-Control-Allow-Private-Network: true`；如果仍被拦，就改用 `pa_open_perfetto.html`：
它从同源取到文件，再通过窗口间 postMessage 把 buffer 交给 Perfetto，不走跨源网络请求。

**Claude 自己的内置浏览器已确认会拦。** 所以不要把"agent 在内置浏览器里成功加载 trace"
当作流程的一环：把链接给用户，让用户在自己的浏览器里打开；agent 的判断依据用脚本输出、
`heatmap.html` 和 `alignment.md`。用户手上如果装了 MindStudio Insight，它也能直接打开
`trace_view.json`，是等价的替代。

## 3. 打开后看什么

1. 左侧进程列表会分成 `[REAL] ...` 和 `[SIM] ...` 两组，把同名的 track 上下拖到一起。
2. 先看 `Ascend Hardware` 的各条 `Stream`：从左往右扫，找**第一处两边"花纹"开始错位**的位置。
3. 再看 `python3` 线程里的 `ProfilerStep#N` 和 `nn.Module:` 层级，确认错位发生在模型的哪一段
   （attention / mlp / moe / optimizer）。
4. 点中错位处的第一个 slice，看 `Arguments` 里的 `Input Dims` 和 flow 箭头指向的 host 算子——
   这就是要喂给 `pa_evidence.py --uid` 的那个算子。

## 4. 用 Query (SQL) 交叉验证

左侧 `Query (SQL)`，输入后 Ctrl+Enter。合并后的 trace 里两侧在同一个库，可以直接对比：

```sql
-- 每个算子在真机/仿真各出现多少次，只列不相等的
select s.name as op,
       sum(case when p.name like '[REAL]%' then 1 else 0 end) as real_cnt,
       sum(case when p.name like '[SIM]%'  then 1 else 0 end) as sim_cnt
from slice s
join thread_track tt on s.track_id = tt.id
join thread th using(utid)
join process p using(upid)
group by 1
having real_cnt <> sim_cnt
order by abs(real_cnt - sim_cnt) desc
limit 40;
```

```sql
-- 有哪些 track，各多少个 slice（确认 track 配对是否合理）
select p.name as proc, th.name as thread, count(*) as n
from slice s join thread_track tt on s.track_id = tt.id
join thread th using(utid) join process p using(upid)
group by 1,2 order by n desc;
```

```sql
-- 某个算子在两侧的出现顺序（看它在序列里的相对位置是否漂移）
select p.name as side, s.ts, s.name
from slice s join thread_track tt on s.track_id = tt.id
join thread th using(utid) join process p using(upid)
where s.name like 'hcom_alltoall%'
order by side, s.ts limit 100;
```

这些查询的结论应该和 `alignment.md` 第 3 节的算子数量差异一致；**不一致就说明 track 配对
或 step 窗口选错了**，回去修，别急着下结论。

## 5. 隐私说明（可以直接转告用户）

Perfetto UI 在浏览器里用 WASM 解析 trace，文件是从本机的临时服务器取的，不会上传到
Google；只有主动点 Perfetto 的 "Share" 按钮才会上传。分析完记得停掉本地服务器
（`serve` 到时间会自动退出，默认 1800 秒）。

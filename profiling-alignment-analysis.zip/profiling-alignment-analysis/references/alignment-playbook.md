# 全 Rank / 全 Thread 结构对齐手册

## 目录

1. 角色与范围门禁
2. Rank 发现与配对
3. Host 与 Device 事件域
4. Thread/lane 配对
5. 算子树与序列对齐
6. 序位热力图与首次分叉
7. Host→Device 直接关联
8. 产物与完整性检查
9. 失败模式

## 1. 角色与范围门禁

固定：

```text
reference = 真机
candidate = 仿真
```

用户必须明确标注哪一侧是真机、哪一侧是仿真。不得从路径名、机器名、事件数量或性能猜角色。

本分析只回答结构与控制路径问题：执行了哪些算子、在哪个 Rank、哪个 Host Thread 或 Device stream、以什么顺序和嵌套关系执行、Shape/dtype/format 是否一致、首次可观测分叉在哪里。禁止输出或解释 duration、latency、self/total time、利用率、重叠、空闲、带宽、快慢、性能比率或时间误差。

`ts/dur` 只允许在解析器内部用于：

- 校验 `X` slice 与配对 `B/E`；
- 确立同一 lane 内稳定事件顺序；
- 恢复嵌套父子关系；
- 将标准 Chrome flow 端点绑定到包含该端点的 slice。

Ascend trace 的 epoch 级微秒时间可能带小数；解析器必须用 `Decimal` 或整数纳秒并以 `source_event_index` 作最终稳定 tie-break，禁止转 IEEE-754 `float` 后再决定顺序、嵌套或 flow 端点。

公开 CSV、报告和结论均使用事件序位，不输出 duration 字段。调用数是结构事实，可以报告；不能把它乘以或除以时间。

## 2. Rank 发现与配对

先运行 `preflight_ascend_profiles.py`。当前完整支持范围是 TorchNPU 已整合生成的 `ASCEND_PROFILER_OUTPUT` text export；纯 `PROF_*/mindstudio_profiler_output/msprof_*.json`、`analysis.db` only 或只有聚合统计的输入标 `unsupported/partial`，不能当成“零事件”的 integrated export。

递归发现每侧全部 `ASCEND_PROFILER_OUTPUT`。`profiler_info*.json` 中的 `rank_id/global_rank` 是权威身份，明确目录标记只作 fallback。若 metadata 与目录 Rank 冲突，把目录列入 `unpaired_ranks.csv` 并标 `rank-identity-conflict`；不得按优先级静默选一个。DP/TP/EP/PP/CP/DCP 只作为拓扑审计字段。

配对规则固定为：

```text
paired = sorted(real_global_rank_ids ∩ sim_global_rank_ids)
```

例如真机 `0..7`、仿真 `0..3`，只生成 `(0,0)`、`(1,1)`、`(2,2)`、`(3,3)`。不得把 Rank 4 与仿真 Rank 0 配对，不得按目录枚举顺序左移、补位或重编号。

若 Rank ID 缺失或重复：

- 将对应目录列入 `unpaired_ranks.csv`；
- 标记 `未知/重复`；
- 不从相邻目录推断；
- 需要用户提供可审计的 rank metadata 或明确映射后才能继续该 Rank。

每个同号 pair 仍检查并行坐标。坐标冲突不会改变同号配对，但会降低“同一逻辑分片”的可比性；报告必须列出冲突。

## 3. Ascend 三层事件域

先读取 process/thread metadata，再分类普通事件。严格使用三层语义：

```text
framework_op = Host 上的 PyTorch dispatcher/custom cpu_op
host_launch  = Host 上的 CANN/AscendCL/GE/Runtime/enqueue/dequeue bridge
device_task  = Ascend Hardware 上的 kernel/HCCL/memcpy/task
```

公开 `domain` 可保留 `host/device`，但每个事件必须另有 `semantic_layer`。Host lane 至少包含 `rank+semantic_layer+pid+tid+track`；Device lane 包含 `rank+device+stream+track`。

`framework_op` 只纳入可确认的 PyTorch dispatcher/custom `cpu_op`，例如 `aten::`、`torch_npu::`、`npu::`、`c10d::`。`ProfilerStep`、module scope、autograd scope、Python scope 不冒充逐调用 dispatcher 算子，但可作为树/阶段辅助证据。

`CANN`、`AscendCL/ACL`、`GE`、`Runtime`、`enqueue/dequeue` 即便 args 含 `Device Id`、`Stream Id`，也仍是 `host_launch`；不得仅凭名称含 `npu/device/stream/runtime` 判为 Device。

`device_task` 只在存在强证据时确认：

1. `trace_view.json` 的 Ascend Hardware/NPU process 或明确 kernel/HCCL/memcpy/task hardware track；单独出现 `HCCL/HCOM` 名称或 category 不足以证明 Device；
2. `cat=kernel`、可信 `Task Type`，或同时可见 Device/Stream/Task 字段；
3. trace 没有已确认 `device_task` 时，才用 `kernel_details.csv` 逐行补充。

标准 CSV 应识别 `Start Time(us)`、`Task Start Time(us)`、`Stream ID`、`Task Id/Task ID`、`Task Type`、`Accelerator Core`、`Model ID`、`Step ID`。若缺 `Stream ID`，只保留 Rank 级 Device coverage 并写 `lane_observability=rank-only`，不能构造 `stream=unknown` 的伪可比 lane。Host launch 的存在不得抑制 kernel CSV fallback。

`operator_details.csv` 可写入独立的 Rank 级 coverage/Shape/call-stack 交叉表，但若缺少 pid/tid，不得追加到 `canonical_events.csv` 或写成 Thread 级运行事实。聚合的 `op_statistic.csv` 不能证明逐事件顺序。

实现与复核优先参考华为官方产物定义和 TorchNPU 解析代码：

- [MindStudio：使用 Perfetto UI 打开 trace_view.json](https://www.hiascend.com/document/detail/en/mindstudio/700/TITools/Profiling/atlasprofiling_16_1149.html)
- [Ascend PyTorch CANN file parser](https://github.com/Ascend/pytorch/blob/f8802037a71d7224a215813ba4f420785fb2113a/torch_npu/profiler/analysis/prof_parse/_cann_file_parser.py)
- [Ascend PyTorch trace event manager](https://github.com/Ascend/pytorch/blob/f8802037a71d7224a215813ba4f420785fb2113a/torch_npu/profiler/analysis/prof_common_func/_trace_event_manager.py)

Shape 规则：

- Input/Output Shape 只使用该事件或 CSV 直接记录的字段；
- Output Shape 缺失时写未知，不从下游 kernel 反推；
- Shape 相同不证明 tensor value、tensor identity、storage、routing 或控制条件结果相同；
- tensor/address ID 只在同环境内哈希后用于溯源，不作为跨环境 tensor 身份。

## 4. Thread/lane 配对

每个 Rank 分析全部含已分类事件的 framework Host lane、Host launch lane 与可观察 Device lane，不随机抽样，不用一个主线程代表整个 Rank。三层分别配对，禁止跨层匹配。

跨环境 PID/TID、stream ID 通常不稳定，不能直接作为配对主键。`align_profiles.py` 对同一域做确定性一一匹配，特征包括：

- 规范化 process/thread 名；
- operator 3-gram；
- `operator + Shape` 多重集合；
- 相邻 parent-child/sequence 边；
- correlation 角色特征。

唯一且非空的规范化 process/thread 名精确相同时可直接高置信配对；其余使用确定性最大权匹配。默认等级：

| 状态 | 条件 | 允许结论 |
|---|---|---|
| `matched/高` | 唯一名称或 score ≥ 0.80 且 margin ≥ 0.15 | 可做严格逐 lane 结构对齐 |
| `matched-degraded/中` | score ≥ 0.65 且 margin ≥ 0.10 | 可列差异；控制流结论须结合源码/stack |
| `ambiguous/低` | 其余 | 不强配，不做逐 lane 因果结论 |
| `real-only/sim-only` | union 中仅一侧存在 | 明确列出，不静默丢弃 |

人工可以推翻配对，但必须记录替代 PID/TID、证据和原因；不得仅凭“看起来时间位置接近”改配。

## 5. 算子树与序列对齐

每个事件至少保存：

```text
rank, domain, semantic_layer, lane_id, lane_observability,
pid, tid, track_id/name, device_id, stream_id, task_id/type,
event_id, source_event_index, thread_ordinal, normalized_ordinal,
depth, parent_event_id,
sibling_ordinal, raw_name, canonical_op, op_family,
input/output shape, dtype, format, stack/module, direct scalar evidence
```

同时运行三种视图：

1. `op-only`：只看规范化 operator；
2. `op+metadata`：加入 Shape/dtype/format；
3. `tree-aware`：再加入 depth/parent-presence。

允许先把连续相同 token 压成 run 以减少比对规模，但 run token 必须携带 `run_calls`。真机连续 2 次与仿真连续 3 次同名算子必须输出调用数差异，不能压缩成 `exact`。输出至少包含 `real_run_calls/sim_run_calls` 与 relation：

```text
exact, metadata_mismatch, substitute, real_only, sim_only
```

`tree-aware` token 应尽量包含 module hierarchy、call-stack fingerprint、parent operator 与 sibling/run 序位。重复 Transformer 层或大段重复 token 使多个非交叉对齐同样最优时，标 `repeated-anchor-ambiguous`，不得把任意一次平移结果当成唯一首次差异。

若三种视图的首个非 equal 边界有任何一个缺失，或非 equal 边界彼此不同，标 `boundary_stability=unstable`。只有三者都为 `None`（完全一致），或三者都是同一边界，才可标 stable。

控制流升级还要求首差异前后各至少 3 个 exact anchor；把 `anchors_before`、`anchors_after` 和 `anchor_gate_passed` 写入 divergence。direct branch marker 可替代锚点数量。缺锚点不阻止展示差异，但只允许静态候选。

“Rank 全局最早”需要跨 Thread flow/marker 或明确调度边；没有直接证据时，只报告每个逻辑 Thread 内首个分叉，不按跨线程绝对时间戳排序成全局因果链。

## 6. 序位热力图与首次分叉

结构热力图固定：

```text
x = lane-relative normalized event ordinal
y = matched logical Host Thread 或 Device stream
color = operator family
red outline = first divergence window
```

它不是时间热力图。格宽、颜色面积、空白和连续块长度均不得解释为 duration、利用率、停顿或性能。首次差异以 `event_alignment.csv` 和 `divergence_windows.jsonl` 为准，HTML 只用于导航。

每个 matched lane 的首次分叉窗口至少记录：

- 最后一个共同 anchor；
- 真机首个差异 run；
- 仿真首个差异 run；
- 下一共同 anchor；
- 两侧 operator、Shape、call stack、module；
- 三种视图的边界稳定性；
- 更早 unresolved 是否存在；
- 替代解释。

不要只展示长串 equal 前缀；报告直接显示首个差异前后少量上下文。

## 7. Host→Device 直接关联

Ascend flow 必须按 namespace 解析，不得把裸数值 ID 放在同一字典。至少区分：

```text
async_npu / torch_to_npu
async_task_queue
HostToDevice
fwdbwd
MsTx（若存在）
```

flow key 至少包含 `cat + name + scope + id/id2`，且合法 ID `0` 不能因布尔判断丢失。`correlation_id` 与 `external_id` 必须按 `(id_kind,value[,cat/scope])` 分开。

只允许：

- Chrome trace `s/t/f` flow 的 namespace 正确、角色合法且端点唯一的直接边；
- 同环境内明确、同 kind 且唯一的 `correlation_id` 或 `external_id`；
- profiler 明确记录的 launch/correlation 边。

端点先按 `(pid,tid,ts)` 精确事件/边界匹配；只有唯一 containment 时才可标 degraded containment，多个候选标 group-level ambiguous。禁止把所有候选做笛卡尔积，也禁止把“时间包含的最短 slice”命名为 direct-flow。框架 op→kernel 往往是多跳链：`framework_op → enqueue/dequeue/runtime launch → HostToDevice → device_task`；没有完整可审计边时不得压扁成直接因果。

禁止使用“时间最近的 kernel”或相同 Shape/名称建立 Host→Device 因果。共享 ID 对应多个 Host/Device 事件时标 `ambiguous-shared-id`，不可任意选一个。`has_correlation=false` 在两侧都相同不产生正向 lane 匹配分。

`host_device_links.csv` 可保留唯一 containment 的降级观察，但只有 `causal_eligible=是` 且 `link_status=direct-id/direct-flow` 的行可作因果边；`degraded-flow-containment` 只作定位线索。Device 首次差异与 Host guard 建立关系时必须引用合格行。没有合格 direct link 时分别报告“首次 Host 差异”和“首次 Device 差异”，不能声称某 Host 算子启动了该 Device kernel。

## 8. 产物与完整性检查

预检先产生 `collection_contract.json/csv`；`align_profiles.py` 必须产生：

| 产物 | 用途 |
|---|---|
| `analysis_manifest.json` | 算法、范围、Rank 交集、禁止时间结论声明 |
| `rank_pairs.csv` | 每个同号 Rank pair、trace 路径/hash、拓扑门禁 |
| `unpaired_ranks.csv` | 未配对和未知/重复 Rank |
| `thread_pairs.csv` | 三层 semantic lane union、匹配方法/score/margin/置信度 |
| `canonical_events.csv` | 无 duration 的逐事件结构证据，含 semantic layer、track/task/stream 可观测字段 |
| `operator_details_rank_coverage.csv` | operator_details 的 Rank 级 coverage；不冒充 Thread 逐事件事实 |
| `event_alignment.csv` | run 对齐列、real/sim calls 与 relation |
| `divergence_windows.jsonl` | 每个 matched lane 首次分叉窗口 |
| `host_device_links.csv` | 唯一 flow/correlation 边观察；仅 `causal_eligible=是` 可作因果证据 |
| `structural_heatmap.csv/html` | 序位热力图 |
| `perfetto_inputs/` | 每个 Rank 两侧全部兼容 Host lane 清单 |

交付前检查：

- `duration_metrics_emitted=false`；
- `compared_rank_ids` 等于两侧 Rank ID 交集；
- 每个 pair 的 framework/launch/device lane union 都出现在 `thread_pairs.csv`；
- ambiguous/unmatched 未被后续强行对齐；
- `canonical_events.csv` 无 duration/start/end/time ratio 字段；
- divergence 的 event ID 能回连 canonical event；
- Host→Device 结论都有 link 行；
- `rank-identity-conflict` 未进入同号配对；缺 Stream 的 Device coverage 未构造伪 lane；
- 连续重复调用数差异未被压缩成 exact；flow ID namespace 与 `id=0` 已通过自测；
- 任一解析失败、coverage 缺口或不可观测 lane 会把 manifest 总状态降为 `partial`；
- 两侧原始 Profiling 未修改。

## 9. 失败模式

### 原生 msprof 或 DB-only

不要让 integrated parser 继续并产出空序列。预检标 `unsupported`，列出发现的 `PROF_*`、`mindstudio_profiler_output/msprof_*.json` 或 `analysis.db`，要求先生成 TorchNPU integrated text export，或使用专门的 msprof/DB 解析流程；当前 skill 不伪称已覆盖这些 schema。

### trace 缺失

保留 Rank pair 与 Device CSV 证据；Host Thread、Perfetto 和 Host 控制流标为未知。缺失不是零事件。

### 一侧没有 Host PyTorch lane

不得用 Device kernel lane替代 Host Thread。检查 profiler 是否同时采 CPU/NPU activities，并启用 `record_shapes`、`with_stack`、`with_modules`；若算子发生在子线程，检查是否有 `enable_profiler_in_child_thread` 等运行证据。不可从缺失字段反推配置为 false，只能写 unknown 并列最小重采要求。

### lane 配对低置信

保留 union 和单侧序列；要求 runtime thread marker、process/thread 名、request/phase marker 或用户显式 PID/TID 映射。

### 采集窗口不同

可以展示结构差异，但不得把窗口边界差异归因于 if-else。先对齐 workload、phase、Profiler schedule 和重复次数。

### 相同算子但 Shape 不同

先定位 metadata divergence；Shape 可能导致 guard，也可能是更早错误的结果。继续追踪 Shape producer，不能默认 Shape 是根因。

### Device 差异早于可见 Host 差异

可能是 Host instrumentation 缺失、backend lowering、图捕获/回放或外部 runtime path。没有直接 flow 时保持两个独立观察。

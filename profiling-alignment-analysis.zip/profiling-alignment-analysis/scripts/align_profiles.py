#!/usr/bin/env python3
"""Align real-machine and simulation profiler traces by rank, lane, and operator order.

This tool deliberately emits no duration, latency, utilization, overlap, or performance
metrics. Trace timestamps/durations are consumed only to pair B/E slices, recover nesting
and flow endpoints, and establish deterministic within-lane order. Public artifacts use
event ordinals and structural signatures.
"""

from __future__ import annotations

import argparse
import csv
import difflib
import hashlib
import html
import io
import json
import math
import re
import tempfile
from collections import Counter, defaultdict
from dataclasses import dataclass, field
from decimal import Decimal, InvalidOperation
from pathlib import Path
from typing import Any, Iterable, Iterator


SCHEMA_VERSION = 2
ALGORITHM_VERSION = "all-rank-all-lane-structural-v2-ascend"
MAX_EVENT_JSON_CHARS = 64 * 1024 * 1024
MAX_TEXT_FIELD = 8000
MAX_WARNINGS = 2000
UNKNOWN_INPUT_SHAPE = "未知（未采集）"
UNKNOWN_OUTPUT_SHAPE = "未知（trace 未直接提供可信输出 Shape）"
UNKNOWN = {"", "unknown", "未知", "none", "null", "n/a", "na"}
PARALLEL_FIELDS = ("dp", "tp", "ep", "pp", "cp", "dcp")
COORD_PATTERN = re.compile(
    r"(?:^|[_\-.])(?:global[_-]?)?(rank|global_rank|local_rank|localrank|device|dp|tp|ep|pp|cp|dcp)"
    r"[_:=\-]?(\d+)(?:$|[_\-.])",
    re.IGNORECASE,
)
THREAD_ID_PATTERN = re.compile(r"\bthread\s+[-+]?\d+\b", re.IGNORECASE)
SPACE_PATTERN = re.compile(r"\s+")
NAMESPACE_PATTERN = re.compile(r"^([A-Za-z_][A-Za-z0-9_.]*)::")
KNOWN_PYTORCH_NAMESPACES = {
    "aten", "prims", "torch", "torch_npu", "npu", "quantized", "c10d", "distributed",
}
FORBIDDEN_HOST_CATEGORY_PARTS = (
    "kernel", "cann", "runtime", "driver", "acl", "hccl", "memcpy", "python_function",
    "user_annotation",
)
SCOPE_PATTERN = re.compile(
    r"profiler\s*step|pytorch\s*profiler|autograd::engine::evaluate_function|"
    r"^python(::|\s)|^module(::|\s)|(^|[.#])forward($|[#(])|^optimizer\.",
    re.IGNORECASE,
)
HOST_LAUNCH_CATEGORY_TOKENS = {
    "acl", "ascendcl", "runtime", "cann", "enqueue", "dequeue", "task_queue",
    "hccl", "hcom",
}
DEVICE_TASK_CATEGORY_TOKENS = {
    "kernel", "device_task", "npu_kernel", "aicore", "aicpu",
}
DEVICE_TASK_TYPE_PATTERN = re.compile(
    r"ai[_ ]?core|ai[_ ]?cpu|aiv|aic|vector|ffts|sdma|pcie[_ ]?dma|"
    r"event[_ ]?wait|kernel|memcpy|hccl|hcom",
    re.IGNORECASE,
)
OUTPUT_SHAPE_ALIASES = (
    "Output Dims", "Output Shapes", "Output Shape", "Output Dimensions",
)
EMPTY_CSV_SCHEMAS: dict[str, list[str]] = {
    "unpaired_ranks.csv": ["environment", "rank", "path", "identity_status", "reason"],
    "thread_pairs.csv": [
        "rank_pair_id", "thread_pair_id", "domain", "semantic_layer", "real_lane_id",
        "sim_lane_id", "match_method", "score", "margin", "confidence", "status",
    ],
    "canonical_events.csv": [
        "environment", "rank", "domain", "semantic_layer", "lane_id", "lane_status",
        "event_id", "source_event_index", "pid", "tid", "raw_name", "canonical_op",
        "thread_ordinal", "normalized_ordinal", "depth", "parent_event_id", "input_shapes",
        "output_shapes", "stream_id", "device_id", "task_id", "task_type", "source",
        "correlation_id_hashed", "external_id_hashed", "timestamps_exposed",
    ],
    "event_alignment.csv": [
        "rank_pair_id", "domain", "semantic_layer", "thread_pair_id", "alignment_column",
        "real_event_ids", "sim_event_ids", "real_operator", "sim_operator",
        "real_run_calls", "sim_run_calls", "relation", "first_divergence",
    ],
    "host_device_links.csv": [
        "environment", "rank", "host_event_id", "device_event_id", "host_lane_id",
        "device_lane_id", "host_semantic_layer", "device_semantic_layer",
        "correlation_type", "correlation_namespace", "correlation_id_hash", "link_status",
        "endpoint_match", "causal_eligible", "evidence_ids",
    ],
    "structural_heatmap.csv": [
        "rank_pair_id", "domain", "semantic_layer", "thread_pair_id", "environment",
        "lane_id", "bin_index", "normalized_start", "normalized_end", "operator_family",
        "event_count", "contains_first_divergence", "position_semantics",
    ],
    "parser_warnings.csv": ["environment", "rank", "source", "warning"],
    "operator_details_rank_coverage.csv": [
        "environment", "rank", "coverage_scope", "source", "source_row", "raw_name",
        "canonical_op", "input_shapes", "output_shapes", "call_stack",
    ],
}


def clean_text(value: Any, limit: int = MAX_TEXT_FIELD) -> str:
    if value is None:
        return ""
    if isinstance(value, (dict, list, tuple)):
        value = json.dumps(
            value, ensure_ascii=False, separators=(",", ":"), sort_keys=True,
            default=lambda item: format(item, "f") if isinstance(item, Decimal) else str(item),
        )
    text = SPACE_PATTERN.sub(" ", str(value)).strip()
    return text if len(text) <= limit else text[: limit - 3] + "..."


def stable_hash(*parts: Any, length: int = 64) -> str:
    payload = "\x1f".join(str(part) for part in parts)
    return hashlib.sha256(payload.encode("utf-8", errors="replace")).hexdigest()[:length]


def compact_json(value: Any, limit: int = MAX_TEXT_FIELD) -> str:
    if value is None or value == "":
        return ""
    try:
        text = json.dumps(
            value, ensure_ascii=False, separators=(",", ":"), sort_keys=True,
            default=lambda item: format(item, "f") if isinstance(item, Decimal) else str(item),
        )
    except (TypeError, ValueError):
        text = str(value)
    return clean_text(text, limit)


def stable_time(value: Any) -> Decimal | None:
    """Parse trace/CSV time without binary floating-point reordering."""
    if value is None or isinstance(value, bool):
        return None
    try:
        result = Decimal(str(value).strip())
    except (InvalidOperation, ValueError):
        return None
    return result if result.is_finite() else None


def parse_int(value: Any) -> int | None:
    if value is None or isinstance(value, bool):
        return None
    text = str(value).strip()
    if not re.fullmatch(r"[-+]?\d+", text):
        return None
    try:
        return int(text)
    except ValueError:
        return None


def canonical_id(value: Any) -> str:
    if value is None:
        return ""
    if isinstance(value, bool):
        return "true" if value else "false"
    if isinstance(value, int):
        return str(value)
    if isinstance(value, float) and math.isfinite(value):
        return str(int(value)) if value.is_integer() else format(value, ".17g")
    return clean_text(value, 256)


def strict_json_loads(raw: str) -> Any:
    def reject_constant(value: str) -> None:
        raise ValueError(f"JSON 不允许非有限常量 {value}")

    return json.loads(raw, parse_float=Decimal, parse_constant=reject_constant)


def normalized_arg_key(key: Any) -> str:
    return re.sub(r"[^a-z0-9]", "", str(key).lower())


def arg_value(args: dict[str, Any], *aliases: str) -> Any:
    indexed = {normalized_arg_key(key): value for key, value in args.items()}
    for alias in aliases:
        key = normalized_arg_key(alias)
        if key in indexed:
            return indexed[key]
    return None


def row_value(row: dict[str, Any], *aliases: str) -> Any:
    indexed = {normalized_arg_key(key): value for key, value in row.items()}
    for alias in aliases:
        key = normalized_arg_key(alias)
        if key in indexed:
            return indexed[key]
    return None


def normalize_shape_value(value: Any, unknown: str) -> str:
    if value is None or isinstance(value, bool):
        return unknown
    if isinstance(value, str):
        text = clean_text(value)
        if not text or text.casefold() in UNKNOWN:
            return unknown
        if text[:1] in "[{":
            try:
                return compact_json(strict_json_loads(text))
            except (ValueError, json.JSONDecodeError):
                return text
        return text
    if isinstance(value, (int, float)):
        return unknown
    return compact_json(value) or unknown


def direct_output_shape(args: dict[str, Any]) -> tuple[str, str]:
    aliases = {normalized_arg_key(alias) for alias in OUTPUT_SHAPE_ALIASES}
    values: list[tuple[str, str]] = []
    for key, value in args.items():
        if normalized_arg_key(key) in aliases:
            normalized = normalize_shape_value(value, "")
            if normalized:
                values.append((clean_text(key, 200), normalized))
    unique = sorted({value for _, value in values})
    if not unique:
        return UNKNOWN_OUTPUT_SHAPE, "无直接证据"
    if len(unique) == 1:
        return unique[0], "直接证据"
    return compact_json(unique), "直接证据冲突"


def scalar_and_tensor_evidence(args: dict[str, Any]) -> tuple[str, str, str]:
    """Retain only directly recorded scalar evidence and hashed tensor identities."""
    scalars: dict[str, Any] = {}
    tensor_ids: list[str] = []
    scalar_key = re.compile(r"scalar|predicate|condition|branch|boolean|bool|result|value", re.I)
    tensor_key = re.compile(r"tensor.*(?:id|addr|address|ptr)|storage.*ptr|data.*ptr", re.I)
    excluded = re.compile(r"shape|dim|dtype|type|format|stride|duration|time", re.I)
    for raw_key, value in args.items():
        key = clean_text(raw_key, 200)
        if tensor_key.search(key):
            if isinstance(value, (str, int, float, Decimal)) and not isinstance(value, bool):
                tensor_ids.append(stable_hash(key, value, length=24))
            elif isinstance(value, (list, tuple)):
                tensor_ids.extend(
                    stable_hash(key, item, length=24)
                    for item in value[:128]
                    if isinstance(item, (str, int, float, Decimal)) and not isinstance(item, bool)
                )
        if scalar_key.search(key) and not excluded.search(key):
            if isinstance(value, (str, int, float, Decimal, bool)) or value is None:
                scalars[key] = value
            elif isinstance(value, (list, tuple)) and len(value) <= 64 and all(
                isinstance(item, (str, int, float, Decimal, bool)) or item is None for item in value
            ):
                scalars[key] = value
        if len(scalars) >= 64:
            break
    return compact_json(scalars, 16000), compact_json(sorted(set(tensor_ids)), 16000), (
        "trace event args direct evidence" if scalars or tensor_ids else ""
    )


class JSONCharReader:
    """Buffered character reader that never materializes a complete trace file."""

    def __init__(self, handle: Any, chunk_size: int = 1024 * 1024) -> None:
        self.handle = handle
        self.chunk_size = chunk_size
        self.buffer = ""
        self.position = 0
        self.absolute_position = 0
        self.eof = False

    def _compact(self) -> None:
        if self.position > self.chunk_size and self.position > len(self.buffer) // 2:
            self.buffer = self.buffer[self.position :]
            self.position = 0

    def _fill(self, count: int = 1) -> None:
        while len(self.buffer) - self.position < count and not self.eof:
            self._compact()
            chunk = self.handle.read(self.chunk_size)
            if chunk == "":
                self.eof = True
                break
            self.buffer += chunk

    def peek(self) -> str:
        self._fill(1)
        return self.buffer[self.position] if self.position < len(self.buffer) else ""

    def get(self) -> str:
        char = self.peek()
        if char:
            self.position += 1
            self.absolute_position += 1
        return char

    def skip_ws(self) -> None:
        while self.peek() and self.peek().isspace():
            self.get()

    def expect(self, expected: str) -> None:
        self.skip_ws()
        actual = self.get()
        if actual != expected:
            raise ValueError(
                f"JSON 位置 {self.absolute_position}: 期望 {expected!r}，实际 {actual!r}"
            )

    def read_raw_value(self, capture: bool = True) -> str:
        self.skip_ws()
        first = self.peek()
        if not first:
            raise ValueError(f"JSON 位置 {self.absolute_position}: 意外到达文件末尾")
        effective_capture = capture or first not in "[{"
        output = io.StringIO() if effective_capture else None
        captured_count = 0

        def append(char: str) -> None:
            nonlocal captured_count
            if effective_capture:
                captured_count += len(char)
                if captured_count > MAX_EVENT_JSON_CHARS:
                    raise ValueError("单个 JSON event 超过 64 MiB 安全上限")
                assert output is not None
                output.write(char)

        if first in "[{":
            closing_stack: list[str] = []
            in_string = False
            escaped = False
            while True:
                char = self.get()
                if not char:
                    raise ValueError("复合 JSON value 未闭合")
                append(char)
                if in_string:
                    if escaped:
                        escaped = False
                    elif char == "\\":
                        escaped = True
                    elif char == '"':
                        in_string = False
                    continue
                if char == '"':
                    in_string = True
                elif char in "[{":
                    closing_stack.append("}" if char == "{" else "]")
                elif char in "]}":
                    if not closing_stack or char != closing_stack[-1]:
                        raise ValueError(
                            f"JSON 位置 {self.absolute_position}: 容器闭合符 {char!r} 不匹配"
                        )
                    closing_stack.pop()
                    if not closing_stack:
                        break
            return "" if output is None else output.getvalue()

        if first == '"':
            escaped = False
            first_char = True
            while True:
                char = self.get()
                if not char:
                    raise ValueError("JSON string 未闭合")
                append(char)
                if first_char:
                    first_char = False
                elif escaped:
                    escaped = False
                elif char == "\\":
                    escaped = True
                elif char == '"':
                    break
            return "" if output is None else output.getvalue()

        while self.peek() and self.peek() not in ",]}" and not self.peek().isspace():
            append(self.get())
        if captured_count == 0:
            raise ValueError(f"JSON 位置 {self.absolute_position}: value 为空")
        return "" if output is None else output.getvalue()

    def read_value(self) -> Any:
        return strict_json_loads(self.read_raw_value(capture=True))

    def skip_value(self, depth: int = 0) -> None:
        if depth > 1000:
            raise ValueError("JSON 嵌套超过 1000 层安全上限")
        self.skip_ws()
        first = self.peek()
        if first == "{":
            self.get()
            self.skip_ws()
            if self.peek() == "}":
                self.get()
                return
            while True:
                key = self.read_value()
                if not isinstance(key, str):
                    raise ValueError("JSON object key 不是字符串")
                self.expect(":")
                self.skip_value(depth + 1)
                self.skip_ws()
                separator = self.get()
                if separator == "}":
                    return
                if separator != ",":
                    raise ValueError("JSON object member 后缺少 ',' 或 '}'")
        elif first == "[":
            self.get()
            self.skip_ws()
            if self.peek() == "]":
                self.get()
                return
            while True:
                self.skip_value(depth + 1)
                self.skip_ws()
                separator = self.get()
                if separator == "]":
                    return
                if separator != ",":
                    raise ValueError("JSON array element 后缺少 ',' 或 ']'")
        else:
            strict_json_loads(self.read_raw_value(capture=True))


def _iter_json_array(reader: JSONCharReader) -> Iterator[Any]:
    reader.expect("[")
    reader.skip_ws()
    if reader.peek() == "]":
        reader.get()
        return
    while True:
        yield reader.read_value()
        reader.skip_ws()
        separator = reader.get()
        if separator == "]":
            return
        if separator != ",":
            raise ValueError("JSON array element 后缺少 ',' 或 ']'")


def iter_trace_events(path: Path) -> Iterator[dict[str, Any]]:
    with path.open("r", encoding="utf-8-sig", errors="strict") as handle:
        reader = JSONCharReader(handle)
        reader.skip_ws()
        first = reader.peek()
        if first == "[":
            for value in _iter_json_array(reader):
                yield value if isinstance(value, dict) else {}
            reader.skip_ws()
            if reader.peek():
                raise ValueError("顶层 JSON 数组后存在多余内容")
            return
        if first != "{":
            raise ValueError("trace 必须是顶层数组或包含 traceEvents 的对象")
        reader.expect("{")
        found = False
        reader.skip_ws()
        if reader.peek() == "}":
            reader.get()
        else:
            while True:
                key = reader.read_value()
                if not isinstance(key, str):
                    raise ValueError("顶层 JSON object 的 key 不是字符串")
                reader.expect(":")
                if key == "traceEvents" and not found:
                    found = True
                    for value in _iter_json_array(reader):
                        yield value if isinstance(value, dict) else {}
                else:
                    reader.skip_value()
                reader.skip_ws()
                separator = reader.get()
                if separator == "}":
                    break
                if separator != ",":
                    raise ValueError("顶层 JSON object member 后缺少 ',' 或 '}'")
        if not found:
            raise ValueError("顶层 JSON object 中没有 traceEvents 数组")


@dataclass
class RankInfo:
    root: Path
    rank_id: int | None = None
    local_rank: int | None = None
    device: int | None = None
    dp: int | None = None
    tp: int | None = None
    ep: int | None = None
    pp: int | None = None
    cp: int | None = None
    dcp: int | None = None
    coordinate_source: str = "unknown"
    identity_status: str = "resolved"
    identity_reason: str = ""

    @property
    def coordinate_text(self) -> str:
        return "/".join(
            f"{name.upper()}={'?' if getattr(self, name) is None else getattr(self, name)}"
            for name in PARALLEL_FIELDS
        )

    @property
    def trace_path(self) -> Path | None:
        path = self.root / "trace_view.json"
        return path if path.is_file() else None


def read_csv_rows(path: Path) -> Iterator[dict[str, str]]:
    with path.open("r", newline="", encoding="utf-8-sig", errors="replace") as handle:
        yield from csv.DictReader(handle)


def discover_outputs(root: Path) -> list[Path]:
    if root.name == "ASCEND_PROFILER_OUTPUT" and root.is_dir():
        return [root]
    return sorted(path for path in root.rglob("ASCEND_PROFILER_OUTPUT") if path.is_dir())


def infer_rank_info(output_dir: Path) -> RankInfo:
    directory_values: dict[str, set[int]] = defaultdict(set)
    for name in [output_dir.parent.name, *(parent.name for parent in output_dir.parents[:5])]:
        for raw_key, raw_value in COORD_PATTERN.findall(name):
            key = raw_key.lower().replace("-", "_")
            if key in {"rank", "global_rank"}:
                key = "rank_id"
            elif key == "localrank":
                key = "local_rank"
            directory_values[key].add(int(raw_value))
    metadata_values: dict[str, set[int]] = defaultdict(set)
    metadata_key_map = {
        "global_rank": "rank_id", "globalrank": "rank_id", "rank_id": "rank_id",
        "rankid": "rank_id", "local_rank": "local_rank", "localrank": "local_rank",
        "device_id": "device", "deviceid": "device", "device": "device",
        "dp_rank": "dp", "data_parallel_rank": "dp", "tp_rank": "tp",
        "tensor_parallel_rank": "tp", "tensor_model_parallel_rank": "tp",
        "ep_rank": "ep", "expert_parallel_rank": "ep", "pp_rank": "pp",
        "pipeline_parallel_rank": "pp", "cp_rank": "cp", "context_parallel_rank": "cp",
        "dcp_rank": "dcp", "distributed_context_parallel_rank": "dcp",
    }
    ignored = {"peer", "peers", "link", "links", "group", "groups", "member", "members"}

    def collect(value: Any, path: tuple[str, ...] = (), depth: int = 0) -> None:
        if depth > 8:
            return
        if isinstance(value, dict):
            for raw_key, child in value.items():
                key = re.sub(r"[^a-z0-9]+", "_", str(raw_key).lower()).strip("_")
                child_path = (*path, key)
                if any(part in ignored for part in child_path):
                    continue
                canonical = metadata_key_map.get(key)
                if canonical and not isinstance(child, (dict, list, tuple)):
                    parsed = parse_int(child)
                    if parsed is not None:
                        metadata_values[canonical].add(parsed)
                collect(child, child_path, depth + 1)
        elif isinstance(value, list):
            for child in value[:1000]:
                collect(child, path, depth + 1)

    metadata_paths: set[Path] = set()
    for directory in (output_dir, output_dir.parent, output_dir.parent.parent):
        if not directory.is_dir():
            continue
        for pattern in ("profiler_info*.json", "profiler_metadata*.json", "metadata*.json"):
            metadata_paths.update(path for path in directory.glob(pattern) if path.is_file())
    for path in sorted(metadata_paths):
        try:
            if path.stat().st_size <= 16 * 1024 * 1024:
                with path.open("r", encoding="utf-8-sig", errors="replace") as handle:
                    collect(json.load(handle))
        except (OSError, UnicodeError, json.JSONDecodeError):
            continue
    values: dict[str, int] = {}
    all_fields = {"rank_id", "local_rank", "device", *PARALLEL_FIELDS}
    for field_name in all_fields:
        metadata_candidates = metadata_values.get(field_name, set())
        directory_candidates = directory_values.get(field_name, set())
        if len(metadata_candidates) == 1:
            values[field_name] = next(iter(metadata_candidates))
        elif not metadata_candidates and len(directory_candidates) == 1:
            values[field_name] = next(iter(directory_candidates))

    metadata_ranks = metadata_values.get("rank_id", set())
    directory_ranks = directory_values.get("rank_id", set())
    conflict_reasons: list[str] = []
    if len(metadata_ranks) > 1:
        conflict_reasons.append(f"metadata global_rank conflict: {sorted(metadata_ranks)}")
    if len(directory_ranks) > 1:
        conflict_reasons.append(f"directory global_rank conflict: {sorted(directory_ranks)}")
    if len(metadata_ranks) == 1 and directory_ranks and directory_ranks != metadata_ranks:
        conflict_reasons.append(
            f"metadata rank {next(iter(metadata_ranks))} conflicts with directory rank(s) "
            f"{sorted(directory_ranks)}"
        )
    if conflict_reasons:
        values.pop("rank_id", None)

    if "device" not in values:
        kernel = output_dir / "kernel_details.csv"
        if kernel.is_file():
            try:
                first = next(read_csv_rows(kernel), {})
                parsed = parse_int(row_value(first, "Device_id", "Device ID", "Device"))
                if parsed is not None:
                    values["device"] = parsed
            except OSError:
                pass
    if metadata_values:
        source = "metadata" if not directory_values else "metadata-priority"
    else:
        source = "directory" if directory_values else "unknown"
    return RankInfo(
        root=output_dir.resolve(),
        coordinate_source=source,
        identity_status="conflict" if conflict_reasons else ("resolved" if "rank_id" in values else "unknown"),
        identity_reason="; ".join(conflict_reasons),
        **values,
    )


def file_sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def normalize_lane_name(value: Any, kind: str) -> str:
    text = clean_text(value, 500).casefold()
    if not text:
        return ""
    text = THREAD_ID_PATTERN.sub("thread <id>", text)
    if kind == "process":
        text = re.sub(r"\bpid\s*[:=#-]?\s*\d+\b", "pid <id>", text)
    return SPACE_PATTERN.sub(" ", text).strip()


def call_stack_fingerprint(value: Any) -> str:
    text = clean_text(value, 16000).replace("\\", "/")
    if not text:
        return ""
    text = re.sub(r"0x[0-9a-f]+", "<addr>", text, flags=re.I)
    text = re.sub(
        r"(?:[A-Za-z]:)?(?:/[^,;\s:]+)+/([^/,;\s:]+\.py(?::\d+)?)",
        r"\1",
        text,
    )
    return stable_hash(text, length=24)


def event_args(event: dict[str, Any]) -> dict[str, Any]:
    value = event.get("args")
    return value if isinstance(value, dict) else {}


def category_text(event: dict[str, Any]) -> str:
    return clean_text(event.get("cat"), 1000)


def classify_host_operator(event: dict[str, Any]) -> tuple[bool, str, str]:
    name = clean_text(event.get("name"), 1000)
    lower_name = name.casefold()
    tokens = {part.strip() for part in category_text(event).casefold().split(",") if part.strip()}
    is_cpu_op = "cpu_op" in tokens or any(token.endswith(".cpu_op") for token in tokens)
    if not name or SCOPE_PATTERN.search(name):
        return False, "结构 scope/metadata", ""
    if any(part in token for token in tokens for part in FORBIDDEN_HOST_CATEGORY_PARTS) and not is_cpu_op:
        return False, "设备/CANN/runtime category", ""
    match = NAMESPACE_PATTERN.match(name)
    namespace = match.group(1) if match else ""
    if namespace.casefold() in KNOWN_PYTORCH_NAMESPACES:
        if any("kernel" in token for token in tokens):
            return False, "kernel track 上的 namespace", namespace
        return True, f"PyTorch namespace:{namespace}", namespace
    if is_cpu_op:
        return True, "cpu_op custom operator/marker", namespace or (
            "c10d" if lower_name == "record_param_comms" else "custom"
        )
    return False, "非确认 Host PyTorch operator", namespace


def classify_device_operator(event: dict[str, Any], process_name: str = "") -> tuple[bool, str]:
    name = clean_text(event.get("name"), 1000)
    if not name or SCOPE_PATTERN.search(name):
        return False, ""
    tokens = {part.strip() for part in category_text(event).casefold().split(",") if part.strip()}
    explicit_category = any(
        token in DEVICE_TASK_CATEGORY_TOKENS
        or any(part in token for part in ("kernel", "device_task", "aicore", "aicpu"))
        for token in tokens
    )
    args = event_args(event)
    task_type = clean_text(arg_value(args, "Task Type", "Type", "Accelerator Core"), 500)
    stream = arg_value(args, "Stream Id", "Stream ID", "stream_id")
    device = arg_value(args, "Device Id", "Device ID", "device_id")
    if explicit_category:
        return True, "explicit device task category"
    if task_type and DEVICE_TASK_TYPE_PATTERN.search(task_type) and (stream is not None or device is not None):
        return True, "device task metadata"
    if re.search(r"(?:^|\b)(?:ascend\s+hardware|npu\s*\d+|hccl)(?:\b|$)", process_name, re.I):
        return True, "explicit Ascend Hardware/NPU process metadata"
    return False, ""


def classify_host_launch(event: dict[str, Any]) -> tuple[bool, str]:
    name = clean_text(event.get("name"), 1000)
    if not name or SCOPE_PATTERN.search(name):
        return False, ""
    tokens = {part.strip() for part in category_text(event).casefold().split(",") if part.strip()}
    if any(
        token in HOST_LAUNCH_CATEGORY_TOKENS
        or any(
            part in token
            for part in ("runtime", "ascendcl", "acl", "enqueue", "dequeue", "hccl", "hcom")
        )
        for token in tokens
    ):
        return True, "explicit Ascend host launch category"
    if re.search(r"^(?:acl|aclop|aclnn|rt[A-Z_]|runtime\b|ascendcl\b)", name, re.IGNORECASE):
        return True, "explicit Ascend host launch API"
    return False, ""


def canonical_operator(name: str) -> str:
    text = clean_text(name, 1000)
    text = re.sub(r"(?:0x[0-9a-f]+|[0-9a-f]{8}-[0-9a-f-]{20,})", "<id>", text, flags=re.I)
    text = re.sub(r"(?<=\D)#?\d{5,}$", "<instance>", text)
    return text


def operator_family(name: str) -> str:
    lower = name.casefold()
    families = (
        ("communication", ("all_reduce", "allreduce", "all_gather", "reduce_scatter", "hccl", "hcom", "send", "recv")),
        ("attention", ("attention", "flash", "paged")),
        ("matmul", ("matmul", "mm", "gemm", "linear", "addmm", "bmm")),
        ("normalization", ("norm", "rms")),
        ("activation", ("relu", "gelu", "silu", "sigmoid", "softmax")),
        ("routing", ("topk", "top_k", "router", "expert", "moe")),
        ("memory", ("copy", "memcpy", "clone", "contiguous")),
        ("shape", ("view", "reshape", "transpose", "permute", "slice", "narrow")),
    )
    for family, needles in families:
        if any(needle in lower for needle in needles):
            return family
    namespace = lower.split("::", 1)[0]
    return namespace if namespace and namespace != lower else "other"


def selected_fields(args: dict[str, Any]) -> dict[str, str]:
    output_shapes, output_status = direct_output_shape(args)
    scalar_args, tensor_ids_hashed, value_provenance = scalar_and_tensor_evidence(args)
    correlation = arg_value(args, "correlation", "Correlation id", "Correlation ID", "CorrelationId")
    external = arg_value(args, "External id", "External ID", "ExternalId")
    return {
        "input_shapes": normalize_shape_value(
            arg_value(args, "Input Dims", "Input Shapes", "Input Shape"), UNKNOWN_INPUT_SHAPE
        ),
        "output_shapes": output_shapes,
        "input_dtypes": clean_text(arg_value(args, "Input type", "Input types", "Input Data Types")),
        "output_dtypes": clean_text(arg_value(args, "Output type", "Output types", "Output Data Types")),
        "input_formats": clean_text(arg_value(args, "Input Formats", "Input Format")),
        "output_formats": clean_text(arg_value(args, "Output Formats", "Output Format")),
        "call_stack": clean_text(arg_value(args, "Call stack", "Call Stack", "Stack")),
        "module_hierarchy": clean_text(arg_value(args, "Module Hierarchy", "Module", "Module hierarchy")),
        "output_shape_provenance": output_status,
        "correlation_id": canonical_id(correlation),
        "external_id": canonical_id(external),
        "stream_id": canonical_id(arg_value(args, "Stream Id", "Stream ID", "Stream", "stream_id")),
        "device_id": canonical_id(arg_value(args, "Device Id", "Device ID", "Device", "device_id")),
        "task_id": canonical_id(arg_value(args, "Task Id", "Task ID", "task_id")),
        "task_type": clean_text(arg_value(args, "Task Type", "Type", "task_type")),
        "accelerator_core": clean_text(arg_value(args, "Accelerator Core", "Core Type")),
        "scalar_args": scalar_args,
        "tensor_ids_hashed": tensor_ids_hashed,
        "value_provenance": value_provenance,
        "args_evidence_sha256": stable_hash(compact_json(args, 32000)),
    }


@dataclass
class ParsedTrace:
    events: list[dict[str, Any]] = field(default_factory=list)
    flows: list[dict[str, Any]] = field(default_factory=list)
    warnings: list[str] = field(default_factory=list)
    process_names: dict[str, str] = field(default_factory=dict)
    thread_names: dict[tuple[str, str], str] = field(default_factory=dict)


def parse_trace(path: Path, environment: str, rank: int) -> ParsedTrace:
    result = ParsedTrace()
    begin_stacks: dict[tuple[str, str], list[tuple[dict[str, Any], int]]] = defaultdict(list)
    warning_overflow = 0

    def warn(message: str) -> None:
        nonlocal warning_overflow
        if len(result.warnings) < MAX_WARNINGS:
            result.warnings.append(message)
        else:
            warning_overflow += 1

    def lane_key(event: dict[str, Any]) -> tuple[str, str] | None:
        pid = canonical_id(event.get("pid"))
        tid = canonical_id(event.get("tid"))
        return (pid, tid) if pid and tid else None

    # Chrome metadata is not guaranteed to precede every slice.  Read only M events
    # first so classification never depends on file order, then stream the trace again.
    for metadata_event in iter_trace_events(path):
        if clean_text(metadata_event.get("ph"), 8) != "M":
            continue
        metadata_name = clean_text(metadata_event.get("name"), 200).casefold()
        metadata_args = event_args(metadata_event)
        metadata_pid = canonical_id(metadata_event.get("pid"))
        metadata_tid = canonical_id(metadata_event.get("tid"))
        metadata_label = clean_text(arg_value(metadata_args, "name"), 1000)
        if metadata_name == "process_name" and metadata_pid and metadata_label:
            result.process_names[metadata_pid] = metadata_label
        elif metadata_name == "thread_name" and metadata_pid and metadata_tid and metadata_label:
            result.thread_names[(metadata_pid, metadata_tid)] = metadata_label

    def register(event: dict[str, Any], start_index: int, end_index: int | None, phase: str) -> None:
        key = lane_key(event)
        if key is None:
            warn(f"traceEvents[{start_index}] 缺少 pid/tid")
            return
        ts = stable_time(event.get("ts"))
        if phase == "X":
            duration = stable_time(event.get("dur"))
        else:
            end_ts = stable_time(event.get("_paired_end_ts"))
            duration = None if ts is None or end_ts is None else end_ts - ts
        if ts is None or duration is None or duration < 0:
            warn(f"traceEvents[{start_index}] 缺少有效 ts/dur 或 B/E 反转")
            return
        host, host_reason, namespace = classify_host_operator(event)
        host_launch, host_launch_reason = classify_host_launch(event)
        device, device_reason = classify_device_operator(
            event, result.process_names.get(key[0], "")
        )
        if not host and not host_launch and not device:
            return
        if host:
            domain, semantic_layer, classification_reason = "host", "framework_op", host_reason
        elif device and (not host_launch or device_reason != "device task metadata"):
            domain, semantic_layer, classification_reason = "device", "device_task", device_reason
            namespace = ""
        else:
            domain, semantic_layer, classification_reason = "host", "host_launch", host_launch_reason
            namespace = ""
        args = event_args(event)
        fields = selected_fields(args)
        name = clean_text(event.get("name"), 1000)
        event_id = stable_hash(environment, rank, domain, key[0], key[1], start_index, name, length=24)
        result.events.append(
            {
                "environment": environment,
                "rank": rank,
                "domain": domain,
                "semantic_layer": semantic_layer,
                "lane_id": "",
                "event_id": event_id,
                "source_event_index": start_index,
                "source_end_event_index": "" if end_index is None else end_index,
                "phase": phase,
                "pid": key[0],
                "tid": key[1],
                "process_name": "",
                "thread_name": "",
                "raw_name": name,
                "canonical_op": canonical_operator(name),
                "op_family": operator_family(name),
                "operator_namespace": namespace,
                "classification_reason": classification_reason,
                "category": category_text(event),
                "thread_ordinal": 0,
                "normalized_ordinal": 0.0,
                "depth": 0,
                "parent_event_id": "",
                "sibling_ordinal": 0,
                "nesting_status": "未计算",
                "source": f"{path}:traceEvents[{start_index}]",
                "parser_flags": "",
                **fields,
                "_ts": ts,
                "_end": ts + duration,
            }
        )

    for index, event in enumerate(iter_trace_events(path)):
        phase = clean_text(event.get("ph"), 8)
        if phase == "M":
            name = clean_text(event.get("name"), 200).casefold()
            args = event_args(event)
            pid = canonical_id(event.get("pid"))
            tid = canonical_id(event.get("tid"))
            label = clean_text(arg_value(args, "name"), 1000)
            if name == "process_name" and pid and label:
                result.process_names[pid] = label
            elif name == "thread_name" and pid and tid and label:
                result.thread_names[(pid, tid)] = label
            continue
        if phase in {"s", "t", "f"}:
            key = lane_key(event)
            args = event_args(event)
            raw_id = event["id"] if "id" in event else arg_value(args, "id", "flow_id")
            raw_id2 = event["id2"] if "id2" in event else arg_value(args, "id2")
            flow_id = canonical_id(raw_id)
            flow_id2 = compact_json(raw_id2, 500)
            flow_cat = category_text(event)
            flow_name = clean_text(event.get("name"), 500)
            flow_scope = canonical_id(event["scope"] if "scope" in event else arg_value(args, "scope"))
            flow_identity = {
                "cat": flow_cat, "name": flow_name, "scope": flow_scope,
                "id": flow_id, "id2": flow_id2,
            }
            ts = stable_time(event.get("ts"))
            if key and (flow_id or flow_id2) and ts is not None:
                result.flows.append(
                    {"flow_key": stable_hash(compact_json(flow_identity), length=32),
                     "flow_id": flow_id, "flow_id2": flow_id2, "flow_cat": flow_cat,
                     "flow_name": flow_name, "flow_scope": flow_scope, "phase": phase,
                     "pid": key[0], "tid": key[1], "_ts": ts,
                     "source": f"{path}:traceEvents[{index}]"}
                )
            continue
        if phase == "X":
            register(event, index, None, "X")
        elif phase == "B":
            key = lane_key(event)
            if key:
                begin_stacks[key].append((event, index))
            else:
                warn(f"traceEvents[{index}] B event 缺少 pid/tid")
        elif phase == "E":
            key = lane_key(event)
            if not key or not begin_stacks.get(key):
                warn(f"traceEvents[{index}] 孤立 E event")
                continue
            begin, begin_index = begin_stacks[key].pop()
            begin = dict(begin)
            begin["_paired_end_ts"] = event.get("ts")
            register(begin, begin_index, index, "B/E")
    unclosed = sum(len(stack) for stack in begin_stacks.values())
    if unclosed:
        warn(f"trace 结束时有 {unclosed} 个未闭合 B event")
    if warning_overflow:
        result.warnings.append(f"另有 {warning_overflow} 条解析告警未展开")
    finalize_trace_events(result)
    return result


def finalize_trace_events(parsed: ParsedTrace) -> None:
    by_lane: dict[str, list[dict[str, Any]]] = defaultdict(list)
    for row in parsed.events:
        row["process_name"] = parsed.process_names.get(row["pid"], "")
        row["thread_name"] = parsed.thread_names.get((row["pid"], row["tid"]), "")
        if row["domain"] == "host":
            row["lane_id"] = (
                f"host:layer={row['semantic_layer']}:pid={row['pid']}:tid={row['tid']}"
            )
            row["lane_status"] = "trace-pid-tid"
        else:
            stream = row.get("stream_id") or row["tid"]
            device = row.get("device_id") or "unknown"
            row["lane_id"] = f"device={device}:stream={stream}:track={row['pid']}/{row['tid']}"
            row["lane_status"] = "stream-id" if row.get("stream_id") else "trace-track-pid-tid"
        by_lane[row["lane_id"]].append(row)

    for rows in by_lane.values():
        rows.sort(key=lambda item: (item["_ts"], -item["_end"], item["source_event_index"]))
        stack: list[dict[str, Any]] = []
        sibling_counts: Counter[str] = Counter()
        for ordinal, row in enumerate(rows):
            while stack and row["_ts"] >= stack[-1]["_end"]:
                stack.pop()
            if stack and row["_end"] <= stack[-1]["_end"]:
                row["parent_event_id"] = stack[-1]["event_id"]
                row["depth"] = len(stack)
                row["nesting_status"] = "nested"
            elif stack and row["_ts"] < stack[-1]["_end"] < row["_end"]:
                row["nesting_status"] = "overlap-not-contained"
                row["parser_flags"] = "非嵌套重叠"
            else:
                row["nesting_status"] = "root"
            parent = row["parent_event_id"] or "<root>"
            row["sibling_ordinal"] = sibling_counts[parent]
            sibling_counts[parent] += 1
            row["thread_ordinal"] = ordinal
            row["normalized_ordinal"] = round(ordinal / max(1, len(rows) - 1), 9)
            stack.append(row)
        by_event_id = {row["event_id"]: row for row in rows}
        for row in rows:
            parent = by_event_id.get(row.get("parent_event_id", ""))
            row["parent_operator"] = parent["canonical_op"] if parent else ""
            row["call_stack_fingerprint"] = call_stack_fingerprint(row.get("call_stack"))


def parse_kernel_details(path: Path, environment: str, rank: int, default_device: int | None) -> list[dict[str, Any]]:
    if not path.is_file():
        return []
    rows: list[dict[str, Any]] = []
    for source_index, raw in enumerate(read_csv_rows(path)):
        name = clean_text(row_value(raw, "Name", "Op Name", "Operator", "Kernel Name", "Task Name"), 1000)
        if not name:
            continue
        stream = canonical_id(row_value(raw, "Stream ID", "Stream Id", "Stream", "stream_id"))
        device = canonical_id(row_value(raw, "Device ID", "Device_id", "Device"))
        if not device and default_device is not None:
            device = str(default_device)
        start = stable_time(
            row_value(
                raw, "Start Time(us)", "Start Time (us)", "Task Start Time(us)",
                "Start Time", "Start(us)", "Start", "Timestamp",
            )
        )
        event_id = stable_hash(environment, rank, "device-csv", source_index, name, stream, length=24)
        rows.append(
            {
                "environment": environment, "rank": rank, "domain": "device",
                "semantic_layer": "device_task",
                "lane_id": (
                    f"device={device or 'unknown'}:stream={stream}:kernel_details" if stream else ""
                ),
                "lane_status": "stream-id" if stream else "unresolved-no-stream",
                "event_id": event_id, "source_event_index": source_index, "source_end_event_index": "",
                "phase": "csv-row", "pid": "", "tid": stream, "process_name": "",
                "thread_name": f"stream {stream}" if stream else "", "raw_name": name,
                "canonical_op": canonical_operator(name), "op_family": operator_family(name),
                "operator_namespace": "", "classification_reason": "kernel_details.csv device evidence",
                "category": clean_text(row_value(raw, "Type", "Task Type", "Core Type")),
                "thread_ordinal": 0 if stream else "", "normalized_ordinal": 0.0 if stream else "", "depth": 0,
                "parent_event_id": "", "sibling_ordinal": 0,
                "nesting_status": "csv-order" if stream else "rank-only-no-stream",
                "input_shapes": normalize_shape_value(row_value(raw, "Input Shapes", "Input Shape"), UNKNOWN_INPUT_SHAPE),
                "output_shapes": normalize_shape_value(row_value(raw, "Output Shapes", "Output Shape"), UNKNOWN_OUTPUT_SHAPE),
                "input_dtypes": clean_text(row_value(raw, "Input Data Types", "Input Dtypes", "Input Type")),
                "output_dtypes": clean_text(row_value(raw, "Output Data Types", "Output Dtypes", "Output Type")),
                "input_formats": clean_text(row_value(raw, "Input Formats", "Input Format")),
                "output_formats": clean_text(row_value(raw, "Output Formats", "Output Format")),
                "call_stack": "", "module_hierarchy": "", "output_shape_provenance": "kernel_details.csv",
                "correlation_id": canonical_id(row_value(raw, "Correlation ID", "CorrelationId")),
                "external_id": canonical_id(row_value(raw, "External ID", "ExternalId")),
                "stream_id": stream, "device_id": device,
                "task_id": canonical_id(row_value(raw, "Task Id", "Task ID", "task_id")),
                "task_type": clean_text(row_value(raw, "Task Type", "Type")),
                "accelerator_core": clean_text(row_value(raw, "Accelerator Core", "Core Type")),
                "scalar_args": "", "tensor_ids_hashed": "", "value_provenance": "",
                "args_evidence_sha256": stable_hash(compact_json(raw, 32000)),
                "source": f"{path}:row[{source_index + 2}]",
                "parser_flags": "" if stream else "kernel_details row has no Stream Id; excluded from lane alignment",
                "_ts": start if start is not None else Decimal(source_index),
                "_end": start if start is not None else Decimal(source_index),
            }
        )
    grouped: dict[str, list[dict[str, Any]]] = defaultdict(list)
    for row in rows:
        if row["lane_id"]:
            grouped[row["lane_id"]].append(row)
    for lane_rows in grouped.values():
        lane_rows.sort(key=lambda item: (item["_ts"], item["source_event_index"]))
        for ordinal, row in enumerate(lane_rows):
            row["thread_ordinal"] = ordinal
            row["normalized_ordinal"] = round(ordinal / max(1, len(lane_rows) - 1), 9)
            row["sibling_ordinal"] = ordinal
    return rows


def parse_operator_details_coverage(path: Path, environment: str, rank: int) -> list[dict[str, Any]]:
    """Read operator_details only as rank-scoped coverage, never as a thread lane."""
    if not path.is_file():
        return []
    grouped: dict[tuple[str, str, str, str, str], dict[str, Any]] = {}
    for source_index, raw in enumerate(read_csv_rows(path)):
        name = clean_text(row_value(raw, "Name", "Op Name", "Operator", "Operator Name"), 1000)
        if not name:
            continue
        key = (
            canonical_operator(name),
            normalize_shape_value(row_value(raw, "Input Shapes", "Input Shape", "Input Dims"), UNKNOWN_INPUT_SHAPE),
            normalize_shape_value(row_value(raw, "Output Shapes", "Output Shape", "Output Dims"), UNKNOWN_OUTPUT_SHAPE),
            clean_text(row_value(raw, "Input Data Types", "Input Dtypes", "Input Type")),
            clean_text(row_value(raw, "Output Data Types", "Output Dtypes", "Output Type")),
        )
        if key not in grouped:
            grouped[key] = {
                "environment": environment, "rank": rank, "coverage_scope": "rank-only",
                "semantic_layer": "framework_op", "canonical_op": key[0],
                "input_shapes": key[1], "output_shapes": key[2],
                "input_dtypes": key[3], "output_dtypes": key[4], "calls": 0,
                "lane_assignment": "forbidden-no-thread-evidence",
                "source": str(path), "first_source_row": source_index + 2,
                "evidence_ids": [],
            }
        grouped[key]["calls"] += 1
        if len(grouped[key]["evidence_ids"]) < 16:
            grouped[key]["evidence_ids"].append(stable_hash(compact_json(raw, 32000), length=20))
    output = []
    for row in grouped.values():
        row["evidence_ids"] = compact_json(row["evidence_ids"])
        output.append(row)
    return sorted(output, key=lambda row: (row["rank"], row["canonical_op"], row["input_shapes"]))


def public_event(row: dict[str, Any]) -> dict[str, Any]:
    output = {key: value for key, value in row.items() if not key.startswith("_")}
    correlation_id = output.pop("correlation_id", "")
    external_id = output.pop("external_id", "")
    output["correlation_id_hashed"] = (
        stable_hash("correlation_id", correlation_id, length=20) if correlation_id else ""
    )
    output["external_id_hashed"] = (
        stable_hash("external_id", external_id, length=20) if external_id else ""
    )
    output["timestamps_exposed"] = "否（仅序位）"
    return output


def lane_profiles(events: list[dict[str, Any]], domain: str) -> list[dict[str, Any]]:
    grouped: dict[str, list[dict[str, Any]]] = defaultdict(list)
    for row in events:
        if row["domain"] == domain and row.get("lane_id"):
            grouped[row["lane_id"]].append(row)
    profiles = []
    for lane_id, rows in sorted(grouped.items()):
        rows.sort(key=lambda item: item["thread_ordinal"])
        first = rows[0]
        tokens = [event_token(row, "metadata") for row in rows]
        op_tokens = [row["canonical_op"] for row in rows]
        ngrams = Counter(tuple(op_tokens[index : index + 3]) for index in range(max(0, len(op_tokens) - 2)))
        sequence_edges = Counter(
            ("sequence", rows[index - 1]["canonical_op"], rows[index]["canonical_op"])
            for index in range(1, len(rows))
        )
        parent_edges = Counter(
            ("parent", row.get("parent_operator", ""), row["canonical_op"])
            for row in rows if row.get("parent_operator")
        )
        profiles.append(
            {
                "lane_id": lane_id,
                "domain": domain,
                "semantic_layer": first.get("semantic_layer", ""),
                "pid": first["pid"], "tid": first["tid"],
                "process_name": first["process_name"], "thread_name": first["thread_name"],
                "normalized_process_name": normalize_lane_name(first["process_name"], "process"),
                "normalized_thread_name": normalize_lane_name(first["thread_name"], "thread"),
                "event_count": len(rows), "events": rows,
                "counter": Counter(tokens), "ngram_counter": ngrams,
                "edge_counter": sequence_edges + parent_edges,
                "fingerprint": stable_hash(compact_json(tokens, 1_000_000), length=24),
                "has_correlation": any(row.get("correlation_id") or row.get("external_id") for row in rows),
                "nesting_reliable": all(
                    row.get("nesting_status") != "overlap-not-contained" for row in rows
                ),
            }
        )
    return profiles


def event_token(row: dict[str, Any], mode: str) -> tuple[Any, ...]:
    op = row["canonical_op"]
    if mode == "op":
        return (op,)
    metadata = (
        op, row.get("input_shapes", ""), row.get("output_shapes", ""),
        row.get("input_dtypes", ""), row.get("output_dtypes", ""),
        row.get("input_formats", ""), row.get("output_formats", ""),
    )
    if mode == "metadata":
        return metadata
    return (
        *metadata, row.get("depth", 0), row.get("parent_operator", ""),
        row.get("module_hierarchy", ""), row.get("call_stack_fingerprint", ""),
    )


def weighted_jaccard(left: Counter[Any], right: Counter[Any]) -> float:
    keys = set(left) | set(right)
    denominator = sum(max(left.get(key, 0), right.get(key, 0)) for key in keys)
    if not denominator:
        return 1.0
    return sum(min(left.get(key, 0), right.get(key, 0)) for key in keys) / denominator


def name_similarity(left: dict[str, Any], right: dict[str, Any]) -> float:
    left_key = f"{left['normalized_process_name']}|{left['normalized_thread_name']}"
    right_key = f"{right['normalized_process_name']}|{right['normalized_thread_name']}"
    if left_key != "|" and left_key == right_key:
        return 1.0
    return difflib.SequenceMatcher(None, left_key, right_key, autojunk=False).ratio()


def pair_score(left: dict[str, Any], right: dict[str, Any]) -> tuple[float, dict[str, float]]:
    components = {
        "semantic_layer": 1.0 if left["semantic_layer"] == right["semantic_layer"] else 0.0,
        "name": name_similarity(left, right),
        "operator_3gram": weighted_jaccard(left["ngram_counter"], right["ngram_counter"]),
        "operator_shape_multiset": weighted_jaccard(left["counter"], right["counter"]),
        "parent_child_edges": weighted_jaccard(left["edge_counter"], right["edge_counter"]),
        "role_correlation": 1.0 if left["has_correlation"] and right["has_correlation"] else 0.0,
    }
    if not components["semantic_layer"]:
        return 0.0, components
    score = (
        0.15 * components["name"] + 0.25 * components["operator_3gram"]
        + 0.20 * components["operator_shape_multiset"] + 0.15 * components["parent_child_edges"]
        + 0.15 * components["semantic_layer"] + 0.10 * components["role_correlation"]
    )
    return score, components


def hungarian_max(matrix: list[list[float]]) -> list[tuple[int, int]]:
    if not matrix or not matrix[0]:
        return []
    rows, columns = len(matrix), len(matrix[0])
    size = max(rows, columns)
    maximum = max(max(row) for row in matrix)
    cost = [[maximum for _ in range(size)] for _ in range(size)]
    for i in range(rows):
        for j in range(columns):
            cost[i][j] = maximum - matrix[i][j]
    u = [0.0] * (size + 1)
    v = [0.0] * (size + 1)
    p = [0] * (size + 1)
    way = [0] * (size + 1)
    for i in range(1, size + 1):
        p[0] = i
        j0 = 0
        minv = [float("inf")] * (size + 1)
        used = [False] * (size + 1)
        while True:
            used[j0] = True
            i0 = p[j0]
            delta = float("inf")
            j1 = 0
            for j in range(1, size + 1):
                if used[j]:
                    continue
                current = cost[i0 - 1][j - 1] - u[i0] - v[j]
                if current < minv[j] - 1e-15:
                    minv[j] = current
                    way[j] = j0
                if minv[j] < delta - 1e-15 or (abs(minv[j] - delta) <= 1e-15 and j < j1):
                    delta = minv[j]
                    j1 = j
            for j in range(size + 1):
                if used[j]:
                    u[p[j]] += delta
                    v[j] -= delta
                else:
                    minv[j] -= delta
            j0 = j1
            if p[j0] == 0:
                break
        while True:
            j1 = way[j0]
            p[j0] = p[j1]
            j0 = j1
            if j0 == 0:
                break
    assignment = []
    for column in range(1, size + 1):
        row = p[column]
        if 1 <= row <= rows and 1 <= column <= columns:
            assignment.append((row - 1, column - 1))
    return sorted(assignment)


def pair_lanes(
    real: list[dict[str, Any]], sim: list[dict[str, Any]], rank_pair_id: str, domain: str
) -> tuple[list[dict[str, Any]], list[tuple[dict[str, Any], dict[str, Any], str]]]:
    scores: list[list[float]] = []
    components: dict[tuple[int, int], dict[str, float]] = {}
    for i, left in enumerate(real):
        row_scores = []
        for j, right in enumerate(sim):
            score, parts = pair_score(left, right)
            row_scores.append(score)
            components[(i, j)] = parts
        scores.append(row_scores)
    assignments = hungarian_max(scores)
    real_name_counts = Counter(
        (row["normalized_process_name"], row["normalized_thread_name"]) for row in real
    )
    sim_name_counts = Counter(
        (row["normalized_process_name"], row["normalized_thread_name"]) for row in sim
    )
    paired_real: set[int] = set()
    paired_sim: set[int] = set()
    rows: list[dict[str, Any]] = []
    accepted: list[tuple[dict[str, Any], dict[str, Any], str]] = []
    for i, j in assignments:
        score = scores[i][j]
        alternatives = sorted(
            [scores[i][k] for k in range(len(sim)) if k != j]
            + [scores[k][j] for k in range(len(real)) if k != i],
            reverse=True,
        )
        second = alternatives[0] if alternatives else 0.0
        margin = score - second
        semantic_key = (
            real[i]["normalized_process_name"], real[i]["normalized_thread_name"]
        )
        unique_exact_name = (
            all(semantic_key)
            and real[i]["semantic_layer"] == sim[j]["semantic_layer"]
            and semantic_key == (
                sim[j]["normalized_process_name"], sim[j]["normalized_thread_name"]
            )
            and real_name_counts[semantic_key] == 1
            and sim_name_counts[semantic_key] == 1
        )
        if unique_exact_name:
            confidence, status = "高", "matched"
        elif score >= 0.80 and margin >= 0.15:
            confidence, status = "高", "matched"
        elif score >= 0.65 and margin >= 0.10:
            confidence, status = "中", "matched-degraded"
        else:
            confidence, status = "低", "ambiguous"
        left, right = real[i], sim[j]
        layer = left["semantic_layer"] if left["semantic_layer"] == right["semantic_layer"] else "cross-layer"
        pair_id = f"{rank_pair_id}:{domain}:{layer}:lane-{len(rows):04d}"
        rows.append(
            {
                "rank_pair_id": rank_pair_id, "thread_pair_id": pair_id, "domain": domain,
                "semantic_layer": left["semantic_layer"],
                "real_lane_id": left["lane_id"], "sim_lane_id": right["lane_id"],
                "real_pid": left["pid"], "real_tid": left["tid"],
                "real_process_name": left["process_name"], "real_thread_name": left["thread_name"],
                "sim_pid": right["pid"], "sim_tid": right["tid"],
                "sim_process_name": right["process_name"], "sim_thread_name": right["thread_name"],
                "match_method": "deterministic-hungarian-structural-score-v1",
                "score": round(score, 6), "second_best_score": round(second, 6),
                "margin": round(margin, 6), "confidence": confidence, "status": status,
                "real_nesting_reliable": left["nesting_reliable"],
                "sim_nesting_reliable": right["nesting_reliable"],
                "score_components": compact_json({key: round(value, 6) for key, value in components[(i, j)].items()}),
                "evidence_ids": compact_json([left["fingerprint"], right["fingerprint"]]),
            }
        )
        paired_real.add(i)
        paired_sim.add(j)
        if status.startswith("matched"):
            for profile in (left, right):
                profile["_lane_match_status"] = status
                profile["_lane_match_confidence"] = confidence
                profile["_lane_match_score"] = round(score, 6)
                profile["_lane_match_margin"] = round(margin, 6)
            accepted.append((left, right, pair_id))
    for i, left in enumerate(real):
        if i not in paired_real:
            rows.append(
                {"rank_pair_id": rank_pair_id, "thread_pair_id": "", "domain": domain,
                 "semantic_layer": left["semantic_layer"],
                 "real_lane_id": left["lane_id"], "sim_lane_id": "", "real_pid": left["pid"],
                 "real_tid": left["tid"], "real_process_name": left["process_name"],
                 "real_thread_name": left["thread_name"], "sim_pid": "", "sim_tid": "",
                 "sim_process_name": "", "sim_thread_name": "", "match_method": "union-inventory",
                 "score": "", "second_best_score": "", "margin": "", "confidence": "",
                 "status": "real-only", "score_components": "", "evidence_ids": left["fingerprint"]}
            )
    for j, right in enumerate(sim):
        if j not in paired_sim:
            rows.append(
                {"rank_pair_id": rank_pair_id, "thread_pair_id": "", "domain": domain,
                 "semantic_layer": right["semantic_layer"],
                 "real_lane_id": "", "sim_lane_id": right["lane_id"], "real_pid": "", "real_tid": "",
                 "real_process_name": "", "real_thread_name": "", "sim_pid": right["pid"],
                 "sim_tid": right["tid"], "sim_process_name": right["process_name"],
                 "sim_thread_name": right["thread_name"], "match_method": "union-inventory",
                 "score": "", "second_best_score": "", "margin": "", "confidence": "",
                 "status": "sim-only", "score_components": "", "evidence_ids": right["fingerprint"]}
            )
    return rows, accepted


def sequence_runs(events: list[dict[str, Any]], mode: str) -> list[dict[str, Any]]:
    runs: list[dict[str, Any]] = []
    for row in sorted(events, key=lambda item: item["thread_ordinal"]):
        token = event_token(row, mode)
        if runs and runs[-1]["token"] == token:
            runs[-1]["event_ids"].append(row["event_id"])
            runs[-1]["end_ordinal"] = row["thread_ordinal"]
            runs[-1]["calls"] += 1
            continue
        runs.append(
            {"token": token, "operator": row["canonical_op"], "input_shapes": row["input_shapes"],
             "output_shapes": row["output_shapes"], "start_ordinal": row["thread_ordinal"],
             "end_ordinal": row["thread_ordinal"], "calls": 1, "event_ids": [row["event_id"]],
             "call_stack": row["call_stack"], "module_hierarchy": row["module_hierarchy"],
             "source": row["source"], "depth": row["depth"]}
        )
    for run in runs:
        run["alignment_token"] = (*run["token"], ("run_calls", run["calls"]))
    return runs


def first_non_equal_opcode(real_runs: list[dict[str, Any]], sim_runs: list[dict[str, Any]]) -> tuple[int, int] | None:
    matcher = difflib.SequenceMatcher(
        None, [run["alignment_token"] for run in real_runs],
        [run["alignment_token"] for run in sim_runs], autojunk=False
    )
    for tag, i1, _i2, j1, _j2 in matcher.get_opcodes():
        if tag != "equal":
            return i1, j1
    return None


def align_lane_events(
    real_profile: dict[str, Any], sim_profile: dict[str, Any], rank_pair_id: str,
    thread_pair_id: str, domain: str,
) -> tuple[list[dict[str, Any]], dict[str, Any] | None]:
    semantic_layer = real_profile["semantic_layer"]
    real_runs = sequence_runs(real_profile["events"], "tree")
    sim_runs = sequence_runs(sim_profile["events"], "tree")
    matcher = difflib.SequenceMatcher(
        None, [run["alignment_token"] for run in real_runs],
        [run["alignment_token"] for run in sim_runs], autojunk=False
    )
    opcodes = matcher.get_opcodes()
    alignment: list[dict[str, Any]] = []
    column = 0
    first_window: dict[str, Any] | None = None
    last_equal_real: dict[str, Any] | None = None
    last_equal_sim: dict[str, Any] | None = None
    previous_anchor_count = 0
    for opcode_index, (tag, i1, i2, j1, j2) in enumerate(opcodes):
        span = max(i2 - i1, j2 - j1)
        for offset in range(span):
            left = real_runs[i1 + offset] if i1 + offset < i2 else None
            right = sim_runs[j1 + offset] if j1 + offset < j2 else None
            if tag == "equal":
                relation = "exact"
            elif left and right:
                if left["token"] == right["token"] and left["calls"] != right["calls"]:
                    relation = "run_calls_mismatch"
                else:
                    relation = "metadata_mismatch" if left["operator"] == right["operator"] else "substitute"
            elif left:
                relation = "real_only"
            else:
                relation = "sim_only"
            alignment.append(
                {"rank_pair_id": rank_pair_id, "domain": domain,
                 "semantic_layer": semantic_layer, "thread_pair_id": thread_pair_id,
                 "alignment_column": column, "block_id": opcode_index,
                 "real_event_ids": compact_json(left["event_ids"]) if left else "",
                 "sim_event_ids": compact_json(right["event_ids"]) if right else "",
                 "real_ordinal_start": left["start_ordinal"] if left else "",
                 "real_ordinal_end": left["end_ordinal"] if left else "",
                 "sim_ordinal_start": right["start_ordinal"] if right else "",
                 "sim_ordinal_end": right["end_ordinal"] if right else "",
                 "real_operator": left["operator"] if left else "",
                 "sim_operator": right["operator"] if right else "",
                 "real_run_calls": left["calls"] if left else "",
                 "sim_run_calls": right["calls"] if right else "", "relation": relation,
                 "op_relation": "same" if left and right and left["operator"] == right["operator"] else "different",
                 "shape_relation": "same" if left and right and (left["input_shapes"], left["output_shapes"]) == (right["input_shapes"], right["output_shapes"]) else "different-or-missing",
                 "nesting_relation": "same" if left and right and left["depth"] == right["depth"] else "different-or-missing",
                 "first_divergence": "是" if first_window is None and tag != "equal" and offset == 0 else "否",
                 "anchor_kind": "tree-token" if tag == "equal" else "", "anchor_strength": "exact" if tag == "equal" else "",
                 "evidence_ids": compact_json((left["event_ids"] if left else []) + (right["event_ids"] if right else []))}
            )
            column += 1
        if tag == "equal" and i2 > i1 and j2 > j1:
            last_equal_real = real_runs[i2 - 1]
            last_equal_sim = sim_runs[j2 - 1]
            previous_anchor_count = min(i2 - i1, j2 - j1)
        elif first_window is None:
            next_real = next_sim = None
            following_anchor_count = 0
            for future_tag, fi1, fi2, fj1, fj2 in opcodes[opcode_index + 1 :]:
                if future_tag == "equal" and fi2 > fi1 and fj2 > fj1:
                    next_real, next_sim = real_runs[fi1], sim_runs[fj1]
                    following_anchor_count = min(fi2 - fi1, fj2 - fj1)
                    break
            first_window = {
                "divergence_id": f"{thread_pair_id}:first", "rank_pair_id": rank_pair_id,
                "domain": domain, "semantic_layer": semantic_layer,
                "thread_pair_id": thread_pair_id,
                "lane_match_status": real_profile.get("_lane_match_status", ""),
                "lane_match_confidence": real_profile.get("_lane_match_confidence", ""),
                "lane_match_score": real_profile.get("_lane_match_score", ""),
                "lane_match_margin": real_profile.get("_lane_match_margin", ""),
                "anchors_before": previous_anchor_count,
                "anchors_after": following_anchor_count,
                "anchor_gate_passed": previous_anchor_count >= 3 and following_anchor_count >= 3,
                "nesting_gate_passed": (
                    real_profile.get("nesting_reliable") is True
                    and sim_profile.get("nesting_reliable") is True
                ),
                "last_common_anchor": compact_json({"real": last_equal_real, "sim": last_equal_sim}),
                "first_real_event": compact_json(real_runs[i1] if i1 < i2 else {}),
                "first_sim_event": compact_json(sim_runs[j1] if j1 < j2 else {}),
                "next_common_anchor": compact_json({"real": next_real, "sim": next_sim}),
                "real_event_ids": [eid for run in real_runs[i1:i2] for eid in run["event_ids"]],
                "sim_event_ids": [eid for run in sim_runs[j1:j2] for eid in run["event_ids"]],
                "real_operators": [run["operator"] for run in real_runs[i1:i2]],
                "sim_operators": [run["operator"] for run in sim_runs[j1:j2]],
                "real_run_calls": [run["calls"] for run in real_runs[i1:i2]],
                "sim_run_calls": [run["calls"] for run in sim_runs[j1:j2]],
                "real_shapes": [(run["input_shapes"], run["output_shapes"]) for run in real_runs[i1:i2]],
                "sim_shapes": [(run["input_shapes"], run["output_shapes"]) for run in sim_runs[j1:j2]],
                "real_call_stacks": [run["call_stack"] for run in real_runs[i1:i2] if run["call_stack"]],
                "sim_call_stacks": [run["call_stack"] for run in sim_runs[j1:j2] if run["call_stack"]],
                "real_modules": [run["module_hierarchy"] for run in real_runs[i1:i2] if run["module_hierarchy"]],
                "sim_modules": [run["module_hierarchy"] for run in sim_runs[j1:j2] if run["module_hierarchy"]],
                "divergence_kind": tag, "alternative_explanations": [
                    "采集窗口或 instrumentation 不一致", "线程配对错误", "动态 Shape/输入不同",
                    "backend lowering 差异", "控制流 predicate 结果不同",
                ],
            }
    mode_boundaries = {}
    for mode in ("op", "metadata", "tree"):
        boundary = first_non_equal_opcode(sequence_runs(real_profile["events"], mode), sequence_runs(sim_profile["events"], mode))
        mode_boundaries[mode] = boundary
    if first_window is not None:
        values = list(mode_boundaries.values())
        first_window["alignment_boundaries"] = mode_boundaries
        stable_boundary = (
            all(value is None for value in values)
            or (all(value is not None for value in values) and len(set(values)) == 1)
        )
        first_window["boundary_stability"] = "stable" if stable_boundary else "unstable"
        anchor_tokens = [
            run["alignment_token"] for run in (last_equal_real, next_real)
            if run is not None
        ]
        repeated_ambiguous = any(
            sum(run["alignment_token"] == token for run in real_runs) > 1
            and sum(run["alignment_token"] == token for run in sim_runs) > 1
            for token in anchor_tokens
        )
        first_window["repeated_anchor_ambiguous"] = repeated_ambiguous
        first_window["alignment_ambiguity"] = (
            "repeated-anchor-ambiguous" if repeated_ambiguous else "none-observed"
        )
        first_window["earlier_unresolved"] = (
            "是" if first_window["boundary_stability"] != "stable" or repeated_ambiguous else "否"
        )
    return alignment, first_window


def build_host_device_links(events: list[dict[str, Any]], flows: list[dict[str, Any]]) -> list[dict[str, Any]]:
    by_namespaced_id: dict[tuple[str, str], list[dict[str, Any]]] = defaultdict(list)
    by_lane: dict[tuple[str, str], list[dict[str, Any]]] = defaultdict(list)
    for row in events:
        by_lane[(row["pid"], row["tid"])].append(row)
        for namespace, raw in (
            ("correlation_id", row.get("correlation_id", "")),
            ("external_id", row.get("external_id", "")),
        ):
            if raw:
                by_namespaced_id[(namespace, raw)].append(row)
    links: list[dict[str, Any]] = []
    seen: set[tuple[str, str, str]] = set()

    def emit(
        host: dict[str, Any], device: dict[str, Any], kind: str, namespace: str,
        raw_id: str, status: str, endpoint_match: str = "unique-id",
        causal_eligible: bool = True,
    ) -> None:
        key = (host["event_id"], device["event_id"], f"{kind}:{namespace}:{raw_id}")
        if key in seen:
            return
        seen.add(key)
        links.append(
            {"environment": host["environment"], "rank": host["rank"],
             "host_event_id": host["event_id"], "device_event_id": device["event_id"],
             "host_lane_id": host["lane_id"], "device_lane_id": device["lane_id"],
             "host_semantic_layer": host["semantic_layer"],
             "device_semantic_layer": device["semantic_layer"],
             "correlation_type": kind, "correlation_namespace": namespace,
             "correlation_id_hash": stable_hash(namespace, raw_id, length=20),
             "link_status": status, "endpoint_match": endpoint_match,
             "causal_eligible": "是" if causal_eligible else "否",
             "evidence_ids": compact_json([host["source"], device["source"]])}
        )

    for (namespace, raw_id), rows in by_namespaced_id.items():
        hosts = [row for row in rows if row["domain"] == "host"]
        devices = [
            row for row in rows
            if row["domain"] == "device" and row.get("semantic_layer") == "device_task"
        ]
        # A shared ID is direct evidence only when both endpoints are unique.  Never
        # expand ambiguous IDs into a Cartesian product of false direct links.
        if len(hosts) == 1 and len(devices) == 1:
            emit(hosts[0], devices[0], "event-id", namespace, raw_id, "direct-id")

    flow_groups: dict[str, list[dict[str, Any]]] = defaultdict(list)
    for flow in flows:
        flow_groups[flow["flow_key"]].append(flow)

    def endpoint(
        flow: dict[str, Any], domain: str, semantic_layer: str,
    ) -> tuple[dict[str, Any] | None, str]:
        candidates = [
            row for row in by_lane.get((flow["pid"], flow["tid"]), [])
            if row["domain"] == domain
            and row.get("semantic_layer") == semantic_layer
            and row["_ts"] <= flow["_ts"] <= row["_end"]
        ]
        exact = [
            row for row in candidates
            if row["_ts"] == flow["_ts"] or row["_end"] == flow["_ts"]
        ]
        if len(exact) == 1:
            return exact[0], "exact-pid-tid-boundary"
        if not exact and len(candidates) == 1:
            return candidates[0], "unique-containment-degraded"
        return None, "ambiguous-or-missing"

    for flow_key, group in flow_groups.items():
        starts = [flow for flow in group if flow["phase"] == "s"]
        ends = [flow for flow in group if flow["phase"] == "f"]
        if len(starts) != 1 or len(ends) != 1:
            continue
        start, end = starts[0], ends[0]
        category = start["flow_cat"].casefold()
        name = start["flow_name"].casefold()
        if category == "hosttodevice":
            host_layer = "host_launch"
        elif category == "async_npu" and name == "torch_to_npu":
            host_layer = "framework_op"
        else:
            continue
        host, host_match = endpoint(start, "host", host_layer)
        device, device_match = endpoint(end, "device", "device_task")
        if host is None or device is None:
            continue
        flow_identity = compact_json(
            {"cat": start["flow_cat"], "name": start["flow_name"],
             "scope": start["flow_scope"], "id": start["flow_id"], "id2": start["flow_id2"]},
            2000,
        )
        exact_endpoints = host_match.startswith("exact-") and device_match.startswith("exact-")
        emit(
            host, device, "chrome-flow", "cat/name/scope/id/id2",
            flow_identity or flow_key,
            "direct-flow" if exact_endpoints else "degraded-flow-containment",
            endpoint_match=f"host={host_match};device={device_match}",
            causal_eligible=exact_endpoints,
        )
    return links


def heatmap_rows(
    accepted_pairs: list[tuple[dict[str, Any], dict[str, Any], str]], rank_pair_id: str,
    domain: str, bins: int, divergence_ids: set[str],
) -> list[dict[str, Any]]:
    output: list[dict[str, Any]] = []
    for real, sim, pair_id in accepted_pairs:
        for environment, profile in (("real/reference/真机", real), ("sim/candidate/仿真", sim)):
            cells: dict[tuple[int, str], list[dict[str, Any]]] = defaultdict(list)
            count = max(1, len(profile["events"]))
            for event in profile["events"]:
                bin_index = min(bins - 1, int(event["thread_ordinal"] * bins / count))
                cells[(bin_index, event["op_family"])].append(event)
            totals: Counter[int] = Counter()
            for (bin_index, _family), events in cells.items():
                totals[bin_index] += len(events)
            for (bin_index, family), events in sorted(cells.items()):
                output.append(
                    {"rank_pair_id": rank_pair_id, "domain": domain, "thread_pair_id": pair_id,
                     "semantic_layer": profile["semantic_layer"],
                     "environment": environment, "lane_id": profile["lane_id"], "bin_index": bin_index,
                     "normalized_start": round(bin_index / bins, 6),
                     "normalized_end": round((bin_index + 1) / bins, 6), "operator_family": family,
                     "event_count": len(events), "is_dominant": "是" if len(events) == max(
                         len(value) for (cell_bin, _), value in cells.items() if cell_bin == bin_index
                     ) else "否",
                     "event_ids": compact_json([event["event_id"] for event in events]),
                     "contains_first_divergence": "是" if any(event["event_id"] in divergence_ids for event in events) else "否",
                     "position_semantics": "lane-relative event ordinal; not time"}
                )
    return output


def write_csv(path: Path, rows: Iterable[dict[str, Any]], fields: list[str] | None = None) -> None:
    materialized = list(rows)
    path.parent.mkdir(parents=True, exist_ok=True)
    if fields is None:
        fields = []
        seen: set[str] = set()
        for row in materialized:
            for key in row:
                if key not in seen:
                    seen.add(key)
                    fields.append(key)
        if not fields:
            fields = EMPTY_CSV_SCHEMAS.get(path.name, ["message"])
    with path.open("w", newline="", encoding="utf-8-sig") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields, extrasaction="ignore")
        writer.writeheader()
        writer.writerows(materialized)


def write_json(path: Path, value: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8") as handle:
        json.dump(value, handle, ensure_ascii=False, indent=2)


def write_jsonl(path: Path, rows: Iterable[dict[str, Any]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8") as handle:
        for row in rows:
            handle.write(json.dumps(row, ensure_ascii=False, sort_keys=True) + "\n")


def structural_heatmap_html(rows: list[dict[str, Any]]) -> str:
    groups: dict[tuple[str, str, str, str], list[dict[str, Any]]] = defaultdict(list)
    for row in rows:
        groups[(row["rank_pair_id"], row["domain"], row["thread_pair_id"], row["environment"])].append(row)
    palettes = {
        "communication": "#d97757", "attention": "#a78bfa", "matmul": "#60a5fa",
        "normalization": "#34d399", "activation": "#fbbf24", "routing": "#f472b6",
        "memory": "#94a3b8", "shape": "#22d3ee", "other": "#64748b",
        "aten": "#818cf8", "torch_npu": "#2dd4bf", "npu": "#14b8a6",
    }
    sections = []
    for key, values in sorted(groups.items()):
        by_bin: dict[int, list[dict[str, Any]]] = defaultdict(list)
        for row in values:
            by_bin[int(row["bin_index"])].append(row)
        cells = []
        max_bin = max(by_bin, default=-1)
        for index in range(max_bin + 1):
            choices = sorted(by_bin.get(index, []), key=lambda row: (-int(row["event_count"]), row["operator_family"]))
            if not choices:
                cells.append('<td class="empty" title="无事件"></td>')
                continue
            row = choices[0]
            color = palettes.get(row["operator_family"], "#64748b")
            border = "outline:2px solid #ef4444;" if row["contains_first_divergence"] == "是" else ""
            title = html.escape(f"bin={index}; family={row['operator_family']}; events={row['event_count']}")
            cells.append(f'<td title="{title}" style="background:{color};{border}"></td>')
        label = html.escape(" / ".join(key))
        sections.append(f"<h2>{label}</h2><table><tr>{''.join(cells)}</tr></table>")
    return f"""<!doctype html><html lang="zh-CN"><head><meta charset="utf-8"><title>算子序位热力图</title>
<style>body{{background:#0b1020;color:#e5e7eb;font:14px system-ui;margin:24px}}h1{{font-size:22px}}h2{{font-size:13px;margin-top:20px;color:#cbd5e1}}table{{border-collapse:collapse;width:100%;table-layout:fixed}}td{{height:22px;border:1px solid #111827}}td.empty{{background:#111827}}.note{{padding:12px;background:#172033;border-left:3px solid #38bdf8}}</style></head>
<body><h1>真机 / 仿真算子序位热力图</h1><p class="note">横轴是 lane 内归一化事件序位，不是时间；红框标出首次结构分叉所在 bin。格宽、颜色面积和空白均不得解释为耗时、利用率或性能。</p>{''.join(sections)}</body></html>"""


def validate_roots(real: Path, sim: Path, output: Path) -> tuple[Path, Path, Path]:
    real = real.resolve()
    sim = sim.resolve()
    output = output.resolve()
    if not real.is_dir() or not sim.is_dir():
        raise ValueError("真机和仿真 Profiling 根目录都必须存在")
    if real == sim:
        raise ValueError("真机与仿真 Profiling 目录不能相同")
    for source in (real, sim):
        try:
            output.relative_to(source)
            raise ValueError("输出目录不得位于任何原始 Profiling 根目录内")
        except ValueError as error:
            if str(error).startswith("输出目录"):
                raise
    return real, sim, output


def rank_map(root: Path) -> tuple[dict[int, RankInfo], list[RankInfo], list[str]]:
    infos = [infer_rank_info(path) for path in discover_outputs(root)]
    warnings: list[str] = []
    result: dict[int, RankInfo] = {}
    unresolved: list[RankInfo] = []
    duplicates: set[int] = set()
    for info in infos:
        if info.rank_id is None:
            unresolved.append(info)
        elif info.rank_id in result:
            duplicates.add(info.rank_id)
            previous = result.pop(info.rank_id)
            previous.identity_status = info.identity_status = "duplicate"
            previous.identity_reason = info.identity_reason = f"duplicate resolved global rank {info.rank_id}"
            unresolved.extend([previous, info])
        elif info.rank_id not in duplicates:
            result[info.rank_id] = info
    if unresolved:
        warnings.append("存在无法恢复或重复的 global rank；未按目录顺序猜测，也未左移配对")
    return result, unresolved, warnings


def topology_compatible(real: RankInfo, sim: RankInfo) -> tuple[str, str]:
    mismatches = []
    unknown = []
    for field_name in PARALLEL_FIELDS:
        left, right = getattr(real, field_name), getattr(sim, field_name)
        if left is None or right is None:
            unknown.append(field_name)
        elif left != right:
            mismatches.append(f"{field_name}:{left}!={right}")
    if mismatches:
        return "否", ";".join(mismatches)
    if unknown:
        return "待确认", "unknown:" + ",".join(unknown)
    return "是", "DP/TP/EP/PP/CP/DCP 全部一致"


def write_perfetto_lane_file(path: Path, profiles: list[dict[str, Any]]) -> None:
    # Perfetto selects a thread by numeric pid/tid, while local analysis keeps
    # framework_op and host_launch as separate semantic lanes.  Merge only for UI
    # selection to avoid duplicate pid/tid jobs; retain the covered layers explicitly.
    grouped: dict[tuple[str, str], list[dict[str, Any]]] = defaultdict(list)
    for profile in profiles:
        grouped[(profile["pid"], profile["tid"])].append(profile)
    lanes = []
    for (pid, tid), lane_profiles_for_thread in sorted(grouped.items()):
        first = lane_profiles_for_thread[0]
        compatible = parse_int(pid) is not None and parse_int(tid) is not None
        if compatible:
            compatible = 0 <= int(pid) <= 2**53 - 1 and 0 <= int(tid) <= 2**53 - 1
        layers = sorted({profile["semantic_layer"] for profile in lane_profiles_for_thread})
        lanes.append(
            {"pid": pid, "tid": tid, "process_name": first["process_name"],
             "thread_name": first["thread_name"],
             "lane_id": f"host:pid={pid}:tid={tid}",
             "semantic_layer": layers[0] if len(layers) == 1 else "mixed-host-thread",
             "semantic_layers": layers,
             "local_semantic_lane_ids": [
                 profile["lane_id"] for profile in lane_profiles_for_thread
             ],
             "renderer_compatible": compatible,
             "event_count": sum(profile["event_count"] for profile in lane_profiles_for_thread)}
        )
    write_json(
        path,
        {"schema_version": 2, "domain": "host", "selection_unit": "unique-pid-tid-thread",
         "semantic_evidence": "framework_op and host_launch remain separate in canonical_events.csv",
         "lanes": lanes},
    )


def analyze(real_root: Path, sim_root: Path, output: Path, heatmap_bins: int) -> dict[str, Any]:
    real_root, sim_root, output = validate_roots(real_root, sim_root, output)
    output.mkdir(parents=True, exist_ok=True)
    real_ranks, real_unresolved, real_warnings = rank_map(real_root)
    sim_ranks, sim_unresolved, sim_warnings = rank_map(sim_root)
    common = sorted(set(real_ranks) & set(sim_ranks))
    if not common:
        raise ValueError("没有可按同号 global rank 对齐的真机/仿真 Rank")
    rank_pair_rows: list[dict[str, Any]] = []
    unpaired_rows: list[dict[str, Any]] = []
    thread_rows: list[dict[str, Any]] = []
    canonical_rows: list[dict[str, Any]] = []
    alignment_rows: list[dict[str, Any]] = []
    divergence_rows: list[dict[str, Any]] = []
    link_rows: list[dict[str, Any]] = []
    heat_rows: list[dict[str, Any]] = []
    parser_warnings: list[dict[str, Any]] = []
    operator_coverage_rows: list[dict[str, Any]] = []

    for side, mapping, other in (("real/reference/真机", real_ranks, sim_ranks), ("sim/candidate/仿真", sim_ranks, real_ranks)):
        for rank_id, info in sorted(mapping.items()):
            if rank_id not in other:
                unpaired_rows.append({"environment": side, "rank": rank_id, "path": str(info.root),
                                      "reason": "另一侧不存在同号 Rank；未重编号或左移配对"})
    for side, infos in (("real/reference/真机", real_unresolved), ("sim/candidate/仿真", sim_unresolved)):
        for info in infos:
            unpaired_rows.append({"environment": side, "rank": "未知/重复", "path": str(info.root),
                                  "reason": "global rank 无法唯一恢复；需要用户提供明确映射"})

    unresolved_by_path = {
        str(info.root): info for info in [*real_unresolved, *sim_unresolved]
    }
    for row in unpaired_rows:
        info = unresolved_by_path.get(row["path"])
        if info is not None:
            row["rank"] = "unknown/conflict/duplicate"
            row["identity_status"] = info.identity_status
            row["reason"] = info.identity_reason or "global rank could not be resolved uniquely"

    for rank_id in common:
        real_info, sim_info = real_ranks[rank_id], sim_ranks[rank_id]
        pair_id = f"rank-{rank_id:04d}"
        compatible, topology_note = topology_compatible(real_info, sim_info)
        real_trace, sim_trace = real_info.trace_path, sim_info.trace_path
        pair_row = {"rank_pair_id": pair_id, "real_rank": rank_id, "sim_rank": rank_id,
             "pair_rule": "exact-global-rank-intersection",
             "real_trace_path": str(real_trace) if real_trace else "缺失",
             "sim_trace_path": str(sim_trace) if sim_trace else "缺失",
             "real_trace_sha256": file_sha256(real_trace) if real_trace else "",
             "sim_trace_sha256": file_sha256(sim_trace) if sim_trace else "",
             "real_topology": real_info.coordinate_text, "sim_topology": sim_info.coordinate_text,
             "topology_compatible": compatible,
             "status": "ready" if real_trace and sim_trace and compatible == "是" else "partial",
             "real_parse_status": "pending", "sim_parse_status": "pending", "notes": topology_note}
        rank_pair_rows.append(pair_row)
        parsed: dict[str, ParsedTrace] = {}
        events_by_side: dict[str, list[dict[str, Any]]] = {}
        parse_status_by_side: dict[str, str] = {}
        for side_key, label, info, trace in (
            ("real", "real/reference/真机", real_info, real_trace),
            ("sim", "sim/candidate/仿真", sim_info, sim_trace),
        ):
            if trace:
                try:
                    trace_result = parse_trace(trace, label, rank_id)
                    parse_status_by_side[side_key] = "success"
                except Exception as error:
                    trace_result = ParsedTrace(warnings=[f"trace parse failed: {type(error).__name__}: {error}"])
                    parse_status_by_side[side_key] = "failure"
                parsed[side_key] = trace_result
                events = trace_result.events
                for warning in trace_result.warnings:
                    parser_warnings.append({"environment": label, "rank": rank_id, "source": str(trace), "warning": warning})
                if trace_result.warnings:
                    pair_row["status"] = "partial"
            else:
                parsed[side_key] = ParsedTrace(warnings=["trace_view.json 缺失"])
                parse_status_by_side[side_key] = "missing"
                events = []
            trace_device = [
                row for row in events
                if row.get("semantic_layer") == "device_task" and row["domain"] == "device"
            ]
            if not trace_device:
                kernel_rows = parse_kernel_details(
                    info.root / "kernel_details.csv", label, rank_id, info.device
                )
                events.extend(kernel_rows)
                unresolved_kernel_rows = [row for row in kernel_rows if not row.get("lane_id")]
                if unresolved_kernel_rows:
                    pair_row["status"] = "partial"
                    parser_warnings.append(
                        {"environment": label, "rank": rank_id,
                         "source": str(info.root / "kernel_details.csv"),
                         "warning": (
                             f"{len(unresolved_kernel_rows)} kernel_details row(s) have no Stream Id; "
                             "kept as rank evidence and excluded from lane alignment"
                         )}
                    )
            operator_coverage_rows.extend(
                parse_operator_details_coverage(
                    info.root / "operator_details.csv", label, rank_id
                )
            )
            events_by_side[side_key] = events
            canonical_rows.extend(public_event(row) for row in events)
        pair_row["real_parse_status"] = parse_status_by_side["real"]
        pair_row["sim_parse_status"] = parse_status_by_side["sim"]
        if any(status != "success" for status in parse_status_by_side.values()):
            pair_row["status"] = "partial"

        real_host = lane_profiles(events_by_side["real"], "host")
        sim_host = lane_profiles(events_by_side["sim"], "host")
        real_device = lane_profiles(events_by_side["real"], "device")
        sim_device = lane_profiles(events_by_side["sim"], "device")
        write_perfetto_lane_file(output / "perfetto_inputs" / pair_id / "real_host_lanes.json", real_host)
        write_perfetto_lane_file(output / "perfetto_inputs" / pair_id / "sim_host_lanes.json", sim_host)
        pair_row["real_framework_lanes"] = sum(
            profile["semantic_layer"] == "framework_op" for profile in real_host
        )
        pair_row["sim_framework_lanes"] = sum(
            profile["semantic_layer"] == "framework_op" for profile in sim_host
        )
        pair_row["real_host_launch_lanes"] = sum(
            profile["semantic_layer"] == "host_launch" for profile in real_host
        )
        pair_row["sim_host_launch_lanes"] = sum(
            profile["semantic_layer"] == "host_launch" for profile in sim_host
        )
        pair_row["real_device_lanes"] = len(real_device)
        pair_row["sim_device_lanes"] = len(sim_device)
        if (
            not pair_row["real_framework_lanes"] or not pair_row["sim_framework_lanes"]
            or not pair_row["real_device_lanes"] or not pair_row["sim_device_lanes"]
        ):
            pair_row["status"] = "partial"
            parser_warnings.append(
                {"environment": "both", "rank": rank_id, "source": pair_id,
                 "warning": "framework_op 或可比较 device_task lane 在至少一侧不可观测"}
            )
        divergence_event_ids: set[str] = set()
        for domain, real_profiles, sim_profiles in (
            ("host", real_host, sim_host), ("device", real_device, sim_device)
        ):
            layers = sorted(
                {profile["semantic_layer"] for profile in real_profiles}
                | {profile["semantic_layer"] for profile in sim_profiles}
            )
            for layer in layers:
                layer_real = [profile for profile in real_profiles if profile["semantic_layer"] == layer]
                layer_sim = [profile for profile in sim_profiles if profile["semantic_layer"] == layer]
                lane_rows, accepted = pair_lanes(layer_real, layer_sim, pair_id, domain)
                thread_rows.extend(lane_rows)
                for real_profile, sim_profile, thread_pair_id in accepted:
                    aligned, divergence = align_lane_events(
                        real_profile, sim_profile, pair_id, thread_pair_id, domain
                    )
                    alignment_rows.extend(aligned)
                    if divergence:
                        divergence_rows.append(divergence)
                        divergence_event_ids.update(divergence["real_event_ids"])
                        divergence_event_ids.update(divergence["sim_event_ids"])
                heat_rows.extend(
                    heatmap_rows(accepted, pair_id, domain, heatmap_bins, divergence_event_ids)
                )
        for side_key in ("real", "sim"):
            link_rows.extend(build_host_device_links(events_by_side[side_key], parsed[side_key].flows))

    write_csv(output / "rank_pairs.csv", rank_pair_rows)
    write_csv(output / "unpaired_ranks.csv", unpaired_rows)
    write_csv(output / "thread_pairs.csv", thread_rows)
    write_csv(output / "canonical_events.csv", canonical_rows)
    write_csv(output / "event_alignment.csv", alignment_rows)
    write_jsonl(output / "divergence_windows.jsonl", divergence_rows)
    write_csv(output / "host_device_links.csv", link_rows)
    write_csv(output / "structural_heatmap.csv", heat_rows)
    (output / "structural_heatmap.html").write_text(structural_heatmap_html(heat_rows), encoding="utf-8")
    write_csv(output / "parser_warnings.csv", parser_warnings)
    write_csv(output / "operator_details_rank_coverage.csv", operator_coverage_rows)
    analysis_partial = bool(unpaired_rows) or any(
        row.get("status") == "partial" for row in rank_pair_rows
    )
    manifest = {
        "schema_version": SCHEMA_VERSION, "algorithm_version": ALGORITHM_VERSION,
        "status": "partial" if analysis_partial else "complete", "language": "zh-CN",
        "roles": {"real": "reference/真机", "sim": "candidate/仿真"},
        "real_root": str(real_root), "sim_root": str(sim_root),
        "real_rank_ids": sorted(real_ranks), "sim_rank_ids": sorted(sim_ranks),
        "compared_rank_ids": common,
        "unpaired_rank_ids": sorted(set(real_ranks) ^ set(sim_ranks)),
        "rank_pair_rule": "sorted intersection of exact global rank IDs; never enumerate, shift, or renumber",
        "thread_scope": "all framework_op, host_launch, and observable device_task lanes; no random sampling",
        "semantic_layers": ["framework_op", "host_launch", "device_task"],
        "operator_details_policy": "rank coverage only; never invent pid/tid/stream/lane",
        "host_device_policy": (
            "separate domains; only causal_eligible direct-id/direct-flow rows support causality; "
            "degraded containment is navigation-only; no nearest-time join"
        ),
        "timestamps_used_only_for": ["X/B/E slice validation", "within-lane ordering", "nesting", "flow endpoint containment"],
        "duration_metrics_emitted": False, "performance_conclusions_allowed": False,
        "structural_heatmap_axis": "lane-relative event ordinal",
        "counts": {"rank_pairs": len(rank_pair_rows), "thread_inventory_rows": len(thread_rows),
                   "canonical_events": len(canonical_rows), "alignment_rows": len(alignment_rows),
                   "first_divergence_windows": len(divergence_rows), "host_device_links": len(link_rows),
                   "operator_details_rank_coverage": len(operator_coverage_rows)},
        "warnings": real_warnings + sim_warnings,
        "artifacts": ["rank_pairs.csv", "unpaired_ranks.csv", "thread_pairs.csv", "canonical_events.csv",
                      "event_alignment.csv", "divergence_windows.jsonl", "host_device_links.csv",
                      "structural_heatmap.csv", "structural_heatmap.html", "parser_warnings.csv",
                      "operator_details_rank_coverage.csv", "perfetto_inputs/"],
    }
    write_json(output / "analysis_manifest.json", manifest)
    return manifest


def run_self_test() -> int:
    with tempfile.TemporaryDirectory(prefix="profiling-alignment-selftest-") as directory:
        root = Path(directory)
        real, sim, out = root / "real", root / "sim", root / "out"

        def target_for(side: Path, directory_rank: int, metadata_rank: int | None = None) -> Path:
            target = side / f"rank_{directory_rank}" / "ASCEND_PROFILER_OUTPUT"
            target.mkdir(parents=True)
            metadata = directory_rank if metadata_rank is None else metadata_rank
            (target.parent / "profiler_info.json").write_text(
                json.dumps({"global_rank": metadata, "tp_rank": metadata}), encoding="utf-8"
            )
            return target

        def write_trace(target: Path, events: list[dict[str, Any]]) -> None:
            (target / "trace_view.json").write_text(
                json.dumps({"traceEvents": events}), encoding="utf-8"
            )

        def rank0_events(repeat_calls: int, rank: int) -> list[dict[str, Any]]:
            events: list[dict[str, Any]] = [
                {"ph": "M", "name": "process_name", "pid": 10, "args": {"name": "model"}},
                {"ph": "M", "name": "thread_name", "pid": 10, "tid": 20, "args": {"name": "main"}},
                {"ph": "M", "name": "thread_name", "pid": 10, "tid": 21, "args": {"name": "launch"}},
                {"ph": "X", "cat": "cpu_op", "name": "aten::eq", "pid": 10, "tid": 20,
                 "ts": 0, "dur": 2, "args": {"Input Shapes": [[2, 2]], "Output Shapes": [[2, 2]]}},
            ]
            for call in range(repeat_calls):
                events.append(
                    {"ph": "X", "cat": "cpu_op", "name": "aten::relu", "pid": 10, "tid": 20,
                     "ts": 10 + call * 10, "dur": 2,
                     "args": {"Input Shapes": [[2, 2]], "Output Shapes": [[2, 2]]}}
                )
            events.append(
                {"ph": "X", "cat": "cpu_op", "name": "aten::tail", "pid": 10, "tid": 20,
                 "ts": 60, "dur": 2, "args": {"Input Shapes": [[2, 2]], "Output Shapes": [[2, 2]]}}
            )
            events.extend(
                [
                    {"ph": "X", "cat": "ACL", "name": "aclnnExecute", "pid": 10, "tid": 21,
                     "ts": 100, "dur": 4, "args": {"Correlation ID": 99}},
                    {"ph": "s", "cat": "HostToDevice", "name": "launch", "scope": "ascend",
                     "id": 0, "id2": {"global": 1}, "pid": 10, "tid": 21, "ts": 100},
                    {"ph": "X", "cat": "kernel", "name": "kernel_acl", "pid": 30, "tid": 40,
                     "ts": 105, "dur": 1,
                     "args": {"Stream ID": 0, "Device ID": rank, "Correlation ID": 99,
                              "Task ID": 7, "Task Type": "AI_CORE", "Accelerator Core": "AiCore"}},
                    {"ph": "f", "cat": "HostToDevice", "name": "launch", "scope": "ascend",
                     "id": 0, "id2": {"global": 1}, "pid": 30, "tid": 40, "ts": 105},
                    {"ph": "X", "cat": "Runtime", "name": "rtLaunchKernel", "pid": 10, "tid": 21,
                     "ts": 110, "dur": 4, "args": {"External ID": 99}},
                    {"ph": "s", "cat": "HostToDevice", "name": "launch", "scope": "ascend",
                     "id": 0, "id2": {"global": 2}, "pid": 10, "tid": 21, "ts": 110},
                    {"ph": "X", "cat": "kernel", "name": "kernel_runtime", "pid": 30, "tid": 40,
                     "ts": 115, "dur": 1,
                     "args": {"Stream ID": 0, "Device ID": rank, "External ID": 99,
                              "Task ID": 8, "Task Type": "AI_CORE", "Accelerator Core": "AiCore"}},
                    {"ph": "f", "cat": "HostToDevice", "name": "launch", "scope": "ascend",
                     "id": 0, "id2": {"global": 2}, "pid": 30, "tid": 40, "ts": 115},
                    {"ph": "X", "cat": "HCCL", "name": "HcclAllReduce", "pid": 10, "tid": 21,
                     "ts": 120, "dur": 2, "args": {}},
                    {"ph": "X", "cat": "", "name": "device_process_only", "pid": 31, "tid": 41,
                     "ts": 130, "dur": 1, "args": {}},
                    {"ph": "M", "name": "process_name", "pid": 31,
                     "args": {"name": "NPU 0"}},
                ]
            )
            return events

        for side, repeats in ((real, 2), (sim, 3)):
            target = target_for(side, 0)
            write_trace(target, rank0_events(repeats, 0))

        # Rank 1 has Runtime host events but no trace kernel.  The standard
        # kernel_details.csv must therefore remain eligible as device fallback.
        for side in (real, sim):
            target = target_for(side, 1)
            write_trace(
                target,
                [
                    {"ph": "M", "name": "process_name", "pid": 11, "args": {"name": "model"}},
                    {"ph": "X", "cat": "cpu_op", "name": "aten::add", "pid": 11, "tid": 22,
                     "ts": "9007199254740992.0001", "dur": "0.0001", "args": {}},
                    {"ph": "X", "cat": "Runtime", "name": "rtLaunchKernel", "pid": 11, "tid": 23,
                     "ts": "9007199254740992.0003", "dur": "0.0001", "args": {}},
                ],
            )
            with (target / "kernel_details.csv").open("w", newline="", encoding="utf-8-sig") as handle:
                writer = csv.DictWriter(
                    handle,
                    fieldnames=["Device_id", "Name", "Type", "Accelerator Core", "Start Time(us)",
                                "Duration(us)", "Stream Id", "Task Id"],
                )
                writer.writeheader()
                writer.writerows(
                    [
                        {"Device_id": 1, "Name": "kernel_late", "Type": "AI_CORE",
                         "Accelerator Core": "AiCore", "Start Time(us)": "20.000000000000000002",
                         "Duration(us)": "1", "Stream Id": 9, "Task Id": 2},
                        {"Device_id": 1, "Name": "kernel_early", "Type": "AI_CORE",
                         "Accelerator Core": "AiCore", "Start Time(us)": "10.000000000000000001",
                         "Duration(us)": "1", "Stream Id": 9, "Task Id": 1},
                        {"Device_id": 1, "Name": "kernel_without_stream", "Type": "AI_CORE",
                         "Accelerator Core": "AiCore", "Start Time(us)": "30", "Duration(us)": "1",
                         "Stream Id": "", "Task Id": 3},
                    ]
                )
            with (target / "operator_details.csv").open("w", newline="", encoding="utf-8-sig") as handle:
                writer = csv.DictWriter(handle, fieldnames=["Name", "Input Shapes", "Output Shapes"])
                writer.writeheader()
                writer.writerow({"Name": "aten::add", "Input Shapes": "[[2,2]]", "Output Shapes": "[[2,2]]"})

        # A known extra rank is reported but never shifted onto a simulator rank.
        extra = target_for(real, 2)
        write_trace(extra, [{"ph": "X", "cat": "cpu_op", "name": "aten::noop", "pid": 1,
                             "tid": 1, "ts": 0, "dur": 1, "args": {}}])

        # Directory rank 3 conflicts with authoritative metadata rank 4 and must
        # be unresolved rather than paired as either rank.
        target_for(real, 3, metadata_rank=4)

        real_map, real_unresolved, _ = rank_map(real)
        assert sorted(real_map) == [0, 1, 2]
        assert any(info.identity_status == "conflict" for info in real_unresolved)
        manifest = analyze(real, sim, out, 16)
        assert manifest["compared_rank_ids"] == [0, 1]
        assert manifest["unpaired_rank_ids"] == [2]
        assert manifest["status"] == "partial"
        assert manifest["duration_metrics_emitted"] is False
        header = (out / "canonical_events.csv").read_text(encoding="utf-8-sig").splitlines()[0].casefold()
        assert "duration" not in header and "start_us" not in header and "end_us" not in header

        canonical = list(read_csv_rows(out / "canonical_events.csv"))
        layers = {(row["raw_name"], row["domain"], row["semantic_layer"]) for row in canonical}
        assert ("aclnnExecute", "host", "host_launch") in layers
        assert ("rtLaunchKernel", "host", "host_launch") in layers
        assert ("HcclAllReduce", "host", "host_launch") in layers
        assert ("kernel_acl", "device", "device_task") in layers
        assert ("device_process_only", "device", "device_task") in layers

        fallback = [
            row for row in canonical
            if row["rank"] == "1" and row["raw_name"] in {"kernel_early", "kernel_late"}
        ]
        assert len(fallback) == 4
        for environment in {row["environment"] for row in fallback}:
            ordered = sorted(
                [row for row in fallback if row["environment"] == environment],
                key=lambda row: int(row["thread_ordinal"]),
            )
            assert [row["raw_name"] for row in ordered] == ["kernel_early", "kernel_late"]
        unresolved_kernels = [row for row in canonical if row["raw_name"] == "kernel_without_stream"]
        assert unresolved_kernels and all(not row["lane_id"] for row in unresolved_kernels)

        alignment = list(read_csv_rows(out / "event_alignment.csv"))
        repeat_rows = [row for row in alignment if row["relation"] == "run_calls_mismatch"]
        assert repeat_rows
        assert {(row["real_run_calls"], row["sim_run_calls"]) for row in repeat_rows} >= {("2", "3")}

        links = list(read_csv_rows(out / "host_device_links.csv"))
        flow_links = [row for row in links if row["correlation_type"] == "chrome-flow"]
        assert len(flow_links) >= 4
        assert all(row["link_status"] == "direct-flow" for row in flow_links)
        assert all(row["causal_eligible"] == "是" for row in flow_links)
        id_links = [row for row in links if row["correlation_type"] == "event-id"]
        assert {row["correlation_namespace"] for row in id_links} >= {"correlation_id", "external_id"}
        namespace_hashes = {
            row["correlation_namespace"]: row["correlation_id_hash"] for row in id_links
        }
        assert namespace_hashes["correlation_id"] != namespace_hashes["external_id"]

        unpaired = list(read_csv_rows(out / "unpaired_ranks.csv"))
        assert any(row.get("identity_status") == "conflict" for row in unpaired)
        coverage = list(read_csv_rows(out / "operator_details_rank_coverage.csv"))
        assert coverage and all(row["coverage_scope"] == "rank-only" for row in coverage)
        assert all("lane_id" not in row and "tid" not in row for row in coverage)
        divergence = [
            json.loads(line)
            for line in (out / "divergence_windows.jsonl").read_text(encoding="utf-8").splitlines()
            if line.strip()
        ]
        assert divergence and all("lane_match_status" in row for row in divergence)
        assert all("anchors_before" in row and "anchors_after" in row for row in divergence)
        for side in ("real", "sim"):
            lane_payload = json.loads(
                (out / "perfetto_inputs" / "rank-0000" / f"{side}_host_lanes.json").read_text(
                    encoding="utf-8"
                )
            )
            keys = [(str(row["pid"]), str(row["tid"])) for row in lane_payload["lanes"]]
            assert len(keys) == len(set(keys))
    print("self-test: ok")
    return 0


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--real", type=Path, help="显式标注的真机/reference Profiling 根目录")
    parser.add_argument("--sim", type=Path, help="显式标注的仿真/candidate Profiling 根目录")
    parser.add_argument("--output", type=Path, help="位于两侧原始目录之外的输出目录")
    parser.add_argument("--heatmap-bins", type=int, default=64, help="算子序位热力图列数，默认 64；不是时间桶")
    parser.add_argument("--self-test", action="store_true", help="运行内置合成回归")
    return parser


def main(argv: list[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    if args.self_test:
        return run_self_test()
    if not args.real or not args.sim or not args.output:
        raise SystemExit("--real、--sim 和 --output 均为必需参数")
    if args.heatmap_bins < 4 or args.heatmap_bins > 512:
        raise SystemExit("--heatmap-bins 必须在 4..512")
    manifest = analyze(args.real, args.sim, args.output, args.heatmap_bins)
    print(json.dumps(manifest, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

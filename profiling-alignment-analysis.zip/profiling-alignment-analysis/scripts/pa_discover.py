#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""pa_discover.py -- inventory a real-device and a simulated profiling directory.

    python pa_discover.py --real <dir> --sim <dir> [--out inventory.json]

Prints one table per side (rank -> trace_view.json / kernel_details.csv / ...),
the rank sets on both sides, and the intersection you can actually compare.

Why this runs first: half of "the operators do not line up" reports are really
"the two runs were not launched the same way" -- different world size, different
profiler level, different steps captured. Those show up here, before any
expensive trace parsing, and they change what the divergence means.
"""
from __future__ import annotations

import argparse
import json
import os
import re
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from pa_common import force_utf8, write_json  # noqa: E402

RANK_FROM_INFO = re.compile(r"profiler_info_(\d+)\.json$", re.I)
RANK_FROM_DB = re.compile(r"ascend_pytorch_profiler_(\d+)\.db$", re.I)
RANK_FROM_DIR = re.compile(r"(?:^|[_/\\])rank[_-]?(\d+)(?:$|[_/\\])", re.I)
RANK_FROM_MS = re.compile(r"ascend_timeline_display_(\d+)\.json$", re.I)

INTERESTING = [
    "trace_view.json", "kernel_details.csv", "operator_details.csv",
    "op_statistic.csv", "step_trace_time.csv", "communication.json",
    "communication_matrix.json", "profiler_metadata.json", "api_statistic.csv",
    "memory_record.csv", "operator_memory.csv",
]


def _find_run_dirs(root):
    """A 'run dir' is anything that owns an ASCEND_PROFILER_OUTPUT (or MindSpore profiler/)."""
    runs = []
    for dirpath, dirnames, filenames in os.walk(root):
        base = os.path.basename(dirpath)
        if base.upper() == "ASCEND_PROFILER_OUTPUT":
            runs.append((os.path.dirname(dirpath), dirpath))
            dirnames[:] = []
            continue
        if base.lower() == "profiler" and any(RANK_FROM_MS.search(f) for f in filenames):
            runs.append((os.path.dirname(dirpath), dirpath))
            dirnames[:] = []
            continue
        # a bare output dir handed to us directly
        if "trace_view.json" in filenames and not runs:
            runs.append((dirpath, dirpath))
    return runs


def _rank_of(run_dir, out_dir):
    for name in os.listdir(run_dir):
        m = RANK_FROM_INFO.search(name)
        if m:
            return int(m.group(1)), "profiler_info_%s.json" % m.group(1)
    if os.path.isdir(out_dir):
        for name in os.listdir(out_dir):
            for pat, why in ((RANK_FROM_DB, "db name"), (RANK_FROM_MS, "timeline name")):
                m = pat.search(name)
                if m:
                    return int(m.group(1)), why
    m = RANK_FROM_DIR.search(run_dir.replace("\\", "/"))
    if m:
        return int(m.group(1)), "directory name"
    return None, "unknown"


def _read_info(run_dir):
    info = {}
    for name in os.listdir(run_dir):
        if RANK_FROM_INFO.search(name):
            try:
                with open(os.path.join(run_dir, name), "r", encoding="utf-8") as fh:
                    info["profiler_info"] = json.load(fh)
            except Exception as exc:
                info["profiler_info_error"] = str(exc)
    meta = os.path.join(run_dir, "ASCEND_PROFILER_OUTPUT", "profiler_metadata.json")
    if os.path.isfile(meta):
        try:
            with open(meta, "r", encoding="utf-8") as fh:
                info["metadata"] = json.load(fh)
        except Exception as exc:
            info["metadata_error"] = str(exc)
    return info


def scan(root, side):
    root = os.path.abspath(root)
    if not os.path.isdir(root):
        raise SystemExit("%s side: not a directory: %s" % (side, root))
    runs = []
    for run_dir, out_dir in _find_run_dirs(root):
        rank, how = _rank_of(run_dir, out_dir)
        files = {}
        for f in INTERESTING:
            p = os.path.join(out_dir, f)
            if os.path.isfile(p):
                files[f] = {"path": p, "mb": round(os.path.getsize(p) / 1e6, 2)}
        runs.append({
            "side": side, "rank": rank, "rank_source": how,
            "run_dir": run_dir, "output_dir": out_dir,
            "files": files, "info": _read_info(run_dir),
        })
    runs.sort(key=lambda r: (r["rank"] is None, r["rank"] or 0))
    return runs


def _fmt_table(runs):
    lines = ["| rank | trace_view.json (MB) | kernel_details.csv | dir |",
             "| --- | --- | --- | --- |"]
    for r in runs:
        tv = r["files"].get("trace_view.json")
        kd = r["files"].get("kernel_details.csv")
        lines.append("| %s | %s | %s | %s |" % (
            r["rank"] if r["rank"] is not None else "?",
            ("%.1f" % tv["mb"]) if tv else "MISSING",
            "yes" if kd else "-",
            os.path.basename(r["run_dir"]) or r["run_dir"],
        ))
    return "\n".join(lines)


def _cfg_of(run):
    info = (run.get("info") or {}).get("profiler_info") or {}
    cfg = info.get("config", info)
    flat = {}
    def walk(prefix, obj):
        if isinstance(obj, dict):
            for k, v in obj.items():
                walk("%s.%s" % (prefix, k) if prefix else str(k), v)
        else:
            flat[prefix] = obj
    walk("", cfg)
    return flat


def main():
    force_utf8()
    ap = argparse.ArgumentParser(description=__doc__,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--real", required=True, help="real-device profiling root")
    ap.add_argument("--sim", required=True, help="simulated profiling root")
    ap.add_argument("--out", default="", help="write inventory json here")
    args = ap.parse_args()

    real = scan(args.real, "real")
    sim = scan(args.sim, "sim")

    print("# Profiling inventory\n")
    print("## real (%s)\n" % args.real)
    print(_fmt_table(real) if real else "(no profiling run found)")
    print("\n## sim (%s)\n" % args.sim)
    print(_fmt_table(sim) if sim else "(no profiling run found)")

    rr = sorted(r["rank"] for r in real if r["rank"] is not None)
    sr = sorted(r["rank"] for r in sim if r["rank"] is not None)
    common = sorted(set(rr) & set(sr))
    print("\n## ranks\n")
    print("- real: %s" % (rr or "unknown"))
    print("- sim : %s" % (sr or "unknown"))
    print("- comparable: %s" % (common or "none -- pass --rank explicitly"))
    if rr and sr and len(rr) != len(sr):
        print("\n> WARNING: world size differs (%d vs %d). Rank N does not necessarily "
              "play the same role on both sides: with different TP/PP/DP/EP sizes the "
              "same rank can hold a different pipeline stage or different experts, and "
              "then a large operator difference is EXPECTED, not a simulation bug. "
              "Confirm the parallel config (pa_shargs.py on both launch scripts) before "
              "reading any divergence as a control-flow problem."
              % (len(rr), len(sr)))

    if real and sim:
        a, b = _cfg_of(real[0]), _cfg_of(sim[0])
        diff = [(k, a.get(k), b.get(k)) for k in sorted(set(a) | set(b)) if a.get(k) != b.get(k)]
        print("\n## profiler config diff (real vs sim, rank %s / %s)\n"
              % (real[0]["rank"], sim[0]["rank"]))
        if diff:
            print("| key | real | sim |")
            print("| --- | --- | --- |")
            for k, va, vb in diff[:40]:
                print("| %s | %s | %s |" % (k, va, vb))
            print("\n> A different `profiler_level`/`activities`/`with_stack` setting changes "
                  "which events exist at all -- rule that out before calling anything a divergence.")
        else:
            print("(identical)")

    inv = {"real": real, "sim": sim, "common_ranks": common}
    if args.out:
        write_json(args.out, inv)
        print("\nwrote %s" % args.out)


if __name__ == "__main__":
    main()

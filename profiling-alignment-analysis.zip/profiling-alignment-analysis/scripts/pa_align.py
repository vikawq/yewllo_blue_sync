#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""pa_align.py -- align the operator sequences of a real-device trace and a
simulated trace, thread by thread, and report where they stop matching.

    python pa_align.py --real REAL/trace_view.json --sim SIM/trace_view.json \\
        --outdir out/rank0 [--step 2] [--side both] [--name-mode medium]

What it compares
----------------
Operator *order*, not time. Simulated timestamps are modelled, so wall clock is
meaningless here; what carries signal is the sequence of ops each thread issues.
Two runs of the same control flow emit the same sequence even if every duration
differs, so any structural difference is a real behavioural difference.

Alignment is a patience diff (anchor on ops that appear exactly once on both
sides, then diff between anchors). That keeps a single inserted block from
shifting everything after it and drowning the report in false differences.

Outputs
-------
  <outdir>/alignment.json   machine-readable: per track-pair opcodes, first
                            divergence (with event uids for pa_evidence.py),
                            op-count histogram delta, shape mismatches
  <outdir>/alignment.md     the same thing for a human / for the report
"""
from __future__ import annotations

import argparse
import difflib
import os
import sys
from collections import Counter, defaultdict

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from pa_common import (force_utf8, load_trace, normalize_name, shape_of, dtype_of,  # noqa: E402
                       find_steps, write_json, categorize)

# --------------------------------------------------------------------------
# sequence extraction
# --------------------------------------------------------------------------


def track_sequence(track, name_mode, t_start=None, t_end=None, limit=0):
    evs = track.events
    if t_start is not None:
        evs = [e for e in evs if t_start <= e["ts"] < t_end]
    if limit and len(evs) > limit:
        evs = evs[:limit]
    seq = [normalize_name(e["name"], name_mode) for e in evs]
    return evs, seq


# --------------------------------------------------------------------------
# track pairing
# --------------------------------------------------------------------------


def _histogram(seq):
    c = Counter(seq)
    total = sum(c.values()) or 1
    return {k: v / total for k, v in c.items()}


def _similarity(h1, h2):
    keys = set(h1) & set(h2)
    return sum(min(h1[k], h2[k]) for k in keys)      # histogram intersection, 0..1


def pair_tracks(real_tracks, sim_tracks, seqs_r, seqs_s, manual=None):
    """Pair real/sim tracks: identical thread name first, then best histogram match.

    Thread ids and stream ids are assigned per run, so they cannot be trusted to
    mean the same thing on both sides. Op-mix similarity is the honest fallback,
    and the chosen pairing is always printed so a wrong guess is visible rather
    than silently poisoning the diff.
    """
    pairs, reason = [], {}
    used_s = set()
    if manual:
        for r_label, s_label in manual:
            rt = next((t for t in real_tracks if t.label == r_label), None)
            st = next((t for t in sim_tracks if t.label == s_label), None)
            if rt and st:
                pairs.append((rt, st))
                used_s.add(st.label)
                reason[rt.label] = "manual"
    for rt in real_tracks:
        if any(rt is p[0] for p in pairs):
            continue
        cand = [st for st in sim_tracks if st.label not in used_s and st.kind == rt.kind]
        if not cand:
            continue
        exact = [st for st in cand if st.thread == rt.thread]
        if len(exact) == 1:
            st = exact[0]
            pairs.append((rt, st))
            used_s.add(st.label)
            reason[rt.label] = "same thread name %r" % rt.thread
            continue
        hr = _histogram(seqs_r[rt.label])
        best, score = None, -1.0
        for st in cand:
            s = _similarity(hr, _histogram(seqs_s[st.label]))
            if s > score:
                best, score = st, s
        if best is not None:
            pairs.append((rt, best))
            used_s.add(best.label)
            reason[rt.label] = "op-mix similarity %.2f" % score
    unmatched_s = [st for st in sim_tracks if st.label not in used_s]
    return pairs, reason, unmatched_s


# --------------------------------------------------------------------------
# patience diff
# --------------------------------------------------------------------------


def _anchors(a, b):
    ca, cb = Counter(a), Counter(b)
    uniq = {x for x, n in ca.items() if n == 1 and cb.get(x) == 1}
    if not uniq:
        return []
    posb = {x: i for i, x in enumerate(b) if x in uniq}
    cand = [(i, posb[x]) for i, x in enumerate(a) if x in uniq]
    # longest increasing subsequence on the b-index
    piles, backptr, tails = [], [], []
    import bisect as _bisect
    for idx, (ia, ib) in enumerate(cand):
        p = _bisect.bisect_left(tails, ib)
        if p == len(tails):
            tails.append(ib)
            piles.append(idx)
        else:
            tails[p] = ib
            piles[p] = idx
        backptr.append(piles[p - 1] if p > 0 else -1)
    out, k = [], (piles[-1] if piles else -1)
    while k >= 0:
        out.append(cand[k])
        k = backptr[k]
    return list(reversed(out))


def _opcodes(a, b, max_segment):
    """Global opcode list [(tag, i1, i2, j1, j2)] using anchors + local diffs."""
    anchors = _anchors(a, b)
    segments, ai, bi = [], 0, 0
    for ia, ib in anchors:
        segments.append((ai, ia, bi, ib))
        segments.append((ia, ia + 1, ib, ib + 1))     # the anchor itself: equal
        ai, bi = ia + 1, ib + 1
    segments.append((ai, len(a), bi, len(b)))

    ops = []
    for si, (i1, i2, j1, j2) in enumerate(segments):
        is_anchor = (si % 2 == 1) and si < len(segments) - 1
        if is_anchor:
            ops.append(("equal", i1, i2, j1, j2))
            continue
        if i1 == i2 and j1 == j2:
            continue
        if i1 == i2:
            ops.append(("insert", i1, i2, j1, j2))
            continue
        if j1 == j2:
            ops.append(("delete", i1, i2, j1, j2))
            continue
        if (i2 - i1) > max_segment or (j2 - j1) > max_segment:
            ops.append(("replace", i1, i2, j1, j2))
            continue
        sm = difflib.SequenceMatcher(None, a[i1:i2], b[j1:j2], autojunk=False)
        for tag, x1, x2, y1, y2 in sm.get_opcodes():
            ops.append((tag, i1 + x1, i1 + x2, j1 + y1, j1 + y2))
    # merge adjacent equal runs
    merged = []
    for op in ops:
        if merged and op[0] == "equal" and merged[-1][0] == "equal" \
                and merged[-1][2] == op[1] and merged[-1][4] == op[3]:
            t, i1, _, j1, _ = merged[-1]
            merged[-1] = (t, i1, op[2], j1, op[4])
        else:
            merged.append(op)
    return merged


# --------------------------------------------------------------------------
# per-pair analysis
# --------------------------------------------------------------------------


def analyse_pair(rt, st, ev_r, seq_r, ev_s, seq_s, ctx=8, max_show=12, max_segment=8000):
    ops = _opcodes(seq_r, seq_s, max_segment)
    res = {
        "track": {"real": rt.label, "sim": st.label, "kind": rt.kind, "side": rt.side},
        "counts": {"real": len(seq_r), "sim": len(seq_s)},
        "identical": all(o[0] == "equal" for o in ops),
        "matched_ops": sum(o[2] - o[1] for o in ops if o[0] == "equal"),
        "first_divergence": None,
        "blocks": [],
        "histogram_delta": [],
        "shape_mismatches": [],
    }

    def ev_desc(evs, idx):
        e = evs[idx]
        return {"i": idx, "name": e["name"], "norm": normalize_name(e["name"]),
                "cat": categorize(e["name"]), "ts": e["ts"], "dur": e["dur"],
                "uid": e["uid"], "shape": shape_of(e), "dtype": dtype_of(e)}

    for tag, i1, i2, j1, j2 in ops:
        if tag == "equal":
            continue
        blk = {
            "tag": tag, "real_range": [i1, i2], "sim_range": [j1, j2],
            "real_len": i2 - i1, "sim_len": j2 - j1,
            "real_ops": [ev_desc(ev_r, i) for i in range(i1, min(i2, i1 + max_show))],
            "sim_ops": [ev_desc(ev_s, j) for j in range(j1, min(j2, j1 + max_show))],
        }
        res["blocks"].append(blk)
        if res["first_divergence"] is None:
            res["first_divergence"] = {
                "tag": tag,
                "real_index": i1, "sim_index": j1,
                "position_pct": round(100.0 * i1 / max(1, len(seq_r)), 2),
                "last_common": [ev_desc(ev_r, i) for i in range(max(0, i1 - ctx), i1)],
                "real_ops": blk["real_ops"], "sim_ops": blk["sim_ops"],
            }
    res["blocks"].sort(key=lambda b: -(b["real_len"] + b["sim_len"]))
    res["blocks"] = res["blocks"][:30]

    cr, cs = Counter(seq_r), Counter(seq_s)
    delta = []
    for name in set(cr) | set(cs):
        d = cs.get(name, 0) - cr.get(name, 0)
        if d:
            delta.append({"op": name, "real": cr.get(name, 0), "sim": cs.get(name, 0),
                          "delta": d, "cat": categorize(name)})
    delta.sort(key=lambda x: -abs(x["delta"]))
    res["histogram_delta"] = delta[:40]

    # Same op name at the same aligned position but a different input shape means
    # the control flow matched while the *data* did not -- that is the tensor-level
    # symptom of a simulation value error and often precedes the branch flip.
    for tag, i1, i2, j1, j2 in ops:
        if tag != "equal":
            continue
        for k in range(i2 - i1):
            a, b = ev_r[i1 + k], ev_s[j1 + k]
            sa, sb = shape_of(a), shape_of(b)
            if sa and sb and sa != sb:
                res["shape_mismatches"].append({
                    "real_index": i1 + k, "sim_index": j1 + k, "op": a["name"],
                    "real_shape": sa, "sim_shape": sb,
                    "real_uid": a["uid"], "sim_uid": b["uid"],
                })
            if len(res["shape_mismatches"]) >= 200:
                break
    return res


# --------------------------------------------------------------------------
# reporting
# --------------------------------------------------------------------------


def _ops_line(ops):
    return " -> ".join("%s%s" % (o["norm"], ("[%s]" % o["shape"]) if o["shape"] else "")
                       for o in ops) or "(none)"


def to_markdown(meta, results, track_tables, warnings):
    L = ["# 算子序列对齐 (real vs sim)", ""]
    L.append("- real trace: `%s`" % meta["real"])
    L.append("- sim  trace: `%s`" % meta["sim"])
    L.append("- rank: %s    step window: %s" % (meta.get("rank", "?"), meta.get("step", "all")))
    L.append("- 名称归一化: %s" % meta["name_mode"])
    if warnings:
        L.append("")
        for w in warnings:
            L.append("> WARNING: %s" % w)
    L.append("")
    L.append("## 1. Track 分类与配对")
    L.append("")
    L.append("| side | kind | real track | sim track | real ops | sim ops | 配对依据 |")
    L.append("| --- | --- | --- | --- | --- | --- | --- |")
    for row in track_tables:
        L.append("| %s | %s | %s | %s | %d | %d | %s |" % (
            row["side"], row["kind"], row["real"], row["sim"],
            row["real_ops"], row["sim_ops"], row["reason"]))
    L.append("")
    L.append("## 2. 首个分歧点（按 host 优先、位置由早到晚）")
    L.append("")
    # framework first: it is the layer closest to the model source, so its first
    # divergence is the one you can actually take to a line of code.
    kind_order = {"framework": 0, "cann": 1, "device": 2, "device_comm": 3}
    ranked = sorted([r for r in results if r["first_divergence"]],
                    key=lambda r: (kind_order.get(r["track"]["kind"], 9),
                                   r["first_divergence"]["position_pct"]))
    if not ranked:
        L.append("**两侧所有 track 的算子序列完全一致**（在当前 step 窗口与归一化模式下）。")
        L.append("若热力图仍看起来不同，说明差异只在耗时/并发排布，不在控制流；")
        L.append("换 `--name-mode raw` 或去掉 `--step` 再确认一次。")
    for r in ranked:
        fd = r["first_divergence"]
        L.append("### [%s/%s] %s  ↔  %s" % (r["track"]["side"], r["track"]["kind"],
                                            r["track"]["real"], r["track"]["sim"]))
        L.append("")
        L.append("- 算子数: real=%d, sim=%d, 对齐上的=%d" % (
            r["counts"]["real"], r["counts"]["sim"], r["matched_ops"]))
        L.append("- 首个分歧: `%s` @ real#%d / sim#%d (序列 %.1f%% 处)" % (
            fd["tag"], fd["real_index"], fd["sim_index"], fd["position_pct"]))
        L.append("- 最后共同算子: %s" % _ops_line(fd["last_common"]))
        L.append("- real 侧: %s" % _ops_line(fd["real_ops"]))
        L.append("- sim  侧: %s" % _ops_line(fd["sim_ops"]))
        L.append("- 定位用 uid: real=%s sim=%s，最后共同算子 real uid=%s"
                 "（喂给 pa_evidence.py --uid，注意 --trace 用哪一侧就传哪一侧的 uid）" % (
                     fd["real_ops"][0]["uid"] if fd["real_ops"] else "-",
                     fd["sim_ops"][0]["uid"] if fd["sim_ops"] else "-",
                     fd["last_common"][-1]["uid"] if fd["last_common"] else "-"))
        L.append("")
    L.append("## 3. 算子数量差异（sim - real）")
    L.append("")
    for r in results:
        if not r["histogram_delta"]:
            continue
        L.append("### %s" % r["track"]["real"])
        L.append("")
        L.append("| op | cat | real | sim | delta |")
        L.append("| --- | --- | --- | --- | --- |")
        for d in r["histogram_delta"][:20]:
            L.append("| %s | %s | %d | %d | %+d |" % (d["op"], d["cat"], d["real"], d["sim"], d["delta"]))
        L.append("")
    L.append("## 4. 同名算子的 shape 不一致（tensor 级线索）")
    L.append("")
    any_shape = False
    for r in results:
        if not r["shape_mismatches"]:
            continue
        any_shape = True
        L.append("### %s" % r["track"]["real"])
        L.append("")
        L.append("| # | op | real shape | sim shape |")
        L.append("| --- | --- | --- | --- |")
        for s in r["shape_mismatches"][:25]:
            L.append("| %d | %s | %s | %s |" % (s["real_index"], s["op"], s["real_shape"], s["sim_shape"]))
        L.append("")
    if not any_shape:
        L.append("(未发现 shape 不一致，或该 trace 未采集 Input Dims —— "
                 "需要 `torch_npu.profiler` 打开 `record_shapes=True`)")
        L.append("")
    L.append("## 5. 最大的分歧块")
    L.append("")
    for r in results:
        if not r["blocks"]:
            continue
        L.append("### %s" % r["track"]["real"])
        L.append("")
        for b in r["blocks"][:6]:
            L.append("- `%s` real[%d:%d] (%d) vs sim[%d:%d] (%d)" % (
                b["tag"], b["real_range"][0], b["real_range"][1], b["real_len"],
                b["sim_range"][0], b["sim_range"][1], b["sim_len"]))
            L.append("  - real: %s" % _ops_line(b["real_ops"]))
            L.append("  - sim : %s" % _ops_line(b["sim_ops"]))
        L.append("")
    return "\n".join(L)


# --------------------------------------------------------------------------


def _pick_step(trace, step_arg, label):
    steps = find_steps(trace)
    if not steps:
        return None, None, "%s: 没有 ProfilerStep 标记，按整段 trace 对比" % label
    if step_arg is None:
        return None, None, "%s: 发现 %d 个 step（%s），未指定 --step，按整段对比" % (
            label, len(steps), ", ".join(s[0] for s in steps[:6]))
    idx = step_arg if step_arg >= 0 else len(steps) + step_arg
    if not (0 <= idx < len(steps)):
        raise SystemExit("%s: --step %d 越界，只有 %d 个 step" % (label, step_arg, len(steps)))
    name, a, b = steps[idx]
    return a, b, "%s: 取第 %d 个 step (%s)" % (label, idx, name)


def main():
    force_utf8()
    ap = argparse.ArgumentParser(description=__doc__,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--real", required=True)
    ap.add_argument("--sim", required=True)
    ap.add_argument("--outdir", default="alignment_out")
    ap.add_argument("--rank", default="?")
    ap.add_argument("--side", default="both", choices=["host", "device", "both"])
    ap.add_argument("--name-mode", default="medium", choices=["raw", "medium", "aggressive"])
    ap.add_argument("--step", type=int, default=None,
                    help="compare only the Nth ProfilerStep (negative counts from the end); "
                         "recommended: pick a steady-state step, not step 0")
    ap.add_argument("--real-step", type=int, default=None)
    ap.add_argument("--sim-step", type=int, default=None)
    ap.add_argument("--min-events", type=int, default=20,
                    help="ignore tracks with fewer events than this")
    ap.add_argument("--limit-events", type=int, default=300000)
    ap.add_argument("--max-segment", type=int, default=8000)
    ap.add_argument("--pair", action="append", default=[],
                    help='force a pairing: --pair "REAL LABEL==SIM LABEL"')
    args = ap.parse_args()

    warnings = []
    print("loading %s ..." % args.real, file=sys.stderr)
    tr = load_trace(args.real)
    print("loading %s ..." % args.sim, file=sys.stderr)
    ts_ = load_trace(args.sim)
    warnings.extend(tr.warnings + ts_.warnings)

    rs, ra, msg_r = _pick_step(tr, args.real_step if args.real_step is not None else args.step, "real")
    ss, sa, msg_s = _pick_step(ts_, args.sim_step if args.sim_step is not None else args.step, "sim")
    print(msg_r, file=sys.stderr)
    print(msg_s, file=sys.stderr)
    warnings.extend([msg_r, msg_s])

    sides = ["host", "device"] if args.side == "both" else [args.side]
    real_tracks = [t for s in sides for t in tr.tracks_by_side(s) if len(t.events) >= args.min_events]
    sim_tracks = [t for s in sides for t in ts_.tracks_by_side(s) if len(t.events) >= args.min_events]
    if not real_tracks or not sim_tracks:
        print("\n[track classification] real:", file=sys.stderr)
        for row in tr.summary()[:20]:
            print("   ", row, file=sys.stderr)
        print("[track classification] sim:", file=sys.stderr)
        for row in ts_.summary()[:20]:
            print("   ", row, file=sys.stderr)
        raise SystemExit("no comparable tracks; check the classification dump above "
                         "and re-run with --side host|device")

    ev_r, seq_r_map, ev_s, seq_s_map = {}, {}, {}, {}
    for t in real_tracks:
        e, s = track_sequence(t, args.name_mode, rs, ra, args.limit_events)
        ev_r[t.label], seq_r_map[t.label] = e, s
    for t in sim_tracks:
        e, s = track_sequence(t, args.name_mode, ss, sa, args.limit_events)
        ev_s[t.label], seq_s_map[t.label] = e, s

    manual = []
    for p in args.pair:
        if "==" in p:
            a, b = p.split("==", 1)
            manual.append((a.strip(), b.strip()))
    pairs, reason, unmatched = pair_tracks(real_tracks, sim_tracks, seq_r_map, seq_s_map, manual)

    results, table = [], []
    for rt, st in pairs:
        if not seq_r_map[rt.label] or not seq_s_map[st.label]:
            continue
        res = analyse_pair(rt, st, ev_r[rt.label], seq_r_map[rt.label],
                           ev_s[st.label], seq_s_map[st.label], max_segment=args.max_segment)
        results.append(res)
        table.append({"side": rt.side, "kind": rt.kind, "real": rt.label, "sim": st.label,
                      "real_ops": len(seq_r_map[rt.label]), "sim_ops": len(seq_s_map[st.label]),
                      "reason": reason.get(rt.label, "")})
    for st in unmatched:
        warnings.append("sim track %r 未找到对应的真机 track（可能是仿真独有的线程）" % st.label)

    meta = {"real": args.real, "sim": args.sim, "rank": args.rank, "name_mode": args.name_mode,
            "step": args.step, "sides": sides}
    os.makedirs(args.outdir, exist_ok=True)
    write_json(os.path.join(args.outdir, "alignment.json"),
               {"meta": meta, "tracks": table, "results": results, "warnings": warnings,
                "real_track_summary": tr.summary(), "sim_track_summary": ts_.summary()})
    md = to_markdown(meta, results, table, warnings)
    with open(os.path.join(args.outdir, "alignment.md"), "w", encoding="utf-8") as fh:
        fh.write(md)
    print(md)
    print("\nwrote %s" % os.path.join(args.outdir, "alignment.json"), file=sys.stderr)


if __name__ == "__main__":
    main()

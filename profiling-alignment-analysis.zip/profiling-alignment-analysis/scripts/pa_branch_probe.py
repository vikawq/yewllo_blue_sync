#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""pa_branch_probe.py -- record which way every `if` went, so real vs sim can be
diffed at the level of source lines instead of guessed at from operator names.

Run the model with the probe wrapped around the entry script
------------------------------------------------------------
    # in the launch .sh, replace `python pretrain_gpt.py ...`
    #                       with `python -m pa_branch_probe pretrain_gpt.py ...`
    # (torchrun works the same: `torchrun ... -m pa_branch_probe pretrain_gpt.py ...`)

    export PYTHONPATH=<skill>/scripts:$PYTHONPATH
    export PA_PROBE_OUT=/tmp/branch_real            # rank suffix is appended
    export PA_PROBE_INCLUDE=/path/MindSpeed-LLM,/path/Megatron-LM/megatron/core/transformer
    export PA_PROBE_MAX_ITERS=3                     # stop tracing after N marker calls

Then diff the two runs
----------------------
    python pa_branch_probe.py --diff /tmp/branch_real.rank0.log /tmp/branch_sim.rank0.log

What it records
---------------
Only *decision edges*: lines whose bytecode contains a conditional jump, paired
with the line that actually ran next. `foo.py:412>413` and `foo.py:412>418` are
the two outcomes of the same `if`, so a diff of these logs names the exact
branch that flipped, in order, with no interpretation needed. Tracing is limited
to the files you list, because tracing everything is both slow and unreadable.

Cost: roughly 2-10x slower inside the included files. Keep the include list
narrow and the run short (a few iterations is plenty -- divergence shows up in
the first steps).
"""
from __future__ import annotations

import argparse
import atexit
import dis
import os
import sys
import threading

_state = {
    "out": None, "fh": None, "include": [], "exclude": [],
    "branch_lines": {}, "last": {}, "count": 0, "max_events": 2000000,
    "markers": set(), "iters": 0, "max_iters": 0, "enabled": False,
}


def _branch_lines_for(code):
    """Line numbers in `code` whose bytecode can jump conditionally."""
    key = (code.co_filename, code.co_firstlineno, code.co_name)
    cached = _state["branch_lines"].get(key)
    if cached is not None:
        return cached
    lines = set()
    try:
        cur = code.co_firstlineno
        for ins in dis.get_instructions(code):
            # 3.13 moved the line number to `line_number`; on <=3.12 `starts_line` holds it
            ln = getattr(ins, "line_number", None)
            if ln is None and not isinstance(getattr(ins, "starts_line", None), bool):
                ln = ins.starts_line
            if ln:
                cur = ln
            name = ins.opname
            if name.startswith(("POP_JUMP", "JUMP_IF", "FOR_ITER")) or name in (
                    "SETUP_FINALLY", "MATCH_CLASS", "SEND"):
                lines.add(cur)
    except Exception:
        pass
    _state["branch_lines"][key] = lines
    return lines


def _included(filename):
    f = filename.replace("\\", "/").lower()
    if not f.endswith(".py"):
        return False
    for e in _state["exclude"]:
        if e in f:
            return False
    if not _state["include"]:
        return False
    return any(i in f for i in _state["include"])


def _emit(text):
    fh = _state["fh"]
    if fh is None:
        return
    _state["count"] += 1
    if _state["count"] > _state["max_events"]:
        return
    fh.write(text)


def _local_trace(frame, event, arg):
    if event != "line":
        return _local_trace
    code = frame.f_code
    fn = code.co_filename
    branches = _branch_lines_for(code)
    key = id(frame)
    prev = _state["last"].get(key)
    if prev is not None and prev in branches:
        _emit("%s:%d>%d\n" % (_short(fn), prev, frame.f_lineno))
    _state["last"][key] = frame.f_lineno
    return _local_trace


def _short(path):
    p = path.replace("\\", "/")
    for root in _state["include"]:
        i = p.lower().find(root)
        if i >= 0:
            return p[i:]
    return os.path.basename(p)


def _global_trace(frame, event, arg):
    if event != "call":
        return None
    code = frame.f_code
    if code.co_name in _state["markers"]:
        _state["iters"] += 1
        _emit("### marker %s #%d\n" % (code.co_name, _state["iters"]))
        if _state["max_iters"] and _state["iters"] > _state["max_iters"]:
            uninstall()
            return None
    if not _included(code.co_filename):
        return None
    return _local_trace


def install(out=None, include=None, exclude=None, markers=None, max_iters=0):
    out = out or os.environ.get("PA_PROBE_OUT", "pa_branch")
    include = include or os.environ.get("PA_PROBE_INCLUDE", "")
    exclude = exclude or os.environ.get("PA_PROBE_EXCLUDE", "site-packages/torch/,/dist-packages/torch/")
    markers = markers or os.environ.get("PA_PROBE_MARKERS", "train_step,forward_step,forward_backward_func")
    max_iters = int(max_iters or os.environ.get("PA_PROBE_MAX_ITERS", "0"))

    inc = [s.strip().replace("\\", "/").lower() for s in str(include).split(",") if s.strip()]
    if not inc:
        sys.stderr.write("[pa_branch_probe] PA_PROBE_INCLUDE is empty; nothing will be traced. "
                         "Point it at the model source dirs you suspect.\n")
    rank = os.environ.get("RANK") or os.environ.get("LOCAL_RANK") or "0"
    path = "%s.rank%s.log" % (out, rank)
    _state.update({
        "out": path, "fh": open(path, "w", encoding="utf-8", buffering=1 << 20),
        "include": inc,
        "exclude": [s.strip().replace("\\", "/").lower() for s in str(exclude).split(",") if s.strip()],
        "markers": set(s.strip() for s in str(markers).split(",") if s.strip()),
        "max_iters": max_iters, "enabled": True,
    })
    sys.stderr.write("[pa_branch_probe] tracing %s -> %s\n" % (inc, path))
    threading.settrace(_global_trace)
    sys.settrace(_global_trace)
    atexit.register(uninstall)


def uninstall():
    if not _state["enabled"]:
        return
    _state["enabled"] = False
    sys.settrace(None)
    threading.settrace(None)
    fh = _state["fh"]
    if fh:
        fh.flush()
        fh.close()
        _state["fh"] = None
    sys.stderr.write("[pa_branch_probe] wrote %d decision edges to %s\n"
                     % (_state["count"], _state["out"]))


# --------------------------------------------------------------------------
# diff mode
# --------------------------------------------------------------------------


def _read(path):
    with open(path, "r", encoding="utf-8", errors="replace") as fh:
        return [ln.rstrip("\n") for ln in fh if ln.strip()]


def diff_logs(a_path, b_path, context=6, max_report=15):
    import difflib
    from collections import Counter
    for stream in (sys.stdout, sys.stderr):
        try:
            stream.reconfigure(encoding="utf-8")
        except Exception:
            pass
    a, b = _read(a_path), _read(b_path)
    print("# 分支决策 diff\n")
    print("- A (real): `%s`  %d edges" % (a_path, len(a)))
    print("- B (sim ): `%s`  %d edges\n" % (b_path, len(b)))
    sm = difflib.SequenceMatcher(None, a, b, autojunk=False)
    shown = 0
    print("## 首个及后续分歧（按发生顺序）\n")
    for tag, i1, i2, j1, j2 in sm.get_opcodes():
        if tag == "equal" or shown >= max_report:
            continue
        shown += 1
        print("### #%d `%s` @ A[%d] / B[%d]\n" % (shown, tag, i1, j1))
        print("共同前缀:")
        for ln in a[max(0, i1 - context):i1]:
            print("    %s" % ln)
        print("A 走了:")
        for ln in a[i1:min(i2, i1 + context)]:
            print("  - %s" % ln)
        print("B 走了:")
        for ln in b[j1:min(j2, j1 + context)]:
            print("  + %s" % ln)
        # the decision itself is the source line of the first edge that differs
        src = (a[i1] if i1 < i2 else (b[j1] if j1 < j2 else ""))
        if ">" in src:
            print("\n**判定点**: `%s` —— 打开这一行，读它测试的表达式和它依赖的 tensor。\n"
                  % src.split(">")[0])
    if shown == 0:
        print("两边的分支决策序列完全一致：控制流没有分叉，差异要到数值/调度层面找。")
    ca, cb = Counter(a), Counter(b)
    delta = [(k, ca.get(k, 0), cb.get(k, 0)) for k in set(ca) | set(cb) if ca.get(k) != cb.get(k)]
    delta.sort(key=lambda x: -abs(x[1] - x[2]))
    if delta:
        print("\n## 执行次数差异最大的判定边\n")
        print("| 决策边 (file:line>next) | real | sim |")
        print("| --- | --- | --- |")
        for k, x, y in delta[:25]:
            print("| `%s` | %d | %d |" % (k, x, y))


def main():
    ap = argparse.ArgumentParser(description=__doc__,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--diff", nargs=2, metavar=("REAL_LOG", "SIM_LOG"))
    ap.add_argument("--context", type=int, default=6)
    args, rest = ap.parse_known_args()
    if args.diff:
        diff_logs(args.diff[0], args.diff[1], context=args.context)
        return
    ap.error("nothing to do: use --diff, or run `python -m pa_branch_probe <script.py> <args>`")


if __name__ == "__main__":
    # `python -m pa_branch_probe script.py ...` -> install the probe, then run the script
    if len(sys.argv) > 1 and sys.argv[1].endswith(".py") and os.path.isfile(sys.argv[1]):
        import runpy
        script = sys.argv[1]
        sys.argv = sys.argv[1:]
        sys.path.insert(0, os.path.dirname(os.path.abspath(script)))
        install()
        try:
            runpy.run_path(script, run_name="__main__")
        finally:
            uninstall()
    else:
        main()

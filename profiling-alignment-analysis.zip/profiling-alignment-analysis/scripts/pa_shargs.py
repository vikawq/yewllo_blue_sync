#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""pa_shargs.py -- read a MindSpeed/Megatron launch script (or a folder of them)
and turn it into the flag set that actually decides which code paths run.

    python pa_shargs.py --file examples/mcore/llama3/pretrain_llama3_8b_ptd.sh
    python pa_shargs.py --dir examples/ --list
    python pa_shargs.py --file real_run.sh --diff sim_run.sh

Why this is step one of the code side: the launch script is the entry point the
user actually has, and its flags gate large `if args.xxx:` regions inside the
model (fusion kernels, recompute, MoE, sequence parallel...). Before blaming the
simulator for a control-flow difference, check that both sides were launched
with the same flags -- a different `--recompute-granularity` explains a
completely different operator layout with no simulation bug at all.
"""
from __future__ import annotations

import argparse
import os
import re
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from pa_common import force_utf8  # noqa: E402

# Flags whose value flips a branch that is visible in the operator stream.
BRANCH_RELEVANT = [
    ("并行切分", re.compile(r"tensor-model-parallel|pipeline-model-parallel|context-parallel|"
                            r"expert-model-parallel|sequence-parallel|virtual-pipeline|"
                            r"num-layer-list|noop-layers|world-size|nproc|nnodes", re.I)),
    ("MoE", re.compile(r"moe|expert|router|topk|capacity|aux-loss|shared-experts|"
                       r"token-dispatcher|drop-and-pad", re.I)),
    ("重计算/内存", re.compile(r"recompute|checkpoint|swap|offload|adaptive-memory|reuse-fp32|"
                              r"distributed-optimizer|overlap-grad|overlap-param", re.I)),
    ("融合算子", re.compile(r"use-fused|flash-attn|use-fusion|mc2|rotary|swiglu|"
                           r"npu-|jit-compile|use-ascend", re.I)),
    ("精度/溢出", re.compile(r"^(bf16|fp16|fp32|loss-scale|initial-loss-scale|hysteresis|"
                             r"min-loss-scale|grad-clip|clip-grad|check-nan|deterministic)", re.I)),
    ("动态形状", re.compile(r"variable-seq|seq-length|max-position|pad-to|dynamic|packing|"
                            r"reset-position-ids|reset-attention-mask|eod", re.I)),
    ("迭代/数据", re.compile(r"train-iters|global-batch|micro-batch|data-path|split|"
                             r"eval-interval|save-interval|num-workers", re.I)),
]


def _join_continuations(text):
    return re.sub(r"\\\s*\n\s*", " ", text)


def parse_sh(path):
    with open(path, "r", encoding="utf-8", errors="replace") as fh:
        raw = fh.read()
    text = _join_continuations(raw)
    env = {}
    for m in re.finditer(r"^\s*(?:export\s+)?([A-Za-z_][A-Za-z0-9_]*)=([^\n#]*)", text, re.M):
        env[m.group(1)] = m.group(2).strip().strip('"').strip("'")

    def expand(s, depth=0):
        if depth > 3 or not s:
            return s
        def sub(m):
            return env.get(m.group(1) or m.group(2), m.group(0))
        out = re.sub(r"\$\{([A-Za-z_][A-Za-z0-9_]*)\}|\$([A-Za-z_][A-Za-z0-9_]*)", sub, s)
        return expand(out, depth + 1) if out != s else out

    args = {}
    for m in re.finditer(r"(?<![\w-])--([A-Za-z0-9][\w-]*)(?:[ \t]+((?!--)[^\s\\]+(?:[ \t]+(?!--)[^\s\\]+)*))?", text):
        flag, val = m.group(1), (m.group(2) or "").strip()
        # multi-valued flags exist (--num-layer-list 4 4 4 4) but the shell quoting
        # around a GPT_ARGS block leaves stray quotes at the end of the last value
        val = " ".join(tok for tok in val.split() if tok not in ('"', "'", "\\", '"\\'))
        val = expand(val) if val else "(flag)"
        if flag in args and args[flag] != val:
            args[flag] = "%s | %s" % (args[flag], val)
        else:
            args[flag] = val

    entry = []
    for m in re.finditer(r"(?:python3?|torchrun|msrun|deepspeed)[^\n]*?([\w./-]+\.py)", text):
        entry.append(m.group(1))
    sourced = re.findall(r"^\s*(?:source|\.)\s+([^\s\n]+)", text, re.M)
    launcher = "torchrun" if "torchrun" in text else ("msrun" if "msrun" in text else
                                                      ("deepspeed" if "deepspeed" in text else "python"))
    return {"path": path, "env": env, "args": args, "entry": sorted(set(entry)),
            "sourced": sourced, "launcher": launcher}


def group_of(flag):
    for name, pat in BRANCH_RELEVANT:
        if pat.search(flag):
            return name
    return ""


def report_one(p):
    L = ["# 启动脚本解析: %s" % p["path"], "",
         "- 启动方式: `%s`" % p["launcher"],
         "- 入口脚本: %s" % (", ".join("`%s`" % e for e in p["entry"]) or "(未识别，检查是否在被 source 的文件里)")]
    if p["sourced"]:
        L.append("- source 了: %s  ← 这些文件里的参数也要一起看" % ", ".join("`%s`" % s for s in p["sourced"]))
    for key in ("WORLD_SIZE", "NPUS_PER_NODE", "NNODES", "TP", "PP", "CP", "EP", "MBS", "GBS", "SEQ_LEN"):
        if key in p["env"]:
            L.append("- env %s = %s" % (key, p["env"][key]))
    L += ["", "## 影响控制流的参数", "", "| 分组 | 参数 | 值 |", "| --- | --- | --- |"]
    rows = [(group_of(f), f, v) for f, v in sorted(p["args"].items()) if group_of(f)]
    for g, f, v in sorted(rows):
        L.append("| %s | `--%s` | %s |" % (g, f, v))
    others = [f for f in sorted(p["args"]) if not group_of(f)]
    L += ["", "<details><summary>其余 %d 个参数</summary>" % len(others), "",
          " ".join("`--%s`" % f for f in others), "", "</details>", ""]
    return "\n".join(L)


def report_diff(a, b):
    L = ["# 启动参数对比", "", "- A: `%s`" % a["path"], "- B: `%s`" % b["path"], ""]
    keys = sorted(set(a["args"]) | set(b["args"]))
    diff = [(k, a["args"].get(k, "—"), b["args"].get(k, "—")) for k in keys
            if a["args"].get(k) != b["args"].get(k)]
    if not diff:
        L.append("**两侧参数完全一致** —— 配置不是差异来源，继续看 profiling 层面的分歧。")
        return "\n".join(L)
    L += ["两侧有 %d 个参数不同。带分组标记的会直接改变算子构成，" % len(diff),
          "先解释掉它们，再谈仿真数值导致的分支差异。", "",
          "| 分组 | 参数 | A | B |", "| --- | --- | --- | --- |"]
    for k, va, vb in sorted(diff, key=lambda x: (not group_of(x[0]), x[0])):
        L.append("| %s | `--%s` | %s | %s |" % (group_of(k) or "-", k, va, vb))
    env_keys = sorted(set(a["env"]) | set(b["env"]))
    env_diff = [(k, a["env"].get(k, "—"), b["env"].get(k, "—")) for k in env_keys
                if a["env"].get(k) != b["env"].get(k)
                and re.search(r"TP|PP|CP|EP|SIZE|SEQ|BATCH|RANK|NODE|ASCEND|HCCL|TASK_QUEUE|"
                              r"COMBINED|JIT|DETERMIN", k, re.I)]
    if env_diff:
        L += ["", "## 相关环境变量差异", "", "| 变量 | A | B |", "| --- | --- | --- |"]
        for k, va, vb in env_diff:
            L.append("| %s | %s | %s |" % (k, va, vb))
    return "\n".join(L)


def main():
    force_utf8()
    ap = argparse.ArgumentParser(description=__doc__,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--file", help="a launch .sh")
    ap.add_argument("--dir", help="scan a folder for .sh entry points")
    ap.add_argument("--diff", help="second .sh to compare with --file")
    ap.add_argument("--list", action="store_true", help="with --dir: just list candidates")
    args = ap.parse_args()

    if args.dir:
        hits = []
        for dp, _dn, fn in os.walk(args.dir):
            for f in fn:
                if f.endswith(".sh"):
                    p = os.path.join(dp, f)
                    try:
                        with open(p, "r", encoding="utf-8", errors="replace") as fh:
                            t = fh.read()
                    except OSError:
                        continue
                    if re.search(r"torchrun|msrun|deepspeed|python3?\s+\S+\.py", t):
                        hits.append((p, len(re.findall(r"(?<![\w-])--[A-Za-z]", t))))
        hits.sort(key=lambda x: -x[1])
        print("# 候选启动脚本 (按参数数量排序)\n")
        for p, n in hits[:60]:
            print("- `%s`  (%d 个参数)" % (p, n))
        if not args.list and hits:
            print("\n" + report_one(parse_sh(hits[0][0])))
        return

    if not args.file:
        raise SystemExit("need --file or --dir")
    a = parse_sh(args.file)
    if args.diff:
        print(report_diff(a, parse_sh(args.diff)))
    else:
        print(report_one(a))


if __name__ == "__main__":
    main()

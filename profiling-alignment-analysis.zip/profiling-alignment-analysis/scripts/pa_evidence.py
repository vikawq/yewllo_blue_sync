#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""pa_evidence.py -- turn a divergent operator into candidate lines of model code.

    # 1) the candidate set for a whole step: every point where device data
    #    reaches the host and can therefore steer a Python branch
    python pa_evidence.py --trace REAL/trace_view.json --list-sync --step -1 \\
        --repo D:/code/MindSpeed-LLM --out out/sync_points.md

    # 2) everything around one divergence found by pa_align.py
    python pa_evidence.py --trace REAL/trace_view.json --alignment out/rank0/alignment.json \\
        --repo D:/code/MindSpeed-LLM --out out/evidence.md

    # 3) one specific event
    python pa_evidence.py --trace REAL/trace_view.json --uid 918273 --repo ...

The idea this tool is built on
------------------------------
A Python `if` can only take a different branch in simulation if the value it
tests came from the device. That value has to cross to the host through a
synchronising read -- `.item()`, `.cpu()`, `bool(t)`, `nonzero()`, an overflow
check, a D2H `aclrtMemcpy`, a stream sync. So the set of *possible* culprits is
not "every if in the model", it is the small set of host-visible sync points
that executed shortly before the traces stopped matching. That is a list you can
actually read, and each entry carries a call stack pointing at real code.
"""
from __future__ import annotations

import argparse
import json
import os
import re
import sys
from collections import Counter, defaultdict

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from pa_common import (force_utf8, load_trace, link_flows, callstack_of, shape_of,  # noqa: E402
                       find_steps, normalize_name, write_json)

# Ops that pull a device value into host-visible Python, ordered by how directly
# they feed a branch. `.item()` lowers to aten::_local_scalar_dense, which is the
# single strongest signal that a Python-level decision is about to be made.
SYNC_PATTERNS = [
    ("value->python", re.compile(
        r"aten::_local_scalar_dense|aten::item|aten::is_nonzero|aten::equal|aten::allclose|"
        r"aten::_assert_async|aten::nonzero|aten::masked_select|aten::unique|aten::_unique2|"
        r"aten::bincount|aten::argwhere|aten::tolist", re.I)),
    ("overflow/amp", re.compile(
        r"float_status|npu_get_float_status|npu_clear_float_status|non_finite|"
        r"_amp_foreach_non_finite_check_and_unscale|inf_check|isinf|isnan|found_inf", re.I)),
    ("d2h copy", re.compile(
        r"Memcpy.*(D2H|DtoH|DeviceToHost)|aclrtMemcpy(?!Async)|MemcpyD2H|aten::_to_copy|"
        r"aten::to\b|aten::cpu\b|aten::copy_", re.I)),
    ("stream sync", re.compile(
        r"aclrtSynchronizeStream|aclrtSynchronizeDevice|aclrtSynchronizeEvent|"
        r"SynchronizeStreamWithTimeout|npu::synchronize|StreamWaitEvent", re.I)),
    ("collective", re.compile(
        r"c10d::|hcom_|allreduce|all_reduce|allgather|all_gather|broadcast|barrier", re.I)),
]

NOISE_FRAME = re.compile(
    r"site-packages[/\\](torch|torch_npu|apex|numpy)[/\\]|[/\\]torch[/\\]autograd[/\\]|"
    r"<built-in>|<string>|frozen importlib", re.I)


def classify_sync(name):
    for label, pat in SYNC_PATTERNS:
        if pat.search(name):
            return label
    return None


def parse_frame(frame):
    """'/path/file.py(123): func' -> (path, line, func); tolerant of other shapes."""
    m = re.match(r"(.+?)\((\d+)\)\s*:\s*(.*)$", frame.strip())
    if m:
        return m.group(1), int(m.group(2)), m.group(3)
    m = re.match(r"(.+?):(\d+)(?::\s*(.*))?$", frame.strip())
    if m:
        return m.group(1), int(m.group(2)), m.group(3) or ""
    return frame.strip(), 0, ""


def repo_frames(frames, repo):
    """Keep the frames that live in the model repo; those are the actionable ones."""
    out = []
    repo_norm = os.path.abspath(repo).replace("\\", "/").lower() if repo else ""
    for f in frames:
        path, line, func = parse_frame(f)
        p = path.replace("\\", "/")
        if NOISE_FRAME.search(p):
            continue
        if repo_norm and repo_norm not in p.lower():
            continue
        out.append((path, line, func))
    return out


def module_ancestors(track, ev):
    """Enclosing nn.Module / Optimizer / python_function slices give the code
    location even when the profiler was run without with_stack."""
    out = []
    for e in track.events:
        if e["ts"] > ev["ts"]:
            break
        if e["ts"] <= ev["ts"] <= e["ts"] + e["dur"] and e["uid"] != ev["uid"]:
            n = e["name"]
            if n.startswith(("nn.Module:", "Optimizer.", "ProfilerStep", "autograd::", "python_function")) \
                    or "/" in n or ".py" in n:
                if not out or out[-1] != n:
                    out.append(n)
    return out[-8:]


def collect_sync_points(trace, t0, t1, repo, limit=400):
    rows = []
    for tk in trace.tracks_by_side("host"):
        for ev in tk.events:
            if t0 is not None and not (t0 <= ev["ts"] < t1):
                continue
            label = classify_sync(ev["name"])
            if not label:
                continue
            frames = callstack_of(ev)
            rows.append({
                "uid": ev["uid"], "ts": ev["ts"], "dur": ev["dur"], "name": ev["name"],
                "kind": label, "track": tk.label,
                "frames": [list(x) for x in repo_frames(frames, repo)],
                "all_frames": frames[:12],
                "modules": module_ancestors(tk, ev),
                "shape": shape_of(ev),
            })
    rows.sort(key=lambda r: r["ts"])
    return rows[:limit]


def rank_call_sites(rows):
    """Group sync points by originating code line: a hot line executed once per
    step is a far better suspect than one executed ten thousand times."""
    sites = defaultdict(lambda: {"count": 0, "kinds": Counter(), "example_uid": None, "ops": Counter()})
    for r in rows:
        key = None
        if r["frames"]:
            path, line, func = r["frames"][-1]
            key = "%s:%d (%s)" % (path, line, func)
        elif r["modules"]:
            key = "module:%s" % r["modules"][-1]
        else:
            key = "unknown-callsite"
        s = sites[key]
        s["count"] += 1
        s["kinds"][r["kind"]] += 1
        s["ops"][normalize_name(r["name"])] += 1
        if s["example_uid"] is None:
            s["example_uid"] = r["uid"]
    out = [{"site": k, "count": v["count"], "kinds": dict(v["kinds"]),
            "ops": dict(v["ops"]), "example_uid": v["example_uid"]}
           for k, v in sites.items()]
    out.sort(key=lambda x: (x["count"], x["site"]))
    return out


def describe_event(trace, uid, dev2host, repo):
    ev = trace.by_uid.get(uid)
    if ev is None:
        return None
    tk = trace.tracks[(ev["pid"], ev["tid"])]
    info = {"uid": uid, "name": ev["name"], "ts": ev["ts"], "dur": ev["dur"],
            "track": tk.label, "side": tk.side, "shape": shape_of(ev),
            "args": {k: v for k, v in list(ev["args"].items())[:12]}}
    host = ev
    if tk.side == "device":
        h_uid = dev2host.get(uid)
        if h_uid is not None:
            host = trace.by_uid[h_uid]
            info["launched_by"] = {"uid": h_uid, "name": host["name"],
                                   "track": trace.tracks[(host["pid"], host["tid"])].label}
        else:
            info["launched_by"] = None
            host = None
    if host is not None:
        h_tk = trace.tracks[(host["pid"], host["tid"])]
        info["modules"] = module_ancestors(h_tk, host)
        frames = callstack_of(host)
        info["repo_frames"] = [list(x) for x in repo_frames(frames, repo)]
        info["all_frames"] = frames[:15]
    return info


def md_report(trace_path, ranked, rows, targets, window, repo):
    L = ["# 控制流分歧的代码证据线索", "",
         "- trace: `%s`" % trace_path,
         "- 窗口: %s" % window,
         "- repo 过滤: `%s`" % (repo or "(未指定，调用栈未过滤)"), ""]
    if targets:
        L += ["## 0. 分歧算子回溯", ""]
        for t in targets:
            if not t:
                continue
            L.append("### uid=%s `%s`  (%s, %s)" % (t["uid"], t["name"], t["side"], t["track"]))
            L.append("")
            if t.get("launched_by") is not None:
                L.append("- 下发它的 host 算子: `%s` (uid=%s, %s)" % (
                    t["launched_by"]["name"], t["launched_by"]["uid"], t["launched_by"]["track"]))
            elif "launched_by" in t:
                L.append("- 未找到 host→device 的 flow 连线（trace 里没有 async_npu 流事件），"
                         "改用同一 step 内的序号对应或 kernel_details.csv 的 Correlation Id 回溯")
            if t.get("shape"):
                L.append("- 输入 shape: `%s`" % t["shape"])
            if t.get("modules"):
                L.append("- 所在模块栈: %s" % " > ".join(t["modules"]))
            if t.get("repo_frames"):
                L.append("- 模型代码调用栈:")
                for path, line, func in t["repo_frames"][-8:]:
                    L.append("  - `%s:%d` %s" % (path, line, func))
            elif t.get("all_frames"):
                L.append("- 调用栈(未过滤):")
                for f in t["all_frames"][-8:]:
                    L.append("  - `%s`" % f)
            else:
                L.append("- 无调用栈：profiler 未开 `with_stack=True`。"
                         "重采一次真机 profiling 并加上 `with_stack=True, with_modules=True` "
                         "会让这一步从猜测变成直接读行号。")
            L.append("")
    L += ["## 1. 候选分支点（按调用点聚合，执行次数少的排前面）", "",
          "控制流只可能在“设备值回到 host”的地方分叉，所以下面这张表就是可疑 if 的完整候选集。",
          "每步只执行一两次的调用点（比如溢出检查、grad-norm、路由统计）最可疑；",
          "执行成千上万次的通常是逐算子的例行拷贝，不是分支。", ""]
    L += ["| 调用点 | 次数 | 类型 | 触发的算子 | 例子 uid |", "| --- | --- | --- | --- | --- |"]
    for s in ranked[:40]:
        L.append("| `%s` | %d | %s | %s | %s |" % (
            s["site"], s["count"],
            ",".join("%s x%d" % (k, v) for k, v in s["kinds"].items()),
            ",".join(list(s["ops"])[:3]), s["example_uid"]))
    L += ["", "## 2. 时间序上的同步点（前 60 条）", "",
          "| ts | 类型 | 算子 | 模块栈 / 代码行 |", "| --- | --- | --- | --- |"]
    for r in rows[:60]:
        loc = ""
        if r["frames"]:
            path, line, func = r["frames"][-1]
            loc = "`%s:%d` %s" % (os.path.basename(path), line, func)
        elif r["modules"]:
            loc = " > ".join(r["modules"][-2:])
        L.append("| %.3f | %s | %s | %s |" % (r["ts"], r["kind"], r["name"], loc))
    L += ["", "## 3. 下一步", "",
          "1. 打开上表里排名靠前的调用点，读它上下 30 行，找到消费这个值的 `if/while/assert`。",
          "2. 记录判据表达式（例如 `if grad_norm > clip_grad`、`if found_inf.item() > 0`、",
          "   `topk_idx` 决定的专家分发），以及它依赖的 tensor。",
          "3. 用 pa_branch_probe.py 在真机和仿真上各跑一遍，直接 diff 到具体哪一行、",
          "   哪一次迭代开始走了不同分支——这是可以写进结论的硬证据。", ""]
    return "\n".join(L)


def main():
    force_utf8()
    ap = argparse.ArgumentParser(description=__doc__,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--trace", required=True, help="usually the REAL trace_view.json "
                                                   "(it has the richer host side)")
    ap.add_argument("--alignment", default="", help="alignment.json from pa_align.py")
    ap.add_argument("--uid", type=int, action="append", default=[])
    ap.add_argument("--repo", default="", help="model repo root, used to filter call stacks")
    ap.add_argument("--list-sync", action="store_true")
    ap.add_argument("--step", type=int, default=None)
    ap.add_argument("--window-us", type=float, default=200000.0,
                    help="how far back from the divergence to collect sync points")
    ap.add_argument("--out", default="")
    args = ap.parse_args()

    trace = load_trace(args.trace)
    dev2host, _ = link_flows(trace)
    print("flow links: %d device kernels mapped to host ops" % len(dev2host), file=sys.stderr)

    t0 = t1 = None
    window = "whole trace"
    steps = find_steps(trace)
    if args.step is not None and steps:
        idx = args.step if args.step >= 0 else len(steps) + args.step
        name, t0, t1 = steps[idx]
        window = "step %s [%.0f, %.0f]" % (name, t0, t1)

    targets = []
    uids = list(args.uid)
    if args.alignment:
        with open(args.alignment, "r", encoding="utf-8") as fh:
            al = json.load(fh)
        for res in al.get("results", []):
            fd = res.get("first_divergence")
            if not fd:
                continue
            for o in (fd.get("real_ops") or [])[:1]:
                uids.append(o["uid"])
            for lc in (fd.get("last_common") or [])[-1:]:
                uids.append(lc["uid"])
        # narrow the sync-point window to just before the earliest divergence
        ts_list = [trace.by_uid[u]["ts"] for u in uids if u in trace.by_uid]
        if ts_list and t0 is None:
            first = min(ts_list)
            trace_start = min((tk.events[0]["ts"] for tk in trace.tracks.values() if tk.events),
                              default=0.0)
            t0, t1 = max(trace_start, first - args.window_us), first + 1.0
            window = "divergence-%.0fus .. divergence (%.0f, %.0f)" % (args.window_us, t0, t1)
    for u in uids:
        targets.append(describe_event(trace, u, dev2host, args.repo))

    rows = collect_sync_points(trace, t0, t1, args.repo)
    ranked = rank_call_sites(rows)
    md = md_report(args.trace, ranked, rows, targets, window, args.repo)
    print(md)
    if args.out:
        os.makedirs(os.path.dirname(os.path.abspath(args.out)) or ".", exist_ok=True)
        with open(args.out, "w", encoding="utf-8") as fh:
            fh.write(md)
        write_json(os.path.splitext(args.out)[0] + ".json",
                   {"targets": targets, "sync_points": rows, "call_sites": ranked,
                    "window": window})
        print("\nwrote %s" % args.out, file=sys.stderr)


if __name__ == "__main__":
    main()

#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""pa_heatmap.py -- operator heat map for real vs sim, side by side.

    python pa_heatmap.py --real REAL/trace_view.json --sim SIM/trace_view.json \\
        --outdir out/rank0 [--step -1] [--alignment out/rank0/alignment.json]

The x axis is *sequence position*, not wall clock. Simulated durations are
modelled, so a time-based heat map mostly shows how the simulator guessed at
latency; binning by op index instead makes the picture answer the question that
matters here -- "does each thread issue the same kinds of work in the same
order" -- and a control-flow divergence shows up as the moment the two columns
stop rhyming.

Writes heatmap.html (self-contained, open it or feed it to Perfetto's sibling
view) and prints an ASCII version so it is readable straight from the terminal.
"""
from __future__ import annotations

import argparse
import html
import json
import os
import sys
from collections import Counter, defaultdict

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from pa_common import (force_utf8, load_trace, normalize_name, categorize,  # noqa: E402
                       find_steps)
from pa_align import track_sequence, pair_tracks  # noqa: E402

CAT_COLORS = {
    "matmul": "#3b6ea5", "attention": "#7b4fa8", "comm": "#c2582b", "norm": "#2f8f6b",
    "elementwise": "#6f8f2f", "reduce": "#a8912f", "memory": "#8a8a8a", "optimizer": "#b5486b",
    "sync": "#4f4f8f", "other": "#c9c9c9",
}
ASCII_RAMP = " .:-=+*#%@"


def bucketize(seq, nbuckets):
    """Assign each op to a column by its position in the sequence."""
    n = len(seq)
    cols = [Counter() for _ in range(nbuckets)]
    if n == 0:
        return cols
    for i, name in enumerate(seq):
        cols[min(nbuckets - 1, i * nbuckets // n)][name] += 1
    return cols


def cat_strip(seq, nbuckets):
    cols = bucketize([categorize(s) for s in seq], nbuckets)
    out = []
    for c in cols:
        out.append(c.most_common(1)[0][0] if c else "other")
    return out


def ascii_heat(rows, cols_r, cols_s, nbuckets, title):
    L = ["", title, "=" * len(title)]
    width = max((len(r) for r in rows), default=10)
    maxv = 1
    for cols in (cols_r, cols_s):
        for c in cols:
            for r in rows:
                maxv = max(maxv, c.get(r, 0))
    for side, cols in (("real", cols_r), ("sim ", cols_s)):
        L.append("-- %s --" % side)
        for r in rows:
            line = "".join(ASCII_RAMP[min(len(ASCII_RAMP) - 1,
                                          int((c.get(r, 0) / maxv) ** 0.5 * (len(ASCII_RAMP) - 1)))]
                           for c in cols)
            L.append("%-*s |%s|" % (width, r[:width], line))
    L.append("%-*s  %s" % (width, "", "0%" + " " * max(0, nbuckets - 6) + "100%"))
    return "\n".join(L)


def html_table(rows, cols, maxv, marker=None):
    out = ['<table class="hm">']
    for r in rows:
        out.append('<tr><th title="%s">%s</th>' % (html.escape(r), html.escape(r[:38])))
        for i, c in enumerate(cols):
            v = c.get(r, 0)
            a = 0.0 if not v else min(1.0, (v / maxv) ** 0.5)
            mark = ' class="mark"' if marker is not None and i == marker else ""
            out.append('<td%s style="background:rgba(30,90,160,%.3f)" title="%s @col%d = %d"></td>'
                       % (mark, a, html.escape(r), i, v))
        out.append("</tr>")
    out.append("</table>")
    return "".join(out)


def strip_html(strip, marker=None):
    out = ['<table class="hm strip"><tr>']
    for i, cat in enumerate(strip):
        mark = ' class="mark"' if marker is not None and i == marker else ""
        out.append('<td%s style="background:%s" title="col%d %s"></td>' % (mark, CAT_COLORS.get(cat, "#ccc"), i, cat))
    out.append("</tr></table>")
    return "".join(out)


PAGE_CSS = """
body{font:13px/1.5 -apple-system,Segoe UI,Roboto,'Microsoft YaHei',sans-serif;margin:24px;
     background:#fff;color:#222}
h2{margin:28px 0 6px;font-size:17px}
h3{margin:18px 0 4px;font-size:14px;color:#444}
.hm{border-collapse:collapse;table-layout:fixed}
.hm th{font:11px monospace;text-align:right;padding-right:6px;width:280px;white-space:nowrap;
       overflow:hidden;font-weight:400;color:#333}
.hm td{width:9px;height:11px;border:0}
.hm.strip td{height:16px}
.hm td.mark{outline:2px solid #d02020;outline-offset:-1px}
.legend span{display:inline-block;margin-right:10px;font-size:11px}
.legend i{display:inline-block;width:11px;height:11px;vertical-align:-1px;margin-right:3px}
.note{color:#666;font-size:12px;max-width:900px}
.pair{border-top:1px solid #ddd;padding-top:8px;margin-top:24px}
.cols{display:flex;gap:36px;flex-wrap:wrap}
"""


def main():
    force_utf8()
    ap = argparse.ArgumentParser(description=__doc__,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--real", required=True)
    ap.add_argument("--sim", required=True)
    ap.add_argument("--outdir", default="heatmap_out")
    ap.add_argument("--alignment", default="", help="alignment.json: reuses its track pairing "
                                                    "and marks the first divergence column")
    ap.add_argument("--step", type=int, default=None)
    ap.add_argument("--side", default="both", choices=["host", "device", "both"])
    ap.add_argument("--buckets", type=int, default=64)
    ap.add_argument("--top-ops", type=int, default=24)
    ap.add_argument("--name-mode", default="medium", choices=["raw", "medium", "aggressive"])
    ap.add_argument("--min-events", type=int, default=20)
    args = ap.parse_args()

    tr = load_trace(args.real)
    ts_ = load_trace(args.sim)

    def window(trace):
        steps = find_steps(trace)
        if args.step is None or not steps:
            return None, None
        idx = args.step if args.step >= 0 else len(steps) + args.step
        return steps[idx][1], steps[idx][2]

    rw, sw = window(tr), window(ts_)
    sides = ["host", "device"] if args.side == "both" else [args.side]
    real_tracks = [t for s in sides for t in tr.tracks_by_side(s) if len(t.events) >= args.min_events]
    sim_tracks = [t for s in sides for t in ts_.tracks_by_side(s) if len(t.events) >= args.min_events]

    ev_r, seq_r, ev_s, seq_s = {}, {}, {}, {}
    for t in real_tracks:
        ev_r[t.label], seq_r[t.label] = track_sequence(t, args.name_mode, rw[0], rw[1])
    for t in sim_tracks:
        ev_s[t.label], seq_s[t.label] = track_sequence(t, args.name_mode, sw[0], sw[1])

    pairs, reason, _ = pair_tracks(real_tracks, sim_tracks, seq_r, seq_s)

    div_col = {}
    if args.alignment and os.path.isfile(args.alignment):
        with open(args.alignment, "r", encoding="utf-8") as fh:
            al = json.load(fh)
        for res in al.get("results", []):
            fd = res.get("first_divergence")
            if fd:
                pct = fd["position_pct"] / 100.0
                div_col[res["track"]["real"]] = min(args.buckets - 1, int(pct * args.buckets))

    body = ["<h1>算子热力图对比 real vs sim</h1>",
            '<p class="note">横轴 = 算子序列位置 0%%→100%%（不是时间，仿真的时间是模型算出来的，'
            '按时间画只会画出仿真器对时延的猜测）。纵轴 = 算子类型，格子深浅 = 该区间内出现次数。'
            '红框列 = pa_align.py 找到的首个分歧位置。step 窗口: %s</p>' % (args.step,),
            '<p class="legend">' + "".join(
                '<span><i style="background:%s"></i>%s</span>' % (c, k) for k, c in CAT_COLORS.items()) + "</p>"]

    ascii_out = []
    for rt, st in pairs:
        a, b = seq_r[rt.label], seq_s[st.label]
        if not a or not b:
            continue
        total = Counter(a) + Counter(b)
        rows = [n for n, _ in total.most_common(args.top_ops)]
        cols_r, cols_s = bucketize(a, args.buckets), bucketize(b, args.buckets)
        maxv = max([1] + [c.get(r, 0) for c in cols_r + cols_s for r in rows])
        mk = div_col.get(rt.label)
        body.append('<div class="pair"><h2>[%s/%s] %s &nbsp;↔&nbsp; %s</h2>' % (
            rt.side, rt.kind, html.escape(rt.label), html.escape(st.label)))
        body.append('<p class="note">real %d ops / sim %d ops &nbsp;·&nbsp; 配对依据: %s</p>'
                    % (len(a), len(b), html.escape(reason.get(rt.label, ""))))
        body.append("<h3>类型走向条 (real 上 / sim 下)</h3>")
        body.append(strip_html(cat_strip(a, args.buckets), mk))
        body.append(strip_html(cat_strip(b, args.buckets), mk))
        body.append('<div class="cols"><div><h3>real</h3>%s</div><div><h3>sim</h3>%s</div></div></div>'
                    % (html_table(rows, cols_r, maxv, mk), html_table(rows, cols_s, maxv, mk)))
        ascii_out.append(ascii_heat(rows[:14], cols_r, cols_s, args.buckets,
                                    "%s  <->  %s" % (rt.label, st.label)))

    os.makedirs(args.outdir, exist_ok=True)
    out_html = os.path.join(args.outdir, "heatmap.html")
    with open(out_html, "w", encoding="utf-8") as fh:
        fh.write("<!-- generated by pa_heatmap.py -->\n<meta charset='utf-8'>"
                 "<title>operator heatmap</title><style>%s</style>%s" % (PAGE_CSS, "\n".join(body)))
    print("\n".join(ascii_out))
    print("\nwrote %s" % out_html)


if __name__ == "__main__":
    main()

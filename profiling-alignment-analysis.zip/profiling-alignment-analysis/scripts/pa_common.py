#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""pa_common.py -- shared trace loading / track classification helpers.

Used by pa_discover.py, pa_align.py, pa_heatmap.py, pa_evidence.py, pa_perfetto.py.

Design notes
------------
Nothing about the Ascend / torch_npu trace schema is hard-coded as a hard
requirement: process and thread names differ between CANN / torch_npu versions.
Every classification rule is a *heuristic with a fallback to content sniffing*,
and every script prints the classification table it derived so a human (or the
agent) can spot a wrong guess immediately instead of silently comparing the
wrong tracks.

Only the Python standard library is used, so the scripts run on a bare NPU
dev box or a Windows laptop with no extra install.
"""
from __future__ import annotations

import json
import os
import re
import sys
from bisect import bisect_right
from collections import Counter, defaultdict

# --------------------------------------------------------------------------
# io helpers
# --------------------------------------------------------------------------


def force_utf8():
    """Windows consoles default to gbk; profiling names contain '#' and CJK."""
    for stream in (sys.stdout, sys.stderr):
        try:
            stream.reconfigure(encoding="utf-8")
        except Exception:
            pass


def load_json_tolerant(path):
    """Load a trace json, tolerating the truncated files profilers sometimes emit.

    A run killed mid-flush leaves a file ending in `,` or with no closing `]`.
    Rather than making the whole analysis fail, repair the tail and warn: a
    truncated trace is still usable for prefix alignment, which is exactly what
    divergence hunting needs.
    """
    with open(path, "r", encoding="utf-8", errors="replace") as fh:
        text = fh.read()
    try:
        return json.loads(text), None
    except json.JSONDecodeError:
        pass
    repaired = text.rstrip()
    repaired = repaired.rstrip(",")
    for tail in ("]", "}]", '"}]'):
        try:
            return json.loads(repaired + tail), "repaired truncated json (+%r)" % tail
        except json.JSONDecodeError:
            continue
    # last resort: cut back to the last complete object
    idx = repaired.rfind("},")
    if idx > 0:
        try:
            return json.loads(repaired[: idx + 1] + "]"), "repaired: truncated at last complete event"
        except json.JSONDecodeError:
            pass
    raise SystemExit("cannot parse %s as json (file may be corrupt)" % path)


def write_json(path, obj):
    os.makedirs(os.path.dirname(os.path.abspath(path)) or ".", exist_ok=True)
    with open(path, "w", encoding="utf-8") as fh:
        json.dump(obj, fh, ensure_ascii=False, indent=2)


# --------------------------------------------------------------------------
# name normalization
# --------------------------------------------------------------------------

_RE_HCCL_SUFFIX = re.compile(r"__\d+(?:_\d+)*$")          # hcom_allReduce__844_1_1
_RE_LONG_ID = re.compile(r"_\d{3,}(?=$|_)")                # foo_1234567
_RE_HEX = re.compile(r"\b[0-9a-fA-F]{8,}\b")
_RE_PTR = re.compile(r"0x[0-9a-fA-F]+")
_RE_STEP = re.compile(r"^(ProfilerStep|Iteration|step)#?\d+", re.I)
_RE_ANY_DIGITS = re.compile(r"\d+")


def normalize_name(name, mode="medium"):
    """Strip run-to-run varying ids so the same logical op compares equal.

    Both sides get the same treatment, so even aggressive normalization stays
    sound for diffing -- it only costs readability. Raw names are always kept
    alongside for the report, because the evidence a human needs ("which HCCL
    op, which stream") lives in the raw name.
    """
    if mode == "raw":
        return name
    n = name.strip()
    m = _RE_STEP.match(n)
    if m:
        return m.group(1)
    n = _RE_PTR.sub("0x#", n)
    n = _RE_HEX.sub("#", n)
    n = _RE_HCCL_SUFFIX.sub("", n)
    n = _RE_LONG_ID.sub("", n)
    if mode == "aggressive":
        n = _RE_ANY_DIGITS.sub("#", n)
    return n


# --------------------------------------------------------------------------
# op categories (for heatmap colouring and coarse summaries)
# --------------------------------------------------------------------------

CATEGORY_RULES = [
    ("comm", re.compile(r"hcom|hccl|allreduce|allgather|reducescatter|alltoall|broadcast|"
                        r"send|recv|notify|rdma|batchsendrecv", re.I)),
    ("attention", re.compile(r"flashattention|fusedattention|promptattention|incre|paged|softmaxgrad", re.I)),
    ("matmul", re.compile(r"matmul|batchmatmul|gemm|conv|bmm|linear|mm$", re.I)),
    ("norm", re.compile(r"layernorm|rmsnorm|batchnorm|groupnorm", re.I)),
    ("elementwise", re.compile(r"^(add|sub|mul|div|cast|relu|gelu|silu|swish|sigmoid|tanh|exp|"
                               r"sqrt|rsqrt|pow|neg|abs|maximum|minimum|clip|where|select|"
                               r"fill|zeros|ones|muls|adds)", re.I)),
    ("reduce", re.compile(r"reduce|sum|mean|argmax|argmin|max$|min$|softmax|topk|sort|cumsum", re.I)),
    ("memory", re.compile(r"memcpy|memset|copy|slice|concat|split|transpose|reshape|view|"
                          r"gather|scatter|index|pad|broadcastto|contiguous|format", re.I)),
    ("optimizer", re.compile(r"adam|sgd|lamb|clipgrad|gradnorm|foreach|scale|overflow|npugetfloatstatus", re.I)),
    ("sync", re.compile(r"synchronize|streamwait|eventwait|barrier|wait", re.I)),
]


def categorize(name):
    for cat, pat in CATEGORY_RULES:
        if pat.search(name):
            return cat
    return "other"


# --------------------------------------------------------------------------
# track classification
# --------------------------------------------------------------------------

# kind -> side.  'derived' tracks (Overlap Analysis, counters) are summaries the
# profiler computed, not real op streams, so they are excluded from alignment.
KIND_SIDE = {
    "framework": "host",
    "cann": "host",
    "device": "device",
    "device_comm": "device",
    "derived": "derived",
    "unknown": "unknown",
}

_PROC_RULES = [
    ("derived", re.compile(r"overlap analysis|npu ?mem|freq|utilization|bandwidth|statistic", re.I)),
    ("device_comm", re.compile(r"^hccl|communication", re.I)),
    ("device", re.compile(r"ascend hardware|npu(?!.*mem)|device|aicore|ai ?cpu", re.I)),
    ("cann", re.compile(r"^cann|acl|runtime|ge$|gehost", re.I)),
    ("framework", re.compile(r"python|pytorch|torch|process |mindspore|host", re.I)),
]

_CONTENT_RULES = [
    ("framework", re.compile(r"^(aten::|torch_npu::|npu::|c10d::|autograd::|nn\.Module|Optimizer\.|"
                             r"ProfilerStep|DataLoader|Memcpy |Module|torch/|python_function)", re.I)),
    ("cann", re.compile(r"^(aclnn|acl|AscendCL@|Node@|Model@|runtime@|MsprofTx|op_execute|"
                        r"AscendCL|EnqueueTask|Dequeue)", re.I)),
    ("device_comm", re.compile(r"^(hcom_|hccl|Notify_|RDMA|Memcpy\b.*hccl)", re.I)),
]


def classify_track(proc_name, thread_name, sample_names):
    """Return (kind, reason). Process name wins; content sniffing breaks ties."""
    label = "%s / %s" % (proc_name or "", thread_name or "")
    for kind, pat in _PROC_RULES:
        if pat.search(proc_name or ""):
            return kind, "process name %r matched %s" % (proc_name, kind)
    votes = Counter()
    for nm in sample_names:
        for kind, pat in _CONTENT_RULES:
            if pat.search(nm):
                votes[kind] += 1
                break
    if votes:
        kind, n = votes.most_common(1)[0]
        if n >= max(3, 0.2 * len(sample_names)):
            return kind, "content sniff on %d/%d sampled names" % (n, len(sample_names))
    return "unknown", "no rule matched (%s)" % label


# --------------------------------------------------------------------------
# trace model
# --------------------------------------------------------------------------


class Track(object):
    __slots__ = ("pid", "tid", "proc", "thread", "kind", "reason", "events", "label")

    def __init__(self, pid, tid):
        self.pid = pid
        self.tid = tid
        self.proc = str(pid)
        self.thread = str(tid)
        self.kind = "unknown"
        self.reason = ""
        self.events = []
        self.label = ""

    @property
    def side(self):
        return KIND_SIDE.get(self.kind, "unknown")

    def make_label(self):
        # ' / ' rather than '|': labels end up inside markdown tables.
        self.label = "%s / %s" % (self.proc, self.thread)
        return self.label

    def sort(self):
        # Chrome-trace nesting order: outer slices first at equal ts.
        self.events.sort(key=lambda e: (e["ts"], -e.get("dur", 0)))


class Trace(object):
    def __init__(self, path):
        self.path = path
        self.tracks = {}          # (pid, tid) -> Track
        self.by_uid = {}          # uid -> event dict
        self.flows = []           # raw flow events
        self.warnings = []
        self.t0 = 0.0

    # -- lookup helpers -------------------------------------------------
    def tracks_by_side(self, side):
        out = [t for t in self.tracks.values() if t.side == side and t.events]
        out.sort(key=lambda t: (-len(t.events), t.label))
        return out

    def summary(self):
        rows = []
        for t in sorted(self.tracks.values(), key=lambda t: -len(t.events)):
            if not t.events:
                continue
            top = Counter(normalize_name(e["name"]) for e in t.events).most_common(3)
            rows.append({
                "pid": t.pid, "tid": t.tid, "proc": t.proc, "thread": t.thread,
                "kind": t.kind, "side": t.side, "events": len(t.events),
                "reason": t.reason,
                "top_ops": ["%s x%d" % (n, c) for n, c in top],
            })
        return rows


def load_trace(path, keep_kinds=None, drop_zero_dur=False):
    """Parse a chrome-trace json (trace_view.json) into a Trace."""
    data, warn = load_json_tolerant(path)
    if isinstance(data, dict):
        data = data.get("traceEvents", data.get("events", []))
    tr = Trace(path)
    if warn:
        tr.warnings.append("%s: %s" % (os.path.basename(path), warn))

    proc_names, thread_names = {}, {}
    raw_by_track = defaultdict(list)
    for ev in data:
        ph = ev.get("ph")
        if ph == "M":
            nm = ev.get("name")
            args = ev.get("args") or {}
            if nm == "process_name":
                proc_names[ev.get("pid")] = str(args.get("name", ev.get("pid")))
            elif nm == "thread_name":
                thread_names[(ev.get("pid"), ev.get("tid"))] = str(args.get("name", ev.get("tid")))
            continue
        if ph in ("s", "f", "t"):
            tr.flows.append(ev)
            continue
        if ph not in ("X", "x", "i", "I", "R"):
            continue                      # counters (C), begin/end pairs handled below
        if "ts" not in ev:
            continue
        raw_by_track[(ev.get("pid"), ev.get("tid"))].append(ev)

    uid = 0
    for (pid, tid), evs in raw_by_track.items():
        tk = Track(pid, tid)
        tk.proc = proc_names.get(pid, str(pid))
        tk.thread = thread_names.get((pid, tid), str(tid))
        sample = [e.get("name", "") for e in evs[: min(len(evs), 200)]]
        tk.kind, tk.reason = classify_track(tk.proc, tk.thread, sample)
        tk.make_label()
        if keep_kinds and tk.kind not in keep_kinds:
            tr.tracks[(pid, tid)] = tk
            continue
        for ev in evs:
            dur = float(ev.get("dur", 0) or 0)
            if drop_zero_dur and dur <= 0:
                continue
            rec = {
                "uid": uid,
                "name": str(ev.get("name", "")),
                "ts": float(ev.get("ts", 0)),
                "dur": dur,
                "args": ev.get("args") or {},
                "cat": ev.get("cat", ""),
                "pid": pid, "tid": tid,
            }
            tk.events.append(rec)
            tr.by_uid[uid] = rec
            uid += 1
        tk.sort()
        tr.tracks[(pid, tid)] = tk

    all_ts = [t.events[0]["ts"] for t in tr.tracks.values() if t.events]
    tr.t0 = min(all_ts) if all_ts else 0.0
    return tr


# --------------------------------------------------------------------------
# shapes / args
# --------------------------------------------------------------------------

_SHAPE_KEYS = ("Input Dims", "Input Shapes", "input_dims", "Input Shape",
               "input_shapes", "Input dims", "shape")
_DTYPE_KEYS = ("Input type", "Input Data Types", "input_type", "dtype")


def shape_of(ev):
    args = ev.get("args") or {}
    for k in _SHAPE_KEYS:
        if k in args and args[k] not in ("", None, "[]"):
            return str(args[k])
    return ""


def dtype_of(ev):
    args = ev.get("args") or {}
    for k in _DTYPE_KEYS:
        if k in args and args[k] not in ("", None):
            return str(args[k])
    return ""


# --------------------------------------------------------------------------
# python_function events
# --------------------------------------------------------------------------
#
# With `with_stack=True` torch's profiler emits one slice per Python call, named
# `/abs/path/file.py(123): func_name`. These are the most valuable events in the
# whole trace for this analysis: they say which code actually ran, nested exactly
# as the call tree, without needing any separate call-stack argument.

_RE_PYFUNC = re.compile(r"^(?P<file>.+?\.py)\((?P<line>\d+)\):\s*(?P<func>.+?)\s*$")


def parse_pyfunc(name):
    """'/a/b/mod.py(12): fn' -> ('/a/b/mod.py', 12, 'fn'); None if not a py frame."""
    m = _RE_PYFUNC.match(name)
    if not m:
        return None
    return m.group("file"), int(m.group("line")), m.group("func")


def norm_pypath(path, roots=()):
    """Make a path comparable across two machines.

    The real run and the simulated run almost never share absolute paths (different
    conda envs, different checkouts), so comparing raw paths would report every
    single function as 'only on one side'. Cutting at the package root keeps the
    part that actually identifies the code.
    """
    p = str(path).replace("\\", "/")
    low = p.lower()
    for marker in ("/site-packages/", "/dist-packages/"):
        i = low.rfind(marker)
        if i >= 0:
            return p[i + len(marker):]
    for r in roots:
        r = str(r).replace("\\", "/").rstrip("/").lower()
        if not r:
            continue
        i = low.find(r)
        if i >= 0:
            return p[i + len(r):].lstrip("/")
    return p


_CALLSTACK_KEYS = ("Call stack", "call_stack", "Callstack", "stack")


def callstack_of(ev):
    args = ev.get("args") or {}
    for k in _CALLSTACK_KEYS:
        v = args.get(k)
        if v:
            if isinstance(v, list):
                return [str(x) for x in v]
            return [s for s in re.split(r";|\n", str(v)) if s.strip()]
    return []


# --------------------------------------------------------------------------
# nesting / enclosing lookup
# --------------------------------------------------------------------------


def enclosing_stacks(track, query_times):
    """For each query timestamp return the stack of enclosing events (outer->inner).

    Chrome-trace slices on one tid are properly nested, so a single sweep with a
    stack answers every query in O((n+q) log q).
    """
    out = {}
    queries = sorted(set(float(t) for t in query_times))
    if not queries or not track.events:
        return out
    qi = 0
    stack = []
    for ev in track.events:
        start, end = ev["ts"], ev["ts"] + ev["dur"]
        while qi < len(queries) and queries[qi] < start:
            t = queries[qi]
            while stack and stack[-1]["ts"] + stack[-1]["dur"] < t:
                stack.pop()
            out[t] = [e for e in stack if e["ts"] <= t <= e["ts"] + e["dur"]]
            qi += 1
        while stack and stack[-1]["ts"] + stack[-1]["dur"] <= start:
            stack.pop()
        stack.append(ev)
        _ = end
    while qi < len(queries):
        t = queries[qi]
        out[t] = [e for e in stack if e["ts"] <= t <= e["ts"] + e["dur"]]
        qi += 1
    return out


def nearest_event(track, ts, tol=50.0):
    """Event on `track` starting closest to ts (used to attach flow endpoints)."""
    if not track.events:
        return None
    starts = [e["ts"] for e in track.events]
    i = bisect_right(starts, ts)
    best, bestd = None, None
    for j in (i - 1, i):
        if 0 <= j < len(track.events):
            d = abs(track.events[j]["ts"] - ts)
            if bestd is None or d < bestd:
                best, bestd = track.events[j], d
    if best is not None and bestd is not None and bestd <= tol:
        return best
    return best if bestd is not None and bestd <= 1e6 else None


def link_flows(trace):
    """Return {device_uid: host_uid} and {host_uid: [device_uid...]} from flow arrows.

    torch_npu emits `ph:'s'` on the host launch site and `ph:'f'` on the device
    kernel, tied by `id`, usually with cat 'async_npu'. Versions differ, so match
    on id regardless of cat and let the endpoint's track decide direction.
    """
    starts, ends = {}, {}
    for fe in trace.flows:
        fid = fe.get("id", fe.get("id2"))
        if fid is None:
            continue
        rec = (fe.get("pid"), fe.get("tid"), float(fe.get("ts", 0)))
        if fe.get("ph") == "s":
            starts.setdefault(fid, rec)
        elif fe.get("ph") == "f":
            ends[fid] = rec
    dev2host, host2dev = {}, defaultdict(list)
    # group queries per track to reuse sweeps
    by_track_q = defaultdict(list)
    for fid in set(starts) & set(ends):
        for pid, tid, ts in (starts[fid], ends[fid]):
            by_track_q[(pid, tid)].append(ts)
    stacks = {}
    for key, times in by_track_q.items():
        tk = trace.tracks.get(key)
        if tk is not None:
            stacks[key] = enclosing_stacks(tk, times)
    for fid in set(starts) & set(ends):
        spid, stid, sts = starts[fid]
        epid, etid, ets = ends[fid]
        s_tk, e_tk = trace.tracks.get((spid, stid)), trace.tracks.get((epid, etid))
        if s_tk is None or e_tk is None:
            continue
        s_stack = stacks.get((spid, stid), {}).get(sts) or []
        e_stack = stacks.get((epid, etid), {}).get(ets) or []
        a_ev = s_stack[-1] if s_stack else nearest_event(s_tk, sts)
        b_ev = nearest_event(e_tk, ets, tol=5.0) or (e_stack[-1] if e_stack else None)
        if a_ev is None or b_ev is None:
            continue
        if s_tk.side == "host" and e_tk.side == "device":
            host_ev, dev_ev = a_ev, b_ev
        elif s_tk.side == "device" and e_tk.side == "host":
            host_ev, dev_ev = b_ev, a_ev
        else:
            continue
        dev2host[dev_ev["uid"]] = host_ev["uid"]
        host2dev[host_ev["uid"]].append(dev_ev["uid"])
    return dev2host, dict(host2dev)


# --------------------------------------------------------------------------
# step segmentation
# --------------------------------------------------------------------------

_RE_STEP_EVENT = re.compile(r"^(ProfilerStep|Iteration)#?(\d+)", re.I)


def find_steps(trace):
    """Return [(step_label, t_start, t_end)] from ProfilerStep#N markers."""
    steps = []
    for tk in trace.tracks.values():
        for ev in tk.events:
            m = _RE_STEP_EVENT.match(ev["name"])
            if m and ev["dur"] > 0:
                steps.append((ev["name"], ev["ts"], ev["ts"] + ev["dur"]))
    steps.sort(key=lambda s: s[1])
    return steps


def slice_events(events, t_start, t_end):
    return [e for e in events if e["ts"] >= t_start and e["ts"] < t_end]

#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""pa_perfetto.py -- put both traces into one Perfetto timeline and serve them.

    # merge one step of each side into a single comparable trace
    python pa_perfetto.py merge --real REAL/trace_view.json --sim SIM/trace_view.json \\
        --out out/merged_rank0.json --real-step -1 --sim-step -1

    # serve it to https://ui.perfetto.dev/ and print the deep link
    python pa_perfetto.py serve --file out/merged_rank0.json --port 9001 --seconds 1800

Why merge instead of opening two tabs: the question is "where do the two runs
stop doing the same thing", and eyes answer that much faster when both sets of
tracks share one time axis in one window. Both sides are shifted so their first
event sits at t=0 (durations are not comparable anyway -- simulated time is
modelled), sim processes are renamed `[SIM] ...` and moved to their own pid
range so nothing collides.

Privacy note worth telling the user: ui.perfetto.dev parses the trace in the
browser with WASM and the file is fetched from this local server, so the trace
does not leave the machine unless someone clicks Perfetto's own "Share" button.
"""
from __future__ import annotations

import argparse
import json
import os
import sys
import time
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import quote

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from pa_common import force_utf8, load_json_tolerant  # noqa: E402

PID_OFFSET = 1000000
FLOW_ID_OFFSET = 10 ** 9
UI_URL = "https://ui.perfetto.dev/#!/?url="


def _events(path):
    data, warn = load_json_tolerant(path)
    if isinstance(data, dict):
        data = data.get("traceEvents", data.get("events", []))
    if warn:
        print("  note: %s" % warn, file=sys.stderr)
    return data


def _find_steps(events, want):
    """Return (t0, t1) of the requested ProfilerStep, or (None, None)."""
    if want is None:
        return None, None
    steps = []
    for ev in events:
        n = str(ev.get("name", ""))
        if (n.startswith("ProfilerStep") or n.startswith("Iteration")) and ev.get("dur"):
            steps.append((float(ev["ts"]), float(ev["ts"]) + float(ev["dur"]), n))
    steps.sort()
    if not steps:
        print("  note: no ProfilerStep markers, using the whole trace", file=sys.stderr)
        return None, None
    idx = want if want >= 0 else len(steps) + want
    idx = max(0, min(idx, len(steps) - 1))
    print("  step %d/%d -> %s" % (idx, len(steps), steps[idx][2]), file=sys.stderr)
    return steps[idx][0], steps[idx][1]


def _shift(events, tag, pid_offset, t0, t1, drop_counters):
    out = []
    base = None
    for ev in events:
        if "ts" in ev:
            ts = float(ev["ts"])
            if t0 is not None and not (t0 <= ts <= t1):
                if ev.get("ph") != "M":
                    continue
            if ev.get("ph") != "M":
                base = ts if base is None else min(base, ts)
    base = base or 0.0
    for ev in events:
        ph = ev.get("ph")
        if drop_counters and ph == "C":
            continue
        e = dict(ev)
        if "pid" in e and isinstance(e["pid"], (int, float)):
            e["pid"] = int(e["pid"]) + pid_offset
        elif "pid" in e:
            e["pid"] = "%s%s" % (tag, e["pid"])
        if ph == "M" and e.get("name") == "process_name":
            a = dict(e.get("args") or {})
            a["name"] = "[%s] %s" % (tag, a.get("name", ""))
            e["args"] = a
        if ph in ("s", "f", "t") and "id" in e and isinstance(e["id"], (int, float)):
            e["id"] = int(e["id"]) + (FLOW_ID_OFFSET if pid_offset else 0)
        if "ts" in e and ph != "M":
            ts = float(e["ts"])
            if t0 is not None and not (t0 <= ts <= t1):
                continue
            e["ts"] = ts - base
        out.append(e)
    return out


def cmd_merge(args):
    print("reading real ...", file=sys.stderr)
    real = _events(args.real)
    print("reading sim ...", file=sys.stderr)
    sim = _events(args.sim)
    r0, r1 = _find_steps(real, args.real_step if args.real_step is not None else args.step)
    s0, s1 = _find_steps(sim, args.sim_step if args.sim_step is not None else args.step)
    merged = _shift(real, "REAL", 0, r0, r1, args.drop_counters) + \
        _shift(sim, "SIM", PID_OFFSET, s0, s1, args.drop_counters)
    os.makedirs(os.path.dirname(os.path.abspath(args.out)) or ".", exist_ok=True)
    with open(args.out, "w", encoding="utf-8") as fh:
        json.dump(merged, fh, ensure_ascii=False)
    mb = os.path.getsize(args.out) / 1e6
    print("wrote %s (%d events, %.1f MB)" % (args.out, len(merged), mb))
    if mb > 400:
        print("WARNING: %.0f MB is heavy for the browser. Re-run with --step to keep a "
              "single iteration, and/or --drop-counters." % mb)
    print("next: python %s serve --file %s" % (os.path.basename(__file__), args.out))


class _CorsHandler(SimpleHTTPRequestHandler):
    """CORS + Private Network Access headers.

    ui.perfetto.dev is an https origin fetching 127.0.0.1, which Chrome treats as
    a private-network request: it sends a preflight and refuses the fetch unless
    the reply carries `Access-Control-Allow-Private-Network: true`. Without this
    header the request never leaves the browser and Perfetto only says
    "Could not load local trace TypeError: Failed to fetch".
    """

    def end_headers(self):
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Private-Network", "true")
        self.send_header("Cache-Control", "no-cache")
        SimpleHTTPRequestHandler.end_headers(self)

    def do_OPTIONS(self):                       # noqa: N802
        self.send_response(200)
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Methods", "GET, HEAD, OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "*")
        self.send_header("Access-Control-Allow-Private-Network", "true")
        self.send_header("Access-Control-Max-Age", "600")
        self.end_headers()

    def log_message(self, fmt, *a):
        sys.stderr.write("  http: " + fmt % a + "\n")


OPENER_HTML = """<!doctype html><meta charset="utf-8"><title>open in Perfetto</title>
<style>body{font:14px/1.6 system-ui,sans-serif;margin:40px}button{font-size:16px;padding:8px 16px}
#s{margin-top:16px;color:#555;white-space:pre-wrap}</style>
<h2>%(name)s &rarr; ui.perfetto.dev</h2>
<p>Loads the trace from this local server and hands it to Perfetto through the
window messaging API. Use this when the plain <code>?url=</code> deep link is blocked:
Chrome refuses fetches from an https page to 127.0.0.1 on some setups, while a
postMessage between windows is not a network request and always goes through.</p>
<button id="go">Open in Perfetto</button>
<div id="s"></div>
<script>
const FILE = %(json_name)s;
const UI = 'https://ui.perfetto.dev';
const s = (m) => document.getElementById('s').textContent = m;
async function go() {
  s('fetching ' + FILE + ' ...');
  const buf = await (await fetch(FILE)).arrayBuffer();
  s('opening Perfetto (' + (buf.byteLength/1e6).toFixed(1) + ' MB) ...');
  const win = window.open(UI);
  if (!win) { s('popup blocked - click the button again, or allow popups'); return; }
  const timer = setInterval(() => win.postMessage('PING', UI), 50);
  const onMsg = (e) => {
    if (e.data !== 'PONG') return;
    clearInterval(timer);
    window.removeEventListener('message', onMsg);
    win.postMessage({perfetto: {buffer: buf, title: %(title)s, fileName: FILE}}, UI);
    s('sent to Perfetto');
  };
  window.addEventListener('message', onMsg);
  setTimeout(() => s(document.getElementById('s').textContent.startsWith('sent') ? 'sent to Perfetto'
      : 'no PONG from Perfetto yet - keep the Perfetto tab focused for a moment'), 8000);
}
document.getElementById('go').onclick = go;
go();
</script>
"""


def _write_opener(directory, name):
    p = os.path.join(directory, "pa_open_perfetto.html")
    with open(p, "w", encoding="utf-8") as fh:
        fh.write(OPENER_HTML % {"name": name, "json_name": json.dumps(name),
                                "title": json.dumps("real vs sim: " + name)})
    return p


def cmd_serve(args):
    path = os.path.abspath(args.file)
    if not os.path.isfile(path):
        raise SystemExit("no such file: %s" % path)
    directory, name = os.path.dirname(path), os.path.basename(path)
    _write_opener(directory, name)
    handler = type("H", (_CorsHandler,), {"directory": directory})

    def _init(self, *a, **kw):
        SimpleHTTPRequestHandler.__init__(self, *a, directory=directory, **kw)
    handler.__init__ = _init

    httpd = ThreadingHTTPServer(("127.0.0.1", args.port), handler)
    local = "http://127.0.0.1:%d/%s" % (args.port, quote(name))
    link = UI_URL + quote(local, safe="")
    print("serving %s" % path)
    print("\nOPEN THIS IN THE BROWSER (deep link):\n%s\n" % link)
    print("IF THAT SHOWS 'Could not load local trace', USE THIS INSTEAD:\n"
          "http://127.0.0.1:%d/pa_open_perfetto.html\n" % args.port)
    if args.port != 9001:
        print("NOTE: ui.perfetto.dev's CSP only allows plain-http localhost on port 9001, so the\n"
              "      deep link will be refused on port %d. The pa_open_perfetto.html page has no\n"
              "      such restriction and works on any port.\n" % args.port)
    print("(Perfetto parses the trace in the browser; the file goes from this local server to "
          "your browser and nowhere else unless you press Perfetto's Share button.)")
    print("serving for %d seconds, Ctrl-C to stop" % args.seconds)
    httpd.timeout = 1
    end = time.time() + args.seconds
    try:
        while time.time() < end:
            httpd.handle_request()
    except KeyboardInterrupt:
        pass
    finally:
        httpd.server_close()
    print("server stopped")


def main():
    force_utf8()
    ap = argparse.ArgumentParser(description=__doc__,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    sub = ap.add_subparsers(dest="cmd", required=True)

    m = sub.add_parser("merge", help="merge real+sim into one perfetto trace")
    m.add_argument("--real", required=True)
    m.add_argument("--sim", required=True)
    m.add_argument("--out", required=True)
    m.add_argument("--step", type=int, default=None)
    m.add_argument("--real-step", type=int, default=None)
    m.add_argument("--sim-step", type=int, default=None)
    m.add_argument("--drop-counters", action="store_true", default=True)
    m.add_argument("--keep-counters", dest="drop_counters", action="store_false")
    m.set_defaults(func=cmd_merge)

    s = sub.add_parser("serve", help="serve a trace to ui.perfetto.dev")
    s.add_argument("--file", required=True)
    s.add_argument("--port", type=int, default=9001)
    s.add_argument("--seconds", type=int, default=1800)
    s.set_defaults(func=cmd_serve)

    args = ap.parse_args()
    args.func(args)


if __name__ == "__main__":
    main()

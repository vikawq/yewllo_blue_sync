#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""pa_srcbranch.py -- 用 AST 把源码里的控制流分支全量列出来，并标出判据变量/tensor。

三种用法：

    # A. 某个调用被哪些 if 包着（pa_pytrace.py 第 4/5 节的候选边直接喂进来）
    python pa_srcbranch.py --file mindspeed_mm/patchs/adaptive_clip_grad_patch.py \\
        --func get_grad_norm_fp32_async --callee multi_tensor_applier --repo <repo>

    # B. 把一个文件/函数里所有分支枚举出来，按"数值敏感度"排序
    python pa_srcbranch.py --scan-file megatron/core/optimizer/optimizer.py --repo <repo>

    # C. 批量：吃 pa_pytrace.py 的 json，对所有候选 caller 自动跑 A
    python pa_srcbranch.py --from-pytrace out/pytrace.json --repo <repo> --out out/branches.md

为什么要做这一步
----------------
trace 只能告诉你"这个函数被调用了 3 次 vs 2 次"，告诉不了你**是哪一行 if 决定的、它判的是什么**。
源码里这件事是确定的：把 AST 拿出来，找到调用点，往上收集所有把它包住的 `if/while/for`，
就得到了完整的守卫条件链；再把条件里出现的名字回溯到它们的赋值语句，就得到了判据变量
以及产生它的那次计算。这一步不需要 `with_stack`，也不依赖 profiling 采到什么，
所以它是"把可能的分支列全"的唯一可靠办法。
"""
from __future__ import annotations

import argparse
import ast
import json
import os
import re
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from pa_common import force_utf8  # noqa: E402

# 判据里出现这些东西，说明它依赖设备算出来的值 —— 仿真数值一偏就可能翻转
DEVICE_VALUE_PAT = re.compile(
    r"\.item\(\)|\.cpu\(\)|\.tolist\(\)|\.numpy\(\)|\.any\(\)|\.all\(\)|\.max\(\)|\.min\(\)|"
    r"\.sum\(\)|\.numel\(\)|\.nonzero\(|\.count_nonzero\(|is_nonzero|torch\.(any|all|isnan|isinf|"
    r"isfinite|equal|allclose|nonzero|argmax|argmin|topk|unique)", re.I)
# `float(x)` / `int(x)` 本身不说明什么（`norm_type = float(norm_type)` 只是个类型转换），
# 只有当被转换的东西看起来是张量时才算把设备值拉到了 host。
_CAST_ON_TENSOR = re.compile(
    r"(bool|int|float)\s*\(\s*[^)]*(inf|nan|flag|found|mask|norm|loss|scale|tensor|"
    r"\.item\(\)|\.sum\(|\.max\(|\.numel\()", re.I)

TENSORISH_NAME = re.compile(
    r"norm|inf|nan|found|scale|coeff|clip|loss|mask|idx|index|len|count|num_|size|shape|"
    r"success|flag|overflow|skip|topk|expert|token|capacity|seq|batch|finish|eos|done|"
    r"threshold|ratio|prob|logit|grad", re.I)

CONFIG_NAME = re.compile(r"^(args|self\.config|config|cfg|opt|options|self\.args)\b", re.I)


def _src_seg(src, node, lines):
    try:
        seg = ast.get_source_segment(src, node)
        if seg:
            return seg.strip()
    except Exception:
        pass
    a = getattr(node, "lineno", 1) - 1
    b = getattr(node, "end_lineno", a + 1)
    return "\n".join(lines[a:b]).strip()


def _names(node):
    out = []
    for n in ast.walk(node):
        if isinstance(n, ast.Attribute):
            parts, cur = [], n
            while isinstance(cur, ast.Attribute):
                parts.append(cur.attr)
                cur = cur.value
            if isinstance(cur, ast.Name):
                parts.append(cur.id)
                out.append(".".join(reversed(parts)))
        elif isinstance(n, ast.Name):
            out.append(n.id)
    seen, res = set(), []
    for x in out:
        if x not in seen:
            seen.add(x)
            res.append(x)
    return res


def _parents(tree):
    pm = {}
    for parent in ast.walk(tree):
        for child in ast.iter_child_nodes(parent):
            pm[child] = parent
    return pm


def _guards(node, pm, src, lines, stop_at=None):
    """收集把 node 包住的所有条件，从外到内。"""
    chain, cur, child = [], pm.get(node), node
    while cur is not None and cur is not stop_at:
        if isinstance(cur, ast.If):
            branch = "then"
            if any(child is s or child in ast.walk(s) for s in cur.orelse):
                branch = "else"
            chain.append({"kind": "if", "line": cur.lineno, "branch": branch,
                          "test": _src_seg(src, cur.test, lines), "names": _names(cur.test),
                          "_node": cur.test})
        elif isinstance(cur, (ast.While,)):
            chain.append({"kind": "while", "line": cur.lineno, "branch": "body",
                          "test": _src_seg(src, cur.test, lines), "names": _names(cur.test),
                          "_node": cur.test})
        elif isinstance(cur, ast.For):
            chain.append({"kind": "for", "line": cur.lineno, "branch": "body",
                          "test": _src_seg(src, cur.iter, lines), "names": _names(cur.iter)})
        elif isinstance(cur, ast.Try):
            chain.append({"kind": "try", "line": cur.lineno, "branch": "body",
                          "test": "(exception path)", "names": []})
        child = cur
        cur = pm.get(cur)
    return list(reversed(chain))


def _defs_of(funcnode, name, src, lines):
    """在函数体里找 name 的赋值处 —— 判据 tensor 是谁算出来的。"""
    base = name.split(".")[0]
    out = []
    for n in ast.walk(funcnode):
        targets = []
        if isinstance(n, ast.Assign):
            targets = n.targets
        elif isinstance(n, (ast.AnnAssign, ast.AugAssign)):
            targets = [n.target]
        elif isinstance(n, (ast.For,)):
            targets = [n.target]
        else:
            continue
        for t in targets:
            for nm in _names(t):
                if nm == name or nm.split(".")[0] == base:
                    out.append({"line": n.lineno, "src": _src_seg(src, n, lines)[:200]})
                    break
    return out[:6]


# 一个名字如果由这些东西算出来，就认为它带着"设备数值"的味道
TAINT_SOURCE = re.compile(
    r"all_reduce|allreduce|all_gather|reduce_scatter|dist\.|torch\.distributed|"
    r"l2_norm|multi_tensor|\.norm\(|\.grad\b|\.sum\(|\.mean\(|\.max\(|\.min\(|\.abs\(|"
    r"float_status|found_inf|get_grad_norm|clip_coeff|\.item\(\)|\.cpu\(\)|\.tolist\(\)|"
    r"torch\.tensor|topk|softmax|argmax|nonzero", re.I)  # 注意：.shape/.size() 属于元数据，见 SHAPE_META_PAT

BUILTIN_NAMES = {"isinstance", "len", "bool", "int", "float", "str", "max", "min", "sum",
                 "any", "all", "type", "getattr", "hasattr", "torch", "np", "abs", "print",
                 "range", "enumerate", "list", "dict", "set", "tuple", "None", "True", "False"}

_RE_STR_COMPARE = re.compile(r"^[ ]*[\w.]+[ ]*[=!]=[ ]*[\"'][^\"']*[\"'][ ]*$")
_RE_STR_MEMBER = re.compile(r'''^\s*["'][^"']*["']\s+(not\s+)?in\s+[\w.()\[\]]+\s*$''')
_RE_STR_LIT = re.compile(chr(34) + "[^" + chr(34) + "]*" + chr(34) + "|" + chr(39) + "[^" + chr(39) + "]*" + chr(39))
_RE_PURE_ISINSTANCE = re.compile(r"^\s*(not\s+)?isinstance\s*\(", re.I)


class FuncCtx(object):
    """函数内的轻量数据流：判据里的名字最终是不是从设备值算出来的。

    只看单个函数体，不做跨函数分析——够用了，因为分支和它的判据几乎总是写在一起，
    而跨函数的部分由 pa_pytrace.py 的调用边负责串起来。
    """

    def __init__(self, funcnode, src, lines):
        self.defs = {}
        self._memo = {}
        self.params = set()
        if funcnode is None:
            return
        aa = funcnode.args
        for a in list(aa.args) + list(aa.posonlyargs) + list(aa.kwonlyargs):
            self.params.add(a.arg)
        if aa.vararg:
            self.params.add(aa.vararg.arg)
        if aa.kwarg:
            self.params.add(aa.kwarg.arg)
        for n in ast.walk(funcnode):
            targets = []
            if isinstance(n, ast.Assign):
                targets = n.targets
            elif isinstance(n, (ast.AnnAssign, ast.AugAssign)):
                targets = [n.target]
            elif isinstance(n, ast.For):
                targets = [n.target]
            else:
                continue
            seg = _src_seg(src, n, lines)
            for t in targets:
                for nm in _names(t):
                    self.defs.setdefault(nm.split(".")[0], []).append(
                        {"line": n.lineno, "src": seg[:200]})

    def taint_kind(self, name, depth=0):
        """返回 'num'（判据最终来自设备数值）/ 'meta'（只来自形状等元数据）/ None。

        只有一个布尔的话，`is_causal = q.shape[2] > 1 and mask is None` 会被判成
        『依赖设备数值』，然后 `if is_causal:` 顶到 🔴——但它其实只跟形状有关，
        仿真数值再准也照样翻。分成两种污点才能把这类判据放到正确的档位。
        """
        base = name.split(".")[0]
        if base in BUILTIN_NAMES or depth > 3:
            return None
        if base in self._memo:
            return self._memo[base]
        self._memo[base] = None
        res = None
        for d in self.defs.get(base, []):
            src = d["src"]
            if DEVICE_VALUE_PAT.search(src) or _CAST_ON_TENSOR.search(src) or TAINT_SOURCE.search(src):
                res = "num"
                break
            if SHAPE_META_PAT.search(src) or SHAPE_META_NAME.search(src):
                res = "meta"
                continue
            rhs = src.split("=", 1)[-1]
            for nm in (_names(ast.parse(rhs.strip()).body[0]) if _safe(rhs) else []):
                k = self.taint_kind(nm, depth + 1)
                if k == "num":
                    res = "num"
                    break
                if k == "meta" and res is None:
                    res = "meta"
            if res == "num":
                break
        self._memo[base] = res
        return res

    def taint_kind_why(self, name):
        """(kind, 触发它的那行源码)，用于把定级依据讲清楚。"""
        base = name.split(".")[0]
        k = self.taint_kind(name)
        if k != "num":
            return k, None
        for d in self.defs.get(base, []):
            if DEVICE_VALUE_PAT.search(d["src"]) or _CAST_ON_TENSOR.search(d["src"])                     or TAINT_SOURCE.search(d["src"]):
                return k, d["src"]
        return k, "（经由其他变量间接传入）"

    def tainted(self, name, depth=0):
        return self.taint_kind(name, depth) is not None

    def defs_of(self, name):
        return self.defs.get(name.split(".")[0], [])[:4]


def _safe(expr):
    try:
        ast.parse(expr.strip())
        return True
    except Exception:
        return False


# 形状 / 长度类判据：`x.ndim`、`t.shape[0]`、`seq_len`、`actual_seq_len`…
# 它们是 host 侧的元数据，不需要把设备数值搬回来，所以不是"数值翻转"；但只要两侧的输入长度
# 或 padding 策略不同，它们就会翻——在真机 394/400、仿真 640 这种场景里，这类分支恰恰是
# 最该看的一档，所以单独分一级，不要和设备数值混在一起。
# 表达式里出现这些 = 形状/元数据判定（host 侧就能拿到，不需要 D2H）
SHAPE_META_PAT = re.compile(
    r"[.]ndim|[.]shape|[.]size[(]|[.]dim[(]|[.]numel[(]|[.]dtype|[.]device|len[(]|"
    r"seq_len|seqlen|actual_seq|num_tokens|n_tokens|padding|pad_|max_len|position_ids|"
    r"layout[ ]*[=!]=|is[ ]+(not[ ]+)?None", re.I)
# 名字本身像形状/长度（用于判据变量名匹配）。故意不含 layout：`ALL_ATTENTION_LAYOUT`
# 这类常量名会误伤，layout 只在表达式里直接比较字面量时才算形状判定。
SHAPE_META_NAME = re.compile(
    r"[.]ndim$|[.]shape|[.]dtype|[.]device$|seq_len|seqlen|actual_seq|num_tokens|"
    r"n_tokens|max_len|position_ids|_len$|_size$", re.I)


def _is_pure_existence(t):
    """整个判据只由 `X is [not] None` 和 and/or 组成 ⇒ 判的是"传没传"，不是"值多少"。

    这类判据即使变量沾了设备数值的污点也不会因为数值偏差翻转（`attention_mask` 是不是 None，
    跟它里面的数是多少无关），所以要在污点传播之前拦下来，否则会被误顶到 🔴。
    """
    ident = "[" + chr(92) + "w." + chr(92) + "[" + chr(92) + "]()]+"
    x = re.sub(ident + chr(92) + "s+is" + chr(92) + "s+not" + chr(92) + "s+None", "T", t)
    x = re.sub(ident + chr(92) + "s+is" + chr(92) + "s+None", "T", x)
    x = re.sub("[()" + chr(92) + "s]|and|or|not|T|" + chr(92) + "^", "", x)
    return x == "" and "is" in t


def _sensitivity(test_src, names, ctx=None):
    """返回 (等级, 定级依据)。3 = 设备数值，2 = 形状/长度，1 = 其他运行时值，0 = 静态配置。

    每一档都附上理由：这套启发式一定会有误判，能自己说明"我为什么这么判"，
    误判才能被一眼看出来并纠正，而不是让人反推半天。
    """
    t = test_src or ""
    m = DEVICE_VALUE_PAT.search(t) or _CAST_ON_TENSOR.search(t)
    if m:
        return 3, "判据里直接出现 `%s`，设备值被取到 host" % m.group(0)[:40]
    t_nolit = _RE_STR_LIT.sub('""', t)
    if (_RE_STR_COMPARE.match(t) or _RE_STR_MEMBER.match(t)) and not SHAPE_META_PAT.search(t_nolit):
        return 1, "跟字符串字面量比较/判键存在性，属于分派而非数值判定"
    if _RE_PURE_ISINSTANCE.match(t):
        return 1, "类型分派（isinstance），翻转原因是类型不是数值"
    if _is_pure_existence(t):
        return 2, "纯存在性判定（is None），取决于调用方传了什么，与数值无关"
    shapey = bool(SHAPE_META_PAT.search(t)) or any(SHAPE_META_NAME.search(n) for n in names)
    if ctx is not None:
        for n in names:
            k, src = ctx.taint_kind_why(n)
            if k == "num":
                return 3, "判据变量 `%s` 由 `%s` 产生，带设备数值" % (n, (src or "")[:60])
        if any(ctx.taint_kind(n) == "meta" for n in names):
            return 2, "判据变量由形状/元数据算出"
    if shapey:
        return 2, "判据本身是形状/长度/dtype 判定"
    real_names = [n for n in names if n.split(".")[0] not in BUILTIN_NAMES]
    if real_names and all(CONFIG_NAME.match(n) for n in real_names):
        return 0, "判据全部来自 args/config，由启动参数决定"
    if any(TENSORISH_NAME.search(n) for n in real_names):
        return 1, "变量名看起来与张量相关，但查不到设备来源"
    return 0, "没有发现与设备数值或形状的关联"



# --------------------------------------------------------------------------
# 变量的完整来源链 & 让仿真走到另一侧需要满足什么
# --------------------------------------------------------------------------


def origin_paths(ctx, name, max_paths=8, max_depth=8):
    """把 name 在**本函数内**的所有来源路径全枚举出来，直到根。

    只给最近一层赋值是不够用的：`clip_coeff` 上一层是 `max_norm / (total_norm + eps)`，
    真正要盯的是再往上的 `total_norm` 是谁算的。一路回溯到根（函数参数 / 外部作用域 /
    调用返回值 / 字面量），才能知道该去哪个环节比对数值。
    """
    paths = []

    def root_kind(var):
        base = var.split(".")[0]
        if base in ("self", "cls"):
            return "self 属性/方法（非数据来源）"
        if base in ctx.params:
            return "函数参数（要往调用方追）"
        if base in ctx.defs:
            return "本函数内赋值(已到深度上限)"
        return "外层作用域/全局/常量"

    def walk(var, chain, depth, seen):
        if len(paths) >= max_paths:
            return
        base = var.split(".")[0]
        defs = ctx.defs.get(base) or []
        if not defs or depth >= max_depth or base in seen:
            paths.append(chain + [{"var": var, "line": None, "src": None,
                                   "root": root_kind(var)}])
            return
        for d in defs:
            rhs = d["src"].split("=", 1)[-1]
            step = {"var": var, "line": d["line"], "src": d["src"], "root": None}
            sub = []
            if _safe(rhs):
                for nm in _names(ast.parse(rhs.strip()).body[0]):
                    b = nm.split(".")[0]
                    # 只跟数据走：`self.embed` / `self.get_xxx` 是方法调用，不是数据来源；
                    # 而且要按 base 归一，否则 `x` 和 `x.sum` 会被当成两个变量，
                    # 同一条链会分叉成好几条一模一样的路径。
                    if b in BUILTIN_NAMES or b == base or b in ("self", "cls"):
                        continue
                    if b not in sub:
                        sub.append(b)
            if not sub:
                paths.append(chain + [step] + [{"var": "", "line": None, "src": None,
                                                "root": "字面量 / 调用返回值 / 常量"}])
            else:
                for nm in sub[:3]:
                    walk(nm, chain + [step], depth + 1, seen | {base})
            if len(paths) >= max_paths:
                return

    walk(name.split(".")[0], [], 0, set())
    # 同一条链可能被不同写法走出来，按渲染文本去重
    seen, uniq = set(), []
    for pth in paths:
        key = tuple((x["var"], x["line"], x["root"]) for x in pth)
        if key not in seen:
            seen.add(key)
            uniq.append(pth)
    return uniq[:max_paths]


def render_origins(ctx, names, limit_vars=3):
    L = []
    done = set()
    for nm in names[:limit_vars + 3]:
        base = nm.split(".")[0]
        if base in ("self", "cls") or base in done or len(done) >= limit_vars:
            continue
        done.add(base)
        ps = origin_paths(ctx, base)
        if not ps:
            continue
        L.append("  - `%s` 在本函数内的全部来源路径（到根为止；根是函数参数就要继续往调用方追）：" % base)
        for i, path in enumerate(ps, 1):
            parts = []
            for stp in path:
                if stp["line"] is not None:
                    parts.append("`%s` ←L%d `%s`" % (stp["var"], stp["line"], stp["src"][:70]))
                elif stp["root"]:
                    parts.append("【根：%s%s】" % (stp["root"],
                                                 ("：" + stp["var"]) if stp["var"] else ""))
            L.append("    %d. %s" % (i, "  ←  ".join(parts)))
    return L


_CMP_FLIP = {ast.Eq: "!=", ast.NotEq: "==", ast.Lt: ">=", ast.LtE: ">",
             ast.Gt: "<=", ast.GtE: "<", ast.Is: "is not", ast.IsNot: "is",
             ast.In: "not in", ast.NotIn: "in"}
_CMP_KEEP = {ast.Eq: "==", ast.NotEq: "!=", ast.Lt: "<", ast.LtE: "<=",
             ast.Gt: ">", ast.GtE: ">=", ast.Is: "is", ast.IsNot: "is not",
             ast.In: "in", ast.NotIn: "not in"}


def _negate(node, src, lines):
    """取反并化简成人能照着改的形式，而不是套一层 not(...)。"""
    if isinstance(node, ast.UnaryOp) and isinstance(node.op, ast.Not):
        return _src_seg(src, node.operand, lines)
    if isinstance(node, ast.Compare) and len(node.ops) == 1:
        op = type(node.ops[0])
        if op in _CMP_FLIP:
            return "%s %s %s" % (_src_seg(src, node.left, lines), _CMP_FLIP[op],
                                 _src_seg(src, node.comparators[0], lines))
    if isinstance(node, ast.BoolOp):
        parts = [_negate(v, src, lines) for v in node.values]
        if isinstance(node.op, ast.And):
            return "以下至少一条成立： " + " ｜ ".join(parts)
        return "以下全部成立： " + " 且 ".join(parts)
    return "not (%s)" % _src_seg(src, node, lines)


def _cmp_requirements(node, src, lines, flip):
    """把判据拆成逐个比较，给出每个变量必须满足什么。"""
    out = []
    for n in ast.walk(node):
        if not isinstance(n, ast.Compare) or len(n.ops) != 1:
            continue
        op = type(n.ops[0])
        table = _CMP_FLIP if flip else _CMP_KEEP
        if op not in table:
            continue
        left = _src_seg(src, n.left, lines)
        right = _src_seg(src, n.comparators[0], lines)
        out.append("`%s` 必须 `%s %s`" % (left[:60], table[op], right[:60]))
    if not out:
        expr = _src_seg(src, node, lines)
        out.append("`%s` 必须为 %s" % (expr[:80], "假" if flip else "真"))
    return out


def branch_conditions(testnode, src, lines):
    """返回 {'then': (条件, [逐变量要求]), 'else': (...)}。

    报告里最缺的一环就是这个：知道两侧走了不同分支之后，下一句话应该是
    "要让仿真也走真机那一侧，这个变量得满足什么" —— 否则修不动。
    """
    return {
        "then": (_src_seg(src, testnode, lines), _cmp_requirements(testnode, src, lines, False)),
        "else": (_negate(testnode, src, lines), _cmp_requirements(testnode, src, lines, True)),
    }


SENS_LABEL = {3: "🔴 依赖设备数值（数值一偏就翻转）",
              2: "🟠 依赖形状/序列长度（两侧输入长度不同就会翻转）",
              1: "🟡 可能依赖运行时数值",
              0: "⚪ 看起来是静态配置"}
SENS_ICON = {3: "🔴", 2: "🟠", 1: "🟡", 0: "⚪"}


def load_file(path):
    with open(path, "r", encoding="utf-8", errors="replace") as fh:
        src = fh.read()
    return src, src.splitlines(), ast.parse(src)


def find_callsites(path, func_name, callee, context=0):
    src, lines, tree = load_file(path)
    pm = _parents(tree)
    funcs = [n for n in ast.walk(tree)
             if isinstance(n, (ast.FunctionDef, ast.AsyncFunctionDef))
             and (not func_name or n.name == func_name)]
    cal = (callee or "").split(".")[-1]
    hits = []
    for fn in funcs:
        nodes = []
        for n in ast.walk(fn):
            if isinstance(n, ast.Call):
                target = n.func
                nm = target.attr if isinstance(target, ast.Attribute) else getattr(target, "id", "")
                if not cal or nm == cal:
                    nodes.append(n)
        if cal and not nodes:
            # trace 里的"被调用者"未必是显式的 Call：属性访问（`grad.device_mesh`）、
            # 上下文管理器（`__enter__`）、装饰器包装（`wrapper`）都会以函数事件出现。
            # 退一步按名字出现的位置找，一样能拿到守卫条件。
            for n in ast.walk(fn):
                if isinstance(n, ast.Attribute) and n.attr == cal:
                    nodes.append(n)
                elif isinstance(n, ast.Name) and n.id == cal:
                    nodes.append(n)
        ctx = FuncCtx(fn, src, lines) if nodes else None
        for n in nodes:
            guards = _guards(n, pm, src, lines, stop_at=fn)
            for g in guards:
                g["names"] = [x for x in g["names"] if x.split(".")[0] not in BUILTIN_NAMES]
                g["sensitivity"], g["why"] = _sensitivity(g["test"], g["names"], ctx)
                if g.get("_node") is not None and ctx is not None:
                    bc = branch_conditions(g["_node"], src, lines)
                    want = "then" if g["branch"] in ("then", "body") else "else"
                    g["cond_txt"], g["cond_reqs"] = bc[want]
                    g["origins"] = ["  " + x for x in render_origins(ctx, g["names"], 2)]
            hits.append({
                "file": path, "func": fn.name, "func_line": fn.lineno,
                "call_line": n.lineno, "call_src": _src_seg(src, n, lines)[:200],
                "guards": guards,
                "guard_defs": {g["line"]: {nm2: ctx.defs_of(nm2) for nm2 in g["names"][:6]}
                               for g in guards},
                "context": _context(lines, n.lineno, context) if context else "",
            })
    return hits, src, lines


def _context(lines, line, n):
    a, b = max(0, line - 1 - n), min(len(lines), line + n)
    return "\n".join("%5d | %s" % (i + 1, lines[i]) for i in range(a, b))


def scan_branches(path, func_name=None, context=0):
    src, lines, tree = load_file(path)
    pm = _parents(tree)
    out = []
    for n in ast.walk(tree):
        if not isinstance(n, (ast.If, ast.While, ast.IfExp)):
            continue
        fn = None
        cur = pm.get(n)
        while cur is not None:
            if isinstance(cur, (ast.FunctionDef, ast.AsyncFunctionDef)):
                fn = cur
                break
            cur = pm.get(cur)
        if func_name and (fn is None or fn.name != func_name):
            continue
        test_src = _src_seg(src, n.test, lines)
        names = [x for x in _names(n.test) if x.split(".")[0] not in BUILTIN_NAMES]
        ctx = FuncCtx(fn, src, lines)
        sens, why = _sensitivity(test_src, names, ctx)
        conds = branch_conditions(n.test, src, lines) if isinstance(n, (ast.If, ast.While)) else None
        out.append({
            "file": path, "func": fn.name if fn else "(module)",
            "def_line": fn.lineno if fn else None,
            "line": n.lineno, "kind": type(n).__name__,
            "test": test_src[:220], "names": names[:10], "sensitivity": sens, "why": why,
            "conds": conds, "origins": render_origins(ctx, names),
            "tainted": [nm for nm in names[:8] if ctx.tainted(nm)],
            "defs": {nm: ctx.defs_of(nm) for nm in names[:5]},
            "context": _context(lines, n.lineno, context) if context else "",
        })
    out.sort(key=lambda x: (-x["sensitivity"], x["line"]))
    return out


# --------------------------------------------------------------------------


def md_callsites(hits, title):
    L = ["## %s" % title, ""]
    if not hits:
        L += ["(没有找到调用点：函数名/被调用名可能对不上，或者调用发生在别的文件里)", ""]
        return L
    for h in hits:
        L.append("### `%s` 第 %d 行 → `%s`" % (h["func"], h["call_line"], h["call_src"][:80]))
        L.append("")
        if not h["guards"]:
            L += ["- **无条件调用**：这个调用不在任何 if 里，次数差异来自更上层的 caller。", ""]
            continue
        L.append("守卫条件链（从外到内）：")
        L.append("")
        for g in h["guards"]:
            sens = g.get("sensitivity", 0)
            L.append("- L%d `%s (%s)` 走 **%s** 分支 — %s" % (
                g["line"], g["kind"], g["test"][:150], g["branch"], SENS_LABEL[sens]))
            if g.get("why"):
                L.append("  - 定级依据: %s" % g["why"])
            if g.get("cond_txt"):
                L.append("  - **要让仿真也走到这个调用**，需满足：`%s`" % g["cond_txt"][:150])
                for req in (g.get("cond_reqs") or [])[:4]:
                    L.append("    - %s" % req)
            L += g.get("origins") or []
            for nm in g["names"][:6]:
                defs = h["guard_defs"].get(g["line"], {}).get(nm) or []
                if defs:
                    L.append("  - 判据变量 `%s` 定义于: %s" % (
                        nm, "; ".join("L%d `%s`" % (d["line"], d["src"][:90]) for d in defs[:2])))
                else:
                    L.append("  - 判据变量 `%s`（来自参数或外层作用域）" % nm)
        L.append("")
        if h.get("context"):
            L += ["```python", h["context"], "```", ""]
    return L


def load_func_counts(pytrace_json):
    """返回 (counts, status)。status 用来把"为什么没有次数"讲清楚，而不是默默显示一列问号。

    源码里的分支只有"实际被执行过"才值得看：一个文件里往往并列着好几套实现，本次只跑了
    其中一套，其余函数的分支全是噪声。把 pa_pytrace 的执行次数带进来，就能把没跑到的沉底、
    把两侧次数不同的顶上来——次数不同意味着该函数里至少有一个分支翻了。
    """
    if not pytrace_json:
        return {}, "not_given"
    if not os.path.isfile(pytrace_json):
        return {}, "missing_file"
    try:
        with open(pytrace_json, "r", encoding="utf-8") as fh:
            d = json.load(fh)
    except Exception as exc:
        sys.stderr.write("[pa_srcbranch] cannot read %s: %s" % (pytrace_json, exc) + chr(10))
        return {}, "missing_file"
    if d.get("func_counts_usable") is False:
        return {}, "unusable"
    rows = d.get("func_counts")
    if not rows:
        return {}, "no_field"
    out, byline = {}, {}
    for e in rows:
        out.setdefault(e["func"], []).append((e["file"], e["real"], e["sim"]))
    for e in d.get("func_line_counts") or []:
        byline.setdefault((e["func"], e["line"]), []).append((e["file"], e["real"], e["sim"]))
    # 整体平移的文件里，同一个函数会被拆成 (real=n, sim=0) 和 (real=0, sim=n) 两条
    # （例如 set_actual_seq_len 真机在 105 行、仿真在 117 行）。按真机行号直接查会得到
    # "仿真 0 次"这种假信号，所以要用该文件的平移量把仿真侧行号换算回去。
    shifts = {}
    for v in d.get("file_verdicts") or []:
        if v.get("kind") != "uniform":
            continue
        m = re.search(chr(25972) + chr(20307) + chr(24179) + chr(31227) + " ([+-]?[0-9]+) ", v.get("note", ""))
        if m:
            shifts[str(v["file"]).replace(chr(92), "/").lower()] = int(m.group(1))
    # 兜底：即使没有 usable 标记，只要一侧全是 0 也说明那侧压根没采到 python_function，
    # 这时"次数不同"是采集缺失而不是分支翻转，不能拿来排序。
    tot_r = sum(r for v in out.values() for _f, r, _s in v)
    tot_s = sum(sm for v in out.values() for _f, _r, sm in v)
    if not tot_r or not tot_s:
        return {}, "unusable"
    out["__shifts__"] = shifts
    out["__byline__"] = byline
    return out, "ok"



def _file_seen(counts, path):
    """这个文件在 pytrace 里出现过吗？用来区分"没执行"和"路径没对上"。"""
    p = str(path).replace(chr(92), "/").lower()
    for key, cands in counts.items():
        if key in ("__byline__", "__shifts__"):
            continue
        for f, _r, _s in cands:
            if p.endswith(str(f).replace(chr(92), "/").lower()):
                return True
    return False


def _counts_for(counts, path, func, file_seen=None, def_line=None):
    """优先按"函数定义所在行"精确匹配。

    一个文件里同名函数往往不止一个（Qwen3VL 的 modeling_qwen3_vl.py 有 4 个 forward），
    只按函数名聚合会把"只有真机执行的那个定义"和"两侧都执行的那个"混在一起，
    结论会从『这段代码仿真根本没跑』变成『两侧都跑了、差一点点』——方向完全反了。
    """
    p0 = str(path).replace(chr(92), "/").lower()
    if def_line is not None:
        byline = counts.get("__byline__") or {}
        shifts = counts.get("__shifts__") or {}
        delta = next((dd for ff, dd in shifts.items() if p0.endswith(ff)), None)
        for f, r, s_ in byline.get((func, def_line), []):
            if not p0.endswith(str(f).replace(chr(92), "/").lower()):
                continue
            if not s_ and delta is not None:
                for f2, _r2, s2 in byline.get((func, def_line - delta), []):
                    if p0.endswith(str(f2).replace(chr(92), "/").lower()):
                        s_ = s2
                        break
            return r, s_
    cands = counts.get(func) or []
    p = p0
    for f, r, s_ in cands:
        if p.endswith(str(f).replace(chr(92), "/").lower()):
            return r, s_
    if len(cands) == 1:
        return cands[0][1], cands[0][2]
    # 文件本身出现过、只是这个函数没有条目 ⇒ 两侧都没执行到（写 0/0 比写 ? 准确得多，
    # 因为 ? 会让人以为是工具没查到，从而继续分析一堆根本没跑的分支）
    if file_seen:
        return 0, 0
    return None



def _counts_note(counts, status):
    if counts:
        return ("**次数 real/sim** 来自 pa_pytrace：`未执行` = 该函数两侧都没跑到，它的分支是噪声；"
                "两侧次数不同的已排到最前，说明该函数里至少有一个分支翻了。")
    if status == "unusable":
        return ("> ⚠️ pytrace json 里有一侧**完全没有 python_function 事件**（采集时没开 "
                "`with_stack=True`），所有函数在那一侧的次数都会是 0。这种『次数不同』是"
                "**采集缺失**、不是分支翻转，所以已经忽略执行次数。"
                "先把那一侧重采（`with_stack=True, with_modules=True, record_shapes=True`）再来。")
    if status == "no_field":
        return ("> ⚠️ 传进来的 pytrace json 里没有 `func_counts` 字段，说明它是**旧版 pa_pytrace "
                "生成的**。下面的排序没有用到执行次数——请用当前版本重跑一次 pa_pytrace 再来，"
                "否则你可能在分析两侧都没执行到的分支。")
    if status == "missing_file":
        return "> ⚠️ `--pytrace` 指向的文件不存在，已忽略。"
    return ""


def md_scan(rows, path, limit=80, func=None, counts=None, counts_status=None):
    if not rows:
        who = ("函数 `%s`" % func) if func else "这个文件"
        return ["## 文件分支清单: `%s`" % path, "",
                "**%s 里没有任何 if/while 分支。**这不是分析失败——它说明两侧在这里的差异"
                "不是本函数的分支造成的，而是**调用方**传进来的东西不同（长度、shape、"
                "是否为 None）。往上一层看：用 pa_pytrace 第 4 节找到谁调用了它，"
                "再对那个调用方跑 --scan-func。" % who, ""]
    if counts:
        seen = _file_seen(counts, rows[0]["file"]) if rows else False
        for r in rows:
            r["exec"] = _counts_for(counts, r["file"], r["func"], seen, r.get("def_line"))

        def _key(r):
            c = r.get("exec")
            differ = 0 if (c and c[0] != c[1]) else 1
            ran = 0 if (c and (c[0] or c[1])) else 1
            return (differ, ran, -r["sensitivity"], r["line"])
        rows = sorted(rows, key=_key)

    L = ["## 文件分支清单: `%s`" % path, "",
         "按敏感度排序：🔴 判据来自设备数值（数值一偏就翻）；"
         "🟠 判据是形状/序列长度（两侧输入长度或 padding 不同就会翻，"
         "真机 394/400 vs 仿真 640 这种场景要重点看这一档）；"
         "🟡 其他运行时值；⚪ 由启动参数决定，两侧配置一致时不会分叉。", "",
         _counts_note(counts, counts_status), "",
         ("| 敏感度 | 次数 real/sim | 位置 | 函数 | 判据 | 判据变量 |" if counts
          else "| 敏感度 | 位置 | 函数 | 判据 | 判据变量 |"),
         ("| --- | --- | --- | --- | --- | --- |" if counts
          else "| --- | --- | --- | --- | --- |")]
    for r in rows[:limit]:
        cells = [SENS_ICON[r["sensitivity"]]]
        if counts:
            c = r.get("exec")
            cells.append("?" if not c else "未执行" if not (c[0] or c[1])
                         else "**%d / %d**" % c if c[0] != c[1] else "%d / %d" % c)
        cells += ["L%d" % r["line"], "`%s`" % r["func"],
                  "`%s`" % r["test"].replace(chr(10), " ")[:110],
                  ", ".join("`%s`" % n for n in r["names"][:5])]
        L.append("| " + " | ".join(cells) + " |")
    L.append("")
    hot = [r for r in rows if r["sensitivity"] >= 2][:14]
    if hot:
        L += ["### 🔴/🟠 判据变量的来源", ""]
        for r in hot:
            c = r.get("exec")
            head = "- L%d `%s`" % (r["line"], r["test"][:120])
            if c:
                head += "  （执行次数 real/sim = %s / %s）" % (c[0], c[1])
            L.append(head)
            if r.get("why"):
                L.append("  - **定级依据**: %s" % r["why"])
            cond = r.get("conds")
            if cond:
                L.append("  - **要让仿真走 then 分支**，需满足：`%s`" % cond["then"][0][:150])
                for req in cond["then"][1][:4]:
                    L.append("    - %s" % req)
                L.append("  - **要让仿真走 else 分支**，需满足：`%s`" % cond["else"][0][:150])
                for req in cond["else"][1][:4]:
                    L.append("    - %s" % req)
            L += r.get("origins") or []
        L.append("")
    return L


def main():
    force_utf8()
    ap = argparse.ArgumentParser(description=__doc__,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--repo", default="", help="仓库根目录，用于把相对路径补全")
    ap.add_argument("--file", default="")
    ap.add_argument("--func", default="")
    ap.add_argument("--callee", default="")
    ap.add_argument("--scan-file", default="")
    ap.add_argument("--scan-func", default="")
    ap.add_argument("--from-pytrace", default="", help="pa_pytrace.py 输出的 json")
    ap.add_argument("--pytrace", default="",
                    help="pa_pytrace.py 的 json：给 --scan-file 补上每个函数两侧的执行次数，"
                         "用来筛掉根本没跑到的分支")
    ap.add_argument("--max-callers", type=int, default=12)
    ap.add_argument("--context", type=int, default=6, help="打印调用点上下文行数")
    ap.add_argument("--out", default="")
    args = ap.parse_args()

    _cache = {}

    def resolve(p):
        """把 trace 里归一化过的路径还原成本地文件。

        必须按**完整后缀**匹配，不能只按文件名：仓库里 `utils.py` 有几十个，随手返回第一个
        会让后面的 AST 分析在一个毫不相关的文件里找调用点，然后报"没有找到调用点"——
        看起来像分析失败，其实是找错了文件。
        """
        if p in _cache:
            return _cache[p]
        res = ""
        norm = str(p).replace("\\", "/").lstrip("./")
        if os.path.isfile(p):
            res = p
        elif args.repo:
            q = os.path.join(args.repo, norm)
            if os.path.isfile(q):
                res = q
            else:
                tail = norm.split("/")[-1]
                exact, loose = [], []
                for dp, _dn, fns in os.walk(args.repo):
                    if tail not in fns:
                        continue
                    cand = os.path.join(dp, tail)
                    if cand.replace("\\", "/").lower().endswith(norm.lower()):
                        exact.append(cand)
                    else:
                        loose.append(cand)
                if exact:
                    res = exact[0]
                elif len(loose) == 1:
                    res = loose[0]           # 只有一个同名文件，可以放心用
                elif loose:
                    sys.stderr.write(
                        "[pa_srcbranch] %s 在仓库里有 %d 个同名文件且没有一个匹配完整路径，"
                        "跳过（用 --repo 指向更精确的根目录，或直接给绝对路径）\n"
                        % (norm, len(loose)))
        _cache[p] = res
        return res

    L = ["# 源码控制流分支分析", ""]
    if args.scan_file:
        path = resolve(args.scan_file)
        if not path:
            raise SystemExit("找不到文件: %s（试试 --repo 指向仓库根）" % args.scan_file)
        _counts, _status = load_func_counts(args.pytrace)
        L += md_scan(scan_branches(path, args.scan_func or None, args.context), path,
                     func=args.scan_func or None, counts=_counts, counts_status=_status)
    elif args.file:
        path = resolve(args.file)
        if not path:
            raise SystemExit("找不到文件: %s（试试 --repo 指向仓库根）" % args.file)
        hits, _, _ = find_callsites(path, args.func or None, args.callee, args.context)
        if hits:
            L += md_callsites(hits, "`%s` 中对 `%s` 的调用" % (os.path.basename(path), args.callee))
        else:
            L += ["## `%s` 里找不到 `%s` 的引用，改为列出该函数的全部分支" % (
                os.path.basename(path), args.callee), ""]
            L += md_scan(scan_branches(path, args.func or None, args.context), path,
                         func=args.func or None)
    elif args.from_pytrace:
        with open(args.from_pytrace, "r", encoding="utf-8") as fh:
            pt = json.load(fh)
        seen, done, missing = set(), 0, set()
        for e in (pt.get("call_edges") or []) + (pt.get("op_edges") or []):
            if done >= args.max_callers:
                break
            key = (e["caller_file"], e["caller_func"], e.get("callee_func") or e.get("op"))
            if key in seen:
                continue
            seen.add(key)
            path = resolve(e["caller_file"])
            if not path:
                if e["caller_file"] not in missing:
                    missing.add(e["caller_file"])
                    L += ["## `%s`" % e["caller_file"], "",
                          "(仓库里找不到这个文件，跳过；该文件的其他候选边也一并跳过)", ""]
                continue
            callee = e.get("callee_func") or ""
            hits = []
            if callee:
                hits, _, _ = find_callsites(path, e["caller_func"], callee, args.context)
            if hits:
                L += md_callsites(hits, "`%s::%s` → `%s`（real %s / sim %s）" % (
                    os.path.basename(path), e["caller_func"], callee, e["real"], e["sim"]))
            else:
                # 找不到显式引用时不要空手而归：把这个函数里的分支全列出来，
                # 调用次数的差异一定是其中某一个造成的。
                rows = scan_branches(path, e["caller_func"], args.context)
                L += md_scan(rows, "%s::%s（%s: real %s / sim %s）" % (
                    path, e["caller_func"], callee or e.get("op"), e["real"], e["sim"]),
                    limit=25, func=e["caller_func"])
            done += 1
    else:
        ap.error("需要 --file / --scan-file / --from-pytrace 之一")

    md = "\n".join(L)
    print(md)
    if args.out:
        os.makedirs(os.path.dirname(os.path.abspath(args.out)) or ".", exist_ok=True)
        with open(args.out, "w", encoding="utf-8") as fh:
            fh.write(md)
        print("\nwrote %s" % args.out, file=sys.stderr)


if __name__ == "__main__":
    main()

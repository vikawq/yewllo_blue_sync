#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""pa_pytrace.py -- 从两侧 trace 的 Python 调用树里把控制流差异全量枚举出来。

    python pa_pytrace.py --real REAL/trace_view.json --sim SIM/trace_view.json \\
        --repo D:/code/MindSpeed-MM --out out/pytrace.md

为什么这一步比逐个算子对齐更接近答案
------------------------------------
`with_stack=True` 时 torch profiler 会给每次 Python 调用发一个事件，名字就是
`/path/file.py(123): func`，并且天然按调用关系嵌套。把两侧的调用树各建一遍再做差，
得到的东西正是我们要找的：

- 只在真机出现的函数 = 仿真**没走到**的代码路径
- 只在仿真出现的函数 = 仿真器的桩/替换实现（`*_mock`、`simulator_patch/*` 之类）
- 同名函数行号不同 = 两侧装的**不是同一个版本**的库或 patch
- caller→callee 调用次数不同 = caller 里有一个 `if`/循环走了不同的分支
- caller→算子 数量不同 = 这个分支**具体多发/少发了哪些算子**

最后一条把"分支"和"算子"直接连了起来，不需要再靠猜。第 4 节的每一行都是一个候选分支，
把它喂给 pa_srcbranch.py 就能拿到判据表达式和涉及的变量/tensor 名。
"""
from __future__ import annotations

import argparse
import os
import re
import sys
from collections import Counter, defaultdict

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from pa_common import (force_utf8, load_trace, parse_pyfunc, norm_pypath,  # noqa: E402
                       normalize_name, find_steps, write_json, shape_of)

STUB_HINT = re.compile(r"mock|stub|fake|dummy|simulat|sim_|_sim\b|noop|bypass|skip", re.I)

# python_function 事件里混着大量 `<built-in function isinstance>` 这类伪事件。它们不是算子，
# 数量又极大，会把"分支 ⇄ 算子"那张表整个淹掉，所以默认剔除。
BUILTIN_EV = re.compile(r"^<(built-in|method|genexpr|listcomp|setcomp|dictcomp|lambda|module)|"
                        r"object at 0x", re.I)

# 解释器/标准库：两侧 Python 小版本不同就会整片行号偏移，属于纯噪声
RUNTIME_LIB = re.compile(
    r"^(os|posixpath|ntpath|re|typing|functools|inspect|dataclasses|enum|abc|copy|json|logging|"
    r"threading|queue|weakref|_weakrefset|_collections_abc|collections|contextlib|traceback|"
    r"warnings|importlib|pickle|socket|selectors|random|time|types|tempfile|shutil|"
    r"multiprocessing|concurrent|asyncio|unittest|site|sysconfig|tqdm)([/\\]|\.py$)", re.I)

FRAMEWORK_LIB = re.compile(r"^(torch|torch_npu|megatron|mindspeed|apex|transformers|datasets|"
                           r"accelerate|numpy|deepspeed|safetensors|einops)([/\\]|\.py$)", re.I)


def _tier(path, repo_markers):
    """model = 自己能改的代码；framework = 框架/驱动；runtime = 解释器与标准库。"""
    p = str(path).replace("\\", "/").lower().lstrip("./")
    if any(m and m in p for m in repo_markers):
        return "model"
    if RUNTIME_LIB.match(p):
        return "runtime"
    if FRAMEWORK_LIB.match(p):
        return "framework"
    return "model"


TIER_RANK = {"model": 0, "framework": 1, "runtime": 2}


def _cell(s, width=70):
    """markdown 表格单元格：shape 字符串里带换行和分号，不处理会把表格冲垮。"""
    s = re.sub(r"[\r\n]+", " ", str(s))
    s = re.sub(r"\s*;\s*", "; ", s).strip().strip(";").strip()
    s = s.replace("|", "\\|")
    return (s[:width] + "…") if len(s) > width else (s or "-")


def build_calltree(trace, roots, t0=None, t1=None, keep_builtins=False):
    """返回 (sites, edges, op_edges, examples)

    sites:    (file, func) -> Counter{line: n}
    edges:    ((file, func), (file, func)) -> n          父函数调用子函数
    op_edges: ((file, func), op_name)      -> n          父函数直接下发的算子
    """
    sites = defaultdict(Counter)
    edges = Counter()
    op_edges = Counter()
    examples = {}
    shapes = defaultdict(Counter)
    n_py = 0

    for tk in trace.tracks_by_side("host"):
        stack = []                       # [(end_ts, key, ev)] 只放 pyfunc
        for ev in tk.events:
            ts, end = ev["ts"], ev["ts"] + ev["dur"]
            while stack and stack[-1][0] <= ts:
                stack.pop()
            pf = parse_pyfunc(ev["name"])
            parent = stack[-1][1] if stack else None
            if pf:
                n_py += 1
                f, line, fn = pf
                key = (norm_pypath(f, roots), fn)
                sites[key][line] += 1
                if parent is not None:
                    edges[(parent, key)] += 1
                examples.setdefault(key, ev["uid"])
                stack.append((end, key, ev))
            elif parent is not None:
                op = normalize_name(ev["name"])
                if not keep_builtins and BUILTIN_EV.search(op):
                    continue
                op_edges[(parent, op)] += 1
                sh = shape_of(ev)
                if sh:
                    shapes[(parent, op)][sh] += 1
    return {"sites": sites, "edges": edges, "op_edges": op_edges,
            "examples": examples, "shapes": shapes, "n_py": n_py}


# 关键算子：仿真"跑不到某个融合算子"是最常见也最要命的一类失真（例如显存受限导致
# H2D 拷贝失效 → 输入没搬上device → 走不到 FlashAttention 的融合分支）。这类问题埋在几百行
# 差异表里根本看不见，所以单独做一张一眼可见的对照表。
KEY_OP_GROUPS = [
    ("注意力(融合)", r"flashattention|fusionattention|npu_fusion_attention|attentionscore|"
                     r"promptattention|increflashattention|pagedattention"),
    ("矩阵乘", r"matmul|gemm|groupedmatmul|batchmatmul|addmm|(?:::|_|^)mm(?:_|$)|conv"),
    ("归一化", r"rmsnorm|layernorm|batchnorm"),
    ("激活", r"swish|silu|gelu|swiglu|relu"),
    ("通信", r"hcom_|allgather|all_gather|allreduce|all_reduce|reducescatter|alltoall|"
             r"broadcast|batchsendrecv"),
    ("H2D/D2H 拷贝", r"memcpy|foreachcopy|foreach_copy|inplacecopy|aten::to$|aten::copy_|_to_copy"),
    ("优化器", r"applyadam|adamw|foreachadd|foreachmul|clipbynorm"),
    ("同步/事件", r"synchronize|wait_event|record_event|notify|streamwait"),
]
_COPY_OP = re.compile(r"copy|memcpy|aten::to$", re.I)
_SCALARISH = re.compile(r"^\s*(1|0|)\s*$")


def op_census(trace, t0=None, t1=None):
    """全 track（host+device）的算子直方图。build_calltree 只看挂在 Python 函数下面的事件，
    而 CANN / device 线程上的 kernel 没有 Python 父节点，会被漏掉——恰恰是它们能回答
    『那个融合算子到底走没走到』。"""
    c = Counter()
    for tk in trace.tracks.values():
        if tk.side == "derived":
            continue
        for ev in tk.events:
            if t0 is not None and not (t0 <= ev["ts"] < t1):
                continue
            nm = ev["name"]
            if parse_pyfunc(nm):
                continue
            n = normalize_name(nm)
            if BUILTIN_EV.search(n):
                continue
            c[n] += 1
    return c


def shift_analysis(moved):
    """按文件判断"行号不同"到底意味着什么。

    整份文件里所有函数偏移量一致 ⇒ 只是在文件头部增删了几行（比如 import 了一个 patch），
    代码本身是同一份，无害；偏移量五花八门 ⇒ 版本不同；同一个函数在两侧对应到不同的定义行
    ⇒ 两边执行到的是不同的函数体，这才是真正要追的信号。
    """
    by_file = defaultdict(list)
    for k, lr, ls, tier in moved:
        by_file[k[0]].append((k[1], lr, ls, tier))
    out = []
    for f, rows in sorted(by_file.items()):
        # 先用"两侧都只有一个定义"的函数定出这个文件的主偏移量
        deltas = [lr[0] - ls[0] for fn, lr, ls, _t in rows if len(lr) == 1 and len(ls) == 1]
        dominant = set(deltas)
        structural = []
        for fn, lr, ls, _t in rows:
            if len(lr) == 1 and len(ls) == 1:
                continue
            ro, so = sorted(set(lr) - set(ls)), sorted(set(ls) - set(lr))
            # 一个函数有多个定义时，如果"只出现在一侧"的那些行能被文件的主偏移量解释，
            # 那它仍然是同一份代码里的平移（典型：文件中部插了几行，前半没动、后半整体后移），
            # 不是"执行到了不同的函数体"。只有解释不掉的才算结构性差异。
            if ro and len(ro) == len(so) and dominant and                     all((a - b) in dominant for a, b in zip(ro, so)):
                deltas.extend(a - b for a, b in zip(ro, so))
                continue
            structural.append((fn, ro, so))
        if structural:
            kind, note = "structural", "两侧执行到了**不同的函数定义**"
        elif len(set(deltas)) == 1:
            kind, note = "uniform", "整体平移 %+d 行，同一份代码" % deltas[0]
        else:
            kind, note = "mixed", "偏移量不一致（%s），版本不同" % ",".join(
                str(x) for x in sorted(set(deltas))[:6])
        out.append({"file": f, "kind": kind, "note": note, "n": len(rows),
                    "tier": rows[0][3], "structural": structural[:6]})
    order = {"structural": 0, "mixed": 1, "uniform": 2}
    out.sort(key=lambda x: (order[x["kind"]], TIER_RANK.get(x["tier"], 9), x["file"]))
    return out


def _fmt_site(key):
    return "%s :: %s" % key


def _same_module(pa, pb):
    """一侧从仓库源码跑、另一侧从 site-packages 装的同一个模块，归一化后路径一长一短：
    `MindSpeed/mindspeed/core/x.py` vs `mindspeed/core/x.py`。按路径分量做后缀匹配就能认出来。
    不合并的话，同一个函数会同时出现在"只在真机"和"只在仿真"两张表里，是纯假信号。"""
    a = [x for x in str(pa).replace("\\", "/").lower().split("/") if x]
    b = [x for x in str(pb).replace("\\", "/").lower().split("/") if x]
    if not a or not b or a[-1] != b[-1]:
        return False
    n = min(len(a), len(b))
    return a[-n:] == b[-n:] and len(a) != len(b)


def reconcile(real, sim):
    """把仿真侧的 key 改写成真机侧的同名 key，返回改写了多少个。"""
    only_r = [k for k in real["sites"] if k not in sim["sites"]]
    only_s = [k for k in sim["sites"] if k not in real["sites"]]
    by_func = defaultdict(list)
    for k in only_r:
        by_func[k[1]].append(k)
    mapping = {}
    for ks in only_s:
        for kr in by_func.get(ks[1], []):
            if _same_module(kr[0], ks[0]):
                mapping[ks] = kr
                break
    if not mapping:
        return 0

    def remap(k):
        return mapping.get(k, k)

    sites = defaultdict(Counter)
    for k, v in sim["sites"].items():
        sites[remap(k)].update(v)
    edges, op_edges = Counter(), Counter()
    for (a, b), n in sim["edges"].items():
        edges[(remap(a), remap(b))] += n
    for (a, op), n in sim["op_edges"].items():
        op_edges[(remap(a), op)] += n
    shapes = defaultdict(Counter)
    for (a, op), v in sim["shapes"].items():
        shapes[(remap(a), op)].update(v)
    sim.update({"sites": sites, "edges": edges, "op_edges": op_edges, "shapes": shapes})
    return len(mapping)


THIRD_PARTY = re.compile(r"^(torch|torch_npu|numpy|apex|transformers|datasets|accelerate|"
                         r"tokenizers|safetensors|einops|_distutils|importlib|"
                         r"logging|typing|collections|json|os|re)[/\\]", re.I)


def _in_repo(key, repo_markers):
    """模型仓库里的代码优先：分歧要能落到自己能改的代码上才有用。

    显式给的 repo 名优先；没匹配上时，只要不是第三方库路径就当成模型代码——
    路径经过归一化后，模型代码通常长这样：`mindspeed_mm/training.py`。
    """
    p = key[0].lower()
    if any(m and m in p for m in repo_markers):
        return True
    return not THIRD_PARTY.match(p.lstrip("./"))


def diff(real, sim, repo_markers, top=60):
    rs, ss = real["sites"], sim["sites"]
    only_real, only_sim, moved = [], [], []
    for k, lines in rs.items():
        if k not in ss:
            only_real.append((k, sum(lines.values()), sorted(lines)))
    for k, lines in ss.items():
        if k not in rs:
            only_sim.append((k, sum(lines.values()), sorted(lines)))
    for k in set(rs) & set(ss):
        lr, ls = set(rs[k]), set(ss[k])
        if lr != ls:
            moved.append((k, sorted(lr), sorted(ls), _tier(k[0], repo_markers)))
    # 排序一律"层级优先、幅度其次"：torch_npu 内部差 876 次也不如模型代码差 1 次重要，
    # 因为只有模型代码里的分支是你能读、能改、能解释的。
    def tk(path):
        return TIER_RANK[_tier(path, repo_markers)]
    only_real.sort(key=lambda x: (tk(x[0][0]), -x[1]))
    only_sim.sort(key=lambda x: (tk(x[0][0]), -x[1]))
    moved.sort(key=lambda x: (tk(x[0][0]), x[0][0]))

    def edge_delta(re_, se_):
        out = []
        for k in set(re_) | set(se_):
            a, b = re_.get(k, 0), se_.get(k, 0)
            if a != b:
                out.append({"caller": k[0], "callee": k[1], "real": a, "sim": b, "delta": b - a,
                            "tier": _tier(k[0][0], repo_markers)})
        out.sort(key=lambda x: (TIER_RANK[x["tier"]], -abs(x["delta"])))
        return out

    return {
        "only_real": only_real[:top], "only_sim": only_sim[:top], "moved": moved[:top],
        "call_edges": edge_delta(real["edges"], sim["edges"])[:top],
        "op_edges": edge_delta(real["op_edges"], sim["op_edges"])[:top],
        "counts": {"real_py_events": real["n_py"], "sim_py_events": sim["n_py"],
                   "real_funcs": len(rs), "sim_funcs": len(ss)},
    }


def to_md(d, real_shapes, sim_shapes, repo, repo_markers, census=None, shifts=None):
    c = d["counts"]
    L = ["# Python 执行路径差异（控制流分支全量枚举）", "",
         "- real py 事件 %d / 函数 %d；sim py 事件 %d / 函数 %d" % (
             c["real_py_events"], c["real_funcs"], c["sim_py_events"], c["sim_funcs"]),
         "- repo: `%s`" % (repo or "(未指定)"), ""]
    if c["real_py_events"] == 0 or c["sim_py_events"] == 0:
        L += ["> **一侧没有 python_function 事件**，说明这份 profiling 采集时没开 `with_stack=True`。",
              "> 本分析的绝大部分能力依赖它。请重采：",
              "> `torch_npu.profiler.profile(..., with_stack=True, with_modules=True, record_shapes=True)`",
              "> 在拿到之前，只能退回到算子序列层面（pa_align.py）做粗定位。", ""]
        return "\n".join(L)

    stubs = [(k, n) for k, n, _l in d["only_sim"]
             if STUB_HINT.search(k[0]) or STUB_HINT.search(k[1])]
    moved_model = [m for m in d["moved"] if m[3] == "model"]
    moved_fw = [m for m in d["moved"] if m[3] == "framework"]
    moved_rt = [m for m in d["moved"] if m[3] == "runtime"]

    L += ["## 0. 先看这里：阻断项与仿真桩", ""]
    shifts = shifts or []
    structural = [x for x in shifts if x["kind"] == "structural"]
    mixed = [x for x in shifts if x["kind"] == "mixed"]
    uniform = [x for x in shifts if x["kind"] == "uniform"]
    st_model = [x for x in structural if x["tier"] == "model"]
    st_other = [x for x in structural if x["tier"] != "model"]
    if st_model:
        L += ["- ❗ **有 %d 个模型文件两侧执行到了不同的函数定义**——这不是行号平移，"
              "是真的走了不同的代码，优先看：" % len(st_model)]
        for x in st_model[:6]:
            det = "；".join("`%s` 真机独有行 %s / 仿真独有行 %s" % (fn, a, b)
                           for fn, a, b in x["structural"][:2])
            L.append("  - `%s`（%s）" % (x["file"], det))
    if st_other:
        L.append("- （另有 %d 个框架/标准库文件也报了结构性差异：%s，多半是版本差异的副产物，"
                 "不用先看）" % (len(st_other),
                                ", ".join(os.path.basename(x["file"]) for x in st_other[:4])))
    if uniform:
        L.append("- ✅ %d 个文件只是**整体平移**（%s 等），说明是同一份代码在头部增删了几行"
                 "（仿真侧 patch 常见），不构成阻断，行号一律以真机为准。"
                 % (len(uniform), ", ".join("%s %s" % (os.path.basename(x["file"]), x["note"])
                                            for x in uniform[:3])))
    if mixed:
        L.append("- ⚠️ %d 个文件行号偏移不一致（例如 `%s`），大概率是版本不同，属于 A 类环境差异。"
                 % (len(mixed), mixed[0]["file"]))
    if stubs:
        L.append("- 🔧 仿真器桩函数 %d 个（B 类，仿真器没实现真实逻辑，不是模型数值问题）：" % len(stubs))
        for k, n in stubs[:12]:
            L.append("  - `%s`（%d 次）" % (_fmt_site(k), n))
        L.append("  - **注意因果方向**：桩掉一段计算会连带改变后面的 shape 和序列长度，"
                 "很多看起来像『数据不一致』的现象其实是桩造成的后果，不要分别归因。")
    if not (moved_model or stubs):
        L.append("- 未发现模型代码版本差异，也未发现明显的仿真桩函数。")
    L.append("")

    if census:
        cr, cs = census
        L += ["## 0b. 关键算子存在性对照（全 track，含 device 侧）", "",
              "一侧为 0 的行是最要命的：说明那类计算在仿真里**根本没发生**，"
              "后面的一切差异都是它的下游。", "",
              "| 类别 | real | sim | 状态 |", "| --- | --- | --- | --- |"]
        for name, pat in KEY_OP_GROUPS:
            rx = re.compile(pat, re.I)
            a = sum(v for k, v in cr.items() if rx.search(k))
            b = sum(v for k, v in cs.items() if rx.search(k))
            if a == 0 and b == 0:
                continue
            if b == 0:
                st = "❗ 仿真侧完全没有"
            elif a == 0:
                st = "❗ 仅仿真侧有"
            elif abs(b - a) > 0.3 * max(a, b):
                st = "⚠️ 相差 %+.0f%%" % (100.0 * (b - a) / max(1, a))
            else:
                st = "ok"
            L.append("| %s | %d | %d | %s |" % (name, a, b, st))
        gone = [(k, v) for k, v in cr.items() if v >= 5 and cs.get(k, 0) == 0]
        gone.sort(key=lambda x: -x[1])
        added = [(k, v) for k, v in cs.items() if v >= 5 and cr.get(k, 0) == 0]
        added.sort(key=lambda x: -x[1])
        if gone or added:
            L += ["", "只出现在一侧的算子（次数 ≥ 5）：", "",
                  "| 算子 | real | sim |", "| --- | --- | --- |"]
            for k, v in gone[:15]:
                L.append("| `%s` | %d | 0 |" % (_cell(k, 60), v))
            for k, v in added[:10]:
                L.append("| `%s` | 0 | %d |" % (_cell(k, 60), v))
        deg = []
        for (caller, op), sr in (real_shapes or {}).items():
            if not _COPY_OP.search(op):
                continue
            ss_ = (sim_shapes or {}).get((caller, op))
            if not ss_:
                continue
            a = sr.most_common(1)[0][0].split(";")[0].strip()
            b = ss_.most_common(1)[0][0].split(";")[0].strip()
            if a != b and _SCALARISH.match(b) and not _SCALARISH.match(a):
                deg.append((caller, op, a, b))
        if deg:
            L += ["", "**拷贝退化**（同一处拷贝，真机搬的是张量、仿真搬的是标量/空）——"
                  "这正是『显存受限导致 H2D 拷贝失效』的签名：", "",
                  "| 发起处 | 算子 | real shape | sim shape |", "| --- | --- | --- | --- |"]
            for caller, op, a, b in deg[:12]:
                L.append("| `%s` | `%s` | %s | %s |" % (
                    _cell(_fmt_site(caller), 60), _cell(op, 40), _cell(a, 30), _cell(b, 30)))
        L.append("")

    L += ["## 1. 只在真机执行到的函数（仿真跳过的代码路径）", "",
          "| 层级 | 函数 | 真机调用次数 | 行号 |", "| --- | --- | --- | --- |"]
    for k, n, lines in d["only_real"]:
        L.append("| %s | `%s` | %d | %s |" % (
            _tier(k[0], repo_markers), _cell(_fmt_site(k), 90), n, ",".join(map(str, lines[:4]))))
    if not d["only_real"]:
        L.append("| | (无) | | |")

    L += ["", "## 2. 只在仿真执行到的函数（仿真器的桩 / 替换实现）", "",
          "带 ⚑ 的名字里含 mock/stub/simulat 等字样，几乎可以确定是仿真器替换掉的实现——"
          "**这类差异不是模型数值问题，是仿真器没实现真实逻辑**，要单独归类。", "",
          "| 层级 | 函数 | 仿真调用次数 | 行号 |", "| --- | --- | --- | --- |"]
    for k, n, lines in d["only_sim"]:
        flag = " ⚑" if STUB_HINT.search(k[0]) or STUB_HINT.search(k[1]) else ""
        L.append("| %s | `%s`%s | %d | %s |" % (
            _tier(k[0], repo_markers), _cell(_fmt_site(k), 90), flag, n,
            ",".join(map(str, lines[:4]))))
    if not d["only_sim"]:
        L.append("| | (无) | | |")

    verdict_of = {}
    for x in (shifts or []):
        verdict_of[x["file"]] = {"structural": "❗不同定义", "mixed": "⚠️版本不同",
                                 "uniform": "✅同一份代码"}[x["kind"]]
    L += ["", "## 3. 同一函数、两侧行号不同（版本 / patch 不一致）", ""]
    if shifts:
        L += ["### 3.0 按文件的判定（先看这张）", "",
              "| 判定 | 文件 | 函数数 | 说明 |", "| --- | --- | --- | --- |"]
        icon = {"structural": "❗执行到不同定义", "mixed": "⚠️版本不同", "uniform": "✅同一份代码"}
        for x in shifts[:25]:
            L.append("| %s | `%s` | %d | %s |" % (
                icon[x["kind"]], _cell(x["file"], 70), x["n"], x["note"]))
        L.append("")
    for title, rows, note in (
            ("3a. 模型代码", moved_model,
             "只有标 ❗ 的才是阻断项；标 ✅ 的是同一份代码整体平移（仿真侧打 patch 的常见形态），忽略即可。"),
            ("3b. 框架 / 驱动", moved_fw, "torch / torch_npu / megatron 等版本不一致，A 类差异。"),
            ("3c. 解释器与标准库", moved_rt,
             "Python 小版本不同导致的整片行号偏移，基本是噪声，列在这里只为完整。")):
        L += ["### %s（%d）" % (title, len(rows)), "", note, "",
              "| 判定 | 函数 | 真机行号 | 仿真行号 |", "| --- | --- | --- | --- |"]
        for k, lr, ls, _t in rows[:20 if rows is not moved_rt else 8]:
            L.append("| %s | `%s` | %s | %s |" % (
                verdict_of.get(k[0], "?"), _cell(_fmt_site(k), 90), lr[:4], ls[:4]))
        if not rows:
            L.append("| (无) | | |")
        L.append("")

    L += ["", "## 4. 调用次数不同的调用边 —— **候选分支清单**", "",
          "每一行的含义：`caller` 里存在一个分支或循环，它决定了 `callee` 被调用几次。"
          "两侧次数不同 ⇒ 这个分支两侧走向不同。**先按层级排序再按幅度**："
          "torch_npu 内部差 876 次也不如模型代码差 1 次值得看，因为只有模型代码里的分支"
          "是你能读、能改、能解释的。", "",
          "| 层级 | caller | callee | real | sim | Δ |", "| --- | --- | --- | --- | --- | --- |"]
    for e in d["call_edges"]:
        L.append("| %s | `%s` | `%s` | %d | %d | %+d |" % (
            e["tier"], _cell(_fmt_site(e["caller"]), 80), _cell(_fmt_site(e["callee"]), 80),
            e["real"], e["sim"], e["delta"]))
    if not d["call_edges"]:
        L.append("| | (无) | | | | |")

    L += ["", "## 5. 各 Python 函数直接下发的算子数差异 —— **分支 ⇄ 算子的对应关系**", "",
          "这一节把『哪个分支』和『多了/少了哪些算子』直接连起来：同一个 caller 下，"
          "某个算子的数量两侧不同，就是该分支造成的算子差异。写报告时的"
          "『受影响算子清单』直接取这里。", "",
          "| 层级 | 发起的 Python 函数 | 算子 | real | sim | Δ | 典型 shape real→sim |",
          "| --- | --- | --- | --- | --- | --- | --- |"]
    for e in d["op_edges"]:
        key = (e["caller"], e["callee"])
        sr = real_shapes.get(key)
        ss_ = sim_shapes.get(key)
        shp = "%s → %s" % (_cell(sr.most_common(1)[0][0], 34) if sr else "-",
                           _cell(ss_.most_common(1)[0][0], 34) if ss_ else "-")
        L.append("| %s | `%s` | `%s` | %d | %d | %+d | %s |" % (
            e["tier"], _cell(_fmt_site(e["caller"]), 80), _cell(e["callee"], 50),
            e["real"], e["sim"], e["delta"], shp))
    if not d["op_edges"]:
        L.append("| | (无) | | | | | |")

    same_cnt_diff_shape = []
    for key, sr in real_shapes.items():
        ss_ = sim_shapes.get(key)
        if not ss_:
            continue
        a, b = sr.most_common(1)[0], ss_.most_common(1)[0]
        if a[0] != b[0]:
            same_cnt_diff_shape.append((key, a[0], b[0], a[1], b[1]))
    same_cnt_diff_shape.sort(key=lambda x: (TIER_RANK[_tier(x[0][0][0], repo_markers)],
                                            -(x[3] + x[4])))
    L += ["", "## 5b. 算子数量相同但 shape 不同（tensor 级差异，控制流还没岔开）", "",
          "这些位置控制流一致、数据已经不同。它们是**下一个最可能翻转的分支的上游**，"
          "也是 msprobe 该去比对的 tensor 清单。", "",
          "| 发起的 Python 函数 | 算子 | real shape | sim shape |", "| --- | --- | --- | --- |"]
    for key, a, b, _na, _nb in same_cnt_diff_shape[:25]:
        L.append("| `%s` | `%s` | %s | %s |" % (
            _cell(_fmt_site(key[0]), 70), _cell(key[1], 40), _cell(a, 44), _cell(b, 44)))
    if not same_cnt_diff_shape:
        L.append("| (无) | | | |")

    L += ["", "## 6. 下一步：把候选分支变成代码证据", "",
          "对上面表里排在前面、且落在模型仓库内的 caller，逐个跑：", "", "```bash"]
    shown, seen = 0, set()
    for e in d["call_edges"] + d["op_edges"]:
        if shown >= 6:
            break
        caller = e["caller"]
        if e["tier"] != "model":
            continue
        callee = e["callee"][1] if isinstance(e["callee"], tuple) else ""
        # `<listcomp>` / `__enter__` / `wrapper` 这类合成名字在源码里找不到调用点，
        # 对这种 caller 直接做整函数分支扫描更有用
        if callee.startswith("<") or (callee.startswith("__") and callee.endswith("__")) \
                or callee in ("wrapper", "wrapped", "decorated"):
            callee = ""
        key = (caller, callee)
        if key in seen:
            continue
        seen.add(key)
        if callee:
            L.append('python pa_srcbranch.py --repo "%s" --file "%s" --func "%s" --callee "%s"'
                     % (repo or "<repo>", caller[0], caller[1], callee))
        else:
            L.append('python pa_srcbranch.py --repo "%s" --scan-file "%s" --scan-func "%s"'
                     % (repo or "<repo>", caller[0], caller[1]))
        shown += 1
    L.append('python pa_srcbranch.py --repo "%s" --from-pytrace <本文件同名的 .json>   # 批量'
             % (repo or "<repo>"))
    L += ["```", "",
          "它会用 AST 找出这些调用被哪些 `if/while/for` 包着、判据表达式是什么、"
          "依赖哪些变量与 tensor。", ""]
    return "\n".join(L)


def main():
    force_utf8()
    ap = argparse.ArgumentParser(description=__doc__,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--real", required=True)
    ap.add_argument("--sim", required=True)
    ap.add_argument("--repo", default="", help="模型仓库根目录，用于路径归一化与排序")
    ap.add_argument("--extra-root", action="append", default=[],
                    help="额外的路径前缀（torch / torch_npu / mindspeed 源码根），可多次给出")
    ap.add_argument("--step", type=int, default=None)
    ap.add_argument("--top", type=int, default=60)
    ap.add_argument("--keep-builtins", action="store_true",
                    help="保留 <built-in function isinstance> 这类伪事件（默认剔除，"
                         "它们数量巨大且不是算子）")
    ap.add_argument("--out", default="")
    args = ap.parse_args()

    roots = [r for r in ([args.repo] + args.extra_root) if r]
    print("loading real ...", file=sys.stderr)
    tr = load_trace(args.real)
    print("loading sim ...", file=sys.stderr)
    ts_ = load_trace(args.sim)

    def win(trace):
        steps = find_steps(trace)
        if args.step is None or not steps:
            return None, None
        i = args.step if args.step >= 0 else len(steps) + args.step
        return steps[i][1], steps[i][2]

    rw, sw = win(tr), win(ts_)
    real = build_calltree(tr, roots, rw[0], rw[1], args.keep_builtins)
    sim = build_calltree(ts_, roots, sw[0], sw[1], args.keep_builtins)
    merged = reconcile(real, sim)
    if merged:
        print("reconciled %d module paths that differ only by install location "
              "(e.g. <repo>/MindSpeed/mindspeed/... vs site-packages mindspeed/...)"
              % merged, file=sys.stderr)
    # tier 标记只取 --repo：--extra-root 是给路径归一化用的，把它也当成"模型代码标记"会让
    # torch_npu / mindspeed 这些库被判成 model，然后整张候选分支表被框架内部调用占满。
    markers = [os.path.basename(str(args.repo).replace("\\", "/").rstrip("/")).lower()]         if args.repo else []
    markers = [m for m in markers if m and m not in (".", "..")]
    d = diff(real, sim, markers, top=args.top)
    census = (op_census(tr, rw[0], rw[1]), op_census(ts_, sw[0], sw[1]))
    shifts = shift_analysis(d["moved"])
    md = to_md(d, real["shapes"], sim["shapes"], args.repo, markers, census, shifts)
    print(md)
    if args.out:
        os.makedirs(os.path.dirname(os.path.abspath(args.out)) or ".", exist_ok=True)
        with open(args.out, "w", encoding="utf-8") as fh:
            fh.write(md)
        write_json(os.path.splitext(args.out)[0] + ".json", {
            "counts": d["counts"],
            "file_verdicts": shifts,
            "only_real": [{"file": k[0], "func": k[1], "count": n, "lines": ln}
                          for k, n, ln in d["only_real"]],
            "only_sim": [{"file": k[0], "func": k[1], "count": n, "lines": ln}
                         for k, n, ln in d["only_sim"]],
            "moved": [{"file": k[0], "func": k[1], "real_lines": a, "sim_lines": b, "tier": t}
                      for k, a, b, t in d["moved"]],
            "call_edges": [{"caller_file": e["caller"][0], "caller_func": e["caller"][1],
                            "callee_file": e["callee"][0], "callee_func": e["callee"][1],
                            "real": e["real"], "sim": e["sim"], "delta": e["delta"],
                            "tier": e["tier"]}
                           for e in d["call_edges"]],
            "op_edges": [{"caller_file": e["caller"][0], "caller_func": e["caller"][1],
                          "op": e["callee"], "real": e["real"], "sim": e["sim"],
                          "delta": e["delta"], "tier": e["tier"]} for e in d["op_edges"]],
        })
        print("\nwrote %s" % args.out, file=sys.stderr)


if __name__ == "__main__":
    main()

#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""pa_check_trace.py -- 一份 trace_view.json 到底采到了什么？为什么没有 python_function？

    python pa_check_trace.py --trace <...>/ASCEND_PROFILER_OUTPUT/trace_view.json
    python pa_check_trace.py --trace REAL/trace_view.json --trace SIM/trace_view.json   # 两份对照

pa_pytrace 的全部能力都建立在 python_function 事件上，而"开了 with_stack 却没采到"是个
反复出现的坑。与其让下游分析静静地退化，不如先用这个脚本把实际采到的东西摊开：
事件 cat 分布、各进程/线程的事件样例、以及 profiler_info_{rank}.json 里**实际生效**的配置
（代码里怎么写的不重要，落盘的这份才是真的）。
"""
from __future__ import annotations

import argparse
import glob
import json
import os
import re
import sys
from collections import Counter

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from pa_common import force_utf8, load_json_tolerant, parse_pyfunc  # noqa: E402

# 采集配置里跟 python_function 直接相关的键，名字在各版本间有出入，所以按子串匹配
CONFIG_KEYS = ("with_stack", "with_modules", "record_shapes", "activities", "profiler_level",
               "export_type", "data_simplification", "with_flops", "aic_metrics", "l2_cache",
               "msprof_tx", "op_attr", "host_sys", "sys_io", "schedule", "experimental")


def _flat(obj, prefix=""):
    out = {}
    if isinstance(obj, dict):
        for k, v in obj.items():
            out.update(_flat(v, "%s.%s" % (prefix, k) if prefix else str(k)))
    elif isinstance(obj, list):
        out[prefix] = ", ".join(str(x) for x in obj)
    else:
        out[prefix] = obj
    return out


def read_profiler_info(trace_path):
    """从 trace 往上找 profiler_info_{rank}.json —— 落盘的配置才是实际生效的配置。"""
    d = os.path.dirname(os.path.abspath(trace_path))
    for _ in range(4):
        hits = glob.glob(os.path.join(d, "profiler_info*.json"))
        if hits:
            try:
                with open(hits[0], "r", encoding="utf-8") as fh:
                    return os.path.basename(hits[0]), _flat(json.load(fh))
            except Exception as exc:
                return os.path.basename(hits[0]), {"<读取失败>": str(exc)}
        d = os.path.dirname(d)
    return None, {}


def analyse(path):
    data, warn = load_json_tolerant(path)
    if isinstance(data, dict):
        data = data.get("traceEvents", data.get("events", []))
    cats, procs, threads = Counter(), {}, {}
    n_x = n_pyname = n_pycat = 0
    sample_py, sample_other = [], []
    for ev in data:
        ph = ev.get("ph")
        if ph == "M":
            nm, args = ev.get("name"), ev.get("args") or {}
            if nm == "process_name":
                procs[ev.get("pid")] = str(args.get("name", ""))
            elif nm == "thread_name":
                threads[(ev.get("pid"), ev.get("tid"))] = str(args.get("name", ""))
            continue
        if ph not in ("X", "x"):
            continue
        n_x += 1
        cat = str(ev.get("cat", ""))
        cats[cat or "(无 cat 字段)"] += 1
        if "python_function" in cat.lower():
            n_pycat += 1
        name = str(ev.get("name", ""))
        if parse_pyfunc(name):
            n_pyname += 1
            if len(sample_py) < 3:
                sample_py.append((cat, name))
        elif len(sample_other) < 6:
            sample_other.append((cat, name))
    return {"path": path, "warn": warn, "n_x": n_x, "cats": cats, "procs": procs,
            "threads": threads, "n_pyname": n_pyname, "n_pycat": n_pycat,
            "sample_py": sample_py, "sample_other": sample_other}


def report(a):
    L = ["## `%s`" % a["path"], ""]
    if a["warn"]:
        L.append("> %s" % a["warn"])
        L.append("")
    L.append("- X 事件总数：%d" % a["n_x"])
    L.append("- **python_function 事件**：按 cat 计 %d 条，按名字形态计 %d 条"
             % (a["n_pycat"], a["n_pyname"]))
    L.append("")
    L.append("### 事件 cat 分布")
    L.append("")
    L.append("| cat | 数量 |")
    L.append("| --- | --- |")
    for c, n in a["cats"].most_common(12):
        L.append("| `%s` | %d |" % (c, n))
    L.append("")
    if a["sample_py"]:
        L.append("### python_function 样例（这就是它在 trace 里的长相）")
        L.append("")
        for c, n in a["sample_py"]:
            L.append("- cat=`%s`  name=`%s`" % (c, n[:110]))
        L.append("")
    else:
        L.append("### 没有 python_function")
        L.append("")
        L.append("这份 trace 里一条都没有。下面是实际采到的事件长什么样，用来判断缺的是哪一层：")
        L.append("")
        for c, n in a["sample_other"]:
            L.append("- cat=`%s`  name=`%s`" % (c, n[:110]))
        L.append("")
    L.append("### 进程 / 线程")
    L.append("")
    for pid, nm in sorted(a["procs"].items(), key=lambda x: str(x[0])):
        ths = [t for (p, t) in a["threads"] if p == pid]
        L.append("- pid=%s `%s`（%d 个线程）" % (pid, nm, len(ths)))
    L.append("")
    fn, cfg = read_profiler_info(a["path"])
    L.append("### 实际生效的采集配置（%s）" % (fn or "未找到 profiler_info*.json"))
    L.append("")
    if cfg:
        L.append("| 配置项 | 值 |")
        L.append("| --- | --- |")
        for k in sorted(cfg):
            if any(s in k.lower() for s in CONFIG_KEYS):
                L.append("| `%s` | %s |" % (k, str(cfg[k])[:80]))
    else:
        L.append("（找不到，无法核对代码里写的配置有没有真正生效）")
    L.append("")
    return L


VERDICT = """## 怎么读这份结果

`python_function` 事件在 trace 里长这样——**cat 是 `python_function`，name 是
`/abs/path/file.py(123): func_name`**，挂在 host 侧的 python 进程线程上，按调用关系天然嵌套。
pa_pytrace 就是靠它建两侧的调用树。

一条都没有时，按下面的顺序查（都能在上面的表里对上）：

1. **`activities` 里有没有 CPU。** python 侧的追踪器只在 CPU activity 打开时才工作。
   只采 NPU 的话，device kernel 全都在、Python 层一片空白——现象和你看到的一样。
2. **`profiler_level` 是不是 Level0。** Level0 会砍掉 host 侧的细粒度数据。用 Level1 及以上。
3. **配置有没有真正生效。** 代码里写了 `with_stack=True` 不等于落盘时是 True：
   `experimental_config` 会覆盖、动态 profiling（`dynamic_profile` / 外部 `profiler_config.json`）
   会整份接管。以上表 `profiler_info*.json` 里的值为准，它是实际落盘的那份。
4. **`export_type` 是不是只导了 db。** 只出 `ascend_pytorch_profiler_{rank}.db` 时，
   trace_view.json 可能是简化版。
5. **模型是不是跑在 `torch.compile` / 图模式下。** Python 帧被编译掉了，自然没有 python_function。
6. **采的是不是同一个进程。** python 追踪器只跟主进程；模型实际跑在子进程里就采不到。

两份 trace 一起传进来时，直接对比它们的配置表——`with_stack` 采到与没采到的两次运行之间，
差异一定落在这张表里的某一行。
"""


def main():
    force_utf8()
    ap = argparse.ArgumentParser(description=__doc__,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--trace", action="append", required=True,
                    help="trace_view.json，可给多次做对照")
    ap.add_argument("--out", default="")
    args = ap.parse_args()

    L = ["# trace 采集自查", ""]
    for t in args.trace:
        L += report(analyse(t))
    L.append(VERDICT)
    md = "\n".join(L)
    print(md)
    if args.out:
        os.makedirs(os.path.dirname(os.path.abspath(args.out)) or ".", exist_ok=True)
        with open(args.out, "w", encoding="utf-8") as fh:
            fh.write(md)
        print("\nwrote %s" % args.out, file=sys.stderr)


if __name__ == "__main__":
    main()

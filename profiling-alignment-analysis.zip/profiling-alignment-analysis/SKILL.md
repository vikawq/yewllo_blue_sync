---
name: profiling-alignment-analysis
description: 对比华为昇腾 NPU 真机 profiling 与仿真(simulator)profiling，找出两边算子执行序列/热力图对不上的位置，并把差异全量回溯到模型代码里具体是哪个 if-else 走了不同分支、判据是哪个变量/tensor、因此多了少了哪些算子。只做控制流/结构对齐，不做耗时性能调优。当用户提到真机与仿真 profiling 对比、trace_view.json 对齐、算子热力图对不上、ASCEND_PROFILER_OUTPUT/msprof/MindSpeed/Megatron/MindSpeed-MM profiling、按 rank 对比、"仿真走了不同的控制流/分支"、Perfetto 看 trace 时，都要使用本 skill；即使用户只说"这两个 profiling 目录帮我对一下""仿真和真机算子对不上""为什么仿真多了/少了算子"也要使用。Use for Ascend NPU real-device vs simulation profiling alignment, operator sequence divergence, control-flow branch divergence hunting.
---

# 真机 vs 仿真 Profiling 对齐分析（昇腾 NPU / PyTorch + torch_npu + MindSpeed）

## 目标

不是"哪个算子慢"，而是把两边的差异**全量分类并落到代码行**：

> 哪一行 `if` 两侧判定不同 → 判据是哪个变量/tensor、它由哪次计算产生 → 因此多了/少了哪些算子。

耗时全程不看：仿真的时间是模型算出来的，比较耗时只会得到"仿真器对时延的猜测"。

## 差异四分类（写结论前必须先分好类）

真实项目里，"算子对不上"绝大部分**不是**模型数值导致的控制流分叉。先分类，再谈根因：

| 类 | 名称 | 典型证据 | 该怎么处理 |
| --- | --- | --- | --- |
| **A** | 环境/版本不一致 | 同一函数在两侧行号不同；torch/torch_npu/patch 版本不同 | **阻断项**：先对齐版本，否则后面所有结论都不成立 |
| **B** | 仿真器桩实现 | 仿真侧出现 `*_mock` / `simulator_patch/*`；device 侧通信原语被换掉（NOTIFY/UBDMA → event+memcpy） | 归为"仿真器未实现真实逻辑"，不是模型问题 |
| **C** | 配置/数据不一致 | world size、TP/PP/EP、启动参数、输入序列长度、step 选取不同 | **阻断项**：这些会放大甚至伪造差异 |
| **D** | 数值导致的控制流分叉 | 判据 tensor 来自设备（`.item()`/溢出检查/norm/路由），两侧判定翻转 | 这才是要找的东西 |

**只要存在 A 或 C，D 类结论一律标注为"待验证"**，并在报告开头写清楚。这一条不是形式主义：
world size 8 vs 4 时梯度 all-reduce 的参与方就不同，`grad_norm` 本来就该不一样。

## 开工前

1. 真机 profiling 根目录、2. 仿真 profiling 根目录、3. 模型代码（含 torch / torch_npu /
MindSpeed 源码更好，AST 分析要用）+ 两侧启动 `.sh`。缺哪个直接问用户。
用户指定 rank 就用指定的，否则用两边都有的最小 rank。

```bash
SK="<本 skill 目录>/scripts"; WS="pa_out"; mkdir -p "$WS"
```

脚本只用标准库，Windows / Linux 都能跑。

---

## Step 1 — 盘点数据、选 rank、核对采集配置

```bash
python "$SK/pa_discover.py" --real <真机根目录> --sim <仿真根目录> --out "$WS/inventory.json"
```

看 rank 集合、trace_view.json 是否齐全、`with_stack` / `record_shapes` / `profiler_level`
是否一致。**没开 `with_stack=True` 的话，Step 3 几乎废掉**，要第一时间告诉用户重采。

## Step 2 — 启动参数对比（C 类差异）

```bash
python "$SK/pa_shargs.py" --dir <repo>/examples --list
python "$SK/pa_shargs.py" --file <real.sh> --diff <sim.sh>
```

## Step 3 — Python 执行路径对比（最直接的一步，先做）

```bash
python "$SK/pa_pytrace.py" --real <real trace> --sim <sim trace> \
  --repo <模型仓库> --extra-root <torch_npu 源码根> --step -2 --out "$WS/pytrace.md"
```

`with_stack=True` 时每次 Python 调用都是一个事件，两侧各建一棵调用树再做差，一次拿到：

- 只在真机出现的函数 → 仿真**没走到**的代码路径
- 只在仿真出现的函数（带 ⚑）→ 仿真器的桩实现（**B 类**）
- 同函数不同行号 → 版本不一致（**A 类**）
- caller→callee 次数不同 → **候选分支清单**（**D 类线索**）
- 每个 Python 函数直接下发的算子数差异 → 分支 ⇄ 算子的对应关系
- 算子数相同但 shape 不同 → tensor 级差异（还没岔开，但已经在偏）

这一步产出的 `pytrace.json` 直接喂给 Step 6。**读它的顺序是固定的**：

1. **第 0b 节「关键算子存在性对照」**——一侧为 0 的类别是最要命的。仿真跑不到某个融合算子
   （典型：显存受限 → H2D 拷贝失效 → 输入没搬上 device → 走不到 FlashAttention 的融合分支），
   后面所有差异都是它的下游，先把这件事说清楚再往下看。
2. **第 3.0 节「按文件的判定」**——行号不同要分三种看，不能一概当成阻断：
   - ✅ **整体平移**（一个文件里所有函数偏移量相同，比如全 +61 行）＝同一份代码，
     只是头部增删了几行（仿真侧打 patch 的常见形态），**忽略它**；
   - ⚠️ **偏移不一致**＝版本不同，A 类环境差异；
   - ❗ **执行到不同的函数定义**（同名函数在两侧对应到不同的定义行）＝真的走了不同代码，
     这才是要追的。
3. 再看仿真桩清单（⚑）。**注意因果方向**：桩掉一段计算会连带改变后面的 shape 和序列长度，
   很多看起来像『输入数据不一致』的现象其实是桩的后果，不要当成两个独立问题分别归因。
4. 最后才看第 4/5 节的候选分支，并且只看 `model` 层级的行。

**一律以真机代码为基准。** 仿真侧通常是在真机代码上打 patch（跳过若干过程），改动量往往很小；
读行号、定位源码、写结论都用真机那一份，仿真侧只用来回答『它少做了什么』。因此：

- `--repo` 指向**真机跑的那份**模型仓库——它同时决定了哪些文件算 `model` 层级；
- `--extra-root` 只用于路径归一化（把 `<repo>/MindSpeed/mindspeed/x.py` 和装好的
  `mindspeed/x.py` 认成同一个模块），**不要指望它扩大 model 范围**；把 torch_npu 的源码根
  传给它是对的，但 torch_npu 仍应被归为 framework。

## Step 4 — 算子序列对齐（thread 级，host/device 分开）

```bash
python "$SK/pa_align.py" --real <real trace> --sim <sim trace> \
  --outdir "$WS/rank0" --rank 0 --step -2
```

**读结果时先看这三个数，不对就别往下解读**：

1. **对齐率**。低于 20% 通常不是"两边完全不同"，而是 track 配错、step 选错、或序列被截断。
   配错就用 `--pair "真机label==仿真label"` 手工指定。
2. **是否有截断警告**。`--limit-events` 截断会在末尾造出一个巨大的 delete/insert 块，
   长得和真实分歧一模一样（默认已改为不截断；报告里带 `[截断产物，勿采信]` 标记的块直接忽略）。
3. **首个分歧的所在阶段**。报告会标出它落在 `ProfilerStep` / `Optimizer.step` / 哪个
   `nn.Module` 里；分歧集中在哪个阶段比它在第几个算子更有意义。

层级顺序 framework(aten) → CANN → device，framework 层的分歧离代码最近，优先看。
第 4 节"同名算子 shape 不一致"是 tensor 级线索。

## Step 5 — 热力图

```bash
python "$SK/pa_heatmap.py" --real <real trace> --sim <sim trace> \
  --outdir "$WS/rank0" --alignment "$WS/rank0/alignment.json" --step -2
```

横轴是算子序号占比不是时间。终端直接打印 ASCII 图；`heatmap.html` 给人看。

## Step 6 — 代码证据：把候选分支变成 if 和变量名

两条路，都要走：

```bash
# 6a 批量：把 pa_pytrace 的候选边全部 AST 展开
python "$SK/pa_srcbranch.py" --repo <repo> --from-pytrace "$WS/pytrace.json" \
  --out "$WS/branches.md"

# 6b 全量枚举某个文件/函数里所有分支，按"数值敏感度"排序
python "$SK/pa_srcbranch.py" --repo <repo> --scan-file <可疑文件> --context 6
```

`pa_srcbranch.py` 用 AST 找出调用被哪些 `if/while/for` 包着，给出判据表达式、判据变量、
以及**这些变量是被哪一行算出来的**；并做函数内的污点传播，把"判据最终来自设备张量"的分支
标成 🔴（例如 `update_successful = not bool(found_inf.item())` → `if update_successful:` 会被标红）。
🔴 = 仿真数值一偏就可能翻转；🟡 = 依赖运行时值；⚪ = 静态配置。

补充一条 trace 侧的证据链（同步点，即"设备值回到 host"的地方）：

```bash
python "$SK/pa_evidence.py" --trace <real trace> --alignment "$WS/rank0/alignment.json" \
  --repo <repo> --out "$WS/rank0/evidence.md"
```

控制流只可能在同步点分叉，所以每 step 只执行一两次的同步点是最可疑的 if。

## Step 7 — Perfetto 可视化（给人看）

```bash
python "$SK/pa_perfetto.py" merge --real <real trace> --sim <sim trace> \
  --out "$WS/merged_rank0.json" --step -2 --max-mb 250
python "$SK/pa_perfetto.py" serve --file "$WS/merged_rank0.json" --port 9001
```

端口必须 9001（Perfetto CSP 只放行它）。**Claude 自己的内置浏览器会拦截 https 页面对
127.0.0.1 的请求**，所以这一步是给用户的：把链接和"该看什么"一起交出去，不要指望在
agent 的浏览器里加载成功。细节见 `references/perfetto-workflow.md`。

## Step 8 —（可选，唯一的硬证据）分支探针复跑

```bash
export PYTHONPATH="$SK:$PYTHONPATH"
export PA_PROBE_OUT=/tmp/branch_real PA_PROBE_INCLUDE=<repo>/mindspeed_mm,<repo>/megatron/core
export PA_PROBE_MAX_ITERS=3
# 启动脚本里 `python xxx.py ...` → `python -m pa_branch_probe xxx.py ...`
python "$SK/pa_branch_probe.py" --diff /tmp/branch_real.rank0.log /tmp/branch_sim.rank0.log
```

## Step 9 — 出报告

按 `references/report-template.md` 写。**每条差异必须带分类标签 A/B/C/D**，D 类必须给出
`file:line` + 判据表达式 + 判据变量 + 由此多/少的算子清单。

---

## 判读纪律（踩过的坑，逐条都别再犯）

- **不比耗时**。出现时间数字只能是为了说明先后顺序。
- **看到整齐的整数先怀疑是自己造成的**。真机算子数正好等于 `--limit-events` 默认值，
  那是截断不是分歧；两侧分歧块长度完全相等，多半是同一段被整体替换而不是巧合。
- **对齐率低先修工具，不要先写结论**。
- **shape 里的数字不要做算术推断**。`151936` 是 Qwen3 的 vocab_size，不是
  "37×4096+2304"；解释 shape 一律回去对模型配置（vocab_size / hidden_size / num_heads /
  seq_len），不要凭数字凑等式。
- **host 和 device 分开说**。host(aten/CANN) 是"下发了什么"，device 是"执行了什么"。
- **区分证据和推测**。trace 和 AST 里读出来的是证据；"可能是因为…"必须标注待验证并给验证方法。
- **仿真器基础设施差异不要写成模型 bug**（B 类），但要单独列出来——它们往往才是最大头。

## 参考资料

| 文件 | 什么时候读 |
| --- | --- |
| `references/trace-format.md` | 目录结构、trace_view.json 字段、host/device 划分、CSV 列 |
| `references/divergence-patterns.md` | 拿到分歧后查"这种差异一般是哪一类、哪种分支造成的" |
| `references/perfetto-workflow.md` | 用 Perfetto 看图、SQL 交叉验证、加载失败排查 |
| `references/report-template.md` | 写最终报告 |

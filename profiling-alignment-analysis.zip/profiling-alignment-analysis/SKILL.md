---
name: profiling-alignment-analysis
description: Read and align real-machine and simulation Huawei Ascend TorchNPU integrated Profiler text exports across every same-numbered rank, distinguish framework Host operators, CANN/AscendCL/Runtime Host launch bridges, and NPU Device tasks, compare every observable thread/stream structurally without timing analysis, build operator-ordinal heatmaps, optionally cross-review each rank trace in Perfetto UI, and trace the first reliable framework-operator divergence through .sh launchers to model Python if/elif/else guards, predicate operands, tensors, and producers. Use for Ascend profiling alignment failures, simulator control-flow divergence, wrong if-else values, mismatched operator paths or spatial positions, trace_view.json comparison, and code-backed evidence explaining which simulated tensors/operators entered a different branch. Raw msprof or analysis.db-only inputs are preflighted and explicitly degraded rather than treated as an empty integrated export.
---

# 真机 / 仿真 Profiling 控制流对齐

固定 `reference=真机`、`candidate=仿真`。最终报告使用中文；算子名、代码符号、字段、路径和 URL 保留原文。

## 角色与安全门禁

要求用户明确写出：

```text
真机 Profiling（reference）：<目录>
仿真 Profiling（candidate）：<目录>
```

若只有两个目录但角色不明确，停止并只询问角色；不得按路径名、时间戳、事件数或性能猜测。

把原始 Profiling 和源码仓视为只读。把输出放在两侧 Profiling 与源码仓之外；不执行 `.sh`、不 import/运行模型代码、不修改 checkout、不点击 Perfetto Share、不生成公开 trace 链接。

## 本 Skill 的硬约束

- 比较 `sorted(real_global_rank_ids ∩ sim_global_rank_ids)` 的每个同号 Rank。真机 0–7、仿真 0–3 时比较 0、1、2、3；不重编号、不左移、不抽样一个 Rank。
- 分析每个 Rank 内全部含算子的 Host Thread 与 Device stream。不得随机选一个线程代表该 Rank。
- 固定三层语义：`framework_op`（PyTorch/custom `cpu_op`）、`host_launch`（CANN/AscendCL/GE/Runtime/enqueue/dequeue）、`device_task`（Ascend Hardware kernel/HCCL/memcpy/task）。前两层都在 Host；不得因事件名或 args 含 `ACL/CANN/Runtime/Device Id/Stream Id` 就把 Host launch 误判成 Device。
- Host 主键为 `rank+semantic_layer+pid+tid+track`，Device 主键为 `rank+device+stream+track`。只有 namespace 正确且端点唯一的 direct flow/correlation 才建立跨层因果边；`correlation_id` 与 `external_id` 不共享命名空间。
- 只分析 operator presence、calls、顺序、嵌套、Shape/dtype/format、序位位置和控制路径。禁止输出或解释 duration、latency、self/total time、利用率、重叠、空闲、带宽、快慢、性能比率或时间误差。
- 允许解析器内部用 `ts/dur` 配对 `X/B/E`、确定 lane 内顺序/嵌套并恢复 direct flow 端点；不得把这些时间值写入公开证据或报告。
- 把算子“热力图”定义为序位热力图：横轴是 lane 内归一化 event ordinal，不是时间桶。格宽、色块面积和空白不得作性能解释。
- 区分 Shape、tensor identity 与 tensor value。Shape 一致不能证明值一致；缺少直接 predicate operand value 时不得声称“仿真把 tensor 算错”。
- 当前完整输入契约是 TorchNPU 已整合生成的 `ASCEND_PROFILER_OUTPUT` text export。`PROF_*/mindstudio_profiler_output/msprof_*.json`、`analysis.db` only 或缺少逐事件 trace 的输入必须标 `unsupported/partial`，先转换或重采，不得解释为零算子。

## 必须执行的工作流

### 1. 固定输入身份

记录两侧绝对路径、模型/权重/配置、workload、phase、Profiler schedule、world size、DP/TP/EP/PP/CP/DCP、运行版本。用户未提供时继续结构提取，但把相应因果门禁标未知。

若用户给源码 URL，先打开其具体 GitHub/GitCode 页面并固定 commit；本地 checkout 优先。分别绑定真机和仿真源码版本，不用一侧代码解释另一侧运行。完整输入模板见 [references/prompt-template.md](references/prompt-template.md)。

### 2. 完整读取对齐与报告规范

完整读取 [references/alignment-playbook.md](references/alignment-playbook.md) 和 [references/report-contract.md](references/report-contract.md)，再运行任何分析命令。

### 3. 先做 Ascend 采集与格式预检

```powershell
python scripts/preflight_ascend_profiles.py `
  --real "<real-profile-root>" `
  --sim "<simulation-profile-root>" `
  --output "<alignment-output>/preflight"
```

实际读取 `collection_contract.json` 与 `collection_contract.csv`。确认两侧是否为 integrated text export，以及 `trace_view.json`、`operator_details.csv`、`kernel_details.csv`、`profiler_info*.json` 的可观测性。检查 CPU/NPU activities、`record_shapes`、`with_stack`、`with_modules`、profiler level、schedule/window 与子线程注册证据；文件无法证明的字段写 `unknown`，不猜测。`unsupported` 不继续做完整对齐；`partial` 可继续提取，但报告必须保留门禁与最小重采要求。

### 4. 对齐全部同号 Rank 与全部 lane

运行：

```powershell
python scripts/align_profiles.py `
  --real "<real-profile-root>" `
  --sim "<simulation-profile-root>" `
  --output "<alignment-output>" `
  --heatmap-bins 64
```

先审计：

```text
analysis_manifest.json
rank_pairs.csv
unpaired_ranks.csv
thread_pairs.csv
parser_warnings.csv
```

确认 `duration_metrics_emitted=false`，`compared_rank_ids` 恰为同号交集，每个 Rank 的 Host/Device lane union 均已登记，ambiguous/unmatched 未被强配。

再读：

```text
canonical_events.csv
event_alignment.csv
divergence_windows.jsonl
host_device_links.csv
structural_heatmap.csv/html
```

按每个 matched lane 报告首次稳定分叉；没有 direct flow 时分别报告 Host 与 Device 差异，不按时间最近补链。

读取 `host_device_links.csv` 时，只有 `causal_eligible=是` 且 `link_status=direct-id/direct-flow` 的唯一端点行可作跨层因果；`degraded-flow-containment` 只作导航线索。

只允许 profiler metadata 的 `rank_id/global_rank` 作为权威 Rank；目录名仅作 fallback。二者冲突时该目录必须进入 `unpaired_ranks.csv`，不得静默择一。`kernel_details.csv` 缺少 Stream ID 时只保留 Rank 级 Device coverage，禁止构造 `stream=unknown` 的可比 lane。

### 5. 静态解析 `.sh` 入口

如果提供本地代码，完整读取 [references/source-causality.md](references/source-causality.md)。先静态解析一个或多个 `.sh` 或 `.sh` 目录：

```powershell
python scripts/resolve_source_entrypoints.py `
  --repo-root "<fixed-local-checkout>" `
  --entry "<entry-sh-or-directory>" `
  --output "<alignment-output>/source-entrypoints" `
  --environment "shared-or-real-or-sim"
```

可重复 `--entry`。读取入口候选、shell launch chain、Python target、配置脱敏和 unresolved issues。静态可达性不等于实际运行；结合 argv/log/marker 后才升级。

URL 源码不可本地 AST 解析时，先用固定 commit 页面人工追踪最短链；需要可靠跨文件分析时获取最小只读 checkout。私有仓不可访问时不索要凭据，继续完成 Profiler-only 分析并列最小缺失文件。

### 6. 把首次 framework Host 分叉映射到 if-else

运行：

```powershell
python scripts/analyze_control_flow.py `
  --repo-root "<fixed-local-checkout>" `
  --alignment-output "<alignment-output>" `
  --source-analysis-dir "<alignment-output>/source-entrypoints" `
  --entry "<entry-sh-or-python>" `
  --repository-url "<repo-url>" `
  --commit "<full-commit>" `
  --runtime-binding "verified|user-declared|unverified|conflict" `
  --output "<alignment-output>/source-causality"
```

若已采集 guard 值，追加 `--runtime-values <csv>`。实际读取：

```text
control_flow_guard_candidates.csv
control_flow_evidence.jsonl
predicate_tensor_evidence.csv
event_source_map.csv
branch_device_evidence.csv
source_entrypoint_chain.csv
source_evidence.csv
source_analysis_issues.csv
```

只处理 `semantic_layer=framework_op` 的首个 Host 差异；`host_launch` 只能作为框架算子与 NPU task 之间的 bridge 证据，不能直接映射模型 if-else。从 call stack/module/operator 反查固定源码，确认真机与仿真 callsite 是否位于同一 guard 的不同 arm，再回溯 predicate operand 的最近静态 producer。Device 算子只通过唯一 direct link 追加。

强度升级必须同时通过 lane 高置信配对、三视图稳定边界、分叉前后 exact anchor 门禁、无更早 unresolved、`.sh`/launcher 入口绑定或行级 stack。缺任一项保留为静态候选；重复层/重复算子导致锚点歧义时不得用 `SequenceMatcher` 的任意平移结果冒充首次因果分叉。

采用且不得混淆四级结论：`已证实控制流分叉`、`强关联控制流分叉`、`静态候选`、`仿真计算错误已证实`。最后一级需要同输入/权重/seed/config/code/rank state、直接 operand 值、最早 producer、语义 oracle 和可重复 A/B 全部成立。

### 7. 用 Perfetto 逐 Rank 内容复核

完整读取 [references/perfetto-review.md](references/perfetto-review.md)。调用 workspace dependency discovery 定位受信 Node.js 和 `playwright-core`，再运行：

```powershell
$env:PERFETTO_PLAYWRIGHT_NODE_MODULES = "<trusted-node_modules>"
python scripts/render_perfetto_batch.py `
  --alignment-output "<alignment-output>" `
  --output "<alignment-output>/perfetto-review" `
  --online-authorized `
  --node "<trusted-node-executable>"
```

只有用户明确确认数据政策允许时才加 `--online-authorized`。这会对每个同号 Rank 的真机/仿真 `trace_view.json` 分别加载官方 UI；准确语义是“联网获取官方 UI 代码，再离线后把 trace 放入浏览器本地内存”，不是把 trace 文件上传到 Perfetto 服务。默认不截图。只有需要评价 Canvas 颜色/轨道几何时加 `--screenshot`，并实际使用图像查看工具检查 PNG；即使查看也不得从条宽推断耗时。

逐 job 验证官方 origin、`localOnly`、offline-before-post、Service Worker=0、trace SHA、lane batch 与无 duration SQL。必须实际读取 HTML/text/SQL/manifest 并写 `perfetto_content_review.json`；自动产物成功不等于内容复核完成。网络、浏览器、依赖或数据政策阻止时，用同一命令加 `--degraded-reason "<具体原因>"` 写出标准 `not-executed` 记录；明确标“Perfetto 内容复核未执行”，不伪称页面已加载。

### 8. 形成代码证据链

每个重大分叉给出：

```text
Rank/Host Thread
  -> 最后共同 operator anchor
  -> 真机/仿真首个不同 operator+Shape
  -> fixed repo@commit file:symbol:guard lines
  -> 真机 arm / 仿真 arm
  -> predicate operand 与静态/runtime producer
  -> branch-exclusive Host operators
  -> direct-linked Device kernels（若有）
```

同时列替代解释：采集窗口、workload/Shape、lane 错配、backend lowering、图捕获、instrumentation、代码版本冲突。没有直接 tensor value 时给最小 runtime hook，不补造值。

### 9. 交付一份中文主报告

按 [references/report-contract.md](references/report-contract.md) 生成 `<alignment-output>/profiling_alignment_report.md`。报告必须覆盖每个同号 Rank、全部 matched/ambiguous/unmatched Host/Device lane、每 lane 首次分叉、Perfetto 复核状态、代码 guard、predicate tensor/producer、结论强度和最小验证动作。

## 交付前检查

- 真机/仿真角色和源码版本绑定全程一致。
- 所有同号 Rank 均分析；额外 Rank 明确列为 unpaired。
- 每 Rank 的全部 operator-bearing Host/Device lane 均在 union 中；未随机抽样。
- Host 与 Device 分表；跨域结论都有 direct flow/correlation。
- `framework_op`、`host_launch`、`device_task` 分层展示；Host bridge 不冒充 NPU kernel，也不冒充模型算子。
- 重复调用数作为结构事实保留；真机 2 次与仿真 3 次同名连续调用不得判 `exact`。
- 报告和公开 CSV 不含 duration/latency/性能比率或快慢判断。
- 序位热力图未被称为时间热力图。
- 每条 guard 结论可回到 rank/thread/event/operator/Shape/source line。
- 没有直接 predicate operand value 时未声称仿真数值错误。
- Perfetto HTML/text/SQL 由代理实际读取；未看 PNG 时未评价 Canvas。
- 原始 Profiling、源码 checkout 和远端仓库均未修改。

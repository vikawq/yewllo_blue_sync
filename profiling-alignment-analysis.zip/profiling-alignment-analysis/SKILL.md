---
name: profiling-alignment-analysis
description: 对比华为昇腾 NPU 真机 profiling 与仿真(simulator)profiling，找出两边算子执行序列/热力图对不上的位置，并回溯到模型代码里具体是哪个 if-else 走了不同分支、涉及哪些算子和 tensor。只做控制流/结构对齐，不做耗时性能调优。当用户提到真机与仿真 profiling 对比、trace_view.json 对齐、算子热力图对不上、ASCEND_PROFILER_OUTPUT/msprof/MindSpeed/Megatron profiling、按 rank 对比、"仿真走了不同的控制流/分支"、Perfetto 看 trace 时，都要使用本 skill；即使用户只说"这两个 profiling 目录帮我对一下""仿真和真机算子对不上""为什么仿真多了/少了算子"也要使用。Use for Ascend NPU real-device vs simulation profiling alignment, operator sequence divergence, control-flow branch divergence hunting.
---

# 真机 vs 仿真 Profiling 对齐分析（昇腾 NPU / PyTorch + torch_npu + MindSpeed）

## 这个 skill 要回答的问题

仿真器在某个 `if` 上算出的值和真机不一样，模型就走进了另一条控制流，于是算子的种类、数量、
所在 stream 和先后顺序都变了——在热力图上表现为"某一段之后两边完全对不上"。

目标不是"哪个算子慢"，而是：**在哪一步开始不一样 → 是哪一行 if-else → 它判的是哪个 tensor**。
所以全程忽略耗时；仿真的时间是模型算出来的，比较耗时只会得到"仿真器对时延的猜测"，没有信息量。

## 开工前先确认三样东西

1. 真机 profiling 根目录（`*_ascend_pt/`，里面有 `ASCEND_PROFILER_OUTPUT/trace_view.json`）
2. 仿真 profiling 根目录
3. 模型代码：本地目录，或开源地址（`git clone --depth 1` 到工作区）+ 两侧各自的启动 `.sh`

缺哪个就直接问用户，不要猜路径。用户指定了 rank 就用指定的 rank，没指定就用两边都有的最小 rank（通常 0）。

约定（下面命令都用它）：

```bash
SK="<本 skill 目录>/scripts"; WS="pa_out"; mkdir -p "$WS"
```

脚本只用 Python 标准库，Windows / Linux 都能直接跑。

## 分析流程

### Step 1 — 盘点两侧数据，选定 rank

```bash
python "$SK/pa_discover.py" --real <真机根目录> --sim <仿真根目录> --out "$WS/inventory.json"
```

看三件事：两边各有哪些 rank、trace_view.json 是否齐全、profiler 配置（`with_stack` /
`record_shapes` / `profiler_level`）是否一致。**采集配置不同会凭空造出"分歧"**，必须先排除。

如果两边 world size 不同（真机 0-7、仿真 0-3），照用户要求对同一个 rank 号，但要在报告里写清楚：
不同的 TP/PP/EP 切分下同一个 rank 号承担的层/专家可能不同，这种差异是配置带来的，不是仿真 bug。

### Step 2 — 从 .sh 入口进入代码，先排除配置差异

```bash
python "$SK/pa_shargs.py" --dir <repo>/examples --list          # 找出候选启动脚本
python "$SK/pa_shargs.py" --file <real.sh> --diff <sim.sh>       # 两侧启动参数对比
```

`--recompute-granularity`、`--moe-router-topk`、`--use-flash-attn`、`--sequence-parallel`
这类参数直接开关掉大段 `if args.xxx:`，参数不同就足以解释算子构成不同，跟仿真数值无关。
先把这类原因解释干净，剩下的才值得当作控制流分叉来查。

顺手记下入口 `.py`（一般是 `pretrain_gpt.py`）和它 import 的训练主循环位置，Step 6 要用。

### Step 3 — 算子序列对齐（核心，thread 级，host/device 分开）

```bash
python "$SK/pa_align.py" \
  --real <real>/ASCEND_PROFILER_OUTPUT/trace_view.json \
  --sim  <sim>/ASCEND_PROFILER_OUTPUT/trace_view.json \
  --outdir "$WS/rank0" --rank 0 --step -2
```

- `--step -2` 表示取倒数第二个 `ProfilerStep`：**永远优先比稳态迭代**，第 0 步混着编译、
  权重初始化、cache 预热，两边天然不同，拿它对齐会得到一堆假分歧。
- 输出 `alignment.md` / `alignment.json`。先读 `alignment.md` 的第 1 节（track 分类与配对）
  **确认配对没配错**：thread id 和 stream id 是每次运行现分配的，脚本按线程名和算子分布相似度
  配对，配错了后面全是噪声。配错就用 `--pair "真机label==仿真label"` 手工指定。
- 读第 2 节的首个分歧点。分歧按 framework(aten) → CANN → device 排序，**framework 层的分歧
  离代码最近，优先看它**。
- 第 4 节"同名算子 shape 不一致"是 tensor 级线索：控制流还没岔开、但数据已经不同，
  往往是分支翻转的前兆（比如 MoE 路由把不同数量的 token 发给了专家）。

判读要点：

| 现象 | 含义 |
| --- | --- |
| host framework 层就分歧 | 真的走了不同 Python 分支 → 继续 Step 6 |
| host 一致、device 有增删 | 下发一致但设备侧执行不同：多为融合/算子选择/aclnn 分支，看 CANN 层 |
| 只是同名算子顺序在多个 stream 间轮换 | 调度差异，不是控制流问题，不要过度解读 |
| 两边序列完全一致 | 控制流没分叉，热力图的不同来自时延建模，直接结论即可 |

### Step 4 — 算子热力图

```bash
python "$SK/pa_heatmap.py" --real <real trace> --sim <sim trace> \
  --outdir "$WS/rank0" --alignment "$WS/rank0/alignment.json" --step -2
```

横轴是**算子序号占比**而不是时间（理由同上）。终端会直接打印 ASCII 热力图，可以立刻读；
`heatmap.html` 给人看，红框列是首个分歧位置。类型走向条（cube/vector/comm/...）最直观：
两边走向条在某一列之后开始错位，那一列就是"热力图对不上"的起点。

### Step 5 — Perfetto 可视化（给人看的直观证据）

```bash
python "$SK/pa_perfetto.py" merge --real <real trace> --sim <sim trace> \
  --out "$WS/merged_rank0.json" --step -2
python "$SK/pa_perfetto.py" serve --file "$WS/merged_rank0.json" --port 9001
```

merge 会把两侧放进**同一条时间轴**（各自平移到 t=0，进程名加 `[REAL]` / `[SIM]` 前缀），
在一个窗口里上下对照比开两个标签页有效得多。serve 打印两个链接，给用户点：

- `https://ui.perfetto.dev/#!/?url=http://127.0.0.1:9001/...`（**端口必须是 9001**，
  Perfetto 的 CSP 只放行这一个本地 http 端口）
- `http://127.0.0.1:9001/pa_open_perfetto.html`（deep link 被浏览器拦住时用这个）

细节和已知限制见 `references/perfetto-workflow.md`，**其中最重要的一条**：Claude 自己的
内置浏览器会拦截 https 页面对 127.0.0.1 的请求，所以 Perfetto 这一步是给用户看的，
不要指望在 agent 的浏览器里把 trace 加载出来；agent 自己的判断依据用脚本输出和
`heatmap.html`。把链接和"该看什么"一起给用户。

### Step 6 — 从分歧算子回到代码里的 if-else

```bash
python "$SK/pa_evidence.py" --trace <real trace> --alignment "$WS/rank0/alignment.json" \
  --repo <模型代码根目录> --out "$WS/rank0/evidence.md"
```

这一步基于一个很强的约束：**Python 里的 `if` 只可能在"设备上的值回到 host"的地方分叉**。
值要跨到 host，必然经过 `.item()`（`aten::_local_scalar_dense`）、`.cpu()` / D2H `Memcpy`、
`bool(tensor)`、`nonzero()`、溢出检查、stream 同步这些点。所以可疑 if 的候选集不是"模型里
所有的 if"，而是分歧点之前那一小撮同步点——一张能读完的表。

输出里按调用点聚合，**每步只执行一两次的调用点最可疑**（溢出检查、grad-norm、路由统计、
early-exit 判断），执行上万次的通常是逐算子例行拷贝。

拿到候选调用点后：

1. 打开对应 `file:line`，读上下文，找到消费这个值的 `if / while / assert`，记下判据表达式。
2. 确认它依赖的 tensor 是哪个（`found_inf`、`grad_norm`、`router_logits`/`topk_idx`、
   `seq_len`、`eos_mask` ...）。
3. 对照 Step 3 的分歧算子：真机走的分支产生哪些算子、仿真走的分支产生哪些算子，一一对上。

常见分叉模式（溢出跳步、MoE 路由、动态 shape、early exit、重计算阈值……）和它们各自会
产生的算子特征，见 `references/divergence-patterns.md` —— 先查这张表，能省掉大量翻代码。

若调用栈是空的，说明采集时没开 `with_stack`。此时退回用 `nn.Module:` 模块栈定位，
并在报告里建议重采一次真机 profiling（`with_stack=True, with_modules=True, record_shapes=True`）。

### Step 7 —（可选，但这是唯一的硬证据）分支探针复跑

推测出候选 if 之后，如果能重跑模型，就用探针把"哪一行、第几次迭代走了不同分支"直接打出来：

```bash
export PYTHONPATH="$SK:$PYTHONPATH"
export PA_PROBE_OUT=/tmp/branch_real PA_PROBE_INCLUDE=<repo>/mindspeed_llm,<repo>/megatron/core
export PA_PROBE_MAX_ITERS=3
# 把启动脚本里的 `python pretrain_gpt.py ...` 换成：
#   python -m pa_branch_probe pretrain_gpt.py ...
# torchrun 同理：torchrun ... -m pa_branch_probe pretrain_gpt.py ...
python "$SK/pa_branch_probe.py" --diff /tmp/branch_real.rank0.log /tmp/branch_sim.rank0.log
```

它只记录含条件跳转的行和它实际跳到的下一行，diff 出来就是"第一次走岔的那一行"。
`PA_PROBE_INCLUDE` 要窄（只放怀疑的目录），跑 2-3 个迭代就够，否则又慢又难读。

### Step 8 — 出报告

按 `references/report-template.md` 的结构写。报告必须落到这三件事，否则等于没结论：
**哪一行代码的判定不同 → 判的是哪个 tensor → 因此多了/少了哪些算子**。

## 贯穿全程的判读纪律

- **不比耗时。** 提到时间只能是为了确定顺序，任何"仿真快/慢了多少"的结论都不写。
- **先证伪再下结论。** 采集配置差异、启动参数差异、rank 角色差异、step 选错（拿 step0 比），
  这四个是最常见的假分歧来源，报告里要写明已排除。
- **host 和 device 分开说。** host(aten/CANN) 是"下发了什么"，device(Ascend Hardware/HCCL)
  是"执行了什么"。host 一致而 device 不同，和 host 就不同，是完全不同的两类问题。
- **区分"证据"和"推测"。** 从 trace 里读出来的（算子名、shape、调用栈、行号）是证据；
  "可能是因为路由概率不同"是推测，必须标注为待验证，并给出验证方法（Step 7 或加打点）。
- 数据量大时先切一个 step 再分析；trace_view.json 上百 MB 时 `--step` 几乎是必须的。

## 参考资料

| 文件 | 什么时候读 |
| --- | --- |
| `references/trace-format.md` | 需要理解目录结构、trace_view.json 字段、host/device 怎么分、CSV 列含义时 |
| `references/divergence-patterns.md` | 拿到分歧算子后查"这种差异一般是哪种分支造成的" |
| `references/perfetto-workflow.md` | 用 Perfetto 看图、写 SQL 查询、遇到加载失败时 |
| `references/report-template.md` | 写最终报告时 |

#!/usr/bin/env python3
"""Map structural operator divergence to Python control-flow guards without executing code.

The analyzer reads ``divergence_windows.jsonl`` from align_profiles.py, parses repository
Python with :mod:`ast`, and ranks if/elif/else, conditional-expression, and match/case
candidates whose branch-exclusive calls explain the observed Host operator paths. It never
imports, evaluates, compiles, or runs repository code.
"""

from __future__ import annotations

import argparse
import ast
import csv
import hashlib
import json
import re
import subprocess
import tempfile
from collections import Counter, defaultdict
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Iterable
from urllib.parse import quote, urlsplit, urlunsplit


SCHEMA_VERSION = 4
ALGORITHM_VERSION = "ascend-framework-guard-evidence-v4"
EXCLUDED_DIRS = {
    ".git", ".hg", ".svn", ".venv", "venv", "env", "node_modules", "__pycache__",
    "build", "dist", ".tox", ".mypy_cache", ".pytest_cache", "site-packages",
}
OP_FAMILIES = [
    {"linear", "addmm", "mm", "matmul", "gemm"},
    {"relu", "relu_"},
    {"sigmoid", "sigmoid_"},
    {"softmax", "log_softmax"},
    {"all_reduce", "allreduce", "all_reduce_"},
    {"all_gather", "allgather", "all_gather_into_tensor"},
    {"reduce_scatter", "reduce_scatter_tensor", "reducescatter"},
    {"scaled_dot_product_attention", "flash_attention", "attention"},
    {"topk", "top_k"},
]
SENSITIVE_QUERY_KEYS = re.compile(r"token|password|secret|key|cookie|credential|auth", re.I)
CANDIDATE_CSV_FIELDS = [
    "evidence_id", "candidate_rank", "divergence_id", "rank_pair_id", "thread_pair_id",
    "semantic_layer", "guard_id", "guard_path", "guard_symbol", "guard_lines", "guard_kind",
    "predicate_text", "predicate_ast_hash", "real_arm", "real_arm_lines", "sim_arm",
    "sim_arm_lines", "real_operators", "sim_operators", "branch_fingerprint", "mapping_score",
    "stack_binding_level", "real_stack_binding_level", "sim_stack_binding_level",
    "boundary_stability", "lane_match_status", "lane_match_confidence",
    "lane_high_confidence", "anchors_before", "anchors_after", "anchor_gate_passed",
    "repeated_anchor_ambiguous", "nesting_gate_passed", "entrypoint_binding_level",
    "runtime_binding", "predicate_real_result", "predicate_sim_result",
    "predicate_results_opposite", "direct_operand_values_observed", "real_operand_values",
    "sim_operand_values", "analyzed_source_gate_passed", "dependency_source_gate_passed",
    "dependency_source_gate_field", "source_component", "run_contract_sha256",
    "indexed_head_commit", "indexed_tree_hash", "source_scan_complete",
    "run_comparability_status", "run_confounders",
    "strength", "repository", "commit", "permalink", "minimal_missing_evidence",
    "claim_boundary",
]
EMPTY_CSV_SCHEMAS: dict[str, list[str]] = {
    "control_flow_guard_candidates.csv": CANDIDATE_CSV_FIELDS,
    "predicate_tensor_evidence.csv": [
        "evidence_id", "divergence_id", "rank_pair_id", "semantic_layer", "guard_id",
        "operand_expr", "operand_kind", "producer_path", "producer_line_start",
        "producer_expression", "producer_status", "runtime_value_status",
    ],
    "event_source_map.csv": [
        "evidence_id", "environment", "rank_pair_id", "thread_pair_id", "semantic_layer",
        "operator", "source_call", "path", "line_start", "line_end", "symbol", "confidence",
    ],
    "branch_device_evidence.csv": [
        "divergence_id", "rank_pair_id", "thread_pair_id", "environment", "host_event_id",
        "device_event_id", "device_operator", "device_stream_id", "device_task_id",
        "device_task_type", "link_status", "link_namespace", "endpoint_match",
        "causal_eligible", "link_evidence_ids",
    ],
    "source_evidence.csv": [
        "evidence_id", "environment", "repository", "commit", "path", "line_start",
        "line_end", "symbol", "evidence_kind", "content_sha256", "permalink",
    ],
    "source_entrypoint_chain.csv": ["chain_kind", "source", "target", "status", "evidence"],
    "source_analysis_issues.csv": ["path", "issue", "detail", "impact"],
}
SOURCE_ARTIFACT_NAMES = [
    "control_flow_guard_candidates.csv", "control_flow_evidence.jsonl",
    "predicate_tensor_evidence.csv", "event_source_map.csv",
    "branch_device_evidence.csv", "source_evidence.csv",
    "source_entrypoint_chain.csv", "source_analysis_issues.csv",
]


def clean(value: Any, limit: int = 8000) -> str:
    if value is None:
        return ""
    if isinstance(value, (dict, list, tuple)):
        value = json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"))
    text = re.sub(r"\s+", " ", str(value)).strip()
    return text if len(text) <= limit else text[: limit - 3] + "..."


def stable_hash(*parts: Any, length: int = 64) -> str:
    payload = "\x1f".join(str(part) for part in parts)
    return hashlib.sha256(payload.encode("utf-8", errors="replace")).hexdigest()[:length]


def compact_json(value: Any, limit: int = 16000) -> str:
    return clean(json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":")), limit)


RUN_CONTRACT_FIELDS = (
    "analyzed_source", "model_code", "dependency_code", "pytorch_version",
    "torch_npu_version", "cann_version", "workload", "phase", "profiler_schedule",
    "input", "weights", "seed", "config", "parallel_topology",
)
RUN_CONTRACT_STATUSES = {"verified", "user-declared", "unknown", "conflict"}


def _contract_fact(side: dict[str, Any], field_name: str) -> dict[str, Any]:
    raw = side.get(field_name)
    if not isinstance(raw, dict):
        return {
            "value": clean(raw, 4000) if raw not in (None, "") else "",
            "status": "unknown",
            "evidence": "",
            "structured": False,
        }
    status = clean(raw.get("status"), 100).casefold() or "unknown"
    if status not in RUN_CONTRACT_STATUSES:
        raise ValueError(
            f"run contract {field_name}.status={status!r} 非法；"
            f"仅允许 {sorted(RUN_CONTRACT_STATUSES)}"
        )
    if field_name == "analyzed_source":
        snapshot = {
            "component": clean(raw.get("component"), 200).casefold(),
            "repository": clean(raw.get("repository"), 2000),
            "commit": clean(raw.get("commit"), 200).casefold(),
            "tree_hash": clean(raw.get("tree_hash"), 200).casefold(),
            "build_id": clean(raw.get("build_id"), 500),
        }
        return {
            "value": json.dumps(
                snapshot, ensure_ascii=False, sort_keys=True, separators=(",", ":")
            ),
            "status": status,
            "evidence": clean(raw.get("evidence"), 4000),
            "structured": all(
                snapshot[field] for field in ("component", "repository", "commit", "tree_hash")
            ),
            **snapshot,
        }
    value = raw.get("value", "")
    if isinstance(value, (dict, list, tuple)):
        value = json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"))
    return {
        "value": clean(value, 4000),
        "status": status,
        "evidence": clean(raw.get("evidence"), 4000),
        "structured": True,
    }


def load_run_comparability(path: Path | None) -> dict[str, Any]:
    """Read the two-sided run contract used to gate source-causal promotion.

    ``analyzed_source`` means the exact repository/component currently indexed by this
    invocation.  A model repository commit therefore cannot stand in for a TorchNPU/FSDP
    patch snapshot.  The analyzer intentionally refuses to infer this identity from a
    version string printed in prose.
    """
    result: dict[str, Any] = {
        "status": "missing",
        "path": "",
        "sha256": "",
        "analyzed_source_gate_passed": False,
        "fields": {},
        "confounders": ["缺少两侧 run_comparability_contract.json"],
    }
    if path is None:
        return result
    resolved = path.resolve()
    try:
        raw_payload = resolved.read_bytes()
        payload = json.loads(raw_payload.decode("utf-8-sig"))
    except (OSError, UnicodeError, json.JSONDecodeError) as exc:
        raise ValueError(f"无法读取 run contract {resolved}: {exc}") from exc
    if not isinstance(payload, dict) or not isinstance(payload.get("real"), dict) or not isinstance(payload.get("sim"), dict):
        raise ValueError("run contract 必须是含 real/sim 对象的 JSON")
    fields: dict[str, Any] = {}
    confounders: list[str] = []
    for field_name in RUN_CONTRACT_FIELDS:
        real_fact = _contract_fact(payload["real"], field_name)
        sim_fact = _contract_fact(payload["sim"], field_name)
        same_value = bool(real_fact["value"] and sim_fact["value"] and real_fact["value"] == sim_fact["value"])
        both_verified = real_fact["status"] == sim_fact["status"] == "verified"
        if not same_value:
            comparison = "different" if real_fact["value"] and sim_fact["value"] else "unknown"
        elif both_verified:
            comparison = "verified-equal"
        else:
            comparison = "declared-or-unverified-equal"
        fields[field_name] = {
            "real": real_fact,
            "sim": sim_fact,
            "comparison": comparison,
        }
        if comparison != "verified-equal":
            confounders.append(f"{field_name}:{comparison}")
    analyzed_source = fields["analyzed_source"]
    source_evidence_present = all(
        analyzed_source[side]["evidence"] for side in ("real", "sim")
    )
    source_structured = all(
        analyzed_source[side].get("structured") for side in ("real", "sim")
    )
    source_gate = (
        analyzed_source["comparison"] == "verified-equal"
        and source_evidence_present and source_structured
    )
    if analyzed_source["comparison"] == "verified-equal" and not source_evidence_present:
        confounders.append("analyzed_source:verified status 缺少两侧 evidence")
    if not source_structured:
        confounders.append(
            "analyzed_source 必须结构化包含 component/repository/commit/tree_hash"
        )
    all_fields_verified_equal = all(
        field["comparison"] == "verified-equal" for field in fields.values()
    )
    result.update(
        {
            "status": "complete" if all_fields_verified_equal else "partial",
            "path": str(resolved),
            "sha256": hashlib.sha256(raw_payload).hexdigest(),
            "analyzed_source_gate_passed": source_gate,
            "fields": fields,
            "confounders": confounders,
        }
    )
    return result


def bind_run_comparability_to_indexed_source(
    run_comparability: dict[str, Any], source_snapshot: dict[str, Any],
) -> dict[str, Any]:
    """Require exact component/commit/tree identity for the snapshot being indexed."""
    if not run_comparability.get("analyzed_source_gate_passed"):
        return run_comparability
    source_field = run_comparability["fields"]["analyzed_source"]
    head = clean(source_snapshot.get("head_commit"), 200).casefold()
    tree_hash = clean(source_snapshot.get("tree_hash"), 200).casefold()
    remote = clean(source_snapshot.get("remote"), 2000).removesuffix(".git").casefold()
    exact = bool(head and tree_hash)
    for side in ("real", "sim"):
        fact = source_field[side]
        exact = exact and fact.get("commit") == head
        exact = exact and fact.get("tree_hash") == tree_hash
        if remote:
            exact = exact and fact.get("repository", "").removesuffix(".git").casefold() == remote
    if not exact:
        run_comparability["analyzed_source_gate_passed"] = False
        run_comparability["status"] = "partial"
        run_comparability["confounders"].append(
            "analyzed_source repository/commit/tree_hash 与实际索引 Git 快照不完全一致"
        )
    return run_comparability


def _verified_equal_run_field(run_comparability: dict[str, Any], field_name: str) -> bool:
    field = run_comparability.get("fields", {}).get(field_name, {})
    if field.get("comparison") != "verified-equal":
        return False
    return all(field.get(side, {}).get("evidence") for side in ("real", "sim"))


def guard_owner_component(guard_path: str) -> str:
    path = guard_path.replace("\\", "/").casefold()
    if "torch_npu" in path or "_add_fsdp_patch" in path:
        return "torch_npu"
    if (
        path.startswith("torch/")
        or "/torch/" in path
        or path.startswith("torch/distributed/fsdp/")
        or "/torch/distributed/fsdp/" in path
        or path.startswith("torch/distributed/_composable/fsdp/")
        or "/torch/distributed/_composable/fsdp/" in path
        or path.startswith("_fsdp_")
        or "/_fsdp_" in path
    ):
        return "pytorch"
    if "site-packages" in path:
        return "dependency"
    return "unknown"


def effective_owner_component(guard_path: str, source_component: str) -> str:
    path_owner = guard_owner_component(guard_path)
    if path_owner != "unknown":
        return path_owner
    component = clean(source_component, 200).casefold()
    if component in {"model", "torch_npu", "pytorch"}:
        return component
    if component == "dependency" or component.startswith("dependency:"):
        return "dependency"
    return "unknown"


def dependency_source_gate(
    guard_path: str, run_comparability: dict[str, Any], source_component: str,
) -> tuple[bool, str]:
    """Require exact owner component plus its runtime build/version identity."""
    owner = effective_owner_component(guard_path, source_component)
    component = clean(source_component, 200).casefold()
    owner_matches = component == owner or (owner == "dependency" and component.startswith("dependency:"))
    if not owner_matches:
        return False, f"owner={owner}; analyzed_component={component or 'missing'}"
    if owner == "torch_npu":
        return _verified_equal_run_field(run_comparability, "torch_npu_version"), "torch_npu_version"
    if owner == "pytorch":
        return _verified_equal_run_field(run_comparability, "pytorch_version"), "pytorch_version"
    if owner == "dependency":
        return _verified_equal_run_field(run_comparability, "dependency_code"), "dependency_code"
    return True, "model-source"


def sanitize_url(value: str) -> str:
    if not value:
        return ""
    try:
        parsed = urlsplit(value)
    except ValueError:
        return clean(value)
    if parsed.scheme not in {"http", "https"}:
        return clean(value)
    host = parsed.hostname or ""
    if parsed.port:
        host += f":{parsed.port}"
    query_parts = []
    for part in parsed.query.split("&"):
        key = part.split("=", 1)[0]
        if part and not SENSITIVE_QUERY_KEYS.search(key):
            query_parts.append(part)
    return urlunsplit((parsed.scheme, host, parsed.path, "&".join(query_parts), ""))


def write_csv(path: Path, rows: Iterable[dict[str, Any]], fields: list[str] | None = None) -> None:
    materialized = list(rows)
    path.parent.mkdir(parents=True, exist_ok=True)
    if fields is None:
        fields = []
        seen = set()
        for row in materialized:
            for key in row:
                if key not in seen:
                    seen.add(key)
                    fields.append(key)
        if not fields:
            fields = EMPTY_CSV_SCHEMAS.get(path.name, ["message"])
    with path.open("w", newline="", encoding="utf-8-sig") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields, extrasaction="ignore")
        writer.writeheader()
        writer.writerows(materialized)


def write_json(path: Path, value: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8") as handle:
        json.dump(value, handle, ensure_ascii=False, indent=2)


def write_jsonl(path: Path, rows: Iterable[dict[str, Any]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8") as handle:
        for row in rows:
            handle.write(json.dumps(row, ensure_ascii=False, sort_keys=True) + "\n")


def artifact_integrity(output: Path, names: Iterable[str]) -> dict[str, dict[str, Any]]:
    """Bind every emitted source-causality artifact to this manifest run."""
    result: dict[str, dict[str, Any]] = {}
    output_resolved = output.resolve()
    for name in names:
        path = (output / name).resolve()
        if path.parent != output_resolved or not path.is_file():
            raise ValueError(f"source-causality artifact 缺失或越界: {name}")
        raw = path.read_bytes()
        result[name] = {
            "sha256": hashlib.sha256(raw).hexdigest(),
            "bytes": len(raw),
            "nonempty": bool(raw),
        }
    return result


def read_csv(path: Path) -> list[dict[str, str]]:
    if not path.is_file():
        return []
    with path.open("r", newline="", encoding="utf-8-sig", errors="replace") as handle:
        return list(csv.DictReader(handle))


def read_jsonl(path: Path) -> list[dict[str, Any]]:
    rows = []
    if not path.is_file():
        return rows
    with path.open("r", encoding="utf-8", errors="replace") as handle:
        for line_number, line in enumerate(handle, 1):
            if not line.strip():
                continue
            value = json.loads(line)
            if not isinstance(value, dict):
                raise ValueError(f"{path}:{line_number} 不是 JSON object")
            rows.append(value)
    return rows


def is_within(path: Path, root: Path) -> bool:
    try:
        path.resolve().relative_to(root.resolve())
        return True
    except ValueError:
        return False


def dotted_name(node: ast.AST) -> str:
    if isinstance(node, ast.Name):
        return node.id
    if isinstance(node, ast.Attribute):
        prefix = dotted_name(node.value)
        return f"{prefix}.{node.attr}" if prefix else node.attr
    if isinstance(node, ast.Subscript):
        return dotted_name(node.value)
    if isinstance(node, ast.Call):
        return dotted_name(node.func)
    return ""


def operator_base(value: str) -> str:
    text = clean(value, 1000).casefold()
    if "::" in text:
        text = text.split("::", 1)[1]
    text = text.split(".", 1)[0]
    text = re.sub(r"[^a-z0-9_]+", "_", text).strip("_")
    return text


def family_for(base: str) -> frozenset[str]:
    for family in OP_FAMILIES:
        if base in family:
            return frozenset(family)
    return frozenset({base})


def op_matches(profiler_op: str, source_call: str) -> bool:
    profiler = operator_base(profiler_op)
    call = operator_base(source_call.rsplit(".", 1)[-1])
    if not profiler or not call:
        return False
    return profiler == call or bool(family_for(profiler) & family_for(call))


def source_segment(source: str, node: ast.AST, limit: int = 2000) -> str:
    value = ast.get_source_segment(source, node)
    if value:
        return clean(value, limit)
    try:
        return clean(ast.unparse(node), limit)
    except Exception:
        return f"<{type(node).__name__}>"


def node_range(nodes: list[ast.stmt]) -> tuple[int, int]:
    if not nodes:
        return 0, 0
    starts = [getattr(node, "lineno", 0) for node in nodes]
    ends = [getattr(node, "end_lineno", getattr(node, "lineno", 0)) for node in nodes]
    return min(starts), max(ends)


def predicate_operands(node: ast.AST) -> list[dict[str, str]]:
    rows: dict[str, dict[str, str]] = {}
    for child in ast.walk(node):
        if isinstance(child, ast.Name) and isinstance(child.ctx, ast.Load):
            rows.setdefault(child.id, {"expr": child.id, "kind": "name"})
        elif isinstance(child, ast.Attribute) and isinstance(child.ctx, ast.Load):
            expr = dotted_name(child)
            rows.setdefault(expr, {"expr": expr, "kind": "attribute"})
        elif isinstance(child, ast.Subscript) and isinstance(child.ctx, ast.Load):
            expr = dotted_name(child.value)
            rows.setdefault(expr, {"expr": expr, "kind": "subscript"})
        elif isinstance(child, ast.Call):
            expr = dotted_name(child.func)
            kind = "data-value-call" if expr.rsplit(".", 1)[-1] in {"item", "any", "all", "nonzero", "tolist"} else "call"
            rows.setdefault(expr, {"expr": expr, "kind": kind})
    return sorted(rows.values(), key=lambda row: (row["expr"], row["kind"]))


def guard_kind(predicate: str, operands: list[dict[str, str]]) -> str:
    text = predicate.casefold()
    if any(item["kind"] == "data-value-call" for item in operands):
        return "tensor-data-value"
    if any(token in text for token in (".shape", ".size(", ".numel(", ".dtype", ".device", ".dim(")):
        return "tensor-metadata"
    if any(token in text for token in ("os.environ", "getenv", "config", "args.", "backend", "version")):
        return "config/backend"
    return "python-value-or-config"


@dataclass
class SourceCall:
    path: str
    line: int
    end_line: int
    symbol: str
    call_name: str
    call_text: str
    guard_path: list[tuple[str, str]]


@dataclass
class Assignment:
    path: str
    line: int
    end_line: int
    symbol: str
    targets: list[str]
    rhs_text: str
    rhs_calls: list[str]


@dataclass
class Guard:
    guard_id: str
    path: str
    symbol: str
    kind: str
    line_start: int
    line_end: int
    predicate_text: str
    predicate_ast_hash: str
    guard_kind: str
    operands: list[dict[str, str]]
    arms: dict[str, tuple[int, int]]
    arm_calls: dict[str, list[int]] = field(default_factory=lambda: defaultdict(list))


class SourceVisitor(ast.NodeVisitor):
    def __init__(self, relative_path: str, source: str) -> None:
        self.relative_path = relative_path
        self.source = source
        self.symbol_stack: list[str] = ["<module>"]
        self.guard_stack: list[tuple[str, str]] = []
        self.guards: list[Guard] = []
        self.guard_by_id: dict[str, Guard] = {}
        self.calls: list[SourceCall] = []
        self.assignments: list[Assignment] = []

    @property
    def symbol(self) -> str:
        return ".".join(self.symbol_stack)

    def _visit_symbol(self, node: ast.AST, name: str) -> None:
        self.symbol_stack.append(name)
        self.generic_visit(node)
        self.symbol_stack.pop()

    def visit_ClassDef(self, node: ast.ClassDef) -> Any:
        self._visit_symbol(node, node.name)

    def visit_FunctionDef(self, node: ast.FunctionDef) -> Any:
        self._visit_symbol(node, node.name)

    def visit_AsyncFunctionDef(self, node: ast.AsyncFunctionDef) -> Any:
        self._visit_symbol(node, node.name)

    def _new_guard(
        self, node: ast.AST, kind: str, predicate_node: ast.AST, arms: dict[str, list[ast.stmt]]
    ) -> Guard:
        predicate = source_segment(self.source, predicate_node)
        operands = predicate_operands(predicate_node)
        arm_ranges = {name: node_range(statements) for name, statements in arms.items()}
        guard_id = "guard-" + stable_hash(
            self.relative_path, self.symbol, getattr(node, "lineno", 0), kind, predicate, length=20
        )
        guard = Guard(
            guard_id=guard_id, path=self.relative_path, symbol=self.symbol, kind=kind,
            line_start=getattr(node, "lineno", 0),
            line_end=getattr(node, "end_lineno", getattr(node, "lineno", 0)),
            predicate_text=predicate, predicate_ast_hash=stable_hash(ast.dump(predicate_node), length=24),
            guard_kind=guard_kind(predicate, operands), operands=operands, arms=arm_ranges,
        )
        self.guards.append(guard)
        self.guard_by_id[guard_id] = guard
        return guard

    def _visit_arm(self, guard: Guard, arm_name: str, nodes: list[ast.AST]) -> None:
        self.guard_stack.append((guard.guard_id, arm_name))
        for child in nodes:
            self.visit(child)
        self.guard_stack.pop()

    def visit_If(self, node: ast.If) -> Any:
        guard = self._new_guard(node, "if", node.test, {"if": node.body, "else": node.orelse})
        self.visit(node.test)
        self._visit_arm(guard, "if", node.body)
        self._visit_arm(guard, "else", node.orelse)

    def visit_IfExp(self, node: ast.IfExp) -> Any:
        guard = self._new_guard(node, "if-expression", node.test, {"if": [], "else": []})
        self.visit(node.test)
        self._visit_arm(guard, "if", [node.body])
        self._visit_arm(guard, "else", [node.orelse])

    def visit_Match(self, node: ast.Match) -> Any:
        pseudo_predicate = node.subject
        arms = {f"case-{index}": case.body for index, case in enumerate(node.cases)}
        guard = self._new_guard(node, "match", pseudo_predicate, arms)
        self.visit(node.subject)
        for index, case in enumerate(node.cases):
            if case.guard:
                self.visit(case.guard)
            self._visit_arm(guard, f"case-{index}", case.body)

    def visit_Call(self, node: ast.Call) -> Any:
        call_name = dotted_name(node.func)
        call = SourceCall(
            path=self.relative_path, line=getattr(node, "lineno", 0),
            end_line=getattr(node, "end_lineno", getattr(node, "lineno", 0)), symbol=self.symbol,
            call_name=call_name, call_text=source_segment(self.source, node),
            guard_path=list(self.guard_stack),
        )
        index = len(self.calls)
        self.calls.append(call)
        for guard_id, arm in self.guard_stack:
            self.guard_by_id[guard_id].arm_calls[arm].append(index)
        self.generic_visit(node)

    def _record_assignment(self, node: ast.AST, targets: list[ast.AST], value: ast.AST | None) -> None:
        names = []
        for target in targets:
            for child in ast.walk(target):
                if isinstance(child, ast.Name) and isinstance(child.ctx, ast.Store):
                    names.append(child.id)
                elif isinstance(child, ast.Attribute) and isinstance(child.ctx, ast.Store):
                    names.append(dotted_name(child))
        if not names:
            return
        rhs_calls = [dotted_name(child.func) for child in ast.walk(value) if isinstance(child, ast.Call)] if value else []
        self.assignments.append(
            Assignment(
                path=self.relative_path, line=getattr(node, "lineno", 0),
                end_line=getattr(node, "end_lineno", getattr(node, "lineno", 0)),
                symbol=self.symbol, targets=sorted(set(names)),
                rhs_text=source_segment(self.source, value) if value else "",
                rhs_calls=sorted(set(filter(None, rhs_calls))),
            )
        )

    def visit_Assign(self, node: ast.Assign) -> Any:
        self._record_assignment(node, node.targets, node.value)
        self.generic_visit(node)

    def visit_AnnAssign(self, node: ast.AnnAssign) -> Any:
        self._record_assignment(node, [node.target], node.value)
        self.generic_visit(node)

    def visit_AugAssign(self, node: ast.AugAssign) -> Any:
        self._record_assignment(node, [node.target], node.value)
        self.generic_visit(node)


@dataclass
class SourceIndex:
    guards: list[Guard] = field(default_factory=list)
    calls: list[SourceCall] = field(default_factory=list)
    assignments: list[Assignment] = field(default_factory=list)
    evidence: list[dict[str, Any]] = field(default_factory=list)
    issues: list[dict[str, Any]] = field(default_factory=list)
    discovery: dict[str, Any] = field(default_factory=dict)


def discover_python_files(
    repo_root: Path, max_files: int, max_bytes: int
) -> tuple[list[Path], dict[str, Any]]:
    files: list[Path] = []
    used_bytes = 0
    truncated = False
    first_unindexed_path = ""
    truncation_reason = ""
    for path in sorted(repo_root.rglob("*.py")):
        if any(part in EXCLUDED_DIRS for part in path.relative_to(repo_root).parts):
            continue
        try:
            resolved = path.resolve()
            if not is_within(resolved, repo_root):
                continue
            size = path.stat().st_size
        except OSError:
            continue
        if len(files) >= max_files or used_bytes + size > max_bytes:
            truncated = True
            first_unindexed_path = path.relative_to(repo_root).as_posix()
            truncation_reason = "max_files" if len(files) >= max_files else "max_bytes"
            break
        files.append(path)
        used_bytes += size
    return files, {
        "max_python_files": max_files,
        "max_python_bytes": max_bytes,
        "selected_files": len(files),
        "selected_bytes": used_bytes,
        "truncated": truncated,
        "truncation_reason": truncation_reason,
        "first_unindexed_path": first_unindexed_path,
    }


def index_source(repo_root: Path, max_files: int, max_bytes: int) -> SourceIndex:
    result = SourceIndex()
    files, discovery = discover_python_files(repo_root, max_files, max_bytes)
    result.discovery = discovery
    if discovery["truncated"]:
        result.issues.append(
            {
                "path": discovery["first_unindexed_path"],
                "issue": "source-scan-budget-truncated",
                "detail": (
                    f"reason={discovery['truncation_reason']}; selected_files="
                    f"{discovery['selected_files']}; selected_bytes={discovery['selected_bytes']}"
                ),
                "impact": "源码 guard 搜索不完整；所有候选最多为静态候选",
            }
        )
    for path in files:
        relative = path.relative_to(repo_root).as_posix()
        try:
            source = path.read_text(encoding="utf-8-sig", errors="strict")
            tree = ast.parse(source, filename=relative, type_comments=True)
            visitor = SourceVisitor(relative, source)
            visitor.visit(tree)
            call_offset = len(result.calls)
            for guard in visitor.guards:
                guard.arm_calls = {
                    arm: [call_offset + position for position in positions]
                    for arm, positions in guard.arm_calls.items()
                }
            result.guards.extend(visitor.guards)
            result.calls.extend(visitor.calls)
            result.assignments.extend(visitor.assignments)
            result.evidence.append(
                {"evidence_id": "source-" + stable_hash(relative, length=20), "path": relative,
                 "line_start": 1, "line_end": len(source.splitlines()), "symbol": "<module>",
                 "evidence_kind": "python-ast-parsed", "content_sha256": hashlib.sha256(
                     source.encode("utf-8")
                 ).hexdigest(), "note": "只读 ast.parse；未 import/执行"}
            )
        except (OSError, UnicodeError, SyntaxError) as error:
            result.issues.append(
                {"path": relative, "issue": type(error).__name__, "detail": clean(error),
                 "impact": "该文件中的 guard/callsite 不可见"}
            )
    return result


def git_metadata(repo_root: Path, requested_commit: str, repository_url: str) -> dict[str, Any]:
    """Resolve the source snapshot actually indexed, never trusting ``--commit`` as HEAD.

    A caller-provided commit is a claim to verify, not a replacement for ``git rev-parse
    HEAD``.  Non-Git directories remain unverified and cannot support promoted runtime
    source causality in this analyzer version.
    """
    requested = clean(requested_commit, 200)
    remote = sanitize_url(repository_url)
    result: dict[str, Any] = {
        "is_git_repository": False,
        "requested_commit": requested,
        "requested_resolved_commit": "",
        "head_commit": "",
        "resolved_commit": requested,
        "tree_hash": "",
        "requested_matches_head": False,
        "binding_status": "unverified",
        "remote": remote,
        "worktree_dirty": "unknown",
        "worktree_status": "",
    }

    def git_output(arguments: list[str]) -> str:
        exclude_file = repo_root / ".git" / "info" / "exclude"
        completed = subprocess.run(
            [
                "git", "-c", f"core.excludesFile={exclude_file}",
                "-C", str(repo_root), *arguments,
            ],
            capture_output=True,
            text=True, timeout=10, check=True,
        )
        return completed.stdout.strip()

    if not (repo_root / ".git").exists():
        return result
    result["is_git_repository"] = True
    try:
        head = git_output(["rev-parse", "--verify", "HEAD^{commit}"])
        result["head_commit"] = head
        result["resolved_commit"] = head
        result["tree_hash"] = git_output(["rev-parse", "--verify", "HEAD^{tree}"])
    except (OSError, subprocess.SubprocessError):
        return result
    if requested:
        try:
            requested_resolved = git_output(
                ["rev-parse", "--verify", f"{requested}^{{commit}}"]
            )
            result["requested_resolved_commit"] = requested_resolved
            result["requested_matches_head"] = requested_resolved == result["head_commit"]
        except (OSError, subprocess.SubprocessError):
            result["requested_resolved_commit"] = ""
            result["requested_matches_head"] = False
    else:
        result["requested_matches_head"] = True
    try:
        status = git_output(["status", "--porcelain"])
        result["worktree_status"] = clean(status, 4000)
        result["worktree_dirty"] = "yes" if status else "no"
    except (OSError, subprocess.SubprocessError):
        pass
    if not remote:
        try:
            result["remote"] = sanitize_url(git_output(["remote", "get-url", "origin"]))
        except (OSError, subprocess.SubprocessError):
            pass
    result["binding_status"] = (
        "verified"
        if result["requested_matches_head"] and result["worktree_dirty"] == "no"
        else "conflict" if requested and not result["requested_matches_head"] else "unverified"
    )
    return result


def permalink(remote: str, commit: str, path: str, start: int, end: int) -> str:
    if not remote or not commit:
        return ""
    base = remote.removesuffix(".git")
    if base.startswith("git@") and ":" in base:
        host_path = base[4:].replace(":", "/", 1)
        base = "https://" + host_path
    if not base.startswith(("http://", "https://")):
        return ""
    return f"{base}/blob/{quote(commit, safe='')}/{quote(path, safe='/')}#L{start}-L{end}"


def stack_location_score(call: SourceCall, stacks: list[str]) -> int:
    path_slash = call.path.replace("\\", "/")
    score = 0
    for stack in stacks:
        normalized = stack.replace("\\", "/")
        if path_slash in normalized:
            score = max(score, 1)
            line_pattern = re.compile(rf"{re.escape(path_slash)}(?::|\",\s*line\s*){call.line}\b", re.I)
            if line_pattern.search(normalized):
                score = max(score, 2)
    return score


def guard_branch_calls(guard: Guard, index: SourceIndex) -> dict[str, list[SourceCall]]:
    return {arm: [index.calls[position] for position in positions] for arm, positions in guard.arm_calls.items()}


def match_ops_to_calls(operators: list[str], calls: list[SourceCall]) -> tuple[int, list[tuple[str, SourceCall]]]:
    matched: list[tuple[str, SourceCall]] = []
    remaining = list(calls)
    for operator in operators:
        for position, call in enumerate(remaining):
            if op_matches(operator, call.call_name):
                matched.append((operator, call))
                remaining.pop(position)
                break
    return len(matched), matched


def runtime_rows(path: Path | None) -> list[dict[str, str]]:
    if path is None:
        return []
    return read_csv(path)


def runtime_for_guard(
    rows: list[dict[str, str]], guard: Guard, rank_pair_id: str,
    thread_pair_id: str, divergence_id: str,
) -> list[dict[str, str]]:
    output = []
    for row in rows:
        # Runtime confirmation is scoped to the exact structural divergence. Missing
        # identifiers are not wildcards: otherwise one marker can bind every Rank/thread.
        if row.get("rank_pair_id") != rank_pair_id:
            continue
        if row.get("thread_pair_id") != thread_pair_id:
            continue
        if row.get("divergence_id") != divergence_id:
            continue
        if not runtime_environment_side(row.get("environment", "")):
            continue
        if row.get("guard_id") == guard.guard_id:
            output.append(row)
    return output


def runtime_environment_side(value: str) -> str:
    normalized = value.casefold()
    if any(token in normalized for token in ("real", "reference", "真机")):
        return "real"
    if any(token in normalized for token in ("sim", "candidate", "仿真")):
        return "sim"
    return ""


def normalized_predicate_result(value: Any) -> bool | None:
    normalized = clean(value, 100).casefold()
    if normalized in {"1", "true", "yes", "y", "是", "通过", "passed", "pass"}:
        return True
    if normalized in {"0", "false", "no", "n", "否", "未通过", "failed", "fail"}:
        return False
    return None


def opposite_runtime_results(rows: list[dict[str, str]]) -> tuple[bool, str, str]:
    by_environment: dict[str, list[bool]] = defaultdict(list)
    for row in rows:
        side = runtime_environment_side(row.get("environment", ""))
        result = normalized_predicate_result(row.get("predicate_result", ""))
        if side and result is not None:
            by_environment[side].append(result)
    real = sorted(set(by_environment.get("real", [])))
    sim = sorted(set(by_environment.get("sim", [])))
    return bool(len(real) == len(sim) == 1 and real[0] != sim[0]), compact_json(real), compact_json(sim)


def direct_operand_values(rows: list[dict[str, str]]) -> tuple[bool, str, str]:
    by_environment: dict[str, list[dict[str, str]]] = defaultdict(list)
    for row in rows:
        side = runtime_environment_side(row.get("environment", ""))
        operand = clean(row.get("operand") or row.get("operand_name"), 1000)
        value = clean(row.get("operand_value") or row.get("scalar_value"), 4000)
        producer = clean(row.get("producer_event_id"), 1000)
        if not side or not operand or not value or not producer:
            continue
        by_environment[side].append(
            {"operand": operand, "value": value, "producer_event_id": producer}
        )
    real = by_environment.get("real", [])
    sim = by_environment.get("sim", [])
    unique_real = {
        (row["operand"], row["value"], row["producer_event_id"]) for row in real
    }
    unique_sim = {
        (row["operand"], row["value"], row["producer_event_id"]) for row in sim
    }
    same_operand = bool(
        len(unique_real) == len(unique_sim) == 1
        and next(iter(unique_real))[0] == next(iter(unique_sim))[0]
    )
    return same_operand, compact_json(real), compact_json(sim)


def truthy(value: Any) -> bool:
    return clean(value, 100).casefold() in {"1", "true", "yes", "y", "是", "通过", "passed", "pass"}


def unresolved(value: Any) -> bool:
    return clean(value, 100).casefold() in {"1", "true", "yes", "y", "是", "存在", "unresolved"}


def integer_field(row: dict[str, Any], *names: str) -> int | None:
    for name in names:
        value = row.get(name)
        if value in (None, ""):
            continue
        try:
            return int(value)
        except (TypeError, ValueError):
            continue
    return None


def divergence_evidence_gates(divergence: dict[str, Any]) -> dict[str, Any]:
    """Return conservative gates for promoting a static guard to runtime evidence.

    Version-1 divergence rows did not carry lane confidence or anchor counts. They are
    deliberately treated as insufficient instead of silently inheriting high confidence.
    """
    status = clean(
        divergence.get("lane_match_status")
        or divergence.get("pair_status")
        or divergence.get("match_status"),
        100,
    ).casefold()
    confidence = clean(
        divergence.get("lane_match_confidence") or divergence.get("match_confidence"), 100
    ).casefold()
    lane_high = (
        status in {"matched", "exact", "matched-high", "高"}
        and confidence in {"high", "高", "verified"}
    )
    pre = integer_field(
        divergence, "anchors_before", "pre_anchor_count", "previous_anchor_count"
    )
    post = integer_field(
        divergence, "anchors_after", "post_anchor_count", "following_anchor_count"
    )
    direct_marker = truthy(
        divergence.get("direct_branch_marker") or divergence.get("runtime_branch_marker")
    )
    repeated_anchor_ambiguous = truthy(divergence.get("repeated_anchor_ambiguous")) or (
        "repeated" in clean(divergence.get("alignment_ambiguity"), 200).casefold()
    )
    explicit_anchor_gate = divergence.get("anchor_gate_passed")
    if explicit_anchor_gate not in (None, ""):
        anchor_gate = truthy(explicit_anchor_gate)
    else:
        anchor_gate = pre is not None and post is not None and pre >= 3 and post >= 3
    if direct_marker:
        anchor_gate = True
    nesting_gate = truthy(divergence.get("nesting_gate_passed"))
    return {
        "lane_match_status": status or "missing",
        "lane_match_confidence": confidence or "missing",
        "lane_high_confidence": lane_high,
        "anchors_before": pre,
        "anchors_after": post,
        "anchor_gate_passed": anchor_gate,
        "direct_branch_marker": direct_marker,
        "repeated_anchor_ambiguous": repeated_anchor_ambiguous,
        "nesting_gate_passed": nesting_gate,
    }


def entrypoint_binding_score(path: str, rows: list[dict[str, Any]]) -> int:
    """Score static evidence that a guard file is on the user-provided launch chain."""
    normalized = path.replace("\\", "/").casefold().lstrip("./")
    module_form = normalized.removesuffix(".py").replace("/", ".")
    score = 0
    for row in rows:
        for key in ("source", "target", "evidence"):
            value = clean(row.get(key), 16000).replace("\\", "/").casefold()
            if not value:
                continue
            if normalized in value or module_form in value:
                score = max(score, 2 if clean(row.get("status"), 100).casefold() == "resolved" else 1)
    return score


def producer_rows(guard: Guard, index: SourceIndex) -> list[dict[str, Any]]:
    output = []
    for operand in guard.operands:
        base = operand["expr"].split(".", 1)[0]
        candidates = [
            assignment for assignment in index.assignments
            if assignment.path == guard.path and assignment.symbol == guard.symbol
            and assignment.line < guard.line_start and any(
                target == operand["expr"] or target.split(".", 1)[0] == base for target in assignment.targets
            )
        ]
        candidates.sort(key=lambda assignment: assignment.line, reverse=True)
        if candidates:
            assignment = candidates[0]
            output.append(
                {"guard_id": guard.guard_id, "operand_expr": operand["expr"],
                 "operand_kind": operand["kind"], "producer_path": assignment.path,
                 "producer_line_start": assignment.line, "producer_line_end": assignment.end_line,
                 "producer_symbol": assignment.symbol, "producer_expression": assignment.rhs_text,
                 "producer_calls": compact_json(assignment.rhs_calls),
                 "producer_status": "nearest-static-assignment-before-guard",
                 "limitation": "静态 producer 候选；需 runtime tensor/value/marker 绑定"}
            )
        else:
            output.append(
                {"guard_id": guard.guard_id, "operand_expr": operand["expr"],
                 "operand_kind": operand["kind"], "producer_path": "", "producer_line_start": "",
                 "producer_line_end": "", "producer_symbol": guard.symbol, "producer_expression": "",
                 "producer_calls": "", "producer_status": "unresolved",
                 "limitation": "可能来自函数参数、属性、容器、闭包或动态赋值"}
            )
    return output


def collect_entrypoint_evidence(
    repo_root: Path, entries: list[str], source_analysis_dir: Path | None
) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    for entry in entries:
        candidate = (repo_root / entry).resolve() if not Path(entry).is_absolute() else Path(entry).resolve()
        status = "resolved" if candidate.exists() and is_within(candidate, repo_root) else "unresolved"
        relative = candidate.relative_to(repo_root).as_posix() if status == "resolved" else clean(entry)
        rows.append({"chain_kind": "user-entry", "source": clean(entry), "target": relative,
                     "status": status, "evidence": "user CLI --entry"})
    if source_analysis_dir and source_analysis_dir.is_dir():
        for filename, kind in (
            ("source_entrypoint_candidates.csv", "shell-entry-candidate"),
            ("shell_launch_chain.csv", "shell-launch-edge"),
            ("launch_command_candidates.csv", "launcher-candidate"),
        ):
            for row in read_csv(source_analysis_dir / filename):
                rows.append(
                    {"chain_kind": kind, "source": clean(row.get("source") or row.get("source_path") or row.get("path")),
                     "target": clean(row.get("target") or row.get("python_target") or row.get("entry")),
                     "status": clean(row.get("status") or row.get("resolution_status") or row.get("selected")),
                     "evidence": compact_json(row)}
                )
    return rows


def analyze(
    repo_root: Path, alignment_output: Path, output: Path, source_analysis_dir: Path | None,
    entries: list[str], repository_url: str, requested_commit: str, runtime_binding: str,
    runtime_value_path: Path | None, run_contract_path: Path | None,
    max_files: int, max_bytes: int,
) -> dict[str, Any]:
    repo_root = repo_root.resolve()
    alignment_output = alignment_output.resolve()
    output = output.resolve()
    if not repo_root.is_dir():
        raise ValueError(f"源码仓不存在：{repo_root}")
    if is_within(output, repo_root) or is_within(repo_root, output):
        raise ValueError("输出目录必须位于源码仓之外，且不能与源码仓互为祖先")
    all_divergences = read_jsonl(alignment_output / "divergence_windows.jsonl")
    divergences = [
        row for row in all_divergences
        if row.get("domain") == "host" and row.get("semantic_layer") == "framework_op"
    ]
    if not divergences:
        raise ValueError(
            "没有 semantic_layer=framework_op 的 Host divergence_windows 可映射；"
            "请用当前 align_profiles.py 重新生成，Host launch bridge 不能用于模型 if-else 归因"
        )
    source_index = index_source(repo_root, max_files, max_bytes)
    source_snapshot = git_metadata(repo_root, requested_commit, repository_url)
    commit = source_snapshot["resolved_commit"]
    remote = source_snapshot["remote"]
    dirty = source_snapshot["worktree_dirty"]
    runtime_values = runtime_rows(runtime_value_path)
    run_comparability = bind_run_comparability_to_indexed_source(
        load_run_comparability(run_contract_path), source_snapshot
    )
    entry_rows = collect_entrypoint_evidence(repo_root, entries, source_analysis_dir)
    canonical_by_id = {
        row.get("event_id", ""): row
        for row in read_csv(alignment_output / "canonical_events.csv")
        if row.get("event_id")
    }
    direct_links_by_host: dict[str, list[dict[str, str]]] = defaultdict(list)
    for row in read_csv(alignment_output / "host_device_links.csv"):
        direct_status = row.get("link_status") in {"direct-id", "direct-flow"}
        # Missing causal_eligible is unknown, never an implicit approval.
        causal = truthy(row.get("causal_eligible", ""))
        if direct_status and causal and row.get("host_event_id"):
            direct_links_by_host[row["host_event_id"]].append(row)
    candidate_rows: list[dict[str, Any]] = []
    evidence_rows: list[dict[str, Any]] = []
    event_map_rows: list[dict[str, Any]] = []
    tensor_rows: list[dict[str, Any]] = []
    detailed_rows: list[dict[str, Any]] = []
    device_link_rows: list[dict[str, Any]] = []
    candidate_search_total = 0
    candidate_search_emitted = 0
    candidate_search_truncated_divergences: list[str] = []

    for divergence in divergences:
        real_ops = [clean(value, 1000) for value in divergence.get("real_operators", []) if clean(value)]
        sim_ops = [clean(value, 1000) for value in divergence.get("sim_operators", []) if clean(value)]
        real_stacks = [clean(value) for value in divergence.get("real_call_stacks", []) if clean(value)]
        sim_stacks = [clean(value) for value in divergence.get("sim_call_stacks", []) if clean(value)]
        linked_devices: list[dict[str, Any]] = []
        for environment, event_ids in (
            ("real/reference/真机", divergence.get("real_event_ids", [])),
            ("sim/candidate/仿真", divergence.get("sim_event_ids", [])),
        ):
            for host_event_id in event_ids if isinstance(event_ids, list) else []:
                for link in direct_links_by_host.get(str(host_event_id), []):
                    device = canonical_by_id.get(link.get("device_event_id", ""), {})
                    evidence = {
                        "divergence_id": divergence.get("divergence_id", ""),
                        "rank_pair_id": divergence.get("rank_pair_id", ""),
                        "thread_pair_id": divergence.get("thread_pair_id", ""),
                        "environment": environment,
                        "host_event_id": host_event_id,
                        "device_event_id": link.get("device_event_id", ""),
                        "device_operator": device.get("canonical_op", ""),
                        "device_stream_id": device.get("stream_id", ""),
                        "device_task_id": device.get("task_id", ""),
                        "device_task_type": device.get("task_type", ""),
                        "device_input_shapes": device.get("input_shapes", ""),
                        "device_output_shapes": device.get("output_shapes", ""),
                        "link_status": link.get("link_status", ""),
                        "link_namespace": link.get("correlation_namespace", ""),
                        "endpoint_match": link.get("endpoint_match", ""),
                        "causal_eligible": "是",
                        "link_evidence_ids": link.get("evidence_ids", ""),
                    }
                    linked_devices.append(evidence)
                    device_link_rows.append(evidence)
        candidates = []
        for guard in source_index.guards:
            entry_score = entrypoint_binding_score(guard.path, entry_rows)
            arms = guard_branch_calls(guard, source_index)
            arm_names = sorted(arms)
            for real_arm in arm_names:
                for sim_arm in arm_names:
                    if real_arm == sim_arm:
                        continue
                    real_count, real_matches = match_ops_to_calls(real_ops, arms[real_arm])
                    sim_count, sim_matches = match_ops_to_calls(sim_ops, arms[sim_arm])
                    if not real_count or not sim_count:
                        continue
                    real_coverage = real_count / max(1, len(real_ops))
                    sim_coverage = sim_count / max(1, len(sim_ops))
                    real_wrong, _ = match_ops_to_calls(real_ops, arms[sim_arm])
                    sim_wrong, _ = match_ops_to_calls(sim_ops, arms[real_arm])
                    precision_denominator = real_count + sim_count + real_wrong + sim_wrong
                    precision = (real_count + sim_count) / max(1, precision_denominator)
                    real_stack_score = max(
                        [stack_location_score(call, real_stacks) for _, call in real_matches] + [0]
                    )
                    sim_stack_score = max(
                        [stack_location_score(call, sim_stacks) for _, call in sim_matches] + [0]
                    )
                    # Promotion needs evidence on both sides.  Taking max(real, sim) would let
                    # one reference-only stack silently stand in for an unobserved candidate arm.
                    stack_score = min(real_stack_score, sim_stack_score)
                    coverage = min(real_coverage, sim_coverage)
                    score = (
                        0.50 * coverage + 0.28 * precision
                        + 0.17 * min(1.0, stack_score / 2)
                        + 0.05 * min(1.0, entry_score / 2)
                    )
                    candidates.append(
                        (
                            score, precision, coverage, stack_score, real_stack_score,
                            sim_stack_score, entry_score, guard, real_arm, sim_arm,
                            real_matches, sim_matches,
                        )
                    )
        candidates.sort(
            key=lambda item: (-item[0], item[7].path, item[7].line_start, item[8], item[9])
        )
        candidate_search_total += len(candidates)
        candidate_search_emitted += min(20, len(candidates))
        if len(candidates) > 20:
            candidate_search_truncated_divergences.append(
                clean(divergence.get("divergence_id"), 1000)
            )
        for rank_index, item in enumerate(candidates[:20], 1):
            (
                score, precision, coverage, stack_score, real_stack_score, sim_stack_score,
                entry_score, guard, real_arm, sim_arm, real_matches, sim_matches,
            ) = item
            runtime = runtime_for_guard(
                runtime_values, guard, divergence.get("rank_pair_id", ""),
                divergence.get("thread_pair_id", ""), divergence.get("divergence_id", ""),
            )
            opposite, real_result, sim_result = opposite_runtime_results(runtime)
            has_direct_operands, real_operand_values, sim_operand_values = direct_operand_values(runtime)
            stable = divergence.get("boundary_stability") == "stable"
            alignment_gates = divergence_evidence_gates(divergence)
            no_earlier_unresolved = not unresolved(divergence.get("earlier_unresolved"))
            launch_bound = entry_score > 0 or stack_score >= 2
            analyzed_component = clean(
                run_comparability.get("fields", {})
                .get("analyzed_source", {})
                .get("real", {})
                .get("component", ""),
                200,
            ).casefold()
            dependency_gate_ok, dependency_gate_field = dependency_source_gate(
                guard.path, run_comparability, analyzed_component
            )
            source_binding_ok = (
                runtime_binding == "verified"
                and source_snapshot["binding_status"] == "verified"
                and run_comparability["analyzed_source_gate_passed"]
                and dependency_gate_ok
                and not source_index.discovery.get("truncated", True)
            )
            if (
                stable and source_binding_ok and runtime_binding == "verified" and opposite
                and has_direct_operands
                and stack_score >= 2 and coverage >= 0.80 and precision >= 0.90
                and no_earlier_unresolved and alignment_gates["lane_high_confidence"]
                and alignment_gates["anchor_gate_passed"] and launch_bound
                and not alignment_gates["repeated_anchor_ambiguous"]
                and alignment_gates["nesting_gate_passed"]
            ):
                strength = "已证实控制流分叉"
            elif (
                stable and source_binding_ok and stack_score >= 1 and launch_bound
                and coverage >= 0.60 and precision >= 0.70 and no_earlier_unresolved
                and alignment_gates["lane_high_confidence"]
                and alignment_gates["anchor_gate_passed"]
                and not alignment_gates["repeated_anchor_ambiguous"]
                and alignment_gates["nesting_gate_passed"]
            ):
                strength = "强关联控制流分叉"
            else:
                strength = "静态候选"
            evidence_id = "cf-" + stable_hash(
                divergence.get("divergence_id"), guard.guard_id, real_arm, sim_arm, length=24
            )
            branch_fingerprint = {
                "real_operators": real_ops, "sim_operators": sim_ops,
                "real_matched": [operator for operator, _ in real_matches],
                "sim_matched": [operator for operator, _ in sim_matches],
                "coverage": round(coverage, 6), "precision": round(precision, 6),
                "contradictions": real_wrong + sim_wrong,
            }
            minimal_missing = []
            if not alignment_gates["lane_high_confidence"]:
                minimal_missing.append("唯一且高置信的 framework Host lane 配对")
            if not alignment_gates["anchor_gate_passed"]:
                minimal_missing.append("首次分叉前后各至少 3 个 exact anchor，或 direct branch marker")
            if alignment_gates["repeated_anchor_ambiguous"]:
                minimal_missing.append("消除重复层/重复 token 的等价锚点歧义")
            if not alignment_gates["nesting_gate_passed"]:
                minimal_missing.append("无非嵌套重叠/multi-track 歧义的可靠算子树")
            if not stable:
                minimal_missing.append("稳定的 op-only/op+metadata/tree-aware 首次分叉边界")
            if runtime_binding != "verified":
                minimal_missing.append("Profiler/build metadata 与固定 commit 的运行版本绑定")
            if not run_comparability["analyzed_source_gate_passed"]:
                minimal_missing.append(
                    "run contract 中两侧 analyzed_source 的 verified 且相同绑定；"
                    "模型仓 commit 不能替代 TorchNPU/FSDP patch 版本"
                )
            if not dependency_gate_ok:
                minimal_missing.append(
                    f"guard 依赖组件的两侧 verified-equal 运行版本证据: {dependency_gate_field}"
                )
            if source_index.discovery.get("truncated", True):
                minimal_missing.append("提高源码扫描预算，消除 max_files/max_bytes 截断")
            if stack_score < 2:
                minimal_missing.append("包含 path:line 的 runtime call stack 或 branch marker")
            if not launch_bound:
                minimal_missing.append("从用户 .sh/launcher 到该 Python guard 的可审计入口链")
            if not opposite:
                minimal_missing.append("两侧 guard predicate_result 与直接 operand value")
            elif not has_direct_operands:
                minimal_missing.append("两侧 guard 直接 operand_name/operand_value")
            if dirty == "yes":
                minimal_missing.append("与运行一致的干净源码快照")
            if source_snapshot["binding_status"] != "verified":
                minimal_missing.append(
                    "实际索引 Git HEAD 与 --commit 一致且 worktree clean 的本地源码快照"
                )
            arm_ranges = guard.arms
            candidate_row = {
                "evidence_id": evidence_id, "candidate_rank": rank_index,
                "divergence_id": divergence.get("divergence_id", ""),
                "rank_pair_id": divergence.get("rank_pair_id", ""),
                "thread_pair_id": divergence.get("thread_pair_id", ""),
                "guard_id": guard.guard_id, "guard_path": guard.path, "guard_symbol": guard.symbol,
                "guard_lines": f"{guard.line_start}-{guard.line_end}", "guard_kind": guard.guard_kind,
                "predicate_text": guard.predicate_text, "predicate_ast_hash": guard.predicate_ast_hash,
                "real_arm": real_arm, "real_arm_lines": compact_json(arm_ranges.get(real_arm, (0, 0))),
                "sim_arm": sim_arm, "sim_arm_lines": compact_json(arm_ranges.get(sim_arm, (0, 0))),
                "real_operators": compact_json(real_ops), "sim_operators": compact_json(sim_ops),
                "branch_fingerprint": compact_json(branch_fingerprint), "mapping_score": round(score, 6),
                "stack_binding_level": stack_score, "boundary_stability": divergence.get("boundary_stability", ""),
                "real_stack_binding_level": real_stack_score,
                "sim_stack_binding_level": sim_stack_score,
                "semantic_layer": divergence.get("semantic_layer", ""),
                "lane_match_status": alignment_gates["lane_match_status"],
                "lane_match_confidence": alignment_gates["lane_match_confidence"],
                "lane_high_confidence": "是" if alignment_gates["lane_high_confidence"] else "否",
                "anchors_before": alignment_gates["anchors_before"],
                "anchors_after": alignment_gates["anchors_after"],
                "anchor_gate_passed": "是" if alignment_gates["anchor_gate_passed"] else "否",
                "repeated_anchor_ambiguous": (
                    "是" if alignment_gates["repeated_anchor_ambiguous"] else "否"
                ),
                "nesting_gate_passed": "是" if alignment_gates["nesting_gate_passed"] else "否",
                "entrypoint_binding_level": entry_score,
                "runtime_binding": runtime_binding, "predicate_real_result": real_result,
                "predicate_sim_result": sim_result, "predicate_results_opposite": "是" if opposite else "否",
                "direct_operand_values_observed": "是" if has_direct_operands else "否",
                "real_operand_values": real_operand_values,
                "sim_operand_values": sim_operand_values,
                "analyzed_source_gate_passed": (
                    "是" if run_comparability["analyzed_source_gate_passed"] else "否"
                ),
                "dependency_source_gate_passed": "是" if dependency_gate_ok else "否",
                "dependency_source_gate_field": dependency_gate_field,
                "source_component": analyzed_component,
                "run_contract_sha256": run_comparability.get("sha256", ""),
                "indexed_head_commit": source_snapshot.get("head_commit", ""),
                "indexed_tree_hash": source_snapshot.get("tree_hash", ""),
                "source_scan_complete": (
                    "否" if source_index.discovery.get("truncated", True) else "是"
                ),
                "run_comparability_status": run_comparability["status"],
                "run_confounders": compact_json(run_comparability["confounders"]),
                "strength": strength, "repository": remote or str(repo_root), "commit": commit,
                "permalink": permalink(remote, commit, guard.path, guard.line_start, guard.line_end),
                "minimal_missing_evidence": compact_json(minimal_missing),
                "claim_boundary": (
                    "只有直接 predicate operand/result 与最早 producer 差异齐全时，才可称仿真计算错误；"
                    "否则只陈述路径分叉或候选 guard"
                ),
            }
            candidate_rows.append(candidate_row)
            if rank_index == 1:
                tensor_candidates = producer_rows(guard, source_index)
                for row in tensor_candidates:
                    row.update(
                        {"evidence_id": evidence_id, "divergence_id": divergence.get("divergence_id", ""),
                         "rank_pair_id": divergence.get("rank_pair_id", ""),
                         "semantic_layer": divergence.get("semantic_layer", ""),
                         "runtime_values": compact_json(runtime),
                         "runtime_value_status": "direct" if runtime else "missing"}
                    )
                    tensor_rows.append(row)
                for environment, matches in (("real/reference/真机", real_matches), ("sim/candidate/仿真", sim_matches)):
                    for operator, call in matches:
                        event_map_rows.append(
                            {"evidence_id": evidence_id, "environment": environment,
                             "rank_pair_id": divergence.get("rank_pair_id", ""),
                             "thread_pair_id": divergence.get("thread_pair_id", ""),
                             "semantic_layer": divergence.get("semantic_layer", ""),
                             "operator": operator, "source_call": call.call_name, "path": call.path,
                             "line_start": call.line, "line_end": call.end_line, "symbol": call.symbol,
                             "mapping_method": "branch fingerprint + operator family + optional call stack",
                             "stack_binding_level": stack_location_score(
                                 call, real_stacks if environment.startswith("real") else sim_stacks
                             ),
                             "confidence": strength, "permalink": permalink(
                                 remote, commit, call.path, call.line, call.end_line
                             )}
                        )
                detailed_rows.append(
                    {"evidence_id": evidence_id, "rank_pair_id": divergence.get("rank_pair_id", ""),
                     "thread_pair_id": divergence.get("thread_pair_id", ""),
                     "semantic_layer": divergence.get("semantic_layer", ""),
                     "host_divergence_id": divergence.get("divergence_id", ""),
                     "repository": remote or str(repo_root), "commit": commit,
                     "runtime_binding": runtime_binding, "guard_path": guard.path,
                     "guard_symbol": guard.symbol, "guard_lines": [guard.line_start, guard.line_end],
                     "guard_kind": guard.guard_kind, "predicate_text": guard.predicate_text,
                     "predicate_ast_hash": guard.predicate_ast_hash, "real_arm": real_arm,
                     "sim_arm": sim_arm, "operands": tensor_candidates,
                     "predicate_eval": {"method": "runtime-values-csv" if runtime else "not-observed",
                                        "real_result": json.loads(real_result) if real_result else [],
                                        "sim_result": json.loads(sim_result) if sim_result else []},
                     "branch_fingerprint": branch_fingerprint,
                     "direct_linked_device_evidence": linked_devices,
                     "causal_chain": ["first Host operator divergence", f"{guard.path}:{guard.line_start}",
                                      f"{real_arm} vs {sim_arm}", "predicate operand producer candidate",
                                      (
                                          "direct-linked Device tasks available"
                                          if linked_devices else "no direct-linked Device task"
                                      )],
                     "gates": {"stable_boundary": stable, "runtime_source_binding": source_binding_ok,
                               "indexed_source_snapshot": source_snapshot,
                               "analyzed_source_gate_passed": run_comparability[
                                   "analyzed_source_gate_passed"
                               ],
                               "dependency_source_gate_passed": dependency_gate_ok,
                               "dependency_source_gate_field": dependency_gate_field,
                               "run_confounders": run_comparability["confounders"],
                               "direct_opposite_predicate_results": opposite, "stack_binding_level": stack_score,
                               "direct_operand_values_observed": has_direct_operands,
                               "entrypoint_binding_level": entry_score,
                               "lane_high_confidence": alignment_gates["lane_high_confidence"],
                               "anchor_gate_passed": alignment_gates["anchor_gate_passed"],
                               "anchors_before": alignment_gates["anchors_before"],
                               "anchors_after": alignment_gates["anchors_after"],
                               "repeated_anchor_ambiguous": alignment_gates["repeated_anchor_ambiguous"],
                               "nesting_gate_passed": alignment_gates["nesting_gate_passed"],
                               "no_earlier_unresolved": no_earlier_unresolved,
                               "semantic_layer": divergence.get("semantic_layer", ""),
                               "dirty_worktree": dirty},
                     "strength": strength,
                     "claim_text": candidate_row["claim_boundary"],
                     "alternative_explanations": divergence.get("alternative_explanations", []),
                     "minimal_missing_evidence": minimal_missing}
                )

    for row in source_index.evidence:
        row.update(
            {"environment": "source", "repository": remote or str(repo_root), "commit": commit,
             "permalink": permalink(remote, commit, row["path"], row["line_start"], row["line_end"])}
        )
        evidence_rows.append(row)
    output.mkdir(parents=True, exist_ok=True)
    write_csv(
        output / "control_flow_guard_candidates.csv", candidate_rows,
        fields=CANDIDATE_CSV_FIELDS,
    )
    write_jsonl(output / "control_flow_evidence.jsonl", detailed_rows)
    write_csv(output / "predicate_tensor_evidence.csv", tensor_rows)
    write_csv(output / "event_source_map.csv", event_map_rows)
    write_csv(output / "branch_device_evidence.csv", device_link_rows)
    write_csv(output / "source_evidence.csv", evidence_rows)
    write_csv(output / "source_entrypoint_chain.csv", entry_rows)
    write_csv(output / "source_analysis_issues.csv", source_index.issues)
    strength_counts = dict(Counter(row.get("strength", "") for row in candidate_rows))
    promoted_candidates = [
        row for row in candidate_rows
        if row.get("strength") in {"强关联控制流分叉", "已证实控制流分叉"}
    ]
    execution_status = "complete" if candidate_rows else "partial"
    promotion_status = "eligible" if promoted_candidates else "not-eligible"
    causal_gate_complete = bool(
        promoted_candidates
        and source_snapshot["binding_status"] == "verified"
        and run_comparability["analyzed_source_gate_passed"]
        and not source_index.discovery.get("truncated", True)
    )
    limitations: list[str] = []
    if not candidate_rows:
        limitations.append(
            "没有同时解释真机/仿真 branch-exclusive framework operators 的 guard；代码级原因未知"
        )
    if not run_comparability["analyzed_source_gate_passed"]:
        limitations.append(
            "两侧 analyzed_source 未 verified-equal；所有候选最多为静态候选"
        )
    if source_snapshot["binding_status"] != "verified":
        limitations.append("实际索引 Git snapshot 未通过 HEAD/commit/clean tree 门禁")
    if candidate_rows and not promoted_candidates:
        limitations.append("候选均未通过运行因果升级门禁")
    integrity = artifact_integrity(output, SOURCE_ARTIFACT_NAMES)
    manifest = {
        "schema_version": SCHEMA_VERSION, "algorithm_version": ALGORITHM_VERSION,
        "status": "complete" if causal_gate_complete else "partial",
        "execution_status": execution_status,
        "promotion_status": promotion_status,
        "repo_root": str(repo_root), "repository": remote,
        "requested_commit": requested_commit, "resolved_commit": commit,
        "runtime_binding": runtime_binding, "worktree_dirty": dirty,
        "indexed_source_snapshot": source_snapshot,
        "source_scan": source_index.discovery,
        "candidate_search": {
            "per_divergence_limit": 20,
            "total_ranked": candidate_search_total,
            "total_emitted": candidate_search_emitted,
            "truncated": bool(candidate_search_truncated_divergences),
            "truncated_divergence_ids": candidate_search_truncated_divergences,
            "promotion_semantics": "top candidates are sorted before truncation; omitted rows are lower-ranked",
        },
        "run_comparability": run_comparability,
        "safety": "AST/static text only; repository code was not imported, executed, compiled, or evaluated",
        "counts": {"framework_host_divergences": len(divergences),
                   "non_framework_divergences_excluded": len(all_divergences) - len(divergences),
                   "python_files_parsed": len(source_index.evidence),
                   "guards": len(source_index.guards), "calls": len(source_index.calls),
                   "guard_candidates": len(candidate_rows), "top_control_flow_evidence": len(detailed_rows),
                   "predicate_operands": len(tensor_rows),
                   "direct_linked_device_rows": len(device_link_rows),
                   "issues": len(source_index.issues),
                   "strengths": strength_counts},
        "claim_gate": (
            "仿真计算错误 requires verified same inputs/weights/seed/config/code/rank state, direct opposite "
            "predicate operand values, earliest producer mapping, semantic oracle, and reproducibility"
        ),
        "limitations": limitations,
        "artifacts": SOURCE_ARTIFACT_NAMES,
        "artifact_integrity": integrity,
    }
    write_json(output / "source_analysis_manifest.json", manifest)
    return manifest


def run_self_test() -> int:
    composable_fsdp = "torch/distributed/_composable/fsdp/fully_shard.py"
    assert guard_owner_component(composable_fsdp) == "pytorch"
    assert effective_owner_component(composable_fsdp, "model") == "pytorch"
    with tempfile.TemporaryDirectory(prefix="control-flow-selftest-") as directory:
        root = Path(directory)
        repo, alignment, output = root / "repo", root / "alignment", root / "output"
        repo.mkdir()
        alignment.mkdir()
        (repo / "model.py").write_text(
            """import torch
def forward(x):
    predicate = x.sum().item()
    if predicate > 0:
        y = torch.matmul(x, x)
        return torch.relu(y)
    else:
        y = torch.where(x > 0, x, -x)
        return torch.sigmoid(y)
""",
            encoding="utf-8",
        )
        (repo / "_add_fsdp_patch.py").write_text(
            (repo / "model.py").read_text(encoding="utf-8"), encoding="utf-8"
        )
        subprocess.run(["git", "-C", str(repo), "init", "--quiet"], check=True)
        subprocess.run(
            ["git", "-C", str(repo), "config", "user.email", "self-test@example.invalid"],
            check=True,
        )
        subprocess.run(
            ["git", "-C", str(repo), "config", "user.name", "profiling-skill-self-test"],
            check=True,
        )
        subprocess.run(
            ["git", "-C", str(repo), "config", "core.autocrlf", "false"], check=True,
        )
        subprocess.run(
            [
                "git", "-C", str(repo), "config", "core.excludesFile",
                str(repo / ".git" / "info" / "exclude"),
            ],
            check=True,
        )
        subprocess.run(
            ["git", "-C", str(repo), "add", "model.py", "_add_fsdp_patch.py"], check=True
        )
        subprocess.run(
            ["git", "-C", str(repo), "commit", "--quiet", "-m", "self-test fixture"],
            check=True,
        )
        fixture_commit = subprocess.run(
            ["git", "-C", str(repo), "rev-parse", "HEAD"], capture_output=True,
            text=True, check=True,
        ).stdout.strip()
        fixture_tree = subprocess.run(
            ["git", "-C", str(repo), "rev-parse", "HEAD^{tree}"], capture_output=True,
            text=True, check=True,
        ).stdout.strip()

        def source_contract(
            component: str, evidence: str, commit: str = fixture_commit,
            tree_hash: str = fixture_tree,
        ) -> dict[str, str]:
            return {
                "component": component,
                "repository": "self-test/example-source",
                "commit": commit,
                "tree_hash": tree_hash,
                "status": "verified",
                "evidence": evidence,
            }
        divergence = {
            "divergence_id": "rank-0000:host:lane-0000:first", "rank_pair_id": "rank-0000",
            "thread_pair_id": "rank-0000:host:lane-0000", "domain": "host",
            "semantic_layer": "framework_op", "lane_match_status": "matched",
            "lane_match_confidence": "high", "anchors_before": 3, "anchors_after": 3,
            "nesting_gate_passed": True,
            "real_event_ids": ["real-host"], "sim_event_ids": ["sim-host"],
            "real_operators": ["aten::matmul", "aten::relu"],
            "sim_operators": ["aten::where", "aten::sigmoid"],
            "real_call_stacks": ["model.py:5"], "sim_call_stacks": ["model.py:8"],
            "boundary_stability": "stable", "earlier_unresolved": "否",
            "alternative_explanations": ["input mismatch"],
        }
        launch_divergence = dict(divergence)
        launch_divergence.update(
            {"divergence_id": "rank-0000:host-launch:lane-0001:first",
             "thread_pair_id": "rank-0000:host-launch:lane-0001",
             "semantic_layer": "host_launch"}
        )
        (alignment / "divergence_windows.jsonl").write_text(
            "\n".join(json.dumps(row, ensure_ascii=False) for row in (divergence, launch_divergence)) + "\n",
            encoding="utf-8",
        )
        write_csv(
            alignment / "canonical_events.csv",
            [
                {"event_id": "real-device", "canonical_op": "kernel_real", "stream_id": "1",
                 "task_id": "7", "task_type": "AI_CORE"},
                {"event_id": "sim-device", "canonical_op": "kernel_sim", "stream_id": "1",
                 "task_id": "8", "task_type": "AI_CORE"},
            ],
        )
        write_csv(
            alignment / "host_device_links.csv",
            [
                {"host_event_id": "real-host", "device_event_id": "real-device",
                 "link_status": "direct-flow", "causal_eligible": "是",
                 "correlation_namespace": "async_npu", "endpoint_match": "exact", "evidence_ids": "r"},
                {"host_event_id": "sim-host", "device_event_id": "sim-device",
                 "link_status": "direct-flow", "causal_eligible": "是",
                 "correlation_namespace": "async_npu", "endpoint_match": "exact", "evidence_ids": "s"},
            ],
        )
        missing_contract_output = root / "missing-contract-output"
        missing_contract_manifest = analyze(
            repo, alignment, missing_contract_output, None, ["model.py"], "", fixture_commit,
            "verified", None, None, 100, 1024 * 1024,
        )
        missing_contract_candidates = read_csv(
            missing_contract_output / "control_flow_guard_candidates.csv"
        )
        assert missing_contract_manifest["run_comparability"]["status"] == "missing"
        assert missing_contract_candidates[0]["strength"] == "静态候选"
        different_contract = root / "different_run_contract.json"
        write_json(
            different_contract,
            {
                "schema_version": 1,
                "real": {
                    "analyzed_source": source_contract("torch_npu", "real")
                },
                "sim": {
                    "analyzed_source": source_contract(
                        "torch_npu", "sim", commit="cafebabe", tree_hash="0" * 40
                    )
                },
            },
        )
        different_output = root / "different-source-output"
        different_manifest = analyze(
            repo, alignment, different_output, None, ["model.py"], "", fixture_commit,
            "verified", None, different_contract, 100, 1024 * 1024,
        )
        different_candidates = read_csv(
            different_output / "control_flow_guard_candidates.csv"
        )
        assert different_manifest["run_comparability"]["status"] == "partial"
        assert different_candidates[0]["strength"] == "静态候选"
        run_contract = root / "run_comparability_contract.json"
        write_json(
            run_contract,
            {
                "schema_version": 1,
                "real": {
                    "analyzed_source": source_contract("model", "real build manifest")
                },
                "sim": {
                    "analyzed_source": source_contract("model", "sim build manifest")
                },
            },
        )
        wrong_commit_output = root / "wrong-commit-output"
        wrong_commit_manifest = analyze(
            repo, alignment, wrong_commit_output, None, ["model.py"], "", "cafebabe",
            "verified", None, run_contract, 100, 1024 * 1024,
        )
        wrong_commit_candidates = read_csv(
            wrong_commit_output / "control_flow_guard_candidates.csv"
        )
        assert wrong_commit_manifest["indexed_source_snapshot"]["binding_status"] == "conflict"
        assert wrong_commit_candidates[0]["strength"] == "静态候选"

        dirty_marker = repo / "uncommitted-self-test.txt"
        dirty_marker.write_text("dirty", encoding="utf-8")
        dirty_output = root / "dirty-source-output"
        dirty_manifest = analyze(
            repo, alignment, dirty_output, None, ["model.py"], "", fixture_commit,
            "verified", None, run_contract, 100, 1024 * 1024,
        )
        dirty_candidates = read_csv(dirty_output / "control_flow_guard_candidates.csv")
        assert dirty_manifest["indexed_source_snapshot"]["worktree_dirty"] == "yes", dirty_manifest[
            "indexed_source_snapshot"
        ]
        assert dirty_candidates[0]["strength"] == "静态候选"
        dirty_marker.unlink()

        non_git_repo = root / "non-git-repo"
        non_git_repo.mkdir()
        (non_git_repo / "model.py").write_text(
            (repo / "model.py").read_text(encoding="utf-8"), encoding="utf-8"
        )
        non_git_output = root / "non-git-output"
        non_git_manifest = analyze(
            non_git_repo, alignment, non_git_output, None, ["model.py"], "", fixture_commit,
            "verified", None, run_contract, 100, 1024 * 1024,
        )
        non_git_candidates = read_csv(non_git_output / "control_flow_guard_candidates.csv")
        assert non_git_manifest["indexed_source_snapshot"]["binding_status"] == "unverified"
        assert non_git_candidates[0]["strength"] == "静态候选"

        manifest = analyze(
            repo, alignment, output, None, ["model.py"], "", fixture_commit, "verified",
            None, run_contract, 100, 1024 * 1024,
        )
        assert manifest["counts"]["guard_candidates"] >= 1
        assert manifest["counts"]["non_framework_divergences_excluded"] == 1
        assert manifest["counts"]["direct_linked_device_rows"] == 2
        assert manifest["schema_version"] == 4
        assert manifest["source_scan"]["truncated"] is False
        assert set(manifest["artifacts"]) == set(manifest["artifact_integrity"])
        for artifact_name, expected in manifest["artifact_integrity"].items():
            artifact_raw = (output / artifact_name).read_bytes()
            assert hashlib.sha256(artifact_raw).hexdigest() == expected["sha256"]
            assert len(artifact_raw) == expected["bytes"]
        candidates = read_csv(output / "control_flow_guard_candidates.csv")
        assert candidates[0]["real_arm"] == "if" and candidates[0]["sim_arm"] == "else"
        tensors = read_csv(output / "predicate_tensor_evidence.csv")
        assert any(row["operand_expr"] == "predicate" and "x.sum().item()" in row["producer_expression"] for row in tensors)
        assert candidates[0]["strength"] == "强关联控制流分叉", (
            candidates[0], manifest["indexed_source_snapshot"]
        )
        device_evidence = read_csv(output / "branch_device_evidence.csv")
        assert {row["device_operator"] for row in device_evidence} == {"kernel_real", "kernel_sim"}

        truncated_output = root / "truncated-output"
        truncated_manifest = analyze(
            repo, alignment, truncated_output, None, ["model.py"], "", fixture_commit,
            "verified", None, run_contract, 1, 1024 * 1024,
        )
        assert truncated_manifest["source_scan"]["truncated"] is True
        assert truncated_manifest["promotion_status"] == "not-eligible"
        assert all(
            row["strength"] == "静态候选"
            for row in read_csv(truncated_output / "control_flow_guard_candidates.csv")
        )

        dependency_alignment = root / "dependency-alignment"
        dependency_alignment.mkdir()
        dependency_divergence = dict(divergence)
        dependency_divergence.update(
            {
                "divergence_id": "rank-0000:host:dependency:first",
                "thread_pair_id": "rank-0000:host:dependency",
                "real_call_stacks": ["_add_fsdp_patch.py:5"],
                "sim_call_stacks": ["_add_fsdp_patch.py:8"],
            }
        )
        (dependency_alignment / "divergence_windows.jsonl").write_text(
            json.dumps(dependency_divergence, ensure_ascii=False) + "\n", encoding="utf-8"
        )
        write_csv(dependency_alignment / "canonical_events.csv", [])
        write_csv(dependency_alignment / "host_device_links.csv", [])
        dependency_contract = root / "dependency_run_contract.json"
        write_json(
            dependency_contract,
            {
                "schema_version": 1,
                "real": {
                    "analyzed_source": source_contract("torch_npu", "real source build"),
                    "torch_npu_version": {
                        "value": "2.7.1.post7", "status": "verified", "evidence": "real metadata"
                    },
                },
                "sim": {
                    "analyzed_source": source_contract("torch_npu", "sim source build"),
                    "torch_npu_version": {
                        "value": "2.7.1.post4.dev", "status": "verified", "evidence": "sim metadata"
                    },
                },
            },
        )
        dependency_output = root / "dependency-output"
        analyze(
            repo, dependency_alignment, dependency_output, None, ["_add_fsdp_patch.py"],
            "", fixture_commit, "verified", None, dependency_contract, 100, 1024 * 1024,
        )
        dependency_candidates = read_csv(
            dependency_output / "control_flow_guard_candidates.csv"
        )
        assert dependency_candidates[0]["guard_path"] == "_add_fsdp_patch.py"
        assert dependency_candidates[0]["dependency_source_gate_passed"] == "否"
        assert dependency_candidates[0]["strength"] == "静态候选"

        runtime_path = root / "runtime.csv"
        write_csv(
            runtime_path,
            [
                {"environment": "real", "rank_pair_id": "rank-0000",
                 "thread_pair_id": divergence["thread_pair_id"],
                 "divergence_id": divergence["divergence_id"],
                 "guard_id": candidates[0]["guard_id"], "path": "model.py",
                 "line": 4, "predicate_result": "true", "operand": "predicate",
                 "operand_value": "1.0", "producer_event_id": "real-event"},
                {"environment": "sim", "rank_pair_id": "rank-0000",
                 "thread_pair_id": divergence["thread_pair_id"],
                 "divergence_id": divergence["divergence_id"],
                 "guard_id": candidates[0]["guard_id"], "path": "model.py",
                 "line": 4, "predicate_result": "false", "operand": "predicate",
                 "operand_value": "-1.0", "producer_event_id": "sim-event"},
            ],
        )
        confirmed_output = root / "confirmed-output"
        analyze(
            repo, alignment, confirmed_output, None, ["model.py"], "", fixture_commit, "verified",
            runtime_path, run_contract, 100, 1024 * 1024,
        )
        confirmed = read_csv(confirmed_output / "control_flow_guard_candidates.csv")
        assert confirmed[0]["strength"] == "已证实控制流分叉"
        assert confirmed[0]["direct_operand_values_observed"] == "是"
        one_side_alignment = root / "one-side-stack-alignment"
        one_side_alignment.mkdir()
        one_side_divergence = dict(divergence)
        one_side_divergence["sim_call_stacks"] = []
        (one_side_alignment / "divergence_windows.jsonl").write_text(
            json.dumps(one_side_divergence, ensure_ascii=False) + "\n", encoding="utf-8"
        )
        write_csv(one_side_alignment / "canonical_events.csv", [])
        write_csv(one_side_alignment / "host_device_links.csv", [])
        one_side_output = root / "one-side-stack-output"
        analyze(
            repo, one_side_alignment, one_side_output, None, ["model.py"], "", fixture_commit,
            "verified", None, run_contract, 100, 1024 * 1024,
        )
        one_side_candidates = read_csv(
            one_side_output / "control_flow_guard_candidates.csv"
        )
        assert one_side_candidates[0]["sim_stack_binding_level"] == "0"
        assert one_side_candidates[0]["strength"] == "静态候选"
        same_boolean, _, _ = opposite_runtime_results(
            [
                {"environment": "real", "predicate_result": "true"},
                {"environment": "sim", "predicate_result": "1"},
            ]
        )
        assert not same_boolean
        mismatched_operand, _, _ = direct_operand_values(
            [
                {"environment": "real", "operand": "x", "operand_value": "1",
                 "producer_event_id": "real-producer"},
                {"environment": "sim", "operand": "y", "operand_value": "-1",
                 "producer_event_id": "sim-producer"},
            ]
        )
        assert not mismatched_operand
    print("self-test: ok")
    return 0


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--repo-root", type=Path, help="只读本地源码仓根目录")
    parser.add_argument("--alignment-output", type=Path, help="align_profiles.py 输出目录")
    parser.add_argument("--output", type=Path, help="源码仓之外的输出目录")
    parser.add_argument("--source-analysis-dir", type=Path, help="resolve_source_entrypoints.py 输出目录")
    parser.add_argument("--entry", action="append", default=[], help="用户入口 .sh/.py/目录，可重复")
    parser.add_argument("--repository-url", default="", help="公开仓 URL，用于证据与永久链接")
    parser.add_argument("--commit", default="", help="固定 commit；省略时只读 git rev-parse HEAD")
    parser.add_argument(
        "--runtime-binding", choices=["verified", "user-declared", "unverified", "conflict"],
        default="unverified", help="被读源码与本次 Profiling 运行版本的绑定状态",
    )
    parser.add_argument(
        "--runtime-values", type=Path,
        help=(
            "可选 CSV：environment,rank_pair_id,thread_pair_id,divergence_id,guard_id,"
            "path,line,predicate_result,operand,operand_value,producer_event_id"
        ),
    )
    parser.add_argument(
        "--run-contract", type=Path,
        help=(
            "两侧运行可比性 JSON；强关联/已证实至少要求 real/sim.analyzed_source "
            "的 component/repository/commit/tree_hash 精确一致、均 verified 且有 evidence，"
            "并绑定本次实际索引 Git HEAD/tree"
        ),
    )
    parser.add_argument("--max-python-files", type=int, default=500)
    parser.add_argument("--max-python-bytes", type=int, default=8 * 1024 * 1024)
    parser.add_argument("--self-test", action="store_true")
    return parser


def main(argv: list[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    if args.self_test:
        return run_self_test()
    if not args.repo_root or not args.alignment_output or not args.output:
        raise SystemExit("--repo-root、--alignment-output、--output 均为必需参数")
    manifest = analyze(
        args.repo_root, args.alignment_output, args.output, args.source_analysis_dir,
        args.entry, args.repository_url, args.commit, args.runtime_binding, args.runtime_values,
        args.run_contract, args.max_python_files, args.max_python_bytes,
    )
    print(json.dumps(manifest, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

#!/usr/bin/env bash
# 昇腾算子性能可学习性诊断 —— 一键流程
#
# 用法:  bash run_all.sh [DEVICE] [MODEL]
# 例如:  bash run_all.sh 0 llama2-7b
#
# 注意: 全程只用一张卡、不修改任何全局配置、不 kill 任何进程。
#       02 会在剩余显存不足时主动退出。

set -euo pipefail

DEV="${1:-0}"
MODEL="${2:-llama2-7b}"
TP="${TP:-1}"
DENSE="${DENSE:-dense:960:1088}"     # 步长 1 的稠密窗口，可按需改

mkdir -p data logs

echo "############ 0. 环境自检 + 噪声底标定 ############"
python 01_probe_env.py --device "$DEV" --model "$MODEL" --tp "$TP" \
  2>&1 | tee logs/01_probe.log

echo
echo "############ 1. 稠密扫描 (步长1) —— 看抖动 ############"
echo "    这是最关键的一步：Vidur 的 32 步网格根本看不到 shape ±1 的跳变"

python 02_sweep_ops.py --device "$DEV" --model "$MODEL" --tp "$TP" \
  --grid "$DENSE" --tag dense_jitOFF --jit-compile 0 \
  2>&1 | tee logs/02_dense_jitOFF.log

python 02_sweep_ops.py --device "$DEV" --model "$MODEL" --tp "$TP" \
  --grid "$DENSE" --tag dense_jitON --jit-compile 1 \
  2>&1 | tee logs/02_dense_jitON.log

echo
echo "############ 2. Vidur 网格 —— 给建模用 ############"
python 02_sweep_ops.py --device "$DEV" --model "$MODEL" --tp "$TP" \
  --grid vidur --tag vidur_jitOFF --jit-compile 0 \
  2>&1 | tee logs/02_vidur.log

echo
echo "############ 3. 抓 block_dim (best effort, 失败不影响主结论) ############"
python 03_profile_tiling.py --device "$DEV" --model "$MODEL" --tp "$TP" \
  --grid "$DENSE" --jit-compile 0 \
  2>&1 | tee logs/03_tiling.log || echo "[warn] 03 失败，跳过（把 logs/03_tiling.log 贴出来即可）"

echo
echo "############ 4. 分析 ############"
D_OFF="data/sweep_${MODEL}_tp${TP}_dense_jitOFF.csv"
D_ON="data/sweep_${MODEL}_tp${TP}_dense_jitON.csv"
V_OFF="data/sweep_${MODEL}_tp${TP}_vidur_jitOFF.csv"

echo "--- 稠密数据 (抖动 / 台阶 / 尾块 / Vidur网格漏采) ---"
ARGS=(--csv "$D_OFF" --csv2 "$D_ON")
[ -f data/tiling_blockdim.csv ] && ARGS+=(--tiling data/tiling_blockdim.csv)
python 04_analyze.py "${ARGS[@]}" 2>&1 | tee logs/04_dense.log

echo
echo "--- Vidur 网格数据 (模型对比: 内插 vs 外推) ---"
python 04_analyze.py --csv "$V_OFF" --skip B,E 2>&1 | tee logs/04_vidur.log

echo
echo "########################################################"
echo "全部完成。需要回传给我的文件："
echo "   logs/*.log"
echo "   data/sweep_*.csv"
echo "   data/tiling_blockdim.csv (若 03 成功)"
echo "   out_env_probe.json"
echo "########################################################"

#!/usr/bin/env bash
# 昇腾算子性能可学习性诊断 —— 一键流程（v2）
#
# 用法:  bash run_all.sh [DEVICE] [MODEL]
# 例如:  bash run_all.sh 0 llama2-7b
#
# v2 相对 v1 的关键改动（首轮实测踩坑后修正）：
#   * 扫描顺序默认随机 —— v1 按 M 顺序扫，热漂移被直接混叠到 M 轴上，
#     实测 attn_qkv_proj 的 CV 随扫描进度从 1.86% 一路涨到 5.61%
#   * 每份数据交错重复 2 趟（pass_id），04 用它做可复现性闸门
#   * 先跑闸门，不合格就不用看后面的结论
#
# 注意: 全程只用一张卡、不修改任何全局配置、不 kill 任何进程。

set -euo pipefail

DEV="${1:-0}"
MODEL="${2:-llama2-7b}"
TP="${TP:-1}"
DENSE="${DENSE:-dense:896:1152}"   # 257 点, 跨 896/1024/1152 三个 mod-128 边界。
                                   # 上一轮 960:1088 只含 1024 一个边界, B 段只检出 2 个
                                   # 跳变点, 样本太少做不了模数检验。
REPEATS="${REPEATS:-4}"
COOLDOWN="${COOLDOWN:-200}"        # ms，每个 shape 之后的冷却
TIMING="${TIMING:-auto}"           # auto: 单次 <0.15ms 的算子改用打包计时，绕开 Event 开销
ANCHOR="${ANCHOR:-1024}"           # 锚点 shape，用来扣掉共模漂移；0=关闭
GATE_ONLY="${GATE_ONLY:-0}"        # 1=只跑 01 + 稠密扫描 + 闸门（约 5 分钟）

# 环境变量名打错不会报错，只会静默用默认值（上一轮 COOLDOWWN=300 就是这么丢掉的）。
for v in $(env | sed -n 's/^\(REPEAT[A-Z]*\|COOLD[A-Z]*\|DENS[A-Z]*\|TIMIN[A-Z]*\|ANCHO[A-Z]*\)=.*/\1/p'); do
  case "$v" in
    REPEATS|COOLDOWN|DENSE|TIMING|ANCHOR) ;;
    *) echo "  [warn] 环境变量 '$v' 本脚本不认识，多半是笔误（正确名: REPEATS COOLDOWN DENSE TIMING ANCHOR）" ;;
  esac
done
echo "  生效配置: DEV=$DEV MODEL=$MODEL TP=$TP DENSE=$DENSE REPEATS=$REPEATS COOLDOWN=${COOLDOWN}ms TIMING=$TIMING ANCHOR=$ANCHOR"

mkdir -p data logs

echo "############ -1. 确认这张卡上没有别人的进程 ############"
if command -v npu-smi >/dev/null 2>&1; then
  npu-smi info 2>&1 | tee logs/00_npusmi.log | tail -30
  echo
  echo "  ^ 若 Process 一栏有别的 PID 在用卡 $DEV，请换一张空闲卡（bash run_all.sh <其他卡号>）。"
  echo "    共享卡会把噪声底抬高一个数量级，所有台阶判据都会失效。"
else
  echo "  [warn] 找不到 npu-smi，无法确认卡占用情况。"
fi

echo
echo "############ 0. 环境自检 + 噪声底标定 ############"
python 01_probe_env.py --device "$DEV" --model "$MODEL" --tp "$TP" \
  2>&1 | tee logs/01_probe.log

echo
echo "############ 0.5 profiler 列名自检（几秒钟）############"
echo "  上一轮 tiling_blockdim.csv 里 1028 行 block_dim 全是 -1 —— 不是不变，是没解析到。"
echo "  先用 --dump-only 确认能拿到 Block Dim 列，再决定要不要跑完整的 03。"
python 03_profile_tiling.py --device "$DEV" --model "$MODEL" --tp "$TP" \
  --grid "$DENSE" --jit-compile 0 --dump-only \
  2>&1 | tee logs/03a_profcols.log || true
if grep -q "FAIL" logs/03a_profcols.log; then
  echo
  echo "  [!] block_dim 列没拿到。把 logs/03a_profcols.log 和 data/prof_columns.txt 发我。"
  echo "      不影响 02/04 的主结论，继续往下跑。"
  SKIP03=1
else
  SKIP03=0
fi

echo
echo "############ 1. 稠密扫描 (步长1, 随机顺序, ${REPEATS} 趟) ############"
python 02_sweep_ops.py --device "$DEV" --model "$MODEL" --tp "$TP" \
  --grid "$DENSE" --tag dense_jitOFF --jit-compile 0 \
  --order random --repeats "$REPEATS" --cooldown-ms "$COOLDOWN" \
  --timing "$TIMING" --anchor "$ANCHOR" \
  2>&1 | tee logs/02_dense_jitOFF.log

echo
echo "############ 2. 先过可复现性闸门 —— 不合格就别往下看 ############"
D_OFF="data/sweep_${MODEL}_tp${TP}_dense_jitOFF.csv"
python 04_analyze.py --csv "$D_OFF" --skip A,B,C,D,E 2>&1 | tee logs/04_gate.log

if grep -q "测量不合格" logs/04_gate.log; then
  echo
  echo "########################################################"
  echo "闸门未通过：半数以上算子的不可复现噪声 > 3%。"
  echo "继续采数没有意义，先按 logs/04_gate.log 里的排查顺序处理："
  echo "  1) 强制打包计时：TIMING=batched bash run_all.sh $DEV $MODEL"
  echo "  2) 提高趟数：    REPEATS=6 COOLDOWN=300 bash run_all.sh $DEV $MODEL"
  echo "  3) 换一张 npu-smi 里没有其他进程的卡"
  echo "把 logs/04_gate.log 和 logs/01_probe.log 发我，我看下一步怎么调。"
  echo "########################################################"
  exit 1
fi

if [ "$GATE_ONLY" = "1" ]; then
  echo
  echo "闸门通过（GATE_ONLY=1，到此为止）。去掉 GATE_ONLY 即可跑完整流程。"
  exit 0
fi

echo
echo "############ 3. jit_compile 对照 + Vidur 网格 ############"
python 02_sweep_ops.py --device "$DEV" --model "$MODEL" --tp "$TP" \
  --grid "$DENSE" --tag dense_jitON --jit-compile 1 \
  --order random --repeats "$REPEATS" --cooldown-ms "$COOLDOWN" \
  --timing "$TIMING" --anchor "$ANCHOR" \
  2>&1 | tee logs/02_dense_jitON.log

python 02_sweep_ops.py --device "$DEV" --model "$MODEL" --tp "$TP" \
  --grid vidur --tag vidur_jitOFF --jit-compile 0 \
  --order random --repeats "$REPEATS" --cooldown-ms "$COOLDOWN" \
  --timing "$TIMING" --anchor "$ANCHOR" \
  2>&1 | tee logs/02_vidur.log

echo
echo "############ 4. 抓 block_dim ############"
if [ "$SKIP03" = "1" ]; then
  echo "  [skip] 0.5 段已经确认拿不到 block_dim 列，跳过（省 10 分钟）。"
else
  python 03_profile_tiling.py --device "$DEV" --model "$MODEL" --tp "$TP" \
    --grid "$DENSE" --jit-compile 0 --repeats 3 \
    2>&1 | tee logs/03_tiling.log || echo "[warn] 03 失败，把 logs/03_tiling.log 贴出来"
fi

echo
echo "############ 5. 完整分析 ############"
D_ON="data/sweep_${MODEL}_tp${TP}_dense_jitON.csv"
V_OFF="data/sweep_${MODEL}_tp${TP}_vidur_jitOFF.csv"

ARGS=(--csv "$D_OFF" --csv2 "$D_ON")
[ -f data/tiling_blockdim.csv ] && ARGS+=(--tiling data/tiling_blockdim.csv)
python 04_analyze.py "${ARGS[@]}" 2>&1 | tee logs/04_dense.log

python 04_analyze.py --csv "$V_OFF" --skip B,E 2>&1 | tee logs/04_vidur.log

echo
echo "############ 6. 边界对齐补采（04 检出的跳变点两侧各 ±2）############"
BND=$(python - <<'PY'
import re, sys
try:
    txt = open("logs/04_dense.log", encoding="utf-8", errors="ignore").read()
except OSError:
    sys.exit()
s = set()
for m in re.finditer(r"跳变点样例: \[([0-9,\s]+)\]", txt):
    s |= {int(x) for x in m.group(1).split(",") if x.strip()}
print(",".join(str(x) for x in sorted(s)[:40]))
PY
)
if [ -n "$BND" ]; then
  echo "  边界: $BND"
  python 02_sweep_ops.py --device "$DEV" --model "$MODEL" --tp "$TP" \
    --grid "win:${BND}:2" --tag boundary --jit-compile 0 \
    --order random --repeats 6 --cooldown-ms "$COOLDOWN" \
    --timing "$TIMING" --anchor "$ANCHOR" \
    2>&1 | tee logs/05_boundary.log
  echo "  这份数据 repeats=6，用来确认台阶幅度（而不是找台阶位置）。"
else
  echo "  [skip] 04 没报出跳变点。"
fi

echo
echo "############ 7. 打包成一个可回传的小文件 ############"
python 05_digest.py 2>&1 | tee logs/06_digest.log

echo
echo "########################################################"
echo "完成。回传方式（三选一，从省事到最全）："
echo
echo "  A) 只贴文本：把 logs/06_digest.log 里 '### ASCEND-DIGEST' 到 '### END'"
echo "     之间那 ~90 行贴过来。主结论都在里面。"
echo
echo "  B) 传一个文件：data/digest.json.gz（约 70 KB，是原始 CSV 的 1/46）。"
echo "     我用 04_analyze.py --digest 全量复算，除 R 段的趟数外与原始 CSV 逐点一致。"
echo
echo "  C) 要原始数据："
echo "     tar czf result.tgz logs data/sweep_*.csv data/tiling_blockdim.csv \\"
echo "             data/prof_columns.txt out_env_probe.json"
echo "     （别用 cp 挑文件 —— 有一轮 3 个 sweep CSV 都只拷到了 499 行）"
echo "########################################################"
wc -l data/sweep_*.csv data/tiling_blockdim.csv 2>/dev/null
ls -la data/digest.json.gz 2>/dev/null

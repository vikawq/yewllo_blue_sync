#!/usr/bin/env bash
# 昇腾算子性能可学习性诊断 —— 一键流程（v2）
#
# 用法:  bash run_all.sh [DEVICE] [MODEL]
# 例如:  bash run_all.sh 0 llama2-7b
#
# v2 相对 v1 的关键改动（首轮实测踩坑后修正）：
#   * 扫描顺序默认随机 —— v1 按 M 顺序扫，热漂移被直接混叠到 M 轴上，
#     实测 attn_qkv_proj 的 CV 随扫描进度从 1.86% 一路涨到 5.61%
#   * 每份数据交错重复 2 趟（pass_id），04 用它做可复现性闸门
#   * 先跑闸门，不合格就不用看后面的结论
#
# 注意: 全程只用一张卡、不修改任何全局配置、不 kill 任何进程。

set -euo pipefail

DEV="${1:-0}"
MODEL="${2:-llama2-7b}"
TP="${TP:-1}"
DENSE="${DENSE:-dense:960:1088}"
REPEATS="${REPEATS:-2}"
COOLDOWN="${COOLDOWN:-100}"        # ms，每个 shape 之后的冷却

mkdir -p data logs

echo "############ -1. 确认这张卡上没有别人的进程 ############"
if command -v npu-smi >/dev/null 2>&1; then
  npu-smi info 2>&1 | tee logs/00_npusmi.log | tail -30
  echo
  echo "  ^ 若 Process 一栏有别的 PID 在用卡 $DEV，请换一张空闲卡（bash run_all.sh <其他卡号>）。"
  echo "    共享卡会把噪声底抬高一个数量级，所有台阶判据都会失效。"
else
  echo "  [warn] 找不到 npu-smi，无法确认卡占用情况。"
fi

echo
echo "############ 0. 环境自检 + 噪声底标定 ############"
python 01_probe_env.py --device "$DEV" --model "$MODEL" --tp "$TP" \
  2>&1 | tee logs/01_probe.log

echo
echo "############ 1. 稠密扫描 (步长1, 随机顺序, ${REPEATS} 趟) ############"
python 02_sweep_ops.py --device "$DEV" --model "$MODEL" --tp "$TP" \
  --grid "$DENSE" --tag dense_jitOFF --jit-compile 0 \
  --order random --repeats "$REPEATS" --cooldown-ms "$COOLDOWN" \
  2>&1 | tee logs/02_dense_jitOFF.log

echo
echo "############ 2. 先过可复现性闸门 —— 不合格就别往下看 ############"
D_OFF="data/sweep_${MODEL}_tp${TP}_dense_jitOFF.csv"
python 04_analyze.py --csv "$D_OFF" --skip A,B,C,D,E 2>&1 | tee logs/04_gate.log

if grep -q "测量不合格" logs/04_gate.log; then
  echo
  echo "########################################################"
  echo "闸门未通过：测量的不可复现量大于可复现量。"
  echo "继续采数没有意义，先按 logs/04_gate.log 里的排查顺序处理："
  echo "  1) 换一张没有其他进程的卡"
  echo "  2) REPEATS=4 COOLDOWN=300 bash run_all.sh $DEV $MODEL"
  echo "  3) 只保留闸门里 r>=0.7 的算子：02_sweep_ops.py --ops <算子名>"
  echo "把 logs/04_gate.log 和 logs/01_probe.log 发我，我看下一步怎么调。"
  echo "########################################################"
  exit 1
fi

echo
echo "############ 3. jit_compile 对照 + Vidur 网格 ############"
python 02_sweep_ops.py --device "$DEV" --model "$MODEL" --tp "$TP" \
  --grid "$DENSE" --tag dense_jitON --jit-compile 1 \
  --order random --repeats "$REPEATS" --cooldown-ms "$COOLDOWN" \
  2>&1 | tee logs/02_dense_jitON.log

python 02_sweep_ops.py --device "$DEV" --model "$MODEL" --tp "$TP" \
  --grid vidur --tag vidur_jitOFF --jit-compile 0 \
  --order random --repeats "$REPEATS" --cooldown-ms "$COOLDOWN" \
  2>&1 | tee logs/02_vidur.log

echo
echo "############ 4. 抓 block_dim ############"
python 03_profile_tiling.py --device "$DEV" --model "$MODEL" --tp "$TP" \
  --grid "$DENSE" --jit-compile 0 \
  2>&1 | tee logs/03_tiling.log || echo "[warn] 03 失败，把 logs/03_tiling.log 贴出来"

echo
echo "############ 5. 完整分析 ############"
D_ON="data/sweep_${MODEL}_tp${TP}_dense_jitON.csv"
V_OFF="data/sweep_${MODEL}_tp${TP}_vidur_jitOFF.csv"

ARGS=(--csv "$D_OFF" --csv2 "$D_ON")
[ -f data/tiling_blockdim.csv ] && ARGS+=(--tiling data/tiling_blockdim.csv)
python 04_analyze.py "${ARGS[@]}" 2>&1 | tee logs/04_dense.log

python 04_analyze.py --csv "$V_OFF" --skip B,E 2>&1 | tee logs/04_vidur.log

echo
echo "########################################################"
echo "完成。需要回传："
echo "   logs/*.log   data/sweep_*.csv   data/tiling_blockdim.csv   out_env_probe.json"
echo "########################################################"

# -*- coding: utf-8 -*-
"""
第 3 步：分析 —— 直接回答"昇腾上 shape→时延 可不可学"。

这是 REPORT.md 里 E1~E4 那套分析的昇腾版，五个问题：

  A. ±1 抖动有多大？相对噪声底是几倍？          -> 抖动是真信号还是噪声
  B. 台阶落在哪个模数上？                        -> 是否解析可推
  C. 尾块占比能解释多少残差？                    -> 该用什么特征
  D. RF / 多项式 / 灰盒 内插 & 外推 谁赢？        -> 该用什么模型
  E. Vidur 的 32 步网格漏掉了多少？               -> 该怎么采样

用法:
    python 04_analyze.py --csv data/sweep_llama2-7b_tp1_dense_jitF.csv
    # 对比在线编译开/关
    python 04_analyze.py --csv data/..._jitF.csv --csv2 data/..._jitT.csv
    # 加上 03 抓到的 block_dim
    python 04_analyze.py --csv data/..._vidur_jitF.csv --tiling data/tiling_blockdim.csv
"""
import argparse
import warnings

import numpy as np
import pandas as pd

warnings.filterwarnings("ignore")

MODS = [8, 16, 32, 64, 128, 256, 512]


def mape(t, p):
    t, p = np.asarray(t, float), np.asarray(p, float)
    m = t != 0
    return float(np.mean(np.abs((t[m] - p[m]) / t[m])) * 100)


def curves(df):
    for (op,), g in df.groupby(["op"]):
        g = g.groupby("num_tokens", as_index=False).median(numeric_only=True)
        yield op, g.sort_values("num_tokens").reset_index(drop=True)


def detrend(x, y):
    """扣掉全局线性趋势，返回 (残差, R^2)。"""
    A = np.vstack([x, np.ones_like(x)]).T
    c, *_ = np.linalg.lstsq(A, y, rcond=None)
    r = y - A @ c
    return r, float(1 - r.var() / max(y.var(), 1e-30))


def find_jumps(x, y, cv, sigma=4.0, floor_pct=0.5):
    """检测显著跳变点。

    判据是**噪声标定的绝对阈值**，不是百分位：
        |Δ残差| / y  >  max(sigma * 相邻两点噪声CV的合成, floor_pct)
    这样在真的没有台阶时会返回空集（这本身就是一个有价值的结论），
    而不是像百分位阈值那样永远凑出 10% 的"跳变点"。
    """
    r, r2 = detrend(x, y)
    d = np.abs(np.diff(r)) / np.maximum(y[1:], 1e-12) * 100
    # 两点之差的噪声 = sqrt(cv_i^2 + cv_{i-1}^2)
    ncomb = np.sqrt(np.asarray(cv[1:]) ** 2 + np.asarray(cv[:-1]) ** 2)
    thr = np.maximum(sigma * ncomb, floor_pct)
    idx = np.where(d >= thr)[0] + 1
    return x[idx].astype(int), d[idx - 1], r2, float(np.median(thr))


# ---------------------------------------------------------------- A
def sec_A(df):
    print("=" * 96)
    print("A. 相邻 shape 的抖动幅度 vs 噪声底")
    print("   step=相邻采样点; 只有 step==1 时才是真正的 '±1 抖动'")
    print("=" * 96)
    print(f"{'op':16s} {'step':>5s} {'噪声CV p50':>11s} {'相邻跳变 p50':>13s} "
          f"{'p95':>8s} {'max':>8s} {'信噪比p50':>10s} {'信噪比p95':>10s}")
    print("-" * 96)
    rows = []
    for op, g in curves(df):
        x, y = g.num_tokens.values.astype(float), g["median"].values.astype(float)
        cv = g["cv_pct"].values.astype(float)
        if len(x) < 5:
            continue
        step = int(np.median(np.diff(x)))
        d = np.abs(np.diff(y)) / np.maximum(y[1:], 1e-12) * 100
        # 扣掉趋势：用相邻点的期望增量（全局线性斜率）作为基准
        A = np.vstack([x, np.ones_like(x)]).T
        c, *_ = np.linalg.lstsq(A, y, rcond=None)
        expect = np.abs(c[0] * np.diff(x)) / np.maximum(y[1:], 1e-12) * 100
        jit = np.maximum(d - expect, 0)
        n50 = float(np.median(cv))
        rows.append(dict(op=op, step=step, noise=n50,
                         j50=float(np.median(jit)), j95=float(np.percentile(jit, 95)),
                         jmax=float(np.max(jit))))
        print(f"{op:16s} {step:5d} {n50:11.2f} {np.median(jit):13.2f} "
              f"{np.percentile(jit,95):8.2f} {np.max(jit):8.2f} "
              f"{np.median(jit)/max(n50,1e-9):10.2f} {np.percentile(jit,95)/max(n50,1e-9):10.2f}")
    print("-" * 96)
    r = pd.DataFrame(rows)
    if not len(r):
        return r
    snr = float(np.median(r.j95 / np.maximum(r.noise, 1e-9)))
    steps = sorted(set(r.step))
    print(f"  汇总: 抖动 p95 / 噪声底 的中位数 = {snr:.2f}   (采样步长 {steps})")
    print()
    print("  判读 —— 必须和同步长的 GPU 基线比，不能看绝对值：")
    print("    GPU 基线 (A100 Llama-2-70B TP4, 步长 8): 信噪比 p95 中位 = 9.4")
    print("      注意 GPU 这个 9.4 已经包含了 mod-128 的真台阶，属于 '可以用 Vidur 那套搞定' 的水平。")
    if 1 in steps:
        print()
        print("    本次含步长 1 的数据，此时信噪比才真正反映 'shape ±1 抖动':")
        print("      < 3   -> ±1 基本不抖，分支边界稀疏，Vidur 那套网格 + RF 可直接沿用")
        print("      3~10  -> 有真台阶但可数，走 03 的 block_dim 分段 + 边界对齐采样即可")
        print("      > 10  -> 分支密集，禁止任何跨 shape 插值，必须按 TilingKey 分段建模")
    else:
        print()
        print("    [注意] 本次没有步长 1 的数据，上面的数字里混入了正常的趋势增长，")
        print("           不能用来判断 '±1 抖动'。请补跑: --grid dense:LO:HI")
    return r


# ---------------------------------------------------------------- B
def sec_B(df):
    print()
    print("=" * 96)
    print("B. 台阶位置：跳变是否对齐到某个模数？（GPU 上实测全部对齐 mod 128）")
    print("=" * 96)
    for op, g in curves(df):
        x, y = g.num_tokens.values.astype(float), g["median"].values.astype(float)
        cv = g["cv_pct"].values.astype(float)
        if len(x) < 20:
            continue
        if int(np.median(np.diff(x))) != 1:
            print(f"  [{op}] 采样步长 != 1，跳过（模数检验需要 dense 网格）")
            continue
        big, mag, r2, thr = find_jumps(x, y, cv)
        print(f"\n--- {op}: 全局线性 R^2={r2:.5f}, 判据阈值 {thr:.2f}% (=4σ噪声), "
              f"检出 {len(big)} 处显著跳变 / 共 {len(x)-1} 个相邻间隔 ---")
        if len(big) == 0:
            print("    没有超过噪声 4σ 的跳变 —— 该算子在本窗口内 shape 响应是光滑的，")
            print("    可以安全插值，不需要分支建模。")
            continue
        if len(big) > 0.5 * (len(x) - 1):
            print("    [警告] 一半以上的间隔都算跳变 —— 说明抖动是弥散的而非离散台阶，")
            print("           模数检验对这种情况无意义，请直接看 C 段的尾块项。")
        # big 记录的是跳变**后**的采样点，真正的边界通常在 big-1（即 M 跨过 n*tile）。
        # 两种对齐都试，取富集更强的那个。
        rank = []
        for k in MODS:
            h0 = float(np.mean(big % k == 0))
            h1 = float(np.mean((big - 1) % k == 0))
            hit, off = (h0, 0) if h0 >= h1 else (h1, 1)
            base = 1.0 / k
            lift = hit / base if base > 0 else 0.0
            rank.append((k, hit, base, lift, off))
            print(f"    mod {k:4d}: 跳变点中 {hit*100:5.1f}% 落在边界上 "
                  f"(对齐 M-{off}, 随机基线 {base*100:4.1f}%, 提升 {lift:5.1f}x)")
        # 真 tile 是"能解释全部跳变的最大模数"：若 tile=128，则 8/16/…/128 都 100% 命中，
        # 256 只能命中一半。所以取 hit>=0.95 中最大的 k；没有这样的 k 再退回 lift 最大。
        full = [t for t in rank if t[1] >= 0.95]
        best = max(full, key=lambda t: t[0]) if full else max(rank, key=lambda t: t[3])
        if best[3] >= 2.0 and best[1] >= 0.3:
            print(f"    => 最可能的量化粒度 tile = {best[0]}  "
                  f"(命中 {best[1]*100:.0f}%, 提升 {best[3]:.1f}x, 边界在 M ≡ {best[4]} mod {best[0]})")
        else:
            print(f"    => 没有任何模数显著富集（最好的是 mod {best[0]}，仅 {best[3]:.1f}x）。")
            print(f"       跳变位置不规则 -> 不是简单的 tile 量化，需要靠 03 的 block_dim 定位。")
            if len(big) < 4:
                print(f"       [注意] 只检出 {len(big)} 个跳变点，样本太少，模数检验不可信；"
                      f"请扩大 dense 窗口再看。")
        print(f"    跳变点样例: {sorted(set(int(v) for v in big))[:18]}")


# ---------------------------------------------------------------- C
def sec_C(df):
    print()
    print("=" * 96)
    print("C. 尾块占比能解释多少？")
    print("   模型 y = a*M + b + c*tail(M,tile),  tail = (-M) mod tile  （补齐到 tile 需要的空转量）")
    print("=" * 96)
    print(f"{'op':16s} {'tile':>6s} {'纯线性残差MAPE':>15s} {'加尾块项后':>12s} {'降幅':>8s}")
    print("-" * 96)
    for op, g in curves(df):
        x, y = g.num_tokens.values.astype(float), g["median"].values.astype(float)
        if len(x) < 20:
            continue
        A0 = np.vstack([x, np.ones_like(x)]).T
        c0, *_ = np.linalg.lstsq(A0, y, rcond=None)
        e0 = mape(y, A0 @ c0)
        best = (None, e0)
        for k in MODS:
            tail = (-x) % k
            A1 = np.vstack([x, np.ones_like(x), tail]).T
            c1, *_ = np.linalg.lstsq(A1, y, rcond=None)
            e1 = mape(y, A1 @ c1)
            if e1 < best[1]:
                best = (k, e1)
        k, e1 = best
        drop = (e0 - e1) / max(e0, 1e-12) * 100
        print(f"{op:16s} {str(k):>6s} {e0:15.2f} {e1:12.2f} {drop:7.1f}%")
    print("-" * 96)
    print("  降幅 > 20% 说明尾块是抖动主因 -> 建模时必须把 tail 当特征，而不是让模型从 M 去猜。")


# ---------------------------------------------------------------- D
def sec_D(df):
    from sklearn.ensemble import RandomForestRegressor
    from sklearn.linear_model import LinearRegression
    from sklearn.model_selection import GridSearchCV
    from sklearn.pipeline import make_pipeline
    from sklearn.preprocessing import PolynomialFeatures

    print()
    print("=" * 96)
    print("D. RF(Vidur默认) / 多项式 / 灰盒 —— 内插与外推")
    print("=" * 96)

    def rf(X, y):
        gs = GridSearchCV(RandomForestRegressor(random_state=0),
                          {"n_estimators": [250], "max_depth": [8, 16, 32],
                           "min_samples_split": [2, 5]}, cv=3, n_jobs=-1)
        gs.fit(X, y)
        return gs.best_estimator_

    def poly(X, y):
        gs = GridSearchCV(make_pipeline(PolynomialFeatures(), LinearRegression()),
                          {"polynomialfeatures__degree": [1, 2, 3, 4, 5]}, cv=3, n_jobs=-1)
        gs.fit(X, y)
        return gs.best_estimator_

    class Gray:
        """灰盒：解析骨架 ceil(M/tile)*tile + 尾块项，只有 3 个参数。tile 由数据选。"""
        def fit(self, X, y):
            m = X[:, 0]
            best = None
            for k in MODS:
                F = np.vstack([np.ceil(m / k) * k, np.ones_like(m), (-m) % k]).T
                c, *_ = np.linalg.lstsq(F, y, rcond=None)
                e = mape(y, F @ c)
                if best is None or e < best[2]:
                    best = (k, c, e)
            self.k, self.c = best[0], best[1]
            return self

        def predict(self, X):
            m = X[:, 0]
            F = np.vstack([np.ceil(m / self.k) * self.k, np.ones_like(m), (-m) % self.k]).T
            return F @ self.c

    for tag, mode in [("内插 (隔点训练/隔点测试)", "interp"),
                      ("外推 (前 70% 训练, 后 30% 测试)", "extrap")]:
        print(f"\n--- {tag} ---")
        print(f"{'op':16s} | {'RF':>9s} {'Poly':>9s} {'GrayBox':>9s} {'tile':>6s}")
        print("-" * 60)
        acc = {}
        for op, g in curves(df):
            if len(g) < 24:
                continue
            if mode == "interp":
                tr, te = g.iloc[::2], g.iloc[1::2]
            else:
                cut = int(len(g) * 0.7)
                tr, te = g.iloc[:cut], g.iloc[cut:]
            Xtr = tr[["num_tokens"]].values.astype(float)
            ytr = tr["median"].values.astype(float)
            Xte = te[["num_tokens"]].values.astype(float)
            yte = te["median"].values.astype(float)
            e_rf = mape(yte, rf(Xtr, ytr).predict(Xte))
            e_po = mape(yte, poly(Xtr, ytr).predict(Xte))
            gb = Gray().fit(Xtr, ytr)
            e_gb = mape(yte, gb.predict(Xte))
            print(f"{op:16s} | {e_rf:8.2f}% {e_po:8.2f}% {e_gb:8.2f}% {gb.k:6d}")
            for k, v in [("RF", e_rf), ("Poly", e_po), ("Gray", e_gb)]:
                acc.setdefault(k, []).append(v)
        if acc:
            print("-" * 60)
            print("  均值: " + "  ".join(f"{k}={np.mean(v):.2f}%" for k, v in acc.items()))
            print("  最差: " + "  ".join(f"{k}={np.max(v):.2f}%" for k, v in acc.items()))
    print()
    print("  对照 GPU 实测（REPORT.md E3）: 内插 RF 3.08% / 外推 RF 31.83%、灰盒 5.38%。")
    print("  若昇腾上外推 RF 也明显崩，则结论一致：RF 只能当曲线加密器，不能当预测器。")


# ---------------------------------------------------------------- E
def sec_E(df):
    print()
    print("=" * 96)
    print("E. Vidur 的 32 步网格会漏掉多少？（需要 dense 网格数据）")
    print("=" * 96)
    for op, g in curves(df):
        x = g.num_tokens.values.astype(float)
        y = g["median"].values.astype(float)
        if len(x) < 40 or int(np.median(np.diff(x))) != 1:
            print(f"  [{op}] 需要 step=1 的 dense 数据，跳过")
            continue
        lo, hi = x.min(), x.max()
        keep = (x % 32 == 0) | (x == lo) | (x == hi)
        if keep.sum() < 3:
            print(f"  [{op}] 窗口内 32 的倍数太少（{int(keep.sum())} 个），换更宽的 dense 窗口")
            continue
        pred = np.interp(x, x[keep], y[keep])     # 模拟"只采 32 步网格 + 插值"
        err = np.abs(pred - y) / np.maximum(y, 1e-12) * 100
        print(f"  {op:16s}  Vidur 网格插值误差: p50 {np.median(err):5.2f}%  "
              f"p95 {np.percentile(err,95):5.2f}%  max {np.max(err):6.2f}%  "
              f"(实采 {int(keep.sum())}/{len(x)} 点)")
    print()
    print("  max > 10% 就说明: 直接照搬 Vidur 的采样网格会系统性漏掉分支边界，")
    print("  必须改成 03 输出的 block_dim 切换点驱动的边界对齐采样。")


# ---------------------------------------------------------------- 对比
def sec_jit(df1, df2):
    print()
    print("=" * 96)
    print("F. 在线编译 (jit_compile) 开/关 对抖动的影响")
    print("=" * 96)
    c1 = {op: g for op, g in curves(df1)}
    c2 = {op: g for op, g in curves(df2)}
    print(f"{'op':16s} {'jitF中位(ms)':>13s} {'jitT中位(ms)':>13s} "
          f"{'jitF抖动p95':>12s} {'jitT抖动p95':>12s}")
    print("-" * 96)
    for op in sorted(set(c1) & set(c2)):
        def jit_p95(g):
            y = g["median"].values.astype(float)
            x = g.num_tokens.values.astype(float)
            A = np.vstack([x, np.ones_like(x)]).T
            c, *_ = np.linalg.lstsq(A, y, rcond=None)
            d = np.abs(np.diff(y)) / np.maximum(y[1:], 1e-12) * 100
            e = np.abs(c[0] * np.diff(x)) / np.maximum(y[1:], 1e-12) * 100
            return float(np.percentile(np.maximum(d - e, 0), 95))
        print(f"{op:16s} {np.median(c1[op]['median']):13.4f} "
              f"{np.median(c2[op]['median']):13.4f} "
              f"{jit_p95(c1[op]):11.2f}% {jit_p95(c2[op]):11.2f}%")
    print("-" * 96)
    print("  若 jitT 抖动显著更大 -> 抖动主要来自在线编译，部署时关掉 jit_compile 即可大幅缓解，")
    print("     且建模只需针对 jit_compile=False 这一种情况。")
    print("  若两者差不多      -> 抖动来自 tiling 分支本身，必须走分支求值路线。")


def sec_tiling(df, tdf):
    print()
    print("=" * 96)
    print("G. 时延跳变 与 block_dim 切换 是否对齐？")
    print("=" * 96)
    for op, g in curves(df):
        t = tdf[tdf.op == op].sort_values("num_tokens")
        if len(t) < 5:
            continue
        bd = t.block_dim.values
        Mt = t.num_tokens.values.astype(float)
        sw = set(Mt[1:][bd[1:] != bd[:-1]].astype(int))
        x = g.num_tokens.values.astype(float)
        y = g["median"].values.astype(float)
        cv = g["cv_pct"].values.astype(float)
        big_arr, _, _, _ = find_jumps(x, y, cv)
        big = set(int(v) for v in big_arr)
        if not big and not sw:
            print(f"  {op:16s}  无显著时延跳变, 也无 block_dim 切换 -> 该窗口内曲线光滑")
            continue
        if not big:
            print(f"  {op:16s}  无显著时延跳变, 但有 {len(sw)} 处 block_dim 切换 "
                  f"-> 切换不影响性能, 可跨切换点插值")
            continue
        prec = len(big & sw) / max(len(big), 1)     # 跳变里有多少被 block_dim 解释
        rec = len(big & sw) / max(len(sw), 1)       # 切换点里有多少真的引起跳变
        print(f"  {op:16s}  时延跳变 {len(big):4d} 个, block_dim 切换 {len(sw):4d} 个, "
              f"重合 {len(big & sw):4d}  -> 跳变被解释率 {prec*100:5.1f}%, "
              f"切换有效率 {rec*100:5.1f}%")
    print()
    print("  '跳变被解释率' 高 => 抖动被 block_dim 完全解释，直接按 block_dim 分段建模即可。")
    print("  '跳变被解释率' 低 => 还有 block_dim 观测不到的隐藏分支（尾块/格式/流水线），看 C 段。")
    print("  '切换有效率'   低 => block_dim 变了但性能没变，说明可以合并这些分支，减少采样点。")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--csv", required=True)
    ap.add_argument("--csv2", default="", help="第二份（用于 jit_compile 开/关对比）")
    ap.add_argument("--tiling", default="", help="03 输出的 block_dim CSV")
    ap.add_argument("--op", default="", help="只分析某个算子")
    ap.add_argument("--skip", default="", help="跳过的段, 例如 D,E")
    args = ap.parse_args()

    df = pd.read_csv(args.csv)
    if args.op:
        df = df[df.op == args.op]
    skip = {s.strip().upper() for s in args.skip.split(",") if s.strip()}

    print(f"数据: {args.csv}   {len(df)} 行, "
          f"{df.op.nunique()} 算子, M ∈ [{df.num_tokens.min()}, {df.num_tokens.max()}], "
          f"{df.num_tokens.nunique()} 个点")

    if "A" not in skip:
        sec_A(df)
    if "B" not in skip:
        sec_B(df)
    if "C" not in skip:
        sec_C(df)
    if "D" not in skip:
        try:
            sec_D(df)
        except ImportError:
            print("\n[skip D] 需要 scikit-learn: pip install scikit-learn")
    if "E" not in skip:
        sec_E(df)
    if args.csv2:
        sec_jit(df, pd.read_csv(args.csv2))
    if args.tiling:
        sec_tiling(df, pd.read_csv(args.tiling))


if __name__ == "__main__":
    main()

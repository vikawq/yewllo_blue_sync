# 昇腾 NPU 算子性能可学习性诊断

配套 `../REPORT.md`。目的是先回答一个前置问题——**"shape 抖动到底是什么性质"**——
再决定要不要、以及怎么把 Vidur 那套搬到昇腾上。所以这批脚本是**诊断**，不是建模。

## 为什么不能直接抄 Vidur

在 A100/H100/A40 的真实数据上实测（`../analysis/`）：

| 场景 | Vidur 的随机森林 | 2~3 参数的解析式 |
|---|---|---|
| 域内插值 | **3.08%** | 7.50% |
| 域外外推 | **31.83%**（最差 39%） | **5.38%** |

Vidur 的 RF 是**曲线加密器**，不是预测器——只在 profiling 网格的凸包内有效。
它的采样网格是 [1,4096] 上 259 点，>256 后步长固定 32，**看不到 shape ±1 的跳变**。
GPU 上这样可行，是因为分支边界规则（实测全部落在 mod 128）且稀疏；
昇腾上分支由 `TilingKey` 决定，更密更不规则，照抄一定失准。

## 依赖

服务器上应已有 `torch` + `torch_npu`（CANN 环境）。额外只需要：

```bash
pip install numpy pandas scikit-learn
source /usr/local/Ascend/ascend-toolkit/set_env.sh
```

## 一键跑

```bash
bash run_all.sh 0 llama2-7b          # 参数: 设备号 模型名
DENSE=dense:2000:2128 bash run_all.sh 0 llama2-70b   # 换稠密窗口
```

约 30–60 分钟。**只用一张卡，不修改任何全局配置，不 kill 任何进程**；
`02_sweep_ops.py` 在剩余显存不足 4GB 时会主动退出（`--min-free-gb` 可调）。

## 分步跑

```bash
# 0. 环境自检 + 噪声底标定（必做，5 分钟）
python 01_probe_env.py --device 0 --model llama2-7b

# 1. 步长 1 的稠密扫描 —— 判断"可不可学"的决定性数据
#    --order random 和 --repeats 2 是必须的，别省
python 02_sweep_ops.py --grid dense:960:1088 --tag dense_jitOFF --jit-compile 0                        --order random --repeats 2 --cooldown-ms 100
python 02_sweep_ops.py --grid dense:960:1088 --tag dense_jitON  --jit-compile 1                        --order random --repeats 2 --cooldown-ms 100

# 1b. 先过闸门！不合格就别往下采
python 04_analyze.py --csv data/sweep_llama2-7b_tp1_dense_jitOFF.csv --skip A,B,C,D,E

# 2. Vidur 网格 —— 给建模对比用
python 02_sweep_ops.py --grid vidur --tag vidur_jitOFF --jit-compile 0                        --order random --repeats 2

# 3. 抓 block_dim（白盒环节，best effort）
python 03_profile_tiling.py --grid dense:1000:1064 --jit-compile 0

# 4. 分析
python 04_analyze.py --csv data/sweep_llama2-7b_tp1_dense_jitOFF.csv \
                     --csv2 data/sweep_llama2-7b_tp1_dense_jitON.csv \
                     --tiling data/tiling_blockdim.csv
python 04_analyze.py --csv data/sweep_llama2-7b_tp1_vidur_jitOFF.csv --skip B,E

# 若两份 CSV 是设置完全相同的重复测量（而非 jit 对照），加 --replicate 做交叉复现性检验
python 04_analyze.py --csv a.csv --csv2 b.csv --replicate --skip A,B,C,D,E
```

## 脚本职责

| 脚本 | 干什么 | 关键产出 |
|---|---|---|
| `common.py` | 设备/算子/计时/网格 | —— |
| `01_probe_env.py` | warmup 收敛性 + **噪声底 CV** | 误差下界，后续所有判据的标尺 |
| `02_sweep_ops.py` | shape 扫描 | `data/sweep_*.csv` |
| `03_profile_tiling.py` | 抓 `block_dim` / kernel 名 | `data/tiling_blockdim.csv`，**分支边界位置** |
| `04_analyze.py` | R + A–G 八段分析 | 结论（R 是闸门，先看它） |

`04_analyze.py` 的八段：

- **R 可复现性闸门** → 测量本身有没有意义（**先看这个**）
- **A 抖动幅度 vs 噪声底** → 抖动是真信号还是噪声
- **B 台阶模数检验** → 台阶位置是否解析可推（需 step=1 数据）
- **C 尾块占比** → 该用什么特征
- **D RF / 多项式 / 灰盒，内插 & 外推** → 该用什么模型
- **E Vidur 32 步网格漏采率** → 该怎么采样
- **F jit_compile 开/关** → 抖动来自在线编译还是 tiling 分支
- **G 时延跳变 vs block_dim 切换** → 抖动能否被 block_dim 完全解释

## 怎么读结果（决策树）

**第 0 步永远是 R 段（可复现性闸门）。** 首轮实测的教训：噪声底最高到 19% CV，
两次独立测量的残差相关性只有 r=0.17~0.46，不可复现量比可复现量大 2~30 倍——
在那种数据上 A/B/C/D/E 段看到的一切"台阶"都是幻觉。
R 段报"测量不合格"时，唯一该做的事是修测量，不是解读结果。

再看 **F**：

- **jitON 抖动 >> jitOFF** → 抖动主要来自在线编译。部署时关掉 `jit_compile`，
  建模只针对 `jit_compile=False`，问题大幅简化。
- **两者接近** → 抖动来自 tiling 分支本身，继续往下看。

再看 **A**（必须有 step=1 数据）：

- 信噪比 p95 **< 3** → ±1 基本不抖，Vidur 那套网格 + RF 可直接沿用。
- **3~10** → 有真台阶但可数 → 用 **G** 的 block_dim 切换点做边界对齐采样。
- **> 10** → 分支密集 → 禁止任何跨 shape 插值，必须按 TilingKey 分段建模。

然后看 **G** 和 **C** 定位抖动来源：

- G 的"跳变被解释率"高 → 直接按 block_dim 分段，问题解决。
- G 低但 C 的降幅 > 20% → 抖动来自**尾块**，把 `tail = (-M) mod tile` 加成特征即可。
- 两者都低 → 还有隐藏分支（格式转换 / 流水线），需要更细的 profiling。

最后看 **D** 验证结论：如果外推 RF 也像 GPU 那样崩到 30%，
就确认了"RF 只能当曲线加密器"这一点，建模必须走 `../REPORT.md §3.3` 的三段式。

## 几个容易踩的坑

- **warmup 不够**：昇腾首次遇到新 shape 会算 tiling / 取 kernel 二进制，
  第一次调用可能比稳态慢一个数量级。`01` 会告诉你需要多少次。
- **Event 开销**：小算子（norm/add）单次只有几十微秒，NPU Event 开销不可忽略。
  `01` 会打印"event开销占比"，超过 20% 的算子只能看相对趋势，绝对值不可信。
- **别的进程在抢卡**：会把噪声底抬到 5% 以上，所有台阶判据失效。先看 `01` 的 CV。
- **dense 窗口太窄**：`04` 的 B 段模数检验需要窗口里有 **至少 4 个真边界**，
  否则会提示"样本太少不可信"。tile 若是 256，窗口至少要 1000+ 宽。
- **按 M 顺序扫描**（v1 的 bug，已修）：热漂移会被直接混叠到 M 轴上，
  伪装成 shape 结构。实测 attn_qkv_proj 的 CV 随扫描进度从 1.86% 涨到 5.61%。
  现在 `--order random` 是默认值，别改回 `seq`。
- **别人的进程在用同一张卡**：会把噪声底抬高一个数量级。`run_all.sh` 开头会跑
  `npu-smi info` 让你确认。

## 跑完请回传

```
logs/*.log
data/sweep_*.csv
data/tiling_blockdim.csv     # 03 成功的话
out_env_probe.json
```

`03` 如果报"没找到含 Block Dim 列的 CSV"，把它打印出的文件列表一起发过来，
profiler 输出格式随 CANN 版本变化，我按实际列名改解析。

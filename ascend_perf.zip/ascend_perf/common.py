# -*- coding: utf-8 -*-
"""
昇腾算子性能采集公共模块。

设计要点（对应 REPORT.md §3）：
  1. 算子按 Vidur 的 triage 分类，token 级算子唯一自变量是 M = num_tokens；
  2. 计时用 NPU Event，逐次记录，保留完整分布 —— 因为我们需要噪声底 (CV) 来
     区分"测量噪声"和"确定性台阶"，只取中位数会把这个信息丢掉；
  3. 每个 shape 独立 warmup —— 昇腾首次遇到新 shape 会触发 tiling/编译，
     不 warmup 会把编译时间测进去。
"""
import os
import sys
import time
import math
import json

import numpy as np

try:
    import torch
except ImportError:
    sys.exit("[FATAL] 未找到 PyTorch。请先激活带 torch_npu 的环境。")

try:
    import torch_npu  # noqa: F401  导入即注册 npu 后端
except ImportError:
    sys.exit("[FATAL] 未找到 torch_npu。本套脚本必须在昇腾环境运行。\n"
             "        确认已 source /usr/local/Ascend/ascend-toolkit/set_env.sh")


# --------------------------------------------------------------------------
# 设备
# --------------------------------------------------------------------------
def setup_device(idx=0, jit_compile=None, allow_internal_format=None):
    """选定 NPU 并设置编译模式。

    jit_compile:
        True  -> 每个新 shape 触发一次在线编译（老 CANN 默认）
        False -> 使用预编译二进制 kernel + 动态 tiling（新 CANN 默认）
        None  -> 不修改，用环境默认
    这个开关直接决定 shape 抖动的性质，02_sweep_ops.py 会两种都测一遍。

    allow_internal_format:
        False -> 禁止内部私有格式（NZ 等），权重保持 ND
        True  -> 允许 ND->NZ 转换
        None  -> 不修改
    """
    if not torch.npu.is_available():
        sys.exit("[FATAL] torch.npu.is_available() == False")

    torch.npu.set_device(idx)
    info = {"device_index": idx}

    if jit_compile is not None:
        try:
            torch.npu.set_compile_mode(jit_compile=bool(jit_compile))
            info["jit_compile"] = bool(jit_compile)
        except Exception as e:                                  # noqa: BLE001
            info["jit_compile"] = f"UNSUPPORTED ({e})"
    else:
        info["jit_compile"] = "default"

    if allow_internal_format is not None:
        ok = False
        for holder in ("torch.npu.config", "torch_npu.npu.config"):
            try:
                obj = eval(holder)                              # noqa: S307
                obj.allow_internal_format = bool(allow_internal_format)
                ok = True
                break
            except Exception:                                   # noqa: BLE001
                continue
        info["allow_internal_format"] = bool(allow_internal_format) if ok else "UNSUPPORTED"
    else:
        info["allow_internal_format"] = "default"

    return info


def free_memory_gb(idx=0):
    """返回该卡剩余显存 (GB)。用于在分配前自检，避免影响别人的进程。"""
    try:
        total = torch.npu.get_device_properties(idx).total_memory
        reserved = torch.npu.memory_reserved(idx)
        return (total - reserved) / (1024 ** 3)
    except Exception:                                           # noqa: BLE001
        return float("nan")


# --------------------------------------------------------------------------
# 模型规格（声明式，仿 Vidur）
# --------------------------------------------------------------------------
MODEL_SPECS = {
    "llama2-7b": dict(hidden=4096, mlp_hidden=11008, n_head=32, n_kv_head=32,
                      head_dim=128, gated=True),
    "llama2-13b": dict(hidden=5120, mlp_hidden=13824, n_head=40, n_kv_head=40,
                       head_dim=128, gated=True),
    "llama2-70b": dict(hidden=8192, mlp_hidden=28672, n_head=64, n_kv_head=8,
                       head_dim=128, gated=True),
    "qwen2-7b":  dict(hidden=3584, mlp_hidden=18944, n_head=28, n_kv_head=4,
                      head_dim=128, gated=True),
}

DTYPES = {"fp16": torch.float16, "bf16": torch.bfloat16, "fp32": torch.float32}


def build_ops(spec, tp=1, dtype=torch.float16, device="npu"):
    """按 Vidur 的算子分诊构造 token 级算子。

    返回 {op_name: (make_fn, out_shape_fn)}，make_fn(M) -> 无参可调用对象。
    权重按 TP 切分后的分片 shape 构造（Vidur 的"shape 显式推导"）。
    """
    h = spec["hidden"]
    f = spec["mlp_hidden"]
    hd = spec["head_dim"]
    nq = spec["n_head"]
    nkv = spec["n_kv_head"]
    assert nq % tp == 0, f"n_head={nq} 不能被 tp={tp} 整除"
    assert f % tp == 0, f"mlp_hidden={f} 不能被 tp={tp} 整除"

    qkv_out = (nq // tp + 2 * max(nkv // tp, 1)) * hd
    attn_out_in = (nq // tp) * hd
    mlp_up_out = (2 if spec["gated"] else 1) * (f // tp)
    mlp_down_in = f // tp

    def W(o, i):
        return torch.randn(o, i, dtype=dtype, device=device) * 0.02

    w_qkv = W(qkv_out, h)
    w_o = W(h, attn_out_in)
    w_up = W(mlp_up_out, h)
    w_down = W(h, mlp_down_in)
    g_norm = torch.ones(h, dtype=dtype, device=device)

    def _x(M, dim):
        return torch.randn(M, dim, dtype=dtype, device=device) * 0.1

    ops = {}

    # ---- GEMM 类（Vidur 的 token 级算子主体，也是台阶最明显的地方）----
    def mk_qkv(M):
        x = _x(M, h)
        return lambda: torch.nn.functional.linear(x, w_qkv)
    ops["attn_qkv_proj"] = mk_qkv

    def mk_o(M):
        x = _x(M, attn_out_in)
        return lambda: torch.nn.functional.linear(x, w_o)
    ops["attn_o_proj"] = mk_o

    def mk_up(M):
        x = _x(M, h)
        return lambda: torch.nn.functional.linear(x, w_up)
    ops["mlp_up_proj"] = mk_up

    def mk_down(M):
        x = _x(M, mlp_down_in)
        return lambda: torch.nn.functional.linear(x, w_down)
    ops["mlp_down_proj"] = mk_down

    # ---- 访存类（用来对比：这些算子应当没有 tile 台阶，只有带宽饱和）----
    def mk_act(M):
        x = _x(M, mlp_up_out)
        half = mlp_up_out // 2 if spec["gated"] else mlp_up_out
        if spec["gated"]:
            return lambda: torch.nn.functional.silu(x[:, :half]) * x[:, half:]
        return lambda: torch.nn.functional.silu(x)
    ops["mlp_act"] = mk_act

    def mk_norm(M):
        x = _x(M, h)
        eps = 1e-6
        def fn():
            v = x.float()
            r = v * torch.rsqrt(v.pow(2).mean(-1, keepdim=True) + eps)
            return (r.to(x.dtype) * g_norm)
        return fn
    ops["rms_norm"] = mk_norm

    def mk_add(M):
        a = _x(M, h)
        b = _x(M, h)
        return lambda: a + b
    ops["add"] = mk_add

    return ops


# --------------------------------------------------------------------------
# 计时
# --------------------------------------------------------------------------
def time_op(fn, warmup=30, iters=100, use_events=True):
    """返回单次执行耗时数组 (ms)。

    warmup 必须足够 —— 昇腾首次遇到新 shape 会做 tiling 计算 / 取 kernel 二进制，
    第一次调用往往比稳态慢一个数量级。
    """
    for _ in range(warmup):
        fn()
    torch.npu.synchronize()

    samples = []
    if use_events:
        try:
            for _ in range(iters):
                s = torch.npu.Event(enable_timing=True)
                e = torch.npu.Event(enable_timing=True)
                s.record()
                fn()
                e.record()
                torch.npu.synchronize()
                samples.append(s.elapsed_time(e))
            return np.asarray(samples, dtype=np.float64)
        except Exception:                                       # noqa: BLE001
            samples = []

    # 回退：wall clock + synchronize
    for _ in range(iters):
        torch.npu.synchronize()
        t0 = time.perf_counter()
        fn()
        torch.npu.synchronize()
        samples.append((time.perf_counter() - t0) * 1e3)
    return np.asarray(samples, dtype=np.float64)


def time_op_batched(fn, warmup=30, reps=20, inner=20):
    """把 inner 次调用打包计时再平均，用于抵消 Event 开销。
    小算子（norm/add）的单次耗时可能只有几十微秒，Event 开销不可忽略，
    需要用这个结果去校验 time_op 的绝对值。"""
    for _ in range(warmup):
        fn()
    torch.npu.synchronize()
    out = []
    for _ in range(reps):
        t0 = time.perf_counter()
        for _ in range(inner):
            fn()
        torch.npu.synchronize()
        out.append((time.perf_counter() - t0) * 1e3 / inner)
    return np.asarray(out, dtype=np.float64)


def pick_timing_mode(fn, min_event_ms=0.15, probe_iters=12):
    """决定某个算子该用 Event 逐次计时还是打包计时。

    实测教训 (Ascend950PR, CANN 9.1)：Event 计时本身有约 0.010~0.029 ms 的固定开销。
    对 add(0.027 ms) 占 70%、rms_norm(0.087 ms) 占 33%、mlp_act(0.104 ms) 占 13%，
    而这三个算子恰好就是可复现性闸门里判成"不可用"的三个（复现噪声 2.5~10.7%）。
    噪声不是硬件抖，是计时方法测不动 —— 单次耗时越短，Event 开销的相对涨落越大。

    返回 ("event", 1) 或 ("batched", inner)。
    模式必须**按算子固定**、不能随 M 变 —— 否则模式切换会在 M 轴上造出一个假台阶。
    """
    med = float(np.median(time_op(fn, warmup=20, iters=probe_iters)))
    if med >= min_event_ms:
        return "event", 1
    inner = int(min(64, max(4, math.ceil(min_event_ms * 4 / max(med, 1e-6)))))
    return "batched", inner


def time_mode(fn, mode, inner, warmup=30, iters=50):
    """按 pick_timing_mode 选定的模式计时，返回每次调用耗时 (ms) 数组。"""
    if mode == "batched":
        return time_op_batched(fn, warmup=warmup, reps=iters, inner=inner)
    return time_op(fn, warmup=warmup, iters=iters)


def stats(a):
    return dict(
        min=float(np.min(a)), max=float(np.max(a)),
        mean=float(np.mean(a)), median=float(np.median(a)),
        std=float(np.std(a)), p95=float(np.percentile(a, 95)),
        cv_pct=float(np.std(a) / max(np.mean(a), 1e-12) * 100),
        n=int(a.size),
    )


# --------------------------------------------------------------------------
# 采样网格
# --------------------------------------------------------------------------
def grid_vidur(max_tokens=4096):
    """复刻 Vidur 的网格：小 M 密、>256 后步长固定 32。
    共约 259 点 / [1,4096]，实测覆盖率约 13%。"""
    g = [1, 2, 4, 8]
    g += list(range(16, 257, 8))
    g += list(range(288, max_tokens + 1, 32))
    return sorted(set(x for x in g if x <= max_tokens))


def grid_dense(lo, hi, step=1):
    """步长 1 的稠密扫描 —— 这是判断"抖动有多严重"的唯一可靠手段。
    Vidur 的 32 步网格根本看不到 shape ±1 引起的跳变。"""
    return list(range(lo, hi + 1, step))


def grid_windows(centers, radius=8, step=1):
    """在若干中心点附近做 ±radius 的稠密采样（边界对齐采样的雏形）。"""
    out = set()
    for c in centers:
        for m in range(max(1, c - radius), c + radius + 1, step):
            out.add(m)
    return sorted(out)


def grid_from_spec(spec_str, max_tokens=4096):
    """解析 --grid 参数。
      vidur                 -> Vidur 复刻网格
      dense:LO:HI[:STEP]    -> 稠密扫描
      win:C1,C2,...:R       -> 多窗口稠密扫描
      list:1,2,3            -> 显式列表
    多段可用 '+' 连接，例如 'vidur+dense:1000:1080'
    """
    out = set()
    for part in spec_str.split("+"):
        part = part.strip()
        if part == "vidur":
            out |= set(grid_vidur(max_tokens))
        elif part.startswith("dense:"):
            f = part.split(":")[1:]
            lo, hi = int(f[0]), int(f[1])
            step = int(f[2]) if len(f) > 2 else 1
            out |= set(grid_dense(lo, hi, step))
        elif part.startswith("win:"):
            f = part.split(":")
            centers = [int(x) for x in f[1].split(",")]
            radius = int(f[2]) if len(f) > 2 else 8
            out |= set(grid_windows(centers, radius))
        elif part.startswith("list:"):
            out |= set(int(x) for x in part.split(":")[1].split(","))
        else:
            raise ValueError(f"无法解析的 grid 段: {part}")
    return sorted(x for x in out if 1 <= x <= max_tokens)


def env_report():
    r = {"torch": torch.__version__}
    try:
        r["torch_npu"] = torch_npu.__version__
    except Exception:                                           # noqa: BLE001
        r["torch_npu"] = "unknown"
    for k in ("ASCEND_HOME_PATH", "ASCEND_TOOLKIT_HOME", "ASCEND_RT_VISIBLE_DEVICES"):
        r[k] = os.environ.get(k, "")
    try:
        p = torch.npu.get_device_properties(torch.npu.current_device())
        r["device_name"] = getattr(p, "name", str(p))
        r["total_memory_gb"] = round(p.total_memory / 1024 ** 3, 2)
    except Exception as e:                                      # noqa: BLE001
        r["device_name"] = f"unknown ({e})"
    return r

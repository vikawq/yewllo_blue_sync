# -*- coding: utf-8 -*-
"""
第 0 步：环境自检 + 噪声底标定。

在做任何建模之前必须先知道两件事：
  1. 这台机器上重复测量的 CV 是多少 —— 这是误差下界，也是判断"某个跳变
     到底是真台阶还是噪声"的唯一标尺。GPU 上实测是 0.7~1.3%。
  2. warmup 需要多少次才能进入稳态 —— 昇腾首次遇到新 shape 会算 tiling、
     取 kernel 二进制，不排除掉会把编译时间当成算子时间。

用法:
    python 01_probe_env.py --device 0 --model llama2-7b
"""
import argparse
import json

import numpy as np

from common import (DTYPES, MODEL_SPECS, build_ops, env_report, free_memory_gb,
                    setup_device, stats, time_op, time_op_batched)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--device", type=int, default=0)
    ap.add_argument("--model", default="llama2-7b", choices=list(MODEL_SPECS))
    ap.add_argument("--tp", type=int, default=1)
    ap.add_argument("--dtype", default="fp16", choices=list(DTYPES))
    ap.add_argument("--iters", type=int, default=200)
    args = ap.parse_args()

    info = setup_device(args.device)
    print("=" * 78)
    print("环境")
    print("=" * 78)
    for k, v in {**env_report(), **info}.items():
        print(f"  {k:26s} = {v}")
    print(f"  {'free_memory_gb':26s} = {free_memory_gb(args.device):.2f}")

    spec = MODEL_SPECS[args.model]
    ops = build_ops(spec, tp=args.tp, dtype=DTYPES[args.dtype])

    # ---------------- warmup 收敛性 ----------------
    print()
    print("=" * 78)
    print("A. warmup 收敛性: 前 N 次调用相对稳态中位数的比值")
    print("   (若第 1 次远大于 1，说明该 shape 触发了在线编译/tiling 计算)")
    print("=" * 78)
    fn = ops["mlp_up_proj"](1024)
    raw = time_op(fn, warmup=0, iters=60)
    steady = float(np.median(raw[-30:]))
    print(f"  稳态中位数 = {steady:.4f} ms")
    print("  前 12 次 / 稳态 : " + "  ".join(f"{v/steady:6.2f}" for v in raw[:12]))
    n_bad = int(np.argmax(raw / steady < 1.05)) if np.any(raw / steady < 1.05) else len(raw)
    print(f"  => 建议 warmup >= {max(n_bad + 5, 20)} 次")

    # ---------------- 噪声底 ----------------
    print()
    print("=" * 78)
    print("B. 噪声底标定 (同一 shape 重复测量)")
    print("=" * 78)
    print(f"{'op':16s} {'M':>6s} {'median(ms)':>11s} {'CV%':>7s} "
          f"{'p95/p50':>8s} {'batched(ms)':>12s} {'event开销占比':>14s}")
    print("-" * 78)
    noise = {}
    for M in (128, 1024, 4096):
        for name, mk in ops.items():
            f = mk(M)
            a = time_op(f, warmup=40, iters=args.iters)
            b = time_op_batched(f, warmup=20, reps=20, inner=20)
            s = stats(a)
            bm = float(np.median(b))
            overhead = (s["median"] - bm) / max(s["median"], 1e-12) * 100
            noise[f"{name}@{M}"] = s
            print(f"{name:16s} {M:6d} {s['median']:11.4f} {s['cv_pct']:7.2f} "
                  f"{s['p95']/max(s['median'],1e-12):8.3f} {bm:12.4f} {overhead:13.1f}%")
    print("-" * 78)
    cvs = [v["cv_pct"] for v in noise.values()]
    print(f"  噪声底 CV: 中位 {np.median(cvs):.2f}%  p90 {np.percentile(cvs,90):.2f}%  "
          f"最大 {np.max(cvs):.2f}%")
    print()
    print("  判读:")
    print("    * CV 中位 < 2%  -> 噪声可控, 后续观察到的跳变基本可认定为真台阶")
    print("    * CV 中位 > 5%  -> 先排查是否有别的进程抢占 NPU / 是否开了 profiling")
    print("    * event开销占比 > 20% 的算子, 其绝对值不可信, 只能看相对趋势")

    with open("out_env_probe.json", "w", encoding="utf-8") as fp:
        json.dump({"env": {**env_report(), **info}, "noise": noise}, fp,
                  ensure_ascii=False, indent=2)
    print("\n已写出 out_env_probe.json")


if __name__ == "__main__":
    main()

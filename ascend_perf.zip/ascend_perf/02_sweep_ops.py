# -*- coding: utf-8 -*-
"""
第 1 步：shape 扫描，产出 profiling CSV。

这是全套的核心数据采集。三种网格对应三个不同的问题：

  --grid vidur                Vidur 原样的 259 点网格 (>256 步长 32)
                              用途: 复现 "GPU 那套直接搬过来" 的效果
  --grid dense:960:1088       步长 1 的稠密扫描
                              用途: 直接看 shape ±1 到底抖多少 —— 这是判断
                                    "可不可学" 的决定性证据, Vidur 的网格看不到
  --grid win:512,1024,2048:16 在若干中心附近 ±16 稠密采样
                              用途: 边界对齐采样的雏形

--jit-compile 两种都跑一遍很重要: 它决定抖动是"在线编译开销"还是"tiling 分支切换"，
这两者的应对方式完全不同。

用法:
    # 先看抖动 (最重要, 5 分钟)
    python 02_sweep_ops.py --grid dense:960:1088 --tag dense_jitF --jit-compile 0
    python 02_sweep_ops.py --grid dense:960:1088 --tag dense_jitT --jit-compile 1

    # 再采 Vidur 网格 (给建模用)
    python 02_sweep_ops.py --grid vidur --tag vidur_jitF --jit-compile 0
"""
import argparse
import csv
import random
import os
import sys
import time

import numpy as np

from common import (DTYPES, MODEL_SPECS, build_ops, env_report, free_memory_gb,
                    grid_from_spec, setup_device, stats, time_op)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--device", type=int, default=0)
    ap.add_argument("--model", default="llama2-7b", choices=list(MODEL_SPECS))
    ap.add_argument("--tp", type=int, default=1)
    ap.add_argument("--dtype", default="fp16", choices=list(DTYPES))
    ap.add_argument("--grid", default="vidur",
                    help="vidur | dense:LO:HI[:STEP] | win:C1,C2:R | list:.. , 可用 + 连接")
    ap.add_argument("--max-tokens", type=int, default=4096)
    ap.add_argument("--iters", type=int, default=50)
    ap.add_argument("--warmup", type=int, default=30)
    ap.add_argument("--ops", default="", help="逗号分隔, 留空=全部")
    ap.add_argument("--jit-compile", type=int, default=-1,
                    help="0=关(二进制kernel) 1=开(在线编译) -1=不修改")
    ap.add_argument("--internal-format", type=int, default=-1,
                    help="0=禁止NZ 1=允许NZ -1=不修改")
    ap.add_argument("--tag", default="run")
    ap.add_argument("--out-dir", default="data")
    ap.add_argument("--min-free-gb", type=float, default=4.0,
                    help="剩余显存低于该值直接退出, 避免影响别人的进程")
    ap.add_argument("--order", default="random", choices=["random", "seq"],
                    help="扫描顺序。默认 random —— 按 M 顺序扫会把热漂移直接混叠到 M 轴上，"
                         "让温度效应伪装成 shape 结构（实测 CV 从 1.9%% 一路涨到 5.6%%）")
    ap.add_argument("--repeats", type=int, default=2,
                    help="交错重复趟数。每趟独立打乱顺序，结果写成不同 pass_id。"
                         "04_analyze.py 用它算可复现性 —— 这是判断测量有没有意义的前提")
    ap.add_argument("--cooldown-ms", type=float, default=0.0,
                    help="每个 shape 测完后空转等待，让器件回到相同热状态")
    ap.add_argument("--seed", type=int, default=0)
    args = ap.parse_args()

    jit = None if args.jit_compile < 0 else bool(args.jit_compile)
    fmt = None if args.internal_format < 0 else bool(args.internal_format)
    info = setup_device(args.device, jit_compile=jit, allow_internal_format=fmt)

    free = free_memory_gb(args.device)
    if free == free and free < args.min_free_gb:          # NaN-safe
        sys.exit(f"[ABORT] 卡 {args.device} 剩余显存仅 {free:.2f} GB "
                 f"(< --min-free-gb {args.min_free_gb})，为避免影响其他进程已退出。")

    spec = MODEL_SPECS[args.model]
    ops = build_ops(spec, tp=args.tp, dtype=DTYPES[args.dtype])
    if args.ops:
        want = [o.strip() for o in args.ops.split(",")]
        ops = {k: v for k, v in ops.items() if k in want}
        if not ops:
            sys.exit(f"[ABORT] --ops 没有匹配到任何算子，可选: {list(build_ops(spec).keys())}")

    grid = grid_from_spec(args.grid, args.max_tokens)
    os.makedirs(args.out_dir, exist_ok=True)
    out = os.path.join(args.out_dir, f"sweep_{args.model}_tp{args.tp}_{args.tag}.csv")

    print(f"模型={args.model} tp={args.tp} dtype={args.dtype}")
    print(f"jit_compile={info['jit_compile']}  internal_format={info['allow_internal_format']}")
    print(f"算子={list(ops)}")
    print(f"网格={args.grid} -> {len(grid)} 个点  [{grid[0]}, {grid[-1]}]")
    print(f"每点 warmup={args.warmup} iters={args.iters}")
    print(f"顺序={args.order}  交错重复={args.repeats} 趟  冷却={args.cooldown_ms} ms")
    print(f"输出 -> {out}")
    print(f"预计 {len(grid)*len(ops)*args.repeats*(args.warmup+args.iters)/2500/60:.1f} 分钟（粗估）")
    print()

    env = env_report()
    fields = ["model", "tp", "dtype", "op", "num_tokens", "jit_compile",
              "internal_format", "device_name", "pass_id", "order_idx", "t_rel_s",
              "min", "max", "mean", "median", "std", "p95", "cv_pct", "n"]

    rng = random.Random(args.seed)
    t0 = time.time()
    total = len(grid) * args.repeats
    done = 0
    with open(out, "w", newline="", encoding="utf-8") as fp:
        w = csv.DictWriter(fp, fieldnames=fields)
        w.writeheader()
        for p in range(args.repeats):
            # 每趟独立打乱。顺序扫描会把热漂移混叠到 M 轴上，
            # 让温度效应伪装成 shape 结构 —— 实测 CV 会随扫描进度从 1.9% 涨到 5.6%。
            order = list(grid)
            if args.order == "random":
                rng.shuffle(order)
            for k, M in enumerate(order):
                for name, mk in ops.items():
                    try:
                        fn = mk(M)
                        a = time_op(fn, warmup=args.warmup, iters=args.iters)
                    except Exception as e:                      # noqa: BLE001
                        print(f"  [skip] pass{p} {name} M={M}: {e}")
                        continue
                    row = dict(model=args.model, tp=args.tp, dtype=args.dtype, op=name,
                               num_tokens=M, jit_compile=info["jit_compile"],
                               internal_format=info["allow_internal_format"],
                               device_name=env.get("device_name", ""),
                               pass_id=p, order_idx=k,
                               t_rel_s=round(time.time() - t0, 3), **stats(a))
                    w.writerow(row)
                if args.cooldown_ms > 0:
                    time.sleep(args.cooldown_ms / 1000.0)
                done += 1
                if done % 20 == 0 or done == total:
                    fp.flush()
                    el = time.time() - t0
                    eta = el / done * (total - done)
                    print(f"  pass{p} {done:5d}/{total}  M={M:6d}  "
                          f"已用 {el/60:5.1f} min  剩余 ~{eta/60:5.1f} min")

    print(f"\n完成，用时 {(time.time()-t0)/60:.1f} min -> {out}")
    print()
    print("下一步（务必先看可复现性，再看任何结论）:")
    print(f"    python 04_analyze.py --csv {out}")


if __name__ == "__main__":
    main()

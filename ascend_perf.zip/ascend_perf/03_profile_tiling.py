# -*- coding: utf-8 -*-
"""
第 2 步（关键的"白盒"环节）：抓每个 shape 实际用到的 block_dim / kernel 名。

为什么重要（REPORT.md §3.2）：
  GPU 上 kernel 分支选择是闭源启发式，只能靠 probing 反推；
  昇腾上 tiling 是 host 侧确定性代码，其结果 (block_dim / kernel 二进制名)
  会出现在 profiler 输出里。所以我们**不需要学**分支，直接观测即可。

  一旦拿到 block_dim(M)，"抖动"就不再是玄学：
    * block_dim 变化的地方 = 分支边界 = 必须采样的点
    * block_dim 不变的区间内 = 可以安全插值的区间
    * 尾块占比 = (M mod tile) / tile, 其中 tile 可由 block_dim 反推

注意：profiler 输出格式随 CANN / torch_npu 版本变化较大，本脚本做了容错解析。
      如果解析失败，会把找到的 CSV 列名打出来，按提示改 --name-col 等参数即可。
      02 + 04 是核心，03 解析不出来不影响主结论。

用法:
    python 03_profile_tiling.py --grid dense:1000:1064 --model llama2-7b
"""
import argparse
import glob
import os
import re
import shutil
import sys

import numpy as np
import pandas as pd
import torch

from common import (DTYPES, MODEL_SPECS, build_ops, grid_from_spec, setup_device)

try:
    import torch_npu
except ImportError:
    sys.exit("[FATAL] 需要 torch_npu")


GEMM_OPS = ["attn_qkv_proj", "attn_o_proj", "mlp_up_proj", "mlp_down_proj"]


def make_profiler(out_dir):
    """构造 profiler，兼容多个 torch_npu 版本。

    注意：不传 schedule 时必须用显式 start()/stop()，否则 CANN 9.1 会报
    "Incorrect schedule: Stop profiler while current state is RECORD"，
    解析出来的数据可能不完整。
    """
    P = torch_npu.profiler
    kw = dict(activities=[P.ProfilerActivity.NPU],
              on_trace_ready=P.tensorboard_trace_handler(out_dir),
              record_shapes=True)
    try:
        kw["experimental_config"] = P._ExperimentalConfig(
            profiler_level=P.ProfilerLevel.Level1)
    except Exception:                                           # noqa: BLE001
        pass
    try:
        return P.profile(**kw)
    except TypeError:
        kw.pop("experimental_config", None)
        kw.pop("record_shapes", None)
        return P.profile(**kw)


# CANN 9.1 / torch_npu 2.10 的算子明细就是 ASCEND_PROFILER_OUTPUT/kernel_details.csv
PREFERRED = ("kernel_details.csv", "op_summary.csv", "task_time.csv")


def find_kernel_csv(root, verbose=False):
    """在 profiler 输出目录里找算子明细 CSV。

    先按文件名优先匹配（kernel_details.csv 等），再退回到"含 block dim 列"的启发式。
    verbose=True 时把所有候选文件的列名打出来，方便按实际版本调整。
    """
    allcsv = sorted(glob.glob(os.path.join(root, "**", "*.csv"), recursive=True))
    headers = {}
    for p in allcsv:
        try:
            headers[p] = pd.read_csv(p, nrows=1).columns.tolist()
        except Exception as e:                                  # noqa: BLE001
            headers[p] = [f"<读取失败: {e}>"]

    if verbose:
        print("\n[diag] profiler 输出里的 CSV 及其列名：")
        for p, cols in headers.items():
            print(f"    {os.path.basename(p)}")
            print(f"      {cols}")

    # 1) 按文件名优先
    for want in PREFERRED:
        for p, cols in headers.items():
            if os.path.basename(p) == want and cols and not str(cols[0]).startswith("<"):
                return [(p, cols)]
    # 2) 退回到列名启发式
    out = []
    for p, cols in headers.items():
        norm = [str(c).lower().replace(" ", "").replace("_", "") for c in cols]
        if any(k.startswith("blockdim") for k in norm):
            out.append((p, cols))
    return out


def pick(cols, *pats):
    norm = {c.lower().replace(" ", "").replace("_", ""): c for c in cols}
    for pat in pats:
        for k, orig in norm.items():
            if re.search(pat, k):
                return orig
    return None


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--device", type=int, default=0)
    ap.add_argument("--model", default="llama2-7b", choices=list(MODEL_SPECS))
    ap.add_argument("--tp", type=int, default=1)
    ap.add_argument("--dtype", default="fp16", choices=list(DTYPES))
    ap.add_argument("--grid", default="dense:1000:1064")
    ap.add_argument("--max-tokens", type=int, default=4096)
    ap.add_argument("--jit-compile", type=int, default=0)
    ap.add_argument("--prof-dir", default="prof_tmp")
    ap.add_argument("--out", default="data/tiling_blockdim.csv")
    ap.add_argument("--keep-prof", action="store_true",
                    help="保留 profiler 原始输出（默认跑完删掉，很占盘）")
    args = ap.parse_args()

    jit = None if args.jit_compile < 0 else bool(args.jit_compile)
    setup_device(args.device, jit_compile=jit)

    spec = MODEL_SPECS[args.model]
    all_ops = build_ops(spec, tp=args.tp, dtype=DTYPES[args.dtype])
    ops = {k: v for k, v in all_ops.items() if k in GEMM_OPS}
    grid = grid_from_spec(args.grid, args.max_tokens)

    print(f"对 {len(grid)} 个 shape × {len(ops)} 个 GEMM 算子逐个 profile")
    print(f"（每个 shape 一个独立 profiler session，保证归属无歧义）")

    if os.path.isdir(args.prof_dir):
        shutil.rmtree(args.prof_dir, ignore_errors=True)

    records = []
    op_names = list(ops)
    for i, M in enumerate(grid):
        fns = [ops[n](M) for n in op_names]
        for f in fns:                       # profiler 之外先 warmup，排掉编译
            for _ in range(20):
                f()
        torch.npu.synchronize()

        sub = os.path.join(args.prof_dir, f"M{M}")
        try:
            prof = make_profiler(sub)
            prof.start()                     # 显式 start/stop，避免 schedule 警告
            for f in fns:
                f()
                torch.npu.synchronize()
            prof.stop()
        except Exception as e:                                  # noqa: BLE001
            print(f"  [skip] M={M} profiler 失败: {e}")
            continue

        cands = find_kernel_csv(sub, verbose=(i == 0))
        if not cands:
            if i == 0:
                print("\n[WARN] 没找到可用的算子明细 CSV。上面已列出所有文件的列名，")
                print("       请把这段贴给我，我按实际列名调整。")
            continue

        path, cols = cands[0]
        df = pd.read_csv(path)
        c_name = pick(cols, r"^name$", r"opname", r"kernelname", r"^type$")
        c_bd = pick(cols, r"^blockdim", r"blockdim", r"^aicorenum", r"coredim")
        c_dur = pick(cols, r"duration", r"^time", r"aicoretime", r"taskduration")
        c_ts = pick(cols, r"starttime", r"^ts$", r"timestamp")
        c_shape = pick(cols, r"inputshapes", r"^shape")
        if i == 0:
            print(f"\n[diag] 使用 {os.path.basename(path)}，列映射：")
            print(f"    name={c_name}  block_dim={c_bd}  duration={c_dur}  "
                  f"ts={c_ts}  shapes={c_shape}")
        if c_name is None:
            if i == 0:
                print("[FAIL] 找不到算子名列，请把上面的列名贴给我。")
            continue
        if c_bd is None:
            if i == 0:
                print("[WARN] 该版本没有 block_dim 列 —— 仍会记录 kernel 名与耗时，")
                print("       分支检测将退化为'只看 kernel 名是否变化'。")
            df["_no_block_dim"] = -1
            c_bd = "_no_block_dim"

        d = df.copy()
        if c_ts is not None:
            d = d.sort_values(c_ts)
        # 只留矩阵乘类 kernel
        mask = d[c_name].astype(str).str.contains(
            "MatMul|Matmul|Gemm|BatchMatMul|MatMulV|Conv", case=False, na=False)
        d = d[mask]
        if len(d) == 0:
            d = df.copy()   # 兜底：不过滤

        for j, name in enumerate(op_names):
            if j >= len(d):
                break
            r = d.iloc[j]
            records.append(dict(
                num_tokens=M, op=name,
                kernel_name=str(r[c_name]),
                block_dim=r[c_bd],
                duration_us=r[c_dur] if c_dur else np.nan,
                input_shapes=str(r[c_shape]) if c_shape else "",
            ))

        if not args.keep_prof:
            shutil.rmtree(sub, ignore_errors=True)
        if (i + 1) % 10 == 0:
            print(f"  {i+1}/{len(grid)}  M={M}")

    if not records:
        sys.exit("\n[FAIL] 一条记录都没解析出来。请把 03 的输出贴给我。")

    os.makedirs(os.path.dirname(args.out) or ".", exist_ok=True)
    out = pd.DataFrame(records)
    out.to_csv(args.out, index=False)
    print(f"\n写出 {len(out)} 行 -> {args.out}")

    # ---------------- 分支边界检测 ----------------
    print()
    print("=" * 88)
    print("分支边界检测：block_dim / kernel 名 发生变化的 M")
    print("=" * 88)
    for name, g in out.groupby("op"):
        g = g.sort_values("num_tokens")
        bd = g.block_dim.values
        kn = g.kernel_name.values
        M = g.num_tokens.values
        ch = [(int(M[i]), bd[i - 1], bd[i], kn[i - 1] != kn[i])
              for i in range(1, len(g)) if bd[i] != bd[i - 1] or kn[i] != kn[i - 1]]
        print(f"\n--- {name}: {len(set(bd))} 种 block_dim, {len(set(kn))} 种 kernel, "
              f"{len(ch)} 处切换 ---")
        for m, a, b, kchg in ch[:25]:
            tag = "  [kernel也变了]" if kchg else ""
            print(f"    M={m:6d}   block_dim {a} -> {b}{tag}")
        if len(ch) > 25:
            print(f"    ... 还有 {len(ch)-25} 处")

    print()
    print("怎么用这张表:")
    print("  * 上面每个切换点，都要在 02_sweep_ops.py 里用 --grid win:<切换点列表>:2 补采")
    print("  * block_dim 不变的区间内部，才允许插值 / 拟合")
    print("  * 若某算子只有 1 种 block_dim 却仍然抖 -> 抖动来自尾块或格式转换，看 04 的输出")

    if not args.keep_prof:
        shutil.rmtree(args.prof_dir, ignore_errors=True)


if __name__ == "__main__":
    main()

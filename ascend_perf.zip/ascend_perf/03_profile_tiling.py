# -*- coding: utf-8 -*-
"""第 2 步（白盒环节）：抓每个 shape 实际用到的 tiling 分支 + AI-Core 流水线指标。

v4 —— 按 CANN 9.1 / torch_npu 2.10 真机的列名重写（v3 的 --dump-only 拿到了实况）：

  1) block_dim 这一列在这个版本叫 **Block Num**（不是 Block Dim）。v2 静默填了 -1，
     v3 会 FAIL 但还是匹配不上。现在两种名字都认。

  2) kernel_details.csv 的 `Name` 只是 aclnn API 名
     （aclnnMatmul_MatMulV3Common_MatMulV3），**对所有 shape 恒定**，
     用它做分支检测必然得出"1 种 kernel"。真正的 kernel 二进制名在
     task_time.csv 里：
         MatMulV3_ND_ND_ND_ND_FP16_FP16_FP16_FP16_high_performance_66
     末尾的模板后缀才是 tiling 分支标识。两张表按 (Stream ID, Task ID) join。

  3) kernel_details.csv 还带一整套 AI-Core 流水线指标，其中
     cube_utilization(%) 就是灰盒模型要学的那个有界利用率 eta ∈ (0,1]，
     aic_mac_ratio / aic_mte2_ratio 能直接区分"算不满"还是"搬不动"。
     全部抓下来 —— 台阶发生时到底是 cycles 变多还是利用率掉下去，一看便知。

  4) 算子归属按 Input Shapes 里的 (N,K) 精确匹配，不再靠行序。

  5) --repeats N：每个 M 采 N 次取中位数。单次采样在 M=932 造过一个 +55% 的
     假跳变（下一个点又 -55% 弹回来）。

用法:
    python 03_profile_tiling.py --dump-only            # 几秒，只产出列名诊断
    python 03_profile_tiling.py --grid dense:896:1152 --repeats 3
"""
import argparse
import glob
import os
import re
import shutil
import sys

import numpy as np
import pandas as pd
import torch

from common import (DTYPES, MODEL_SPECS, build_ops, grid_from_spec, setup_device)

try:
    import torch_npu
except ImportError:
    sys.exit("[FATAL] 需要 torch_npu")


GEMM_OPS = ["attn_qkv_proj", "attn_o_proj", "mlp_up_proj", "mlp_down_proj"]
DIAG = "data/prof_columns.txt"

# kernel_details.csv 里想要的流水线指标 -> 输出列名。存在即抓，缺了就留空。
METRICS = [
    (r"^aicoretime", "aicore_us"),
    (r"^aictotalcycles", "cycles"),
    (r"^aicmacratio", "mac_ratio"),
    (r"^aicmte1ratio", "mte1_ratio"),
    (r"^aicmte2ratio", "mte2_ratio"),
    (r"^aicfixpiperatio", "fixpipe_ratio"),
    (r"^aicscalarratio", "scalar_ratio"),
    (r"^aicicachemissrate", "icache_miss"),
    (r"^cubeutilization", "cube_util"),
]


def make_profiler(out_dir, log):
    """Level1 才有 aic_* 流水线指标；Level0 的 kernel_details.csv 连 Block Num 都没有。"""
    P = torch_npu.profiler
    kw = dict(activities=[P.ProfilerActivity.NPU],
              on_trace_ready=P.tensorboard_trace_handler(out_dir),
              record_shapes=True)
    exp = None
    for lvl in ("Level1", "Level2"):
        try:
            exp = P._ExperimentalConfig(profiler_level=getattr(P.ProfilerLevel, lvl))
            log("  [ok] experimental_config profiler_level=%s" % lvl)
            break
        except Exception as e:                                  # noqa: BLE001
            log("  [warn] profiler_level=%s 不可用: %s" % (lvl, e))
    if exp is not None:
        kw["experimental_config"] = exp
    else:
        log("  [WARN] experimental_config 不可用 —— 很可能落到 Level0，"
            "将拿不到 Block Num 和 aic_* 指标。")
    try:
        return P.profile(**kw)
    except TypeError as e:
        log("  [warn] profile(**kw) TypeError: %s，退化到最小参数集" % e)
        kw.pop("experimental_config", None)
        kw.pop("record_shapes", None)
        return P.profile(**kw)


def scan_csvs(root):
    info = []
    for p in sorted(glob.glob(os.path.join(root, "**", "*.csv"), recursive=True)):
        try:
            df = pd.read_csv(p, nrows=3)
            info.append((p, df.columns.tolist(), df))
        except Exception as e:                                  # noqa: BLE001
            info.append((p, ["<读取失败: %s>" % e], None))
    return info


def write_diag(info, path=DIAG):
    os.makedirs(os.path.dirname(path) or ".", exist_ok=True)
    with open(path, "w", encoding="utf-8") as f:
        for p, cols, df in info:
            f.write("### %s\n列名: %s\n" % (p, cols))
            if df is not None:
                f.write(df.to_string() + "\n")
            f.write("\n")
    return path


def pick(cols, *pats):
    norm = {str(c).lower().replace(" ", "").replace("_", "").replace("(", "")
            .replace(")", "").replace("%", ""): c for c in cols}
    for pat in pats:
        for k, orig in norm.items():
            if re.search(pat, k):
                return orig
    return None


def parse_shapes(s):
    """'"1024,4096;12288,4096"' -> (M, K, N)。解析不了返回 None。"""
    try:
        parts = str(s).strip().strip('"').split(";")
        a = [int(v) for v in parts[0].split(",")]
        b = [int(v) for v in parts[1].split(",")]
        return a[0], a[1], b[0]          # M, K, N
    except Exception:                                           # noqa: BLE001
        return None


def op_shape_map(ops, M):
    """{(N,K): op_name}。有冲突的 key 直接丢掉，退回行序。"""
    m, seen = {}, {}
    spec = getattr(op_shape_map, "_spec")
    h, f, hd, nq, nkv, tp = spec
    qkv_out = (nq // tp + 2 * max(nkv // tp, 1)) * hd
    want = {
        "attn_qkv_proj": (qkv_out, h),
        "attn_o_proj": (h, (nq // tp) * hd),
        "mlp_up_proj": (2 * (f // tp), h),
        "mlp_down_proj": (h, f // tp),
    }
    for name, key in want.items():
        if name not in ops:
            continue
        seen[key] = seen.get(key, 0) + 1
        m[key] = name
    for key, c in seen.items():
        if c > 1:
            m.pop(key, None)
    return m


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--device", type=int, default=0)
    ap.add_argument("--model", default="llama2-7b", choices=list(MODEL_SPECS))
    ap.add_argument("--tp", type=int, default=1)
    ap.add_argument("--dtype", default="fp16", choices=list(DTYPES))
    ap.add_argument("--grid", default="dense:896:1152")
    ap.add_argument("--max-tokens", type=int, default=4096)
    ap.add_argument("--jit-compile", type=int, default=0)
    ap.add_argument("--repeats", type=int, default=3)
    ap.add_argument("--prof-dir", default="prof_tmp")
    ap.add_argument("--out", default="data/tiling_blockdim.csv")
    ap.add_argument("--dump-only", action="store_true")
    ap.add_argument("--keep-prof", action="store_true")
    args = ap.parse_args()

    def log(*a):
        print(*a, flush=True)

    def quiet(*a):
        pass

    jit = None if args.jit_compile < 0 else bool(args.jit_compile)
    setup_device(args.device, jit_compile=jit)

    spec = MODEL_SPECS[args.model]
    ops = {k: v for k, v in build_ops(spec, tp=args.tp,
                                      dtype=DTYPES[args.dtype]).items()
           if k in GEMM_OPS}
    op_shape_map._spec = (spec["hidden"], spec["mlp_hidden"], spec["head_dim"],
                          spec["n_head"], spec["n_kv_head"], args.tp)
    NK2OP = op_shape_map(ops, 0)
    log("算子识别表 (N,K) -> op:")
    for k, v in sorted(NK2OP.items()):
        log("    N=%-6d K=%-6d  %s" % (k[0], k[1], v))

    grid = grid_from_spec(args.grid, args.max_tokens)
    if args.dump_only:
        grid = grid[len(grid) // 2: len(grid) // 2 + 1]
    log("对 %d 个 shape x %d 个 GEMM 逐个 profile（每 M 重复 %d 次取中位数）"
        % (len(grid), len(ops), args.repeats))

    if os.path.isdir(args.prof_dir):
        shutil.rmtree(args.prof_dir, ignore_errors=True)

    op_names = list(ops)
    cm = None
    records = []

    for i, M in enumerate(grid):
        fns = {n: ops[n](M) for n in op_names}
        for f in fns.values():
            for _ in range(20):
                f()
        torch.npu.synchronize()

        per_rep = {n: [] for n in op_names}
        for rep in range(args.repeats):
            sub = os.path.join(args.prof_dir, "M%d_r%d" % (M, rep))
            first = (i == 0 and rep == 0)
            try:
                prof = make_profiler(sub, log if first else quiet)
                prof.start()
                for n in op_names:
                    fns[n]()
                    torch.npu.synchronize()
                prof.stop()
            except Exception as e:                              # noqa: BLE001
                log("  [skip] M=%d rep=%d profiler 失败: %s" % (M, rep, e))
                continue

            info = scan_csvs(sub)
            kd = [p for p, _, _ in info
                  if os.path.basename(p) == "kernel_details.csv"]
            tt = [p for p, _, _ in info if os.path.basename(p) == "task_time.csv"]
            if not kd:
                if first:
                    write_diag(info)
                    sys.exit("\n[FAIL] 没有 kernel_details.csv。列名已写到 %s，请发我。" % DIAG)
                continue

            df = pd.read_csv(kd[0])
            if cm is None:
                write_diag(info)
                log("\n[diag] profiler 输出的 CSV 列名已写到 %s" % DIAG)
                cols = df.columns.tolist()
                cm = dict(
                    name=pick(cols, r"^name$"),
                    # CANN 9.1 叫 Block Num；老版本叫 Block Dim。别撞上 Mix Block Num。
                    bd=pick(cols, r"^blocknum$", r"^blockdim$", r"^blocknum",
                            r"^blockdim", r"^aicorenum"),
                    mixbd=pick(cols, r"^mixblocknum", r"^mixblockdim"),
                    dur=pick(cols, r"^durationus$", r"^duration"),
                    ts=pick(cols, r"^starttimeus$", r"starttime"),
                    shape=pick(cols, r"^inputshapes$", r"inputshapes"),
                    sid=pick(cols, r"^streamid$"),
                    tid=pick(cols, r"^taskid$"),
                    typ=pick(cols, r"^type$"),
                )
                for pat, out in METRICS:
                    cm[out] = pick(cols, pat)
                log("[diag] 列映射: block_dim=%s  dur=%s  shapes=%s  cube_util=%s"
                    % (cm["bd"], cm["dur"], cm["shape"], cm.get("cube_util")))
                if cm["bd"] is None:
                    sys.exit(
                        "\n[FAIL] kernel_details.csv 没有 Block Num / Block Dim 列。\n"
                        "       列名已写到 %s，请发我。多半是 profiler_level 落到了 "
                        "Level0。" % DIAG)
                if tt:
                    log("[diag] task_time.csv 存在 —— 会 join 出真正的 kernel 二进制名"
                        "（分支标识就在它的模板后缀里）")
                else:
                    log("[WARN] 没有 task_time.csv —— 只能用 aclnn API 名，"
                        "它对所有 shape 恒定，分支检测会退化。")

            # 真 kernel 名：task_time.csv 按 (stream_id, task_id) join
            binmap = {}
            if tt:
                try:
                    t = pd.read_csv(tt[0])
                    kn = pick(t.columns, r"^kernelname$")
                    ts_ = pick(t.columns, r"^streamid$")
                    tt_ = pick(t.columns, r"^taskid$")
                    if kn and ts_ and tt_:
                        for _, r in t.iterrows():
                            binmap[(int(r[ts_]), int(r[tt_]))] = str(r[kn])
                except Exception as e:                          # noqa: BLE001
                    if first:
                        log("  [warn] task_time.csv 解析失败: %s" % e)

            d = df.sort_values(cm["ts"]) if cm["ts"] else df
            if cm["typ"] is not None:
                d = d[d[cm["typ"]].astype(str).str.contains(
                    "MatMul|Gemm|BatchMatMul|Conv", case=False, na=False)]
            if len(d) == 0:
                continue

            used = set()
            for pos, (_, row) in enumerate(d.iterrows()):
                mkn = parse_shapes(row[cm["shape"]]) if cm["shape"] else None
                name = None
                if mkn is not None:
                    _, K, N = mkn
                    name = NK2OP.get((N, K))
                if name is None and pos < len(op_names):
                    name = op_names[pos]                    # 兜底：行序
                if name is None or name in used:
                    continue
                used.add(name)
                rec = dict(
                    block_dim=row[cm["bd"]],
                    mix_block_dim=row[cm["mixbd"]] if cm["mixbd"] else np.nan,
                    kernel_bin=binmap.get(
                        (int(row[cm["sid"]]), int(row[cm["tid"]])), "")
                    if (cm["sid"] and cm["tid"]) else "",
                    kernel_api=str(row[cm["name"]]) if cm["name"] else "",
                    duration_us=float(row[cm["dur"]]) if cm["dur"] else np.nan,
                    input_shapes=str(row[cm["shape"]]) if cm["shape"] else "",
                )
                for _, out in METRICS:
                    c = cm.get(out)
                    rec[out] = float(row[c]) if (c and pd.notna(row[c])) else np.nan
                per_rep[name].append(rec)

            if not args.keep_prof:
                shutil.rmtree(sub, ignore_errors=True)

        for n in op_names:
            rs = per_rep[n]
            if not rs:
                continue
            durs = [r["duration_us"] for r in rs]
            med = float(np.median(durs))
            out = dict(num_tokens=M, op=n,
                       block_dim=rs[0]["block_dim"],
                       mix_block_dim=rs[0]["mix_block_dim"],
                       kernel_bin=rs[0]["kernel_bin"],
                       kernel_api=rs[0]["kernel_api"],
                       duration_us=med,
                       duration_spread_pct=100.0 * (max(durs) - min(durs))
                       / max(med, 1e-9),
                       n_rep=len(rs),
                       input_shapes=rs[0]["input_shapes"])
            for _, k in METRICS:
                vals = [r[k] for r in rs if not np.isnan(r[k])]
                out[k] = float(np.median(vals)) if vals else np.nan
            records.append(out)

        if (i + 1) % 10 == 0:
            log("  %d/%d  M=%d" % (i + 1, len(grid), M))

    if args.dump_only:
        log("\n[dump-only] 诊断文件：%s" % DIAG)
        if records:
            r0 = records[0]
            log("[dump-only] 单点自检 M=%d %s: block_dim=%s  cube_util=%s"
                % (r0["num_tokens"], r0["op"], r0["block_dim"], r0.get("cube_util")))
            log("            kernel_bin=%s" % r0["kernel_bin"])
        return
    if not records:
        sys.exit("\n[FAIL] 一条记录都没解析出来。请把 %s 和上面的输出发我。" % DIAG)

    os.makedirs(os.path.dirname(args.out) or ".", exist_ok=True)
    out = pd.DataFrame(records)
    out.to_csv(args.out, index=False)
    log("\n写出 %d 行 -> %s" % (len(out), args.out))

    print()
    print("=" * 92)
    print("分支边界检测：block_dim / kernel 二进制名 发生变化的 M")
    print("=" * 92)
    for name, g in out.groupby("op"):
        g = g.sort_values("num_tokens")
        keys = list(zip(g.block_dim.values, g.kernel_bin.values))
        Mv = g.num_tokens.values
        ch = [(int(Mv[k]), keys[k - 1], keys[k]) for k in range(1, len(g))
              if keys[k] != keys[k - 1]]
        print("\n--- %s: %d 种 block_dim, %d 种 kernel 二进制, %d 处切换 ---"
              % (name, len(set(g.block_dim)), len(set(g.kernel_bin)), len(ch)))
        for m, a, b in ch[:25]:
            print("    M=%6d   block_dim %s -> %s" % (m, a[0], b[0]))
            if a[1] != b[1]:
                print("               kernel  %s\n                    ->  %s" % (a[1], b[1]))
        if len(ch) > 25:
            print("    ... 还有 %d 处" % (len(ch) - 25))
        print("    每 M 重复采样极差中位 = %.2f%%（profiler 采样噪声底，跳变要大过它）"
              % g.duration_spread_pct.median())
        if "cube_util" in g and g.cube_util.notna().any():
            print("    cube_utilization: 中位 %.2f%%  最低 %.2f%% @ M=%d  最高 %.2f%%"
                  % (g.cube_util.median(), g.cube_util.min(),
                     int(g.loc[g.cube_util.idxmin(), "num_tokens"]),
                     g.cube_util.max()))

    # 利用率是有界量 —— 台阶到底是"多干了活"还是"利用率掉了"，这里直接分开
    if "cube_util" in out and out.cube_util.notna().any():
        print()
        print("=" * 92)
        print("台阶归因：跨过边界时，是 cycles 变多，还是 cube 利用率掉下去？")
        print("=" * 92)
        print("  %-16s %10s %12s %12s %12s" %
              ("op", "M", "duration Δ", "cycles Δ", "cube_util Δ"))
        print("  " + "-" * 66)
        for name, g in out.groupby("op"):
            g = g.sort_values("num_tokens").reset_index(drop=True)
            d = g.duration_us.pct_change() * 100
            sig = np.nanstd(np.diff(d.values[1:], 1)) or 1.0
            for k in np.argsort(-np.abs(d.values))[:3]:
                if not np.isfinite(d.values[k]) or abs(d.values[k]) < 3:
                    continue
                cy = (g.cycles[k] / g.cycles[k - 1] - 1) * 100 if "cycles" in g else np.nan
                cu = g.cube_util[k] - g.cube_util[k - 1]
                print("  %-16s %10d %11.1f%% %11.1f%% %11.2fpt"
                      % (name, int(g.num_tokens[k]), d.values[k], cy, cu))
        print()
        print("  cycles 涨而 cube_util 基本不动 -> 真的多做了一块计算（tile/波量化）")
        print("  cycles 不动而 cube_util 掉     -> 同样的活干得更慢（尾块空转/搬运受阻），")
        print("                                    这时该建模的是 eta，不是时延本身")

    print()
    print("怎么用这张表:")
    print("  * 每个切换点 C，用 --grid win:C1,C2,...:2 补采")
    print("  * 只在切换点之间插值 / 拟合")
    print("  * 若只有 1 种 block_dim 却仍有台阶 -> 波量化 / 尾块，看 04 的 C 段")

    if not args.keep_prof:
        shutil.rmtree(args.prof_dir, ignore_errors=True)


if __name__ == "__main__":
    main()

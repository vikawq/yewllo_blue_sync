# -*- coding: utf-8 -*-
"""第 2 步（白盒环节）：抓每个 shape 实际用到的 block_dim / kernel / tiling 信息。

v3 改动（上一轮真机跑完后发现的问题）：
  * 上一轮 1028 行 block_dim 全是 -1 —— 不是 block_dim 不变，是**根本没解析到**。
    旧脚本在找不到列时静默填 -1，而 04 的 G 段又把它当成「0 处切换」来解释，
    于是得出了「block_dim 完全解释不了抖动」这个假结论。现在改成：
      - 找不到 block_dim 列就直接 FAIL 退出，并把所有 CSV 的列名 + 样例行
        写到 data/prof_columns.txt，不再产出会被误读的表。
      - 显式打印 experimental_config 是否生效。Level0 的 kernel_details.csv
        没有 Block Dim 列，这是最可能的原因。
  * 按 Input Shapes 匹配算子，不再靠 d.iloc[j] 的行序猜。
  * --repeats N：每个 M 采 N 次取中位数。上一轮单次采样在 M=932 造出了一个
    +55% 的假跳变（下一个点又 -55% 回来），单点离群会被误判成台阶。
  * 顺带记录 TilingKey / aicore_time 等「存在即抓」的列。

用法:
    python 03_profile_tiling.py --dump-only            # 几秒钟，只产出列名诊断文件
    python 03_profile_tiling.py --grid dense:896:1152 --repeats 3
"""
import argparse
import glob
import os
import re
import shutil
import sys

import numpy as np
import pandas as pd
import torch

from common import (DTYPES, MODEL_SPECS, build_ops, grid_from_spec, setup_device)

try:
    import torch_npu
except ImportError:
    sys.exit("[FATAL] 需要 torch_npu")


GEMM_OPS = ["attn_qkv_proj", "attn_o_proj", "mlp_up_proj", "mlp_down_proj"]
DIAG = "data/prof_columns.txt"
PREFERRED = ("kernel_details.csv", "op_summary.csv", "task_time.csv")


def make_profiler(out_dir, log):
    """构造 profiler。Level0 的 kernel_details.csv 没有 Block Dim 列，
    所以 experimental_config 是否生效必须显式报出来，不能静默吞掉。"""
    P = torch_npu.profiler
    kw = dict(activities=[P.ProfilerActivity.NPU],
              on_trace_ready=P.tensorboard_trace_handler(out_dir),
              record_shapes=True)
    exp = None
    for lvl in ("Level2", "Level1"):
        try:
            exp = P._ExperimentalConfig(profiler_level=getattr(P.ProfilerLevel, lvl))
            log(f"  [ok] experimental_config profiler_level={lvl}")
            break
        except Exception as e:                                  # noqa: BLE001
            log(f"  [warn] profiler_level={lvl} 不可用: {e}")
    if exp is not None:
        kw["experimental_config"] = exp
    else:
        log("  [WARN] experimental_config 不可用 —— 很可能落到 Level0，"
            "kernel_details.csv 将不含 Block Dim 列。")
    try:
        return P.profile(**kw)
    except TypeError as e:
        log(f"  [warn] profile(**kw) TypeError: {e}，退化到最小参数集")
        kw.pop("experimental_config", None)
        kw.pop("record_shapes", None)
        return P.profile(**kw)


def scan_csvs(root):
    """列出 profiler 输出里所有 CSV 的列名与样例行。"""
    info = []
    for p in sorted(glob.glob(os.path.join(root, "**", "*.csv"), recursive=True)):
        try:
            df = pd.read_csv(p, nrows=3)
            info.append((p, df.columns.tolist(), df))
        except Exception as e:                                  # noqa: BLE001
            info.append((p, ["<读取失败: %s>" % e], None))
    return info


def write_diag(info, path=DIAG):
    os.makedirs(os.path.dirname(path) or ".", exist_ok=True)
    with open(path, "w", encoding="utf-8") as f:
        for p, cols, df in info:
            f.write("### %s\n列名: %s\n" % (p, cols))
            if df is not None:
                f.write(df.to_string() + "\n")
            f.write("\n")
    return path


def pick(cols, *pats):
    norm = {str(c).lower().replace(" ", "").replace("_", ""): c for c in cols}
    for pat in pats:
        for k, orig in norm.items():
            if re.search(pat, k):
                return orig
    return None


def choose_table(info):
    """挑一张既有算子名、又有 block_dim 的表；带 block_dim 的优先。"""
    scored = []
    for p, cols, df in info:
        if df is None:
            continue
        name = pick(cols, r"^name$", r"opname", r"kernelname", r"^type$")
        bd = pick(cols, r"^blockdim$", r"^blockdim", r"blockdim",
                  r"^aicorenum", r"coredim")
        if name is None:
            continue
        base = os.path.basename(p)
        pref = PREFERRED.index(base) if base in PREFERRED else 9
        scored.append(((0 if bd else 1, pref), p, cols))
    if not scored:
        return None, None
    scored.sort(key=lambda x: x[0])
    return scored[0][1], scored[0][2]


def colmap(cols):
    return dict(
        name=pick(cols, r"^name$", r"opname", r"kernelname", r"^type$"),
        bd=pick(cols, r"^blockdim$", r"^blockdim", r"blockdim",
                r"^aicorenum", r"coredim"),
        dur=pick(cols, r"^duration", r"duration", r"^time", r"aicoretime"),
        ts=pick(cols, r"starttime", r"^ts$", r"timestamp"),
        shape=pick(cols, r"^inputshapes", r"inputshapes", r"^shape"),
        tk=pick(cols, r"tilingkey", r"^tiling"),
    )


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--device", type=int, default=0)
    ap.add_argument("--model", default="llama2-7b", choices=list(MODEL_SPECS))
    ap.add_argument("--tp", type=int, default=1)
    ap.add_argument("--dtype", default="fp16", choices=list(DTYPES))
    ap.add_argument("--grid", default="dense:896:1152")
    ap.add_argument("--max-tokens", type=int, default=4096)
    ap.add_argument("--jit-compile", type=int, default=0)
    ap.add_argument("--repeats", type=int, default=3,
                    help="每个 M 采几次取中位数；单次采样会被单点离群骗到")
    ap.add_argument("--prof-dir", default="prof_tmp")
    ap.add_argument("--out", default="data/tiling_blockdim.csv")
    ap.add_argument("--dump-only", action="store_true",
                    help="只 profile 一个 shape，产出列名诊断文件后退出（几秒钟）")
    ap.add_argument("--keep-prof", action="store_true")
    args = ap.parse_args()

    def log(*a):
        print(*a, flush=True)

    def quiet(*a):
        pass

    jit = None if args.jit_compile < 0 else bool(args.jit_compile)
    setup_device(args.device, jit_compile=jit)

    spec = MODEL_SPECS[args.model]
    ops = {k: v for k, v in build_ops(spec, tp=args.tp,
                                      dtype=DTYPES[args.dtype]).items()
           if k in GEMM_OPS}
    grid = grid_from_spec(args.grid, args.max_tokens)
    if args.dump_only:
        grid = grid[len(grid) // 2: len(grid) // 2 + 1]

    log("对 %d 个 shape x %d 个 GEMM 逐个 profile（每 M 重复 %d 次取中位数）"
        % (len(grid), len(ops), args.repeats))

    if os.path.isdir(args.prof_dir):
        shutil.rmtree(args.prof_dir, ignore_errors=True)

    op_names = list(ops)
    table_base = None
    cm = None
    records = []

    for i, M in enumerate(grid):
        fns = {n: ops[n](M) for n in op_names}
        for f in fns.values():
            for _ in range(20):
                f()
        torch.npu.synchronize()

        per_rep = {n: [] for n in op_names}
        for rep in range(args.repeats):
            sub = os.path.join(args.prof_dir, "M%d_r%d" % (M, rep))
            first = (i == 0 and rep == 0)
            try:
                prof = make_profiler(sub, log if first else quiet)
                prof.start()
                for n in op_names:
                    fns[n]()
                    torch.npu.synchronize()
                prof.stop()
            except Exception as e:                              # noqa: BLE001
                log("  [skip] M=%d rep=%d profiler 失败: %s" % (M, rep, e))
                continue

            info = scan_csvs(sub)
            if table_base is None:
                d = write_diag(info)
                log("\n[diag] profiler 输出的 CSV 列名已写到 %s" % d)
                for p, c, _ in info:
                    log("    %-28s %s" % (os.path.basename(p), c))
                path, cols = choose_table(info)
                if path is None:
                    sys.exit("\n[FAIL] 没有一张表带算子名列。请把 %s 发我。" % DIAG)
                table_base = os.path.basename(path)
                cm = colmap(cols)
                log("\n[diag] 选用 %s" % table_base)
                log("[diag] 列映射: %s" % cm)
                if cm["bd"] is None:
                    sys.exit(
                        "\n[FAIL] 这张表没有 block_dim 列。上一轮就是卡在这里，"
                        "而旧脚本会静默填 -1，\n"
                        "       让 04 的 G 段得出「0 处切换」的假结论。\n"
                        "       所有 CSV 的列名与样例行已写到 %s，请把它发我。\n"
                        "       最可能的原因是 profiler_level 落到了 Level0"
                        "（上面有提示），\n"
                        "       或该 CANN 版本把 Block Dim 放在 op_summary.csv 里。"
                        % DIAG)

            cur = [p for p, _, _ in info if os.path.basename(p) == table_base]
            if not cur:
                continue
            df = pd.read_csv(cur[0])
            d = df.sort_values(cm["ts"]) if cm["ts"] else df.copy()
            d = d[d[cm["name"]].astype(str).str.contains(
                "MatMul|Matmul|Gemm|BatchMatMul|Conv", case=False, na=False)]
            if len(d) == 0:
                continue
            # 优先按 Input Shapes 里的 M 维匹配，匹配不到才退回行序
            if cm["shape"]:
                d = d[d[cm["shape"]].astype(str).str.contains(
                    "%d," % M, regex=False)] if any(
                    d[cm["shape"]].astype(str).str.contains(
                        "%d," % M, regex=False)) else d
            for j, n in enumerate(op_names):
                if j >= len(d):
                    break
                row = d.iloc[j]
                per_rep[n].append(dict(
                    kernel_name=str(row[cm["name"]]),
                    block_dim=row[cm["bd"]],
                    duration_us=float(row[cm["dur"]]) if cm["dur"] else np.nan,
                    tiling_key=str(row[cm["tk"]]) if cm["tk"] else "",
                    input_shapes=str(row[cm["shape"]]) if cm["shape"] else "",
                ))
            if not args.keep_prof:
                shutil.rmtree(sub, ignore_errors=True)

        for n in op_names:
            rs = per_rep[n]
            if not rs:
                continue
            durs = [r["duration_us"] for r in rs]
            med = float(np.median(durs))
            records.append(dict(
                num_tokens=M, op=n,
                kernel_name=rs[0]["kernel_name"],
                block_dim=rs[0]["block_dim"],
                tiling_key=rs[0]["tiling_key"],
                duration_us=med,
                duration_spread_pct=100.0 * (max(durs) - min(durs)) / max(med, 1e-9),
                n_rep=len(rs),
                input_shapes=rs[0]["input_shapes"],
            ))
        if (i + 1) % 10 == 0:
            log("  %d/%d  M=%d" % (i + 1, len(grid), M))

    if args.dump_only:
        log("\n[dump-only] 诊断文件已写出：%s。把它发我即可。" % DIAG)
        return
    if not records:
        sys.exit("\n[FAIL] 一条记录都没解析出来。请把 %s 和上面的输出发我。" % DIAG)

    os.makedirs(os.path.dirname(args.out) or ".", exist_ok=True)
    out = pd.DataFrame(records)
    out.to_csv(args.out, index=False)
    log("\n写出 %d 行 -> %s" % (len(out), args.out))

    if (out.block_dim.astype(str) == "-1").mean() > 0.5:
        log("\n[FAIL] block_dim 仍有一半以上是 -1，下面的切换点不可信。"
            "请把 %s 发我。" % DIAG)
        return

    print()
    print("=" * 88)
    print("分支边界检测：block_dim / kernel 名 / TilingKey 发生变化的 M")
    print("=" * 88)
    for name, g in out.groupby("op"):
        g = g.sort_values("num_tokens")
        keys = list(zip(g.block_dim.values, g.kernel_name.values, g.tiling_key.values))
        M = g.num_tokens.values
        ch = [(int(M[k]), keys[k - 1], keys[k]) for k in range(1, len(g))
              if keys[k] != keys[k - 1]]
        print("\n--- %s: %d 种 block_dim, %d 种 kernel, %d 种 TilingKey, %d 处切换 ---"
              % (name, len(set(g.block_dim)), len(set(g.kernel_name)),
                 len(set(g.tiling_key)), len(ch)))
        for m, a, b in ch[:25]:
            print("    M=%6d   %s -> %s" % (m, a, b))
        if len(ch) > 25:
            print("    ... 还有 %d 处" % (len(ch) - 25))
        print("    每 M 重复采样的极差中位数 = %.2f%%（这是 profiler 采样噪声底，"
              "跳变要比它大才算数）" % g.duration_spread_pct.median())

    print()
    print("怎么用这张表:")
    print("  * 每个切换点 C，用 --grid win:C1,C2,...:2 补采")
    print("  * 只在切换点之间插值 / 拟合")
    print("  * 若只有 1 种 block_dim 却仍有台阶 -> 是波量化 / 尾块，看 04 的 C 段")

    if not args.keep_prof:
        shutil.rmtree(args.prof_dir, ignore_errors=True)


if __name__ == "__main__":
    main()

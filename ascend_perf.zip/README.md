# 昇腾 NPU 算子性能可学习性诊断

配套 `../REPORT.md`。目的是先回答一个前置问题——**"shape 抖动到底是什么性质"**——
再决定要不要、以及怎么把 Vidur 那套搬到昇腾上。所以这批脚本是**诊断**，不是建模。

## 为什么不能直接抄 Vidur

在 A100/H100/A40 的真实数据上实测（`../analysis/`）：

| 场景 | Vidur 的随机森林 | 2~3 参数的解析式 |
|---|---|---|
| 域内插值 | **3.08%** | 7.50% |
| 域外外推 | **31.83%**（最差 39%） | **5.38%** |

Vidur 的 RF 是**曲线加密器**，不是预测器——只在 profiling 网格的凸包内有效。
它的采样网格是 [1,4096] 上 259 点，>256 后步长固定 32，**看不到 shape ±1 的跳变**。
GPU 上这样可行，是因为分支边界规则（实测全部落在 mod 128）且稀疏；
昇腾上分支由 `TilingKey` 决定，更密更不规则，照抄一定失准。

## 依赖

服务器上应已有 `torch` + `torch_npu`（CANN 环境）。额外只需要：

```bash
pip install numpy pandas scikit-learn
source /usr/local/Ascend/ascend-toolkit/set_env.sh
```

## 一键跑

```bash
bash run_all.sh 0 llama2-7b          # 参数: 设备号 模型名
DENSE=dense:2000:2128 bash run_all.sh 0 llama2-70b   # 换稠密窗口
```

约 30–60 分钟。**只用一张卡，不修改任何全局配置，不 kill 任何进程**；
`02_sweep_ops.py` 在剩余显存不足 4GB 时会主动退出（`--min-free-gb` 可调）。

## 分步跑

```bash
# 0. 环境自检 + 噪声底标定（必做，5 分钟）
python 01_probe_env.py --device 0 --model llama2-7b

# 1. 步长 1 的稠密扫描 —— 判断"可不可学"的决定性数据
#    --order random 和 --repeats 2 是必须的，别省
python 02_sweep_ops.py --grid dense:960:1088 --tag dense_jitOFF --jit-compile 0                        --order random --repeats 2 --cooldown-ms 100
python 02_sweep_ops.py --grid dense:960:1088 --tag dense_jitON  --jit-compile 1                        --order random --repeats 2 --cooldown-ms 100

# 1b. 先过闸门！不合格就别往下采
python 04_analyze.py --csv data/sweep_llama2-7b_tp1_dense_jitOFF.csv --skip A,B,C,D,E

# 2. Vidur 网格 —— 给建模对比用
python 02_sweep_ops.py --grid vidur --tag vidur_jitOFF --jit-compile 0                        --order random --repeats 2

# 3. 抓 block_dim（白盒环节，best effort）
python 03_profile_tiling.py --grid dense:1000:1064 --jit-compile 0

# 4. 分析
python 04_analyze.py --csv data/sweep_llama2-7b_tp1_dense_jitOFF.csv \
                     --csv2 data/sweep_llama2-7b_tp1_dense_jitON.csv \
                     --tiling data/tiling_blockdim.csv
python 04_analyze.py --csv data/sweep_llama2-7b_tp1_vidur_jitOFF.csv --skip B,E

# 若两份 CSV 是设置完全相同的重复测量（而非 jit 对照），加 --replicate 做交叉复现性检验
python 04_analyze.py --csv a.csv --csv2 b.csv --replicate --skip A,B,C,D,E
```

## 找边界：06_scan_boundaries.py

台阶的位置**不能算**，只能测：mod 256 那一层是先验，但实测约 0.75 道/周期的边界
既不对齐模数、又在各算子间共享、幅度还比 mod-256 那道更大（M=1844 是 +7.0%，
同周期的 1793 只有 +4.6~6.0%）。所以采样器是一步到位的全域搜索，
mod 256 只当作"这些位置必然有边界"的先验塞进粗网格，省掉发现它们的开销。

```bash
python 06_scan_boundaries.py --device 1 --model llama2-7b --tp 1 --dtype bf16 \
    --ops attn_qkv_proj,attn_o_proj,mlp_up_proj,mlp_down_proj \
    --lo 1 --hi 4096 --coarse 32 --tag full
```

三个阶段：粗扫（每 32 个 M 一点）→ 对"两端电平对不上"的区间二分（log2(32)=5 次定位到 ±0）
→ 每个候选点做持续性确认。**第三步不能省**：实测某些 M 上四个算子同时多出一个固定
~70 us 的每次调用开销，下一格立刻回落，不做确认会把边界数多报 10 倍。

离线自检（不碰设备，拿已有的 dense 数据当预言机，顺便评估表的精度）：

```bash
python 06_scan_boundaries.py --replay ../result_0908/digest.json \
    --replay-sweep sweep_llama2-7b_tp1_wide_1024_2048.csv \
    --ops attn_qkv_proj,attn_o_proj,mlp_up_proj,mlp_down_proj --lo 1024 --hi 2048
```

在四份干净数据上回放的结果（对全部 M 预测，真值里的单点尖峰不计入）：

| 数据 | 实测点/全测 | 查表 MAPE | max | 等预算均匀网格 max | Vidur 32 点 max |
|---|---|---|---|---|---|
| bf16 [1792,2048] | 20 / 257 (7.8%) | 0.20~0.31% | 0.95~1.34% | 4.5~5.4% | 4.3~5.2% |
| bf16 [2048,2304] | 31 / 257 (12%) | 0.11~0.19% | 0.61~1.43% | 2.0~5.0% | 2.2~4.9% |
| fp32 [1792,2048] | 20 / 257 (7.8%) | 0.15~0.27% | 1.37~3.65% | 6.1% | 5.8% |
| bf16 [1920,2176] | 33 / 257 (13%) | 0.02~0.12% | 0.18~0.97% | 1.9~4.7% | 1.7~3.2% |

## 脚本职责

| 脚本 | 干什么 | 关键产出 |
|---|---|---|
| `common.py` | 设备/算子/计时/网格 | —— |
| `01_probe_env.py` | warmup 收敛性 + **噪声底 CV** | 误差下界，后续所有判据的标尺 |
| `02_sweep_ops.py` | shape 扫描 | `data/sweep_*.csv` |
| `03_profile_tiling.py` | 抓 `block_dim`(=Block Num) / kernel 二进制名 / AI-Core 流水线指标 | `data/tiling_blockdim.csv`，含 `cube_utilization` |
| `04_analyze.py` | R + A–H 九段分析 | 结论（R 是闸门，先看它）+ `data/cost_table.csv` |
| `05_digest.py` | 把全部数据压成一个可回传的小文件 | `data/digest.json.gz`（原始 CSV 的 1/46）+ 一段可粘贴的摘要 |
| `06_scan_boundaries.py` | **全域台阶搜索**：粗扫 + 二分 + 持续性确认，只测 8~15% 的点就定位出全部边界 | `data/boundaries_*.json` + 可直接喂给 02 的 `--grid list:...` |
| `00_check_scripts.py` | 静态自检：每个 `args.X` 都注册过、`main()` 的局部名没泄漏到模块级 | 退出码（两次线上崩溃都是这两类） |

`04_analyze.py` 的九段：

- **R 可复现性闸门** → 测量本身有没有意义（**先看这个**）
- **A 抖动幅度 vs 噪声底** → 抖动是真信号还是噪声
- **B 台阶模数检验** → 台阶位置是否解析可推（需 step=1 数据）
- **C 尾块占比** → 该用什么特征
- **D RF / 多项式 / 灰盒，内插 & 外推** → 该用什么模型
- **E Vidur 32 步网格漏采率** → 该怎么采样
- **F jit_compile 开/关** → 抖动来自在线编译还是 tiling 分支
- **G 时延跳变 vs block_dim 切换** → 抖动能否被分支切换解释
  （G2 用 profiler 纯 kernel 耗时交叉验证墙钟；G3 报有界利用率 η = `cube_utilization`）
- **H 量化粒度辨识 + 分段常数成本表** → **最终产出**：每段只需实测 1 个点的查找表

## 怎么读结果（决策树）

**第 0 步永远是 R 段（可复现性闸门）。** 首轮实测的教训：噪声底最高到 19% CV，
两次独立测量的残差相关性只有 r=0.17~0.46，不可复现量比可复现量大 2~30 倍——
在那种数据上 A/B/C/D/E 段看到的一切"台阶"都是幻觉。
R 段报"测量不合格"时，唯一该做的事是修测量，不是解读结果。

再看 **F**：

- **jitON 抖动 >> jitOFF** → 抖动主要来自在线编译。部署时关掉 `jit_compile`，
  建模只针对 `jit_compile=False`，问题大幅简化。
- **两者接近** → 抖动来自 tiling 分支本身，继续往下看。

再看 **A**（必须有 step=1 数据）。**看 `max` 和 `>4σ 个数`，不要看 p95** ——
真台阶是稀疏的，257 个间隔里只有 3~5 个是真边界，p95 根本扫不到它们
（有一轮就因为只报 p95/噪声=1.66，漏判了 M=1024→1025 处 +8%~+18% 的真台阶）：

- **没有 >4σ 跳变** → 本窗口内光滑，可直接插值。
- **少数几个（<10）大跳变** → 离散边界稀疏 → 边界对齐采样，边界之间才允许插值。
  实测昇腾就是这一档。
- **>4σ 跳变占间隔数 >20%** → 分支密集 → 禁止跨 shape 插值。

然后看 **G** 和 **C** 定位抖动来源：

- G 的"跳变被解释率"高 → 直接按 block_dim 分段，问题解决。
- G 低但 C 的降幅 > 20% → 抖动来自**尾块**，把 `tail = (-M) mod tile` 加成特征即可。
- 两者都低 → 还有隐藏分支（格式转换 / 流水线），需要更细的 profiling。

最后看 **H**，它把上面这些变成能直接用的东西：辨识出 M 方向的量化粒度 T，
再找出 T 之外的第二层断点，输出一张分段常数表（每段实测 1 个点）。
实测 M∈[896,1152] 上 58 个采样点覆盖 1028 个 shape，MAPE 0.28%。

**T 不是算子的常数** —— 它同时依赖 (N, K) 和 M 的量级。实测同样四个算子
在 M≈1000 与 M≈2000 两个窗口上的 T 全部不同（16/16/32/64 → 64/32/256/64），
所以换窗口必须重新辨识，不能沿用。

**D** 用来验证：如果外推 RF 也像 GPU 那样崩到 30%（实测 vidur 全域网格上
内插 2.0% / 外推 25.9%），就确认了"RF 只能当曲线加密器"这一点。

## 数据怎么回传

原始 CSV 一轮约 3 MB，从机器上拷出来往往不方便。`run_all.sh` 最后会跑 `05_digest.py`，
产出两样东西，按方便程度三选一：

| 方式 | 内容 | 大小 |
|---|---|---|
| A 贴文本 | `logs/06_digest.log` 里 `### ASCEND-DIGEST` 到 `### END` 之间 | ~90 行 |
| B 传文件 | `data/digest.json.gz` | ~70 KB（原始的 1/46） |
| C 原始数据 | `tar czf result.tgz logs data/*.csv out_env_probe.json` | ~3 MB |

拿到 B 之后用 `python 04_analyze.py --digest data/digest.json.gz` 全量复算。
摘要按奇偶两组存（所以 R 段恒显示 2 趟），其余各段用单独存的全趟聚合值，
与原始 CSV 逐点一致 —— 实测四个 GEMM 的 T、断点、段数、MAPE 全部逐字相同。

## 几个容易踩的坑

- **按 M 顺序扫描**：任何随时间变化的干扰（热漂移、别的进程上卡）都会被
  直接混叠到 M 轴上，制造出"大 M 处有巨大台阶"的假象。02 和 03 现在默认
  `--order random` + 交错多趟。有一轮 03 漏了这条，报出 `cube_utilization`
  掉到 45%、duration 翻倍，位置全部落在 M 轴最后 7~12% —— 全是假的。
- **卡被别人用**：判据是 `median/min`。被分时占用时 `min` 与独占时相差 <4%，
  是 `median` 被拉高到 1.13~3.2 倍；热漂移则是两者一起抬高、比值不变。
  04 会直接报"抢卡告警"。救援手段是 `--stat min`。
- **锚点归一不是无条件的好**：锚点只用 10 次快测，卡被抢时它自己的中位数
  会摆动 2 倍以上，除以它等于**注入**噪声。实测同一份数据：
  `median`+锚点 10.1% → `min`+锚点 9.2% → `min` 不归一 **0.27%**。
  所以 `--stat min` 会自动关掉锚点归一。

- **warmup 不够**：昇腾首次遇到新 shape 会算 tiling / 取 kernel 二进制，
  第一次调用可能比稳态慢一个数量级。`01` 会告诉你需要多少次。
- **Event 开销**：小算子（norm/add）单次只有几十微秒，NPU Event 开销不可忽略。
  `01` 会打印"event开销占比"，超过 20% 的算子只能看相对趋势，绝对值不可信。
- **别的进程在抢卡**：会把噪声底抬到 5% 以上，所有台阶判据失效。先看 `01` 的 CV。
- **dense 窗口太窄**：`04` 的 B 段模数检验需要窗口里有 **至少 4 个真边界**，
  否则会提示"样本太少不可信"。tile 若是 256，窗口至少要 1000+ 宽。
- **按 M 顺序扫描**（v1 的 bug，已修）：热漂移会被直接混叠到 M 轴上，
  伪装成 shape 结构。实测 attn_qkv_proj 的 CV 随扫描进度从 1.86% 涨到 5.61%。
  现在 `--order random` 是默认值，别改回 `seq`。
- **别人的进程在用同一张卡**：会把噪声底抬高一个数量级。`run_all.sh` 开头会跑
  `npu-smi info` 让你确认。

## 跑完请回传

```
logs/*.log
data/sweep_*.csv
data/tiling_blockdim.csv     # 03 成功的话
out_env_probe.json
```

`03` 如果报"没找到含 Block Dim 列的 CSV"，把它打印出的文件列表一起发过来，
profiler 输出格式随 CANN 版本变化，我按实际列名改解析。

---

## v3 变更（第二轮实测后修正）

第二轮（`REPEATS=3`，随机顺序）的闸门报"2/7 可用"，但对照 `01` 的噪声底可以看出
**不是硬件的问题，是闸门判据和计时方法的问题**：

| op | 结构 s% | 噪声 n% | Event 开销占比 | 真实结论 |
|---|---|---|---|---|
| mlp_up_proj | 2.0 | 0.7 | 2.2% | 有结构，可建模 |
| mlp_down_proj | 2.5 | 1.2 | 3.7% | 有结构，可建模 |
| attn_o_proj | 3.9 | 2.5 | 9.1% | 有结构，可建模 |
| attn_qkv_proj | 1.3 | 1.1 | 4.0% | 结构弱但真实 |
| mlp_act | ~0 | 2.5 | 12.7% | **测得干净，本来就光滑** |
| rms_norm | ~0 | 10.7 | 33.3% | 测不动（计时开销） |
| add | ~0 | 9.7 | 70.5% | 测不动（计时开销） |

四条修正：

1. **`sec_R` 的信号幅度算错了。** `r` 是**方差**占比，原代码直接用 `rep = r * tot`，
   应该是 `s = tot * sqrt(r)`，干净算子的结构幅度被低估了约 30%。
2. **`r >= 0.7` 不是测量质量的判据。** 对本来就光滑的算子（mlp_act），无论测得多准
   `r` 都上不去 —— r≈0 是**正确答案**而不是故障。新判据改成看不可复现噪声 `n` 的绝对值，
   并把结果分成三类：`结构显著` / `干净但光滑` / `测不动`。
3. **小算子必须换计时方法。** Event 计时有约 0.01~0.03 ms 固定开销，对 add(0.027 ms)
   占 70%、rms_norm(0.087 ms) 占 33%。闸门里"不可用"的三个算子恰好就是开销最大的三个。
   新增 `--timing auto`：单次 < 0.15 ms 的算子自动改用打包计时。
   模式**按算子固定、不随 M 变**，否则模式切换会在 M 轴上造出一个假台阶。
4. **噪声是慢变共模项，加 iters 没用。** 实测不可复现噪声是"批内 50 次调用互相独立"
   所预测值的 **4~10 倍** —— 说明同一次访问里的 50 次调用是**相关的**（共同的时钟/温度/
   功耗状态）。新增 `--anchor 1024`：每测一个 M 之前先快测一次锚点 shape，
   `04` 用 `median/anchor_ms` 扣掉共模漂移。开销约 +20%。

另外：
* 默认窗口从 `dense:960:1088` 加宽到 `dense:896:1152`（跨 896/1024/1152 三个 mod-128
  边界）。上一轮只含 1024 一个边界，B 段只检出 2 个跳变点，模数检验样本不足。
* `run_all.sh` 开头回显生效配置，并对 `COOLDOWWN=` 这类环境变量笔误报警
  （打错不会报错，只会静默用默认值）。
* `GATE_ONLY=1` 只跑到闸门为止（约 5 分钟），用来快速确认协议是否修好。

推荐重跑：

```bash
GATE_ONLY=1 bash run_all.sh 1 llama2-7b     # 先 5 分钟确认闸门过了
bash run_all.sh 1 llama2-7b                 # 再跑完整流程
```

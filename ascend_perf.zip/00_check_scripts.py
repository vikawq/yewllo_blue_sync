# -*- coding: utf-8 -*-
"""静态检查：每个被引用的 args.X 都必须在 add_argument 里注册过。

两次栽在这上面（--force 只引用没注册、闸门写在 main() 外面），
所以把它变成一个能跑的检查，而不是"下次记得看"。
"""
import ast, glob, io, sys

bad = 0
for path in sorted(glob.glob("*.py")):
    tree = ast.parse(io.open(path, encoding="utf-8").read(), path)

    declared = set()
    for node in ast.walk(tree):
        if (isinstance(node, ast.Call) and isinstance(node.func, ast.Attribute)
                and node.func.attr == "add_argument"):
            for a in node.args:
                if isinstance(a, ast.Constant) and isinstance(a.value, str) \
                        and a.value.startswith("--"):
                    declared.add(a.value[2:].replace("-", "_"))
            for kw in node.keywords:                     # dest="..." 覆盖默认名
                if kw.arg == "dest" and isinstance(kw.value, ast.Constant):
                    declared.add(kw.value.value)

    used = {}
    for node in ast.walk(tree):
        if isinstance(node, ast.Attribute) and isinstance(node.value, ast.Name) \
                and node.value.id == "args":
            used.setdefault(node.attr, node.lineno)

    if not declared and not used:
        continue
    missing = {k: v for k, v in used.items() if k not in declared}
    if missing:
        bad += 1
        for k, ln in sorted(missing.items(), key=lambda t: t[1]):
            print(f"  [MISSING] {path}:{ln}  引用了 args.{k}，但没有 add_argument")
    else:
        print(f"  [ok] {path:24s} {len(used)} 个 args.* 全部注册过"
              f"（声明 {len(declared)} 个）")

    # 顺带查一类相关的坑：main() 的局部名被写在模块级
    fnames = {n.name for n in tree.body if isinstance(n, ast.FunctionDef)}
    if "main" in fnames:
        local = set()
        for n in tree.body:
            if isinstance(n, ast.FunctionDef) and n.name == "main":
                for x in ast.walk(n):
                    if isinstance(x, ast.Name) and isinstance(x.ctx, ast.Store):
                        local.add(x.id)
        top = set()
        for n in tree.body:
            if isinstance(n, (ast.Assign, ast.FunctionDef, ast.ClassDef,
                              ast.Import, ast.ImportFrom)):
                continue
            for x in ast.walk(n):
                if isinstance(x, ast.Name) and isinstance(x.ctx, ast.Load):
                    top.add(x.id)
        leak = sorted((top & local) - {"main"})
        if leak:
            bad += 1
            print(f"  [LEAK] {path}: 模块级用到了 main() 的局部名 {leak}")

sys.exit(1 if bad else 0)

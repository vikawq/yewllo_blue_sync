# Copyright (c) 2026, Huawei Technologies Co., Ltd.  All rights reserved.
# Copyright (c) 2022-2026, NVIDIA CORPORATION & AFFILIATES. All rights reserved.

import triton
import triton.language as tl

if hasattr(tl, "get_element"):
    get_element = tl.get_element
else:
    from triton.language.extra.cann.extension import get_element


@triton.autotune(
    configs=[
        triton.Config({"SUB_BLOCK_SIZE": 8}),
        triton.Config({"SUB_BLOCK_SIZE": 16}),
        triton.Config({"SUB_BLOCK_SIZE": 32}),
        triton.Config({"SUB_BLOCK_SIZE": 64}),
        triton.Config({"SUB_BLOCK_SIZE": 128}),
        triton.Config({"SUB_BLOCK_SIZE": 256}),
        triton.Config({"SUB_BLOCK_SIZE": 512}),
        triton.Config({"SUB_BLOCK_SIZE": 1024}),
    ],
    key=["num_splits"],
)
@triton.jit
def _make_chunk_sort_map_kernel(
    split_sizes_ptr,
    cumsum_ptr,
    inverse_sorted_indices_ptr,
    output_cumsum_ptr,
    dst_rows_ptr,
    num_splits,
    num_tokens,
    BLOCK_SIZE: int,
    SUB_BLOCK_SIZE: tl.constexpr,
    IDX_LOAD_WIDTH: tl.constexpr,
):
    pid = tl.program_id(0)

    load_split_offset = tl.arange(0, IDX_LOAD_WIDTH)
    input_split_sizes = tl.load(split_sizes_ptr + load_split_offset, mask=load_split_offset < num_splits, other=0).to(
        tl.float32
    )
    input_split_sizes_cumsum = tl.cumsum(input_split_sizes)

    for off in range(0, BLOCK_SIZE, SUB_BLOCK_SIZE):
        token_offsets = pid * BLOCK_SIZE + off + tl.arange(0, SUB_BLOCK_SIZE)
        token_offsets_cmp = token_offsets.to(tl.float32)

        input_split_sizes_mask = tl.where(input_split_sizes_cumsum[None, :] <= token_offsets_cmp[:, None], 1, 0)
        input_chunk_indices = tl.sum(input_split_sizes_mask, axis=-1)
        cumsum_mask = input_chunk_indices < (num_splits + 1)
        input_split_sizes_presums = tl.load(cumsum_ptr + input_chunk_indices, mask=cumsum_mask, other=0)

        inv_mask = input_chunk_indices < num_splits
        output_chunk_indices = tl.load(inverse_sorted_indices_ptr + input_chunk_indices, mask=inv_mask, other=0)

        output_chunk_mask = output_chunk_indices < (num_splits + 1)
        output_presums = tl.load(output_cumsum_ptr + output_chunk_indices, mask=output_chunk_mask, other=0)

        dst_rows = output_presums + token_offsets_cmp - input_split_sizes_presums
        store_mask = token_offsets < num_tokens
        tl.store(dst_rows_ptr + token_offsets, dst_rows, mask=store_mask)


@triton.jit
def _sort_chunks_by_map_kernel(
    input_ptr,
    output_ptr,
    row_id_map_ptr,
    probs_ptr,
    permuted_probs_ptr,
    num_tokens: int,
    hidden_size: tl.constexpr,
    block_size: int,
    stride_input_token,
    stride_input_hidden,
    stride_output_token,
    stride_output_hidden,
    stride_probs_token,
    stride_permuted_probs_token,
    PERMUTE_PROBS: tl.constexpr,
    FORWARD: tl.constexpr,
    BLOCK_TOKENS: tl.constexpr,
):
    pid = tl.program_id(0)
    pid_start = pid * block_size

    map_offsets = tl.arange(0, BLOCK_TOKENS)
    map_mask = (map_offsets < block_size) & (pid_start + map_offsets < num_tokens)
    row_id_map_block = tl.load(row_id_map_ptr + pid_start + map_offsets, mask=map_mask, other=0).to(tl.int64)

    hidden_offsets = tl.arange(0, hidden_size)
    for token_offset in range(0, BLOCK_TOKENS):
        i = pid_start + token_offset
        if token_offset < block_size and i < num_tokens:
            mapped_row = get_element(row_id_map_block, (token_offset,)).to(tl.int64)
            if FORWARD:
                src_row = i
                dst_row = mapped_row
            else:
                src_row = mapped_row
                dst_row = i

            input_offsets = src_row * stride_input_token + hidden_offsets * stride_input_hidden
            output_offsets = dst_row * stride_output_token + hidden_offsets * stride_output_hidden
            inp = tl.load(input_ptr + input_offsets)
            tl.store(output_ptr + output_offsets, inp)

            if PERMUTE_PROBS:
                prob_off = src_row * stride_probs_token
                permuted_prob_off = dst_row * stride_permuted_probs_token
                prob = tl.load(probs_ptr + prob_off)
                tl.store(permuted_probs_ptr + permuted_prob_off, prob)

def is_arch35() -> bool:
    return False

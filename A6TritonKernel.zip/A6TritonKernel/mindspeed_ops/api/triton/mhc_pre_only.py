import torch
import torch_npu

from mindspeed_ops.utils import is_arch35

if not is_arch35():
    from mindspeed_ops.arch32.triton.mhc.pre_bmm import hc_pre_bmm_forward, hc_pre_bmm_backward
    from mindspeed_ops.arch32.triton.mhc.pre_only import hc_pre_only_fwd, hc_pre_only_bwd
else:
    raise NotImplementedError("this op is not supported in this platform")


class MHCPreOnlyTriton(torch.autograd.Function):
    @staticmethod
    def forward(
        ctx,
        x: torch.Tensor,
        weight: torch.Tensor,
        branch_alpha: torch.Tensor,
        branch_beta: torch.Tensor,
        norm_gamma: torch.Tensor,
        mhc_use_gamma: bool = True,
        num_stream: int = 4,
        eps: float = 1e-6,
        recompute_info=None,
    ):
        if recompute_info is not None:
            ctx.need_recompute = True
        else:
            ctx.need_recompute = False

        B, S, nD = x.shape
        dtype = x.dtype
        x = x.float()
        if recompute_info:
            recompute_info.only_h_pre_input_fp32 = x.detach()

        weight = weight.float().t()
        branch_alpha = branch_alpha.float()
        branch_beta = branch_beta.float()

        x_flat = x.reshape(-1, nD)  # [B*S, nD]
        if not mhc_use_gamma:
            norm_gamma = torch.ones(nD, device=x.device, dtype=torch.float32)
        else:
            norm_gamma = norm_gamma.float()
        x_norm_flat, rstd = torch_npu.npu_rms_norm(x_flat, gamma=norm_gamma, epsilon=eps)
        x_norm_mat = x_norm_flat.reshape(B, S, nD)
        x_proj = torch.matmul(x_norm_mat, weight)
        h_pre = hc_pre_only_fwd(
            mixes=x_proj,
            hc_scale=branch_alpha,
            hc_base=branch_beta,
            hc_mult=num_stream,
            eps=eps,
            group=48,
        )

        x_unflatten = x.unflatten(dim=-1, sizes=(num_stream, -1))
        y = hc_pre_bmm_forward(h_pre, x_unflatten)
        y = y.to(dtype)
        if recompute_info:
            recompute_info.only_h_pre = h_pre.detach()
            recompute_info.only_h_pre_out = y.detach()
        if ctx.need_recompute:
            ctx.save_for_backward(x, weight, branch_alpha, branch_beta, norm_gamma, x_proj, h_pre)
        else:
            # Save for backward
            ctx.save_for_backward(
                x_flat, x_norm_flat, rstd, x_proj, weight, branch_alpha, branch_beta, h_pre, x_unflatten, norm_gamma
            )
        ctx.mhc_use_gamma = mhc_use_gamma
        ctx.num_stream = num_stream
        ctx.eps = eps
        ctx.B, ctx.S, ctx.nD = B, S, nD

        return y, h_pre

    @staticmethod
    def backward(ctx, grad_y, grad_h_pre):
        if grad_h_pre.abs().sum() != 0:
            raise ValueError(
                "The forward output h_pre is only used as an input parameter for hc_pre_bmm_backward, grad_h_pre should be an all-zero tensor"
            )
        mhc_use_gamma = ctx.mhc_use_gamma
        B, S, nD = ctx.B, ctx.S, ctx.nD
        if ctx.need_recompute:
            (x, weight, branch_alpha, branch_beta, norm_gamma, x_proj, h_pre) = ctx.saved_tensors
            x_flat = x.reshape(-1, nD)
            x_norm_flat, rstd = torch_npu.npu_rms_norm(x_flat, gamma=norm_gamma, epsilon=ctx.eps)
            x_unflatten = x.unflatten(dim=-1, sizes=(ctx.num_stream, -1))
        else:
            (x_flat, x_norm_flat, rstd, x_proj, weight, branch_alpha, branch_beta, h_pre, x_unflatten, norm_gamma) = (
                ctx.saved_tensors
            )

        grad_h_pre, grad_x_direct = hc_pre_bmm_backward(h_pre, x_unflatten, grad_y)

        grad_x_proj, grad_branch_alpha, grad_branch_beta = hc_pre_only_bwd(
            grad_pre=grad_h_pre,
            mixes=x_proj,
            hc_scale=branch_alpha,
            hc_base=branch_beta,
        )

        grad_weight = None
        if ctx.needs_input_grad[1]:
            grad_weight = torch.matmul(x_norm_flat.t(), grad_x_proj.reshape(-1, branch_beta.shape[-1]))

        grad_x_norm_mat = torch.matmul(grad_x_proj, weight.t())  # [B, S, nD]

        grad_x_rms_flat, grad_gamma = torch_npu.npu_rms_norm_backward(
            grad_x_norm_mat.view(-1, nD), x_flat, norm_gamma, rstd
        )
        if not mhc_use_gamma:
            grad_gamma = None

        grad_x_rms = grad_x_rms_flat.view(B, S, nD)  # [B, S, nD]

        grad_x = grad_x_direct.view(B, S, nD) + grad_x_rms  # [B, S, nD]
        grads = [grad_x, grad_weight.t(), grad_branch_alpha, grad_branch_beta, grad_gamma, None, None, None, None]

        return tuple(grads)


def mhc_pre_only_triton(
    x: torch.Tensor,
    weight: torch.Tensor,
    branch_alpha: torch.Tensor,
    branch_beta: torch.Tensor,
    norm_gamma: torch.Tensor,
    mhc_use_gamma: bool = True,
    num_stream: int = 4,
    eps: float = 1e-6,
    recompute_info=None,
):
    """MHC pre-only operation with autograd support.

    Computes the pre-only step for MHC (Manifold-Constrained Hyper-Connections),
    which performs RMS normalization, linear projection, head coefficient computation,
    and the pre-bmm multiplication in a single differentiable pass.

    Args:
        x: Input tensor of shape (B, S, nD), where nD = num_stream * D.
        weight: Projection weight of shape (nD, num_stream).
        branch_alpha: Scale coefficients of shape (B, S, num_stream).
        branch_beta: Base coefficients of shape (B, S, num_stream).
        norm_gamma: RMS norm gamma of shape (nD,).
        mhc_use_gamma: Whether to apply gamma in RMS norm. Defaults to True.
        num_stream: Number of streams (must divide nD). Defaults to 4.
        eps: Epsilon for RMS norm. Defaults to 1e-6.
        recompute_info: Optional recompute info for gradient checkpointing.

    Returns:
        Tuple of (y, h_pre):
            y: Output tensor of shape (B, S, D).
            h_pre: Head coefficients tensor of shape (B, S, num_stream).
    """
    return MHCPreOnlyTriton.apply(
        x,
        weight,
        branch_alpha,
        branch_beta,
        norm_gamma,
        mhc_use_gamma,
        num_stream,
        eps,
        recompute_info,
    )

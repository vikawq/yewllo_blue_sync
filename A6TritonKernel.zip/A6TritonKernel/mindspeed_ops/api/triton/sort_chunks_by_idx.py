# Copyright (c) 2026, Huawei Technologies Co., Ltd.  All rights reserved.
# Copyright (c) 2022-2026, NVIDIA CORPORATION & AFFILIATES. All rights reserved.

from typing import Tuple

import torch
import triton

from mindspeed_ops.arch32.triton.sort_chunks_by_idx import (
    _make_chunk_sort_map_kernel,
    _sort_chunks_by_map_kernel,
)
from mindspeed_ops.api.triton.utils import get_vector_num


def make_chunk_sort_map(
    split_sizes: torch.Tensor,
    sorted_indices: torch.Tensor,
    num_tokens: int,
    num_splits: int,
) -> torch.Tensor:
    """
    Make a row id map for chunk sort.

    Args:
        split_sizes: Chunk sizes with shape [num_splits].
        sorted_indices: Chunk indices used to permute chunks, with shape [num_splits].
        num_tokens: Number of input tokens.
        num_splits: Number of chunks.
    """
    if num_tokens <= 0:
        return torch.empty((num_tokens,), dtype=torch.int32, device=split_sizes.device)

    row_id_map = torch.empty((num_tokens,), dtype=torch.int32, device=split_sizes.device)
    num_blocks = min(get_vector_num(), num_tokens)
    block_size = triton.cdiv(num_tokens, num_blocks)
    grid = (num_blocks, 1, 1)

    cumsum = torch.empty(split_sizes.size(0) + 1, dtype=torch.int32, device=split_sizes.device)
    cumsum[0] = 0
    cumsum[1:] = split_sizes.cumsum(dim=0, dtype=torch.int32)

    inverse_sorted_indices = torch.empty(num_splits, dtype=torch.int32, device=split_sizes.device)
    inverse_sorted_indices.scatter_(
        dim=0,
        index=sorted_indices,
        src=torch.arange(num_splits, dtype=torch.int32, device=split_sizes.device),
    )

    output_split_sizes = split_sizes[sorted_indices]
    output_cumsum = torch.empty(split_sizes.size(0) + 1, dtype=torch.int32, device=split_sizes.device)
    output_cumsum[0] = 0
    output_cumsum[1:] = output_split_sizes.cumsum(dim=0, dtype=torch.int32)

    _make_chunk_sort_map_kernel[grid](
        split_sizes,
        cumsum,
        inverse_sorted_indices,
        output_cumsum,
        row_id_map,
        num_splits,
        num_tokens,
        block_size,
        IDX_LOAD_WIDTH=triton.next_power_of_2(num_splits),
    )
    return row_id_map


def sort_chunks_by_map(
    inp: torch.Tensor,
    row_id_map: torch.Tensor,
    probs: torch.Tensor | None,
    num_tokens: int,
    hidden_size: int,
    is_forward: bool,
) -> Tuple[torch.Tensor, torch.Tensor | None]:
    """
    Sort chunks with row_id_map.

    Args:
        inp: Input tensor with shape [num_tokens, hidden_size].
        row_id_map: Destination row map with shape [num_tokens].
        probs: Optional probabilities with shape [num_tokens].
        num_tokens: Number of tokens in the input tensor.
        hidden_size: Hidden size of the input tensor.
        is_forward: Whether the sort is for forward or backward.
    """
    output = torch.empty((num_tokens, hidden_size), dtype=inp.dtype, device=inp.device)
    if probs is not None:
        permuted_probs = torch.empty((num_tokens,), dtype=probs.dtype, device=probs.device)
    else:
        permuted_probs = None

    if num_tokens == 0:
        return output, permuted_probs

    num_blocks = min(get_vector_num(), num_tokens)
    block_size = triton.cdiv(num_tokens, num_blocks)
    block_tokens = triton.next_power_of_2(block_size)
    grid = (num_blocks, 1, 1)
    _sort_chunks_by_map_kernel[grid](
        inp,
        output,
        row_id_map,
        probs,
        permuted_probs,
        num_tokens,
        hidden_size,
        block_size,
        inp.stride(0),
        inp.stride(1),
        output.stride(0),
        output.stride(1),
        probs.stride(0) if probs is not None else None,
        permuted_probs.stride(0) if permuted_probs is not None else None,
        PERMUTE_PROBS=probs is not None,
        FORWARD=is_forward,
        BLOCK_TOKENS=block_tokens,
    )

    return output, permuted_probs


class _MoeChunkSort(torch.autograd.Function):
    @staticmethod
    def forward(
        ctx,
        inp: torch.Tensor,
        split_sizes: torch.Tensor,
        sorted_idxs: torch.Tensor,
        probs: torch.Tensor | None,
    ) -> Tuple[torch.Tensor, torch.Tensor | None]:
        ctx.set_materialize_grads(False)
        if not inp.numel():
            return inp, probs

        num_tokens = inp.shape[0]
        num_splits = split_sizes.size(0)
        if num_splits != sorted_idxs.size(0):
            raise ValueError("sorted_idxs size is not equal to num_splits.")

        for tensor in (inp, split_sizes, sorted_idxs):
            if tensor.device.type != "npu":
                raise RuntimeError("This operation needs NPU")
        if probs is not None and probs.device.type != "npu":
            raise RuntimeError("This operation needs NPU")
        if probs is not None and probs.dtype != inp.dtype:
            raise ValueError("probs dtype should be the same as inp dtype.")

        num_tokens, hidden_size = inp.shape
        row_id_map = make_chunk_sort_map(split_sizes, sorted_idxs, num_tokens, num_splits)
        output, permuted_probs = sort_chunks_by_map(
            inp,
            row_id_map,
            probs,
            num_tokens,
            hidden_size,
            is_forward=True,
        )

        ctx.row_id_map = row_id_map
        ctx.num_tokens = num_tokens
        ctx.hidden_size = hidden_size
        return output, permuted_probs

    @staticmethod
    def backward(
        ctx,
        permuted_act_grad: torch.Tensor,
        permuted_probs_grad: torch.Tensor | None,
    ) -> Tuple[torch.Tensor | None, None, None, torch.Tensor | None]:
        if permuted_act_grad is None and permuted_probs_grad is None:
            return None, None, None, None

        if permuted_act_grad is not None and not permuted_act_grad.numel():
            return permuted_act_grad, None, None, permuted_probs_grad

        act_grad = None
        probs_grad = None
        if ctx.needs_input_grad[0] and permuted_act_grad is not None:
            act_grad, probs_grad = sort_chunks_by_map(
                permuted_act_grad,
                ctx.row_id_map,
                permuted_probs_grad,
                ctx.num_tokens,
                ctx.hidden_size,
                is_forward=False,
            )
        elif ctx.needs_input_grad[3] and permuted_probs_grad is not None:
            dummy_act_grad = permuted_probs_grad.reshape(ctx.num_tokens, 1)
            _, probs_grad = sort_chunks_by_map(
                dummy_act_grad,
                ctx.row_id_map,
                permuted_probs_grad,
                ctx.num_tokens,
                1,
                is_forward=False,
            )
        if not ctx.needs_input_grad[0]:
            act_grad = None
        if not ctx.needs_input_grad[3]:
            probs_grad = None
        return act_grad, None, None, probs_grad


def moe_sort_chunks_by_index(
    inp: torch.Tensor,
    split_sizes: torch.Tensor,
    sorted_index: torch.Tensor,
) -> torch.Tensor:
    """
    Split inp on dim 0 according to split_sizes and concatenate chunks in sorted_index order.
    """
    output, _ = _MoeChunkSort.apply(inp, split_sizes, sorted_index, None)
    return output


def moe_sort_chunks_by_index_with_probs(
    inp: torch.Tensor,
    probs: torch.Tensor,
    split_sizes: torch.Tensor,
    sorted_index: torch.Tensor,
) -> Tuple[torch.Tensor, torch.Tensor]:
    """
    Split inp and probs on dim 0 according to split_sizes and concatenate chunks in sorted_index order.
    """
    output, permuted_probs = _MoeChunkSort.apply(inp, split_sizes, sorted_index, probs)
    return output, permuted_probs

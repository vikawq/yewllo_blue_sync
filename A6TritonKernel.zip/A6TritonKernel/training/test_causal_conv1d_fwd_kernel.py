import os
import sys
import types
import importlib.util

os.environ.setdefault("TRITON_BACKENDS_IN_TREE", "1")
os.environ.setdefault("TRITON_BACKEND", "opentile")
os.environ.setdefault("TRITON_ALWAYS_COMPILE", "1")

BASE = os.path.dirname(os.path.abspath(__file__))
for p in (BASE, os.path.join(BASE, "practice"), os.path.join(BASE, "practice_stub")):
    if p not in sys.path:
        sys.path.insert(0, p)

import triton

_orig_autotune = triton.autotune


def _fast_autotune(configs, key=None, prune_configs_by=None, reset_to_zero=None,
                   do_bench=None, **kwargs):
    configs = list(configs)
    if configs and prune_configs_by is None:
        configs = configs[:1]
    return _orig_autotune(configs, key=key, prune_configs_by=prune_configs_by,
                          reset_to_zero=reset_to_zero,
                          do_bench=(lambda *a, **kw: 1.0), **kwargs)


triton.autotune = _fast_autotune

import numpy as np
import torch
import torch.nn.functional as F

if not (hasattr(torch, "npu") and torch.npu.is_available()):
    raise RuntimeError("no NPU device available")

PRACTICE = os.path.join(BASE, "practice")
spec = importlib.util.spec_from_file_location("trn_ops", os.path.join(PRACTICE, "ops.py"))
ops_mod = importlib.util.module_from_spec(spec)
sys.modules[spec.name] = ops_mod
spec.loader.exec_module(ops_mod)

causal_conv1d_fwd = ops_mod.causal_conv1d_fwd


def ref_conv1d_fwd(x, weight, bias, activation=None):
    B, T, D = x.shape
    W = weight.shape[1]
    y = torch.zeros(B, T, D, dtype=torch.float32)
    for b in range(B):
        for t in range(T):
            for c in range(W):
                ti = t + c - (W - 1)
                if ti < 0 or ti >= T:
                    continue
                y[b, t] += weight[:, c] * x[b, ti]
    if bias is not None:
        y += bias
    if activation in ("swish", "silu"):
        y = y * torch.sigmoid(y)
    return y


def run_case(name, x, weight, bias, activation):
    dev = x.device
    y, fs = causal_conv1d_fwd(x, weight, bias, residual=None, initial_state=None,
                              output_final_state=False, activation=activation)
    torch.npu.synchronize()
    got = y.cpu().float()
    exp = ref_conv1d_fwd(x.cpu().float(), weight.cpu().float(),
                         bias.cpu().float(), activation)
    ok = torch.allclose(got, exp, atol=1e-2, rtol=1e-2)
    print(f"[{'PASS' if ok else 'FAIL'}] {name}: x={tuple(x.shape)} W={weight.shape[1]} act={activation}")
    if not ok:
        d = (got - exp).abs()
        print(f"  max_diff={d.max().item():.6f} (at {np.unravel_index(d.argmax().item(), d.shape)})")
    return ok


def test_causal_conv1d_fwd():
    dev = torch.device("npu", torch.npu.current_device())
    ok = True
    torch.manual_seed(3)
    B, T, D, W = 2, 128, 16, 4
    x = torch.randn(B, T, D, dtype=torch.float16, device=dev) * 0.5
    weight = torch.randn(D, W, dtype=torch.float16, device=dev) * 0.5
    bias = torch.randn(D, dtype=torch.float16, device=dev) * 0.1
    ok &= run_case("basic-w4", x, weight, bias, None)
    torch.manual_seed(3)
    B, T, D, W = 1, 64, 32, 3
    x = torch.randn(B, T, D, dtype=torch.float16, device=dev) * 0.5
    weight = torch.randn(D, W, dtype=torch.float16, device=dev) * 0.5
    bias = torch.randn(D, dtype=torch.float16, device=dev) * 0.1
    ok &= run_case("basic-w3", x, weight, bias, None)
    torch.manual_seed(3)
    B, T, D, W = 2, 64, 8, 5
    x = torch.randn(B, T, D, dtype=torch.float16, device=dev) * 0.5
    weight = torch.randn(D, W, dtype=torch.float16, device=dev) * 0.5
    bias = torch.randn(D, dtype=torch.float16, device=dev) * 0.1
    ok &= run_case("swish-w5", x, weight, bias, "silu")
    assert ok, "causal_conv1d_fwd FAILED"
    print("[ALL PASS] causal_conv1d_fwd")


if __name__ == "__main__":
    test_causal_conv1d_fwd()

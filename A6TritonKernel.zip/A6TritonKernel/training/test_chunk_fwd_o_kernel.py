import os
import sys
import types
import importlib.util

os.environ.setdefault("TRITON_BACKENDS_IN_TREE", "1")
os.environ.setdefault("TRITON_BACKEND", "opentile")
os.environ.setdefault("TRITON_ALWAYS_COMPILE", "1")

BASE = os.path.dirname(os.path.abspath(__file__))
for p in (BASE, os.path.join(BASE, "practice"), os.path.join(BASE, "practice_stub")):
    if p not in sys.path:
        sys.path.insert(0, p)

import triton

_orig_autotune = triton.autotune


def _fast_autotune(configs, key=None, prune_configs_by=None, reset_to_zero=None,
                   do_bench=None, **kwargs):
    configs = list(configs)
    if configs and prune_configs_by is None:
        configs = configs[:1]
    return _orig_autotune(configs, key=key, prune_configs_by=prune_configs_by,
                          reset_to_zero=reset_to_zero,
                          do_bench=(lambda *a, **kw: 1.0), **kwargs)


triton.autotune = _fast_autotune

import numpy as np
import torch

if not (hasattr(torch, "npu") and torch.npu.is_available()):
    raise RuntimeError("no NPU device available")

PRACTICE = os.path.join(BASE, "practice")
spec = importlib.util.spec_from_file_location("trn_chunk_o_fwd", os.path.join(PRACTICE, "chunk_o.py"))
ch_mod = importlib.util.module_from_spec(spec)
sys.modules[spec.name] = ch_mod
spec.loader.exec_module(ch_mod)

chunk_fwd_o = ch_mod.chunk_fwd_o


def ref_fwd_o(q_np, k_np, v_np, h_np, g_np, scale, H, HV, BT):
    B, T, _, K = q_np.shape
    V = v_np.shape[-1]
    NT = T // BT
    o = np.zeros((B, T, HV, V), dtype=np.float32)
    for b in range(B):
        for i_t in range(NT):
            bos = i_t * BT
            for hv in range(HV):
                hm = hv // (HV // H)
                h_c = h_np[b, i_t, hv].astype(np.float32)
                for t in range(BT):
                    tt = bos + t
                    ov = (q_np[b, tt, hm].astype(np.float32) @ h_c) * scale
                    if g_np is not None:
                        ov = ov * (2.0 ** g_np[b, tt, hv])
                    for t2 in range(BT):
                        t2_abs = bos + t2
                        if t >= t2:
                            a = float(np.dot(q_np[b, tt, hm], k_np[b, t2_abs, hm]))
                            if g_np is not None:
                                a = a * (2.0 ** (g_np[b, tt, hv] - g_np[b, t2_abs, hv]))
                            ov = ov + a * v_np[b, t2_abs, hv].astype(np.float32) * scale
                    o[b, tt, hv] = ov
    return o


def run_case(name, q, k, v, h, g, H, HV, BT):
    dev = q.device
    scale = k.shape[-1] ** -0.5
    o = chunk_fwd_o(q=q, k=k, v=v, h=h, g=g, scale=scale,
                    state_v_first=False, chunk_size=BT)
    torch.npu.synchronize()
    exp = ref_fwd_o(q.cpu().numpy(), k.cpu().numpy(), v.cpu().numpy(), h.cpu().numpy(),
                    g.cpu().numpy() if g is not None else None,
                    scale, H, HV, int(BT))
    got = o.cpu().numpy().astype(np.float32)
    ok = np.allclose(got, exp, atol=1e-2, rtol=1e-2)
    print(f"[{'PASS' if ok else 'FAIL'}] {name}: K={k.shape[-1]} V={v.shape[-1]} BT={int(BT)} g={g is not None}")
    if not ok:
        d = np.abs(got - exp)
        print(f"  max_diff={d.max():.6f} (at {np.unravel_index(d.argmax(), d.shape)})")
    return ok


def test_chunk_fwd_o():
    dev = torch.device("npu", torch.npu.current_device())
    ok = True
    torch.manual_seed(3)
    B, T, H, HV, K, V, BT = 2, 64, 2, 2, 16, 16, 32
    q = torch.randn(B, T, H, K, dtype=torch.float16, device=dev) * 0.4
    k = torch.randn(B, T, H, K, dtype=torch.float16, device=dev) * 0.4
    v = torch.randn(B, T, HV, V, dtype=torch.float16, device=dev) * 0.4
    h = torch.randn(B, T // BT, HV, K, V, dtype=torch.float16, device=dev) * 0.3
    g = torch.randn(B, T, HV, dtype=torch.float16, device=dev) * 0.1
    ok &= run_case("fwd-o-gated", q, k, v, h, g, H, HV, BT)
    torch.manual_seed(3)
    B, T, H, HV, K, V, BT = 1, 64, 2, 4, 16, 32, 32
    q = torch.randn(B, T, H, K, dtype=torch.float16, device=dev) * 0.4
    k = torch.randn(B, T, H, K, dtype=torch.float16, device=dev) * 0.4
    v = torch.randn(B, T, HV, V, dtype=torch.float16, device=dev) * 0.4
    h = torch.randn(B, T // BT, HV, K, V, dtype=torch.float16, device=dev) * 0.3
    ok &= run_case("fwd-o-gva", q, k, v, h, None, H, HV, BT)
    assert ok, "chunk_fwd_o FAILED"
    print("[ALL PASS] chunk_fwd_o")


if __name__ == "__main__":
    test_chunk_fwd_o()

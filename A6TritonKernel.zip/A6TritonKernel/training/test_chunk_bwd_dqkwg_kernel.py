import os
import sys
import types
import importlib.util

os.environ.setdefault("TRITON_BACKENDS_IN_TREE", "1")
os.environ.setdefault("TRITON_BACKEND", "opentile")
os.environ.setdefault("TRITON_ALWAYS_COMPILE", "1")

BASE = os.path.dirname(os.path.abspath(__file__))
for p in (BASE, os.path.join(BASE, "practice"), os.path.join(BASE, "practice_stub")):
    if p not in sys.path:
        sys.path.insert(0, p)

import triton

_orig_autotune = triton.autotune


def _fast_autotune(configs, key=None, prune_configs_by=None, reset_to_zero=None,
                   do_bench=None, **kwargs):
    configs = list(configs)
    if configs and prune_configs_by is None:
        configs = configs[:1]
    return _orig_autotune(configs, key=key, prune_configs_by=prune_configs_by,
                          reset_to_zero=reset_to_zero,
                          do_bench=(lambda *a, **kw: 1.0), **kwargs)


triton.autotune = _fast_autotune

import numpy as np
import torch

if not (hasattr(torch, "npu") and torch.npu.is_available()):
    raise RuntimeError("no NPU device available")

PRACTICE = os.path.join(BASE, "practice")
spec = importlib.util.spec_from_file_location("trn_chunk_o_dqkwg", os.path.join(PRACTICE, "chunk_o.py"))
ch_mod = importlib.util.module_from_spec(spec)
sys.modules[spec.name] = ch_mod
spec.loader.exec_module(ch_mod)

chunk_bwd_dqkwg = ch_mod.chunk_bwd_dqkwg


def ref_dqkwg(q_np, k_np, v_np, do_np, h_np, dh_np, dv_np, scale, H, HV, BT):
    B, T, _, K = q_np.shape
    V = v_np.shape[-1]
    NT = T // BT
    dq = np.zeros((B, T, HV, K), dtype=np.float32)
    dk = np.zeros((B, T, HV, K), dtype=np.float32)
    dw = None if dv_np is None else np.zeros((B, T, HV, K), dtype=np.float32)
    for b in range(B):
        for i_t in range(NT):
            bos = i_t * BT
            for hv in range(HV):
                hm = hv // (HV // H)
                h_c = h_np[b, i_t, hv].astype(np.float32)
                dh_c = dh_np[b, i_t, hv].astype(np.float32)
                for t in range(BT):
                    tt = bos + t
                    kv = k_np[b, tt, hm].astype(np.float32)
                    # dq0 = do @ h^T, dk0 = v @ dh^T
                    dq_ = do_np[b, tt, hv].astype(np.float32) @ h_c.T
                    dk_ = v_np[b, tt, hv].astype(np.float32) @ dh_c.T
                    # b_ds = tril(do @ v^T) with mask j <= i (lower incl. diag)
                    for s in range(t, BT):
                        ts = bos + s
                        ds_st = float(np.dot(do_np[b, ts, hv], v_np[b, tt, hv]))
                        dk_ = dk_ + ds_st * q_np[b, ts, hm].astype(np.float32) * scale
                    for s in range(0, t + 1):
                        ts = bos + s
                        ds_ts = float(np.dot(do_np[b, tt, hv], v_np[b, ts, hv]))
                        dq_ = dq_ + ds_ts * k_np[b, ts, hm].astype(np.float32)
                    dq[b, tt, hv] = dq_ * scale
                    dk[b, tt, hv] = dk_
                    if dv_np is not None:
                        # dw = -(dv @ h^T)
                        dw[b, tt, hv] = -(dv_np[b, tt, hv].astype(np.float32) @ h_c.T)
    return dq, dk, dw


def _collapse_gva(x_np, H, HV):
    if H == HV:
        return x_np
    B, T, _, K = x_np.shape
    # group hv -> H, sum over group dimension (mirrors high-level decompose)
    return x_np.reshape(B, T, H, HV // H, K).sum(3).astype(np.float32)


def run_case(name, q, k, v, do, h, dh, dv, w, H, HV, BT):
    dev = q.device
    scale = k.shape[-1] ** -0.5
    dq, dk, dw, dg = chunk_bwd_dqkwg(q=q, k=k, v=v, do=do, h=h, dh=dh,
                                     w=w, g=None, dv=dv, scale=scale, chunk_size=BT)
    torch.npu.synchronize()
    rq, rk, rw = ref_dqkwg(q.cpu().numpy(), k.cpu().numpy(), v.cpu().numpy(),
                           do.cpu().numpy(), h.cpu().numpy(), dh.cpu().numpy(),
                           dv.cpu().numpy() if dv is not None else None,
                           scale, H, HV, int(BT))
    got_dq = dq.cpu().numpy().astype(np.float32)
    got_dk = dk.cpu().numpy().astype(np.float32)
    ok = True
    ok &= np.allclose(got_dq, _collapse_gva(rq, H, HV), atol=1e-2, rtol=1e-2)
    ok &= np.allclose(got_dk, _collapse_gva(rk, H, HV), atol=1e-2, rtol=1e-2)
    if dw is not None:
        ok &= np.allclose(dw.cpu().numpy().astype(np.float32), rw, atol=1e-2, rtol=1e-2)
    print(f"[{'PASS' if ok else 'FAIL'}] {name}: K={k.shape[-1]} V={v.shape[-1]} BT={int(BT)} dw={dw is not None}")
    if not ok:
        print(f"  dq max_diff={(np.abs(got_dq - _collapse_gva(rq, H, HV))).max():.6f}")
        print(f"  dk max_diff={(np.abs(got_dk - _collapse_gva(rk, H, HV))).max():.6f}")
        if dw is not None:
            print(f"  dw max_diff={(np.abs(dw.cpu().numpy().astype(np.float32) - rw)).max():.6f}")
    return ok


def _make_inputs(seed, B, T, H, HV, K, V, BT, dev):
    torch.manual_seed(seed)
    q = torch.randn(B, T, H, K, dtype=torch.float16, device=dev) * 0.3
    k = torch.randn(B, T, H, K, dtype=torch.float16, device=dev) * 0.3
    v = torch.randn(B, T, HV, V, dtype=torch.float16, device=dev) * 0.3
    do = torch.randn(B, T, HV, V, dtype=torch.float16, device=dev) * 0.3
    h = torch.randn(B, T // BT, HV, K, V, dtype=torch.float16, device=dev) * 0.3
    dh = torch.randn(B, T // BT, HV, K, V, dtype=torch.float16, device=dev) * 0.1
    dv = torch.randn(B, T, HV, V, dtype=torch.float16, device=dev) * 0.3
    return q, k, v, do, h, dh, dv


def test_chunk_bwd_dqkwg():
    dev = torch.device("npu", torch.npu.current_device())
    ok = True
    B, T, H, HV, K, V, BT = 2, 128, 2, 2, 16, 16, 64
    q, k, v, do, h, dh, dv = _make_inputs(3, B, T, H, HV, K, V, BT, dev)
    w = torch.randn(B, T, HV, K, dtype=torch.float16, device=dev) * 0.3
    ok &= run_case("dqkwg-no-g", q, k, v, do, h, dh, None, None, H, HV, BT)
    ok &= run_case("dqkwg-no-g-dw", q, k, v, do, h, dh, dv, w, H, HV, BT)
    B, T, H, HV, K, V, BT = 1, 128, 2, 4, 16, 32, 64
    q, k, v, do, h, dh, dv = _make_inputs(3, B, T, H, HV, K, V, BT, dev)
    w = torch.randn(B, T, HV, K, dtype=torch.float16, device=dev) * 0.3
    ok &= run_case("dqkwg-gva-dw", q, k, v, do, h, dh, dv, w, H, HV, BT)
    assert ok, "chunk_bwd_dqkwg FAILED"
    print("[ALL PASS] chunk_bwd_dqkwg")


if __name__ == "__main__":
    test_chunk_bwd_dqkwg()

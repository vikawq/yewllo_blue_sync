import os
import sys
import types
import importlib.util

os.environ.setdefault("TRITON_BACKENDS_IN_TREE", "1")
os.environ.setdefault("TRITON_BACKEND", "opentile")
os.environ.setdefault("TRITON_ALWAYS_COMPILE", "1")

BASE = os.path.dirname(os.path.abspath(__file__))
for p in (BASE, os.path.join(BASE, "practice"), os.path.join(BASE, "practice_stub")):
    if p not in sys.path:
        sys.path.insert(0, p)

import triton

_orig_autotune = triton.autotune


def _fast_autotune(configs, key=None, prune_configs_by=None, reset_to_zero=None,
                   do_bench=None, **kwargs):
    configs = list(configs)
    if configs and prune_configs_by is None:
        configs = configs[:1]
    return _orig_autotune(configs, key=key, prune_configs_by=prune_configs_by,
                          reset_to_zero=reset_to_zero,
                          do_bench=(lambda *a, **kw: 1.0), **kwargs)


triton.autotune = _fast_autotune

import numpy as np
import torch

if not (hasattr(torch, "npu") and torch.npu.is_available()):
    raise RuntimeError("no NPU device available")

PRACTICE = os.path.join(BASE, "practice")
spec = importlib.util.spec_from_file_location("trn_wy_fast", os.path.join(PRACTICE, "wy_fast.py"))
wy_mod = importlib.util.module_from_spec(spec)
sys.modules[spec.name] = wy_mod
spec.loader.exec_module(wy_mod)

recompute_w_u_fwd = wy_mod.recompute_w_u_fwd


def ref_wu(k, v, beta, A, g, H, HV, BT):
    B, T, _, K = k.shape
    V = v.shape[-1]
    w = torch.zeros(B, T, HV, K, dtype=torch.float32)
    u = torch.zeros(B, T, HV, V, dtype=torch.float32)
    g_e = 2.0 ** g
    for nc in range(T // BT):
        for t in range(BT):
            gt = nc * BT + t
            for h in range(HV):
                hm = h // (HV // H)
                for c in range(BT):
                    gcol = nc * BT + c
                    u[:, gt, h, :] += A[:, gt, h, c].unsqueeze(1) * v[:, gcol, h, :] * beta[:, gcol, h].unsqueeze(1)
                    w[:, gt, h, :] += A[:, gt, h, c].unsqueeze(1) * k[:, gcol, hm, :] * beta[:, gcol, h].unsqueeze(1) * g_e[:, gcol, h].unsqueeze(1)
    return w, u


def run_case(name, k, v, beta, A, g, H, HV, BT):
    dev = k.device
    w, u = recompute_w_u_fwd(k=k, v=v, beta=beta, A=A, g=g)
    torch.npu.synchronize()
    ew, eu = ref_wu(k.cpu(), v.cpu(), beta.cpu(), A.cpu(), g.cpu(), H, HV, BT)
    ok1 = torch.allclose(w.cpu().float(), ew, atol=1e-2, rtol=1e-2)
    ok2 = torch.allclose(u.cpu().float(), eu, atol=1e-2, rtol=1e-2)
    print(f"[{'PASS' if (ok1 and ok2) else 'FAIL'}] {name}: B={k.shape[0]} T={k.shape[1]} H={H} HV={HV} K={k.shape[-1]} V={v.shape[-1]} BT={int(BT)}")
    if not ok1:
        print(f"  w max_diff={(w.cpu().float() - ew).abs().max().item():.6f}")
    if not ok2:
        print(f"  u max_diff={(u.cpu().float() - eu).abs().max().item():.6f}")
    return ok1 and ok2


def test_recompute_w_u_fwd():
    dev = torch.device("npu", torch.npu.current_device())
    ok = True
    torch.manual_seed(3)
    B, T, H, HV, K, V, BT = 2, 128, 2, 2, 16, 16, 32
    k = torch.randn(B, T, H, K, dtype=torch.float16, device=dev) * 0.5
    v = torch.randn(B, T, HV, V, dtype=torch.float16, device=dev) * 0.5
    beta = torch.rand(B, T, HV, dtype=torch.float16, device=dev) * 0.5
    g = torch.rand(B, T, HV, dtype=torch.float16, device=dev) * 0.1
    r = torch.arange(BT, device=dev)
    A = torch.randn(B, T, HV, BT, dtype=torch.float16, device=dev) * 0.1
    A = (A.view(B, T // BT, BT, HV, BT) * (r[:, None] > r[None, :]).to(torch.float16).view(1, 1, BT, 1, BT)).reshape(B, T, HV, BT)
    ok &= run_case("wy-fwd-gva", k, v, beta, A, g, H, HV, BT)
    assert ok, "recompute_w_u_fwd FAILED"
    print("[ALL PASS] recompute_w_u_fwd")


if __name__ == "__main__":
    test_recompute_w_u_fwd()

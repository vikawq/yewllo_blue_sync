import os
import sys
import types
import importlib.util

os.environ.setdefault("TRITON_BACKENDS_IN_TREE", "1")
os.environ.setdefault("TRITON_BACKEND", "opentile")
os.environ.setdefault("TRITON_ALWAYS_COMPILE", "1")

BASE = os.path.dirname(os.path.abspath(__file__))
for p in (BASE, os.path.join(BASE, "practice"), os.path.join(BASE, "practice_stub")):
    if p not in sys.path:
        sys.path.insert(0, p)

import triton

_orig_autotune = triton.autotune


def _fast_autotune(configs, key=None, prune_configs_by=None, reset_to_zero=None,
                   do_bench=None, **kwargs):
    configs = list(configs)
    if configs and prune_configs_by is None:
        configs = configs[:1]
    return _orig_autotune(configs, key=key, prune_configs_by=prune_configs_by,
                          reset_to_zero=reset_to_zero,
                          do_bench=(lambda *a, **kw: 1.0), **kwargs)


triton.autotune = _fast_autotune

import numpy as np
import torch

if not (hasattr(torch, "npu") and torch.npu.is_available()):
    raise RuntimeError("no NPU device available")

PRACTICE = os.path.join(BASE, "practice")
spec = importlib.util.spec_from_file_location("trn_wy_fast_bwd", os.path.join(PRACTICE, "wy_fast.py"))
wy_mod = importlib.util.module_from_spec(spec)
sys.modules[spec.name] = wy_mod
spec.loader.exec_module(wy_mod)

prepare_wy_repr_bwd = wy_mod.prepare_wy_repr_bwd


def ref_bwd(k, v, beta, A, g, dw, du, H, HV, BT):
    B, T, _, K = k.shape
    V = v.shape[-1]
    k = k.clone(); v = v.clone(); beta = beta.clone(); g = g.clone()
    k.requires_grad_(); v.requires_grad_(); beta.requires_grad_(); g.requires_grad_()
    g_e = 2.0 ** g
    w = torch.zeros(B, T, HV, K, dtype=torch.float32)
    u = torch.zeros(B, T, HV, V, dtype=torch.float32)
    for h in range(HV):
        hm = h // (HV // H)
        for nc in range(T // BT):
            rows = slice(nc * BT, (nc + 1) * BT)
            A_blk = A[:, rows, h, :BT]
            b_k = beta[:, rows, h:h + 1]
            w[:, rows, h, :] = torch.matmul(A_blk.to(torch.float32), k[:, rows, hm, :].float() * b_k.float() * g_e[:, rows, h:h + 1].float())
            u[:, rows, h, :] = torch.matmul(A_blk.to(torch.float32), v[:, rows, h, :].float() * b_k.float())
    loss = (w * dw).sum() + (u * du).sum()
    loss.backward()
    return k.grad.float(), v.grad.float(), beta.grad.float(), g.grad.float()


def run_case(name, k, v, beta, A, g, dw, du, H, HV, BT):
    dev = k.device
    dk, dv, db, dg = prepare_wy_repr_bwd(k=k, v=v, beta=beta, A=A, dw=dw, du=du, g=g)
    torch.npu.synchronize()
    rk, rv, rb, rg = ref_bwd(k.cpu(), v.cpu(), beta.cpu(), A.cpu(), g.cpu(), dw.cpu(), du.cpu(), H, HV, BT)
    ok = True
    ok &= torch.allclose(dk.cpu().float(), rk, atol=0.15, rtol=0.15)
    ok &= torch.allclose(dv.cpu().float(), rv, atol=0.15, rtol=0.15)
    ok &= torch.allclose(db.cpu().float(), rb, atol=0.15, rtol=0.15)
    if dg is not None:
        ok &= torch.allclose(dg.cpu().float(), rg, atol=0.15, rtol=0.15)
    print(f"[{'PASS' if ok else 'FAIL'}] {name}: B={k.shape[0]} T={k.shape[1]} H={H} HV={HV} K={k.shape[-1]} V={v.shape[-1]} BT={int(BT)}")
    if not ok:
        print(f"  dk max_diff={(dk.cpu().float() - rk).abs().max().item():.6f}")
        print(f"  dv max_diff={(dv.cpu().float() - rv).abs().max().item():.6f}")
        print(f"  db max_diff={(db.cpu().float() - rb).abs().max().item():.6f}")
        if dg is not None:
            print(f"  dg max_diff={(dg.cpu().float() - rg).abs().max().item():.6f}")
    return ok


def test_prepare_wy_repr_bwd():
    dev = torch.device("npu", torch.npu.current_device())
    ok = True
    torch.manual_seed(3)
    B, T, H, HV, K, V, BT = 2, 64, 2, 2, 16, 16, 32
    k = torch.randn(B, T, H, K, dtype=torch.float16, device=dev) * 0.5
    v = torch.randn(B, T, HV, V, dtype=torch.float16, device=dev) * 0.5
    beta = torch.rand(B, T, HV, dtype=torch.float16, device=dev) * 0.5
    g = torch.rand(B, T, HV, dtype=torch.float16, device=dev) * 0.1
    dw = torch.randn(B, T, HV, K, dtype=torch.float16, device=dev) * 0.1
    du = torch.randn(B, T, HV, V, dtype=torch.float16, device=dev) * 0.1
    r = torch.arange(BT, device=dev)
    A = torch.randn(B, T, HV, BT, dtype=torch.float16, device=dev) * 0.1
    A = (A.view(B, T // BT, BT, HV, BT) * (r[:, None] > r[None, :]).to(torch.float16).view(1, 1, BT, 1, BT)).reshape(B, T, HV, BT)
    ok &= run_case("wy-bwd-gva", k, v, beta, A, g, dw, du, H, HV, BT)
    assert ok, "prepare_wy_repr_bwd FAILED"
    print("[ALL PASS] prepare_wy_repr_bwd")


if __name__ == "__main__":
    test_prepare_wy_repr_bwd()

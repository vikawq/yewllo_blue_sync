import os
import sys
import types
import importlib.util

os.environ.setdefault("TRITON_BACKENDS_IN_TREE", "1")
os.environ.setdefault("TRITON_BACKEND", "opentile")
os.environ.setdefault("TRITON_ALWAYS_COMPILE", "1")

BASE = os.path.dirname(os.path.abspath(__file__))
for p in (BASE, os.path.join(BASE, "practice"), os.path.join(BASE, "practice_stub")):
    if p not in sys.path:
        sys.path.insert(0, p)

import triton

_orig_autotune = triton.autotune


def _fast_autotune(configs, key=None, prune_configs_by=None, reset_to_zero=None,
                   do_bench=None, **kwargs):
    configs = list(configs)
    if configs and prune_configs_by is None:
        configs = configs[:1]
    return _orig_autotune(configs, key=key, prune_configs_by=prune_configs_by,
                          reset_to_zero=reset_to_zero,
                          do_bench=(lambda *a, **kw: 1.0), **kwargs)


triton.autotune = _fast_autotune

import numpy as np
import torch

if not (hasattr(torch, "npu") and torch.npu.is_available()):
    raise RuntimeError("no NPU device available")

PRACTICE = os.path.join(BASE, "practice")
spec = importlib.util.spec_from_file_location("trn_cumsum", os.path.join(PRACTICE, "cumsum.py"))
cumsum_mod = importlib.util.module_from_spec(spec)
sys.modules[spec.name] = cumsum_mod
spec.loader.exec_module(cumsum_mod)

chunk_local_cumsum = cumsum_mod.chunk_local_cumsum


def ref_local_cumsum(g_np, chunk_size, reverse, scale):
    g = g_np.copy().astype(np.float32)
    is_vec = g.ndim == 4
    if is_vec:
        B, T, H, S = g.shape
        x = g
    else:
        B, T, H = g.shape
        x = g
    T_pad = ((T + chunk_size - 1) // chunk_size) * chunk_size
    if is_vec:
        pad = np.zeros((B, T_pad - T, H, S), dtype=np.float32)
    else:
        pad = np.zeros((B, T_pad - T, H), dtype=np.float32)
    x = np.concatenate([x, pad], axis=1)
    n_ch = T_pad // chunk_size
    z = x.reshape(B, n_ch, chunk_size, H) if not is_vec else x.reshape(B, n_ch, chunk_size, H, S)
    if reverse:
        z = np.flip(z, axis=2)
        z = z.cumsum(axis=2)
        z = np.flip(z, axis=2)
    else:
        z = z.cumsum(axis=2)
    if scale is not None:
        z = z * scale
    z = z.reshape(B, T_pad, H) if not is_vec else z.reshape(B, T_pad, H, S)
    return z[:, :T].astype(np.float32)


def run_case(name, g_npu, chunk_size, reverse, scale):
    dev = g_npu.device
    out = chunk_local_cumsum(g_npu, chunk_size, reverse=reverse, scale=scale,
                             output_dtype=torch.float32)
    torch.npu.synchronize()
    got = out.cpu().numpy()
    exp = ref_local_cumsum(g_npu.cpu().numpy(), chunk_size, reverse, scale)
    ok = np.allclose(got, exp, atol=1e-3, rtol=1e-3)
    print(f"[{'PASS' if ok else 'FAIL'}] {name}: shape={tuple(g_npu.shape)} chunk={chunk_size} rev={reverse} scale={scale}")
    if not ok:
        print(f"  max_diff={(np.abs(got - exp)).max():.6f}")
    return ok


def test_chunk_local_cumsum():
    dev = torch.device("npu", torch.npu.current_device())
    ok = True
    torch.manual_seed(3)
    g = torch.randn(2, 64, 4, dtype=torch.float16, device=dev)
    ok &= run_case("scalar-basic", g, 16, False, None)
    torch.manual_seed(3)
    g = torch.randn(2, 40, 2, dtype=torch.float16, device=dev)
    ok &= run_case("scalar-unaligned", g, 16, False, None)
    torch.manual_seed(3)
    g = torch.randn(2, 128, 2, dtype=torch.float16, device=dev)
    ok &= run_case("scalar-rev-scale", g, 64, True, 0.5)
    torch.manual_seed(3)
    gv = torch.randn(2, 128, 2, 4, dtype=torch.float16, device=dev)
    ok &= run_case("vector-basic", gv, 64, False, None)
    torch.manual_seed(3)
    gv = torch.randn(1, 80, 3, 4, dtype=torch.float16, device=dev)
    ok &= run_case("vector-rev", gv, 32, True, None)
    assert ok, "chunk_local_cumsum FAILED"
    print("[ALL PASS] chunk_local_cumsum")


if __name__ == "__main__":
    test_chunk_local_cumsum()

import os
import sys
import types
import importlib.util

os.environ.setdefault("TRITON_BACKENDS_IN_TREE", "1")
os.environ.setdefault("TRITON_BACKEND", "opentile")
os.environ.setdefault("TRITON_ALWAYS_COMPILE", "1")

BASE = os.path.dirname(os.path.abspath(__file__))
for p in (BASE, os.path.join(BASE, "practice"), os.path.join(BASE, "practice_stub")):
    if p not in sys.path:
        sys.path.insert(0, p)

import triton

_orig_autotune = triton.autotune


def _fast_autotune(configs, key=None, prune_configs_by=None, reset_to_zero=None,
                   do_bench=None, **kwargs):
    configs = list(configs)
    if configs and prune_configs_by is None:
        configs = configs[:1]
    return _orig_autotune(configs, key=key, prune_configs_by=prune_configs_by,
                          reset_to_zero=reset_to_zero,
                          do_bench=(lambda *a, **kw: 1.0), **kwargs)


triton.autotune = _fast_autotune

import torch
import torch_npu

if not (hasattr(torch, "npu") and torch.npu.is_available()):
    raise RuntimeError("no NPU device available")

try:
    from mindspeed_ops.api.triton.mhc_pre_only import mhc_pre_only_triton
except ImportError as e:
    raise RuntimeError(
        "mindspeed_ops is not importable; run inside the MindSpeed-Ops "
        "environment (arch32). Detail: %s" % e
    )

DEV = "npu"
NS = 4          # num_stream, hard requirement of the kernel
EPS = 1e-6

FP32_TOL = dict(rtol=1e-3, atol=1e-3)
BF16_TOL = dict(rtol=2e-2, atol=2e-2)
RECOMP_TOL = dict(rtol=1e-5, atol=1e-5)
EXACT = dict(rtol=0, atol=0)


def _randn(*args, **kwargs):
    kwargs.pop("device", None)
    return torch.randn(*args, **kwargs).to(DEV)


def _clone_req(t, req):
    r = t.detach().clone()
    r.requires_grad_(req)
    return r


class RecomputeInfo:
    def __init__(self):
        self.only_h_pre_input_fp32 = None
        self.only_h_pre = None
        self.only_h_pre_out = None


def mhc_pre_only_reference(x, weight, branch_alpha, branch_beta, norm_gamma,
                           mhc_use_gamma, num_stream, eps):
    B, S, nD = x.shape
    x_f32 = x.float()
    weight_f32 = weight.float().t()
    if mhc_use_gamma:
        gamma = norm_gamma.float()
    else:
        gamma = torch.ones(nD, device=x.device, dtype=torch.float32)
    x_flat = x_f32.reshape(-1, nD)
    rstd = torch.rsqrt(x_flat.square().mean(-1, keepdim=True) + eps)
    x_norm = x_flat * rstd * gamma
    mixes = torch.matmul(x_norm, weight_f32).view(B, S, -1)
    h_pre = torch.sigmoid(mixes * branch_alpha.float() + branch_beta.float()) + eps
    x_unflat = x_f32.unflatten(-1, (num_stream, -1))
    y = torch.sum(h_pre.unsqueeze(-1) * x_unflat, dim=-2).to(x.dtype)
    return y, h_pre


def make_mhc_inputs(B, S, D, dtype, seed=0, num_stream=NS):
    torch.manual_seed(seed)
    nD = num_stream * D
    x = _randn(B, S, nD, device=DEV, dtype=dtype)
    weight = _randn(num_stream, nD, device=DEV, dtype=dtype)
    alpha = _randn(1, device=DEV, dtype=dtype)
    beta = _randn(num_stream, device=DEV, dtype=dtype)
    gamma = _randn(nD, device=DEV, dtype=dtype)
    return x, weight, alpha, beta, gamma


def report_diff(name, actual, expected):
    a = actual.detach().float().cpu()
    e = expected.detach().float().cpu()
    diff = (a - e).abs()
    print(f"    {name}: shape={tuple(a.shape)} max_abs={diff.max().item():.3e}")


def check_close(name, actual, expected, tol):
    report_diff(name, actual, expected)
    torch.testing.assert_close(actual, expected, **tol)


def _api_bwd(inputs, use_gamma, gy_seed=None, reqs=(True, True, False, False, True),
             recompute_info=None, eps=EPS, num_stream=NS, gy=None):
    xk, wk, ak, bk, gk = (_clone_req(t, r) for t, r in zip(inputs, reqs))
    yk, hk = mhc_pre_only_triton(xk, wk, ak, bk, gk, mhc_use_gamma=use_gamma,
                                 num_stream=num_stream, eps=eps,
                                 recompute_info=recompute_info)
    if gy is None:
        torch.manual_seed(gy_seed)
        gy = torch.randn_like(yk.detach().cpu()).to(DEV)
    (yk * gy).sum().backward()
    return {"x": xk.grad, "w": wk.grad, "a": ak.grad, "b": bk.grad, "g": gk.grad,
            "y": yk.detach(), "h": hk.detach(), "gy": gy}


def _ref_bwd(inputs, use_gamma, gy, reqs=(True, True, False, False, True),
             eps=EPS, num_stream=NS):
    xr, wr, ar, br, gr = (_clone_req(t, r) for t, r in zip(inputs, reqs))
    yr, hr = mhc_pre_only_reference(xr, wr, ar, br, gr, use_gamma, num_stream, eps)
    (yr * gy).sum().backward()
    return {"x": xr.grad, "w": wr.grad, "a": ar.grad, "b": br.grad, "g": gr.grad,
            "y": yr.detach(), "h": hr.detach()}


def _fwd_case(B, S, D, dtype, use_gamma, seed=0):
    tol = FP32_TOL if dtype == torch.float32 else BF16_TOL
    inputs = make_mhc_inputs(B, S, D, dtype, seed=seed)
    x, weight, alpha, beta, gamma = inputs
    y, h_pre = mhc_pre_only_triton(x, weight, alpha, beta, gamma,
                                   mhc_use_gamma=use_gamma, num_stream=NS, eps=EPS)
    ref_y, ref_h = mhc_pre_only_reference(x, weight, alpha, beta, gamma,
                                          use_gamma, NS, EPS)
    ok = True
    assert tuple(y.shape) == (B, S, D), f"unexpected y shape {tuple(y.shape)}"
    assert tuple(h_pre.shape) == (B, S, NS)
    assert h_pre.dtype == torch.float32, f"h_pre must stay fp32, got {h_pre.dtype}"
    assert y.dtype == dtype
    try:
        check_close("y", y, ref_y, tol)
    except AssertionError:
        ok = False
    try:
        check_close("h_pre", h_pre, ref_h, FP32_TOL)
    except AssertionError:
        ok = False
    print(f"[{'PASS' if ok else 'FAIL'}] fwd B={B} S={S} D={D} "
          f"{'fp32' if dtype == torch.float32 else 'bf16'} gamma={use_gamma}")
    return ok


def test_mhc_fwd():
    ok = True
    ok &= _fwd_case(1, 2, 2, torch.float32, use_gamma=True, seed=0)
    ok &= _fwd_case(1, 2, 2, torch.float32, use_gamma=False, seed=0)
    # simulator-only trim: larger/bf16 cases removed for timing
    # ok &= _fwd_case(1, 5, 8, torch.bfloat16, use_gamma=True, seed=10)
    # ok &= _fwd_case(2, 6, 16, torch.bfloat16, use_gamma=False, seed=11)
    # ok &= _fwd_case(1, 17, 16, torch.float32, use_gamma=True, seed=13)
    assert ok, "mhc_pre_only forward FAILED"
    print("[ALL PASS] mhc_pre_only forward")


def test_mhc_bwd():
    tol = FP32_TOL
    ok = True
    for use_gamma, seed in ((True, 20), (False, 21)):
        inputs = make_mhc_inputs(1, 17, 16, torch.float32, seed=seed)
        api = _api_bwd(inputs, use_gamma, gy_seed=seed + 100)
        ref = _ref_bwd(inputs, use_gamma, api["gy"])
        try:
            check_close("grad_x", api["x"], ref["x"], tol)
            check_close("grad_weight", api["w"], ref["w"], tol)
            if use_gamma:
                check_close("grad_gamma", api["g"], ref["g"], tol)
        except AssertionError:
            ok = False
        print(f"[{'PASS' if ok else 'FAIL'}] bwd fp32 gamma={use_gamma}")
    inputs = make_mhc_inputs(2, 9, 32, torch.bfloat16, seed=22)
    api = _api_bwd(inputs, True, gy_seed=122)
    ref = _ref_bwd(inputs, True, api["gy"])
    try:
        check_close("grad_x", api["x"], ref["x"], BF16_TOL)
        check_close("grad_weight", api["w"], ref["w"], BF16_TOL)
    except AssertionError:
        ok = False
    print(f"[{'PASS' if ok else 'FAIL'}] bwd bf16")
    assert ok, "mhc_pre_only backward FAILED"
    print("[ALL PASS] mhc_pre_only backward")


def test_mhc_bwd_recompute():
    tol = FP32_TOL
    B, S, D = 1, 17, 16
    inputs = make_mhc_inputs(B, S, D, torch.float32, seed=23)
    info = RecomputeInfo()
    api_rc = _api_bwd(inputs, True, gy_seed=123, recompute_info=info)
    api_norm = _api_bwd(inputs, True, gy_seed=123)
    ref = _ref_bwd(inputs, True, api_norm["gy"])

    ok = True
    try:
        torch.testing.assert_close(api_rc["y"], api_norm["y"], **RECOMP_TOL)
        torch.testing.assert_close(api_rc["h"], api_norm["h"], **RECOMP_TOL)
        check_close("grad_x (recompute)", api_rc["x"], ref["x"], tol)
        check_close("grad_weight (recompute)", api_rc["w"], ref["w"], tol)
        check_close("grad_gamma (recompute)", api_rc["g"], ref["g"], tol)
    except AssertionError:
        ok = False

    if info.only_h_pre_input_fp32 is None:
        ok = False
    assert ok, "mhc_pre_only recompute FAILED"
    print("[PASS] recompute path matches normal path and reference")
    print("[ALL PASS] mhc_pre_only recompute")


if __name__ == "__main__":
    import os as _os
    _which = _os.environ.get("MHC_TESTS", "fwd")
    _all = {"fwd": test_mhc_fwd, "bwd": test_mhc_bwd, "recompute": test_mhc_bwd_recompute}
    _keys = ["fwd", "bwd", "recompute"] if _which == "all" else _which.split(",")
    tests = [_all[k] for k in _keys if k in _all]
    results = []
    failed = 0
    for t in tests:
        try:
            t()
            results.append((t.__name__, True))
        except Exception as e:
            results.append((t.__name__, False))
            failed += 1
            print(f"[FAIL] {t.__name__}: {type(e).__name__}: {e}")
    for name, ok in results:
        print(f"TEST {name}: {'PASS' if ok else 'FAIL'}")
    if failed:
        sys.exit(1)
    print("[ALL PASS] mhc_pre_only_triton")

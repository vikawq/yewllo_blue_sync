import os
import sys
import types
import importlib.util

os.environ.setdefault("TRITON_BACKENDS_IN_TREE", "1")
os.environ.setdefault("TRITON_BACKEND", "opentile")
os.environ.setdefault("TRITON_ALWAYS_COMPILE", "1")

BASE = os.path.dirname(os.path.abspath(__file__))
for p in (BASE, os.path.join(BASE, "practice"), os.path.join(BASE, "practice_stub")):
    if p not in sys.path:
        sys.path.insert(0, p)

import triton

_orig_autotune = triton.autotune


def _fast_autotune(configs, key=None, prune_configs_by=None, reset_to_zero=None,
                   do_bench=None, **kwargs):
    configs = list(configs)
    if configs and prune_configs_by is None:
        configs = configs[:1]
    return _orig_autotune(configs, key=key, prune_configs_by=prune_configs_by,
                          reset_to_zero=reset_to_zero,
                          do_bench=(lambda *a, **kw: 1.0), **kwargs)


triton.autotune = _fast_autotune

import numpy as np
import torch

if not (hasattr(torch, "npu") and torch.npu.is_available()):
    raise RuntimeError("no NPU device available")

PRACTICE = os.path.join(BASE, "practice")
spec = importlib.util.spec_from_file_location("trn_chunk_delta_fwd", os.path.join(PRACTICE, "chunk_delta_h.py"))
ch_mod = importlib.util.module_from_spec(spec)
sys.modules[spec.name] = ch_mod
spec.loader.exec_module(ch_mod)

chunk_gated_delta_rule_fwd_h = ch_mod.chunk_gated_delta_rule_fwd_h


def ref_fwd_h(k_np, w_np, u_np, g_np, H, HV, BT):
    B, T, _, K = k_np.shape
    V = u_np.shape[-1]
    NT = T // BT
    assert T % BT == 0, "keep T a multiple of BT for the reference"
    h = np.zeros((B, NT, HV, K, V), dtype=np.float32)
    v_new = np.zeros((B, T, HV, V), dtype=np.float32)
    final = np.zeros((B, HV, K, V), dtype=np.float32)
    for b in range(B):
        for hv in range(HV):
            hm = hv // (HV // H)
            h_state = np.zeros((K, V), dtype=np.float32)
            for i_t in range(NT):
                bos = i_t * BT
                h[b, i_t, hv] = h_state.copy()
                vn_raw = np.zeros((BT, V), dtype=np.float32)
                for t in range(BT):
                    tt = bos + t
                    vn_raw[t] = u_np[b, tt, hv] - w_np[b, tt, hv, :] @ h_state
                    v_new[b, tt, hv] = vn_raw[t]
                if g_np is not None:
                    g_last = g_np[b, bos + BT - 1, hv]
                    h_state = h_state * (2.0 ** g_last)
                    for t in range(BT):
                        tt = bos + t
                        h_state += np.outer(k_np[b, tt, hm], vn_raw[t] * (2.0 ** (g_last - g_np[b, tt, hv])))
                else:
                    for t in range(BT):
                        tt = bos + t
                        h_state += np.outer(k_np[b, tt, hm], vn_raw[t])
            final[b, hv] = h_state
    return h, v_new, final


def run_case(name, k, w, u, g, H, HV, BT, check_final):
    dev = k.device
    h, v_new, final = chunk_gated_delta_rule_fwd_h(
        k=k, w=w, u=u, g=g, output_final_state=check_final, chunk_size=BT,
        save_new_value=True, state_v_first=False)
    torch.npu.synchronize()
    rh, rv, rf = ref_fwd_h(k.cpu().numpy(), w.cpu().numpy(), u.cpu().numpy(),
                           g.cpu().numpy() if g is not None else None, H, HV, int(BT))
    ok = True
    ok &= np.allclose(h.cpu().numpy().astype(np.float32), rh, atol=1e-2, rtol=1e-2)
    ok &= np.allclose(v_new.cpu().numpy().astype(np.float32), rv, atol=1e-2, rtol=1e-2)
    if check_final:
        ok &= np.allclose(final.cpu().numpy().astype(np.float32), rf, atol=1e-2, rtol=1e-2)
    print(f"[{'PASS' if ok else 'FAIL'}] {name}: k={tuple(k.shape)} H={H} HV={HV} BT={int(BT)} g={g is not None}")
    if not ok:
        print(f"  h max_diff={(np.abs(h.cpu().numpy().astype(np.float32) - rh)).max():.6f}")
        print(f"  v_new max_diff={(np.abs(v_new.cpu().numpy().astype(np.float32) - rv)).max():.6f}")
        if check_final:
            print(f"  final max_diff={(np.abs(final.cpu().numpy().astype(np.float32) - rf)).max():.6f}")
    return ok


def test_chunk_gated_delta_rule_fwd_h():
    dev = torch.device("npu", torch.npu.current_device())
    ok = True
    torch.manual_seed(3)
    B, T, H, HV, K, V, BT = 2, 128, 2, 2, 16, 16, 64
    k = torch.randn(B, T, H, K, dtype=torch.float16, device=dev) * 0.5
    w = torch.randn(B, T, HV, K, dtype=torch.float16, device=dev) * 0.1
    u = torch.randn(B, T, HV, V, dtype=torch.float16, device=dev) * 0.5
    g = torch.randn(B, T, HV, dtype=torch.float16, device=dev) * 0.1
    ok &= run_case("fwd-h-gated", k, w, u, g, H, HV, BT, check_final=True)
    torch.manual_seed(3)
    B, T, H, HV, K, V, BT = 1, 128, 2, 4, 16, 32, 64
    k = torch.randn(B, T, H, K, dtype=torch.float16, device=dev) * 0.5
    w = torch.randn(B, T, HV, K, dtype=torch.float16, device=dev) * 0.1
    u = torch.randn(B, T, HV, V, dtype=torch.float16, device=dev) * 0.5
    ok &= run_case("fwd-h-gva", k, w, u, None, H, HV, BT, check_final=True)
    assert ok, "chunk_gated_delta_rule_fwd_h FAILED"
    print("[ALL PASS] chunk_gated_delta_rule_fwd_h")


if __name__ == "__main__":
    test_chunk_gated_delta_rule_fwd_h()

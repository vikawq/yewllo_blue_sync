import os
import sys
import types
import importlib.util

os.environ.setdefault("TRITON_BACKENDS_IN_TREE", "1")
os.environ.setdefault("TRITON_BACKEND", "opentile")
# 不设置 TRITON_ALWAYS_COMPILE=1，让 Triton 走编译缓存

BASE = os.path.dirname(os.path.abspath(__file__))
for p in (BASE, os.path.join(BASE, "practice"), os.path.join(BASE, "practice_stub")):
    if p not in sys.path:
        sys.path.insert(0, p)

import triton

_orig_autotune = triton.autotune


def _fast_autotune(configs, key=None, prune_configs_by=None, reset_to_zero=None,
                   do_bench=None, **kwargs):
    configs = list(configs)
    if configs and prune_configs_by is None:
        configs = configs[:1]
    return _orig_autotune(configs, key=key, prune_configs_by=prune_configs_by,
                          reset_to_zero=reset_to_zero,
                          do_bench=(lambda *a, **kw: 1.0), **kwargs)


triton.autotune = _fast_autotune

import torch

if not (hasattr(torch, "npu") and torch.npu.is_available()):
    raise RuntimeError("no NPU device available")

PRACTICE = os.path.join(BASE, "practice")
spec = importlib.util.spec_from_file_location("trn_norm_gate", os.path.join(PRACTICE, "fused_norm_gate.py"))
ng_mod = importlib.util.module_from_spec(spec)
sys.modules[spec.name] = ng_mod
spec.loader.exec_module(ng_mod)

layer_norm_gated_fwd = ng_mod.layer_norm_gated_fwd
layer_norm_gated_bwd = ng_mod.layer_norm_gated_bwd


def ref_norm_gated(x, g, weight, bias, activation, eps, is_rms_norm):
    xf = x.float()
    if is_rms_norm:
        rstd = torch.rsqrt(xf.square().mean(dim=-1, keepdim=True) + eps)
        y = xf * rstd
    else:
        mean = xf.mean(dim=-1, keepdim=True)
        xbar = xf - mean
        var = xbar.square().mean(dim=-1, keepdim=True)
        rstd = torch.rsqrt(var + eps)
        y = xbar * rstd
    if weight is not None:
        y = y * weight.float()
    if bias is not None:
        y = y + bias.float()
    gf = g.float()
    if activation in ("swish", "silu"):
        y = y * gf * torch.sigmoid(gf)
    elif activation == "sigmoid":
        y = y * torch.sigmoid(gf)
    return y


def run_bwd(name, x, g, weight, bias, activation, is_rms_norm):
    y, mean, rstd, _ = layer_norm_gated_fwd(x, g, weight, bias, activation=activation,
                                            eps=1e-5, is_rms_norm=is_rms_norm)
    torch.npu.synchronize()
    dy = torch.randn_like(x) * 0.1
    dx, dg, dw, db, dr = layer_norm_gated_bwd(dy, x, g, weight, bias, activation=activation,
                                              eps=1e-5, mean=mean, rstd=rstd,
                                              dresidual=None, has_residual=False,
                                              is_rms_norm=is_rms_norm)
    torch.npu.synchronize()
    xc = x.cpu().float(); gc = g.cpu().float()
    wc = weight.cpu().float() if weight is not None else None
    bc = bias.cpu().float() if bias is not None else None
    xc = xc.clone(); gc = gc.clone()
    xc.requires_grad_(); gc.requires_grad_()
    if wc is not None:
        wc = wc.clone(); wc.requires_grad_()
    if bc is not None:
        bc = bc.clone(); bc.requires_grad_()
    yr = ref_norm_gated(xc, gc, wc, bc, activation, 1e-5, is_rms_norm)
    (yr * dy.cpu().float()).sum().backward()
    ok = True
    ok &= torch.allclose(dx.cpu().float(), xc.grad, atol=1e-2, rtol=1e-2)
    ok &= torch.allclose(dg.cpu().float(), gc.grad, atol=1e-2, rtol=1e-2)
    if wc is not None:
        ok &= torch.allclose(dw.cpu().float(), wc.grad, atol=1e-2, rtol=1e-2)
    if bc is not None:
        ok &= torch.allclose(db.cpu().float(), bc.grad, atol=1e-2, rtol=1e-2)
    print(f"[{'PASS' if ok else 'FAIL'}] {name}: T={x.shape[0]} D={x.shape[1]} act={activation} rms={is_rms_norm}", flush=True)
    if not ok:
        print(f"  dx max_diff={(dx.cpu().float() - xc.grad).abs().max().item():.6f}", flush=True)
        print(f"  dg max_diff={(dg.cpu().float() - gc.grad).abs().max().item():.6f}", flush=True)
        if wc is not None:
            print(f"  dw max_diff={(dw.cpu().float() - wc.grad).abs().max().item():.6f}", flush=True)
        if bc is not None:
            print(f"  db max_diff={(db.cpu().float() - bc.grad).abs().max().item():.6f}", flush=True)
    return ok


def test_layer_norm_gated_bwd():
    dev = torch.device("npu", torch.npu.current_device())
    ok = True
    torch.manual_seed(3)
    T, D = 64, 64
    x = torch.randn(T, D, dtype=torch.float16, device=dev) * 0.5
    g = torch.randn(T, D, dtype=torch.float16, device=dev) * 0.5
    weight = torch.randn(D, dtype=torch.float16, device=dev) * 0.5 + 1.0
    bias = torch.randn(D, dtype=torch.float16, device=dev) * 0.1

    # backward 覆盖两条分支：LayerNorm+swish+bias、RMSNorm+silu+nobias
    ok &= run_bwd("layer-bwd-swish", x, g, weight, bias, "swish", False)
    ok &= run_bwd("rms-bwd-silu-nobias", x, g, weight, None, "silu", True)

    assert ok, "layer_norm_gated_bwd FAILED"
    print("[ALL PASS] layer_norm_gated_bwd", flush=True)


if __name__ == "__main__":
    test_layer_norm_gated_bwd()
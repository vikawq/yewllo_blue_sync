import os
import sys
import types
import importlib.util

os.environ.setdefault("TRITON_BACKENDS_IN_TREE", "1")
os.environ.setdefault("TRITON_BACKEND", "opentile")
# 去掉 TRITON_ALWAYS_COMPILE=1，让 Triton 走编译缓存，
# 避免同一特化被重复编译，显著减少总耗时。

BASE = os.path.dirname(os.path.abspath(__file__))
for p in (BASE, os.path.join(BASE, "practice"), os.path.join(BASE, "practice_stub")):
    if p not in sys.path:
        sys.path.insert(0, p)

import triton

_orig_autotune = triton.autotune


def _fast_autotune(configs, key=None, prune_configs_by=None, reset_to_zero=None,
                   do_bench=None, **kwargs):
    configs = list(configs)
    if configs and prune_configs_by is None:
        configs = configs[:1]
    return _orig_autotune(configs, key=key, prune_configs_by=prune_configs_by,
                          reset_to_zero=reset_to_zero,
                          do_bench=(lambda *a, **kw: 1.0), **kwargs)


triton.autotune = _fast_autotune

import numpy as np
import torch

if not (hasattr(torch, "npu") and torch.npu.is_available()):
    raise RuntimeError("no NPU device available")

PRACTICE = os.path.join(BASE, "practice")
spec = importlib.util.spec_from_file_location("trn_kkt", os.path.join(PRACTICE, "chunk_scaled_dot_kkt.py"))
kk_mod = importlib.util.module_from_spec(spec)
sys.modules[spec.name] = kk_mod
spec.loader.exec_module(kk_mod)

chunk_scaled_dot_kkt_fwd = kk_mod.chunk_scaled_dot_kkt_fwd


def ref_kkt(k_np, beta_np, g_np, H, HV, BT):
    """
    向量化参考实现，替代原来的 Python 三重循环。
    原实现复杂度 B*n_ch*HV*BT^2 次 Python 迭代，这里把内层 ii/jj
    变成矩阵乘法 + 广播，参考计算从秒级降到毫秒级。
    """
    B, T, _H, K = k_np.shape
    A = np.zeros((B, T, HV, BT), dtype=np.float32)
    n_ch = (T + BT - 1) // BT
    for b in range(B):
        for c in range(n_ch):
            bos = c * BT
            eos = min((c + 1) * BT, T)
            rows = eos - bos
            kk = k_np[b, bos:eos]                 # (rows, H, K)
            bb = beta_np[b, bos:eos]              # (rows, HV)
            gg = g_np[b, bos:eos] if g_np is not None else None
            for hv in range(HV):
                hm = hv // (HV // H)
                k_h = kk[:, hm, :]                # (rows, K)
                dots = k_h @ k_h.T                # (rows, rows)
                if gg is not None:
                    dec = 2.0 ** (gg[:, hv:hv + 1] - gg[None, :, hv])
                else:
                    dec = np.ones((rows, rows), dtype=np.float32)
                # 只保留 ii > jj（严格下三角），原逻辑 ii <= jj 时跳过
                mask = np.tril(np.ones((rows, rows), dtype=np.float32), -1)
                val = bb[:, hv:hv + 1] * dec * dots * mask
                A[b, bos:eos, hv, :rows] = val
    return A


def run_case(name, k, beta, g, H, HV, BT, use_g):
    if use_g:
        A = chunk_scaled_dot_kkt_fwd(k, g=g, beta=beta, chunk_size=BT, output_dtype=torch.float32)
    else:
        A = chunk_scaled_dot_kkt_fwd(k, g=None, beta=beta, chunk_size=BT, output_dtype=torch.float32)
    torch.npu.synchronize()
    got = A.cpu().numpy().astype(np.float32)
    exp = ref_kkt(k.cpu().numpy(), beta.cpu().numpy(),
                  g.cpu().numpy() if use_g else None, H, HV, int(BT))
    ok = np.allclose(got, exp, atol=1e-2, rtol=1e-2)
    print(f"[{'PASS' if ok else 'FAIL'}] {name}: k={tuple(k.shape)} H={H} HV={HV} BT={int(BT)} use_g={use_g}", flush=True)
    if not ok:
        d = np.abs(got - exp)
        print(f"  max_diff={d.max():.6f} (at {np.unravel_index(d.argmax(), d.shape)})", flush=True)
    return ok


def test_chunk_scaled_dot_kkt_fwd():
    dev = torch.device("npu", torch.npu.current_device())
    ok = True
    torch.manual_seed(3)
    # 用例 1: GVA, H=2 HV=2, BT=64, K=32 对齐, 覆盖带 g 的主路径
    k = torch.randn(1, 128, 2, 32, dtype=torch.float32, device=dev) * 0.5
    beta = torch.randn(1, 128, 2, dtype=torch.float32, device=dev).abs() + 0.1
    g = torch.randn(1, 128, 2, dtype=torch.float32, device=dev) * 0.1
    ok &= run_case("gva-h2-hv2", k, beta, g, H=2, HV=2, BT=64, use_g=True)

    assert ok, "chunk_scaled_dot_kkt_fwd FAILED"
    print("[ALL PASS] chunk_scaled_dot_kkt_fwd", flush=True)


if __name__ == "__main__":
    test_chunk_scaled_dot_kkt_fwd()

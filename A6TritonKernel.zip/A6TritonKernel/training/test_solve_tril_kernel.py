import os
import sys
import types
import importlib.util

os.environ.setdefault("TRITON_BACKENDS_IN_TREE", "1")
os.environ.setdefault("TRITON_BACKEND", "opentile")
os.environ.setdefault("TRITON_ALWAYS_COMPILE", "1")

BASE = os.path.dirname(os.path.abspath(__file__))
for p in (BASE, os.path.join(BASE, "practice"), os.path.join(BASE, "practice_stub")):
    if p not in sys.path:
        sys.path.insert(0, p)

import triton

_orig_autotune = triton.autotune


def _fast_autotune(configs, key=None, prune_configs_by=None, reset_to_zero=None,
                   do_bench=None, **kwargs):
    configs = list(configs)
    if configs and prune_configs_by is None:
        configs = configs[:1]
    return _orig_autotune(configs, key=key, prune_configs_by=prune_configs_by,
                          reset_to_zero=reset_to_zero,
                          do_bench=(lambda *a, **kw: 1.0), **kwargs)


triton.autotune = _fast_autotune

import numpy as np
import torch

if not (hasattr(torch, "npu") and torch.npu.is_available()):
    raise RuntimeError("no NPU device available")

PRACTICE = os.path.join(BASE, "practice")
spec = importlib.util.spec_from_file_location("trn_solve_tril", os.path.join(PRACTICE, "solve_tril.py"))
st_mod = importlib.util.module_from_spec(spec)
sys.modules[spec.name] = st_mod
spec.loader.exec_module(st_mod)

solve_tril = st_mod.solve_tril


def ref_solve_tril(A_np, BT):
    B, T, H, _ = A_np.shape
    out = np.zeros_like(A_np, dtype=np.float32)
    for b in range(B):
        for c in range(T // BT):
            bos, eos = c * BT, (c + 1) * BT
            for h in range(H):
                sub = A_np[b, bos:eos, h, :BT].astype(np.float32)
                I = np.eye(BT, dtype=np.float32)
                inv = np.linalg.inv(I + sub)
                out[b, bos:eos, h, :BT] = inv
    return out


def run_case(name, A, BT):
    dev = A.device
    Ai = solve_tril(A, output_dtype=torch.float32)
    torch.npu.synchronize()
    got = Ai.cpu().numpy().astype(np.float32)
    exp = ref_solve_tril(A.cpu().numpy(), int(BT))
    ok = np.allclose(got, exp, atol=1e-3, rtol=1e-3)
    print(f"[{'PASS' if ok else 'FAIL'}] {name}: A={tuple(A.shape)} BT={int(BT)}")
    if not ok:
        d = np.abs(got - exp)
        print(f"  max_diff={d.max():.6f} (at {np.unravel_index(d.argmax(), d.shape)})")
        idx = np.unravel_index(d.argmax(), d.shape)
        print(f"  got={got[idx]:.4f} exp={exp[idx]:.4f}")
    return ok


def make_strict_lower(A, BT):
    r = np.arange(int(BT))
    mask = (r[:, None] > r[None, :]).astype(np.float32)
    B, T, H, _ = A.shape
    return (A.view(B, T // int(BT), int(BT), H, int(BT)) * torch.from_numpy(mask).to(A.device).view(1, 1, int(BT), 1, int(BT))).reshape(B, T, H, int(BT))


def test_solve_tril():
    dev = torch.device("npu", torch.npu.current_device())
    ok = True
    for BT in (16, 32, 64):
        torch.manual_seed(3)
        A = torch.randn(1, 3 * BT, 2, BT, dtype=torch.float32, device=dev) * 0.1
        A = make_strict_lower(A, BT)
        ok &= run_case(f"bt{BT}", A, BT)
    assert ok, "solve_tril FAILED"
    print("[ALL PASS] solve_tril")


if __name__ == "__main__":
    test_solve_tril()

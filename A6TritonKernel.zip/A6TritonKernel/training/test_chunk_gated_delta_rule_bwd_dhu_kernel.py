import os
import sys
import types
import importlib.util

os.environ.setdefault("TRITON_BACKENDS_IN_TREE", "1")
os.environ.setdefault("TRITON_BACKEND", "opentile")
os.environ.setdefault("TRITON_ALWAYS_COMPILE", "1")

BASE = os.path.dirname(os.path.abspath(__file__))
for p in (BASE, os.path.join(BASE, "practice"), os.path.join(BASE, "practice_stub")):
    if p not in sys.path:
        sys.path.insert(0, p)

import triton

_orig_autotune = triton.autotune


def _fast_autotune(configs, key=None, prune_configs_by=None, reset_to_zero=None,
                   do_bench=None, **kwargs):
    configs = list(configs)
    if configs and prune_configs_by is None:
        configs = configs[:1]
    return _orig_autotune(configs, key=key, prune_configs_by=prune_configs_by,
                          reset_to_zero=reset_to_zero,
                          do_bench=(lambda *a, **kw: 1.0), **kwargs)


triton.autotune = _fast_autotune

import numpy as np
import torch

if not (hasattr(torch, "npu") and torch.npu.is_available()):
    raise RuntimeError("no NPU device available")

PRACTICE = os.path.join(BASE, "practice")
spec = importlib.util.spec_from_file_location("trn_chunk_delta_bwd", os.path.join(PRACTICE, "chunk_delta_h.py"))
ch_mod = importlib.util.module_from_spec(spec)
sys.modules[spec.name] = ch_mod
spec.loader.exec_module(ch_mod)

chunk_gated_delta_rule_bwd_dhu = ch_mod.chunk_gated_delta_rule_bwd_dhu


def ref_bwd_dhu(q_np, k_np, w_np, do_np, dv_np, g_np, dht_np, h0_np, scale, H, HV, BT):
    B, T, _, K = q_np.shape
    V = do_np.shape[-1]
    NT = T // BT
    dh = np.zeros((B, NT, HV, K, V), dtype=np.float32)
    dh0 = None if h0_np is None else np.zeros_like(h0_np, dtype=np.float32)
    dv2 = np.zeros((B, T, HV, V), dtype=np.float32)
    for b in range(B):
        for hv in range(HV):
            hm = hv // (HV // H)
            dh_state = np.zeros((K, V), dtype=np.float32)
            if dht_np is not None:
                dh_state = dht_np[b, hv].copy()
            for i_t in range(NT - 1, -1, -1):
                bos = i_t * BT
                dh[b, i_t, hv] = dh_state.copy()
                g_last = None
                if g_np is not None:
                    g_last = g_np[b, bos + BT - 1, hv]
                dv2_chunk = np.zeros((BT, V), dtype=np.float32)
                for t in range(BT):
                    tt = bos + t
                    val = (k_np[b, tt, hm, :].reshape(1, K).astype(np.float32)
                           @ dh_state).reshape(V)
                    if g_np is not None:
                        val = val * (2.0 ** (g_last - g_np[b, tt, hv]))
                    val = val + dv_np[b, tt, hv]
                    dv2[b, tt, hv] = val
                    dv2_chunk[t] = val
                if g_np is not None:
                    dh_state = dh_state * (2.0 ** g_last)
                    for t in range(BT):
                        tt = bos + t
                        qq = q_np[b, tt, hm] * (2.0 ** g_np[b, tt, hv])
                        dh_state += np.outer(qq, do_np[b, tt, hv]) * scale
                else:
                    for t in range(BT):
                        tt = bos + t
                        dh_state += np.outer(q_np[b, tt, hm], do_np[b, tt, hv]) * scale
                for t in range(BT):
                    tt = bos + t
                    dh_state -= np.outer(w_np[b, tt, hv], dv2_chunk[t])
            if h0_np is not None:
                dh0[b, hv] = dh_state
    return dh, dh0, dv2


def run_case(name, q, k, w, do, dv, g, dht, h0, H, HV, BT):
    dev = q.device
    scale = k.shape[-1] ** -0.5
    dh, dh0, dv2 = chunk_gated_delta_rule_bwd_dhu(
        q=q, k=k, w=w, do=do, dv=dv, g=g, h0=h0, dht=dht, scale=scale,
        state_v_first=False, chunk_size=BT)
    torch.npu.synchronize()
    rdh, rdh0, rdv2 = ref_bwd_dhu(
        q.cpu().numpy(), k.cpu().numpy(), w.cpu().numpy(), do.cpu().numpy(),
        dv.cpu().numpy(), g.cpu().numpy() if g is not None else None,
        dht.cpu().numpy() if dht is not None else None,
        h0.cpu().numpy() if h0 is not None else None,
        scale, H, HV, int(BT))
    ok = True
    ok &= np.allclose(dh.cpu().numpy().astype(np.float32), rdh, atol=1e-2, rtol=1e-2)
    ok &= np.allclose(dv2.cpu().numpy().astype(np.float32), rdv2, atol=1e-2, rtol=1e-2)
    if dh0 is not None:
        ok &= np.allclose(dh0.cpu().numpy().astype(np.float32), rdh0, atol=1e-2, rtol=1e-2)
    print(f"[{'PASS' if ok else 'FAIL'}] {name}: K={k.shape[-1]} V={do.shape[-1]} BT={int(BT)} g={g is not None} dht={dht is not None} h0={h0 is not None}")
    if not ok:
        print(f"  dh max_diff={(np.abs(dh.cpu().numpy().astype(np.float32) - rdh)).max():.6f}")
        print(f"  dv2 max_diff={(np.abs(dv2.cpu().numpy().astype(np.float32) - rdv2)).max():.6f}")
        if dh0 is not None:
            print(f"  dh0 max_diff={(np.abs(dh0.cpu().numpy().astype(np.float32) - rdh0)).max():.6f}")
    return ok


def test_chunk_gated_delta_rule_bwd_dhu():
    dev = torch.device("npu", torch.npu.current_device())
    ok = True
    torch.manual_seed(3)
    B, T, H, HV, K, V, BT = 2, 128, 2, 2, 16, 16, 64
    q = torch.randn(B, T, H, K, dtype=torch.float16, device=dev) * 0.3
    k = torch.randn(B, T, H, K, dtype=torch.float16, device=dev) * 0.3
    w = torch.randn(B, T, HV, K, dtype=torch.float16, device=dev) * 0.3
    do = torch.randn(B, T, HV, V, dtype=torch.float16, device=dev) * 0.3
    dv = torch.randn(B, T, HV, V, dtype=torch.float16, device=dev) * 0.3
    g = torch.randn(B, T, HV, dtype=torch.float16, device=dev) * 0.1
    ok &= run_case("bwd-dhu-gated", q, k, w, do, dv, g, None, None, H, HV, BT)
    torch.manual_seed(3)
    B, T, H, HV, K, V, BT = 1, 128, 2, 4, 16, 32, 64
    q = torch.randn(B, T, H, K, dtype=torch.float16, device=dev) * 0.3
    k = torch.randn(B, T, H, K, dtype=torch.float16, device=dev) * 0.3
    w = torch.randn(B, T, HV, K, dtype=torch.float16, device=dev) * 0.3
    do = torch.randn(B, T, HV, V, dtype=torch.float16, device=dev) * 0.3
    dv = torch.randn(B, T, HV, V, dtype=torch.float16, device=dev) * 0.3
    dht = torch.randn(B, HV, K, V, dtype=torch.float16, device=dev) * 0.1
    h0 = torch.randn(B, HV, K, V, dtype=torch.float16, device=dev) * 0.1
    ok &= run_case("bwd-dhu-state", q, k, w, do, dv, None, dht, h0, H, HV, BT)
    assert ok, "chunk_gated_delta_rule_bwd_dhu FAILED"
    print("[ALL PASS] chunk_gated_delta_rule_bwd_dhu")


if __name__ == "__main__":
    test_chunk_gated_delta_rule_bwd_dhu()

import os
import sys
import types
import importlib.util

os.environ.setdefault("TRITON_BACKENDS_IN_TREE", "1")
os.environ.setdefault("TRITON_BACKEND", "opentile")
os.environ.setdefault("TRITON_ALWAYS_COMPILE", "1")

BASE = os.path.dirname(os.path.abspath(__file__))
for p in (BASE, os.path.join(BASE, "practice"), os.path.join(BASE, "practice_stub")):
    if p not in sys.path:
        sys.path.insert(0, p)

import triton

_orig_autotune = triton.autotune


def _fast_autotune(configs, key=None, prune_configs_by=None, reset_to_zero=None,
                   do_bench=None, **kwargs):
    configs = list(configs)
    if configs and prune_configs_by is None:
        configs = configs[:1]
    return _orig_autotune(configs, key=key, prune_configs_by=prune_configs_by,
                          reset_to_zero=reset_to_zero,
                          do_bench=(lambda *a, **kw: 1.0), **kwargs)


triton.autotune = _fast_autotune

import numpy as np
import torch

if not (hasattr(torch, "npu") and torch.npu.is_available()):
    raise RuntimeError("no NPU device available")

PRACTICE = os.path.join(BASE, "practice")
spec = importlib.util.spec_from_file_location("trn_chunk_o_dv", os.path.join(PRACTICE, "chunk_o.py"))
ch_mod = importlib.util.module_from_spec(spec)
sys.modules[spec.name] = ch_mod
spec.loader.exec_module(ch_mod)

chunk_bwd_dv_local = ch_mod.chunk_bwd_dv_local


def ref_dv_local(q_np, k_np, do_np, g_np, scale, H, HV, BT):
    B, T, _, K = q_np.shape
    V = do_np.shape[-1]
    NT = T // BT
    dv = np.zeros((B, T, HV, V), dtype=np.float32)
    for b in range(B):
        for i_t in range(NT):
            bos = i_t * BT
            for hv in range(HV):
                hm = hv // (HV // H)
                for t in range(BT):
                    tt = bos + t
                    acc = np.zeros(V, dtype=np.float32)
                    for s in range(t, BT):
                        ts = bos + s
                        a = float(np.dot(k_np[b, tt, hm], q_np[b, ts, hm])) * scale
                        if g_np is not None:
                            a = a * (2.0 ** (g_np[b, ts, hv] - g_np[b, tt, hv]))
                        acc = acc + a * do_np[b, ts, hv].astype(np.float32)
                    dv[b, tt, hv] = acc
    return dv


def run_case(name, q, k, do, g, H, HV, BT):
    dev = q.device
    scale = k.shape[-1] ** -0.5
    dv = chunk_bwd_dv_local(q=q, k=k, do=do, g=g, scale=scale, chunk_size=BT)
    torch.npu.synchronize()
    exp = ref_dv_local(q.cpu().numpy(), k.cpu().numpy(), do.cpu().numpy(),
                       g.cpu().numpy() if g is not None else None,
                       scale, H, HV, int(BT))
    got = dv.cpu().numpy().astype(np.float32)
    ok = np.allclose(got, exp, atol=1e-2, rtol=1e-2)
    print(f"[{'PASS' if ok else 'FAIL'}] {name}: K={k.shape[-1]} V={do.shape[-1]} BT={int(BT)} g={g is not None}")
    if not ok:
        d = np.abs(got - exp)
        print(f"  max_diff={d.max():.6f} (at {np.unravel_index(d.argmax(), d.shape)})")
    return ok


def test_chunk_bwd_dv_local():
    dev = torch.device("npu", torch.npu.current_device())
    ok = True
    want = os.environ.get("RUN_CASE", "all")
    if want in ("all", "gated"):
        torch.manual_seed(3)
        B, T, H, HV, K, V, BT = 2, 128, 2, 2, 16, 16, 64
        q = torch.randn(B, T, H, K, dtype=torch.float16, device=dev) * 0.4
        k = torch.randn(B, T, H, K, dtype=torch.float16, device=dev) * 0.4
        do = torch.randn(B, T, HV, V, dtype=torch.float16, device=dev) * 0.4
        g = torch.randn(B, T, HV, dtype=torch.float16, device=dev) * 0.1
        ok &= run_case("dv-local-gated", q, k, do, g, H, HV, BT)
    if want in ("all", "gva"):
        torch.manual_seed(3)
        B, T, H, HV, K, V, BT = 1, 128, 2, 4, 16, 32, 64
        q = torch.randn(B, T, H, K, dtype=torch.float16, device=dev) * 0.4
        k = torch.randn(B, T, H, K, dtype=torch.float16, device=dev) * 0.4
        do = torch.randn(B, T, HV, V, dtype=torch.float16, device=dev) * 0.4
        ok &= run_case("dv-local-gva", q, k, do, None, H, HV, BT)
    assert ok, "chunk_bwd_dv_local FAILED"
    print("[ALL PASS] chunk_bwd_dv_local")


if __name__ == "__main__":
    if os.environ.get("RUN_CASE", "all") == "all":
        import subprocess
        rc = 0
        for case in ("gated", "gva"):
            env = dict(os.environ, RUN_CASE=case)
            r = subprocess.run([sys.executable, os.path.abspath(__file__)], env=env)
            rc |= r.returncode
        sys.exit(rc)
    test_chunk_bwd_dv_local()

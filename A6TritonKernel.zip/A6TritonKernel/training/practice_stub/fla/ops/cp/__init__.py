class FLACPContext:
    def __init__(self, *args, **kwargs):
        pass

import triton
import triton.language as tl


@triton.jit
def exp2(x):
    return tl.exp2(x.to(tl.float32))


@triton.jit
def unflatten_program_id(dim0, dim1=1, dim2=1, dim3=1, dim4=1):
    pid = tl.program_id(0)
    return pid % dim0, pid // dim0


try:
    make_tensor_descriptor = tl.make_tensor_descriptor
except AttributeError:
    def make_tensor_descriptor(*args, **kwargs):
        raise RuntimeError("make_tensor_descriptor unavailable on this backend")

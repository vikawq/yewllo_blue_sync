import triton


class _StubAutotuned:
    """Minimal stand-in for fla_cache_autotune: pick the first config and always
    launch with its kwargs (constexpr blocks like BK/BV plus num_warps/num_stages),
    without running any benchmark."""

    def __init__(self, fn, configs):
        self.fn = fn
        cfg = configs[0] if configs else None
        self._defaults = {}
        if cfg is not None:
            self._defaults.update(cfg.kwargs)
        self._defaults["num_warps"] = getattr(cfg, "num_warps", 4) if cfg is not None else 4
        self._defaults["num_stages"] = getattr(cfg, "num_stages", 3) if cfg is not None else 3

    def _inject(self, kwargs):
        for k, v in self._defaults.items():
            kwargs.setdefault(k, v)

    def __getitem__(self, grid):
        fn = self.fn
        defaults = self._defaults

        def runner(*args, **kwargs):
            self._inject(kwargs)
            g = grid
            if callable(g):
                meta = dict(kwargs)
                meta.update(defaults)
                try:
                    g = g(meta)
                except Exception as exc:
                    raise RuntimeError(f"callable grid resolution failed: {exc}") from exc
            return fn[g](*args, **kwargs)

        return runner

    def run(self, *args, **kwargs):
        self._inject(kwargs)
        return self.fn.run(*args, **kwargs)

    def __call__(self, *args, **kwargs):
        return self.fn(*args, **kwargs)

    def __getattr__(self, name):
        return getattr(self.fn, name)


def fla_cache_autotune(*args, **kwargs):
    configs = kwargs.get("configs", [])
    if args and isinstance(args[0], (list, tuple)):
        configs = args[0]
        args = args[1:]

    def deco(fn):
        return _StubAutotuned(fn, configs)

    if args and callable(args[0]):
        return args[0]
    return deco

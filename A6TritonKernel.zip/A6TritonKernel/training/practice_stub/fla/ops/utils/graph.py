import torch

_BUFFERS = {}


def get_static_buffer(name, shape, dtype, device, *args, **kwargs):
    key = (name, tuple(shape), str(dtype), str(device))
    if key not in _BUFFERS:
        _BUFFERS[key] = torch.zeros(shape, dtype=dtype, device=device)
    return _BUFFERS[key]

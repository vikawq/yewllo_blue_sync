import torch


def prepare_chunk_indices(cu_seqlens, chunk_size, chunk_offsets=None):
    if cu_seqlens is None:
        return None
    cu = cu_seqlens.detach()
    num_chunks_per_seq = ((cu[1:] - cu[:-1]) + chunk_size - 1) // chunk_size
    chunk_indices = []
    for i, nc in enumerate(num_chunks_per_seq.tolist()):
        for c in range(nc):
            chunk_indices.append(i)
            chunk_indices.append(c)
    if not chunk_indices:
        chunk_indices = [0, 0]
    return torch.tensor(
        chunk_indices, dtype=torch.long, device=cu_seqlens.device
    )


def prepare_chunk_offsets(cu_seqlens, chunk_size, num_chunks=None):
    if cu_seqlens is None:
        return torch.zeros(1, dtype=torch.long, device="cpu")
    cu = cu_seqlens.detach()
    num_chunks_per_seq = ((cu[1:] - cu[:-1]) + chunk_size - 1) // chunk_size
    offsets = torch.zeros_like(num_chunks_per_seq)
    if num_chunks_per_seq.numel() > 1:
        offsets[1:] = torch.cumsum(num_chunks_per_seq[:-1], 0)
    return offsets.to(cu_seqlens.device)

IS_INTEL = False
IS_NVIDIA_BLACKWELL = False
IS_NVIDIA_HOPPER = False
IS_TF32_SUPPORTED = False
IS_TMA_SUPPORTED = False
TRITON_ABOVE_3_4_0 = True
TRITON_ABOVE_3_7_1 = False
IS_AMD = False
autotune_cache_kwargs = {}


def check_shared_mem(*args, **kwargs):
    return False


def input_guard(*args, **kwargs):
    """Stub compatible with both @input_guard and @input_guard(no_guard_contiguous=[...])."""
    if len(args) == 1 and callable(args[0]) and not kwargs:
        return args[0]

    def deco(fn):
        return fn

    return deco


def deprecate_kwarg(old_name, version, new_name=None, message=None):
    def deco(fn):
        def wrapper(*args, **kwargs):
            if old_name in kwargs and new_name is not None and new_name not in kwargs:
                kwargs[new_name] = kwargs.pop(old_name)
            return fn(*args, **kwargs)

        return wrapper

    return deco


def get_multiprocessor_count(device=None):
    import torch

    if device is not None:
        try:
            import torch_npu  # noqa: F401

            if torch.npu.is_available():
                props = torch.npu.get_device_properties(device)
                return int(getattr(props, "multi_processor_count", 64) or 64)
        except Exception:
            pass
    return 64

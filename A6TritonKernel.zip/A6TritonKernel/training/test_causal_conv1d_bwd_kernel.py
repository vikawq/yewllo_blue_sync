import os
import sys
import types
import importlib.util

os.environ.setdefault("TRITON_BACKENDS_IN_TREE", "1")
os.environ.setdefault("TRITON_BACKEND", "opentile")
# 去掉 TRITON_ALWAYS_COMPILE=1，让 Triton 走编译缓存，
# 避免同一特化被重复编译，显著减少总耗时。

BASE = os.path.dirname(os.path.abspath(__file__))
for p in (BASE, os.path.join(BASE, "practice"), os.path.join(BASE, "practice_stub")):
    if p not in sys.path:
        sys.path.insert(0, p)

import triton
import triton.language as tl

_orig_autotune = triton.autotune


def _fast_autotune(configs, key=None, prune_configs_by=None, reset_to_zero=None,
                   do_bench=None, **kwargs):
    configs = list(configs)
    if configs and prune_configs_by is None:
        configs = configs[:1]
    return _orig_autotune(configs, key=key, prune_configs_by=prune_configs_by,
                          reset_to_zero=reset_to_zero,
                          do_bench=(lambda *a, **kw: 1.0), **kwargs)


triton.autotune = _fast_autotune

import torch
import torch.nn.functional as F

if not (hasattr(torch, "npu") and torch.npu.is_available()):
    raise RuntimeError("no NPU device available")

@triton.jit
def causal_conv1d_bwd_kernel(
    x,
    y,
    weight,
    initial_state,
    dht,
    dy,
    dx,
    dw,
    db,
    cu_seqlens,
    chunk_indices,
    B,
    T,
    stride_x_n,
    stride_x_t,
    stride_x_d,
    stride_dx_n,
    stride_dx_t,
    stride_dx_d,
    stride_dy_n,
    stride_dy_t,
    stride_dy_d,
    D: tl.constexpr,
    W: tl.constexpr,
    BT: tl.constexpr,
    BW: tl.constexpr,
    BD: tl.constexpr,
    NB: tl.constexpr,
    ACTIVATION: tl.constexpr,
):
    i_d, i_t, i_b = tl.program_id(0), tl.program_id(1), tl.program_id(2)
    i_tg = i_b * tl.num_programs(1) + i_t
    i_n = i_b
    bos, eos = (i_b * T).to(tl.int64), (i_b * T + T).to(tl.int64)
    p_x = x + tl.cast(i_b, tl.int64) * stride_x_n
    p_dy = dy + tl.cast(i_b, tl.int64) * stride_dy_n

    o_d = i_d * BD + tl.arange(0, BD)
    o_t = i_t.to(tl.int64) * BT + tl.arange(0, BT)
    o_w = tl.arange(0, BW) + W - BW
    m_d = o_d < D
    m_w = o_w >= 0
    m_x = (o_t < T)[:, None] & m_d[None, :]

    p_xb = p_x + o_t[:, None] * stride_x_t + o_d[None, :] * stride_x_d
    b_x = tl.load(p_xb, mask=m_x, other=0.0)
    b_x_t = tl.trans(b_x)
    b_w = tl.load(weight + o_d[:, None] * W + o_w, mask=m_d[:, None] & m_w, other=0)

    b_dx = tl.zeros((BT, BD), dtype=tl.float32)
    b_db = tl.zeros((BD,), dtype=tl.float32)
    b_dw_blk = tl.zeros((BD, BW), dtype=tl.float32)

    for i_w in tl.static_range(0, W):
        o_dy = o_t + i_w
        p_dy_blk = p_dy + o_dy[:, None] * stride_dy_t + o_d[None, :] * stride_dy_d
        b_dy = tl.load(p_dy_blk, mask=((o_dy < T)[:, None] & m_d[None, :]), other=0.0).to(tl.float32)
        b_wdy = b_dy * tl.sum(b_w * (o_w == (W - i_w - 1)), 1)
        b_dw_blk += tl.sum(tl.trans(b_dy) * b_x_t, 1)[:, None] * (o_w == (W - i_w - 1))[None, :]
        if i_w == 0:
            b_db += tl.sum(tl.trans(b_dy), 1)
        b_dx += b_wdy

    m_dw = (o_d < D)[:, None] & (o_w >= 0)[None, :]
    tl.store(dw + i_tg * D * W + o_d[:, None] * W + o_w[None, :],
             b_dw_blk.to(dw.dtype.element_ty), mask=m_dw)
    tl.store(db + i_tg * D + o_d, b_db.to(db.dtype.element_ty), mask=m_d)

    p_dx = dx + tl.cast(i_b, tl.int64) * stride_dx_n
    p_dx = p_dx + o_t[:, None] * stride_dx_t + o_d[None, :] * stride_dx_d
    tl.store(p_dx, tl.cast(b_dx, dtype=p_dx.dtype.element_ty, fp_downcast_rounding='rtne'), mask=m_x)


def causal_conv1d_bwd(x, dy, dht=None, weight=None, bias=None, residual=None,
                      initial_state=None, activation=None, cu_seqlens=None,
                      cu_seqlens_cpu=None, chunk_indices=None, chunk_size=64,
                      layout_fallback=False):
    shape = x.shape
    x = x.contiguous()
    dy = dy.contiguous()
    B, T, D = x.shape
    W = weight.shape[1]
    BT = chunk_size
    BW = triton.next_power_of_2(W)
    NT = triton.cdiv(T, BT)
    NB = triton.cdiv(B * T, 1024)
    stride_x_n, stride_x_t, stride_x_d = x.stride()
    stride_dy_n, stride_dy_t, stride_dy_d = dy.stride()
    dx = torch.empty_like(x)
    stride_dx_n, stride_dx_t, stride_dx_d = dx.stride()
    dw = torch.zeros(B * NT, D, W, dtype=torch.float, device=x.device)
    db = torch.zeros(B * NT, D, dtype=torch.float, device=x.device)
    BD = 16
    grid = (triton.cdiv(D, BD), NT, B)
    causal_conv1d_bwd_kernel[grid](
        x=x, y=None, weight=weight, initial_state=None, dht=None, dy=dy, dx=dx,
        dw=dw, db=db, cu_seqlens=None, chunk_indices=None,
        B=B, T=T,
        stride_x_n=stride_x_n, stride_x_t=stride_x_t, stride_x_d=stride_x_d,
        stride_dx_n=stride_dx_n, stride_dx_t=stride_dx_t, stride_dx_d=stride_dx_d,
        stride_dy_n=stride_dy_n, stride_dy_t=stride_dy_t, stride_dy_d=stride_dy_d,
        D=D, W=W, BT=BT, BW=BW, BD=BD, NB=NB, ACTIVATION=None,
        num_warps=4,
    )
    dw = dw.sum(0).to(weight)
    db = db.sum(0).to(bias)
    return dx.view(shape), dw, db, None, None


def ref_conv1d(x, weight, bias):
    """
    向量化因果卷积参考实现，替代原来的 Python 三重循环。
    x: (B, T, D), weight: (D, W), bias: (D,)
    y[t] = sum_c weight[:, c] * x[t + c - (W-1)] + bias
    实现：在 T 维左侧补 W-1 个零，然后对每个 c 取切片做乘加。
    """
    B, T, D = x.shape
    W = weight.shape[1]
    # pad 在 T 维左侧 W-1 个零，右侧不补，保持输出长度 T
    xp = F.pad(x, (0, 0, W - 1, 0))  # (B, T + W - 1, D)
    y = torch.zeros(B, T, D, dtype=x.dtype, device=x.device)
    for c in range(W):
        # 对应 ti = t + c - (W-1)，xp 的 [c : c+T] 恰好是 x[t + c - (W-1)]
        y = y + xp[:, c:c + T, :] * weight[:, c].view(1, 1, D)
    return y + bias.view(1, 1, D)


def ref_bwd(x, dy, weight, bias):
    x = x.clone(); weight = weight.clone(); bias = bias.clone()
    x.requires_grad_(); weight.requires_grad_(); bias.requires_grad_()
    y = ref_conv1d(x, weight, bias)
    loss = (y * dy).sum()
    loss.backward()
    return x.grad.detach(), weight.grad.detach(), bias.grad.detach()


def run_case(name, x, weight, bias, dy):
    dx, dw, db, dr, dh0 = causal_conv1d_bwd(x, dy, dht=None, weight=weight, bias=bias,
                                            initial_state=None, activation=None)
    torch.npu.synchronize()
    rx, rw, rb = ref_bwd(x.cpu().float(), dy.cpu().float(),
                         weight.cpu().float(), bias.cpu().float())
    ok = True
    ok &= torch.allclose(dx.cpu().float(), rx, atol=1e-2, rtol=1e-2)
    ok &= torch.allclose(dw.cpu().float(), rw, atol=1e-2, rtol=1e-2)
    ok &= torch.allclose(db.cpu().float(), rb, atol=1e-2, rtol=1e-2)
    print(f"[{'PASS' if ok else 'FAIL'}] {name}: x={tuple(x.shape)} W={weight.shape[1]}", flush=True)
    if not ok:
        print(f"  dx max_diff={(dx.cpu().float() - rx).abs().max().item():.6f}", flush=True)
        print(f"  dw max_diff={(dw.cpu().float() - rw).abs().max().item():.6f}", flush=True)
        print(f"  db max_diff={(db.cpu().float() - rb).abs().max().item():.6f}", flush=True)
    return ok


def test_causal_conv1d_bwd():
    dev = torch.device("npu", torch.npu.current_device())
    ok = True

    # 用例 1：W=4，覆盖最常见的卷积宽度
    torch.manual_seed(3)
    B, T, D, W = 1, 64, 16, 4
    x = torch.randn(B, T, D, dtype=torch.float16, device=dev) * 0.5
    weight = torch.randn(D, W, dtype=torch.float16, device=dev) * 0.5
    bias = torch.randn(D, dtype=torch.float16, device=dev) * 0.1
    dy = torch.randn(B, T, D, dtype=torch.float16, device=dev) * 0.1
    ok &= run_case("basic-w4", x, weight, bias, dy)

    assert ok, "causal_conv1d_bwd FAILED"
    print("[ALL PASS] causal_conv1d_bwd", flush=True)


if __name__ == "__main__":
    test_causal_conv1d_bwd()
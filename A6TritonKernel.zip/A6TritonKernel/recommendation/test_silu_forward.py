import torch
import torch_npu
import triton
import triton.language as tl
from triton.language.extra.cann.libdevice import fast_dividef


@triton.jit
def _silu_forward(
    output_ptr: tl.tensor,
    input_ptr: tl.tensor,
    x_size: tl.int32,
    x_block_size: tl.constexpr,
):
    x_offset = tl.program_id(0) * x_block_size
    mask = x_offset + tl.arange(0, x_block_size) < x_size
    output_block_ptr = output_ptr + x_offset
    input_block_ptr = input_ptr + x_offset
    cols = tl.arange(0, x_block_size)

    input = tl.load(input_block_ptr + cols, mask=mask, other=0.0).to(tl.float32)

    output = fast_dividef(input, 1.0 + tl.exp(-input)).to(output_ptr.dtype.element_ty)

    tl.store(output_block_ptr + cols, output, mask=mask)


def test_silu_forward():
    # 259 个有效元素，保留 5 个尾部元素检查越界写入。
    x_cpu = torch.linspace(-8, 8, 259, dtype=torch.float32)
    x = x_cpu.npu()
    output = torch.full((264,), 23.0, dtype=torch.float32).npu()

    _silu_forward[(2,)](output, x, 259, x_block_size=256)

    expected = x_cpu * torch.sigmoid(x_cpu)
    actual = output.cpu()
    torch.testing.assert_close(
        (actual[:259]).double(), (expected).double(), atol=2e-4, rtol=2e-3
    )
    torch.testing.assert_close(
        (actual[259:]).double(), (torch.full((5,), 23.0)).double(), atol=0, rtol=0
    )

    print(f"最大绝对误差: {(actual[:259] - expected).abs().max().item()}")
    print("PASS: silu_forward，精度和尾部越界检查通过")


if __name__ == "__main__":
    test_silu_forward()

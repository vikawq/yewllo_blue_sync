# Source: tests/kernels/triton_jagged_bmm_jagged_out.py

import torch
import torch_npu
import triton
import triton.language as tl


@triton.jit
def array_jagged_bmm_kernel(
    a_ptr,
    b_ptr,
    c_ptr,
    a_offsets_ptr,
    b_offsets_ptr,
    c_offsets_ptr,
    D,
    stride_bk,
    stride_bn,
    stride_cm,
    stride_cn,
    transpose,
    max_seq_len,
    BLOCK_SIZE_M: tl.constexpr,
    BLOCK_SIZE_N: tl.constexpr,
    BLOCK_SIZE_K: tl.constexpr,
    allow_tf32: tl.constexpr,
):
    pid_batch = tl.program_id(2)
    pid_m = tl.program_id(1)
    pid_n = tl.program_id(0)
    batch_offset_am = tl.load(a_offsets_ptr + pid_batch)
    batch_offset_bk = tl.load(b_offsets_ptr + pid_batch)
    batch_offset_cm = tl.load(c_offsets_ptr + pid_batch)
    batch_K = tl.load(b_offsets_ptr + pid_batch + 1) - batch_offset_bk
    batch_M = tl.load(c_offsets_ptr + pid_batch + 1) - batch_offset_cm
    stride_am = batch_M * (1 - transpose) + 1 * transpose
    stride_ak = batch_M * transpose + 1 * (1 - transpose)
    batch_K = tl.minimum(batch_K, max_seq_len)
    batch_M = tl.minimum(batch_M, max_seq_len)
    if batch_K == 0:
        return
    batch_N = D
    if pid_m * BLOCK_SIZE_M >= batch_M or pid_n * BLOCK_SIZE_N >= batch_N:
        return
    offs_am = (pid_m * BLOCK_SIZE_M + tl.arange(0, BLOCK_SIZE_M)) % batch_M
    offs_bn = (pid_n * BLOCK_SIZE_N + tl.arange(0, BLOCK_SIZE_N)) % batch_N
    offs_k = tl.arange(0, BLOCK_SIZE_K)
    a_ptrs = (
        a_ptr
        + batch_offset_am
        + (offs_am[:, None] * stride_am + offs_k[None, :] * stride_ak)
    )
    b_ptrs = (
        b_ptr
        + batch_offset_bk * stride_bk
        + (offs_k[:, None] * stride_bk + offs_bn[None, :] * stride_bn)
    )
    c = tl.zeros((BLOCK_SIZE_M, BLOCK_SIZE_N), dtype=tl.float32)
    for k in range(0, tl.cdiv(batch_K, BLOCK_SIZE_K)):
        a = tl.load(
            a_ptrs, mask=offs_k[None, :] < batch_K - k * BLOCK_SIZE_K, other=0.0
        )
        b = tl.load(
            b_ptrs, mask=offs_k[:, None] < batch_K - k * BLOCK_SIZE_K, other=0.0
        )
        c += tl.dot(a, b, allow_tf32=allow_tf32)
        a_ptrs += BLOCK_SIZE_K * stride_ak
        b_ptrs += BLOCK_SIZE_K * stride_bk
    offs_cm = pid_m * BLOCK_SIZE_M + tl.arange(0, BLOCK_SIZE_M)
    offs_cn = pid_n * BLOCK_SIZE_N + tl.arange(0, BLOCK_SIZE_N)
    c_ptrs = (
        c_ptr
        + stride_cm * batch_offset_cm
        + stride_cm * offs_cm[:, None]
        + stride_cn * offs_cn[None, :]
    )
    c_mask = (offs_cm[:, None] < batch_M) & (offs_cn[None, :] < batch_N)
    tl.store(c_ptrs, c, mask=c_mask)


def test_array_jagged_bmm_kernel():
    generator = torch.Generator().manual_seed(20261011)
    offset = torch.tensor([0, 3, 8], dtype=torch.int32)
    ao = torch.tensor([0, 9, 34], dtype=torch.int32)
    a = (torch.randn((34,), generator=generator) * 0.2).to(torch.float16)
    b = (torch.randn((8, 16), generator=generator) * 0.2).to(torch.float16)
    out = torch.full((8, 16), 23.0, dtype=torch.float16).npu()
    for trans in (0, 1):
        array_jagged_bmm_kernel[1, 1, 2](
            a.npu(),
            b.npu(),
            out,
            ao.npu(),
            offset.npu(),
            offset.npu(),
            16,
            16,
            1,
            16,
            1,
            trans,
            5,
            BLOCK_SIZE_M=16,
            BLOCK_SIZE_N=16,
            BLOCK_SIZE_K=16,
            allow_tf32=False,
        )
        expected = []
        for st, en, sa, ea in [(0, 3, 0, 9), (3, 8, 9, 34)]:
            aa = a[sa:ea].reshape(en - st, en - st).float()
            expected.append((aa.T if trans else aa) @ b[st:en].float())
        actual_output = out.cpu()
        expected_output = torch.cat(expected)
        torch.testing.assert_close(
            (actual_output).double(),
            (expected_output).double(),
            atol=0.0002,
            rtol=0.002,
            check_dtype=False,
        )
        assert (
            torch.isfinite(actual_output).all()
            and torch.isfinite(expected_output).all()
        )
    print("PASS: array_jagged_bmm_kernel")


if __name__ == "__main__":
    test_array_jagged_bmm_kernel()

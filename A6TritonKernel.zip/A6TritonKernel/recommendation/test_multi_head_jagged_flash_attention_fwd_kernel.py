# Source: tests/kernels/triton_multi_head_jagged_flash_attention.py

import torch
import torch_npu
import triton
import triton.language as tl


@triton.jit
def _multi_head_jagged_flash_attention_fwd_kernel(
    q_ptr,
    k_ptr,
    v_ptr,
    offset_ptr,
    o_ptr,
    lse_i_ptr,
    stride_qh,
    stride_qm,
    stride_qd,
    stride_kh,
    stride_kn,
    stride_kd,
    stride_vh,
    stride_vn,
    stride_vd,
    stride_oh,
    stride_om,
    stride_od,
    stride_lse_h,
    num_heads: tl.constexpr,
    max_seq_len: tl.constexpr,
    D: tl.constexpr,
    allow_tf32: tl.constexpr,
    BLOCK_M: tl.constexpr,
    BLOCK_N: tl.constexpr,
    BLOCK_D: tl.constexpr,
):
    pid_m = tl.program_id(axis=0)
    pid_bh = tl.program_id(axis=1)
    pid_batch = pid_bh // num_heads
    pid_head = pid_bh % num_heads
    begin = tl.load(offset_ptr + pid_batch)
    end = tl.load(offset_ptr + pid_batch + 1)
    seqlen = end - begin
    seqlen = tl.minimum(seqlen, max_seq_len)
    if pid_m * BLOCK_M >= seqlen:
        return
    offs_m = pid_m * BLOCK_M + tl.arange(0, BLOCK_M)
    offs_d = tl.arange(0, BLOCK_D)
    acc = tl.zeros([BLOCK_M, BLOCK_D], dtype=tl.float32)
    mi = tl.zeros([BLOCK_M], dtype=tl.float32) - float("inf")
    li = tl.zeros([BLOCK_M], dtype=tl.float32)
    for j in range(0, seqlen, BLOCK_N):
        offs_n = tl.arange(0, BLOCK_N) + j
        q_ptrs = (
            q_ptr
            + pid_head * stride_qh
            + begin * stride_qm
            + (offs_m[:, None] * stride_qm + offs_d[None, :] * stride_qd)
        )
        k_ptrs = (
            k_ptr
            + pid_head * stride_kh
            + begin * stride_kn
            + (offs_n[None, :] * stride_kn + offs_d[:, None] * stride_kd)
        )
        qk = tl.zeros((BLOCK_M, BLOCK_N), dtype=tl.float32)
        for d in range(0, D, BLOCK_D):
            curr_d = d + offs_d
            q = tl.load(
                q_ptrs,
                mask=(curr_d[None, :] < D) & (offs_m[:, None] < seqlen),
                other=0.0,
            )
            k = tl.load(
                k_ptrs,
                mask=(curr_d[:, None] < D) & (offs_n[None, :] < seqlen),
                other=0.0,
            )
            qk += tl.dot(q, k, allow_tf32=allow_tf32)
            q_ptrs += BLOCK_D * stride_qd
            k_ptrs += BLOCK_D * stride_kd
        mi_new = tl.maximum(tl.max(qk, axis=1), mi)
        mn_mask = (offs_m[:, None] < seqlen) & (offs_n[None, :] < seqlen)
        p = tl.exp(qk - mi_new[:, None])
        p = tl.where(mn_mask, p, 0.0)
        lij_hat = tl.sum(p, axis=1)
        alpha = tl.exp(mi - mi_new)
        li = alpha * li + lij_hat
        acc = alpha[:, None] * acc
        v_ptrs = (
            v_ptr
            + pid_head * stride_vh
            + begin * stride_vn
            + (offs_d[None, :] * stride_vd + offs_n[:, None] * stride_vn)
        )
        v = tl.load(
            v_ptrs, mask=(offs_d[None, :] < D) & (offs_n[:, None] < seqlen), other=0.0
        )
        p /= max_seq_len
        p = p.to(v_ptr.dtype.element_ty)
        acc += tl.dot(p, v, allow_tf32=allow_tf32)
        mi = mi_new
    lse_i = mi + tl.math.log(li)
    lse_i_offsets = pid_m * BLOCK_M + tl.arange(0, BLOCK_M)
    lse_i_ptrs = lse_i_ptr + pid_head * stride_lse_h + begin + lse_i_offsets
    tl.store(lse_i_ptrs, lse_i, mask=lse_i_offsets < seqlen)
    acc = acc / li[:, None]
    o_ptrs = o_ptr + (
        pid_head * stride_oh
        + begin * stride_om
        + offs_m[:, None] * stride_om
        + offs_d[None, :] * stride_od
    )
    o_mask = (offs_m[:, None] < seqlen) & (offs_d[None, :] < D)
    tl.store(o_ptrs, acc, mask=o_mask)


def test_multi_head_jagged_flash_attention_fwd_kernel():
    generator = torch.Generator().manual_seed(20261011)
    h = 2
    d = 16
    total = 8
    maxseq = 5
    offset = torch.tensor([0, 3, 3, 8], dtype=torch.int32)
    q = (torch.randn((h, total, d), generator=generator) * 0.2).to(torch.float16)
    k = (torch.randn((h, total, d), generator=generator) * 0.2).to(torch.float16)
    v = (torch.randn((h, total, d), generator=generator) * 0.2).to(torch.float16)
    dy = (torch.randn((h, total, d), generator=generator) * 0.2).to(torch.float16)
    qq = q.double()
    kk = k.double()
    vv = v.double()
    outs = []
    ls = []
    for a, b in [(0, 3), (3, 8)]:
        score = qq[:, a:b] @ kk[:, a:b].transpose(-1, -2)
        p = score.softmax(-1)
        outs.append(p @ vv[:, a:b] / maxseq)
        ls.append(score.logsumexp(-1))
    ref = torch.cat(outs, 1)
    lse = torch.cat(ls, 1).float()
    o = ref.detach().half()
    out = torch.full_like(o, 23.0).npu()
    lo = torch.full_like(lse, 23.0).npu()
    offs = offset.npu()
    opts = dict(D=d, allow_tf32=False)
    opts.update(num_heads=h, max_seq_len=maxseq, BLOCK_M=16, BLOCK_N=16, BLOCK_D=16)
    _multi_head_jagged_flash_attention_fwd_kernel[1, 3 * h](
        q.npu(),
        k.npu(),
        v.npu(),
        offs,
        out,
        lo,
        128,
        16,
        1,
        128,
        16,
        1,
        128,
        16,
        1,
        128,
        16,
        1,
        8,
        **opts
    )
    actual_attention = out.cpu()
    expected_attention = ref.detach()
    torch.testing.assert_close(
        (actual_attention).double(),
        (expected_attention).double(),
        atol=0.0002,
        rtol=0.003,
        check_dtype=False,
    )
    assert (
        torch.isfinite(actual_attention).all()
        and torch.isfinite(expected_attention).all()
    )
    actual_logsumexp = lo.cpu()
    expected_logsumexp = lse
    torch.testing.assert_close(
        (actual_logsumexp).double(),
        (expected_logsumexp).double(),
        atol=0.0002,
        rtol=0.002,
        check_dtype=False,
    )
    assert (
        torch.isfinite(actual_logsumexp).all()
        and torch.isfinite(expected_logsumexp).all()
    )
    print("PASS: multi_head_jagged_flash_attention_fwd_kernel")


if __name__ == "__main__":
    test_multi_head_jagged_flash_attention_fwd_kernel()

# Source: tests/kernels/triton_layer_norm.py

import torch
import torch_npu
import triton
import triton.language as tl


@triton.jit
def _weighted_layer_norm_fwd(
    X,
    Y,
    W,
    B,
    Mean,
    Rstd,
    D,
    eps,
    stride_x,
    stride_y,
    IS_SWISH: tl.constexpr,
    TRAINING: tl.constexpr,
    BLOCK_D: tl.constexpr,
    COMPUTE_MEAN_AND_RSTD: tl.constexpr,
):
    row = tl.program_id(0)
    X += row.to(tl.int64) * stride_x
    Y += row.to(tl.int64) * stride_y
    cols = tl.arange(0, BLOCK_D)
    x = tl.load(X + cols, mask=cols < D, other=0.0).to(tl.float32)
    if COMPUTE_MEAN_AND_RSTD:
        mean = tl.sum(x, axis=0) / D
    else:
        mean = tl.load(Mean + row)
    x_mean = tl.where(cols < D, x - mean, 0.0)
    if COMPUTE_MEAN_AND_RSTD:
        _var = tl.zeros([BLOCK_D], dtype=tl.float32)
        _var += x_mean * x_mean
        var = tl.sum(_var, axis=0) / D
        rstd = 1 / tl.sqrt(var + eps)
        if TRAINING:
            tl.store(Mean + row, mean)
            tl.store(Rstd + row, rstd)
    else:
        rstd = tl.load(Rstd + row)
    mask = cols < D
    y = x_mean * rstd
    w = tl.load(W + cols, mask=mask).to(tl.float32)
    b = tl.load(B + cols, mask=mask).to(tl.float32)
    y = y * w + b
    if IS_SWISH:
        y = tl.sigmoid(y) * x
    tl.store(Y + cols, y.to(Y.dtype.element_ty), mask=mask)


def test_weighted_layer_norm_fwd():
    generator = torch.Generator().manual_seed(20261011)
    x = (torch.randn((3, 7), generator=generator) * 0.2).to(torch.float32)
    w = (torch.randn((7,), generator=generator) * 0.2).to(torch.float32) + 1
    b = (torch.randn((7,), generator=generator) * 0.2).to(torch.float32)
    mean = x.mean(-1)
    rstd = (x.var(-1, unbiased=False) + 1e-05).rsqrt()
    out = torch.full_like(x, 23.0).npu()
    mn = torch.full((3,), 23.0).npu()
    rs = torch.full((3,), 23.0).npu()
    _weighted_layer_norm_fwd[3,](
        x.npu(),
        out,
        w.npu(),
        b.npu(),
        mn,
        rs,
        7,
        1e-05,
        7,
        7,
        IS_SWISH=False,
        TRAINING=True,
        BLOCK_D=8,
        COMPUTE_MEAN_AND_RSTD=True,
    )
    expected = (x - mean[:, None]) * rstd[:, None] * w + b
    actual_output = out.cpu()
    expected_output = expected
    torch.testing.assert_close(
        (actual_output).double(),
        (expected_output).double(),
        atol=0.0002,
        rtol=0.002,
        check_dtype=False,
    )
    assert torch.isfinite(actual_output).all() and torch.isfinite(expected_output).all()
    actual_rstd = rs.cpu()
    expected_rstd = rstd
    torch.testing.assert_close(
        (actual_rstd).double(),
        (expected_rstd).double(),
        atol=0.0002,
        rtol=0.002,
        check_dtype=False,
    )
    assert torch.isfinite(actual_rstd).all() and torch.isfinite(expected_rstd).all()
    actual_mean = mn.cpu()
    expected_mean = mean
    torch.testing.assert_close(
        (actual_mean).double(),
        (expected_mean).double(),
        atol=0.0002,
        rtol=0.002,
        check_dtype=False,
    )
    assert torch.isfinite(actual_mean).all() and torch.isfinite(expected_mean).all()
    print("PASS: weighted_layer_norm_fwd")


if __name__ == "__main__":
    test_weighted_layer_norm_fwd()

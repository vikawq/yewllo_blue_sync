# Source: tests/kernels/triton_layer_norm.py

import torch
import torch_npu
import triton
import triton.language as tl


@triton.jit
def _layer_norm_bwd_dx(
    DX, DY, X, Mean, Rstd, stride_dx, stride_dy, stride_x, D, eps, BLOCK_D: tl.constexpr
):
    row = tl.program_id(0)
    cols = tl.arange(0, BLOCK_D)
    mask = cols < D
    X += row.to(tl.int64) * stride_x
    DY += row.to(tl.int64) * stride_dy
    DX += row.to(tl.int64) * stride_dx
    x = tl.load(X + cols, mask=mask, other=0).to(tl.float32)
    dy = tl.load(DY + cols, mask=mask, other=0).to(tl.float32)
    mean = tl.load(Mean + row)
    rstd = tl.load(Rstd + row)
    xhat = (x - mean) * rstd
    xhat = tl.where(mask, xhat, 0.0)
    dy = tl.where(mask, dy, 0.0)
    c1 = tl.sum(xhat * dy, axis=0) / D
    c2 = tl.sum(dy, axis=0) / D
    dx = (dy - (xhat * c1 + c2)) * rstd
    tl.store(DX + cols, dx.to(DX.dtype.element_ty), mask=mask)


def test_layer_norm_bwd_dx():
    generator = torch.Generator().manual_seed(20261011)
    x = (torch.randn((3, 7), generator=generator) * 0.2).to(torch.float32)
    dy = (torch.randn((3, 7), generator=generator) * 0.2).to(torch.float32)
    w = (torch.randn((7,), generator=generator) * 0.2).to(torch.float32) + 1
    b = (torch.randn((7,), generator=generator) * 0.2).to(torch.float32)
    mean = x.mean(-1)
    rs = (x.var(-1, unbiased=False) + 1e-05).rsqrt()
    xx = x.double().requires_grad_()
    ww = w.double().requires_grad_()
    bb = b.double().requires_grad_()
    y = torch.nn.functional.layer_norm(xx, (7,), None, None, 1e-05)
    (y * dy.double()).sum().backward()
    dx = torch.full_like(x, 23.0).npu()
    _layer_norm_bwd_dx[3,](
        dx, dy.npu(), x.npu(), mean.npu(), rs.npu(), 7, 7, 7, 7, 1e-05, BLOCK_D=8
    )
    actual_dx = dx.cpu()
    expected_dx = xx.grad
    torch.testing.assert_close(
        (actual_dx).double(),
        (expected_dx).double(),
        atol=0.0002,
        rtol=0.002,
        check_dtype=False,
    )
    assert torch.isfinite(actual_dx).all() and torch.isfinite(expected_dx).all()
    print("PASS: layer_norm_bwd_dx")


if __name__ == "__main__":
    test_layer_norm_bwd_dx()

# Source: tests/kernels/triton_position.py

import torch
import torch_npu
import triton
import triton.language as tl


@triton.jit
def _add_position_embeddings_kernel(
    Jagged,
    seq_offsets,
    high_inds,
    Dense,
    Out,
    AUTOTUNE_MAX_SEQ_LEN,
    D,
    scale,
    ind_offsets,
    stride_jn,
    stride_dk,
    stride_on,
    SCALE_JAGGED: tl.constexpr,
    BLOCK_D: tl.constexpr,
    BLOCK_N: tl.constexpr,
):
    """
    Jagged has shape (sum_B(N_i), D),
    Dense has shape (K, D),
    Out has shape (sum_B(N_i), D)
    """
    off_b = tl.program_id(0)
    off_n = tl.program_id(1)
    seq_start = tl.load(seq_offsets + off_b)
    seq_end = tl.load(seq_offsets + off_b + 1)
    max_ind = tl.load(high_inds + off_b)
    seq_len = seq_end - seq_start
    start_n = off_n * BLOCK_N
    if start_n >= seq_len:
        return
    offs_n = start_n + tl.arange(0, BLOCK_N)
    if ind_offsets is None:
        clamped_offs_n = tl.where(offs_n >= max_ind, max_ind, offs_n)
    else:
        ind_offset = tl.load(ind_offsets + off_b)
        clamped_offs_n = tl.where(
            offs_n + ind_offset >= max_ind, max_ind, offs_n + ind_offset
        )
    offs_d = tl.arange(0, BLOCK_D)
    Jagged += seq_start.to(tl.int64) * stride_jn
    jagged_ptr_offsets = offs_n[:, None] * stride_jn + offs_d[None, :]
    Out += seq_start.to(tl.int64) * stride_on
    out_ptrs = Out + offs_n[:, None] * stride_on + offs_d[None, :]
    dense_ptrs = Dense + clamped_offs_n[:, None] * stride_dk + offs_d[None, :]
    for _d in range(0, D, BLOCK_D):
        mask = (offs_n[:, None] < seq_len) & (offs_d[None, :] < D)
        jg = tl.load(Jagged + jagged_ptr_offsets, mask=mask)
        if SCALE_JAGGED:
            jg = jg * scale
        dn = tl.load(dense_ptrs, mask=mask)
        jg += dn
        tl.store(out_ptrs, jg, mask=mask)
        dense_ptrs += BLOCK_D
        out_ptrs += BLOCK_D
        offs_d += BLOCK_D
        jagged_ptr_offsets += BLOCK_D


def test_add_position_embeddings_kernel():
    generator = torch.Generator().manual_seed(20261011)
    offsets = torch.tensor([0, 3, 3, 8], dtype=torch.int32)
    high = torch.tensor([1, 0, 2], dtype=torch.int32)
    x = (torch.randn((8, 7), generator=generator) * 0.2).to(torch.float32)
    emb = (torch.randn((3, 7), generator=generator) * 0.2).to(torch.float32)
    out = torch.full_like(x, 23.0).npu()
    ids = torch.tensor([0, 1, 1, 0, 1, 2, 2, 2])
    scale = 0.75
    _add_position_embeddings_kernel[3, 2](
        x.npu(),
        offsets.npu(),
        high.npu(),
        emb.npu(),
        out,
        5,
        7,
        scale,
        None,
        7,
        7,
        7,
        SCALE_JAGGED=True,
        BLOCK_D=8,
        BLOCK_N=4,
    )
    actual_out = out.cpu()
    expected_out = x * scale + emb[ids]
    torch.testing.assert_close(
        (actual_out).double(),
        (expected_out).double(),
        atol=0.0002,
        rtol=0.002,
        check_dtype=False,
    )
    assert torch.isfinite(actual_out).all() and torch.isfinite(expected_out).all()
    print("PASS: add_position_embeddings_kernel")


if __name__ == "__main__":
    test_add_position_embeddings_kernel()

# Source: tests/kernels/triton_jagged_dense_flash_attention.py

import torch
import torch_npu
import triton
import triton.language as tl


@triton.jit
def _bwd_preprocess_do_o_dot(
    o_ptr,
    do_ptr,
    delta_ptr,
    T,
    stride_ob,
    stride_ot,
    stride_od,
    stride_do_b,
    stride_do_t,
    stride_do_d,
    BLOCK_T: tl.constexpr,
    BLOCK_D: tl.constexpr,
):
    start_t = tl.program_id(0)
    offs_t = start_t * BLOCK_T + tl.arange(0, BLOCK_T)
    pid_b = tl.program_id(1)
    offs_d = tl.arange(0, BLOCK_D)
    o_ptrs = (
        o_ptr
        + pid_b * stride_ob
        + offs_t[:, None] * stride_ot
        + offs_d[None, :] * stride_od
    )
    do_ptrs = (
        do_ptr
        + pid_b * stride_do_b
        + offs_t[:, None] * stride_do_t
        + offs_d[None, :] * stride_do_d
    )
    o = tl.load(o_ptrs, mask=offs_t[:, None] < T, other=0.0)
    do = tl.load(do_ptrs, mask=offs_t[:, None] < T, other=0.0)
    delta = tl.sum(o * do, axis=1)
    delta_ptrs = delta_ptr + pid_b * T + offs_t
    tl.store(delta_ptrs, delta, mask=offs_t < T)


def test_bwd_preprocess_do_o_dot():
    generator = torch.Generator().manual_seed(20261011)
    input_dtype = torch.float16
    d, t, maxseq = (16, 3, 5)
    q = (torch.randn((8, d), generator=generator) * 0.2).to(input_dtype)
    k = (torch.randn((2, d, t), generator=generator) * 0.2).to(input_dtype)
    v = (torch.randn((8, d), generator=generator) * 0.2).to(input_dtype)
    bias = (torch.randn((2, maxseq, t), generator=generator) * 0.2).to(torch.float32)
    dy = (torch.randn((2, t, d), generator=generator) * 0.2).to(input_dtype)
    qq = q.double()
    kk = k.double()
    vv = v.double()
    bb = bias.double()
    ys = []
    ls = []
    for b, (st, en) in enumerate([(0, 3), (3, 8)]):
        s = qq[st:en] @ kk[b] + bb[b, : en - st]
        ys.append(s.softmax(0).T @ vv[st:en])
        ls.append(s.logsumexp(0))
    ref = torch.stack(ys)
    lse = torch.stack(ls).float()
    o = ref.detach().to(input_dtype)
    delta = (o.float() * dy.float()).sum(-1)
    lo = torch.full_like(lse, 23.0).npu()
    _bwd_preprocess_do_o_dot[1, 2](
        o.npu(), dy.npu(), lo, t, 48, 16, 1, 48, 16, 1, BLOCK_T=16, BLOCK_D=16
    )
    actual_delta = lo.cpu()
    expected_delta = delta
    torch.testing.assert_close(
        (actual_delta).double(),
        (expected_delta).double(),
        atol=0.0002,
        rtol=0.002,
        check_dtype=False,
    )
    assert torch.isfinite(actual_delta).all() and torch.isfinite(expected_delta).all()
    print("PASS: bwd_preprocess_do_o_dot")


if __name__ == "__main__":
    test_bwd_preprocess_do_o_dot()

# Source: tests/kernels/triton_jagged.py

import torch
import torch_npu
import triton
import triton.language as tl


@triton.jit
def concat_2D_jagged_w_prefix(
    OffsetsA,
    ValuesA,
    OffsetsB,
    ValuesB,
    DenseSize,
    Out,
    D,
    stride_ad,
    stride_bd,
    stride_dense_batch,
    stride_od,
    n_prefix_from_B,
    IS_DENSE_A: tl.constexpr,
    IS_DENSE_B: tl.constexpr,
    BLOCK_D: tl.constexpr,
    IS_REPLACE: tl.constexpr,
):
    off_z = tl.program_id(1)
    off_n = tl.program_id(0)
    if IS_DENSE_A:
        seq_start_a = off_z * DenseSize
        seq_len_a = DenseSize
        seq_start_b = tl.load(OffsetsB + off_z)
        seq_end_b = tl.load(OffsetsB + off_z + 1)
        seq_len_b = seq_end_b - seq_start_b
    elif IS_DENSE_B:
        seq_start_a = tl.load(OffsetsA + off_z)
        seq_end_a = tl.load(OffsetsA + off_z + 1)
        seq_len_a = seq_end_a - seq_start_a
        seq_start_b = off_z * DenseSize
        seq_len_b = DenseSize
    else:
        seq_start_a = tl.load(OffsetsA + off_z)
        seq_end_a = tl.load(OffsetsA + off_z + 1)
        seq_len_a = seq_end_a - seq_start_a
        seq_start_b = tl.load(OffsetsB + off_z)
        seq_end_b = tl.load(OffsetsB + off_z + 1)
        seq_len_b = seq_end_b - seq_start_b
    if IS_REPLACE:
        seq_len = seq_len_a
    else:
        seq_len = seq_len_a + seq_len_b
    if off_n >= seq_len:
        return
    offs_d = tl.arange(0, BLOCK_D)
    if IS_REPLACE:
        out_seq_start = seq_start_a + off_n
        out_seq_b_start = seq_len_a - seq_len_b
    else:
        out_seq_start = seq_start_a + seq_start_b + off_n
        out_seq_b_start = seq_len_a + n_prefix_from_B
    out_ptrs = Out + out_seq_start.to(tl.int64) * stride_od + offs_d
    if off_n < out_seq_b_start and off_n >= n_prefix_from_B:
        off_a = off_n - n_prefix_from_B
        if IS_DENSE_A:
            in_ptrs = (
                ValuesA
                + off_a.to(tl.int64) * stride_ad
                + off_z.to(tl.int64) * stride_dense_batch
                + offs_d
            )
        else:
            in_ptrs = ValuesA + (off_a + seq_start_a).to(tl.int64) * stride_ad + offs_d
    else:
        off_b = off_n - out_seq_b_start + n_prefix_from_B
        if off_n < n_prefix_from_B:
            off_b += out_seq_b_start - n_prefix_from_B
        if IS_DENSE_B:
            in_ptrs = (
                ValuesB
                + off_b.to(tl.int64) * stride_bd
                + off_z.to(tl.int64) * stride_dense_batch
                + offs_d
            )
        else:
            in_ptrs = ValuesB + (off_b + seq_start_b).to(tl.int64) * stride_bd + offs_d
    v = tl.load(in_ptrs, mask=offs_d < D)
    tl.store(out_ptrs, v, mask=offs_d < D)


def test_concat_2d_jagged_w_prefix():
    generator = torch.Generator().manual_seed(20261011)
    a = (torch.randn((3, 7), generator=generator) * 0.2).to(torch.float32)
    b = (torch.randn((5, 7), generator=generator) * 0.2).to(torch.float32)
    oa = torch.tensor([0, 2, 3], dtype=torch.int32).npu()
    ob = torch.tensor([0, 3, 5], dtype=torch.int32).npu()
    prefix = 1
    chunks = []
    for aa, bb in [(a[:2], b[:3]), (a[2:], b[3:])]:
        chunks.append(torch.cat([bb[:prefix], aa, bb[prefix:]]))
    merged = torch.cat(chunks)
    out = torch.full((8, 7), 23.0).npu()
    args = (oa, a.npu(), ob, b.npu(), 0, out, 7, 7, 7, 0, 7)
    args += (prefix,)
    concat_2D_jagged_w_prefix[5, 2](
        *args, IS_DENSE_A=False, IS_DENSE_B=False, BLOCK_D=8, IS_REPLACE=False
    )
    actual_merged = out.cpu()
    expected_merged = merged
    torch.testing.assert_close(
        (actual_merged).double(),
        (expected_merged).double(),
        atol=0,
        rtol=0,
        check_dtype=False,
    )
    assert torch.isfinite(actual_merged).all() and torch.isfinite(expected_merged).all()
    print("PASS: concat_2D_jagged_w_prefix")


if __name__ == "__main__":
    test_concat_2d_jagged_w_prefix()

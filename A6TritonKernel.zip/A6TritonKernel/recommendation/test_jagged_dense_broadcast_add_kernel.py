# Source: tests/kernels/triton_jagged.py

import torch
import torch_npu
import triton
import triton.language as tl


@triton.jit
def jagged_dense_broadcast_add_kernel(
    seq_offsets,
    Jagged,
    Dense,
    Out,
    AUTOTUNE_MAX_SEQ_LEN,
    D,
    stride_jn,
    stride_db,
    stride_on,
    BLOCK_N: tl.constexpr,
    BLOCK_D: tl.constexpr,
):
    """
    Computing Out = Jagged + Dense
    JaggedA has shape (sum_B(N_i), D), Dense has shape (B, D), and Out has shape (sum_B(N_i), D)
    """
    off_b = tl.program_id(0)
    off_n = tl.program_id(1)
    seq_start = tl.load(seq_offsets + off_b)
    seq_end = tl.load(seq_offsets + off_b + 1)
    seq_len = seq_end - seq_start
    start_n = off_n * BLOCK_N
    if start_n >= seq_len:
        return
    Jagged += seq_start * stride_jn
    Dense += off_b * stride_db
    Out += seq_start * stride_on
    offs_n = start_n + tl.arange(0, BLOCK_N)
    offs_d = tl.arange(0, BLOCK_D)
    jagged_ptrs = Jagged + offs_n[:, None] * stride_jn + offs_d[None, :]
    dense_ptrs = Dense + offs_d
    out_ptrs = Out + offs_n[:, None] * stride_jn + offs_d[None, :]
    for d in range(0, D, BLOCK_D):
        jg = tl.load(
            jagged_ptrs, mask=offs_n[:, None] < seq_len and (d + offs_d)[None, :] < D
        )
        dn = tl.load(dense_ptrs, mask=d + offs_d < D)
        out = jg + dn[None, :]
        tl.store(
            out_ptrs, out, mask=offs_n[:, None] < seq_len and (d + offs_d)[None, :] < D
        )
        dense_ptrs += BLOCK_D
        jagged_ptrs += BLOCK_D
        out_ptrs += BLOCK_D


def test_jagged_dense_broadcast_add_kernel():
    generator = torch.Generator().manual_seed(20261011)
    x = (torch.randn((8, 7), generator=generator) * 0.2).to(torch.float32)
    y = (torch.randn((3, 7), generator=generator) * 0.2).to(torch.float32)
    o = torch.full_like(x, 23.0).npu()
    jagged_dense_broadcast_add_kernel[3, 2](
        torch.tensor([0, 3, 3, 8], dtype=torch.int32).npu(),
        x.npu(),
        y.npu(),
        o,
        5,
        7,
        7,
        7,
        7,
        BLOCK_N=4,
        BLOCK_D=8,
    )
    actual_output = o.cpu()
    expected_output = torch.cat([x[:3] + y[0], x[3:] + y[2]])
    torch.testing.assert_close(
        (actual_output).double(),
        (expected_output).double(),
        atol=0.0002,
        rtol=0.002,
        check_dtype=False,
    )
    assert torch.isfinite(actual_output).all() and torch.isfinite(expected_output).all()
    print("PASS: jagged_dense_broadcast_add_kernel")


if __name__ == "__main__":
    test_jagged_dense_broadcast_add_kernel()

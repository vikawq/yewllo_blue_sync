# Source: tests/kernels/triton_jagged_dense_elementwise_mul_jagged_out.py

import torch
import torch_npu
import triton
import triton.language as tl


@triton.jit
def jagged_dense_elementwise_mul_jagged_out_kernel(
    a_ptr,
    b_ptr,
    c_ptr,
    a_seq_lengths_ptr,
    a_offsets_ptr,
    stride_a,
    stride_bm,
    stride_bn,
    max_seq_len,
    BLOCK_M: tl.constexpr,
    BLOCK_N: tl.constexpr,
):
    pid_batch = tl.program_id(0)
    pid_row_block = tl.program_id(1)
    batch_offset = tl.load(a_offsets_ptr + pid_batch)
    batch_seq_len = tl.load(a_seq_lengths_ptr + pid_batch)
    truncated_seq_len = tl.minimum(batch_seq_len, max_seq_len)
    offs_row = tl.arange(0, BLOCK_M)
    offs_col = tl.arange(0, BLOCK_N)
    rows = pid_row_block * BLOCK_M + offs_row
    a_ptrs = (
        a_ptr
        + batch_offset * stride_a
        + rows[:, None] * truncated_seq_len
        + offs_col[None, :]
    )
    b_ptrs = b_ptr + rows[:, None] * stride_bm + offs_col[None, :] * stride_bn
    c_ptrs = (
        c_ptr + batch_offset + rows[:, None] * truncated_seq_len + offs_col[None, :]
    )
    for block_start in range(0, truncated_seq_len, BLOCK_N):
        cols = block_start + offs_col
        mask = (rows[:, None] < truncated_seq_len) & (cols[None, :] < truncated_seq_len)
        a = tl.load(a_ptrs, mask=mask)
        a_ptrs += BLOCK_N
        b = tl.load(b_ptrs, mask=mask)
        b_ptrs += BLOCK_N
        c = a * b
        tl.store(c_ptrs, c, mask=mask)
        c_ptrs += BLOCK_N


def test_jagged_dense_elementwise_mul_jagged_out_kernel():
    generator = torch.Generator().manual_seed(20261011)
    a = (torch.randn((13,), generator=generator) * 0.2).to(torch.float32)
    b = (torch.randn((3, 3), generator=generator) * 0.2).to(torch.float32)
    o = torch.full_like(a, 23.0).npu()
    jagged_dense_elementwise_mul_jagged_out_kernel[2, 1](
        a.npu(),
        b.npu(),
        o,
        torch.tensor([2, 3], dtype=torch.int32).npu(),
        torch.tensor([0, 4, 13], dtype=torch.int32).npu(),
        1,
        3,
        1,
        3,
        BLOCK_M=4,
        BLOCK_N=4,
    )
    actual_output = o.cpu()
    expected_output = torch.cat(
        [
            (a[:4].reshape(2, 2) * b[:2, :2]).flatten(),
            (a[4:].reshape(3, 3) * b).flatten(),
        ]
    )
    torch.testing.assert_close(
        (actual_output).double(),
        (expected_output).double(),
        atol=0.0002,
        rtol=0.002,
        check_dtype=False,
    )
    assert torch.isfinite(actual_output).all() and torch.isfinite(expected_output).all()
    print("PASS: jagged_dense_elementwise_mul_jagged_out_kernel")


if __name__ == "__main__":
    test_jagged_dense_elementwise_mul_jagged_out_kernel()

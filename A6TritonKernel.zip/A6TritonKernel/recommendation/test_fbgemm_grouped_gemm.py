# Source: tests/kernels/grouped_gemm.py

import torch
import torch_npu
import triton
import triton.language as tl


@triton.jit
def _fbgemm_grouped_gemm(
    a_desc_ptr,
    b_desc_ptr,
    c_ptr,
    scatter_add_indices,
    m_sizes,
    G: tl.constexpr,
    M_BUCKET,
    N: tl.constexpr,
    K: tl.constexpr,
    NUM_SMS: tl.constexpr,
    FUSE_SCATTER_ADD: tl.constexpr,
    USE_TMA_LOAD: tl.constexpr,
    USE_TMA_STORE: tl.constexpr,
    USE_FAST_ACCUM: tl.constexpr,
    BLOCK_SIZE_M: tl.constexpr,
    BLOCK_SIZE_N: tl.constexpr,
    BLOCK_SIZE_K: tl.constexpr,
    NUM_CONSUMER_GROUPS: tl.constexpr,
) -> None:
    tl.static_assert(
        not (FUSE_SCATTER_ADD and USE_TMA_STORE),
        "Cannot fuse scatter add with TMA store!",
    )
    tidx = tl.program_id(0)
    dtype: tl.dtype = c_ptr.dtype.element_ty
    M_end_offset = 0
    M_end_offset = M_end_offset.to(tl.int64)
    iterated_tiles = 0
    for g in tl.range(G):
        m_size = tl.load(m_sizes + g)
        if m_size > 0:
            M_start_offset = M_end_offset
            M_end_offset = M_start_offset + m_size
            N_start_offset = g.to(tl.int64) * N
            n_size = N
            num_m_tiles = tl.cdiv(m_size, BLOCK_SIZE_M)
            num_n_tiles = tl.cdiv(n_size, BLOCK_SIZE_N)
            num_tiles = num_m_tiles * num_n_tiles
            if USE_TMA_STORE:
                c_desc_ptr = tl.make_tensor_descriptor(
                    c_ptr + M_start_offset * N,
                    shape=[m_size, n_size],
                    strides=[n_size, 1],
                    block_shape=[BLOCK_SIZE_M, BLOCK_SIZE_N],
                )
            while tidx >= iterated_tiles and tidx < iterated_tiles + num_tiles:
                gidx = tidx - iterated_tiles
                tile_m_idx = gidx % num_m_tiles
                tile_n_idx = gidx // num_m_tiles
                accumulator = tl.zeros((BLOCK_SIZE_M, BLOCK_SIZE_N), dtype=tl.float32)
                if USE_TMA_LOAD:
                    tl.static_assert(K % BLOCK_SIZE_K == 0)
                    m_offset = (M_start_offset + tile_m_idx * BLOCK_SIZE_M).to(tl.int32)
                    n_offset = (N_start_offset + tile_n_idx * BLOCK_SIZE_N).to(tl.int32)
                    for k_offset in range(0, K, BLOCK_SIZE_K):
                        a = tl._experimental_descriptor_load(
                            a_desc_ptr,
                            [m_offset, k_offset],
                            [BLOCK_SIZE_M, BLOCK_SIZE_K],
                            dtype,
                        )
                        b = tl._experimental_descriptor_load(
                            b_desc_ptr,
                            [n_offset, k_offset],
                            [BLOCK_SIZE_N, BLOCK_SIZE_K],
                            dtype,
                        )
                        if USE_FAST_ACCUM:
                            accumulator = tl.dot(a, b.T, accumulator)
                        else:
                            accumulator += tl.dot(a, b.T)
                else:
                    offs_am = tile_m_idx * BLOCK_SIZE_M + tl.arange(0, BLOCK_SIZE_M)
                    offs_bn = tile_n_idx * BLOCK_SIZE_N + tl.arange(0, BLOCK_SIZE_N)
                    offs_k = tl.arange(0, BLOCK_SIZE_K)
                    a_ptrs = (
                        a_desc_ptr
                        + (M_start_offset + offs_am[:, None]) * K
                        + offs_k[None, :]
                    )
                    b_ptrs = (
                        b_desc_ptr
                        + (N_start_offset + offs_bn[:, None]) * K
                        + offs_k[None, :]
                    )
                    for k_offset in range(0, K, BLOCK_SIZE_K):
                        updated_k_offset = k_offset + offs_k
                        updated_k_offset_mask = updated_k_offset[None, :] < K
                        a = tl.load(
                            a_ptrs,
                            mask=(offs_am[:, None] < m_size) & updated_k_offset_mask,
                            other=0.0,
                        )
                        b = tl.load(
                            b_ptrs,
                            mask=(offs_bn[:, None] < n_size) & updated_k_offset_mask,
                            other=0.0,
                        )
                        accumulator += tl.dot(a, b.T)
                        a_ptrs += BLOCK_SIZE_K
                        b_ptrs += BLOCK_SIZE_K
                if USE_TMA_STORE:
                    m_offset = (tile_m_idx * BLOCK_SIZE_M).to(tl.int32)
                    n_offset = (tile_n_idx * BLOCK_SIZE_N).to(tl.int32)
                    c_desc_ptr.store(
                        [m_offset, n_offset], accumulator.to(c_ptr.dtype.element_ty)
                    )
                elif FUSE_SCATTER_ADD:
                    offs_am = tile_m_idx * BLOCK_SIZE_M + tl.arange(0, BLOCK_SIZE_M)
                    mask = offs_am < m_size
                    m_offsets = tl.load(
                        scatter_add_indices + M_start_offset + offs_am,
                        mask=mask,
                        cache_modifier=".ca",
                    )
                    offs_bn = tile_n_idx * BLOCK_SIZE_N + tl.arange(0, BLOCK_SIZE_N)
                    c = accumulator.to(c_ptr.dtype.element_ty)
                    tl.atomic_add(
                        c_ptr + m_offsets[:, None] * N + offs_bn[None, :],
                        c,
                        mask=mask[:, None] and offs_bn[None, :] < n_size,
                        sem="relaxed",
                    )
                else:
                    offs_am = tile_m_idx * BLOCK_SIZE_M + tl.arange(0, BLOCK_SIZE_M)
                    offs_bn = tile_n_idx * BLOCK_SIZE_N + tl.arange(0, BLOCK_SIZE_N)
                    c = accumulator.to(c_ptr.dtype.element_ty)
                    tl.store(
                        c_ptr
                        + (M_start_offset + offs_am[:, None]) * N
                        + offs_bn[None, :],
                        c,
                        mask=offs_am[:, None] < m_size and offs_bn[None, :] < n_size,
                    )
                tidx += NUM_SMS
            iterated_tiles += num_tiles


def test_fbgemm_grouped_gemm():
    generator = torch.Generator().manual_seed(20261011)
    g, n, k = (3, 16, 32)
    lengths = torch.tensor([3, 0, 5], dtype=torch.int32)
    dtype = torch.float16
    a = (torch.randn((8, k), generator=generator) * 0.2).to(torch.float32).to(dtype)
    b = (torch.randn((g, n, k), generator=generator) * 0.2).to(torch.float32).to(dtype)
    out = torch.full((8, n), 23.0, dtype=torch.float16).npu()
    indices = torch.arange(8, dtype=torch.int32).npu()
    sizes = lengths.npu()
    opts = dict(
        G=g,
        M_BUCKET=8,
        N=n,
        K=k,
        NUM_SMS=2,
        FUSE_SCATTER_ADD=False,
        USE_TMA_LOAD=False,
        USE_TMA_STORE=False,
        USE_FAST_ACCUM=False,
        BLOCK_SIZE_M=16,
        BLOCK_SIZE_N=16,
        BLOCK_SIZE_K=32,
        NUM_CONSUMER_GROUPS=1,
    )
    args = [a.npu(), b.npu(), out, indices, sizes]
    _fbgemm_grouped_gemm[2,](*args, **opts)
    ref = torch.cat([a[:3].float() @ b[0].float().T, a[3:].float() @ b[2].float().T])
    actual_gemm = out.cpu()
    expected_gemm = ref
    torch.testing.assert_close(
        (actual_gemm).double(),
        (expected_gemm).double(),
        atol=0.0003,
        rtol=0.003,
        check_dtype=False,
    )
    assert torch.isfinite(actual_gemm).all() and torch.isfinite(expected_gemm).all()
    print("PASS: fbgemm_grouped_gemm")


if __name__ == "__main__":
    test_fbgemm_grouped_gemm()

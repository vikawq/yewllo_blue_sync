# Source: tests/kernels/triton_addmm.py

import torch
import torch_npu
import triton
import triton.language as tl
from triton.language.extra.cann.libdevice import fast_dividef


@triton.jit
def _addmm_optional_silu_fwd(
    x_ptr,
    w_ptr,
    y_ptr,
    z_ptr,
    silu_z_ptr,
    M,
    N,
    K,
    stride_xm,
    stride_xk,
    stride_wk,
    stride_wn,
    stride_ym,
    stride_yn,
    stride_zm,
    stride_zn,
    BLOCK_M: tl.constexpr,
    BLOCK_N: tl.constexpr,
    BLOCK_K: tl.constexpr,
    GROUP_M: tl.constexpr,
    ALLOW_TF32: tl.constexpr,
    BROADCAST_Y: tl.constexpr,
    SILU: tl.constexpr,
    KEEP_UNFUSED_OUT: tl.constexpr,
):
    pid_0, pid_1 = (tl.program_id(axis=0), tl.program_id(axis=1))
    pid = pid_0 * tl.num_programs(axis=1) + pid_1
    num_pid_m = tl.cdiv(M, BLOCK_M)
    num_pid_n = tl.cdiv(N, BLOCK_N)
    num_pid_in_group = GROUP_M * num_pid_n
    group_id = pid // num_pid_in_group
    first_pid_m = group_id * GROUP_M
    group_size_m = min(num_pid_m - first_pid_m, GROUP_M)
    pid_m = first_pid_m + pid % group_size_m
    pid_n = pid % num_pid_in_group // group_size_m
    offs_m = tl.arange(0, BLOCK_M)
    offs_k = tl.arange(0, BLOCK_K)
    offs_n = tl.arange(0, BLOCK_N)
    mask_m = (pid_m * BLOCK_M + offs_m)[:, None] < M
    mask_n = (pid_n * BLOCK_N + offs_n)[None, :] < N
    x_ptr += pid_m.to(tl.int64) * BLOCK_M * stride_xm
    x_ptrs = x_ptr + (offs_m[:, None] * stride_xm + offs_k[None, :] * stride_xk)
    w_ptr += pid_n.to(tl.int64) * BLOCK_N * stride_wn
    w_ptrs = w_ptr + (offs_k[:, None] * stride_wk + offs_n[None, :] * stride_wn)
    accumulator = tl.zeros((BLOCK_M, BLOCK_N), dtype=tl.float32)
    for k in range(0, tl.cdiv(K, BLOCK_K)):
        mask_k = offs_k[None, :] < K - k * BLOCK_K
        x = tl.load(x_ptrs, mask=mask_k & mask_m, other=0.0)
        mask_k = offs_k[:, None] < K - k * BLOCK_K
        w = tl.load(w_ptrs, mask=mask_k & mask_n, other=0.0)
        accumulator += tl.dot(x, w, allow_tf32=ALLOW_TF32)
        x_ptrs += BLOCK_K * stride_xk
        w_ptrs += BLOCK_K * stride_wk
    z_mask = mask_m & mask_n
    if BROADCAST_Y:
        y_ptr += pid_n.to(tl.int64) * BLOCK_N * stride_yn
        y_ptrs = y_ptr + stride_yn * offs_n[None, :]
        y = tl.load(y_ptrs, mask=mask_n)
    else:
        y_ptr += pid_m.to(tl.int64) * BLOCK_M * stride_ym
        y_ptr += pid_n.to(tl.int64) * BLOCK_N * stride_yn
        y_ptrs = y_ptr + stride_ym * offs_m[:, None] + stride_yn * offs_n[None, :]
        y = tl.load(y_ptrs, mask=z_mask)
    z = accumulator + y.to(tl.float32)
    if KEEP_UNFUSED_OUT:
        z_ptr += pid_m.to(tl.int64) * BLOCK_M * stride_zm
        z_ptr += pid_n.to(tl.int64) * BLOCK_N * stride_zn
        z_ptrs = z_ptr + stride_zm * offs_m[:, None] + stride_zn * offs_n[None, :]
    if SILU:
        silu_z_ptr += pid_m.to(tl.int64) * BLOCK_M * stride_zm
        silu_z_ptr += pid_n.to(tl.int64) * BLOCK_N * stride_zn
        silu_z_ptrs = (
            silu_z_ptr + stride_zm * offs_m[:, None] + stride_zn * offs_n[None, :]
        )
        sz = z.to(silu_z_ptr.dtype.element_ty)
        silu_z = fast_dividef(sz.to(tl.float32), 1.0 + tl.exp(-sz.to(tl.float32))).to(
            silu_z_ptr.dtype.element_ty
        )
        tl.store(silu_z_ptrs, silu_z, mask=z_mask)
    if KEEP_UNFUSED_OUT:
        tl.store(z_ptrs, z.to(z_ptr.dtype.element_ty), mask=z_mask)


def test_addmm_optional_silu_fwd():
    generator = torch.Generator().manual_seed(20261011)
    x = (torch.randn((3, 16), generator=generator) * 0.2).to(torch.float16)
    w = (torch.randn((16, 16), generator=generator) * 0.2).to(torch.float16)
    for broadcast in (False, True):
        y = (
            (torch.randn((16,), generator=generator) * 0.2).to(torch.float16)
            if broadcast
            else (torch.randn((3, 16), generator=generator) * 0.2).to(torch.float16)
        )
        z = torch.full((3, 16), 23.0, dtype=torch.float16).npu()
        out = torch.full((3, 16), 23.0, dtype=torch.float16).npu()
        _addmm_optional_silu_fwd[1, 1](
            x.npu(),
            w.npu(),
            y.npu(),
            z,
            out,
            3,
            16,
            16,
            16,
            1,
            16,
            1,
            0 if broadcast else 16,
            1,
            16,
            1,
            BLOCK_M=16,
            BLOCK_N=16,
            BLOCK_K=16,
            GROUP_M=1,
            ALLOW_TF32=False,
            BROADCAST_Y=broadcast,
            SILU=True,
            KEEP_UNFUSED_OUT=True,
        )
        expected = (x.float() @ w.float() + y.float()).half()
        actual_output = z.cpu()
        expected_output = expected
        torch.testing.assert_close(
            (actual_output).double(),
            (expected_output).double(),
            atol=0.0002,
            rtol=0.002,
            check_dtype=False,
        )
        assert (
            torch.isfinite(actual_output).all()
            and torch.isfinite(expected_output).all()
        )
        actual_output = out.cpu()
        expected_output = torch.nn.functional.silu(expected.float())
        torch.testing.assert_close(
            (actual_output).double(),
            (expected_output).double(),
            atol=0.0002,
            rtol=0.002,
            check_dtype=False,
        )
        assert (
            torch.isfinite(actual_output).all()
            and torch.isfinite(expected_output).all()
        )
    print("PASS: addmm_optional_silu_fwd")


if __name__ == "__main__":
    test_addmm_optional_silu_fwd()

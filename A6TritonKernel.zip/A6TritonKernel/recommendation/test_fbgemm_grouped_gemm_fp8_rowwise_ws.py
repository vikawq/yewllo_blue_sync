# 来源中的 A6 适配使用带边界掩码的 tl.load，替代 CUDA TMA 描述符加载。
# Source: tests/ports/grouped_gemm_a6.py

import torch
import torch_npu
import triton
import triton.language as tl

TT_FP8_DTYPE = tl.constexpr(tl.float8e4nv)


@triton.jit
def load_2d(
    base, offsets, shape: tl.constexpr, dtype: tl.constexpr, rows, columns: tl.constexpr
):
    row = offsets[0] + tl.arange(0, shape[0])
    col = offsets[1] + tl.arange(0, shape[1])
    return tl.load(
        base + row[:, None] * columns + col[None, :],
        mask=(row[:, None] < rows) & (col[None, :] < columns),
        other=0.0,
    ).to(dtype)


@triton.jit
def _fbgemm_grouped_gemm_fp8_rowwise_ws(
    a_desc_ptr,
    a_scale_ptr,
    b_desc_ptr,
    b_scale_ptr,
    b_scale_desc_ptr,
    c_ptr,
    scatter_add_indices,
    m_sizes,
    G: tl.constexpr,
    M_BUCKET: tl.constexpr,
    N: tl.constexpr,
    K: tl.constexpr,
    NUM_SMS: tl.constexpr,
    FUSE_SCATTER_ADD: tl.constexpr,
    USE_TMA_LOAD: tl.constexpr,
    USE_FAST_ACCUM: tl.constexpr,
    BLOCK_SIZE_M: tl.constexpr,
    BLOCK_SIZE_N: tl.constexpr,
    BLOCK_SIZE_K: tl.constexpr,
    NUM_CONSUMER_GROUPS: tl.constexpr,
    USE_TMA_LOAD_ON_SCALES: tl.constexpr,
    USE_TMA_STORE: tl.constexpr,
) -> None:
    tl.static_assert(USE_TMA_LOAD, "Always use TMA load with warp specialziation!")
    tl.static_assert(
        not (FUSE_SCATTER_ADD and USE_TMA_STORE),
        "Cannot fuse scatter add with TMA store!",
    )
    tidx = tl.program_id(0)
    dtype = TT_FP8_DTYPE
    M_end_offset = 0
    M_end_offset = M_end_offset.to(tl.int64)
    iterated_tiles = 0
    for g in tl.range(G):
        m_size = tl.load(m_sizes + g, cache_modifier=".ca")
        if m_size > 0:
            M_start_offset = M_end_offset
            M_end_offset = M_start_offset + m_size
            N_start_offset = g.to(tl.int64) * N
            num_m_tiles = tl.cdiv(m_size, BLOCK_SIZE_M)
            tl.static_assert(N % BLOCK_SIZE_N == 0)
            NUM_N_TILES: tl.constexpr = N // BLOCK_SIZE_N
            num_tiles = num_m_tiles * NUM_N_TILES
            if USE_TMA_STORE:
                c_desc_ptr = tl.make_tensor_descriptor(
                    c_ptr + M_start_offset * N,
                    shape=[m_size, N],
                    strides=[N, 1],
                    block_shape=[BLOCK_SIZE_M, BLOCK_SIZE_N],
                )
            next_iterated_tiles = iterated_tiles + num_tiles
            if tidx >= iterated_tiles and tidx < next_iterated_tiles:
                for i in range(tidx, next_iterated_tiles, NUM_SMS):
                    gidx = i - iterated_tiles
                    tile_m_idx = gidx % num_m_tiles
                    tile_n_idx = gidx // num_m_tiles
                    accumulator = tl.zeros(
                        (BLOCK_SIZE_M, BLOCK_SIZE_N), dtype=tl.float32
                    )
                    tl.static_assert(K % BLOCK_SIZE_K == 0)
                    m_offset = (M_start_offset + tile_m_idx * BLOCK_SIZE_M).to(tl.int32)
                    n_offset = (N_start_offset + tile_n_idx * BLOCK_SIZE_N).to(tl.int32)
                    for k_offset in range(0, K, BLOCK_SIZE_K):
                        a = load_2d(
                            a_desc_ptr,
                            [m_offset, k_offset],
                            [BLOCK_SIZE_M, BLOCK_SIZE_K],
                            dtype,
                            M_end_offset,
                            K,
                        )
                        b = load_2d(
                            b_desc_ptr,
                            [n_offset, k_offset],
                            [BLOCK_SIZE_N, BLOCK_SIZE_K],
                            dtype,
                            (g + 1) * N,
                            K,
                        )
                        if USE_FAST_ACCUM:
                            accumulator = tl.dot(a, b.T, accumulator)
                        else:
                            accumulator += tl.dot(a, b.T)
                    offs_am = tile_m_idx * BLOCK_SIZE_M + tl.arange(0, BLOCK_SIZE_M)
                    offs_bn = tile_n_idx * BLOCK_SIZE_N + tl.arange(0, BLOCK_SIZE_N)
                    a_scale = tl.load(
                        a_scale_ptr + M_start_offset + offs_am[:, None],
                        mask=offs_am[:, None] < m_size,
                        cache_modifier=".ca",
                    )
                    b_scale = tl.load(
                        b_scale_ptr + N_start_offset + offs_bn[None, :],
                        cache_modifier=".ca",
                    )
                    c = accumulator.to(tl.float32) * a_scale * b_scale
                    if USE_TMA_STORE:
                        m_offset = (tile_m_idx * BLOCK_SIZE_M).to(tl.int32)
                        n_offset = (tile_n_idx * BLOCK_SIZE_N).to(tl.int32)
                        c_desc_ptr.store(
                            [m_offset, n_offset], c.to(c_ptr.dtype.element_ty)
                        )
                    elif FUSE_SCATTER_ADD:
                        offs_am = tile_m_idx * BLOCK_SIZE_M + tl.arange(0, BLOCK_SIZE_M)
                        mask = offs_am < m_size
                        m_offsets = tl.load(
                            scatter_add_indices + M_start_offset + offs_am,
                            mask=mask,
                            cache_modifier=".ca",
                        )
                        offs_bn = tile_n_idx * BLOCK_SIZE_N + tl.arange(0, BLOCK_SIZE_N)
                        tl.atomic_add(
                            c_ptr + m_offsets[:, None] * N + offs_bn[None, :],
                            c,
                            mask=mask[:, None],
                            sem="relaxed",
                        )
                    else:
                        offs_am = tile_m_idx * BLOCK_SIZE_M + tl.arange(0, BLOCK_SIZE_M)
                        offs_bn = tile_n_idx * BLOCK_SIZE_N + tl.arange(0, BLOCK_SIZE_N)
                        tl.store(
                            c_ptr
                            + (M_start_offset + offs_am[:, None]) * N
                            + offs_bn[None, :],
                            c,
                            mask=offs_am[:, None] < m_size,
                            cache_modifier=".cs",
                        )
                    tidx += NUM_SMS
            iterated_tiles += num_tiles


def test_fbgemm_grouped_gemm_fp8_rowwise_ws():
    generator = torch.Generator().manual_seed(20261011)
    g, n, k = (3, 16, 32)
    lengths = torch.tensor([3, 0, 5], dtype=torch.int32)
    dtype = torch.float8_e4m3fn
    a = (torch.randn((8, k), generator=generator) * 0.2).to(torch.float32).to(dtype)
    b = (torch.randn((g, n, k), generator=generator) * 0.2).to(torch.float32).to(dtype)
    sa = torch.linspace(0.5, 1.2, 8)
    sb = torch.linspace(0.7, 1.3, g * n).reshape(g, n)
    out = torch.full((8, n), 23.0, dtype=torch.float16).npu()
    indices = torch.arange(8, dtype=torch.int32).npu()
    sizes = lengths.npu()
    opts = dict(
        G=g,
        M_BUCKET=8,
        N=n,
        K=k,
        NUM_SMS=2,
        FUSE_SCATTER_ADD=False,
        USE_TMA_LOAD=True,
        USE_TMA_STORE=False,
        USE_FAST_ACCUM=False,
        BLOCK_SIZE_M=16,
        BLOCK_SIZE_N=16,
        BLOCK_SIZE_K=32,
        NUM_CONSUMER_GROUPS=1,
    )
    opts["USE_TMA_LOAD_ON_SCALES"] = False
    args = [a.npu(), sa.npu(), b.npu(), sb.npu(), None, out, indices, sizes]
    _fbgemm_grouped_gemm_fp8_rowwise_ws[2,](*args, **opts)
    ref = torch.cat([a[:3].float() @ b[0].float().T, a[3:].float() @ b[2].float().T])
    ref = ref * sa[:, None] * torch.cat([sb[0].expand(3, n), sb[2].expand(5, n)])
    actual_gemm = out.cpu()
    expected_gemm = ref
    torch.testing.assert_close(
        (actual_gemm).double(),
        (expected_gemm).double(),
        atol=0.0003,
        rtol=0.003,
        check_dtype=False,
    )
    assert torch.isfinite(actual_gemm).all() and torch.isfinite(expected_gemm).all()
    print("PASS: fbgemm_grouped_gemm_fp8_rowwise_ws")


if __name__ == "__main__":
    test_fbgemm_grouped_gemm_fp8_rowwise_ws()

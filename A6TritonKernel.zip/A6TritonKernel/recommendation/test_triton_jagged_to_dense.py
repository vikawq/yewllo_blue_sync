# Source: tests/kernels/triton_jagged_tensor_ops.py

import torch
import torch_npu
import triton
import triton.language as tl


@triton.jit
def tensor_elementwise_add(x, y):
    return x + y


@triton.jit
def tensor_elementwise_mul(x, y):
    return x * y


@triton.jit
def triton_jagged_to_dense(
    jagged_value_ptr,
    jagged_offsets_ptr,
    jagged_value_row_stride,
    output_dense_ptr,
    dense_indices_ptr,
    dense_col_stride,
    dense_row_stride,
    dense_matrix_stride,
    JAGGED_DIM: tl.constexpr,
    thread_block_row_size: tl.constexpr,
    thread_block_col_size: tl.constexpr,
    operation_function: tl.constexpr,
    operation_dense,
) -> None:
    pid = tl.program_id(0)
    begin = tl.load(jagged_offsets_ptr + pid)
    end = tl.load(jagged_offsets_ptr + (pid + 1))
    jagged_value_ptr += begin * jagged_value_row_stride
    if JAGGED_DIM > 2:
        dense_indice = tl.load(dense_indices_ptr + pid)
        if dense_indice == -1:
            return
        output_dense_ptr += dense_indice
        if operation_function is not None:
            operation_dense += dense_indice
    else:
        output_dense_ptr += pid * dense_matrix_stride
        if operation_function is not None:
            operation_dense += pid * dense_matrix_stride
    offset_row = tl.arange(0, thread_block_row_size)
    N = tl.minimum(dense_row_stride, jagged_value_row_stride)
    M = tl.minimum(dense_matrix_stride // dense_row_stride, end - begin)
    for _i in range(begin, end, thread_block_row_size):
        offset_col = tl.arange(0, thread_block_col_size)
        block_offset = (
            offset_row[:, None] * dense_row_stride
            + offset_col[None, :] * dense_col_stride
        )
        for _j in range(0, N, thread_block_col_size):
            mask = (offset_row[:, None] < M) & (offset_col[None, :] < N)
            jagged_val = tl.load(jagged_value_ptr + block_offset, mask=mask, other=0)
            if operation_function is not None:
                val1 = jagged_val
                val2 = tl.load(operation_dense + block_offset, mask=mask, other=0)
                if operation_function == "add":
                    jagged_val = tensor_elementwise_add(val1, val2)
                else:
                    jagged_val = tensor_elementwise_mul(val1, val2)
            tl.store(output_dense_ptr + block_offset, jagged_val, mask=mask)
            offset_col += thread_block_col_size
            block_offset += thread_block_col_size
        offset_row += thread_block_row_size


def test_triton_jagged_to_dense():
    generator = torch.Generator().manual_seed(20261011)
    off = torch.tensor([0, 3, 3, 8], dtype=torch.int32)
    x = (torch.randn((8, 7), generator=generator) * 0.2).to(torch.float32)
    dense = torch.full((3, 4, 7), -2.0)
    dense[0, :3] = x[:3]
    dense[2, :4] = x[3:7]
    out = torch.full((3, 4, 7), -2.0).npu()
    triton_jagged_to_dense[3,](
        x.npu(),
        off.npu(),
        7,
        out,
        None,
        1,
        7,
        28,
        JAGGED_DIM=2,
        thread_block_row_size=4,
        thread_block_col_size=8,
        operation_function=None,
        operation_dense=None,
    )
    expected = dense
    actual_converted = out.cpu()
    expected_converted = expected
    torch.testing.assert_close(
        (actual_converted).double(),
        (expected_converted).double(),
        atol=0,
        rtol=0,
        check_dtype=False,
    )
    assert (
        torch.isfinite(actual_converted).all()
        and torch.isfinite(expected_converted).all()
    )
    print("PASS: triton_jagged_to_dense")


if __name__ == "__main__":
    test_triton_jagged_to_dense()

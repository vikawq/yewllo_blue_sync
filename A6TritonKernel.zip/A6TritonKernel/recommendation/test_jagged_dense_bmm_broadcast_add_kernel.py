# Source: tests/kernels/triton_jagged.py

import torch
import torch_npu
import triton
import triton.language as tl


@triton.jit
def jagged_dense_bmm_broadcast_add_kernel(
    seq_offsets,
    Jagged,
    Dense,
    Bias,
    Out,
    AUTOTUNE_MAX_SEQ_LEN,
    N,
    K,
    stride_jm,
    stride_db,
    stride_dk,
    stride_dn,
    stride_bias_b,
    stride_om,
    HAS_BIAS: tl.constexpr,
    ALLOW_TF32: tl.constexpr,
    BLOCK_M: tl.constexpr,
    BLOCK_N: tl.constexpr,
    BLOCK_K: tl.constexpr,
):
    """
    Computing bmm Out = Jagged x Dense + Bias
    M is the jagged dimension
    Jagged has shape (sum_B(M_i), K), Dense has shape (B, K, N), Bias has shape (B, N), and Out has shape (sum_B(M_i), N)
    """
    off_n = tl.program_id(0)
    off_m = tl.program_id(1)
    off_b = tl.program_id(2)
    seq_start = tl.load(seq_offsets + off_b).to(tl.int64)
    seq_end = tl.load(seq_offsets + off_b + 1)
    seq_len = seq_end - seq_start
    start_m = off_m * BLOCK_M
    start_n = off_n * BLOCK_N
    if start_m >= seq_len:
        return
    Jagged += seq_start * stride_jm
    Dense += off_b.to(tl.int64) * stride_db
    Out += seq_start * stride_om
    offs_m = start_m + tl.arange(0, BLOCK_M)
    offs_n = start_n + tl.arange(0, BLOCK_N)
    offs_k = tl.arange(0, BLOCK_K)
    jg_ptrs = Jagged + offs_m[:, None] * stride_jm + offs_k[None, :]
    dn_ptrs = Dense + offs_k[:, None] * stride_dk + offs_n[None, :] * stride_dn
    accumulator = tl.zeros((BLOCK_M, BLOCK_N), dtype=tl.float32)
    for k in range(0, K, BLOCK_K):
        jg = tl.load(
            jg_ptrs,
            mask=offs_m[:, None] < seq_len and (k + offs_k)[None, :] < K,
            other=0.0,
        )
        dn = tl.load(
            dn_ptrs, mask=(k + offs_k)[:, None] < K and offs_n[None, :] < N, other=0.0
        )
        accumulator += tl.dot(jg, dn, allow_tf32=ALLOW_TF32)
        jg_ptrs += BLOCK_K
        dn_ptrs += BLOCK_K * stride_dk
    if HAS_BIAS:
        bias_ptrs = Bias + off_b * stride_bias_b + offs_n
        bias = tl.load(bias_ptrs, mask=offs_n < N)
        accumulator += bias[None, :].to(tl.float32)
    out = accumulator.to(Out.dtype.element_ty)
    offs_m = start_m + tl.arange(0, BLOCK_M)
    offs_n = start_n + tl.arange(0, BLOCK_N)
    out_ptrs = Out + offs_m[:, None] * stride_om + offs_n[None, :]
    tl.store(out_ptrs, out, mask=(offs_m[:, None] < seq_len) & (offs_n[None, :] < N))


def test_jagged_dense_bmm_broadcast_add_kernel():
    generator = torch.Generator().manual_seed(20261011)
    x = (torch.randn((8, 16), generator=generator) * 0.2).to(torch.float16)
    w = (torch.randn((3, 16, 16), generator=generator) * 0.2).to(torch.float16)
    b = (torch.randn((3, 16), generator=generator) * 0.2).to(torch.float16)
    o = torch.full((8, 16), 23.0, dtype=torch.float16).npu()
    jagged_dense_bmm_broadcast_add_kernel[1, 1, 3](
        torch.tensor([0, 3, 3, 8], dtype=torch.int32).npu(),
        x.npu(),
        w.npu(),
        b.npu(),
        o,
        5,
        16,
        16,
        16,
        256,
        16,
        1,
        16,
        16,
        HAS_BIAS=True,
        ALLOW_TF32=False,
        BLOCK_M=16,
        BLOCK_N=16,
        BLOCK_K=16,
    )
    actual_output = o.cpu()
    expected_output = torch.cat(
        [
            x[:3].float() @ w[0].float() + b[0].float(),
            x[3:].float() @ w[2].float() + b[2].float(),
        ]
    )
    torch.testing.assert_close(
        (actual_output).double(),
        (expected_output).double(),
        atol=0.0002,
        rtol=0.002,
        check_dtype=False,
    )
    assert torch.isfinite(actual_output).all() and torch.isfinite(expected_output).all()
    print("PASS: jagged_dense_bmm_broadcast_add_kernel")


if __name__ == "__main__":
    test_jagged_dense_bmm_broadcast_add_kernel()

# Source: tests/kernels/triton_position.py

import torch
import torch_npu
import triton
import triton.language as tl


@triton.jit
def _add_position_embeddings_bwd_kernel(
    Jagged,
    seq_offsets,
    high_inds,
    DenseOut,
    JaggedOut,
    B,
    D,
    scale,
    stride_jn,
    stride_jon,
    stride_don,
    SCALE_JAGGED: tl.constexpr,
    BLOCK_D: tl.constexpr,
):
    off_k = tl.program_id(0)
    offs_d = tl.arange(0, BLOCK_D)
    accumulator = tl.zeros((BLOCK_D,), dtype=tl.float32)
    for off_b in range(0, B):
        max_ind = tl.load(high_inds + off_b)
        if off_k < max_ind:
            seq_start = tl.load(seq_offsets + off_b)
            jagged_ptr = (
                Jagged
                + seq_start.to(tl.int64) * stride_jn
                + off_k.to(tl.int64) * stride_jn
            )
            jagged_ptrs = jagged_ptr + offs_d
            jg = tl.load(jagged_ptrs, mask=offs_d < D)
            accumulator += jg
            if SCALE_JAGGED:
                out_jagged_ptr = (
                    JaggedOut
                    + seq_start.to(tl.int64) * stride_jon
                    + off_k.to(tl.int64) * stride_jon
                )
                out_jagged_ptrs = out_jagged_ptr + offs_d
                tl.store(out_jagged_ptrs, jg * scale, mask=offs_d < D)
        elif off_k == max_ind:
            seq_start = tl.load(seq_offsets + off_b).to(tl.int64)
            seq_end = tl.load(seq_offsets + off_b + 1)
            for k in range(seq_start + max_ind, seq_end):
                jagged_ptr = Jagged + k * stride_jn
                jagged_ptrs = jagged_ptr + offs_d
                jg = tl.load(jagged_ptrs, mask=offs_d < D)
                accumulator += jg
                if SCALE_JAGGED:
                    out_jagged_ptr = JaggedOut + k * stride_jon
                    out_jagged_ptrs = out_jagged_ptr + offs_d
                    tl.store(out_jagged_ptrs, jg * scale, mask=offs_d < D)
    out = accumulator.to(DenseOut.dtype.element_ty)
    out_ptrs = DenseOut + off_k * stride_don + offs_d
    tl.store(out_ptrs, out, mask=offs_d < D)


def test_add_position_embeddings_bwd_kernel():
    generator = torch.Generator().manual_seed(20261011)
    offsets = torch.tensor([0, 3, 3, 8], dtype=torch.int32)
    high = torch.tensor([1, 0, 2], dtype=torch.int32)
    x = (torch.randn((8, 7), generator=generator) * 0.2).to(torch.float32)
    emb = (torch.randn((3, 7), generator=generator) * 0.2).to(torch.float32)
    out = torch.full_like(x, 23.0).npu()
    ids = torch.tensor([0, 1, 1, 0, 1, 2, 2, 2])
    scale = 0.75
    de = torch.full_like(emb, 23.0).npu()
    _add_position_embeddings_bwd_kernel[3,](
        x.npu(),
        offsets.npu(),
        high.npu(),
        de,
        out,
        3,
        7,
        scale,
        7,
        7,
        7,
        SCALE_JAGGED=True,
        BLOCK_D=8,
    )
    ref = torch.zeros_like(emb).index_add_(0, ids, x)
    actual_embedding_grad = de.cpu()
    expected_embedding_grad = ref
    torch.testing.assert_close(
        (actual_embedding_grad).double(),
        (expected_embedding_grad).double(),
        atol=0.0002,
        rtol=0.002,
        check_dtype=False,
    )
    assert (
        torch.isfinite(actual_embedding_grad).all()
        and torch.isfinite(expected_embedding_grad).all()
    )
    actual_input_grad = out.cpu()
    expected_input_grad = x * scale
    torch.testing.assert_close(
        (actual_input_grad).double(),
        (expected_input_grad).double(),
        atol=0.0002,
        rtol=0.002,
        check_dtype=False,
    )
    assert (
        torch.isfinite(actual_input_grad).all()
        and torch.isfinite(expected_input_grad).all()
    )
    print("PASS: add_position_embeddings_bwd_kernel")


if __name__ == "__main__":
    test_add_position_embeddings_bwd_kernel()

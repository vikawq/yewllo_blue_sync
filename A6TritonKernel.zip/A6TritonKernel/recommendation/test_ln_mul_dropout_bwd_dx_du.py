# Source: tests/kernels/triton_norm_mul_dropout.py

import torch
import torch_npu
import triton
import triton.language as tl


@triton.jit
def _ln_mul_dropout_bwd_dx_du(
    DX,
    DU,
    DY,
    DW,
    DB,
    X,
    U,
    Y,
    W,
    B,
    Mean,
    Rstd,
    stride_dx,
    stride_du0,
    stride_du1,
    stride_dy,
    stride_x,
    stride_u0,
    stride_u1,
    stride_y,
    D,
    eps,
    seed,
    dropout_ratio,
    N,
    NUM_U_SLICES: tl.constexpr,
    UD: tl.constexpr,
    BLOCK_D: tl.constexpr,
    TRAINING: tl.constexpr,
    CONCAT_UX: tl.constexpr,
    COMPUTE_Y: tl.constexpr,
):
    pid = tl.program_id(0)
    tile_num = tl.num_programs(0)
    rows_per_tile = N // tile_num
    if pid < N % tile_num:
        rows_per_tile += 1
    if rows_per_tile == 0:
        return
    cols = tl.arange(0, BLOCK_D)
    mask = cols < D
    row = pid
    X += row.to(tl.int64) * stride_x
    U += row.to(tl.int64) * stride_u0
    if COMPUTE_Y:
        Y += row.to(tl.int64) * stride_y
    DY += row.to(tl.int64) * stride_dy
    DX += row.to(tl.int64) * stride_dx
    DU += row.to(tl.int64) * stride_du0
    DW = DW + pid * D + cols
    DB = DB + pid * D + cols
    for idx in range(0, rows_per_tile):
        x = tl.load(X + cols, mask=mask, other=0).to(tl.float32)
        if CONCAT_UX:
            du = tl.load(DY + cols, mask=mask, other=0).to(tl.float32)
            dx = tl.load(DY + D + cols, mask=mask, other=0).to(tl.float32)
            dy = tl.load(DY + 2 * D + cols, mask=mask, other=0).to(tl.float32)
        else:
            du = tl.zeros([BLOCK_D], dtype=tl.float32)
            dx = tl.zeros([BLOCK_D], dtype=tl.float32)
            dy = tl.load(DY + cols, mask=mask, other=0).to(tl.float32)
        if TRAINING:
            random_offsets = row * BLOCK_D + cols
            if CONCAT_UX:
                random_du = tl.rand(seed, random_offsets)
                du_keep = (random_du > dropout_ratio) | (dropout_ratio == 0.0)
                du = tl.where(du_keep, du / (1.0 - dropout_ratio), 0.0)
                random_dx = tl.rand(seed, random_offsets + D)
                dx_keep = (random_dx > dropout_ratio) | (dropout_ratio == 0.0)
                dx = tl.where(dx_keep, dx / (1.0 - dropout_ratio), 0.0)
                random_dy = tl.rand(seed, random_offsets + 2 * D)
                dy_keep = (random_dy > dropout_ratio) | (dropout_ratio == 0.0)
                dy = tl.where(dy_keep, dy / (1.0 - dropout_ratio), 0.0)
            else:
                random = tl.rand(seed, random_offsets)
                dy_keep = (random > dropout_ratio) | (dropout_ratio == 0.0)
                dy = tl.where(dy_keep, dy / (1.0 - dropout_ratio), 0.0)
        mean = tl.load(Mean + row)
        rstd = tl.load(Rstd + row)
        xhat = (x - mean) * rstd
        w = tl.load(W + cols, mask=mask).to(tl.float32)
        b = tl.load(B + cols, mask=mask).to(tl.float32)
        ln = xhat * w + b
        du += dy * ln
        if NUM_U_SLICES > 1:
            du = du.reshape(NUM_U_SLICES, UD)
            u_tile_offsets = tl.arange(0, NUM_U_SLICES)
            u_inner_offsets = tl.arange(0, UD)
            offsets_2d = u_tile_offsets[:, None] * stride_du1 + u_inner_offsets[None, :]
            u_mask = (u_tile_offsets[:, None] < NUM_U_SLICES) & (
                u_inner_offsets[None, :] < UD
            )
            tl.store(DU + offsets_2d, du, mask=u_mask)
        else:
            tl.store(DU + cols, du.to(DU.dtype.element_ty), mask=mask)
        if NUM_U_SLICES > 1:
            u_tile_offsets = tl.arange(0, NUM_U_SLICES)
            u_inner_offsets = tl.arange(0, UD)
            offsets_2d = u_tile_offsets[:, None] * stride_u1 + u_inner_offsets[None, :]
            u_mask = (u_tile_offsets[:, None] < NUM_U_SLICES) & (
                u_inner_offsets[None, :] < UD
            )
            u = tl.load(U + offsets_2d, mask=u_mask, other=0.0).to(tl.float32)
            u = u.reshape(NUM_U_SLICES * UD)
        else:
            u = tl.load(U + cols, mask=cols < D, other=0.0).to(tl.float32)
        dy = dy * u
        wdy = w * dy
        if COMPUTE_Y:
            y = ln * u
            if TRAINING:
                if CONCAT_UX:
                    u = tl.where(du_keep, u / (1.0 - dropout_ratio), 0.0)
                    x = tl.where(dx_keep, x / (1.0 - dropout_ratio), 0.0)
                    y = tl.where(dy_keep, y / (1.0 - dropout_ratio), 0.0)
                else:
                    y = tl.where(dy_keep, y / (1.0 - dropout_ratio), 0.0)
            if CONCAT_UX:
                tl.store(Y + cols, u.to(Y.dtype.element_ty), mask=mask)
                tl.store(Y + D + cols, x.to(Y.dtype.element_ty), mask=mask)
                tl.store(Y + 2 * D + cols, y.to(Y.dtype.element_ty), mask=mask)
            else:
                tl.store(Y + cols, y.to(Y.dtype.element_ty), mask=mask)
            Y += tile_num.to(tl.int64) * stride_y
        xhat = tl.where(mask, xhat, 0.0)
        wdy = tl.where(mask, wdy, 0.0)
        c1 = tl.sum(xhat * wdy, axis=0) / D
        c2 = tl.sum(wdy, axis=0) / D
        dx += (wdy - (xhat * c1 + c2)) * rstd
        tl.store(DX + cols, dx, mask=mask)
        partial_dw = dy * xhat
        partial_db = dy
        if idx > 0:
            partial_dw += tl.load(DW, mask=mask)
            partial_db += tl.load(DB, mask=mask)
        tl.store(DW, partial_dw, mask=mask)
        tl.store(DB, partial_db, mask=mask)
        X += tile_num.to(tl.int64) * stride_x
        U += tile_num.to(tl.int64) * stride_u0
        DY += tile_num.to(tl.int64) * stride_dy
        DX += tile_num.to(tl.int64) * stride_dx
        DU += tile_num.to(tl.int64) * stride_du0
        row += tile_num


def philox_uniform(seed, count):
    """CPU Philox4x32-10 reference for tl.rand."""
    values = []
    mask = (1 << 32) - 1
    for offset in range(count):
        c0, c1, c2, c3 = (offset, 0, 0, 0)
        k0, k1 = (seed & mask, seed >> 32 & mask)
        for _ in range(10):
            a = 3528531795 * c0
            b = 3449720151 * c2
            c0, c1, c2, c3 = (
                (b >> 32 ^ c1 ^ k0) & mask,
                b & mask,
                (a >> 32 ^ c3 ^ k1) & mask,
                a & mask,
            )
            k0 = k0 + 2654435769 & mask
            k1 = k1 + 3144134277 & mask
        value = c0 if c0 < 1 << 31 else mask - c0
        values.append(value)
    return torch.tensor(values, dtype=torch.float32) * torch.tensor(
        4.6566127342e-10, dtype=torch.float32
    )


def test_ln_mul_dropout_bwd_dx_du():
    generator = torch.Generator().manual_seed(20261011)
    n, h, d = (3, 1, 7)
    width = h * d
    x = (torch.randn((n, h, d), generator=generator) * 0.2).to(torch.float32)
    u = (torch.randn((n, h, d), generator=generator) * 0.2).to(torch.float32)
    w = (torch.randn((d,), generator=generator) * 0.2).to(torch.float32) + 1
    b = (torch.randn((d,), generator=generator) * 0.2).to(torch.float32)
    mean = x.mean(-1)
    rs = (x.var(-1, unbiased=False) + 1e-05).rsqrt()
    xh = (x - mean[..., None]) * rs[..., None]
    wa = w
    ba = b
    dropout = 0.25
    randoms = philox_uniform(123, n * 8).reshape(n, 1, 8)[..., :d]
    factor = (randoms > dropout).float() / (1 - dropout)
    y = (xh * wa + ba) * u * factor
    out = torch.full_like(x, 23.0).npu()
    dy = (torch.randn((n, h, d), generator=generator) * 0.2).to(torch.float32)
    dx = torch.full_like(x, 23.0).npu()
    du = torch.full_like(u, 23.0).npu()
    dw = torch.zeros(n, d).npu()
    db = torch.zeros(n, d).npu()
    xx = x.double().requires_grad_()
    uu = u.double().requires_grad_()
    ww = w.double().requires_grad_()
    bb = b.double().requires_grad_()
    yy = torch.nn.functional.layer_norm(xx, (d,), None, None, 1e-05) * ww + bb
    yy = yy * uu * factor.double()
    (yy * dy.double()).sum().backward()
    _ln_mul_dropout_bwd_dx_du[n,](
        dx,
        du,
        dy.npu(),
        dw,
        db,
        x.npu(),
        u.npu(),
        out,
        w.npu(),
        b.npu(),
        mean.npu(),
        rs.npu(),
        width,
        width,
        1,
        width,
        width,
        width,
        1,
        width,
        d,
        1e-05,
        123,
        dropout,
        N=n,
        NUM_U_SLICES=1,
        UD=d,
        BLOCK_D=8,
        TRAINING=True,
        CONCAT_UX=False,
        COMPUTE_Y=True,
    )
    actual_dx = dx.cpu()
    expected_dx = xx.grad
    torch.testing.assert_close(
        (actual_dx).double(),
        (expected_dx).double(),
        atol=0.0002,
        rtol=0.002,
        check_dtype=False,
    )
    assert torch.isfinite(actual_dx).all() and torch.isfinite(expected_dx).all()
    actual_du = du.cpu()
    expected_du = uu.grad
    torch.testing.assert_close(
        (actual_du).double(),
        (expected_du).double(),
        atol=0.0002,
        rtol=0.002,
        check_dtype=False,
    )
    assert torch.isfinite(actual_du).all() and torch.isfinite(expected_du).all()
    actual_y = out.cpu()
    expected_y = y
    torch.testing.assert_close(
        (actual_y).double(),
        (expected_y).double(),
        atol=0.0002,
        rtol=0.002,
        check_dtype=False,
    )
    assert torch.isfinite(actual_y).all() and torch.isfinite(expected_y).all()
    actual_dw = dw.cpu()
    expected_dw = (dy * factor * u * xh).reshape(n, d)
    torch.testing.assert_close(
        (actual_dw).double(),
        (expected_dw).double(),
        atol=0.0002,
        rtol=0.002,
        check_dtype=False,
    )
    assert torch.isfinite(actual_dw).all() and torch.isfinite(expected_dw).all()
    actual_db = db.cpu()
    expected_db = (dy * factor * u).reshape(n, d)
    torch.testing.assert_close(
        (actual_db).double(),
        (expected_db).double(),
        atol=0.0002,
        rtol=0.002,
        check_dtype=False,
    )
    assert torch.isfinite(actual_db).all() and torch.isfinite(expected_db).all()
    print("PASS: ln_mul_dropout_bwd_dx_du")


if __name__ == "__main__":
    test_ln_mul_dropout_bwd_dx_du()

# Source: tests/kernels/triton_jagged_tensor_ops.py

import torch
import torch_npu
import triton
import triton.language as tl


@triton.jit
def triton_batched_dense_vec_jagged_2d_matmul(
    jagged_tensor_ptr,
    dense_ptr,
    jagged_offset,
    thread_block_col_size: tl.constexpr,
    dense_row_stride,
    jagged_value_row_stride,
    D,
    H: tl.constexpr,
    output_ptr,
) -> None:
    pid = tl.program_id(0)
    GRID_DIM_COL = (D + thread_block_col_size - 1) // thread_block_col_size
    output_row_idx = pid // GRID_DIM_COL
    jagged_offset_id = output_row_idx // H
    D_refer_idx = output_row_idx % H
    group_id = pid % GRID_DIM_COL
    offset = group_id * thread_block_col_size + tl.arange(0, thread_block_col_size)
    begin = tl.load(jagged_offset + jagged_offset_id)
    end = tl.load(jagged_offset + (jagged_offset_id + 1))
    dense_ptr += output_row_idx * dense_row_stride
    jagged_tensor_ptr += begin * jagged_value_row_stride + D_refer_idx * D
    output_ptr += D * output_row_idx
    num_row = tl.minimum(end - begin, dense_row_stride)
    acc = tl.zeros((thread_block_col_size,), dtype=tl.float32)
    mask = offset < D
    for i in range(num_row):
        val1 = tl.load(dense_ptr + i)
        val2 = tl.load(jagged_tensor_ptr + offset, mask=mask, other=0.0)
        result = val1 * val2
        acc += result
        jagged_tensor_ptr += jagged_value_row_stride
    tl.store(output_ptr + offset, acc, mask=mask)


def test_triton_batched_dense_vec_jagged_2d_matmul():
    generator = torch.Generator().manual_seed(20261011)
    x = (torch.randn((8, 14), generator=generator) * 0.2).to(torch.float32)
    v = (torch.randn((6, 5), generator=generator) * 0.2).to(torch.float32)
    o = torch.full((6, 7), 23.0).npu()
    expected = torch.zeros(6, 7)
    for batch, (start, end) in enumerate([(0, 3), (3, 3), (3, 8)]):
        for h in range(2):
            expected[batch * 2 + h] = (
                v[batch * 2 + h, : end - start] @ x[start:end, h * 7 : (h + 1) * 7]
            )
    triton_batched_dense_vec_jagged_2d_matmul[6,](
        x.npu(),
        v.npu(),
        torch.tensor([0, 3, 3, 8], dtype=torch.int32).npu(),
        8,
        5,
        14,
        7,
        2,
        o,
    )
    actual_output = o.cpu()
    expected_output = expected
    torch.testing.assert_close(
        (actual_output).double(),
        (expected_output).double(),
        atol=0.0002,
        rtol=0.002,
        check_dtype=False,
    )
    assert torch.isfinite(actual_output).all() and torch.isfinite(expected_output).all()
    print("PASS: triton_batched_dense_vec_jagged_2d_matmul")


if __name__ == "__main__":
    test_triton_batched_dense_vec_jagged_2d_matmul()

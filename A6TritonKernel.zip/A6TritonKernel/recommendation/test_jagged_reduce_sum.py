# Source: tests/kernels/triton_jagged.py

import torch
import torch_npu
import triton
import triton.language as tl


@triton.jit
def jagged_reduce_sum(
    seq_offsets, Jagged, Out, D, stride_jn, stride_ob, BLOCK_D: tl.constexpr
):
    """
    Computing Out = Jagged + Dense
    JaggedA has shape (sum_B(N_i), D), Dense has shape (B, D), and Out has shape (sum_B(N_i), D)
    """
    off_b = tl.program_id(0)
    off_d = tl.program_id(1) * BLOCK_D
    seq_start = tl.load(seq_offsets + off_b)
    seq_end = tl.load(seq_offsets + off_b + 1)
    seq_len = seq_end - seq_start
    Jagged += seq_start * stride_jn
    Out += off_b * stride_ob
    offs_d = off_d + tl.arange(0, BLOCK_D)
    jagged_ptrs = Jagged + offs_d
    out_ptrs = Out + offs_d
    accumulator = tl.zeros((BLOCK_D,), dtype=tl.float32)
    for _ in range(0, seq_len):
        jg = tl.load(jagged_ptrs, mask=offs_d < D)
        accumulator += jg
        jagged_ptrs += stride_jn
    out = accumulator.to(Out.dtype.element_ty)
    tl.store(out_ptrs, out, mask=offs_d < D)


def test_jagged_reduce_sum():
    generator = torch.Generator().manual_seed(20261011)
    x = (torch.randn((8, 7), generator=generator) * 0.2).to(torch.float32)
    o = torch.full((3, 7), 23.0).npu()
    jagged_reduce_sum[3, 1](
        torch.tensor([0, 3, 3, 8], dtype=torch.int32).npu(),
        x.npu(),
        o,
        7,
        7,
        7,
        BLOCK_D=8,
    )
    actual_output = o.cpu()
    expected_output = torch.stack([x[:3].sum(0), torch.zeros(7), x[3:].sum(0)])
    torch.testing.assert_close(
        (actual_output).double(),
        (expected_output).double(),
        atol=0.0002,
        rtol=0.002,
        check_dtype=False,
    )
    assert torch.isfinite(actual_output).all() and torch.isfinite(expected_output).all()
    print("PASS: jagged_reduce_sum")


if __name__ == "__main__":
    test_jagged_reduce_sum()

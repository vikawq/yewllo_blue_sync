# Source: tests/kernels/triton_silu.py

import torch
import torch_npu
import triton
import triton.language as tl


@triton.jit
def _silu_backward(
    grad_input_ptr: tl.tensor,
    grad_output_ptr: tl.tensor,
    input_ptr: tl.tensor,
    x_size: tl.int32,
    x_block_size: tl.constexpr,
):
    x_offset = tl.program_id(0) * x_block_size
    mask = x_offset + tl.arange(0, x_block_size) < x_size
    grad_input_ptr += x_offset
    grad_output_ptr += x_offset
    input_ptr += x_offset
    cols = tl.arange(0, x_block_size)
    grad_output = tl.load(grad_output_ptr + cols, mask=mask, other=0.0).to(tl.float32)
    input = tl.load(input_ptr + cols, mask=mask, other=0.0).to(tl.float32)
    sigma = tl.sigmoid(input)
    grad_input = grad_output * (sigma + input * sigma * (1 - sigma))
    tl.store(
        grad_input_ptr + cols, grad_input.to(grad_input_ptr.dtype.element_ty), mask=mask
    )


def test_silu_backward():
    generator = torch.Generator().manual_seed(20261011)
    x = torch.linspace(-8, 8, 259)
    dy = (torch.randn((259,), generator=generator) * 0.2).to(torch.float32)
    storage = torch.full((264,), 23.0).npu()
    sigma = x.sigmoid()
    _silu_backward[2,](storage, dy.npu(), x.npu(), 259, x_block_size=256)
    expected = dy * (sigma + x * sigma * (1 - sigma))
    actual_silu = storage[:259].cpu()
    expected_silu = expected
    torch.testing.assert_close(
        (actual_silu).double(),
        (expected_silu).double(),
        atol=0.0002,
        rtol=0.002,
        check_dtype=False,
    )
    assert torch.isfinite(actual_silu).all() and torch.isfinite(expected_silu).all()
    actual_guard = storage[259:].cpu()
    expected_guard = torch.full((5,), 23.0)
    torch.testing.assert_close(
        (actual_guard).double(),
        (expected_guard).double(),
        atol=0,
        rtol=0,
        check_dtype=False,
    )
    assert torch.isfinite(actual_guard).all() and torch.isfinite(expected_guard).all()
    print("PASS: silu_backward")


if __name__ == "__main__":
    test_silu_backward()

# Source: tests/kernels/triton_norm_mul_dropout.py

import torch
import torch_npu
import triton
import triton.language as tl


@triton.jit
def _group_norm_mul_dropout_fwd(
    X,
    U,
    Y,
    W,
    B,
    Mean,
    Rstd,
    D,
    Heads,
    eps,
    seed,
    dropout_ratio,
    stride_x,
    stride_u0,
    stride_y,
    BLOCK_D: tl.constexpr,
    BLOCK_H: tl.constexpr,
    TRAINING: tl.constexpr,
    CONCAT_UX: tl.constexpr,
):
    row = tl.program_id(0)
    X += row.to(tl.int64) * stride_x
    U += row.to(tl.int64) * stride_u0
    Y += row.to(tl.int64) * stride_y
    cols = tl.arange(0, BLOCK_D)
    heads = tl.arange(0, BLOCK_H)
    offsets = heads[:, None] * D + cols[None, :]
    mask_h = heads < Heads
    mask_c = cols < D
    mask = mask_c[None, :] & mask_h[:, None]
    mean = 0.0
    x = tl.load(X + offsets, mask=mask, other=0.0).to(tl.float32)
    mean = tl.sum(x, axis=1) / D
    mean = tl.ravel(mean)
    _var = tl.zeros([BLOCK_H, BLOCK_D], dtype=tl.float32)
    x_mean = tl.where(mask, x - mean[:, None], 0.0)
    _var += x_mean * x_mean
    var = tl.sum(_var, axis=1) / D
    var = tl.ravel(var)
    rstd = 1 / tl.sqrt(var + eps)
    tl.store(Mean + row * Heads + heads, mean, mask=mask_h)
    tl.store(Rstd + row * Heads + heads, rstd, mask=mask_h)
    y = x_mean * rstd[:, None]
    w = tl.load(W + heads, mask=mask_h).to(tl.float32)
    b = tl.load(B + heads, mask=mask_h).to(tl.float32)
    y = y * w[:, None] + b[:, None]
    u = tl.load(U + offsets, mask=mask, other=0.0).to(tl.float32)
    y = y * u
    if TRAINING:
        if CONCAT_UX:
            random_offsets = row * 3 * D * Heads + offsets
            random_u = tl.rand(seed, random_offsets)
            u_keep = (random_u > dropout_ratio) | (dropout_ratio == 0.0)
            u = tl.where(u_keep, u / (1.0 - dropout_ratio), 0.0)
            random_x = tl.rand(seed, random_offsets + Heads * D)
            x_keep = (random_x > dropout_ratio) | (dropout_ratio == 0.0)
            x = tl.where(x_keep, x / (1.0 - dropout_ratio), 0.0)
            random_y = tl.rand(seed, random_offsets + 2 * Heads * D)
            y_keep = (random_y > dropout_ratio) | (dropout_ratio == 0.0)
            y = tl.where(y_keep, y / (1.0 - dropout_ratio), 0.0)
        else:
            random_offsets = row * D * Heads + offsets
            random = tl.rand(seed, random_offsets)
            y_keep = (random > dropout_ratio) | (dropout_ratio == 0.0)
            y = tl.where(y_keep, y / (1.0 - dropout_ratio), 0.0)
    if CONCAT_UX:
        tl.store(Y + offsets, u.to(Y.dtype.element_ty), mask=mask)
        tl.store(Y + Heads * D + offsets, x.to(Y.dtype.element_ty), mask=mask)
        tl.store(Y + 2 * Heads * D + offsets, y.to(Y.dtype.element_ty), mask=mask)
    else:
        tl.store(Y + offsets, y.to(Y.dtype.element_ty), mask=mask)


def philox_uniform(seed, count):
    """CPU Philox4x32-10 reference for tl.rand."""
    values = []
    mask = (1 << 32) - 1
    for offset in range(count):
        c0, c1, c2, c3 = (offset, 0, 0, 0)
        k0, k1 = (seed & mask, seed >> 32 & mask)
        for _ in range(10):
            a = 3528531795 * c0
            b = 3449720151 * c2
            c0, c1, c2, c3 = (
                (b >> 32 ^ c1 ^ k0) & mask,
                b & mask,
                (a >> 32 ^ c3 ^ k1) & mask,
                a & mask,
            )
            k0 = k0 + 2654435769 & mask
            k1 = k1 + 3144134277 & mask
        value = c0 if c0 < 1 << 31 else mask - c0
        values.append(value)
    return torch.tensor(values, dtype=torch.float32) * torch.tensor(
        4.6566127342e-10, dtype=torch.float32
    )


def test_group_norm_mul_dropout_fwd():
    generator = torch.Generator().manual_seed(20261011)
    n, h, d = (3, 2, 7)
    width = h * d
    x = (torch.randn((n, h, d), generator=generator) * 0.2).to(torch.float32)
    u = (torch.randn((n, h, d), generator=generator) * 0.2).to(torch.float32)
    w = (torch.randn((h,), generator=generator) * 0.2).to(torch.float32) + 1
    b = (torch.randn((h,), generator=generator) * 0.2).to(torch.float32)
    mean = x.mean(-1)
    rs = (x.var(-1, unbiased=False) + 1e-05).rsqrt()
    xh = (x - mean[..., None]) * rs[..., None]
    wa = w[None, :, None]
    ba = b[None, :, None]
    dropout = 0.25
    randoms = philox_uniform(123, n * h * d).reshape(n, h, d)
    factor = (randoms > dropout).float() / (1 - dropout)
    y = (xh * wa + ba) * u * factor
    out = torch.full_like(x, 23.0).npu()
    mn = torch.full_like(mean, 23.0).npu()
    rstd = torch.full_like(rs, 23.0).npu()
    _group_norm_mul_dropout_fwd[n,](
        x.npu(),
        u.npu(),
        out,
        w.npu(),
        b.npu(),
        mn,
        rstd,
        d,
        h,
        1e-05,
        123,
        dropout,
        width,
        width,
        width,
        BLOCK_D=8,
        BLOCK_H=2,
        TRAINING=True,
        CONCAT_UX=False,
    )
    actual_y = out.cpu()
    expected_y = y
    torch.testing.assert_close(
        (actual_y).double(),
        (expected_y).double(),
        atol=0.0002,
        rtol=0.002,
        check_dtype=False,
    )
    assert torch.isfinite(actual_y).all() and torch.isfinite(expected_y).all()
    actual_mean = mn.cpu()
    expected_mean = mean
    torch.testing.assert_close(
        (actual_mean).double(),
        (expected_mean).double(),
        atol=0.0002,
        rtol=0.002,
        check_dtype=False,
    )
    assert torch.isfinite(actual_mean).all() and torch.isfinite(expected_mean).all()
    actual_rstd = rstd.cpu()
    expected_rstd = rs
    torch.testing.assert_close(
        (actual_rstd).double(),
        (expected_rstd).double(),
        atol=0.0002,
        rtol=0.002,
        check_dtype=False,
    )
    assert torch.isfinite(actual_rstd).all() and torch.isfinite(expected_rstd).all()
    print("PASS: group_norm_mul_dropout_fwd")


if __name__ == "__main__":
    test_group_norm_mul_dropout_fwd()

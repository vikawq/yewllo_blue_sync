# Source: tests/kernels/triton_jagged_bmm.py

import torch
import torch_npu
import triton
import triton.language as tl


@triton.jit
def jagged_dense_bmm_kernel(
    a_ptr,
    a_offset_ptr,
    b_ptr,
    c_ptr,
    N,
    K,
    stride_am,
    stride_ak,
    stride_bl,
    stride_bk,
    stride_bn,
    stride_cm,
    stride_cn,
    max_seq_len,
    allow_tf32: tl.constexpr,
    BLOCK_SIZE_M: tl.constexpr,
    BLOCK_SIZE_N: tl.constexpr,
    BLOCK_SIZE_K: tl.constexpr,
):
    """Kernel for computing the matmul C = A x B.
    A has shape (sum_B(M_i), K), B has shape (B, K, N) and C has shape (sum_B(M_i), N)
    """
    pid_batch = tl.program_id(0)
    pid = tl.program_id(1)
    begin = tl.load(a_offset_ptr + pid_batch)
    end = tl.load(a_offset_ptr + pid_batch + 1)
    M = tl.minimum(end - begin, max_seq_len)
    if M == 0:
        return
    num_pid_n = tl.cdiv(N, BLOCK_SIZE_N)
    pid_m = pid // num_pid_n
    pid_n = pid % num_pid_n
    offs_am = pid_m * BLOCK_SIZE_M + tl.arange(0, BLOCK_SIZE_M)
    if pid_m * BLOCK_SIZE_M >= M:
        return
    offs_bn = pid_n * BLOCK_SIZE_N + tl.arange(0, BLOCK_SIZE_N)
    if pid_n * BLOCK_SIZE_N >= N:
        return
    offs_k = tl.arange(0, BLOCK_SIZE_K)
    a_ptrs = a_ptr + (
        offs_am[:, None] * stride_am + offs_k[None, :] * stride_ak + begin * stride_am
    )
    b_ptrs = b_ptr + (
        offs_k[:, None] * stride_bk
        + offs_bn[None, :] * stride_bn
        + pid_batch * stride_bl
    )
    c = tl.zeros((BLOCK_SIZE_M, BLOCK_SIZE_N), dtype=tl.float32)
    for k in range(0, K, BLOCK_SIZE_K):
        updated_offset = k + offs_k
        a = tl.load(
            a_ptrs,
            mask=(updated_offset[None, :] < K) & (offs_am[:, None] < M),
            other=0.0,
        )
        b = tl.load(
            b_ptrs,
            mask=(updated_offset[:, None] < K) & (offs_bn[None, :] < N),
            other=0.0,
        )
        c += tl.dot(a, b, allow_tf32=allow_tf32)
        a_ptrs += BLOCK_SIZE_K * stride_ak
        b_ptrs += BLOCK_SIZE_K * stride_bk
    offs_m = pid_m * BLOCK_SIZE_M + tl.arange(0, BLOCK_SIZE_M)
    offs_n = pid_n * BLOCK_SIZE_N + tl.arange(0, BLOCK_SIZE_N)
    mask = (offs_m[:, None] < M) & (offs_n[None, :] < N)
    c_ptrs = (
        c_ptr
        + stride_cm * offs_m[:, None]
        + stride_cn * offs_n[None, :]
        + begin * stride_cm
    )
    tl.store(c_ptrs, c, mask=mask)


def test_jagged_dense_bmm_kernel():
    generator = torch.Generator().manual_seed(20261011)
    offset = torch.tensor([0, 3, 3, 8], dtype=torch.int32)
    a = (torch.randn((8, 16), generator=generator) * 0.2).to(torch.float16)
    b = (torch.randn((3, 16, 16), generator=generator) * 0.2).to(torch.float16)
    out = torch.full((8, 16), 23.0, dtype=torch.float16).npu()
    jagged_dense_bmm_kernel[3, 1](
        a.npu(),
        offset.npu(),
        b.npu(),
        out,
        16,
        16,
        16,
        1,
        256,
        16,
        1,
        16,
        1,
        5,
        allow_tf32=False,
        BLOCK_SIZE_M=16,
        BLOCK_SIZE_N=16,
        BLOCK_SIZE_K=16,
    )
    expected = torch.cat([a[:3].float() @ b[0].float(), a[3:].float() @ b[2].float()])
    actual_bmm = out.cpu()
    expected_bmm = expected
    torch.testing.assert_close(
        (actual_bmm).double(),
        (expected_bmm).double(),
        atol=0.0002,
        rtol=0.002,
        check_dtype=False,
    )
    assert torch.isfinite(actual_bmm).all() and torch.isfinite(expected_bmm).all()
    print("PASS: jagged_dense_bmm_kernel")


if __name__ == "__main__":
    test_jagged_dense_bmm_kernel()

# Source: tests/kernels/triton_jagged.py

import torch
import torch_npu
import triton
import triton.language as tl


@triton.jit
def split_2D_jagged_w_prefix(
    JaggedIn,
    DenseSize,
    OffsetsA,
    OffsetsB,
    OutA,
    OutB,
    D,
    stride_id,
    stride_ad,
    stride_bd,
    n_prefix_to_B,
    IS_DENSE_A: tl.constexpr,
    IS_DENSE_B: tl.constexpr,
    BLOCK_D: tl.constexpr,
    IS_REPLACE: tl.constexpr,
):
    off_z = tl.program_id(1)
    off_n = tl.program_id(0)
    if IS_DENSE_A:
        seq_start_b = tl.load(OffsetsB + off_z)
        seq_end_b = tl.load(OffsetsB + off_z + 1)
        seq_start_a = off_z * DenseSize
        seq_len_a = DenseSize
        seq_len_b = seq_end_b - seq_start_b
    elif IS_DENSE_B:
        seq_start_a = tl.load(OffsetsA + off_z)
        seq_end_a = tl.load(OffsetsA + off_z + 1)
        seq_len_a = seq_end_a - seq_start_a
        seq_start_b = off_z * DenseSize
        seq_len_b = DenseSize
    else:
        seq_start_a = tl.load(OffsetsA + off_z)
        seq_end_a = tl.load(OffsetsA + off_z + 1)
        seq_len_a = seq_end_a - seq_start_a
        seq_start_b = tl.load(OffsetsB + off_z)
        seq_end_b = tl.load(OffsetsB + off_z + 1)
        seq_len_b = seq_end_b - seq_start_b
    if IS_REPLACE:
        seq_len = seq_len_a
    else:
        seq_len = seq_len_a + seq_len_b
    if off_n >= seq_len:
        return
    if IS_REPLACE:
        seq_start = seq_start_a
        out_seq_b_start = seq_len_a - seq_len_b
    else:
        seq_start = seq_start_a + seq_start_b
        out_seq_b_start = seq_len_a + n_prefix_to_B
    offs_d = tl.arange(0, BLOCK_D)
    in_ptrs = JaggedIn + (seq_start + off_n).to(tl.int64) * stride_id + offs_d
    if off_n < out_seq_b_start and off_n >= n_prefix_to_B:
        off_a = off_n - n_prefix_to_B
        out_ptrs = OutA + (off_a + seq_start_a).to(tl.int64) * stride_ad + offs_d
    else:
        off_b = off_n - out_seq_b_start + n_prefix_to_B
        if off_n < n_prefix_to_B:
            off_b += out_seq_b_start - n_prefix_to_B
        out_ptrs = OutB + (off_b + seq_start_b).to(tl.int64) * stride_bd + offs_d
    v = tl.load(in_ptrs, mask=offs_d < D)
    tl.store(out_ptrs, v, mask=offs_d < D)


def test_split_2d_jagged_w_prefix():
    generator = torch.Generator().manual_seed(20261011)
    a = (torch.randn((3, 7), generator=generator) * 0.2).to(torch.float32)
    b = (torch.randn((5, 7), generator=generator) * 0.2).to(torch.float32)
    oa = torch.tensor([0, 2, 3], dtype=torch.int32).npu()
    ob = torch.tensor([0, 3, 5], dtype=torch.int32).npu()
    prefix = 1
    chunks = []
    for aa, bb in [(a[:2], b[:3]), (a[2:], b[3:])]:
        chunks.append(torch.cat([bb[:prefix], aa, bb[prefix:]]))
    merged = torch.cat(chunks)
    outa = torch.full_like(a, 23.0).npu()
    outb = torch.full_like(b, 23.0).npu()
    args = (merged.npu(), 0, oa, ob, outa, outb, 7, 7, 7, 7)
    args += (prefix,)
    split_2D_jagged_w_prefix[5, 2](
        *args, IS_DENSE_A=False, IS_DENSE_B=False, BLOCK_D=8, IS_REPLACE=False
    )
    actual_a = outa.cpu()
    expected_a = a
    torch.testing.assert_close(
        (actual_a).double(), (expected_a).double(), atol=0, rtol=0, check_dtype=False
    )
    assert torch.isfinite(actual_a).all() and torch.isfinite(expected_a).all()
    actual_b = outb.cpu()
    expected_b = b
    torch.testing.assert_close(
        (actual_b).double(), (expected_b).double(), atol=0, rtol=0, check_dtype=False
    )
    assert torch.isfinite(actual_b).all() and torch.isfinite(expected_b).all()
    print("PASS: split_2D_jagged_w_prefix")


if __name__ == "__main__":
    test_split_2d_jagged_w_prefix()

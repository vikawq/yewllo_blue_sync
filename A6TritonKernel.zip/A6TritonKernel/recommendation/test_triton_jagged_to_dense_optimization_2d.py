# Source: tests/kernels/triton_jagged_tensor_ops.py

import torch
import torch_npu
import triton
import triton.language as tl


@triton.jit
def triton_jagged_to_dense_optimization_2d(
    input_jagged_values_ptr,
    input_jagged_offset_ptr,
    input_jagged_row_stride,
    output_dense_ptr,
    output_dense_row_stride,
    output_dense_matrix_stride,
    thread_block_row_size: tl.constexpr,
    thread_block_col_size: tl.constexpr,
    padded_value,
    operation_function: tl.constexpr,
    operation_dense,
) -> None:
    pid = tl.program_id(0)
    offset_idx = pid
    begin = tl.load(input_jagged_offset_ptr + offset_idx)
    end = tl.load(input_jagged_offset_ptr + offset_idx + 1)
    cur_jagged_tensor_row_size = end - begin
    output_dense_ptr += pid * output_dense_matrix_stride
    input_jagged_values_ptr += begin * input_jagged_row_stride
    if operation_function is not None:
        operation_dense += pid * output_dense_matrix_stride
    offset_row = tl.arange(0, thread_block_row_size)
    dense_col_size = output_dense_row_stride
    dense_row_size = output_dense_matrix_stride // output_dense_row_stride
    for _i in range(0, dense_row_size, thread_block_row_size):
        offset_col = tl.arange(0, thread_block_col_size)
        block_offset = (
            offset_row[:, None] * output_dense_row_stride + offset_col[None, :]
        )
        for _j in range(0, dense_col_size, thread_block_col_size):
            dense_mask = (offset_row[:, None] < dense_row_size) & (
                offset_col[None, :] < dense_col_size
            )
            jagged_mask = (offset_row[:, None] < cur_jagged_tensor_row_size) & (
                offset_col[None, :] < input_jagged_row_stride
            )
            jagged_val = tl.load(
                input_jagged_values_ptr + block_offset,
                mask=jagged_mask,
                other=padded_value,
            )
            if operation_function is not None:
                operation_dense_val = tl.load(
                    operation_dense + block_offset, mask=dense_mask, other=0.0
                )
                jagged_val = operation_function(operation_dense_val, jagged_val)
            tl.store(output_dense_ptr + block_offset, jagged_val, mask=dense_mask)
            offset_col += thread_block_col_size
            block_offset += thread_block_col_size
        offset_row += thread_block_row_size


def test_triton_jagged_to_dense_optimization_2d():
    generator = torch.Generator().manual_seed(20261011)
    off = torch.tensor([0, 3, 3, 8], dtype=torch.int32)
    x = (torch.randn((8, 7), generator=generator) * 0.2).to(torch.float32)
    dense = torch.full((3, 4, 7), -2.0)
    dense[0, :3] = x[:3]
    dense[2, :4] = x[3:7]
    out = torch.full((3, 4, 7), 23.0).npu()
    triton_jagged_to_dense_optimization_2d[3,](
        x.npu(),
        off.npu(),
        7,
        out,
        7,
        28,
        thread_block_row_size=4,
        thread_block_col_size=8,
        padded_value=-2.0,
        operation_function=None,
        operation_dense=None,
    )
    expected = dense
    actual_converted = out.cpu()
    expected_converted = expected
    torch.testing.assert_close(
        (actual_converted).double(),
        (expected_converted).double(),
        atol=0,
        rtol=0,
        check_dtype=False,
    )
    assert (
        torch.isfinite(actual_converted).all()
        and torch.isfinite(expected_converted).all()
    )
    print("PASS: triton_jagged_to_dense_optimization_2d")


if __name__ == "__main__":
    test_triton_jagged_to_dense_optimization_2d()

# Source: tests/kernels/triton_layer_norm.py

import torch
import torch_npu
import triton
import triton.language as tl


@triton.jit
def _rms_norm_bwd_dwdb(
    DW, FINAL_DW, N, D, BLOCK_N: tl.constexpr, BLOCK_D: tl.constexpr
):
    pid = tl.program_id(0)
    cols = pid * BLOCK_D + tl.arange(0, BLOCK_D)
    dw = tl.zeros((BLOCK_N, BLOCK_D), dtype=tl.float32)
    for i in range(0, N, BLOCK_N):
        rows = i + tl.arange(0, BLOCK_N)
        mask = (rows[:, None] < N) & (cols[None, :] < D)
        offs = rows[:, None] * D + cols[None, :]
        dw += tl.load(DW + offs, mask=mask, other=0.0)
    sum_dw = tl.sum(dw, axis=0)
    tl.store(FINAL_DW + cols, sum_dw.to(FINAL_DW.dtype.element_ty), mask=cols < D)


def test_rms_norm_bwd_dwdb():
    generator = torch.Generator().manual_seed(20261011)
    dw = (torch.randn((5, 7), generator=generator) * 0.2).to(torch.float32)
    db = (torch.randn((5, 7), generator=generator) * 0.2).to(torch.float32)
    outw = torch.full((7,), 23.0).npu()
    _rms_norm_bwd_dwdb[1,](dw.npu(), outw, 5, 7, BLOCK_N=4, BLOCK_D=8)
    actual_dw = outw.cpu()
    expected_dw = dw.sum(0)
    torch.testing.assert_close(
        (actual_dw).double(),
        (expected_dw).double(),
        atol=0.0002,
        rtol=0.002,
        check_dtype=False,
    )
    assert torch.isfinite(actual_dw).all() and torch.isfinite(expected_dw).all()
    print("PASS: rms_norm_bwd_dwdb")


if __name__ == "__main__":
    test_rms_norm_bwd_dwdb()

# Source: tests/kernels/triton_position.py

import torch
import torch_npu
import triton
import triton.language as tl


@triton.jit
def _add_embeddings_bwd_kernel(
    In,
    KeyInds,
    ValueInds,
    Out,
    AUTOTUNE_MAX_SEQ_LEN,
    B,
    AUTOTUNE_B,
    D,
    jagged_size,
    stride_in,
    stride_on,
    BLOCK_D: tl.constexpr,
    BLOCK: tl.constexpr,
):
    off_block = tl.program_id(0)
    offs_d = tl.arange(0, BLOCK_D)
    mask_d = offs_d < D
    key_ind = -1
    key_ind = key_ind.to(KeyInds.dtype.element_ty)
    accumulator = tl.zeros((BLOCK_D,), dtype=In.dtype.element_ty)
    for off_i in range(0, BLOCK):
        off = off_block * BLOCK + off_i
        if off < jagged_size:
            value_ind = tl.load(ValueInds + off)
            in_offset = In + value_ind.to(tl.int64) * stride_in
            jagged_in = tl.load(in_offset + offs_d, mask=mask_d)
            key_ind_new = tl.load(KeyInds + off)
            if key_ind == key_ind_new:
                accumulator += jagged_in
            else:
                if key_ind >= 0:
                    out_offset = Out + key_ind.to(tl.int64) * stride_on
                    tl.atomic_add(
                        out_offset + offs_d,
                        accumulator.to(Out.dtype.element_ty),
                        mask=mask_d,
                        sem="relaxed",
                    )
                key_ind = key_ind_new
                accumulator = jagged_in
    if key_ind >= 0:
        out_offset = Out + key_ind.to(tl.int64) * stride_on
        tl.atomic_add(
            out_offset + offs_d,
            accumulator.to(Out.dtype.element_ty),
            mask=mask_d,
            sem="relaxed",
        )


def test_add_embeddings_bwd_kernel():
    generator = torch.Generator().manual_seed(20261011)
    x = (torch.randn((8, 7), generator=generator) * 0.2).to(torch.float32)
    keys = torch.tensor([0, 0, 1, 1, 1, 3, 3, 3], dtype=torch.int32)
    values = torch.tensor([2, 5, 0, 1, 7, 3, 4, 6], dtype=torch.int32)
    out = torch.zeros(5, 7).npu()
    _add_embeddings_bwd_kernel[2,](
        x.npu(), keys.npu(), values.npu(), out, 5, 3, 4, 7, 8, 7, 7, BLOCK_D=8, BLOCK=4
    )
    actual_embedding_grad = out.cpu()
    expected_embedding_grad = torch.zeros(5, 7).index_add_(
        0, keys.long(), x[values.long()]
    )
    torch.testing.assert_close(
        (actual_embedding_grad).double(),
        (expected_embedding_grad).double(),
        atol=0.0002,
        rtol=0.002,
        check_dtype=False,
    )
    assert (
        torch.isfinite(actual_embedding_grad).all()
        and torch.isfinite(expected_embedding_grad).all()
    )
    print("PASS: add_embeddings_bwd_kernel")


if __name__ == "__main__":
    test_add_embeddings_bwd_kernel()

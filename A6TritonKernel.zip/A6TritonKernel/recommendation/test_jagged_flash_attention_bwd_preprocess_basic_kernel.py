# Source: tests/kernels/triton_jagged_flash_attention_basic.py

import torch
import torch_npu
import triton
import triton.language as tl


@triton.jit
def _jagged_flash_attention_bwd_preprocess_basic_kernel(
    o_ptr,
    o_offset_ptr,
    do_ptr,
    delta_ptr,
    stride_om,
    stride_od,
    max_seq_len,
    D: tl.constexpr,
    BLOCK_SIZE_M: tl.constexpr,
    BLOCK_SIZE_D: tl.constexpr,
):
    pid_m = tl.program_id(axis=0)
    pid_batch = tl.program_id(axis=1)
    begin_o = tl.load(o_offset_ptr + pid_batch)
    end_o = tl.load(o_offset_ptr + pid_batch + 1)
    M = end_o - begin_o
    M = tl.minimum(M, max_seq_len)
    offs_om = pid_m * BLOCK_SIZE_M + tl.arange(0, BLOCK_SIZE_M)
    offs_od = tl.arange(0, BLOCK_SIZE_D)
    o_offsets = (
        offs_om[:, None] * stride_om
        + offs_od[None, :] * stride_od
        + begin_o * stride_om
    )
    o_ptrs = o_ptr + o_offsets
    do_ptrs = do_ptr + o_offsets
    o_mask = (offs_om[:, None] < M) & (offs_od[None, :] < D)
    o = tl.load(o_ptrs, mask=o_mask)
    do = tl.load(do_ptrs, mask=o_mask)
    delta = tl.sum(o * do, axis=1)
    tl.store(delta_ptr + begin_o + offs_om, delta, mask=offs_om < M)


def test_jagged_flash_attention_bwd_preprocess_basic_kernel():
    generator = torch.Generator().manual_seed(20261011)
    h = 1
    d = 16
    total = 8
    maxseq = 5
    offset = torch.tensor([0, 3, 3, 8], dtype=torch.int32)
    q = (torch.randn((h, total, d), generator=generator) * 0.2).to(torch.float16)
    k = (torch.randn((h, total, d), generator=generator) * 0.2).to(torch.float16)
    v = (torch.randn((h, total, d), generator=generator) * 0.2).to(torch.float16)
    dy = (torch.randn((h, total, d), generator=generator) * 0.2).to(torch.float16)
    qq = q.double()
    kk = k.double()
    vv = v.double()
    outs = []
    ls = []
    for a, b in [(0, 3), (3, 8)]:
        score = qq[:, a:b] @ kk[:, a:b].transpose(-1, -2)
        p = score.softmax(-1)
        outs.append(p @ vv[:, a:b] / maxseq)
        ls.append(score.logsumexp(-1))
    ref = torch.cat(outs, 1)
    lse = torch.cat(ls, 1).float()
    o = ref.detach().half()
    delta = (o.float() * dy.float()).sum(-1)
    lo = torch.full_like(lse, 23.0).npu()
    offs = offset.npu()
    opts = dict(D=d, allow_tf32=False)
    opts.update(use_mask=False, BLOCK_SIZE_M=16, BLOCK_SIZE_N=16, BLOCK_SIZE_D=16)
    _jagged_flash_attention_bwd_preprocess_basic_kernel[1, 3](
        o.npu(),
        offs,
        dy.npu(),
        lo,
        16,
        1,
        maxseq,
        D=d,
        BLOCK_SIZE_M=16,
        BLOCK_SIZE_D=16,
    )
    actual_delta = lo.cpu()
    expected_delta = delta
    torch.testing.assert_close(
        (actual_delta).double(),
        (expected_delta).double(),
        atol=0.0002,
        rtol=0.002,
        check_dtype=False,
    )
    assert torch.isfinite(actual_delta).all() and torch.isfinite(expected_delta).all()
    print("PASS: jagged_flash_attention_bwd_preprocess_basic_kernel")


if __name__ == "__main__":
    test_jagged_flash_attention_bwd_preprocess_basic_kernel()

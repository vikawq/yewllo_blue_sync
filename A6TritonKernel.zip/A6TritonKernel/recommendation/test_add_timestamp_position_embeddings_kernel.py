# Source: tests/kernels/triton_position.py

import torch
import torch_npu
import triton
import triton.language as tl


@triton.jit
def _add_timestamp_position_embeddings_kernel(
    SeqEmb,
    Offsets,
    Lengths,
    PosEmb,
    TsEmb,
    Out,
    TS,
    PosInds,
    TsInds,
    NumTargets,
    AUTOTUNE_MAX_SEQ_LEN,
    D,
    num_time_buckets,
    time_bucket_increments,
    time_bucket_scale,
    time_delta,
    max_contextual_seq_len,
    max_pos_ind,
    stride_sn,
    stride_pn,
    stride_tn,
    stride_on,
    TRAINING: tl.constexpr,
    HAS_MULTIPLE_TARGETS: tl.constexpr,
    INTERLEAVE_TARGETS: tl.constexpr,
    TIME_BUCKET_FN: tl.constexpr,
    BLOCK_D: tl.constexpr,
    BLOCK_N: tl.constexpr,
):
    """
    SeqEmb has shape (sum_B(N_i), D),
    PosEmb has shape (N_p, D),
    TsEmb has shape (N_t, D),
    Out has shape (sum_B(N_i), D)
    """
    off_b = tl.program_id(0)
    off_n = tl.program_id(1)
    seq_start = tl.load(Offsets + off_b)
    seq_end = tl.load(Offsets + off_b + 1)
    seq_len = seq_end - seq_start
    start_n = off_n * BLOCK_N
    if start_n >= seq_len:
        return
    offs_n = start_n + tl.arange(0, BLOCK_N)
    offs_d = tl.arange(0, BLOCK_D)
    seq_emb_offsets = offs_n[:, None] * stride_sn + offs_d[None, :]
    SeqEmb += seq_start.to(tl.int64) * stride_sn
    mask_n = offs_n < seq_len
    seq_len = tl.load(Lengths + off_b)
    if HAS_MULTIPLE_TARGETS:
        num_targets = tl.load(NumTargets + off_b)
        if INTERLEAVE_TARGETS:
            high_ind = seq_len - num_targets * 2
        else:
            high_ind = seq_len - num_targets
    else:
        high_ind = seq_len
    pos_inds = tl.where(offs_n < high_ind, offs_n, high_ind)
    pos_inds = high_ind - pos_inds + max_contextual_seq_len
    pos_inds = tl.where(pos_inds < max_pos_ind - 1, pos_inds, max_pos_ind - 1)
    pos_inds = tl.where(offs_n < max_contextual_seq_len, offs_n, pos_inds)
    if TRAINING:
        tl.store(PosInds + seq_start + offs_n, pos_inds, mask=mask_n)
    pos_emb_offsets = pos_inds[:, None] * stride_pn + offs_d[None, :]
    ts = tl.load(TS + seq_start + offs_n, mask=mask_n)
    query_time = tl.load(TS + seq_end - 1)
    ts = query_time - ts + time_delta
    ts = tl.where(ts > 1e-06, ts, 1e-06) / time_bucket_increments
    if TIME_BUCKET_FN == "log":
        ts = tl.log(ts)
    else:
        ts = tl.sqrt(ts)
    ts = ts * time_bucket_scale
    ts = ts.to(tl.int32)
    ts = tl.where(ts > 0, ts, 0)
    ts = tl.where(ts < num_time_buckets, ts, num_time_buckets)
    if TRAINING:
        tl.store(TsInds + seq_start + offs_n, ts, mask=mask_n)
    ts_emb_offsets = ts[:, None] * stride_tn + offs_d[None, :]
    Out += seq_start.to(tl.int64) * stride_on
    out_offsets = Out + offs_n[:, None] * stride_on + offs_d[None, :]
    for _d in range(0, D, BLOCK_D):
        mask = (offs_n[:, None] < seq_len) & (offs_d[None, :] < D)
        seq_emb = tl.load(SeqEmb + seq_emb_offsets, mask=mask)
        pos_emb = tl.load(PosEmb + pos_emb_offsets, mask=mask)
        ts_emb = tl.load(TsEmb + ts_emb_offsets, mask=mask)
        tl.store(out_offsets, seq_emb + (pos_emb + ts_emb).to(seq_emb.dtype), mask=mask)
        seq_emb_offsets += BLOCK_D
        pos_emb_offsets += BLOCK_D
        ts_emb_offsets += BLOCK_D
        out_offsets += BLOCK_D
        offs_d += BLOCK_D


def test_add_timestamp_position_embeddings_kernel():
    generator = torch.Generator().manual_seed(20261011)
    offsets = torch.tensor([0, 3, 3, 8], dtype=torch.int32)
    lengths = torch.tensor([3, 0, 5], dtype=torch.int32)
    x = (torch.randn((8, 7), generator=generator) * 0.2).to(torch.float32)
    pe = (torch.randn((6, 7), generator=generator) * 0.2).to(torch.float32)
    te = (torch.randn((5, 7), generator=generator) * 0.2).to(torch.float32)
    ts = torch.tensor([1.0, 4.0, 9.0, 2.0, 3.0, 7.0, 12.0, 18.0])
    out = torch.full_like(x, 23.0).npu()
    pi = torch.full((8,), -99, dtype=torch.int32).npu()
    ti = torch.full((8,), -99, dtype=torch.int32).npu()
    targets = torch.tensor([1, 0, 2], dtype=torch.int32)
    for fn in ("log", "sqrt"):
        _add_timestamp_position_embeddings_kernel[3, 2](
            x.npu(),
            offsets.npu(),
            lengths.npu(),
            pe.npu(),
            te.npu(),
            out,
            ts.npu(),
            pi,
            ti,
            targets.npu(),
            5,
            7,
            4,
            2.0,
            1.5,
            1.0,
            1,
            6,
            7,
            7,
            7,
            7,
            TRAINING=True,
            HAS_MULTIPLE_TARGETS=True,
            INTERLEAVE_TARGETS=False,
            TIME_BUCKET_FN=fn,
            BLOCK_D=8,
            BLOCK_N=4,
        )
        pids = []
        tids = []
        for start, end, target in [(0, 3, 1), (3, 3, 0), (3, 8, 2)]:
            if end == start:
                continue
            nn = torch.arange(end - start)
            high = end - start - target
            p = (high - nn.clamp(max=high) + 1).clamp(max=5)
            p = torch.where(nn < 1, nn, p)
            delta = (ts[end - 1] - ts[start:end] + 1).clamp(min=1e-06) / 2.0
            v = delta.log() if fn == "log" else delta.sqrt()
            t = (v * 1.5).to(torch.int32).clamp(0, 4)
            pids.extend(p.tolist())
            tids.extend(t.tolist())
        pp = torch.tensor(pids)
        tt = torch.tensor(tids)
        actual_output = pi.cpu()
        expected_output = pp
        torch.testing.assert_close(
            actual_output, expected_output, atol=0, rtol=0, check_dtype=False
        )
        assert (
            torch.isfinite(actual_output).all()
            and torch.isfinite(expected_output).all()
        )
        actual_output = ti.cpu()
        expected_output = tt
        torch.testing.assert_close(
            actual_output, expected_output, atol=0, rtol=0, check_dtype=False
        )
        assert (
            torch.isfinite(actual_output).all()
            and torch.isfinite(expected_output).all()
        )
        actual_output = out.cpu()
        expected_output = x + pe[pp] + te[tt]
        torch.testing.assert_close(
            (actual_output).double(),
            (expected_output).double(),
            atol=0.0002,
            rtol=0.002,
            check_dtype=False,
        )
        assert (
            torch.isfinite(actual_output).all()
            and torch.isfinite(expected_output).all()
        )
    print("PASS: add_timestamp_position_embeddings_kernel")


if __name__ == "__main__":
    test_add_timestamp_position_embeddings_kernel()

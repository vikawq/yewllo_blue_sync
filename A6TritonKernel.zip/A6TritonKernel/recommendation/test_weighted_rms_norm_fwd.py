# Source: tests/kernels/triton_layer_norm.py

import torch
import torch_npu
import triton
import triton.language as tl


@triton.jit
def _weighted_rms_norm_fwd(
    X, Y, W, Rstd, D, eps, stride_x, stride_y, BLOCK_D: tl.constexpr
):
    row = tl.program_id(0)
    X += row.to(tl.int64) * stride_x
    Y += row.to(tl.int64) * stride_y
    cols = tl.arange(0, BLOCK_D)
    x = tl.load(X + cols, mask=cols < D, other=0.0).to(tl.float32)
    _var = tl.zeros([BLOCK_D], dtype=tl.float32)
    x_mean = tl.where(cols < D, x, 0.0)
    _var += x_mean * x_mean
    var = tl.sum(_var, axis=0) / D
    rstd = 1 / tl.sqrt(var + eps)
    tl.store(Rstd + row, rstd)
    mask = cols < D
    y = x_mean * rstd
    w = tl.load(W + cols, mask=mask).to(tl.float32)
    y = y * w
    tl.store(Y + cols, y.to(Y.dtype.element_ty), mask=mask)


def test_weighted_rms_norm_fwd():
    generator = torch.Generator().manual_seed(20261011)
    x = (torch.randn((3, 7), generator=generator) * 0.2).to(torch.float32)
    w = (torch.randn((7,), generator=generator) * 0.2).to(torch.float32) + 1
    b = (torch.randn((7,), generator=generator) * 0.2).to(torch.float32)
    rstd = (x.square().mean(-1) + 1e-05).rsqrt()
    out = torch.full_like(x, 23.0).npu()
    rs = torch.full((3,), 23.0).npu()
    _weighted_rms_norm_fwd[3,](x.npu(), out, w.npu(), rs, 7, 1e-05, 7, 7, BLOCK_D=8)
    expected = x * rstd[:, None] * w
    actual_output = out.cpu()
    expected_output = expected
    torch.testing.assert_close(
        (actual_output).double(),
        (expected_output).double(),
        atol=0.0002,
        rtol=0.002,
        check_dtype=False,
    )
    assert torch.isfinite(actual_output).all() and torch.isfinite(expected_output).all()
    actual_rstd = rs.cpu()
    expected_rstd = rstd
    torch.testing.assert_close(
        (actual_rstd).double(),
        (expected_rstd).double(),
        atol=0.0002,
        rtol=0.002,
        check_dtype=False,
    )
    assert torch.isfinite(actual_rstd).all() and torch.isfinite(expected_rstd).all()
    print("PASS: weighted_rms_norm_fwd")


if __name__ == "__main__":
    test_weighted_rms_norm_fwd()

# Source: tests/kernels/triton_jagged_softmax.py

import torch
import torch_npu
import triton
import triton.language as tl


@triton.jit
def jagged_softmax_backward_kernel(
    grad_output_ptr,
    softmax_output_ptr,
    grad_input_ptr,
    input_offsets_ptr,
    grad_output_row_stride,
    grad_output_head_stride,
    softmax_output_row_stride,
    softmax_output_head_stride,
    grad_input_row_stride,
    grad_input_head_stride,
    max_seq_len: tl.constexpr,
    BLOCK_SIZE: tl.constexpr,
):
    """
    grad_output_ptr shpae is [SUM_B, H]
    softmax_output shape is [SUM_B, H]
    grad_input shape is [SUM_B, H]
    """
    pid_batch = tl.program_id(0)
    pid_head = tl.program_id(1)
    row_begin = tl.load(input_offsets_ptr + pid_batch)
    row_end = tl.load(input_offsets_ptr + pid_batch + 1)
    N = tl.minimum(max_seq_len, row_end - row_begin)
    col_offsets = tl.arange(0, BLOCK_SIZE)
    grad_output_ptrs = (
        grad_output_ptr
        + row_begin * grad_output_row_stride
        + col_offsets * grad_output_row_stride
        + pid_head * grad_output_head_stride
    )
    softmax_output_ptrs = (
        softmax_output_ptr
        + row_begin * softmax_output_row_stride
        + col_offsets * softmax_output_row_stride
        + pid_head * softmax_output_head_stride
    )
    grad_output_row = tl.load(grad_output_ptrs, mask=col_offsets < N, other=0.0)
    softmax_output_row = tl.load(softmax_output_ptrs, mask=col_offsets < N, other=0.0)
    sum_value = tl.sum(grad_output_row * softmax_output_row, axis=0)
    grad_input_row = (grad_output_row - sum_value) * softmax_output_row
    grad_input_ptrs = (
        grad_input_ptr
        + row_begin * grad_input_row_stride
        + col_offsets * grad_input_row_stride
        + pid_head * grad_input_head_stride
    )
    tl.store(grad_input_ptrs, grad_input_row, mask=col_offsets < N)


def test_jagged_softmax_backward_kernel():
    generator = torch.Generator().manual_seed(20261011)
    offsets = torch.tensor([0, 3, 3, 8], dtype=torch.int32)
    x = (torch.randn((8, 2), generator=generator) * 0.2).to(torch.float32)
    y = torch.cat([x[:3].softmax(0), x[3:].softmax(0)])
    out = torch.full_like(x, 23.0).npu()
    dy = (torch.randn((8, 2), generator=generator) * 0.2).to(torch.float32)
    expected = torch.cat(
        [
            y[:3] * (dy[:3] - (dy[:3] * y[:3]).sum(0)),
            y[3:] * (dy[3:] - (dy[3:] * y[3:]).sum(0)),
        ]
    )
    jagged_softmax_backward_kernel[3, 2](
        dy.npu(),
        y.npu(),
        out,
        offsets.npu(),
        2,
        1,
        2,
        1,
        2,
        1,
        max_seq_len=5,
        BLOCK_SIZE=8,
    )
    actual_output = out.cpu()
    expected_output = expected
    torch.testing.assert_close(
        (actual_output).double(),
        (expected_output).double(),
        atol=0.0002,
        rtol=0.002,
        check_dtype=False,
    )
    assert torch.isfinite(actual_output).all() and torch.isfinite(expected_output).all()
    print("PASS: jagged_softmax_backward_kernel")


if __name__ == "__main__":
    test_jagged_softmax_backward_kernel()

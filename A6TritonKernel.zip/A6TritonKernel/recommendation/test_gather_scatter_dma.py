# 独立构造的行 gather/scatter 功能测试，不验证专用 DMA 指令。
# Source: tests/cases_gather_scatter.py

import torch
import torch_npu
import triton
import triton.language as tl


@triton.jit
def gather_rows(X, I, Y, ROWS: tl.constexpr, D: tl.constexpr, B: tl.constexpr):
    p = tl.program_id(0) * B + tl.arange(0, B)
    valid = p < ROWS * D
    r = p // D
    c = p % D
    idx = tl.load(I + r, mask=valid, other=0)
    v = tl.load(X + idx * D + c, mask=valid, other=0)
    tl.store(Y + p, v, mask=valid)


@triton.jit
def scatter_rows(X, I, Y, ROWS: tl.constexpr, D: tl.constexpr, B: tl.constexpr):
    p = tl.program_id(0) * B + tl.arange(0, B)
    valid = p < ROWS * D
    r = p // D
    c = p % D
    idx = tl.load(I + r, mask=valid, other=0)
    v = tl.load(X + p, mask=valid, other=0)
    tl.store(Y + idx * D + c, v, mask=valid)


def test_gather_scatter_dma():
    generator = torch.Generator().manual_seed(20261011)
    x = (torch.randn((8, 7), generator=generator) * 0.2).to(torch.float32)
    ids = torch.tensor([6, 1, 4, 0, 7], dtype=torch.int32)
    y = torch.full((5, 7), 23.0).npu()
    out = torch.full((8, 7), 23.0).npu()
    i = ids.npu()
    gather_rows[2,](x.npu(), i, y, ROWS=5, D=7, B=32)
    actual_gather = y.cpu()
    expected_gather = x[ids.long()]
    torch.testing.assert_close(
        (actual_gather).double(),
        (expected_gather).double(),
        atol=0.0002,
        rtol=0.002,
        check_dtype=False,
    )
    assert torch.isfinite(actual_gather).all() and torch.isfinite(expected_gather).all()
    scatter_rows[2,](y, i, out, ROWS=5, D=7, B=32)
    ref = torch.full((8, 7), 23.0)
    ref[ids.long()] = x[ids.long()]
    actual_scatter = out.cpu()
    expected_scatter = ref
    torch.testing.assert_close(
        (actual_scatter).double(),
        (expected_scatter).double(),
        atol=0.0002,
        rtol=0.002,
        check_dtype=False,
    )
    assert (
        torch.isfinite(actual_scatter).all() and torch.isfinite(expected_scatter).all()
    )
    print("PASS: Gather_Scatter_DMA")


if __name__ == "__main__":
    test_gather_scatter_dma()

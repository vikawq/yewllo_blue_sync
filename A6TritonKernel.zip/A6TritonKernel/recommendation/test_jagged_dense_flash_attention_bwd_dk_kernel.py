# Source: tests/kernels/triton_jagged_dense_flash_attention.py

import torch
import torch_npu
import triton
import triton.language as tl


@triton.jit
def _jagged_dense_flash_attention_bwd_dk_kernel(
    q_ptr,
    k_ptr,
    v_ptr,
    ab_ptr,
    jagged_offsets_ptr,
    out_ptr,
    do_ptr,
    lse_ptr,
    delta_ptr,
    dq_ptr,
    dk_ptr,
    dv_ptr,
    dbias_ptr,
    max_seq_len,
    stride_ql,
    stride_qd,
    stride_kb,
    stride_kd,
    stride_kt,
    stride_vl,
    stride_vd,
    stride_ab_b,
    stride_ab_l,
    stride_ab_t,
    stride_ob,
    stride_ot,
    stride_od,
    stride_dk_b,
    stride_dk_d,
    stride_dk_t,
    stride_do_b,
    stride_do_t,
    stride_do_d,
    D,
    T: tl.constexpr,
    BLOCK_T: tl.constexpr,
    BLOCK_L: tl.constexpr,
    BLOCK_D: tl.constexpr,
    allow_tf32: tl.constexpr,
):
    pid_t = tl.program_id(0)
    pid_b = tl.program_id(1)
    begin = tl.load(jagged_offsets_ptr + pid_b)
    end = tl.load(jagged_offsets_ptr + pid_b + 1)
    seqlen = end - begin
    seqlen = tl.minimum(seqlen, max_seq_len)
    if seqlen == 0:
        return
    q_start_ptr = q_ptr + begin * stride_ql
    k_start_ptr = k_ptr + pid_b * stride_kb
    ab_start_ptr = ab_ptr + pid_b * stride_ab_b
    v_start_ptr = v_ptr + begin * stride_vl
    do_start_ptr = do_ptr + pid_b * stride_do_b
    dk_start_ptr = dk_ptr + pid_b * stride_dk_b
    delta_ptrs = delta_ptr + pid_b * T
    lse_ptrs = lse_ptr + pid_b * T
    offs_t_curr = pid_t * BLOCK_T + tl.arange(0, BLOCK_T)
    offs_d = tl.arange(0, BLOCK_D)
    k_ptrs = (
        k_start_ptr + offs_d[:, None] * stride_kd + offs_t_curr[None, :] * stride_kt
    )
    do_ptrs = (
        do_start_ptr
        + offs_t_curr[:, None] * stride_do_t
        + offs_d[None, :] * stride_do_d
    )
    dk_ptrs = (
        dk_start_ptr
        + offs_d[:, None] * stride_dk_d
        + offs_t_curr[None, :] * stride_dk_t
    )
    dk = tl.zeros([BLOCK_D, BLOCK_T], dtype=tl.float32)
    k = tl.load(
        k_ptrs, mask=(offs_t_curr[None, :] < T) & (offs_d[:, None] < BLOCK_D), other=0.0
    )
    start_l = 0
    while start_l < seqlen:
        offs_l_curr = start_l + tl.arange(0, BLOCK_L)
        q_ptrs = (
            q_start_ptr + offs_l_curr[:, None] * stride_ql + offs_d[None, :] * stride_qd
        )
        q = tl.load(q_ptrs, mask=offs_l_curr[:, None] < seqlen, other=0.0)
        v_ptrs = (
            v_start_ptr + offs_l_curr[:, None] * stride_vl + offs_d[None, :] * stride_vd
        )
        v = tl.load(v_ptrs, mask=offs_l_curr[:, None] < seqlen, other=0.0)
        qk = tl.zeros([BLOCK_L, BLOCK_T], dtype=tl.float32)
        qk = tl.dot(q, k, allow_tf32=allow_tf32)
        qk = tl.where(
            (offs_l_curr[:, None] < seqlen) & (offs_t_curr[None, :] < T), qk, 0.0
        )
        ab_ptrs = (
            ab_start_ptr
            + offs_l_curr[:, None] * stride_ab_l
            + offs_t_curr[None, :] * stride_ab_t
        )
        ab = tl.load(
            ab_ptrs,
            mask=(offs_l_curr[:, None] < seqlen) & (offs_t_curr[None, :] < T),
            other=0.0,
        )
        qk = qk + ab
        qk_mask = (offs_l_curr[:, None] < seqlen) & (offs_t_curr[None, :] < T)
        qk = tl.where(qk_mask, qk, float("-inf"))
        lse_t = tl.load(lse_ptrs + offs_t_curr, mask=offs_t_curr < T)
        p = tl.exp(qk - lse_t[None, :])
        p = tl.where(qk_mask, p, 0.0)
        do = tl.load(do_ptrs, mask=offs_t_curr[:, None] < T, other=0.0)
        delta = tl.load(delta_ptrs + offs_t_curr, mask=offs_t_curr < T)
        dp = tl.trans(tl.dot(do, tl.trans(v), allow_tf32=allow_tf32))
        ds = p * (dp - delta[None, :])
        dk += tl.dot(tl.trans(q), ds, allow_tf32=allow_tf32)
        start_l += BLOCK_L
    tl.store(dk_ptrs, dk, mask=offs_t_curr[None, :] < T)


def test_jagged_dense_flash_attention_bwd_dk_kernel():
    generator = torch.Generator().manual_seed(20261011)
    input_dtype = torch.float32
    d, t, maxseq = (16, 3, 5)
    off = torch.tensor([0, 3, 8], dtype=torch.int32)
    q = (torch.randn((8, d), generator=generator) * 0.2).to(input_dtype)
    k = (torch.randn((2, d, t), generator=generator) * 0.2).to(input_dtype)
    v = (torch.randn((8, d), generator=generator) * 0.2).to(input_dtype)
    bias = (torch.randn((2, maxseq, t), generator=generator) * 0.2).to(torch.float32)
    dy = (torch.randn((2, t, d), generator=generator) * 0.2).to(input_dtype)
    qq = q.double().requires_grad_()
    kk = k.double().requires_grad_()
    vv = v.double().requires_grad_()
    bb = bias.double().requires_grad_()
    ys = []
    ls = []
    for b, (st, en) in enumerate([(0, 3), (3, 8)]):
        s = qq[st:en] @ kk[b] + bb[b, : en - st]
        ys.append(s.softmax(0).T @ vv[st:en])
        ls.append(s.logsumexp(0))
    ref = torch.stack(ys)
    lse = torch.stack(ls).float()
    (ref * dy.double()).sum().backward()
    o = ref.detach().to(input_dtype)
    delta = (o.float() * dy.float()).sum(-1)
    common = [16, 1, 48, 3, 1, 16, 1, 15, 3, 1, 48, 16, 1]
    opts = dict(T=t, BLOCK_T=16, BLOCK_L=16, BLOCK_D=16, allow_tf32=False)
    dq = torch.full_like(q, 23.0).npu()
    dk = torch.full_like(k, 23.0).npu()
    dv = torch.full_like(v, 23.0).npu()
    db = torch.zeros_like(bias).npu()
    args = [
        q.npu(),
        k.npu(),
        v.npu(),
        bias.npu(),
        off.npu(),
        o.npu(),
        dy.npu(),
        lse.npu(),
        delta.npu(),
        dq,
        dk,
        dv,
        db,
        maxseq,
        *common,
    ]
    _jagged_dense_flash_attention_bwd_dk_kernel[1, 2](
        *args, 48, 3, 1, 48, 16, 1, d, **opts
    )
    actual_dk = dk.cpu()
    expected_dk = kk.grad
    torch.testing.assert_close(
        (actual_dk).double(),
        (expected_dk).double(),
        atol=0.0002,
        rtol=0.002,
        check_dtype=False,
    )
    assert torch.isfinite(actual_dk).all() and torch.isfinite(expected_dk).all()
    print("PASS: jagged_dense_flash_attention_bwd_dk_kernel")


if __name__ == "__main__":
    test_jagged_dense_flash_attention_bwd_dk_kernel()

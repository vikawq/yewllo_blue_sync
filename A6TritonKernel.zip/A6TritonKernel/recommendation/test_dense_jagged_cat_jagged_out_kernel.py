# Source: tests/kernels/triton_dense_jagged_cat_jagged_out.py

import torch
import torch_npu
import triton
import triton.language as tl


@triton.jit
def dense_jagged_cat_jagged_out_kernel(
    a_ptr,
    b_ptr,
    c_ptr,
    b_offsets_ptr,
    c_offsets_ptr,
    max_seq_len,
    BLOCK_SIZE: tl.constexpr,
):
    pid_batch = tl.program_id(0)
    b_start = tl.load(b_offsets_ptr + pid_batch)
    b_end = tl.load(b_offsets_ptr + pid_batch + 1)
    c_start = b_start + pid_batch
    N = b_end - b_start
    N = tl.minimum(N, max_seq_len)
    a = tl.load(a_ptr + pid_batch)
    tl.store(c_ptr + c_start, a)
    offs_k = tl.arange(0, BLOCK_SIZE)
    for k in range(0, N, BLOCK_SIZE):
        b_offset = k + offs_k
        b_ptrs = b_ptr + b_start + b_offset
        b = tl.load(b_ptrs, mask=b_offset < N, other=0.0)
        tl.store(c_ptr + c_start + 1 + b_offset, b, mask=b_offset < N)
    tl.store(c_offsets_ptr + pid_batch, b_start + pid_batch)


def test_dense_jagged_cat_jagged_out_kernel():
    generator = torch.Generator().manual_seed(20261011)
    a = (torch.randn((3,), generator=generator) * 0.2).to(torch.float32)
    b = (torch.randn((8,), generator=generator) * 0.2).to(torch.float32)
    o = torch.full((11,), 23.0).npu()
    off = torch.tensor([-99, -99, -99, 11], dtype=torch.int32).npu()
    dense_jagged_cat_jagged_out_kernel[3,](
        a.npu(),
        b.npu(),
        o,
        torch.tensor([0, 3, 3, 8], dtype=torch.int32).npu(),
        off,
        5,
        BLOCK_SIZE=4,
    )
    actual_output = o.cpu()
    expected_output = torch.cat([a[:1], b[:3], a[1:2], a[2:], b[3:]])
    torch.testing.assert_close(
        (actual_output).double(),
        (expected_output).double(),
        atol=0,
        rtol=0,
        check_dtype=False,
    )
    assert torch.isfinite(actual_output).all() and torch.isfinite(expected_output).all()
    actual_offsets = off.cpu()
    expected_offsets = torch.tensor([0, 4, 5, 11], dtype=torch.int32)
    torch.testing.assert_close(
        actual_offsets, expected_offsets, atol=0, rtol=0, check_dtype=False
    )
    assert (
        torch.isfinite(actual_offsets).all() and torch.isfinite(expected_offsets).all()
    )
    print("PASS: dense_jagged_cat_jagged_out_kernel")


if __name__ == "__main__":
    test_dense_jagged_cat_jagged_out_kernel()

# Source: tests/kernels/triton_jagged_tensor_ops.py

import torch
import torch_npu
import triton
import triton.language as tl


@triton.jit
def jagged_jagged_elementwise_arithmetic_ops(
    x_ptr,
    y_ptr,
    M: tl.constexpr,
    N: tl.constexpr,
    stride_row: tl.constexpr,
    stride_col: tl.constexpr,
    output,
    thread_block_row_size: tl.constexpr,
    thread_block_col_size: tl.constexpr,
    ops_func: tl.constexpr,
) -> None:
    pid = tl.program_id(0)
    num_group_n = (N + thread_block_col_size - 1) // thread_block_col_size
    pid_n = pid % num_group_n
    pid_m = pid // num_group_n
    offset_m = pid_m * thread_block_row_size + tl.arange(0, thread_block_row_size)
    offset_n = pid_n * thread_block_col_size + tl.arange(0, thread_block_col_size)
    mask = (offset_m[:, None] < M) & (offset_n[None, :] < N)
    offset = offset_m[:, None] * stride_row + offset_n[None, :] * stride_col
    x_ptr += offset
    y_ptr += offset
    x = tl.load(x_ptr, mask=mask)
    y = tl.load(y_ptr, mask=mask)
    if ops_func == "add":
        z = tensor_elementwise_add(x, y)
    else:
        z = tensor_elementwise_mul(x, y)
    output += offset
    tl.store(output, z, mask=mask)


@triton.jit
def tensor_elementwise_add(x, y):
    return x + y


@triton.jit
def tensor_elementwise_mul(x, y):
    return x * y


def test_jagged_jagged_elementwise_arithmetic_ops():
    generator = torch.Generator().manual_seed(20261011)
    a = (torch.randn((5, 7), generator=generator) * 0.2).to(torch.float32)
    b = (torch.randn((5, 7), generator=generator) * 0.2).to(torch.float32)
    o = torch.full_like(a, 23.0).npu()
    jagged_jagged_elementwise_arithmetic_ops[2,](
        a.npu(),
        b.npu(),
        5,
        7,
        7,
        1,
        o,
        thread_block_row_size=4,
        thread_block_col_size=8,
        ops_func="add",
    )
    actual_output = o.cpu()
    expected_output = a + b
    torch.testing.assert_close(
        (actual_output).double(),
        (expected_output).double(),
        atol=0.0002,
        rtol=0.002,
        check_dtype=False,
    )
    assert torch.isfinite(actual_output).all() and torch.isfinite(expected_output).all()
    a = (torch.randn((5, 7), generator=generator) * 0.2).to(torch.float32)
    b = (torch.randn((5, 7), generator=generator) * 0.2).to(torch.float32)
    o = torch.full_like(a, 23.0).npu()
    jagged_jagged_elementwise_arithmetic_ops[2,](
        a.npu(),
        b.npu(),
        5,
        7,
        7,
        1,
        o,
        thread_block_row_size=4,
        thread_block_col_size=8,
        ops_func="mul",
    )
    actual_output = o.cpu()
    expected_output = a * b
    torch.testing.assert_close(
        (actual_output).double(),
        (expected_output).double(),
        atol=0.0002,
        rtol=0.002,
        check_dtype=False,
    )
    assert torch.isfinite(actual_output).all() and torch.isfinite(expected_output).all()
    print("PASS: jagged_jagged_elementwise_arithmetic_ops")


if __name__ == "__main__":
    test_jagged_jagged_elementwise_arithmetic_ops()

# Source: tests/kernels/triton_layer_norm.py

import torch
import torch_npu
import triton
import triton.language as tl


@triton.jit
def _weighted_layer_norm_bwd_dx(
    DX,
    DY,
    DW,
    DB,
    X,
    W,
    B,
    Mean,
    Rstd,
    stride_dx,
    stride_dy,
    stride_x,
    stride_acc,
    D,
    eps,
    IS_SWISH: tl.constexpr,
    N,
    DX_ACC,
    BLOCK_D: tl.constexpr,
    DGRAD_ACCUM: tl.constexpr,
):
    pid = tl.program_id(0)
    tile_num = tl.num_programs(0)
    rows_per_tile = N // tile_num
    if pid < N % tile_num:
        rows_per_tile += 1
    cols = tl.arange(0, BLOCK_D)
    mask = cols < D
    row = pid
    for idx in range(rows_per_tile):
        x_ptrs = X + row.to(tl.int64) * stride_x
        if DGRAD_ACCUM:
            dx_acc_ptrs = DX_ACC + row.to(tl.int64) * stride_acc
        dy_ptrs = DY + row.to(tl.int64) * stride_dy
        dx_ptrs = DX + row.to(tl.int64) * stride_dx
        dw_ptrs = DW + pid.to(tl.int64) * D
        dw_ptrs += cols
        db_ptrs = DB + pid.to(tl.int64) * D
        db_ptrs += cols
        x = tl.load(x_ptrs + cols, mask=mask, other=0).to(tl.float32)
        dy = tl.load(dy_ptrs + cols, mask=mask, other=0).to(tl.float32)
        if DGRAD_ACCUM:
            dx_acc = tl.load(dx_acc_ptrs + cols, mask=mask, other=0).to(tl.float32)
        mean = tl.load(Mean + row)
        rstd = tl.load(Rstd + row)
        xhat = (x - mean) * rstd
        w = tl.load(W + cols, mask=mask).to(tl.float32)
        wdy = w * dy
        xhat = tl.where(mask, xhat, 0.0)
        wdy = tl.where(mask, wdy, 0.0)
        sigmoid_layer_norm = None
        if IS_SWISH:
            b = tl.load(B + cols, mask=mask).to(tl.float32)
            sigmoid_layer_norm = tl.sigmoid(xhat * w + b)
            sigmoid_layer_norm = tl.where(mask, sigmoid_layer_norm, 0.0)
            x_ = wdy * x * sigmoid_layer_norm * (1 - sigmoid_layer_norm)
            x_ = tl.where(mask, x_, 0.0)
            c1 = tl.sum(xhat * x_, axis=0) / D
            c2 = tl.sum(x_, axis=0) / D
            dx = (x_ - (xhat * c1 + c2)) * rstd
            dx = dy * sigmoid_layer_norm + dx
        else:
            c1 = tl.sum(xhat * wdy, axis=0) / D
            c2 = tl.sum(wdy, axis=0) / D
            dx = (wdy - (xhat * c1 + c2)) * rstd
        if DGRAD_ACCUM:
            dx += dx_acc
        tl.store(dx_ptrs + cols, dx.to(dx_ptrs.dtype.element_ty), mask=mask)
        if IS_SWISH:
            partial_dw = dy * x * xhat * sigmoid_layer_norm * (1 - sigmoid_layer_norm)
            partial_db = dy * x * sigmoid_layer_norm * (1 - sigmoid_layer_norm)
        else:
            partial_dw = dy * xhat
            partial_db = dy
        if idx > 0:
            partial_dw += tl.load(dw_ptrs, mask=mask)
            partial_db += tl.load(db_ptrs, mask=mask)
        tl.store(dw_ptrs, partial_dw, mask=mask)
        tl.store(db_ptrs, partial_db, mask=mask)
        row += tile_num


def test_weighted_layer_norm_bwd_dx():
    generator = torch.Generator().manual_seed(20261011)
    x = (torch.randn((3, 7), generator=generator) * 0.2).to(torch.float32)
    dy = (torch.randn((3, 7), generator=generator) * 0.2).to(torch.float32)
    w = (torch.randn((7,), generator=generator) * 0.2).to(torch.float32) + 1
    b = (torch.randn((7,), generator=generator) * 0.2).to(torch.float32)
    mean = x.mean(-1)
    rs = (x.var(-1, unbiased=False) + 1e-05).rsqrt()
    xn = (x - mean[:, None]) * rs[:, None]
    xx = x.double().requires_grad_()
    ww = w.double().requires_grad_()
    bb = b.double().requires_grad_()
    y = torch.nn.functional.layer_norm(xx, (7,), ww, bb, 1e-05)
    (y * dy.double()).sum().backward()
    dx = torch.full_like(x, 23.0).npu()
    dw = torch.full_like(x, 23.0).npu()
    db = torch.full_like(x, 23.0).npu()
    _weighted_layer_norm_bwd_dx[3,](
        dx,
        dy.npu(),
        dw,
        db,
        x.npu(),
        w.npu(),
        b.npu(),
        mean.npu(),
        rs.npu(),
        7,
        7,
        7,
        7,
        7,
        1e-05,
        IS_SWISH=False,
        N=3,
        DX_ACC=None,
        BLOCK_D=8,
        DGRAD_ACCUM=False,
    )
    actual_partial_dw = dw.cpu()
    expected_partial_dw = dy * xn
    torch.testing.assert_close(
        (actual_partial_dw).double(),
        (expected_partial_dw).double(),
        atol=0.0002,
        rtol=0.002,
        check_dtype=False,
    )
    assert (
        torch.isfinite(actual_partial_dw).all()
        and torch.isfinite(expected_partial_dw).all()
    )
    actual_partial_db = db.cpu()
    expected_partial_db = dy
    torch.testing.assert_close(
        (actual_partial_db).double(),
        (expected_partial_db).double(),
        atol=0.0002,
        rtol=0.002,
        check_dtype=False,
    )
    assert (
        torch.isfinite(actual_partial_db).all()
        and torch.isfinite(expected_partial_db).all()
    )
    actual_dx = dx.cpu()
    expected_dx = xx.grad
    torch.testing.assert_close(
        (actual_dx).double(),
        (expected_dx).double(),
        atol=0.0002,
        rtol=0.002,
        check_dtype=False,
    )
    assert torch.isfinite(actual_dx).all() and torch.isfinite(expected_dx).all()
    print("PASS: weighted_layer_norm_bwd_dx")


if __name__ == "__main__":
    test_weighted_layer_norm_bwd_dx()

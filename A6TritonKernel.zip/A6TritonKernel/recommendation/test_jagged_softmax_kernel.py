# Source: tests/kernels/triton_jagged_softmax.py

import torch
import torch_npu
import triton
import triton.language as tl


@triton.jit
def jagged_softmax_kernel(
    input_ptr,
    output_ptr,
    input_offsets_ptr,
    input_row_stride,
    input_head_stride,
    output_row_stride,
    output_head_stride,
    max_seq_len: tl.constexpr,
    BLOCK_SIZE: tl.constexpr,
):
    """
    input shpae is [SUM_B, H]
    output shape is [SUM_B, H]
    """
    pid_batch = tl.program_id(0)
    pid_head = tl.program_id(1)
    row_begin = tl.load(input_offsets_ptr + pid_batch)
    row_end = tl.load(input_offsets_ptr + pid_batch + 1)
    N = tl.minimum(max_seq_len, row_end - row_begin)
    if N == 0:
        return
    row_start_ptr = input_ptr + row_begin * input_row_stride
    col_offsets = tl.arange(0, BLOCK_SIZE)
    input_ptrs = (
        row_start_ptr + col_offsets * input_row_stride + pid_head * input_head_stride
    )
    row = tl.load(input_ptrs, mask=col_offsets < N, other=-float("inf"))
    row_mins_max = row - tl.max(row, axis=0)
    numerator = tl.exp(row_mins_max)
    denominator = tl.sum(numerator, axis=0)
    softmax_output = numerator / denominator
    output_row_start_ptr = output_ptr + row_begin * output_row_stride
    output_ptrs = (
        output_row_start_ptr
        + col_offsets * output_row_stride
        + pid_head * output_head_stride
    )
    tl.store(output_ptrs, softmax_output, mask=col_offsets < N)


def test_jagged_softmax_kernel():
    generator = torch.Generator().manual_seed(20261011)
    offsets = torch.tensor([0, 3, 3, 8], dtype=torch.int32)
    x = (torch.randn((8, 2), generator=generator) * 0.2).to(torch.float32)
    y = torch.cat([x[:3].softmax(0), x[3:].softmax(0)])
    out = torch.full_like(x, 23.0).npu()
    jagged_softmax_kernel[3, 2](
        x.npu(), out, offsets.npu(), 2, 1, 2, 1, max_seq_len=5, BLOCK_SIZE=8
    )
    expected = y
    actual_output = out.cpu()
    expected_output = expected
    torch.testing.assert_close(
        (actual_output).double(),
        (expected_output).double(),
        atol=0.0002,
        rtol=0.002,
        check_dtype=False,
    )
    assert torch.isfinite(actual_output).all() and torch.isfinite(expected_output).all()
    print("PASS: jagged_softmax_kernel")


if __name__ == "__main__":
    test_jagged_softmax_kernel()

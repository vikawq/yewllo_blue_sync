# Source: tests/kernels/triton_jagged_bmm_jagged_out.py

import torch
import torch_npu
import triton
import triton.language as tl


@triton.jit
def jagged_jagged_bmm_jagged_out_kernel(
    a_ptr,
    a_offset_ptr,
    b_ptr,
    b_offset_ptr,
    c_ptr,
    offsets_mn_ptr,
    max_seq_len,
    num_blocks_n,
    K,
    stride_am,
    stride_ak,
    stride_bk,
    stride_bn,
    allow_tf32: tl.constexpr,
    BLOCK_SIZE_M: tl.constexpr,
    BLOCK_SIZE_N: tl.constexpr,
    BLOCK_SIZE_K: tl.constexpr,
):
    """
    Kernel for computing C = A x B.
    A has shape (sum_B(Mi), K), B has shape (K, sum_B(Ni))
    and C has shape (sum_B(Mi * Ni))
    """
    pid = tl.program_id(axis=0)
    pid_batch = tl.program_id(axis=1)
    begin_a = tl.load(a_offset_ptr + pid_batch)
    end_a = tl.load(a_offset_ptr + pid_batch + 1)
    begin_b = tl.load(b_offset_ptr + pid_batch)
    end_b = tl.load(b_offset_ptr + pid_batch + 1)
    offset_mn = tl.load(offsets_mn_ptr + pid_batch)
    M = end_a - begin_a
    M = tl.minimum(M, max_seq_len)
    N = end_b - begin_b
    N = tl.minimum(N, max_seq_len)
    pid_m = pid // num_blocks_n
    pid_n = pid % num_blocks_n
    if pid_m * BLOCK_SIZE_M >= M or pid_n * BLOCK_SIZE_N >= N:
        return
    offs_am = pid_m * BLOCK_SIZE_M + tl.arange(0, BLOCK_SIZE_M)
    offs_bn = pid_n * BLOCK_SIZE_N + tl.arange(0, BLOCK_SIZE_N)
    offs_k = tl.arange(0, BLOCK_SIZE_K)
    a_ptrs = (
        a_ptr
        + (offs_am[:, None] * stride_am + offs_k[None, :] * stride_ak)
        + begin_a * stride_am
    )
    b_ptrs = (
        b_ptr
        + (offs_k[:, None] * stride_bk + offs_bn[None, :] * stride_bn)
        + begin_b * stride_bn
    )
    c = tl.zeros((BLOCK_SIZE_M, BLOCK_SIZE_N), dtype=tl.float32)
    for k in range(0, K, BLOCK_SIZE_K):
        updated_offset = k + offs_k
        a = tl.load(
            a_ptrs,
            mask=(updated_offset[None, :] < K) & (offs_am[:, None] < M),
            other=0.0,
        )
        b = tl.load(
            b_ptrs,
            mask=(updated_offset[:, None] < K) & (offs_bn[None, :] < N),
            other=0.0,
        )
        c += tl.dot(a, b, allow_tf32=allow_tf32)
        a_ptrs += BLOCK_SIZE_K * stride_ak
        b_ptrs += BLOCK_SIZE_K * stride_bk
    offs_cm = pid_m * BLOCK_SIZE_M + tl.arange(0, BLOCK_SIZE_M)
    offs_cn = pid_n * BLOCK_SIZE_N + tl.arange(0, BLOCK_SIZE_N)
    c_ptrs = c_ptr + offset_mn + N * offs_cm[:, None] + offs_cn[None, :]
    c_mask = (offs_cm[:, None] < M) & (offs_cn[None, :] < N)
    tl.store(c_ptrs, c, mask=c_mask)


def test_jagged_jagged_bmm_jagged_out_kernel():
    generator = torch.Generator().manual_seed(20261011)
    a = (torch.randn((5, 16), generator=generator) * 0.2).to(torch.float16)
    b = (torch.randn((16, 7), generator=generator) * 0.2).to(torch.float16)
    out = torch.full((18,), 23.0, dtype=torch.float16).npu()
    jagged_jagged_bmm_jagged_out_kernel[1, 2](
        a.npu(),
        torch.tensor([0, 2, 5], dtype=torch.int32).npu(),
        b.npu(),
        torch.tensor([0, 3, 7], dtype=torch.int32).npu(),
        out,
        torch.tensor([0, 6, 18], dtype=torch.int32).npu(),
        4,
        1,
        16,
        16,
        1,
        7,
        1,
        allow_tf32=False,
        BLOCK_SIZE_M=16,
        BLOCK_SIZE_N=16,
        BLOCK_SIZE_K=16,
    )
    actual_bmm = out.cpu()
    expected_bmm = torch.cat(
        [
            (a[:2].float() @ b[:, :3].float()).flatten(),
            (a[2:].float() @ b[:, 3:].float()).flatten(),
        ]
    )
    torch.testing.assert_close(
        (actual_bmm).double(),
        (expected_bmm).double(),
        atol=0.0002,
        rtol=0.002,
        check_dtype=False,
    )
    assert torch.isfinite(actual_bmm).all() and torch.isfinite(expected_bmm).all()
    print("PASS: jagged_jagged_bmm_jagged_out_kernel")


if __name__ == "__main__":
    test_jagged_jagged_bmm_jagged_out_kernel()

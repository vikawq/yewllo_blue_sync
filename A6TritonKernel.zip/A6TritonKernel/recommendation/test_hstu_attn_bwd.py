# Source: tests/kernels/triton_hstu_attention.py

import torch
import torch_npu
import triton
import triton.language as tl
from triton.language.extra.cann.libdevice import fast_dividef


@triton.jit
def acc_dq(
    dq_ptrs_trans,
    start_m,
    stride_dqm,
    k,
    dqk_trans,
    alpha,
    mask_m,
    MAX_SEQ_LEN,
    LOCK,
    BLOCK_M: tl.constexpr,
    ATOMIC_ADD: tl.constexpr,
    ALLOW_TF32: tl.constexpr,
):
    if ATOMIC_ADD:
        lock_id = start_m // BLOCK_M
        stride_lock = tl.cdiv(MAX_SEQ_LEN, BLOCK_M)
        lock = LOCK + tl.program_id(0) * stride_lock + lock_id
        tl.debug_barrier()
        while tl.atomic_cas(lock, 0, 1) == 1:
            pass
    dq_trans = tl.load(
        dq_ptrs_trans + start_m * stride_dqm,
        mask=mask_m[None, :],
        other=0.0,
        eviction_policy="evict_last",
    )
    dq_trans += tl.dot(tl.trans(k), dqk_trans, allow_tf32=ALLOW_TF32) * alpha
    dq_trans = dq_trans.to(k.dtype)
    tl.store(
        dq_ptrs_trans + start_m * stride_dqm,
        dq_trans,
        mask=mask_m[None, :],
        eviction_policy="evict_last",
    )
    if ATOMIC_ADD:
        tl.atomic_xchg(lock, 0)


@triton.jit
def _hstu_attn_bwd_one_block(
    start_m,
    offs_n,
    offs_m,
    q_ptrs_trans,
    dq_ptrs_trans,
    do_ptrs,
    device_desc_q,
    device_desc_do,
    dk,
    dv,
    k,
    v,
    pos_offs_n,
    seq_len,
    max_ids,
    contextual_seq_len,
    max_attn_len,
    scaling_seqlen,
    LOCK,
    off_h,
    stride_qh,
    stride_doh,
    stride_qm,
    stride_dom,
    stride_dqm,
    alpha,
    MAX_SEQ_LEN,
    HAS_MULTIPLE_TARGETS: tl.constexpr,
    HAS_CONTEXTUAL_SEQ_LEN: tl.constexpr,
    HAS_MAX_ATTN_LEN: tl.constexpr,
    ALLOW_TF32: tl.constexpr,
    BLOCK_M: tl.constexpr,
    ATOMIC_ADD: tl.constexpr,
    ENABLE_TMA: tl.constexpr,
    BLOCK_D_Q: tl.constexpr,
    BLOCK_D_V: tl.constexpr,
):
    pos_offs_m = offs_m + start_m
    mask_m = pos_offs_m < seq_len
    invalid_mask_trans = pos_offs_m[None, :] == offs_n[:, None]
    if HAS_CONTEXTUAL_SEQ_LEN:
        pos_offs_m = pos_offs_m - contextual_seq_len + 1
        pos_offs_m = tl.where(pos_offs_m > 0, pos_offs_m, 0)
    if HAS_MULTIPLE_TARGETS:
        pos_offs_m = tl.where(pos_offs_m < max_ids, pos_offs_m, max_ids)
    if ENABLE_TMA:
        q = device_desc_q.load([start_m, (off_h * stride_qh).to(tl.int32)])
        q_trans = tl.trans(q)
    else:
        q_trans = tl.load(
            q_ptrs_trans + start_m * stride_qm, mask=mask_m[None, :], other=0.0
        )
    qk_trans = tl.dot(k, q_trans, allow_tf32=ALLOW_TF32) * alpha
    sig_trans = fast_dividef(1.0, 1.0 + tl.exp(-qk_trans))
    silu_trans = qk_trans * sig_trans * (1.0 / scaling_seqlen)
    pos_offs_m_minus_n = pos_offs_m[None, :] - pos_offs_n[:, None]
    invalid_mask_trans = invalid_mask_trans | (pos_offs_m_minus_n > 0)
    if HAS_MAX_ATTN_LEN:
        invalid_mask_trans = invalid_mask_trans & (pos_offs_m_minus_n <= max_attn_len)
    if HAS_CONTEXTUAL_SEQ_LEN:
        invalid_mask_trans = invalid_mask_trans | (pos_offs_m[None, :] == 0) & (
            pos_offs_n[:, None] < max_ids
        )
    silu_trans = tl.where(invalid_mask_trans, silu_trans, 0)
    silu_trans = silu_trans.to(k.dtype)
    if ENABLE_TMA:
        do = device_desc_do.load([start_m, (off_h * stride_doh).to(tl.int32)])
    else:
        do = tl.load(do_ptrs + start_m * stride_dom, mask=mask_m[:, None], other=0.0)
    dv += tl.dot(silu_trans, do, allow_tf32=ALLOW_TF32)
    dqk_trans = tl.dot(v, tl.trans(do), allow_tf32=ALLOW_TF32)
    dqk_trans = (
        dqk_trans
        * sig_trans
        * (1 + qk_trans * (1 - sig_trans))
        * (1.0 / scaling_seqlen)
    )
    dqk_trans = tl.where(invalid_mask_trans, dqk_trans, 0)
    dqk_trans = dqk_trans.to(k.dtype)
    dk += tl.dot(dqk_trans, tl.trans(q_trans), allow_tf32=ALLOW_TF32)
    acc_dq(
        dq_ptrs_trans=dq_ptrs_trans,
        start_m=start_m,
        stride_dqm=stride_dqm,
        k=k,
        dqk_trans=dqk_trans,
        alpha=alpha,
        mask_m=mask_m,
        MAX_SEQ_LEN=MAX_SEQ_LEN,
        LOCK=LOCK,
        BLOCK_M=BLOCK_M,
        ATOMIC_ADD=ATOMIC_ADD,
        ALLOW_TF32=ALLOW_TF32,
    )
    return (dk, dv)


@triton.jit
def _hstu_attn_bwd_one_col_block(
    start_n,
    seq_len,
    n_targets,
    contextual_seq_len,
    max_attn_len,
    scaling_seqlen,
    Q,
    K,
    V,
    DOut,
    DQ,
    DK,
    DV,
    device_desc_q,
    device_desc_k,
    device_desc_v,
    device_desc_do,
    device_desc_dk,
    device_desc_dv,
    LOCK,
    off_h,
    stride_qh,
    stride_kh,
    stride_vh,
    stride_doh,
    stride_dkh,
    stride_dvh,
    stride_qm,
    stride_kn,
    stride_vn,
    stride_dom,
    stride_dqm,
    stride_dkn,
    stride_dvn,
    alpha,
    MAX_SEQ_LEN,
    HAS_MULTIPLE_TARGETS: tl.constexpr,
    HAS_CONTEXTUAL_SEQ_LEN: tl.constexpr,
    HAS_MAX_ATTN_LEN: tl.constexpr,
    ALLOW_TF32: tl.constexpr,
    BLOCK_D_Q: tl.constexpr,
    BLOCK_D_V: tl.constexpr,
    BLOCK_M: tl.constexpr,
    BLOCK_N: tl.constexpr,
    UNROLL: tl.constexpr,
    ATOMIC_ADD: tl.constexpr,
    ENABLE_TMA: tl.constexpr,
):
    if HAS_MULTIPLE_TARGETS:
        low = start_n
        if HAS_MAX_ATTN_LEN:
            high = start_n + max_attn_len + BLOCK_N
            high = high if high + n_targets < seq_len else seq_len
        else:
            high = seq_len
    else:
        low = start_n
        if HAS_MAX_ATTN_LEN:
            high = start_n + max_attn_len + BLOCK_N
            high = high if high < seq_len else seq_len
        else:
            high = seq_len
    if HAS_CONTEXTUAL_SEQ_LEN:
        contextual_block_end = tl.cdiv(contextual_seq_len, BLOCK_M) * BLOCK_M
        if low < contextual_block_end:
            low = contextual_block_end
    offs_m = tl.arange(0, BLOCK_M)
    offs_qk_d = tl.arange(0, BLOCK_D_Q)
    offs_v_d = tl.arange(0, BLOCK_D_V)
    offs_n = start_n + tl.arange(0, BLOCK_N)
    dq_ptrs_trans = DQ + (offs_m[None, :] * stride_dqm + offs_qk_d[:, None])
    dv = tl.zeros([BLOCK_N, BLOCK_D_V], dtype=tl.float32)
    dk = tl.zeros([BLOCK_N, BLOCK_D_Q], dtype=tl.float32)
    if ENABLE_TMA:
        q_ptrs_trans = None
        do_ptrs = None
        k = device_desc_k.load([start_n, (off_h * stride_kh).to(tl.int32)])
        v = device_desc_v.load([start_n, (off_h * stride_vh).to(tl.int32)])
    else:
        mask_n = offs_n < seq_len
        q_ptrs_trans = Q + (offs_m[None, :] * stride_qm + offs_qk_d[:, None])
        do_ptrs = DOut + (offs_m[:, None] * stride_dom + offs_v_d[None, :])
        k_ptrs = K + (offs_n[:, None] * stride_kn + offs_qk_d[None, :])
        v_ptrs = V + (offs_n[:, None] * stride_vn + offs_v_d[None, :])
        k = tl.load(k_ptrs, mask=mask_n[:, None], other=0.0)
        v = tl.load(v_ptrs, mask=mask_n[:, None], other=0.0)
    max_ids = seq_len
    if HAS_CONTEXTUAL_SEQ_LEN:
        pos_offs_n = offs_n - contextual_seq_len + 1
        pos_offs_n = tl.where(pos_offs_n > 0, pos_offs_n, 0)
        max_ids = max_ids - contextual_seq_len + 1
    else:
        pos_offs_n = offs_n
    if HAS_MULTIPLE_TARGETS:
        max_ids = max_ids - n_targets
        pos_offs_n = tl.where(pos_offs_n < max_ids, pos_offs_n, max_ids)
    if HAS_CONTEXTUAL_SEQ_LEN:
        for start_m in range(0, contextual_seq_len, BLOCK_M):
            start_m = tl.multiple_of(start_m, BLOCK_M)
            dk, dv = _hstu_attn_bwd_one_block(
                start_m=start_m,
                offs_n=offs_n,
                offs_m=offs_m,
                q_ptrs_trans=q_ptrs_trans,
                dq_ptrs_trans=dq_ptrs_trans,
                do_ptrs=do_ptrs,
                device_desc_q=device_desc_q,
                device_desc_do=device_desc_do,
                dk=dk,
                dv=dv,
                k=k,
                v=v,
                pos_offs_n=pos_offs_n,
                seq_len=seq_len,
                max_ids=max_ids,
                contextual_seq_len=contextual_seq_len,
                max_attn_len=max_attn_len,
                scaling_seqlen=scaling_seqlen,
                LOCK=LOCK,
                off_h=off_h,
                stride_qh=stride_qh,
                stride_doh=stride_doh,
                stride_qm=stride_qm,
                stride_dom=stride_dom,
                stride_dqm=stride_dqm,
                alpha=alpha,
                MAX_SEQ_LEN=MAX_SEQ_LEN,
                HAS_MULTIPLE_TARGETS=HAS_MULTIPLE_TARGETS,
                HAS_CONTEXTUAL_SEQ_LEN=HAS_CONTEXTUAL_SEQ_LEN,
                HAS_MAX_ATTN_LEN=HAS_MAX_ATTN_LEN,
                ALLOW_TF32=ALLOW_TF32,
                BLOCK_M=BLOCK_M,
                ATOMIC_ADD=ATOMIC_ADD,
                ENABLE_TMA=ENABLE_TMA,
                BLOCK_D_Q=BLOCK_D_Q,
                BLOCK_D_V=BLOCK_D_V,
            )
    for start_m in tl.range(low, high, BLOCK_M, loop_unroll_factor=UNROLL):
        start_m = tl.multiple_of(start_m, BLOCK_M)
        dk, dv = _hstu_attn_bwd_one_block(
            start_m=start_m,
            offs_n=offs_n,
            offs_m=offs_m,
            q_ptrs_trans=q_ptrs_trans,
            dq_ptrs_trans=dq_ptrs_trans,
            do_ptrs=do_ptrs,
            device_desc_q=device_desc_q,
            device_desc_do=device_desc_do,
            dk=dk,
            dv=dv,
            k=k,
            v=v,
            pos_offs_n=pos_offs_n,
            seq_len=seq_len,
            max_ids=max_ids,
            contextual_seq_len=contextual_seq_len,
            max_attn_len=max_attn_len,
            scaling_seqlen=scaling_seqlen,
            LOCK=LOCK,
            off_h=off_h,
            stride_qh=stride_qh,
            stride_doh=stride_doh,
            stride_qm=stride_qm,
            stride_dom=stride_dom,
            stride_dqm=stride_dqm,
            alpha=alpha,
            MAX_SEQ_LEN=MAX_SEQ_LEN,
            HAS_MULTIPLE_TARGETS=HAS_MULTIPLE_TARGETS,
            HAS_CONTEXTUAL_SEQ_LEN=HAS_CONTEXTUAL_SEQ_LEN,
            HAS_MAX_ATTN_LEN=HAS_MAX_ATTN_LEN,
            ALLOW_TF32=ALLOW_TF32,
            BLOCK_M=BLOCK_M,
            ATOMIC_ADD=ATOMIC_ADD,
            ENABLE_TMA=ENABLE_TMA,
            BLOCK_D_Q=BLOCK_D_Q,
            BLOCK_D_V=BLOCK_D_V,
        )
    dk = dk * alpha
    if ENABLE_TMA:
        device_desc_dv.store(
            [start_n, (off_h * stride_dvh).to(tl.int32)], dv.to(k.dtype)
        )
        device_desc_dk.store(
            [start_n, (off_h * stride_dkh).to(tl.int32)], dk.to(k.dtype)
        )
    else:
        dv_ptrs = DV + (offs_n[:, None] * stride_dvn + offs_v_d[None, :])
        dk_ptrs = DK + (offs_n[:, None] * stride_dkn + offs_qk_d[None, :])
        tl.store(dv_ptrs, dv.to(k.dtype), mask=mask_n[:, None])
        tl.store(dk_ptrs, dk.to(k.dtype), mask=mask_n[:, None])


@triton.jit
def _hstu_attn_bwd(
    Q,
    K,
    V,
    tma_workspace_ptr,
    sort_by_length_indices,
    seq_offsets,
    num_targets,
    DOut,
    DQ,
    DK,
    DV,
    LOCK,
    stride_qm,
    stride_qh,
    stride_kn,
    stride_kh,
    stride_vn,
    stride_vh,
    stride_dom,
    stride_doh,
    stride_dqm,
    stride_dqh,
    stride_dkn,
    stride_dkh,
    stride_dvn,
    stride_dvh,
    alpha,
    scaling_seqlen,
    contextual_seq_len,
    max_attn_len,
    Z,
    AUTOTUNE_Z,
    H,
    MAX_SEQ_LEN,
    AUTOTUNE_MAX_SEQ_LEN,
    DimQ,
    DimV,
    HAS_MULTIPLE_TARGETS: tl.constexpr,
    HAS_CONTEXTUAL_SEQ_LEN: tl.constexpr,
    HAS_MAX_ATTN_LEN: tl.constexpr,
    ALLOW_TF32: tl.constexpr,
    BLOCK_D_Q: tl.constexpr,
    BLOCK_D_V: tl.constexpr,
    SEQUENCE_PARALLEL: tl.constexpr,
    BLOCK_M: tl.constexpr,
    BLOCK_N: tl.constexpr,
    UNROLL: tl.constexpr,
    HAS_SORT_BY_LENGTH_INDICES: tl.constexpr,
    ENABLE_TMA: tl.constexpr,
    TMA_DESC_SIZE: tl.constexpr,
    ENABLE_BUFFER_OPS_ASSUMES: tl.constexpr,
):
    off_hz = tl.program_id(0)
    off_z = off_hz // H
    if HAS_SORT_BY_LENGTH_INDICES:
        off_z = tl.load(sort_by_length_indices + off_z)
    off_h = off_hz % H
    off_h = off_h.to(tl.int64)
    seq_start = tl.load(seq_offsets + off_z).to(tl.int64)
    seq_end = tl.load(seq_offsets + off_z + 1)
    seq_len = (seq_end - seq_start).to(tl.int32)
    if HAS_MULTIPLE_TARGETS:
        n_targets = tl.load(num_targets + off_z).to(tl.int32)
    else:
        n_targets = None
    if ENABLE_BUFFER_OPS_ASSUMES:
        tl.assume(off_hz >= 0)
        tl.assume(off_z >= 0)
        tl.assume(off_h >= 0)
        tl.assume(seq_start >= 0)
        tl.assume(stride_qm >= 0)
        tl.assume(stride_qh >= 0)
        tl.assume(stride_kn >= 0)
        tl.assume(stride_kh >= 0)
        tl.assume(stride_vn >= 0)
        tl.assume(stride_vh >= 0)
        tl.assume(stride_dom >= 0)
        tl.assume(stride_doh >= 0)
        tl.assume(stride_dqm >= 0)
        tl.assume(stride_dqh >= 0)
        tl.assume(stride_dkn >= 0)
        tl.assume(stride_dkh >= 0)
        tl.assume(stride_dvn >= 0)
        tl.assume(stride_dvh >= 0)
    Q = Q + seq_start * stride_qm
    K = K + seq_start * stride_kn
    V = V + seq_start * stride_vn
    DOut = DOut + seq_start * stride_dom
    DQ = DQ + seq_start * stride_dqm + off_h * stride_dqh
    DK = DK + seq_start * stride_dkn
    DV = DV + seq_start * stride_dvn
    device_desc_q = None
    device_desc_k = None
    device_desc_v = None
    device_desc_do = None
    device_desc_dk = None
    device_desc_dv = None
    if ENABLE_TMA:
        device_desc_q = tl.make_tensor_descriptor(
            Q,
            shape=[seq_len, H * DimQ],
            strides=[H * DimQ, 1],
            block_shape=[BLOCK_M, BLOCK_D_Q],
        )
        device_desc_do = tl.make_tensor_descriptor(
            DOut,
            shape=[seq_len, H * DimV],
            strides=[H * DimV, 1],
            block_shape=[BLOCK_M, BLOCK_D_V],
        )
        device_desc_k = tl.make_tensor_descriptor(
            K,
            shape=[seq_len, H * DimQ],
            strides=[H * DimQ, 1],
            block_shape=[BLOCK_N, BLOCK_D_Q],
        )
        device_desc_dk = tl.make_tensor_descriptor(
            DK,
            shape=[seq_len, H * DimQ],
            strides=[H * DimQ, 1],
            block_shape=[BLOCK_N, BLOCK_D_Q],
        )
        device_desc_v = tl.make_tensor_descriptor(
            V,
            shape=[seq_len, H * DimV],
            strides=[H * DimV, 1],
            block_shape=[BLOCK_N, BLOCK_D_V],
        )
        device_desc_dv = tl.make_tensor_descriptor(
            DV,
            shape=[seq_len, H * DimV],
            strides=[H * DimV, 1],
            block_shape=[BLOCK_N, BLOCK_D_V],
        )
    else:
        Q += off_h * stride_qh
        K += off_h * stride_kh
        V += off_h * stride_vh
        DOut += off_h * stride_doh
        DK += off_h * stride_dkh
        DV += off_h * stride_dvh
    if SEQUENCE_PARALLEL:
        start_n = tl.program_id(1) * BLOCK_N
        if start_n >= seq_len:
            return
        _hstu_attn_bwd_one_col_block(
            start_n=start_n,
            seq_len=seq_len,
            n_targets=n_targets,
            contextual_seq_len=contextual_seq_len,
            max_attn_len=max_attn_len,
            scaling_seqlen=scaling_seqlen,
            Q=Q,
            K=K,
            V=V,
            DOut=DOut,
            DQ=DQ,
            DK=DK,
            DV=DV,
            device_desc_q=device_desc_q,
            device_desc_k=device_desc_k,
            device_desc_v=device_desc_v,
            device_desc_do=device_desc_do,
            device_desc_dk=device_desc_dk,
            device_desc_dv=device_desc_dv,
            LOCK=LOCK,
            off_h=off_h,
            stride_qh=stride_qh,
            stride_kh=stride_kh,
            stride_vh=stride_vh,
            stride_doh=stride_doh,
            stride_dkh=stride_dkh,
            stride_dvh=stride_dvh,
            stride_qm=stride_qm,
            stride_kn=stride_kn,
            stride_vn=stride_vn,
            stride_dom=stride_dom,
            stride_dqm=stride_dqm,
            stride_dkn=stride_dkn,
            stride_dvn=stride_dvn,
            alpha=alpha,
            MAX_SEQ_LEN=MAX_SEQ_LEN,
            HAS_MULTIPLE_TARGETS=HAS_MULTIPLE_TARGETS,
            HAS_CONTEXTUAL_SEQ_LEN=HAS_CONTEXTUAL_SEQ_LEN,
            HAS_MAX_ATTN_LEN=HAS_MAX_ATTN_LEN,
            ALLOW_TF32=ALLOW_TF32,
            BLOCK_D_Q=BLOCK_D_Q,
            BLOCK_D_V=BLOCK_D_V,
            BLOCK_M=BLOCK_M,
            BLOCK_N=BLOCK_N,
            UNROLL=UNROLL,
            ATOMIC_ADD=True,
            ENABLE_TMA=ENABLE_TMA,
        )
    else:
        for start_n in range(0, seq_len, BLOCK_N):
            _hstu_attn_bwd_one_col_block(
                start_n=start_n,
                seq_len=seq_len,
                n_targets=n_targets,
                contextual_seq_len=contextual_seq_len,
                max_attn_len=max_attn_len,
                scaling_seqlen=scaling_seqlen,
                Q=Q,
                K=K,
                V=V,
                DOut=DOut,
                DQ=DQ,
                DK=DK,
                DV=DV,
                device_desc_q=device_desc_q,
                device_desc_k=device_desc_k,
                device_desc_v=device_desc_v,
                device_desc_do=device_desc_do,
                device_desc_dk=device_desc_dk,
                device_desc_dv=device_desc_dv,
                LOCK=LOCK,
                off_h=off_h,
                stride_qh=stride_qh,
                stride_kh=stride_kh,
                stride_vh=stride_vh,
                stride_doh=stride_doh,
                stride_dkh=stride_dkh,
                stride_dvh=stride_dvh,
                stride_qm=stride_qm,
                stride_kn=stride_kn,
                stride_vn=stride_vn,
                stride_dom=stride_dom,
                stride_dqm=stride_dqm,
                stride_dkn=stride_dkn,
                stride_dvn=stride_dvn,
                alpha=alpha,
                MAX_SEQ_LEN=MAX_SEQ_LEN,
                HAS_MULTIPLE_TARGETS=HAS_MULTIPLE_TARGETS,
                HAS_CONTEXTUAL_SEQ_LEN=HAS_CONTEXTUAL_SEQ_LEN,
                HAS_MAX_ATTN_LEN=HAS_MAX_ATTN_LEN,
                ALLOW_TF32=ALLOW_TF32,
                BLOCK_D_Q=BLOCK_D_Q,
                BLOCK_D_V=BLOCK_D_V,
                BLOCK_M=BLOCK_M,
                BLOCK_N=BLOCK_N,
                UNROLL=UNROLL,
                ATOMIC_ADD=False,
                ENABLE_TMA=ENABLE_TMA,
            )


def test_hstu_attn_bwd():
    generator = torch.Generator().manual_seed(20261011)
    h, d, total = (2, 16, 8)
    q = (torch.randn((total, h, d), generator=generator) * 0.2).to(torch.float16)
    k = (torch.randn((total, h, d), generator=generator) * 0.2).to(torch.float16)
    v = (torch.randn((total, h, d), generator=generator) * 0.2).to(torch.float16)
    dy = (torch.randn((total, h, d), generator=generator) * 0.2).to(torch.float16)
    offset = torch.tensor([0, 3, 8], dtype=torch.int32)
    alpha = 0.25
    qq = q.double().requires_grad_()
    kk = k.double().requires_grad_()
    vv = v.double().requires_grad_()
    ys = []
    for st, en in [(0, 3), (3, 8)]:
        score = qq[st:en].transpose(0, 1) @ kk[st:en].permute(1, 2, 0) * alpha
        mask = torch.ones(en - st, en - st).tril()
        ys.append(
            (
                torch.nn.functional.silu(score) * mask / 5 @ vv[st:en].transpose(0, 1)
            ).transpose(0, 1)
        )
    ref = torch.cat(ys)
    (ref * dy.double()).sum().backward()
    workspace = torch.zeros(256, dtype=torch.uint8).npu()
    targets = torch.tensor([0, 0], dtype=torch.int32).npu()
    indices = torch.tensor([0, 1], dtype=torch.int32).npu()
    offs = offset.npu()
    opts = dict(
        HAS_MULTIPLE_TARGETS=False,
        HAS_CONTEXTUAL_SEQ_LEN=False,
        HAS_MAX_ATTN_LEN=False,
        ALLOW_TF32=False,
        BLOCK_D_Q=d,
        BLOCK_D_V=d,
        BLOCK_M=16,
        BLOCK_N=16,
        HAS_SORT_BY_LENGTH_INDICES=False,
        ENABLE_TMA=False,
        TMA_DESC_SIZE=128,
    )
    dq = torch.zeros_like(q).npu()
    dk = torch.full_like(k, 23.0).npu()
    dv = torch.full_like(v, 23.0).npu()
    locks = torch.zeros(64, dtype=torch.int32).npu()
    _hstu_attn_bwd[4,](
        q.npu(),
        k.npu(),
        v.npu(),
        workspace,
        indices,
        offs,
        targets,
        dy.npu(),
        dq,
        dk,
        dv,
        locks,
        *[32, 16] * 7,
        alpha,
        5,
        0,
        0,
        2,
        2,
        h,
        5,
        8,
        d,
        d,
        SEQUENCE_PARALLEL=False,
        UNROLL=1,
        ENABLE_BUFFER_OPS_ASSUMES=False,
        **opts
    )
    actual_dq = dq.cpu()
    expected_dq = qq.grad
    torch.testing.assert_close(
        (actual_dq).double(),
        (expected_dq).double(),
        atol=0.0002,
        rtol=0.002,
        check_dtype=False,
    )
    assert torch.isfinite(actual_dq).all() and torch.isfinite(expected_dq).all()
    actual_dk = dk.cpu()
    expected_dk = kk.grad
    torch.testing.assert_close(
        (actual_dk).double(),
        (expected_dk).double(),
        atol=0.0002,
        rtol=0.002,
        check_dtype=False,
    )
    assert torch.isfinite(actual_dk).all() and torch.isfinite(expected_dk).all()
    actual_dv = dv.cpu()
    expected_dv = vv.grad
    torch.testing.assert_close(
        (actual_dv).double(),
        (expected_dv).double(),
        atol=0.0002,
        rtol=0.002,
        check_dtype=False,
    )
    assert torch.isfinite(actual_dv).all() and torch.isfinite(expected_dv).all()
    print("PASS: hstu_attn_bwd")


if __name__ == "__main__":
    test_hstu_attn_bwd()

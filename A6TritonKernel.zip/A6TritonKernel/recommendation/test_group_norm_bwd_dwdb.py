# Source: tests/kernels/triton_norm_mul_dropout.py

import torch
import torch_npu
import triton
import triton.language as tl


@triton.jit
def _group_norm_bwd_dwdb(DW, DB, FINAL_DW, FINAL_DB, N, BLOCK_N: tl.constexpr):
    col = tl.program_id(0)
    num_heads = tl.num_programs(0)
    dw = tl.zeros((BLOCK_N,), dtype=tl.float32)
    db = tl.zeros((BLOCK_N,), dtype=tl.float32)
    for i in range(0, N, BLOCK_N):
        rows = i + tl.arange(0, BLOCK_N)
        mask = rows < N
        offs = rows * num_heads + col
        dw += tl.load(DW + offs, mask=mask, other=0.0)
        db += tl.load(DB + offs, mask=mask, other=0.0)
    sum_dw = tl.sum(dw, axis=0)
    sum_db = tl.sum(db, axis=0)
    tl.store(FINAL_DW + col, sum_dw.to(FINAL_DW.dtype.element_ty))
    tl.store(FINAL_DB + col, sum_db.to(FINAL_DB.dtype.element_ty))


def test_group_norm_bwd_dwdb():
    generator = torch.Generator().manual_seed(20261011)
    dw = (torch.randn((5, 7), generator=generator) * 0.2).to(torch.float32)
    db = (torch.randn((5, 7), generator=generator) * 0.2).to(torch.float32)
    ow = torch.full((7,), 23.0).npu()
    ob = torch.full((7,), 23.0).npu()
    _group_norm_bwd_dwdb[7,](dw.npu(), db.npu(), ow, ob, 5, BLOCK_N=4)
    actual_dw = ow.cpu()
    expected_dw = dw.sum(0)
    torch.testing.assert_close(
        (actual_dw).double(),
        (expected_dw).double(),
        atol=0.0002,
        rtol=0.002,
        check_dtype=False,
    )
    assert torch.isfinite(actual_dw).all() and torch.isfinite(expected_dw).all()
    actual_db = ob.cpu()
    expected_db = db.sum(0)
    torch.testing.assert_close(
        (actual_db).double(),
        (expected_db).double(),
        atol=0.0002,
        rtol=0.002,
        check_dtype=False,
    )
    assert torch.isfinite(actual_db).all() and torch.isfinite(expected_db).all()
    print("PASS: group_norm_bwd_dwdb")


if __name__ == "__main__":
    test_group_norm_bwd_dwdb()

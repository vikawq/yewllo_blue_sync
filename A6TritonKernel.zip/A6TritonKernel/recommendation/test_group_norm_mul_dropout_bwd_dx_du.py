# Source: tests/kernels/triton_norm_mul_dropout.py

import torch
import torch_npu
import triton
import triton.language as tl


@triton.jit
def _group_norm_mul_dropout_bwd_dx_du(
    DX,
    DU,
    DY,
    DW,
    DB,
    X,
    U,
    Y,
    W,
    B,
    Mean,
    Rstd,
    stride_dx,
    stride_du0,
    stride_dy,
    stride_x,
    stride_u0,
    stride_y,
    D,
    Heads,
    eps,
    seed,
    dropout_ratio,
    GROUP_N: tl.constexpr,
    BLOCK_D: tl.constexpr,
    BLOCK_H: tl.constexpr,
    TRAINING: tl.constexpr,
    CONCAT_UX: tl.constexpr,
    COMPUTE_Y: tl.constexpr,
):
    row = tl.program_id(0)
    cols = tl.arange(0, BLOCK_D)
    off_heads = tl.arange(0, BLOCK_H)
    mask_c = cols < D
    mask_h = off_heads < Heads
    mask = mask_c[None, :] & mask_h[:, None]
    X += row.to(tl.int64) * stride_x
    U += row.to(tl.int64) * stride_u0
    DY += row.to(tl.int64) * stride_dy
    DX += row.to(tl.int64) * stride_dx
    DU += row.to(tl.int64) * stride_du0
    offsets = off_heads[:, None] * D + cols[None, :]
    x = tl.load(X + offsets, mask=mask, other=0).to(tl.float32)
    if CONCAT_UX:
        du = tl.load(DY + offsets, mask=mask, other=0).to(tl.float32)
        dx = tl.load(DY + Heads * D + offsets, mask=mask, other=0).to(tl.float32)
        dy = tl.load(DY + 2 * Heads * D + offsets, mask=mask, other=0).to(tl.float32)
    else:
        du = tl.zeros([BLOCK_H, BLOCK_D], dtype=tl.float32)
        dx = tl.zeros([BLOCK_H, BLOCK_D], dtype=tl.float32)
        dy = tl.load(DY + offsets, mask=mask, other=0).to(tl.float32)
    if TRAINING:
        if CONCAT_UX:
            random_offsets = row * 3 * D * Heads + offsets
            random_du = tl.rand(seed, random_offsets)
            du_keep = (random_du > dropout_ratio) | (dropout_ratio == 0.0)
            du = tl.where(du_keep, du / (1.0 - dropout_ratio), 0.0)
            random_dx = tl.rand(seed, random_offsets + Heads * D)
            dx_keep = (random_dx > dropout_ratio) | (dropout_ratio == 0.0)
            dx = tl.where(dx_keep, dx / (1.0 - dropout_ratio), 0.0)
            random_dy = tl.rand(seed, random_offsets + 2 * Heads * D)
            dy_keep = (random_dy > dropout_ratio) | (dropout_ratio == 0.0)
            dy = tl.where(dy_keep, dy / (1.0 - dropout_ratio), 0.0)
        else:
            random_offsets = row * D * Heads + offsets
            random = tl.rand(seed, random_offsets)
            dy_keep = (random > dropout_ratio) | (dropout_ratio == 0.0)
            dy = tl.where(dy_keep, dy / (1.0 - dropout_ratio), 0.0)
    mean = tl.load(Mean + row * Heads + off_heads)
    rstd = tl.load(Rstd + row * Heads + off_heads)
    xhat = (x - mean[:, None]) * rstd[:, None]
    w = tl.load(W + off_heads, mask=mask_h).to(tl.float32)
    b = tl.load(B + off_heads, mask=mask_h).to(tl.float32)
    ln = xhat * w[:, None] + b[:, None]
    du += dy * ln
    tl.store(DU + offsets, du.to(DU.dtype.element_ty), mask=mask)
    u = tl.load(U + offsets, mask=mask, other=0).to(tl.float32)
    dy = dy * u
    wdy = w[:, None] * dy
    if COMPUTE_Y:
        Y += row.to(tl.int64) * stride_y
        y = ln * u
        if TRAINING:
            if CONCAT_UX:
                u = tl.where(du_keep, u / (1.0 - dropout_ratio), 0.0)
                x = tl.where(dx_keep, x / (1.0 - dropout_ratio), 0.0)
                y = tl.where(dy_keep, y / (1.0 - dropout_ratio), 0.0)
            else:
                y = tl.where(dy_keep, y / (1.0 - dropout_ratio), 0.0)
        if CONCAT_UX:
            tl.store(Y + offsets, u.to(Y.dtype.element_ty), mask=mask)
            tl.store(Y + Heads * D + offsets, x.to(Y.dtype.element_ty), mask=mask)
            tl.store(Y + 2 * Heads * D + offsets, y.to(Y.dtype.element_ty), mask=mask)
        else:
            tl.store(Y + offsets, y.to(Y.dtype.element_ty), mask=mask)
    xhat = tl.where(mask, xhat, 0.0)
    wdy = tl.where(mask, wdy, 0.0)
    c1 = tl.sum(xhat * wdy, axis=1) / D
    c2 = tl.sum(wdy, axis=1) / D
    dx += (wdy - (xhat * c1[:, None] + c2[:, None])) * rstd[:, None]
    tl.store(DX + offsets, dx, mask=mask)
    lock_id = row % GROUP_N
    DW = DW + lock_id * Heads + off_heads
    DB = DB + lock_id * Heads + off_heads
    partial_dw = tl.sum(dy * xhat, axis=1)
    partial_dw = tl.ravel(partial_dw)
    partial_db = tl.sum(dy, axis=1)
    partial_db = tl.ravel(partial_db)
    tl.atomic_add(DW, partial_dw, mask=mask_h, sem="relaxed")
    tl.atomic_add(DB, partial_db, mask=mask_h, sem="relaxed")


def philox_uniform(seed, count):
    """CPU Philox4x32-10 reference for tl.rand."""
    values = []
    mask = (1 << 32) - 1
    for offset in range(count):
        c0, c1, c2, c3 = (offset, 0, 0, 0)
        k0, k1 = (seed & mask, seed >> 32 & mask)
        for _ in range(10):
            a = 3528531795 * c0
            b = 3449720151 * c2
            c0, c1, c2, c3 = (
                (b >> 32 ^ c1 ^ k0) & mask,
                b & mask,
                (a >> 32 ^ c3 ^ k1) & mask,
                a & mask,
            )
            k0 = k0 + 2654435769 & mask
            k1 = k1 + 3144134277 & mask
        value = c0 if c0 < 1 << 31 else mask - c0
        values.append(value)
    return torch.tensor(values, dtype=torch.float32) * torch.tensor(
        4.6566127342e-10, dtype=torch.float32
    )


def test_group_norm_mul_dropout_bwd_dx_du():
    generator = torch.Generator().manual_seed(20261011)
    n, h, d = (3, 2, 7)
    width = h * d
    x = (torch.randn((n, h, d), generator=generator) * 0.2).to(torch.float32)
    u = (torch.randn((n, h, d), generator=generator) * 0.2).to(torch.float32)
    w = (torch.randn((h,), generator=generator) * 0.2).to(torch.float32) + 1
    b = (torch.randn((h,), generator=generator) * 0.2).to(torch.float32)
    mean = x.mean(-1)
    rs = (x.var(-1, unbiased=False) + 1e-05).rsqrt()
    xh = (x - mean[..., None]) * rs[..., None]
    wa = w[None, :, None]
    ba = b[None, :, None]
    dropout = 0.25
    randoms = philox_uniform(123, n * h * d).reshape(n, h, d)
    factor = (randoms > dropout).float() / (1 - dropout)
    y = (xh * wa + ba) * u * factor
    out = torch.full_like(x, 23.0).npu()
    dy = (torch.randn((n, h, d), generator=generator) * 0.2).to(torch.float32)
    dx = torch.full_like(x, 23.0).npu()
    du = torch.full_like(u, 23.0).npu()
    dw = torch.zeros(n, h).npu()
    db = torch.zeros(n, h).npu()
    xx = x.double().requires_grad_()
    uu = u.double().requires_grad_()
    ww = w.double().requires_grad_()
    bb = b.double().requires_grad_()
    yy = (
        torch.nn.functional.layer_norm(xx, (d,), None, None, 1e-05) * ww[None, :, None]
        + bb[None, :, None]
    )
    yy = yy * uu * factor.double()
    (yy * dy.double()).sum().backward()
    _group_norm_mul_dropout_bwd_dx_du[n,](
        dx,
        du,
        dy.npu(),
        dw,
        db,
        x.npu(),
        u.npu(),
        out,
        w.npu(),
        b.npu(),
        mean.npu(),
        rs.npu(),
        width,
        width,
        width,
        width,
        width,
        width,
        d,
        h,
        1e-05,
        123,
        dropout,
        GROUP_N=n,
        BLOCK_D=8,
        BLOCK_H=2,
        TRAINING=True,
        CONCAT_UX=False,
        COMPUTE_Y=True,
    )
    actual_dx = dx.cpu()
    expected_dx = xx.grad
    torch.testing.assert_close(
        (actual_dx).double(),
        (expected_dx).double(),
        atol=0.0002,
        rtol=0.002,
        check_dtype=False,
    )
    assert torch.isfinite(actual_dx).all() and torch.isfinite(expected_dx).all()
    actual_du = du.cpu()
    expected_du = uu.grad
    torch.testing.assert_close(
        (actual_du).double(),
        (expected_du).double(),
        atol=0.0002,
        rtol=0.002,
        check_dtype=False,
    )
    assert torch.isfinite(actual_du).all() and torch.isfinite(expected_du).all()
    actual_y = out.cpu()
    expected_y = y
    torch.testing.assert_close(
        (actual_y).double(),
        (expected_y).double(),
        atol=0.0002,
        rtol=0.002,
        check_dtype=False,
    )
    assert torch.isfinite(actual_y).all() and torch.isfinite(expected_y).all()
    actual_dw = dw.cpu()
    expected_dw = (dy * factor * u * xh).sum(-1)
    torch.testing.assert_close(
        (actual_dw).double(),
        (expected_dw).double(),
        atol=0.0002,
        rtol=0.002,
        check_dtype=False,
    )
    assert torch.isfinite(actual_dw).all() and torch.isfinite(expected_dw).all()
    actual_db = db.cpu()
    expected_db = (dy * factor * u).sum(-1)
    torch.testing.assert_close(
        (actual_db).double(),
        (expected_db).double(),
        atol=0.0002,
        rtol=0.002,
        check_dtype=False,
    )
    assert torch.isfinite(actual_db).all() and torch.isfinite(expected_db).all()
    print("PASS: group_norm_mul_dropout_bwd_dx_du")


if __name__ == "__main__":
    test_group_norm_mul_dropout_bwd_dx_du()

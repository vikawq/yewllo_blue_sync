# Source: tests/kernels/triton_hstu_attention.py

import torch
import torch_npu
import triton
import triton.language as tl

tlx = None
from triton.language.extra.cann.libdevice import fast_dividef, fast_expf


@triton.jit
def _hstu_attn_fwd_one_block(
    start_n,
    seq_len,
    offs_m,
    offs_n,
    q,
    K,
    V,
    K_block_ptr,
    V_block_ptr,
    offset_kh,
    offset_vh,
    seq_start,
    n_targets,
    alpha,
    MAX_SEQ_LEN,
    scaling_seqlen,
    contextual_seq_len,
    max_attn_len,
    HAS_MULTIPLE_TARGETS: tl.constexpr,
    HAS_CONTEXTUAL_SEQ_LEN: tl.constexpr,
    HAS_MAX_ATTN_LEN: tl.constexpr,
    ALLOW_TF32: tl.constexpr,
    BLOCK_D_Q: tl.constexpr,
    BLOCK_D_V: tl.constexpr,
    BLOCK_N: tl.constexpr,
    ENABLE_TMA: tl.constexpr,
):
    start_n = tl.multiple_of(start_n, BLOCK_N)
    k = None
    qk = None
    if ENABLE_TMA:
        k = K.load([(seq_start + start_n).to(tl.int32), offset_kh.to(tl.int32)])
        qk = tl.dot(q, tl.trans(k), allow_tf32=ALLOW_TF32) * alpha
    else:
        k = tl.load(K_block_ptr, boundary_check=(1,), padding_option="zero")
        qk = tl.dot(q, k, allow_tf32=ALLOW_TF32) * alpha
    invalid_mask = offs_m[:, None] == offs_n[None, :]
    max_ids = seq_len
    if HAS_CONTEXTUAL_SEQ_LEN:
        offs_m = offs_m - contextual_seq_len + 1
        offs_m = tl.where(offs_m > 0, offs_m, 0)
        offs_n = offs_n - contextual_seq_len + 1
        offs_n = tl.where(offs_n > 0, offs_n, 0)
        max_ids = max_ids - contextual_seq_len + 1
    if HAS_MULTIPLE_TARGETS:
        max_ids = max_ids - n_targets
        offs_m = tl.where(offs_m < max_ids, offs_m, max_ids)
        offs_n = tl.where(offs_n < max_ids, offs_n, max_ids)
    offs_m_minus_n = offs_m[:, None] - offs_n[None, :]
    invalid_mask = invalid_mask | (offs_m_minus_n > 0)
    if HAS_MAX_ATTN_LEN:
        invalid_mask = invalid_mask & (offs_m_minus_n <= max_attn_len)
    if HAS_CONTEXTUAL_SEQ_LEN:
        invalid_mask = invalid_mask | (offs_m[:, None] == 0) & (
            offs_n[None, :] < max_ids
        )
    scale = tl.where(invalid_mask, 1.0 / scaling_seqlen, 0.0)
    silu = fast_dividef(qk, 1.0 + fast_expf(-qk)) * scale
    v = None
    if ENABLE_TMA:
        v = V.load([(seq_start + start_n).to(tl.int32), offset_vh.to(tl.int32)])
    else:
        v = tl.load(V_block_ptr, boundary_check=(0,), padding_option="zero")
    silu = silu.to(v.dtype)
    return tl.dot(silu, v, allow_tf32=ALLOW_TF32)


@triton.jit
def _hstu_attn_fwd_compute(
    Q,
    K,
    V,
    H,
    DimQ,
    DimV,
    workspace_ptr,
    seq_offsets,
    num_targets,
    Out,
    stride_qm,
    stride_qh,
    stride_kn,
    stride_kh,
    stride_vn,
    stride_vh,
    stride_om,
    stride_oh,
    alpha,
    MAX_SEQ_LEN,
    scaling_seqlen,
    DeltaSize,
    contextual_seq_len,
    max_attn_len,
    off_z,
    off_h,
    pid,
    HAS_MULTIPLE_TARGETS: tl.constexpr,
    IS_DELTA_Q: tl.constexpr,
    ALLOW_TF32: tl.constexpr,
    BLOCK_D_Q: tl.constexpr,
    BLOCK_D_V: tl.constexpr,
    BLOCK_M: tl.constexpr,
    BLOCK_N: tl.constexpr,
    HAS_CONTEXTUAL_SEQ_LEN: tl.constexpr,
    HAS_MAX_ATTN_LEN: tl.constexpr,
    ENABLE_TMA: tl.constexpr,
    TMA_DESC_SIZE: tl.constexpr,
):
    seq_start = tl.load(seq_offsets + off_z).to(tl.int64)
    off_h = off_h.to(tl.int64)
    off_z = off_z.to(tl.int64)
    seq_end = tl.load(seq_offsets + off_z + 1)
    seq_len = (seq_end - seq_start).to(tl.int32)
    if IS_DELTA_Q:
        start_m_delta = pid * BLOCK_M
        start_m = (start_m_delta + seq_len - DeltaSize).to(tl.int32)
    else:
        start_m_delta = 0
        start_m = pid * BLOCK_M
    if start_m < seq_len:
        if HAS_MULTIPLE_TARGETS:
            n_targets = tl.load(num_targets + off_z).to(tl.int32)
        else:
            n_targets = None
        offs_m = start_m + tl.arange(0, BLOCK_M)
        offs_n = tl.arange(0, BLOCK_N)
        Q_block_ptr = None
        K_block_ptr = None
        V_block_ptr = None
        if not ENABLE_TMA:
            if IS_DELTA_Q:
                Q_block_ptr = tl.make_block_ptr(
                    base=Q + off_h * stride_qh + off_z * DeltaSize * stride_qm,
                    shape=(DeltaSize, BLOCK_D_Q),
                    strides=(stride_qm, 1),
                    offsets=(start_m_delta, 0),
                    block_shape=(BLOCK_M, BLOCK_D_Q),
                    order=(1, 0),
                )
            else:
                Q_block_ptr = tl.make_block_ptr(
                    base=Q + off_h * stride_qh + seq_start * stride_qm,
                    shape=(seq_len, BLOCK_D_Q),
                    strides=(stride_qm, 1),
                    offsets=(start_m, 0),
                    block_shape=(BLOCK_M, BLOCK_D_Q),
                    order=(1, 0),
                )
            q = tl.load(Q_block_ptr, boundary_check=(0,), padding_option="zero")
            K_block_ptr = tl.make_block_ptr(
                base=K + off_h * stride_kh + seq_start * stride_kn,
                shape=(BLOCK_D_Q, seq_len),
                strides=(1, stride_kn),
                offsets=(0, 0),
                block_shape=(BLOCK_D_Q, BLOCK_N),
                order=(0, 1),
            )
            V_block_ptr = tl.make_block_ptr(
                base=V + off_h * stride_vh + seq_start * stride_vn,
                shape=(seq_len, BLOCK_D_V),
                strides=(stride_vn, 1),
                offsets=(0, 0),
                block_shape=(BLOCK_N, BLOCK_D_V),
                order=(1, 0),
            )
        elif IS_DELTA_Q:
            q = Q.load(
                [
                    (off_z * DeltaSize + start_m_delta).to(tl.int32),
                    (off_h * stride_qh).to(tl.int32),
                ]
            )
        else:
            q = Q.load(
                [(seq_start + start_m).to(tl.int32), (off_h * stride_qh).to(tl.int32)]
            )
        acc = tl.zeros([BLOCK_M, BLOCK_D_V], dtype=tl.float32)
        if HAS_MULTIPLE_TARGETS:
            uih_end = seq_len - n_targets
        else:
            uih_end = seq_len
        if HAS_CONTEXTUAL_SEQ_LEN is True and start_m < contextual_seq_len:
            low = 0
            high = seq_len
        else:
            low = 0
            high = start_m + BLOCK_M
            if HAS_MAX_ATTN_LEN:
                if start_m > uih_end:
                    low = uih_end - max_attn_len
                else:
                    low = start_m - max_attn_len
                if HAS_CONTEXTUAL_SEQ_LEN:
                    low = low if low > contextual_seq_len else 0
                else:
                    low = low if low > 0 else 0
            if HAS_MULTIPLE_TARGETS:
                uih_end = (uih_end + BLOCK_N - 1) // BLOCK_N * BLOCK_N
                if uih_end < start_m:
                    high = seq_len - n_targets
        if low > 0:
            if not ENABLE_TMA:
                K_block_ptr = tl.advance(K_block_ptr, (0, low))
                V_block_ptr = tl.advance(V_block_ptr, (low, 0))
        end_n = low
        for start_n in range(low, high, BLOCK_N):
            acc += _hstu_attn_fwd_one_block(
                start_n=start_n,
                seq_len=seq_len,
                offs_m=offs_m,
                offs_n=offs_n + start_n,
                q=q,
                K=K,
                V=V,
                K_block_ptr=K_block_ptr,
                V_block_ptr=V_block_ptr,
                offset_kh=off_h * stride_kh,
                offset_vh=off_h * stride_vh,
                seq_start=seq_start,
                n_targets=n_targets if HAS_MULTIPLE_TARGETS else None,
                alpha=alpha,
                MAX_SEQ_LEN=MAX_SEQ_LEN,
                scaling_seqlen=scaling_seqlen,
                contextual_seq_len=contextual_seq_len,
                max_attn_len=max_attn_len,
                HAS_MULTIPLE_TARGETS=HAS_MULTIPLE_TARGETS,
                HAS_CONTEXTUAL_SEQ_LEN=HAS_CONTEXTUAL_SEQ_LEN,
                HAS_MAX_ATTN_LEN=HAS_MAX_ATTN_LEN,
                ALLOW_TF32=ALLOW_TF32,
                BLOCK_D_Q=BLOCK_D_Q,
                BLOCK_D_V=BLOCK_D_V,
                BLOCK_N=BLOCK_N,
                ENABLE_TMA=ENABLE_TMA,
            )
            if not ENABLE_TMA:
                K_block_ptr = tl.advance(K_block_ptr, (0, BLOCK_N))
                V_block_ptr = tl.advance(V_block_ptr, (BLOCK_N, 0))
            end_n += BLOCK_N
        if HAS_MULTIPLE_TARGETS:
            if uih_end < start_m:
                low_delta = start_m
                high_delta = start_m + BLOCK_M
                offset = (low_delta - end_n).to(tl.int32)
                if not ENABLE_TMA:
                    K_block_ptr = tl.advance(K_block_ptr, (0, offset))
                    V_block_ptr = tl.advance(V_block_ptr, (offset, 0))
                for start_delta in tl.range(
                    low_delta, high_delta, BLOCK_N, num_stages=0
                ):
                    acc += _hstu_attn_fwd_one_block(
                        start_n=start_delta,
                        seq_len=seq_len,
                        offs_m=offs_m,
                        offs_n=offs_n + start_delta,
                        q=q,
                        K=K,
                        V=V,
                        K_block_ptr=K_block_ptr,
                        V_block_ptr=V_block_ptr,
                        offset_kh=off_h * stride_kh,
                        offset_vh=off_h * stride_vh,
                        seq_start=seq_start,
                        n_targets=n_targets if HAS_MULTIPLE_TARGETS else None,
                        alpha=alpha,
                        MAX_SEQ_LEN=MAX_SEQ_LEN,
                        scaling_seqlen=scaling_seqlen,
                        contextual_seq_len=contextual_seq_len,
                        max_attn_len=max_attn_len,
                        HAS_MULTIPLE_TARGETS=HAS_MULTIPLE_TARGETS,
                        HAS_CONTEXTUAL_SEQ_LEN=HAS_CONTEXTUAL_SEQ_LEN,
                        HAS_MAX_ATTN_LEN=HAS_MAX_ATTN_LEN,
                        ALLOW_TF32=ALLOW_TF32,
                        BLOCK_D_Q=BLOCK_D_Q,
                        BLOCK_D_V=BLOCK_D_V,
                        BLOCK_N=BLOCK_N,
                        ENABLE_TMA=ENABLE_TMA,
                    )
                    if not ENABLE_TMA:
                        K_block_ptr = tl.advance(K_block_ptr, (0, BLOCK_N))
                        V_block_ptr = tl.advance(V_block_ptr, (BLOCK_N, 0))
        if IS_DELTA_Q:
            start_m_delta = pid * BLOCK_M
            offs_m_delta = start_m_delta + tl.arange(0, BLOCK_M)
            offs_v_d = tl.arange(0, BLOCK_D_V)
            off_o = Out + off_z * DeltaSize * stride_om + off_h * stride_oh
            out_ptrs = off_o + offs_m_delta[:, None] * stride_om + offs_v_d[None, :]
            tl.store(out_ptrs, acc, mask=(offs_m_delta < DeltaSize)[:, None])
        else:
            start_m = pid * BLOCK_M
            offs_m = start_m + tl.arange(0, BLOCK_M)
            offs_v_d = tl.arange(0, BLOCK_D_V)
            off_o = Out + seq_start * stride_om + off_h * stride_oh
            out_ptrs = off_o + offs_m[:, None] * stride_om + offs_v_d[None, :]
            tl.store(out_ptrs, acc, mask=(offs_m < seq_len)[:, None])


@triton.jit
def _hstu_attn_fwd_compute_main_loop_tlx(
    low,
    high,
    seq_len,
    offs_m,
    offs_n,
    acc,
    q_tiles,
    k_tiles,
    v_tiles,
    q_fulls,
    k_fulls,
    v_fulls,
    k_empties,
    v_empties,
    v_dtype,
    n_targets,
    alpha,
    end_n,
    loop_trip_cnt,
    max_attn_len,
    scaling_seqlen,
    HAS_MULTIPLE_TARGETS: tl.constexpr,
    HAS_CONTEXTUAL_SEQ_LEN: tl.constexpr,
    HAS_MAX_ATTN_LEN: tl.constexpr,
    cid: tl.constexpr,
    BLOCK_N: tl.constexpr,
    NUM_BUFFERS: tl.constexpr,
    MAX_SEQ_LEN: tl.constexpr,
    WAIT_FOR_Q: tl.constexpr,
):
    if WAIT_FOR_Q:
        q_full = tlx.local_view(q_fulls, cid)
        tlx.barrier_wait(q_full, 0)
    q_tile = tlx.local_view(q_tiles, cid)
    for start in tl.range(low + BLOCK_N, high, BLOCK_N, num_stages=0):
        buf_id = loop_trip_cnt % NUM_BUFFERS
        kv_phase = loop_trip_cnt // NUM_BUFFERS % 2
        start_n = tl.multiple_of(start, BLOCK_N)
        offs_n_start = offs_n
        offs_n = offs_n_start + start_n
        k_full = tlx.local_view(k_fulls, buf_id)
        tlx.barrier_wait(k_full, kv_phase)
        k_tile = tlx.local_view(k_tiles, buf_id)
        k_tile = tlx.local_trans(k_tile)
        qk = tlx.async_dot(q_tile, k_tile)
        qk = tlx.async_dot_wait(0, qk)
        k_empty = tlx.local_view(k_empties, buf_id)
        tlx.barrier_arrive(k_empty, 1)
        qk = qk * alpha
        invalid_mask = offs_m[:, None] == offs_n[None, :]
        max_ids = seq_len
        if HAS_MULTIPLE_TARGETS:
            max_ids = max_ids - n_targets
            offs_m = tl.where(offs_m < max_ids, offs_m, max_ids)
            offs_n = tl.where(offs_n < max_ids, offs_n, max_ids)
        offs_m_minus_n = offs_m[:, None] - offs_n[None, :]
        invalid_mask = invalid_mask | (offs_m_minus_n > 0)
        if HAS_MAX_ATTN_LEN:
            invalid_mask = invalid_mask & (offs_m_minus_n <= max_attn_len)
        if HAS_CONTEXTUAL_SEQ_LEN:
            invalid_mask = invalid_mask | (offs_m[:, None] == 0) & (
                offs_n[None, :] < max_ids
            )
        scale = tl.where(invalid_mask, 1.0 / scaling_seqlen, 0.0)
        silu = fast_dividef(qk, 1.0 + fast_expf(-qk)) * scale
        silu = silu.to(v_dtype)
        v_full = tlx.local_view(v_fulls, buf_id)
        tlx.barrier_wait(v_full, kv_phase)
        v_tile = tlx.local_view(v_tiles, buf_id)
        acc = tlx.async_dot(silu, v_tile, acc)
        acc = tlx.async_dot_wait(0, acc)
        v_empty = tlx.local_view(v_empties, buf_id)
        tlx.barrier_arrive(v_empty, 1)
        end_n += BLOCK_N
        loop_trip_cnt += 1
    return (acc, end_n, loop_trip_cnt)


@triton.jit
def _hstu_attn_fwd_compute_main_loop_tlx_pipelined(
    low,
    high,
    seq_len,
    offs_m,
    offs_n,
    acc,
    q_tiles,
    k_tiles,
    v_tiles,
    q_fulls,
    k_fulls,
    v_fulls,
    k_empties,
    v_empties,
    v_dtype,
    n_targets,
    alpha,
    end_n,
    loop_trip_cnt,
    max_attn_len,
    scaling_seqlen,
    HAS_MULTIPLE_TARGETS: tl.constexpr,
    HAS_CONTEXTUAL_SEQ_LEN: tl.constexpr,
    HAS_MAX_ATTN_LEN: tl.constexpr,
    cid: tl.constexpr,
    BLOCK_N: tl.constexpr,
    NUM_BUFFERS: tl.constexpr,
    MAX_SEQ_LEN: tl.constexpr,
    WAIT_FOR_Q: tl.constexpr,
):
    if WAIT_FOR_Q:
        q_full = tlx.local_view(q_fulls, cid)
        tlx.barrier_wait(q_full, 0)
    q_tile = tlx.local_view(q_tiles, cid)
    k_buf_id = loop_trip_cnt % NUM_BUFFERS
    k_phase = loop_trip_cnt // NUM_BUFFERS % 2
    k_full = tlx.local_view(k_fulls, k_buf_id)
    tlx.barrier_wait(k_full, k_phase)
    k_tile = tlx.local_view(k_tiles, k_buf_id)
    k_tile = tlx.local_trans(k_tile)
    if cid == 0:
        tlx.named_barrier_wait(9, 256)
    else:
        tlx.named_barrier_arrive(9, 256)
        tlx.named_barrier_wait(10, 256)
    qk = tlx.async_dot(q_tile, k_tile)
    if cid == 0:
        tlx.named_barrier_arrive(10, 256)
    qk = tlx.async_dot_wait(0, qk)
    k_empty = tlx.local_view(k_empties, k_buf_id)
    tlx.barrier_arrive(k_empty, 1)
    qk = qk * alpha
    start_n = tl.multiple_of(low, BLOCK_N)
    offs_n_start = offs_n
    offs_n = offs_n_start + start_n
    invalid_mask = offs_m[:, None] == offs_n[None, :]
    max_ids = seq_len
    if HAS_MULTIPLE_TARGETS:
        max_ids = max_ids - n_targets
        offs_m = tl.where(offs_m < max_ids, offs_m, max_ids)
        offs_n = tl.where(offs_n < max_ids, offs_n, max_ids)
    offs_m_minus_n = offs_m[:, None] - offs_n[None, :]
    invalid_mask = invalid_mask | (offs_m_minus_n > 0)
    if HAS_MAX_ATTN_LEN:
        invalid_mask = invalid_mask & (offs_m_minus_n <= max_attn_len)
    if HAS_CONTEXTUAL_SEQ_LEN:
        invalid_mask = invalid_mask | (offs_m[:, None] == 0) & (
            offs_n[None, :] < max_ids
        )
    scale = tl.where(invalid_mask, 1.0 / scaling_seqlen, 0.0)
    silu = fast_dividef(qk, 1.0 + fast_expf(-qk)) * scale
    silu = silu.to(v_dtype)
    loop_trip_cnt += 1
    for start in tl.range(low + BLOCK_N, high, BLOCK_N, num_stages=0):
        start_n = tl.multiple_of(start, BLOCK_N)
        offs_n = offs_n_start + start_n
        k_buf_id = loop_trip_cnt % NUM_BUFFERS
        k_phase = k_phase ^ (k_buf_id == 0)
        k_full = tlx.local_view(k_fulls, k_buf_id)
        tlx.barrier_wait(k_full, k_phase)
        k_tile = tlx.local_view(k_tiles, k_buf_id)
        k_tile = tlx.local_trans(k_tile)
        qk = tlx.async_dot(q_tile, k_tile)
        prev_silu = silu
        v_buf_id = (loop_trip_cnt - 1) % NUM_BUFFERS
        v_phase = (loop_trip_cnt - 1) // NUM_BUFFERS % 2
        v_full = tlx.local_view(v_fulls, v_buf_id)
        tlx.barrier_wait(v_full, v_phase)
        v_tile = tlx.local_view(v_tiles, v_buf_id)
        acc = tlx.async_dot(prev_silu, v_tile, acc)
        qk = tlx.async_dot_wait(1, qk)
        k_empty = tlx.local_view(k_empties, k_buf_id)
        tlx.barrier_arrive(k_empty, 1)
        qk = qk * alpha
        invalid_mask = offs_m[:, None] == offs_n[None, :]
        max_ids = seq_len
        if HAS_MULTIPLE_TARGETS:
            max_ids = max_ids - n_targets
            offs_m = tl.where(offs_m < max_ids, offs_m, max_ids)
            offs_n = tl.where(offs_n < max_ids, offs_n, max_ids)
        offs_m_minus_n = offs_m[:, None] - offs_n[None, :]
        invalid_mask = invalid_mask | (offs_m_minus_n > 0)
        if HAS_MAX_ATTN_LEN:
            invalid_mask = invalid_mask & (offs_m_minus_n <= max_attn_len)
        if HAS_CONTEXTUAL_SEQ_LEN:
            invalid_mask = invalid_mask | (offs_m[:, None] == 0) & (
                offs_n[None, :] < max_ids
            )
        scale = tl.where(invalid_mask, 1.0 / scaling_seqlen, 0.0)
        silu = fast_dividef(qk, 1.0 + fast_expf(-qk)) * scale
        silu = silu.to(v_dtype)
        acc = tlx.async_dot_wait(0, acc)
        v_empty = tlx.local_view(v_empties, v_buf_id)
        tlx.barrier_arrive(v_empty, 1)
        end_n += BLOCK_N
        loop_trip_cnt += 1
    v_buf_id = (loop_trip_cnt - 1) % NUM_BUFFERS
    v_phase = (loop_trip_cnt - 1) // NUM_BUFFERS % 2
    v_full = tlx.local_view(v_fulls, v_buf_id)
    v_tile = tlx.local_view(v_tiles, v_buf_id)
    tlx.barrier_wait(v_full, v_phase)
    acc = tlx.async_dot(silu, v_tile, acc)
    acc = tlx.async_dot_wait(0, acc)
    v_empty = tlx.local_view(v_empties, v_buf_id)
    tlx.barrier_arrive(v_empty, 1)
    return (acc, end_n, loop_trip_cnt)


@triton.jit
def _hstu_attn_fwd_load_K_or_V(
    K,
    k_tiles,
    k_empties,
    k_fulls,
    buf_id,
    k_phase,
    start_n,
    seq_start,
    offset_kh,
    BLOCK_D_Q: tl.constexpr,
    BLOCK_N: tl.constexpr,
):
    k_empty = tlx.local_view(k_empties, buf_id)
    tlx.barrier_wait(k_empty, k_phase)
    k_full = tlx.local_view(k_fulls, buf_id)
    k_tile = tlx.local_view(k_tiles, buf_id)
    tlx.barrier_expect_bytes(k_full, 2 * BLOCK_N * BLOCK_D_Q)
    tlx.async_descriptor_load(
        K, k_tile, [(seq_start + start_n).to(tl.int32), offset_kh.to(tl.int32)], k_full
    )


@triton.jit
def _hstu_attn_fwd_load_Q(
    Q,
    q_tiles,
    q_fulls,
    cid,
    off_z,
    off_h,
    stride_qh,
    start_m,
    seq_start,
    DeltaSize,
    IS_DELTA_Q: tl.constexpr,
    BLOCK_D_Q: tl.constexpr,
    BLOCK_M: tl.constexpr,
):
    q_full = tlx.local_view(q_fulls, cid)
    tlx.barrier_expect_bytes(q_full, 2 * BLOCK_M * BLOCK_D_Q)
    q_tile = tlx.local_view(q_tiles, cid)
    seq_offset = start_m + cid * BLOCK_M
    if IS_DELTA_Q:
        tlx.async_descriptor_load(
            Q,
            q_tile,
            [
                (off_z * DeltaSize + start_m).to(tl.int32),
                (off_h * stride_qh).to(tl.int32),
            ],
            q_full,
        )
    else:
        tlx.async_descriptor_load(
            Q,
            q_tile,
            [(seq_start + seq_offset).to(tl.int32), (off_h * stride_qh).to(tl.int32)],
            q_full,
        )


@triton.jit
def _hstu_attn_fwd_caculate_range(
    seq_len,
    start_m,
    n_targets,
    contextual_seq_len,
    max_attn_len,
    HAS_MULTIPLE_TARGETS: tl.constexpr,
    HAS_CONTEXTUAL_SEQ_LEN: tl.constexpr,
    HAS_MAX_ATTN_LEN: tl.constexpr,
    BLOCK_M: tl.constexpr,
    BLOCK_N: tl.constexpr,
):
    if HAS_MULTIPLE_TARGETS:
        uih_end = seq_len - n_targets
    else:
        uih_end = seq_len
    if HAS_CONTEXTUAL_SEQ_LEN is True and start_m < contextual_seq_len:
        low = 0
        high = seq_len
    else:
        low = 0
        high = start_m + BLOCK_M
        if HAS_MAX_ATTN_LEN:
            if start_m > uih_end:
                low = uih_end - max_attn_len
            else:
                low = start_m - max_attn_len
            if HAS_CONTEXTUAL_SEQ_LEN:
                low = low if low > contextual_seq_len else 0
            else:
                low = low if low > 0 else 0
        if HAS_MULTIPLE_TARGETS:
            uih_end = (uih_end + BLOCK_N - 1) // BLOCK_N * BLOCK_N
            if uih_end < start_m:
                high = seq_len - n_targets
    return (low, high, uih_end)


@triton.jit
def _hstu_attn_fwd_load_Q_K_V(
    Q,
    K,
    V,
    q_tiles,
    k_tiles,
    v_tiles,
    q_fulls,
    k_fulls,
    v_fulls,
    k_empties,
    v_empties,
    stride_qh,
    stride_kh,
    stride_vh,
    contextual_seq_len,
    max_attn_len,
    DeltaSize,
    off_z,
    off_h,
    start_m,
    seq_start,
    seq_len,
    n_targets,
    HAS_MULTIPLE_TARGETS: tl.constexpr,
    IS_DELTA_Q: tl.constexpr,
    BLOCK_D_Q: tl.constexpr,
    BLOCK_D_V: tl.constexpr,
    BLOCK_M: tl.constexpr,
    BLOCK_N: tl.constexpr,
    NUM_BUFFERS: tl.constexpr,
    NUM_MMA_GROUPS: tl.constexpr,
    HAS_CONTEXTUAL_SEQ_LEN: tl.constexpr,
    HAS_MAX_ATTN_LEN: tl.constexpr,
):
    BLOCK_M_SPLIT: tl.constexpr = BLOCK_M // NUM_MMA_GROUPS
    _hstu_attn_fwd_load_Q(
        Q=Q,
        q_tiles=q_tiles,
        q_fulls=q_fulls,
        cid=0,
        off_z=off_z,
        off_h=off_h,
        stride_qh=stride_qh,
        start_m=start_m,
        seq_start=seq_start,
        DeltaSize=DeltaSize,
        IS_DELTA_Q=IS_DELTA_Q,
        BLOCK_D_Q=BLOCK_D_Q,
        BLOCK_M=BLOCK_M_SPLIT,
    )
    off_h = off_h.to(tl.int64)
    off_z = off_z.to(tl.int64)
    offset_kh = off_h * stride_kh
    offset_vh = off_h * stride_vh
    low, high, uih_end = _hstu_attn_fwd_caculate_range(
        seq_len,
        start_m,
        n_targets,
        contextual_seq_len,
        max_attn_len,
        HAS_MULTIPLE_TARGETS,
        HAS_CONTEXTUAL_SEQ_LEN,
        HAS_MAX_ATTN_LEN,
        BLOCK_M,
        BLOCK_N,
    )
    kv_phase = 0
    loop_trip_cnt = 0
    buf_id = loop_trip_cnt % NUM_BUFFERS
    kv_phase = kv_phase ^ (buf_id == 0)
    start_n = tl.multiple_of(low, BLOCK_N)
    _hstu_attn_fwd_load_K_or_V(
        K,
        k_tiles,
        k_empties,
        k_fulls,
        buf_id,
        kv_phase,
        start_n,
        seq_start,
        offset_kh,
        BLOCK_D_Q,
        BLOCK_N,
    )
    for cid in tl.range(1, NUM_MMA_GROUPS, loop_unroll_factor=NUM_MMA_GROUPS - 1):
        _hstu_attn_fwd_load_Q(
            Q,
            q_tiles,
            q_fulls,
            cid,
            off_z,
            off_h,
            stride_qh,
            start_m,
            seq_start,
            DeltaSize,
            IS_DELTA_Q,
            BLOCK_D_Q,
            BLOCK_M_SPLIT,
        )
    _hstu_attn_fwd_load_K_or_V(
        V,
        v_tiles,
        v_empties,
        v_fulls,
        buf_id,
        kv_phase,
        start_n,
        seq_start,
        offset_vh,
        BLOCK_D_V,
        BLOCK_N,
    )
    loop_trip_cnt += 1
    for start in range(low + BLOCK_N, high, BLOCK_N):
        buf_id = loop_trip_cnt % NUM_BUFFERS
        kv_phase = kv_phase ^ (buf_id == 0)
        start_n = tl.multiple_of(start, BLOCK_N)
        _hstu_attn_fwd_load_K_or_V(
            K,
            k_tiles,
            k_empties,
            k_fulls,
            buf_id,
            kv_phase,
            start_n,
            seq_start,
            offset_kh,
            BLOCK_D_Q,
            BLOCK_N,
        )
        _hstu_attn_fwd_load_K_or_V(
            V,
            v_tiles,
            v_empties,
            v_fulls,
            buf_id,
            kv_phase,
            start_n,
            seq_start,
            offset_vh,
            BLOCK_D_V,
            BLOCK_N,
        )
        loop_trip_cnt += 1
    if uih_end < start_m:
        low_delta = start_m
        high_delta = start_m + BLOCK_M
        for start_delta in tl.range(low_delta, high_delta, BLOCK_N, num_stages=0):
            buf_id = loop_trip_cnt % NUM_BUFFERS
            kv_phase = kv_phase ^ (buf_id == 0)
            start_n = tl.multiple_of(start_delta, BLOCK_N)
            _hstu_attn_fwd_load_K_or_V(
                K,
                k_tiles,
                k_empties,
                k_fulls,
                buf_id,
                kv_phase,
                start_n,
                seq_start,
                offset_kh,
                BLOCK_D_Q,
                BLOCK_N,
            )
            _hstu_attn_fwd_load_K_or_V(
                V,
                v_tiles,
                v_empties,
                v_fulls,
                buf_id,
                kv_phase,
                start_n,
                seq_start,
                offset_vh,
                BLOCK_D_V,
                BLOCK_N,
            )
            loop_trip_cnt += 1


@triton.jit
def _hstu_attn_fwd_compute_tlx(
    Q,
    K,
    V,
    H,
    DimQ,
    DimV,
    seq_offsets,
    num_targets,
    Out,
    stride_qh,
    stride_kh,
    stride_vh,
    stride_om,
    stride_oh,
    alpha,
    MAX_SEQ_LEN,
    scaling_seqlen,
    DeltaSize,
    contextual_seq_len,
    max_attn_len,
    off_z,
    off_h,
    pid,
    HAS_MULTIPLE_TARGETS: tl.constexpr,
    IS_DELTA_Q: tl.constexpr,
    ALLOW_TF32: tl.constexpr,
    BLOCK_D_Q: tl.constexpr,
    BLOCK_D_V: tl.constexpr,
    BLOCK_M: tl.constexpr,
    BLOCK_N: tl.constexpr,
    NUM_BUFFERS: tl.constexpr,
    NUM_MMA_WARPS_PER_GROUP: tl.constexpr,
    NUM_MMA_GROUPS: tl.constexpr,
    HAS_CONTEXTUAL_SEQ_LEN: tl.constexpr,
    HAS_MAX_ATTN_LEN: tl.constexpr,
):
    seq_start = tl.load(seq_offsets + off_z).to(tl.int64)
    seq_end = tl.load(seq_offsets + off_z + 1)
    seq_len = (seq_end - seq_start).to(tl.int32)
    if IS_DELTA_Q:
        start_m = pid * BLOCK_M
        start_m = (start_m + seq_len - DeltaSize).to(tl.int32)
    else:
        start_m = pid * BLOCK_M
    if start_m >= seq_len:
        return
    if HAS_MULTIPLE_TARGETS:
        n_targets = tl.load(num_targets + off_z).to(tl.int32)
    else:
        n_targets = None
    BLOCK_M_SPLIT: tl.constexpr = BLOCK_M // NUM_MMA_GROUPS
    q_tiles = tlx.local_alloc(
        (BLOCK_M_SPLIT, BLOCK_D_Q), tlx.dtype_of(Q), NUM_MMA_GROUPS
    )
    k_tiles = tlx.local_alloc((BLOCK_N, BLOCK_D_Q), tlx.dtype_of(K), NUM_BUFFERS)
    v_tiles = tlx.local_alloc((BLOCK_N, BLOCK_D_V), tlx.dtype_of(V), NUM_BUFFERS)
    q_fulls = tlx.alloc_barriers(num_barriers=NUM_MMA_GROUPS, arrive_count=1)
    k_empties = tlx.alloc_barriers(
        num_barriers=NUM_BUFFERS, arrive_count=NUM_MMA_GROUPS
    )
    k_fulls = tlx.alloc_barriers(num_barriers=NUM_BUFFERS, arrive_count=1)
    v_empties = tlx.alloc_barriers(
        num_barriers=NUM_BUFFERS, arrive_count=NUM_MMA_GROUPS
    )
    v_fulls = tlx.alloc_barriers(num_barriers=NUM_BUFFERS, arrive_count=1)
    with tlx.async_tasks():
        with tlx.async_task("default"):
            _hstu_attn_fwd_load_Q_K_V(
                Q=Q,
                K=K,
                V=V,
                q_tiles=q_tiles,
                k_tiles=k_tiles,
                v_tiles=v_tiles,
                q_fulls=q_fulls,
                k_fulls=k_fulls,
                v_fulls=v_fulls,
                k_empties=k_empties,
                v_empties=v_empties,
                stride_qh=stride_qh,
                stride_kh=stride_kh,
                stride_vh=stride_vh,
                contextual_seq_len=contextual_seq_len,
                max_attn_len=max_attn_len,
                DeltaSize=DeltaSize,
                off_z=off_z,
                off_h=off_h,
                start_m=start_m,
                seq_start=seq_start,
                seq_len=seq_len,
                n_targets=n_targets,
                HAS_MULTIPLE_TARGETS=HAS_MULTIPLE_TARGETS,
                IS_DELTA_Q=IS_DELTA_Q,
                BLOCK_D_Q=BLOCK_D_Q,
                BLOCK_D_V=BLOCK_D_V,
                BLOCK_M=BLOCK_M,
                BLOCK_N=BLOCK_N,
                NUM_BUFFERS=NUM_BUFFERS,
                NUM_MMA_GROUPS=NUM_MMA_GROUPS,
                HAS_CONTEXTUAL_SEQ_LEN=HAS_CONTEXTUAL_SEQ_LEN,
                HAS_MAX_ATTN_LEN=HAS_MAX_ATTN_LEN,
            )
        with tlx.async_task(
            num_warps=NUM_MMA_WARPS_PER_GROUP, registers=232, replicate=NUM_MMA_GROUPS
        ):
            cid = tlx.async_task_replica_id()
            acc = tl.zeros([BLOCK_M_SPLIT, BLOCK_D_V], dtype=tl.float32)
            offs_m = start_m + tl.arange(0, BLOCK_M_SPLIT) + cid * BLOCK_M_SPLIT
            offs_n = tl.arange(0, BLOCK_N)
            low, high, uih_end = _hstu_attn_fwd_caculate_range(
                seq_len,
                start_m,
                n_targets,
                contextual_seq_len,
                max_attn_len,
                HAS_MULTIPLE_TARGETS,
                HAS_CONTEXTUAL_SEQ_LEN,
                HAS_MAX_ATTN_LEN,
                BLOCK_M,
                BLOCK_N,
            )
            end_n = low
            loop_trip_cnt = 0
            acc, end_n, loop_trip_cnt = _hstu_attn_fwd_compute_main_loop_tlx_pipelined(
                low=low,
                high=high,
                seq_len=seq_len,
                offs_m=offs_m,
                offs_n=offs_n,
                acc=acc,
                q_tiles=q_tiles,
                k_tiles=k_tiles,
                v_tiles=v_tiles,
                q_fulls=q_fulls,
                k_fulls=k_fulls,
                v_fulls=v_fulls,
                k_empties=k_empties,
                v_empties=v_empties,
                v_dtype=tlx.dtype_of(V),
                n_targets=n_targets,
                alpha=alpha,
                end_n=end_n,
                loop_trip_cnt=loop_trip_cnt,
                max_attn_len=max_attn_len,
                scaling_seqlen=scaling_seqlen,
                HAS_MULTIPLE_TARGETS=HAS_MULTIPLE_TARGETS,
                HAS_CONTEXTUAL_SEQ_LEN=HAS_CONTEXTUAL_SEQ_LEN,
                HAS_MAX_ATTN_LEN=HAS_MAX_ATTN_LEN,
                cid=cid,
                BLOCK_N=BLOCK_N,
                NUM_BUFFERS=NUM_BUFFERS,
                MAX_SEQ_LEN=MAX_SEQ_LEN,
                WAIT_FOR_Q=1,
            )
            if uih_end < start_m:
                low_delta = start_m
                high_delta = start_m + BLOCK_M
                acc, end_n, loop_trip_cnt = _hstu_attn_fwd_compute_main_loop_tlx(
                    low=low_delta,
                    high=high_delta,
                    seq_len=seq_len,
                    offs_m=offs_m,
                    offs_n=offs_n,
                    acc=acc,
                    q_tiles=q_tiles,
                    k_tiles=k_tiles,
                    v_tiles=v_tiles,
                    q_fulls=q_fulls,
                    k_fulls=k_fulls,
                    v_fulls=v_fulls,
                    k_empties=k_empties,
                    v_empties=v_empties,
                    v_dtype=tlx.dtype_of(V),
                    n_targets=n_targets,
                    alpha=alpha,
                    end_n=end_n,
                    loop_trip_cnt=loop_trip_cnt,
                    max_attn_len=max_attn_len,
                    scaling_seqlen=scaling_seqlen,
                    HAS_MULTIPLE_TARGETS=HAS_MULTIPLE_TARGETS,
                    HAS_CONTEXTUAL_SEQ_LEN=HAS_CONTEXTUAL_SEQ_LEN,
                    HAS_MAX_ATTN_LEN=HAS_MAX_ATTN_LEN,
                    cid=cid,
                    BLOCK_N=BLOCK_N,
                    NUM_BUFFERS=NUM_BUFFERS,
                    MAX_SEQ_LEN=MAX_SEQ_LEN,
                    WAIT_FOR_Q=0,
                )
            if IS_DELTA_Q:
                start_m_delta = pid * BLOCK_M + cid * BLOCK_M_SPLIT
                offs_m_delta = start_m_delta + tl.arange(0, BLOCK_M_SPLIT)
                offs_v_d = tl.arange(0, BLOCK_D_V)
                off_o = Out + off_z * DeltaSize * stride_om + off_h * stride_oh
                out_ptrs = off_o + offs_m_delta[:, None] * stride_om + offs_v_d[None, :]
                tl.store(out_ptrs, acc, mask=(offs_m_delta < DeltaSize)[:, None])
            else:
                start_m = pid * BLOCK_M + cid * BLOCK_M_SPLIT
                offs_m = start_m + tl.arange(0, BLOCK_M_SPLIT)
                offs_v_d = tl.arange(0, BLOCK_D_V)
                off_o = Out + seq_start * stride_om + off_h * stride_oh
                out_ptrs = off_o + offs_m[:, None] * stride_om + offs_v_d[None, :]
                tl.store(out_ptrs, acc, mask=(offs_m < seq_len)[:, None])


@triton.jit
def _hstu_attn_fwd(
    Q,
    K,
    V,
    workspace_ptr,
    sort_by_length_indices,
    seq_offsets,
    num_targets,
    Out,
    stride_qm,
    stride_qh,
    stride_kn,
    stride_kh,
    stride_vn,
    stride_vh,
    stride_om,
    stride_oh,
    alpha,
    Z,
    AUTOTUNE_Z,
    H,
    MAX_SEQ_LEN,
    AUTOTUNE_MAX_SEQ_LEN,
    DimQ,
    DimV,
    DeltaSize,
    scaling_seqlen,
    contextual_seq_len,
    max_attn_len,
    HAS_MULTIPLE_TARGETS: tl.constexpr,
    IS_DELTA_Q: tl.constexpr,
    ALLOW_TF32: tl.constexpr,
    BLOCK_D_Q: tl.constexpr,
    BLOCK_D_V: tl.constexpr,
    BLOCK_M: tl.constexpr,
    BLOCK_N: tl.constexpr,
    USE_TLX: tl.constexpr,
    NUM_BUFFERS: tl.constexpr,
    NUM_MMA_WARPS_PER_GROUP: tl.constexpr,
    NUM_MMA_GROUPS: tl.constexpr,
    HAS_CONTEXTUAL_SEQ_LEN: tl.constexpr,
    HAS_MAX_ATTN_LEN: tl.constexpr,
    HAS_SORT_BY_LENGTH_INDICES: tl.constexpr,
    ENABLE_TMA: tl.constexpr,
    TMA_DESC_SIZE: tl.constexpr,
):
    off_hz = tl.program_id(1)
    off_z = off_hz // H
    if HAS_SORT_BY_LENGTH_INDICES:
        off_z = tl.load(sort_by_length_indices + off_z)
    off_h = off_hz % H
    pid = tl.program_id(0)
    if USE_TLX:
        _hstu_attn_fwd_compute_tlx(
            Q=Q,
            K=K,
            V=V,
            H=H,
            DimQ=DimQ,
            DimV=DimV,
            seq_offsets=seq_offsets,
            num_targets=num_targets,
            Out=Out,
            stride_qh=stride_qh,
            stride_kh=stride_kh,
            stride_vh=stride_vh,
            stride_om=stride_om,
            stride_oh=stride_oh,
            alpha=alpha,
            MAX_SEQ_LEN=MAX_SEQ_LEN,
            scaling_seqlen=scaling_seqlen,
            DeltaSize=DeltaSize,
            contextual_seq_len=contextual_seq_len,
            max_attn_len=max_attn_len,
            off_z=off_z,
            off_h=off_h,
            pid=pid,
            HAS_MULTIPLE_TARGETS=HAS_MULTIPLE_TARGETS,
            IS_DELTA_Q=IS_DELTA_Q,
            ALLOW_TF32=ALLOW_TF32,
            BLOCK_D_Q=BLOCK_D_Q,
            BLOCK_D_V=BLOCK_D_V,
            HAS_CONTEXTUAL_SEQ_LEN=HAS_CONTEXTUAL_SEQ_LEN,
            HAS_MAX_ATTN_LEN=HAS_MAX_ATTN_LEN,
            BLOCK_M=BLOCK_M,
            BLOCK_N=BLOCK_N,
            NUM_BUFFERS=NUM_BUFFERS,
            NUM_MMA_WARPS_PER_GROUP=NUM_MMA_WARPS_PER_GROUP,
            NUM_MMA_GROUPS=NUM_MMA_GROUPS,
        )
    else:
        _hstu_attn_fwd_compute(
            Q=Q,
            K=K,
            V=V,
            H=H,
            DimQ=DimQ,
            DimV=DimV,
            workspace_ptr=workspace_ptr,
            seq_offsets=seq_offsets,
            num_targets=num_targets,
            Out=Out,
            stride_qm=stride_qm,
            stride_qh=stride_qh,
            stride_kn=stride_kn,
            stride_kh=stride_kh,
            stride_vn=stride_vn,
            stride_vh=stride_vh,
            stride_om=stride_om,
            stride_oh=stride_oh,
            alpha=alpha,
            MAX_SEQ_LEN=MAX_SEQ_LEN,
            scaling_seqlen=scaling_seqlen,
            DeltaSize=DeltaSize,
            contextual_seq_len=contextual_seq_len,
            max_attn_len=max_attn_len,
            off_z=off_z,
            off_h=off_h,
            pid=pid,
            HAS_MULTIPLE_TARGETS=HAS_MULTIPLE_TARGETS,
            IS_DELTA_Q=IS_DELTA_Q,
            ALLOW_TF32=ALLOW_TF32,
            BLOCK_D_Q=BLOCK_D_Q,
            BLOCK_D_V=BLOCK_D_V,
            HAS_CONTEXTUAL_SEQ_LEN=HAS_CONTEXTUAL_SEQ_LEN,
            HAS_MAX_ATTN_LEN=HAS_MAX_ATTN_LEN,
            BLOCK_M=BLOCK_M,
            BLOCK_N=BLOCK_N,
            ENABLE_TMA=ENABLE_TMA,
            TMA_DESC_SIZE=TMA_DESC_SIZE,
        )


def test_hstu_attn_fwd():
    generator = torch.Generator().manual_seed(20261011)
    h, d, total = (2, 16, 8)
    q = (torch.randn((total, h, d), generator=generator) * 0.2).to(torch.float16)
    k = (torch.randn((total, h, d), generator=generator) * 0.2).to(torch.float16)
    v = (torch.randn((total, h, d), generator=generator) * 0.2).to(torch.float16)
    dy = (torch.randn((total, h, d), generator=generator) * 0.2).to(torch.float16)
    offset = torch.tensor([0, 3, 8], dtype=torch.int32)
    alpha = 0.25
    qq = q.double()
    kk = k.double()
    vv = v.double()
    ys = []
    for st, en in [(0, 3), (3, 8)]:
        score = qq[st:en].transpose(0, 1) @ kk[st:en].permute(1, 2, 0) * alpha
        mask = torch.ones(en - st, en - st).tril()
        ys.append(
            (
                torch.nn.functional.silu(score) * mask / 5 @ vv[st:en].transpose(0, 1)
            ).transpose(0, 1)
        )
    ref = torch.cat(ys)
    out = torch.full_like(q, 23.0).npu()
    workspace = torch.zeros(256, dtype=torch.uint8).npu()
    targets = torch.tensor([0, 0], dtype=torch.int32).npu()
    indices = torch.tensor([0, 1], dtype=torch.int32).npu()
    offs = offset.npu()
    opts = dict(
        HAS_MULTIPLE_TARGETS=False,
        HAS_CONTEXTUAL_SEQ_LEN=False,
        HAS_MAX_ATTN_LEN=False,
        ALLOW_TF32=False,
        BLOCK_D_Q=d,
        BLOCK_D_V=d,
        BLOCK_M=16,
        BLOCK_N=16,
        HAS_SORT_BY_LENGTH_INDICES=False,
        ENABLE_TMA=False,
        TMA_DESC_SIZE=128,
    )
    _hstu_attn_fwd[1, 4](
        q.npu(),
        k.npu(),
        v.npu(),
        workspace,
        indices,
        offs,
        targets,
        out,
        32,
        16,
        32,
        16,
        32,
        16,
        32,
        16,
        alpha,
        2,
        2,
        h,
        5,
        8,
        d,
        d,
        0,
        5,
        0,
        0,
        IS_DELTA_Q=False,
        USE_TLX=False,
        NUM_BUFFERS=2,
        NUM_MMA_WARPS_PER_GROUP=4,
        NUM_MMA_GROUPS=1,
        **opts
    )
    actual_attention = out.cpu()
    expected_attention = ref.detach()
    torch.testing.assert_close(
        (actual_attention).double(),
        (expected_attention).double(),
        atol=0.0002,
        rtol=0.002,
        check_dtype=False,
    )
    assert (
        torch.isfinite(actual_attention).all()
        and torch.isfinite(expected_attention).all()
    )
    print("PASS: hstu_attn_fwd")


if __name__ == "__main__":
    test_hstu_attn_fwd()

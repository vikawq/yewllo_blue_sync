# Copyright (c) 2025 Huawei Technologies Co., Ltd. All Rights Reserved.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
# This file is a part of the vllm-ascend project.
#
# Adapted from https://github.com/vllm-project/vllm/blob/main/vllm/v1/spec_decode/utils.py

import torch
import torch_npu
import triton
import triton.language as tl


@triton.jit(do_not_specialize=["num_reqs"])
def prepare_inputs_padded_kernel(
    cu_num_draft_tokens_ptr,
    valid_sampled_tokens_count_ptr,
    query_start_loc_gpu_ptr,
    token_indices_to_sample_ptr,
    num_rejected_tokens_gpu_ptr,
    num_reqs,
    BLOCK_SIZE: tl.constexpr,
):
    pid = tl.program_id(axis=0)
    num_programs = tl.num_programs(axis=0)
    block_start_step = num_programs * BLOCK_SIZE
    for block_start in tl.range(pid * BLOCK_SIZE, num_reqs, block_start_step):
        offsets = block_start + tl.arange(0, BLOCK_SIZE)
        mask = offsets < num_reqs
        cu_draft_curr = tl.load(cu_num_draft_tokens_ptr + offsets, mask=mask)
        prev_indices = offsets - 1
        has_prev = offsets > 0
        cu_draft_prev = tl.load(
            cu_num_draft_tokens_ptr + prev_indices, mask=mask & has_prev, other=0
        )
        num_draft_tokens = tl.where(
            has_prev, cu_draft_curr - cu_draft_prev, cu_draft_curr
        )
        valid_count = tl.load(valid_sampled_tokens_count_ptr + offsets, mask=mask)
        num_rejected = num_draft_tokens + 1 - valid_count
        num_rejected = tl.where(num_draft_tokens > 0, num_rejected, 0)
        q_last_tok_idx = tl.load(query_start_loc_gpu_ptr + offsets + 1, mask=mask) - 1
        index_to_sample = q_last_tok_idx - num_rejected
        tl.store(token_indices_to_sample_ptr + offsets, index_to_sample, mask=mask)
        tl.store(num_rejected_tokens_gpu_ptr + offsets, num_rejected, mask=mask)


def test_prepare_inputs_padded_kernel():
    drafts = torch.tensor([4], dtype=torch.int32)
    valid = torch.tensor([2], dtype=torch.int32)
    query = torch.tensor([0, 5], dtype=torch.int32)
    initial = torch.full((5,), -99, dtype=torch.int32)
    out, rej = (initial.npu(), initial.npu())
    prepare_inputs_padded_kernel[1,](
        drafts.npu(), valid.npu(), query.npu(), out, rej, 1, BLOCK_SIZE=4
    )
    actual, actual_rej = (out.cpu(), rej.cpu())
    actual_index_to_sample = actual[:1].cpu()
    expected_index_to_sample = torch.tensor([1], dtype=torch.int32)
    expected_index_to_sample = expected_index_to_sample.to(actual_index_to_sample.dtype)
    torch.testing.assert_close(
        actual_index_to_sample,
        expected_index_to_sample,
        atol=0,
        rtol=0,
        check_dtype=False,
    )
    assert (
        torch.isfinite(actual_index_to_sample).all()
        and torch.isfinite(expected_index_to_sample).all()
    )
    actual_rejected = actual_rej[:1].cpu()
    expected_rejected = torch.tensor([3], dtype=torch.int32)
    expected_rejected = expected_rejected.to(actual_rejected.dtype)
    torch.testing.assert_close(
        actual_rejected, expected_rejected, atol=0, rtol=0, check_dtype=False
    )
    assert (
        torch.isfinite(actual_rejected).all()
        and torch.isfinite(expected_rejected).all()
    )
    actual_index_tail_guard = actual[1:].cpu()
    expected_index_tail_guard = initial[1:]
    expected_index_tail_guard = expected_index_tail_guard.to(
        actual_index_tail_guard.dtype
    )
    torch.testing.assert_close(
        actual_index_tail_guard,
        expected_index_tail_guard,
        atol=0,
        rtol=0,
        check_dtype=False,
    )
    assert (
        torch.isfinite(actual_index_tail_guard).all()
        and torch.isfinite(expected_index_tail_guard).all()
    )
    actual_rejected_tail_guard = actual_rej[1:].cpu()
    expected_rejected_tail_guard = initial[1:]
    expected_rejected_tail_guard = expected_rejected_tail_guard.to(
        actual_rejected_tail_guard.dtype
    )
    torch.testing.assert_close(
        actual_rejected_tail_guard,
        expected_rejected_tail_guard,
        atol=0,
        rtol=0,
        check_dtype=False,
    )
    assert (
        torch.isfinite(actual_rejected_tail_guard).all()
        and torch.isfinite(expected_rejected_tail_guard).all()
    )
    print("PASS: prepare_inputs_padded_kernel")


if __name__ == "__main__":
    test_prepare_inputs_padded_kernel()

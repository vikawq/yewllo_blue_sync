# SPDX-License-Identifier: Apache-2.0
# SPDX-FileCopyrightText: Copyright contributors to the vLLM project
# SPDX-FileCopyrightText: Songlin Yang, Yu Zhang
#
# This file contains code copied from the flash-linear-attention project.
# The original source code was licensed under the MIT license and included
# the following copyright notice:
# Copyright (c) 2023-2025, Songlin Yang, Yu Zhang
# ruff: noqa: E501

import torch
import torch_npu
import triton
import triton.language as tl


@triton.jit(do_not_specialize=["inner_size", "row_stride"])
def _clear_ssm_states_kernel(
    states_ptr, has_initial_state_ptr, inner_size, row_stride, BLOCK_SIZE: tl.constexpr
):
    row_idx = tl.program_id(axis=0)
    col_block_idx = tl.program_id(axis=1)
    has_state = tl.load(has_initial_state_ptr + row_idx).to(tl.int1)
    if has_state:
        return
    cols = col_block_idx * BLOCK_SIZE + tl.arange(0, BLOCK_SIZE)
    mask = cols < inner_size
    row_ptr = states_ptr + row_idx * row_stride + cols
    tl.store(
        row_ptr, tl.zeros((BLOCK_SIZE,), dtype=states_ptr.dtype.element_ty), mask=mask
    )


def test_clear_ssm_states_kernel():
    rows, inner, block = (2, 524288, 4096)
    x = torch.arange(rows * inner, dtype=torch.float32).reshape(rows, inner) % 97 - 48
    state = torch.tensor([False, True])
    xn = x.npu()
    _clear_ssm_states_kernel[rows, 128](xn, state.npu(), inner, inner, BLOCK_SIZE=block)
    expected = x.clone()
    expected[0].zero_()
    actual_states = xn.cpu()
    expected_states = expected
    expected_states = expected_states.to(actual_states.dtype)
    torch.testing.assert_close(
        (actual_states).float(),
        (expected_states).float(),
        atol=0,
        rtol=0,
        check_dtype=False,
    )
    assert torch.isfinite(actual_states).all() and torch.isfinite(expected_states).all()
    print("PASS: _clear_ssm_states_kernel")


if __name__ == "__main__":
    test_clear_ssm_states_kernel()

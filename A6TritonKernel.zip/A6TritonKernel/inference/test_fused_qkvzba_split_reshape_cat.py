# SPDX-License-Identifier: Apache-2.0
# SPDX-FileCopyrightText: Copyright contributors to the vLLM project
# SPDX-FileCopyrightText: Songlin Yang, Yu Zhang
#
# This file contains code copied from the flash-linear-attention project.
# The original source code was licensed under the MIT license and included
# the following copyright notice:
# Copyright (c) 2023-2025, Songlin Yang, Yu Zhang

# ruff: noqa: E501
# mypy: ignore-errors

import torch
import torch_npu
import triton
import triton.language as tl


@triton.jit(do_not_specialize=["total_rows", "rows_per_vec"])
def fused_qkvzba_split_reshape_cat_kernel(
    mixed_qkv,
    z,
    b,
    a,
    mixed_qkvz,
    mixed_ba,
    NUM_HEADS_QK: tl.constexpr,
    NUM_HEADS_V: tl.constexpr,
    HEAD_QK: tl.constexpr,
    HEAD_V: tl.constexpr,
    total_rows,
    rows_per_vec,
    QKVZ_ROW_STRIDE: tl.constexpr,
    BA_ROW_STRIDE: tl.constexpr,
    QKV_ROW_STRIDE: tl.constexpr,
    Z_ROW_STRIDE: tl.constexpr,
    BA_OUT_ROW_STRIDE: tl.constexpr,
    ROWS_PER_ITER: tl.constexpr,
):
    """
    Fused kernel to split and reshape mixed QKVZ and BA tensors.

    This kernel performs the following transformations:
    - Input mixed_qkvz: [num_tokens, num_heads_qk * (Q + K + V + Z)] where each
      head block contains [Q(HEAD_QK), K(HEAD_QK), V(V_DIM_PER_QK), Z(V_DIM_PER_QK)]
    - Input mixed_ba: [num_tokens, num_heads_qk * (B + A)] where each head block
      contains [B(V_HEADS_PER_QK), A(V_HEADS_PER_QK)]
    - Output mixed_qkv: [num_tokens, Q_all | K_all | V_all] concatenated by type
    - Output z: [num_tokens, num_heads_v, head_v]
    - Output b, a: [num_tokens, num_heads_v]
    """
    vec_id = tl.program_id(0)
    V_HEADS_PER_QK: tl.constexpr = NUM_HEADS_V // NUM_HEADS_QK
    V_DIM_PER_QK: tl.constexpr = V_HEADS_PER_QK * HEAD_V
    QKVZ_DIM_T: tl.constexpr = HEAD_QK * 2 + V_DIM_PER_QK * 2
    BA_DIM_T: tl.constexpr = V_HEADS_PER_QK * 2
    Q_TOTAL: tl.constexpr = NUM_HEADS_QK * HEAD_QK
    K_TOTAL: tl.constexpr = NUM_HEADS_QK * HEAD_QK
    row_start = vec_id * rows_per_vec
    row_end = min(row_start + rows_per_vec, total_rows)
    row_offset = row_start
    iter_count = (row_end - row_start + ROWS_PER_ITER - 1) // ROWS_PER_ITER
    for _ in tl.range(iter_count):
        row_indices = tl.arange(0, ROWS_PER_ITER) + row_offset
        row_mask = row_indices < row_end
        for head_id in tl.static_range(NUM_HEADS_QK):
            src_head_offset = head_id * QKVZ_DIM_T
            q_range = tl.arange(0, HEAD_QK)
            q_src = (
                row_indices[:, None] * QKVZ_ROW_STRIDE
                + src_head_offset
                + q_range[None, :]
            )
            q_dst = (
                row_indices[:, None] * QKV_ROW_STRIDE
                + head_id * HEAD_QK
                + q_range[None, :]
            )
            q_data = tl.load(mixed_qkvz + q_src, mask=row_mask[:, None])
            tl.store(mixed_qkv + q_dst, q_data, mask=row_mask[:, None])
            k_src = (
                row_indices[:, None] * QKVZ_ROW_STRIDE
                + src_head_offset
                + HEAD_QK
                + q_range[None, :]
            )
            k_dst = (
                row_indices[:, None] * QKV_ROW_STRIDE
                + Q_TOTAL
                + head_id * HEAD_QK
                + q_range[None, :]
            )
            k_data = tl.load(mixed_qkvz + k_src, mask=row_mask[:, None])
            tl.store(mixed_qkv + k_dst, k_data, mask=row_mask[:, None])
            v_range = tl.arange(0, V_DIM_PER_QK)
            v_src = (
                row_indices[:, None] * QKVZ_ROW_STRIDE
                + src_head_offset
                + HEAD_QK * 2
                + v_range[None, :]
            )
            v_dst = (
                row_indices[:, None] * QKV_ROW_STRIDE
                + Q_TOTAL
                + K_TOTAL
                + head_id * V_DIM_PER_QK
                + v_range[None, :]
            )
            v_data = tl.load(mixed_qkvz + v_src, mask=row_mask[:, None])
            tl.store(mixed_qkv + v_dst, v_data, mask=row_mask[:, None])
            z_src = (
                row_indices[:, None] * QKVZ_ROW_STRIDE
                + src_head_offset
                + HEAD_QK * 2
                + V_DIM_PER_QK
                + v_range[None, :]
            )
            z_dst = (
                row_indices[:, None] * Z_ROW_STRIDE
                + head_id * V_DIM_PER_QK
                + v_range[None, :]
            )
            z_data = tl.load(mixed_qkvz + z_src, mask=row_mask[:, None])
            tl.store(z + z_dst, z_data, mask=row_mask[:, None])
            b_range = tl.arange(0, V_HEADS_PER_QK)
            ba_head_offset = head_id * BA_DIM_T
            b_src = (
                row_indices[:, None] * BA_ROW_STRIDE + ba_head_offset + b_range[None, :]
            )
            b_dst = (
                row_indices[:, None] * BA_OUT_ROW_STRIDE
                + head_id * V_HEADS_PER_QK
                + b_range[None, :]
            )
            b_data = tl.load(mixed_ba + b_src, mask=row_mask[:, None])
            tl.store(b + b_dst, b_data, mask=row_mask[:, None])
            a_src = (
                row_indices[:, None] * BA_ROW_STRIDE
                + ba_head_offset
                + V_HEADS_PER_QK
                + b_range[None, :]
            )
            a_data = tl.load(mixed_ba + a_src, mask=row_mask[:, None])
            tl.store(a + b_dst, a_data, mask=row_mask[:, None])
        row_offset += ROWS_PER_ITER


def test_fused_qkvzba_split_reshape_cat():
    generator = torch.Generator().manual_seed(20261009)
    rows, h, hv, k, v = (3, 8, 16, 128, 128)
    x, ba = (
        torch.randn((rows, 6144), generator=generator).to(torch.float16),
        torch.randn((rows, 32), generator=generator).to(torch.float16),
    )
    x_npu, ba_npu = (x.npu(), ba.npu())
    mixed_qkv_out = torch.empty(
        (rows, 2 * h * k + hv * v), dtype=x.dtype, device=x_npu.device
    )
    z_out = torch.empty((rows, hv, v), dtype=x.dtype, device=x_npu.device)
    b_out = torch.empty((rows, hv), dtype=ba.dtype, device=ba_npu.device)
    a_out = torch.empty_like(b_out)
    fused_qkvzba_split_reshape_cat_kernel[3, 1](
        mixed_qkv_out,
        z_out,
        b_out,
        a_out,
        x_npu,
        ba_npu,
        h,
        hv,
        k,
        v,
        rows,
        1,
        x_npu.stride(0),
        ba_npu.stride(0),
        mixed_qkv_out.stride(0),
        z_out.stride(0),
        b_out.stride(0),
        1,
    )
    result = (mixed_qkv_out, z_out, b_out, a_out)
    grouped = x.reshape(rows, h, 768)
    grouped_ba = ba.reshape(rows, h, 4)
    qs, ks, vs, zs = grouped.split([128, 128, 256, 256], dim=-1)
    expected = (
        torch.cat(
            [qs.reshape(rows, -1), ks.reshape(rows, -1), vs.reshape(rows, -1)], -1
        ),
        zs.reshape(rows, hv, v),
        grouped_ba[:, :, :2].reshape(rows, hv),
        grouped_ba[:, :, 2:].reshape(rows, hv),
    )
    for name, actual, reference in zip(["mixed_qkv", "z", "b", "a"], result, expected):
        actual_output = actual.cpu()
        expected_output = reference
        expected_output = expected_output.to(actual_output.dtype)
        torch.testing.assert_close(
            (actual_output).float(),
            (expected_output).float(),
            atol=0,
            rtol=0,
            check_dtype=False,
        )
        assert (
            torch.isfinite(actual_output).all()
            and torch.isfinite(expected_output).all()
        )
    print("PASS: fused_qkvzba_split_reshape_cat")


if __name__ == "__main__":
    test_fused_qkvzba_split_reshape_cat()

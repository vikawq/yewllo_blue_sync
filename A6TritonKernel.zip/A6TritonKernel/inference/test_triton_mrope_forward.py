import os
import sys
import types
from types import SimpleNamespace

os.environ.setdefault("TRITON_BACKENDS_IN_TREE", "1")
os.environ.setdefault("TRITON_BACKEND", "opentile")
os.environ.setdefault("TRITON_ALWAYS_COMPILE", "1")

import triton
import triton.language as _tl

tl = _tl

_vllm_utils = types.ModuleType("vllm.triton_utils")
_vllm_utils.tl = _tl
_vllm_utils.triton = triton
_vllm_pkg = types.ModuleType("vllm")
_vllm_pkg.triton_utils = _vllm_utils
sys.modules.setdefault("vllm", _vllm_pkg)
sys.modules.setdefault("vllm.triton_utils", _vllm_utils)

vllm_platforms = types.ModuleType("vllm.platforms")
vllm_platforms.current_platform = SimpleNamespace(is_rocm=lambda: False, is_cuda=lambda: False)
sys.modules["vllm.platforms"] = vllm_platforms

vllm_utils_mod = types.ModuleType("vllm.utils")
sys.modules["vllm.utils"] = vllm_utils_mod
vllm_torch_utils = types.ModuleType("vllm.utils.torch_utils")
vllm_torch_utils.direct_register_custom_op = lambda **kw: None
sys.modules["vllm.utils.torch_utils"] = vllm_torch_utils
vllm_utils_mod.torch_utils = vllm_torch_utils

try:
    from triton.backends.ascend import compiler as C

    _orig = C.linalg_to_bin_enable_npu_compile_910_95

    def _compile_with_nolicm(linalg, metadata, opt):
        bo = metadata.get("bisheng_options")
        if bo and "-disable-machine-licm" not in bo:
            metadata["bisheng_options"] = bo + " -mllvm -disable-machine-licm"
        return _orig(linalg, metadata, opt)

    C.linalg_to_bin_enable_npu_compile_910_95 = _compile_with_nolicm
except Exception:
    pass

import torch
import numpy as np

if not (hasattr(torch, "npu") and torch.npu.is_available()):
    raise RuntimeError("no NPU device visible")

RP_PKG = "vllm.model_executor.layers.rotary_embedding"
for m in [RP_PKG, RP_PKG + ".base", RP_PKG + ".yarn_scaling_rope"]:
    sys.modules[m] = types.ModuleType(m)

base_mod = sys.modules[RP_PKG + ".base"]


class RotaryEmbeddingBase:
    def __init__(self, head_size, rotary_dim, max_position_embeddings, base, is_neox_style, dtype):
        self.head_size = head_size
        self.rotary_dim = rotary_dim
        self.max_position_embeddings = max_position_embeddings
        self.base = base
        self.is_neox_style = is_neox_style
        self.dtype = dtype

    def _compute_inv_freq(self, base):
        raise NotImplementedError

    def _compute_cos_sin_cache(self):
        raise NotImplementedError

    def _match_cos_sin_cache_dtype(self, query):
        return query


base_mod.RotaryEmbeddingBase = RotaryEmbeddingBase

ysr_mod = sys.modules[RP_PKG + ".yarn_scaling_rope"]


class YaRNScalingRotaryEmbedding:
    pass


ysr_mod.YaRNScalingRotaryEmbedding = YaRNScalingRotaryEmbedding
ysr_mod.yarn_get_mscale = lambda *a, **k: 1.0


current_platform = vllm_platforms.current_platform

@triton.jit

def _triton_mrope_forward(

    q_ptr,

    k_ptr,

    cos,

    sin,

    mod3,

    num_tokens,

    n_qh: tl.constexpr,

    n_kh: tl.constexpr,

    hd: tl.constexpr,

    rd: tl.constexpr,

    pad_n_qh: tl.constexpr,

    pad_n_kh: tl.constexpr,

    pad_rd: tl.constexpr,

    mrope_section_t: tl.constexpr,

    mrope_section_h: tl.constexpr,

    mrope_section_w: tl.constexpr,

    is_interleaved: tl.constexpr,

    is_neox_style: tl.constexpr,

):

    # Adapted from

    # https://github.com/linkedin/Liger-Kernel/blob/main/src/liger_kernel/ops/qwen2vl_mrope.py

    # This version supports flatten input tensors from vllm

    # and supports cos and sin cache with shape (3, num_tokens, rotary_dim // 2)

    # instead of (3, bsz, seq_len, head_dim), also supports interleaved rotary

    pid = tl.program_id(0)

    # locate start address

    q_ptr = q_ptr + pid * (n_qh * hd)

    k_ptr = k_ptr + pid * (n_kh * hd)



    # ####################################################################

    # get the cos(m胃_{i...d/2}) and sin(m胃_{i...d/2}) for token position

    # m of this program instance

    # ####################################################################

    # Note: cos and sin now have shape (3, num_tokens, rotary_dim // 2)



    # Updated stride calculation for half rotary_dim

    half_rd = rd // 2

    t_cos = cos + pid * half_rd

    h_cos = t_cos + num_tokens * half_rd

    w_cos = h_cos + num_tokens * half_rd

    t_sin = sin + pid * half_rd

    h_sin = t_sin + num_tokens * half_rd

    w_sin = h_sin + num_tokens * half_rd



    # Updated offsets for half rotary_dim

    cos_offsets = tl.arange(0, pad_rd // 2)

    if is_interleaved:

        valid_mask = cos_offsets < half_rd

        mod3_row = tl.load(mod3 + cos_offsets, mask=valid_mask, other=0)

        h_mask = (

            valid_mask & (mod3_row == 1) & (cos_offsets <= 3 * mrope_section_h)

        )

        w_mask = (

            valid_mask & (mod3_row == 2) & (cos_offsets <= 3 * mrope_section_w)

        )

        t_mask = valid_mask & ~(h_mask | w_mask)

    else:

        t_end = mrope_section_t

        h_end = t_end + mrope_section_h

        t_mask = cos_offsets < mrope_section_t

        h_mask = (t_end <= cos_offsets) & (cos_offsets < h_end)

        w_mask = (h_end <= cos_offsets) & (cos_offsets < half_rd)



    # Load the full row without mask and select with tl.where. The three

    # masks are mutually exclusive, so sum(tl.where(mask_k, row_k, 0)) is

    # exactly equivalent to the masked-load version while avoiding the

    # gather-style indirect load (indirect_load_nonvolatile_1d_float_int64_t)

    # that has no implementation in meta_op.aiv.9201.bc.

    t_cos_all = tl.load(t_cos + cos_offsets)

    h_cos_all = tl.load(h_cos + cos_offsets)

    w_cos_all = tl.load(w_cos + cos_offsets)

    t_sin_all = tl.load(t_sin + cos_offsets)

    h_sin_all = tl.load(h_sin + cos_offsets)

    w_sin_all = tl.load(w_sin + cos_offsets)



    cos_row = (

        tl.where(t_mask, t_cos_all, 0.0)

        + tl.where(h_mask, h_cos_all, 0.0)

        + tl.where(w_mask, w_cos_all, 0.0)

    )

    sin_row = (

        tl.where(t_mask, t_sin_all, 0.0)

        + tl.where(h_mask, h_sin_all, 0.0)

        + tl.where(w_mask, w_sin_all, 0.0)

    )



    # ####################################################################

    # Load the two values in each rotary pair for the current token.

    # NeoX pairs the first and second halves, while GPT-J pairs

    # adjacent values.

    # ####################################################################

    if is_neox_style:

        rotary_offsets = tl.arange(0, pad_rd // 2)

        first_q_offsets = tl.arange(0, pad_n_qh)[:, None] * hd + rotary_offsets[None, :]

        first_k_offsets = tl.arange(0, pad_n_kh)[:, None] * hd + rotary_offsets[None, :]

        first_q_mask = (tl.arange(0, pad_n_qh)[:, None] < n_qh) & (

            rotary_offsets[None, :] < rd // 2

        )

        first_k_mask = (tl.arange(0, pad_n_kh)[:, None] < n_kh) & (

            rotary_offsets[None, :] < rd // 2

        )



        q_tile_1 = tl.load(q_ptr + first_q_offsets, mask=first_q_mask, other=0).to(

            sin_row.dtype

        )

        k_tile_1 = tl.load(k_ptr + first_k_offsets, mask=first_k_mask, other=0).to(

            sin_row.dtype

        )



        second_q_offsets = first_q_offsets + (rd // 2)

        second_k_offsets = first_k_offsets + (rd // 2)

        q_tile_2 = tl.load(q_ptr + second_q_offsets, mask=first_q_mask, other=0).to(

            sin_row.dtype

        )

        k_tile_2 = tl.load(k_ptr + second_k_offsets, mask=first_k_mask, other=0).to(

            sin_row.dtype

        )



        new_q_tile_1 = q_tile_1 * cos_row - q_tile_2 * sin_row

        tl.store(q_ptr + first_q_offsets, new_q_tile_1, mask=first_q_mask)

        new_q_tile_2 = q_tile_2 * cos_row + q_tile_1 * sin_row

        tl.store(q_ptr + second_q_offsets, new_q_tile_2, mask=first_q_mask)



        new_k_tile_1 = k_tile_1 * cos_row - k_tile_2 * sin_row

        tl.store(k_ptr + first_k_offsets, new_k_tile_1, mask=first_k_mask)

        new_k_tile_2 = k_tile_2 * cos_row + k_tile_1 * sin_row

        tl.store(k_ptr + second_k_offsets, new_k_tile_2, mask=first_k_mask)

    else:

        # GPT-J layout: adjacent pairs (2i, 2i+1) share one (cos, sin).

        # Load even/odd elements with two stride-2 loads so the backend can

        # keep contiguous vector loads and no tl.split/tl.interleave (which

        # lower to vintlv/vdintlvv2, unsupported on dav-920r1-vec) is emitted.

        pair_offsets = tl.arange(0, pad_rd // 2)

        even_q_offsets = (

            tl.arange(0, pad_n_qh)[:, None] * hd + pair_offsets[None, :] * 2

        )

        odd_q_offsets = even_q_offsets + 1

        even_k_offsets = (

            tl.arange(0, pad_n_kh)[:, None] * hd + pair_offsets[None, :] * 2

        )

        odd_k_offsets = even_k_offsets + 1

        q_mask = (tl.arange(0, pad_n_qh)[:, None] < n_qh) & (

            pair_offsets[None, :] * 2 < rd

        )

        k_mask = (tl.arange(0, pad_n_kh)[:, None] < n_kh) & (

            pair_offsets[None, :] * 2 < rd

        )



        q_tile_1 = tl.load(q_ptr + even_q_offsets, mask=q_mask, other=0).to(

            sin_row.dtype

        )

        q_tile_2 = tl.load(q_ptr + odd_q_offsets, mask=q_mask, other=0).to(

            sin_row.dtype

        )

        k_tile_1 = tl.load(k_ptr + even_k_offsets, mask=k_mask, other=0).to(

            sin_row.dtype

        )

        k_tile_2 = tl.load(k_ptr + odd_k_offsets, mask=k_mask, other=0).to(

            sin_row.dtype

        )



        new_q_tile_1 = q_tile_1 * cos_row - q_tile_2 * sin_row

        new_q_tile_2 = q_tile_2 * cos_row + q_tile_1 * sin_row

        tl.store(q_ptr + even_q_offsets, new_q_tile_1, mask=q_mask)

        tl.store(q_ptr + odd_q_offsets, new_q_tile_2, mask=q_mask)



        new_k_tile_1 = k_tile_1 * cos_row - k_tile_2 * sin_row

        new_k_tile_2 = k_tile_2 * cos_row + k_tile_1 * sin_row

        tl.store(k_ptr + even_k_offsets, new_k_tile_1, mask=k_mask)

        tl.store(k_ptr + odd_k_offsets, new_k_tile_2, mask=k_mask)

def triton_mrope(

    q: torch.Tensor,

    k: torch.Tensor,

    cos: torch.Tensor,

    sin: torch.Tensor,

    mrope_section: list[int],

    head_size: int,

    rotary_dim: int,

    mrope_interleaved: bool,

    is_neox_style: bool,

) -> tuple[torch.Tensor, torch.Tensor]:

    """Qwen2VL mrope kernel.



    Args:

        q: [num_tokens, num_heads * head_size]

        k: [num_tokens, num_kv_heads * head_size]

        cos: [3, num_tokens, rotary_dim // 2]

            (T/H/W positions with multimodal inputs)

        sin: [3, num_tokens, rotary_dim // 2]

            (T/H/W positions with multimodal inputs)

        mrope_section: [t, h, w]

        head_size: int

        rotary_dim: Number of leading dimensions rotary is applied to.

        mrope_interleaved: Whether the T/H/W sections are interleaved rather

            than concatenated.

        is_neox_style: Whether rotary pairs use split-half (NeoX) or

            adjacent (GPT-J) layout.



    """

    n_row, n_q_head_head_dim = q.shape

    n_q_head = n_q_head_head_dim // head_size

    n_kv_head = k.shape[1] // head_size

    pad_rd = triton.next_power_of_2(rotary_dim)

    pad_n_q_head = triton.next_power_of_2(n_q_head)

    pad_n_kv_head = triton.next_power_of_2(n_kv_head)



    # ensure tensors passed into the kernel are contiguous.

    # It will be no-op if they are already contiguous

    q = q.contiguous()

    k = k.contiguous()

    cos = cos.contiguous()

    sin = sin.contiguous()



    # Small adjacent-pair tiles perform best with one wave per program on

    # ROCm. Keep the existing launch shape for larger rotary dimensions,

    # NeoX, and other backends.

    use_single_wave = current_platform.is_rocm() and not is_neox_style and pad_rd <= 64

    num_warps = 1

    half_rd = rotary_dim // 2

    if mrope_interleaved:

        with torch.no_grad():

            mod3_cpu = torch.arange(0, pad_rd // 2, dtype=torch.int32) % 3

            mod3 = mod3_cpu.contiguous().to(q.device)

    else:

        mod3 = torch.empty(0, device=q.device, dtype=torch.int32)

    _triton_mrope_forward[(n_row,)](

        q,

        k,

        cos,

        sin,

        mod3,

        n_row,

        n_q_head,

        n_kv_head,

        head_size,

        rotary_dim,

        pad_n_q_head,

        pad_n_kv_head,

        pad_rd,

        mrope_section[0],

        mrope_section[1],

        mrope_section[2],

        mrope_interleaved,

        is_neox_style,

        num_warps=num_warps,

    )

    return q, k

# ===== end inlined MROPE =====

def cos_row_ref(cos, sin, pid, mrope_section, half_rd, is_interleaved):
    t, h, w = mrope_section
    cr = np.zeros(half_rd, dtype=np.float32)
    sr = np.zeros(half_rd, dtype=np.float32)
    for j in range(half_rd):
        if is_interleaved:
            if (j % 3) == 1 and j <= 3 * h:
                chan = 1
            elif (j % 3) == 2 and j <= 3 * w:
                chan = 2
            else:
                chan = 0
        else:
            if j < t:
                chan = 0
            elif j < t + h:
                chan = 1
            else:
                chan = 2
        cr[j] = cos[chan, pid, j]
        sr[j] = sin[chan, pid, j]
    return cr, sr


def ref_mrope(q, k, cos, sin, mrope_section, head_size, rd, is_neox, is_interleaved):
    nt, _ = q.shape
    q = q.copy().astype(np.float32)
    k = k.copy().astype(np.float32)
    half = rd // 2
    n_qh = q.shape[1] // head_size
    n_kh = k.shape[1] // head_size
    for pid in range(nt):
        cr, sr = cos_row_ref(cos, sin, pid, mrope_section, half, is_interleaved)
        if is_neox:
            for hh in range(n_qh):
                base = hh * head_size
                q1 = q[pid, base : base + half].copy()
                q2 = q[pid, base + half : base + rd].copy()
                q[pid, base : base + half] = q1 * cr - q2 * sr
                q[pid, base + half : base + rd] = q2 * cr + q1 * sr
            for hh in range(n_kh):
                base = hh * head_size
                q1 = k[pid, base : base + half].copy()
                q2 = k[pid, base + half : base + rd].copy()
                k[pid, base : base + half] = q1 * cr - q2 * sr
                k[pid, base + half : base + rd] = q2 * cr + q1 * sr
        else:
            for hh in range(n_qh):
                base = hh * head_size
                for j in range(half):
                    a = q[pid, base + 2 * j]
                    b = q[pid, base + 2 * j + 1]
                    q[pid, base + 2 * j] = a * cr[j] - b * sr[j]
                    q[pid, base + 2 * j + 1] = b * cr[j] + a * sr[j]
            for hh in range(n_kh):
                base = hh * head_size
                for j in range(half):
                    a = k[pid, base + 2 * j]
                    b = k[pid, base + 2 * j + 1]
                    k[pid, base + 2 * j] = a * cr[j] - b * sr[j]
                    k[pid, base + 2 * j + 1] = b * cr[j] + a * sr[j]
    return q, k


def run_case(name, nt, n_qh, n_kh, head_size, rd, section, is_neox, is_interleaved, seed=0):
    torch.manual_seed(seed)
    dev = torch.device("npu", torch.npu.current_device())
    q = torch.randn(nt, n_qh * head_size, dtype=torch.float32, device=dev)
    k = torch.randn(nt, n_kh * head_size, dtype=torch.float32, device=dev)
    cos = torch.randn(3, nt, rd // 2, dtype=torch.float32, device=dev)
    sin = torch.randn(3, nt, rd // 2, dtype=torch.float32, device=dev)

    q_in = q.clone()
    k_in = k.clone()
    q_out, k_out = triton_mrope(
        q_in, k_in, cos, sin, section, head_size, rd, is_interleaved, is_neox
    )
    torch.npu.synchronize()

    eq, ek = ref_mrope(
        q.cpu().numpy(), k.cpu().numpy(),
        cos.cpu().numpy(), sin.cpu().numpy(),
        section, head_size, rd, is_neox, is_interleaved,
    )
    gq = q_out.cpu().numpy()
    gk = k_out.cpu().numpy()
    dq = np.abs(gq - eq).max()
    dk = np.abs(gk - ek).max()
    ok = dq < 1e-3 and dk < 1e-3
    print(f"[{'PASS' if ok else 'FAIL'}] {name}: nt={nt} qh={n_qh} kh={n_kh} hd={head_size} rd={rd} sec={section} neox={is_neox} inter={is_interleaved}")
    if not ok:
        print(f"  q_max_diff={dq:.6f} k_max_diff={dk:.6f}")
    return ok


def test_triton_mrope_forward():
    ok = run_case("mrope-neox-concat", 4, 4, 2, 32, 32, [8, 4, 4], True, False, seed=1)
    assert ok, "triton_mrope_forward FAILED"
    print("[ALL PASS] triton_mrope_forward")


if __name__ == "__main__":
    test_triton_mrope_forward()

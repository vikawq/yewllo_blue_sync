import os
import sys
import types

os.environ.setdefault("TRITON_BACKENDS_IN_TREE", "1")
os.environ.setdefault("TRITON_BACKEND", "opentile")
os.environ.setdefault("TRITON_ALWAYS_COMPILE", "1")

import triton
import triton.language as _tl

tl = _tl

_vllm_utils = types.ModuleType("vllm.triton_utils")
_vllm_utils.tl = _tl
_vllm_utils.triton = triton
_vllm_pkg = types.ModuleType("vllm")
_vllm_pkg.triton_utils = _vllm_utils
sys.modules.setdefault("vllm", _vllm_pkg)
sys.modules.setdefault("vllm.triton_utils", _vllm_utils)

try:
    from triton.language.extra.cann.extension import extract_slice, insert_slice
except Exception:
    raise

vllm_ascend_pkg = types.ModuleType("vllm_ascend")
vllm_ascend_ops = types.ModuleType("vllm_ascend.ops")
vllm_ascend_triton = types.ModuleType("vllm_ascend.ops.triton")
vllm_ascend_tu = types.ModuleType("vllm_ascend.ops.triton.triton_utils")
vllm_ascend_tu.extract_slice = extract_slice
vllm_ascend_tu.insert_slice = insert_slice
vllm_ascend_tu.get_aicore_num = lambda: 32
for name, mod in [
    ("vllm_ascend", vllm_ascend_pkg),
    ("vllm_ascend.ops", vllm_ascend_ops),
    ("vllm_ascend.ops.triton", vllm_ascend_triton),
    ("vllm_ascend.ops.triton.triton_utils", vllm_ascend_tu),
]:
    sys.modules.setdefault(name, mod)
vllm_ascend_pkg.ops = vllm_ascend_ops
vllm_ascend_ops.triton = vllm_ascend_triton
vllm_ascend_triton.triton_utils = vllm_ascend_tu

try:
    from triton.backends.ascend import compiler as C

    _orig = C.linalg_to_bin_enable_npu_compile_910_95

    def _compile_with_nolicm(linalg, metadata, opt):
        bo = metadata.get("bisheng_options")
        if bo and "-disable-machine-licm" not in bo:
            metadata["bisheng_options"] = bo + " -mllvm -disable-machine-licm"
        return _orig(linalg, metadata, opt)

    C.linalg_to_bin_enable_npu_compile_910_95 = _compile_with_nolicm
except Exception:
    pass

import torch
import numpy as np

if not (hasattr(torch, "npu") and torch.npu.is_available()):
    raise RuntimeError("no NPU device visible")


@triton.heuristics({"IS_VARLEN": lambda args: args["cu_seqlens"] is not None})
@triton.jit(do_not_specialize=["T", "H"])
def solve_tril_16x16_kernel(
    A,
    Ad,
    cu_seqlens,
    chunk_indices,
    T,
    H,
    BT: tl.constexpr,
    IS_VARLEN: tl.constexpr,
    LARGE_BLOCK_T: tl.constexpr,
    EXTRACT_SLICE_STRIDE_1: tl.constexpr,
):
    i_t, i_bh = tl.program_id(0), tl.program_id(1)
    i_b, i_h = i_bh // H, i_bh % H
    if IS_VARLEN:
        i_n, i_t = (
            tl.load(chunk_indices + i_t * 2).to(tl.int32),
            tl.load(chunk_indices + i_t * 2 + 1).to(tl.int32),
        )
        bos, eos = (
            tl.load(cu_seqlens + i_n).to(tl.int32),
            tl.load(cu_seqlens + i_n + 1).to(tl.int32),
        )
        T = eos - bos
    else:
        bos, eos = i_b * T, i_b * T + T

    A = A + (bos * H + i_h) * BT
    Ad = Ad + (bos * H + i_h) * 16

    base_t = i_t * LARGE_BLOCK_T

    NTASKS: tl.constexpr = 2
    N_BLOCKS: tl.constexpr = LARGE_BLOCK_T // 16 // NTASKS

    for taskid in range(0, NTASKS):
        base_t += taskid * (LARGE_BLOCK_T // NTASKS)

        # use make_block_ptr to reduce vector computation
        b_A = tl.zeros((N_BLOCKS, 16, 16), dtype=tl.float32)
        for blkid in range(0, N_BLOCKS):
            row_start_o = base_t + blkid * 16
            col_start_o = row_start_o % BT

            # 1 Create in-block offset
            offs_rows_in_block = tl.arange(0, 16)
            offs_cols_in_block = tl.arange(0, 16)

            # 2 Calculate the pointer of each element
            ptr_A_subrec16 = (
                A
                + row_start_o * H * BT
                + col_start_o
                + offs_rows_in_block[:, None] * H * BT
                + offs_cols_in_block[None, :]
            )

            # 3 Create a mask to prevent out-of-bounds access
            global_rows = row_start_o + offs_rows_in_block[:, None]
            global_cols = col_start_o + offs_cols_in_block[None, :]
            load_mask = (global_rows < T) & (global_cols < BT)

            # 4 Use mask to safely load data
            b_A_subrec16 = tl.load(ptr_A_subrec16, mask=load_mask, other=0.0).to(tl.float32)
            b_A = insert_slice(
                ful=b_A,
                sub=b_A_subrec16[None, :, :],  # (1, 16, 16)
                offsets=[blkid, 0, 0],
                sizes=[1, 16, 16],
                strides=[1, 1, 1],
            )

        local_ori_A = tl.trans(b_A, (1, 0, 2))
        local_ori_A = tl.reshape(local_ori_A, (16, 16 * N_BLOCKS))

        # Convert mask into matrix multiplication to avoid for loops ub oom
        tmp = tl.arange(0, 16).to(tl.float32)
        rows = tmp[:, None]
        cols = tmp[None, :]
        is_lower = (rows > cols).to(b_A.dtype)
        b_A = -b_A * is_lower

        # for loop to update N_BLOCKS row vector
        for i in range(1, 16):
            nblks_vec16 = -extract_slice(local_ori_A, (i, 0), (1, 16 * N_BLOCKS), (EXTRACT_SLICE_STRIDE_1, 1))
            b_a = tl.reshape(nblks_vec16, (N_BLOCKS, 16))

            dot_tmp = tl.trans(b_a[:, :, None] * b_A, (1, 0, 2))
            dot_product = tl.sum(dot_tmp, 0)
            b_a = b_a + dot_product

            b_a_new_expanded = b_a[:, None, :]
            b_A = insert_slice(
                ful=b_A, sub=b_a_new_expanded, offsets=[0, i, 0], sizes=[N_BLOCKS, 1, 16], strides=[1, 1, 1]
            )

        on_diagonal = rows == cols
        b_A = b_A + on_diagonal.to(b_A.dtype)

        b_A = tl.reshape(b_A, (N_BLOCKS * 16, 16))
        p_Ai = tl.make_block_ptr(Ad, (T, 16), (H * 16, 1), (base_t, 0), (N_BLOCKS * 16, 16), (1, 0))

        # 1 Create in-block offset
        offs_rows_to_store = tl.arange(0, N_BLOCKS * 16)
        offs_cols_to_store = tl.arange(0, 16)

        # 2 Calculate the pointer of each element
        p_Ai = Ad + base_t * H * 16 + 0 + offs_rows_to_store[:, None] * H * 16 + offs_cols_to_store[None, :]
        # 3 Create a mask to prevent out-of-bounds access, only check rows
        global_store_rows = base_t + offs_rows_to_store[:, None]
        store_mask = global_store_rows < T
        # 4 use mask to save data safely
        tl.store(p_Ai, b_A.to(p_Ai.dtype.element_ty, fp_downcast_rounding="rtne"), mask=store_mask)

@triton.heuristics({"IS_VARLEN": lambda args: args["cu_seqlens"] is not None})
@triton.jit(do_not_specialize=["T", "H"])
def merge_16x16_to_32x32_inverse_kernel(
    A,
    Ad,
    Ai,
    cu_seqlens,
    chunk_indices,
    T,
    H,
    BT: tl.constexpr,
    IS_VARLEN: tl.constexpr,
):
    i_t, i_bh = tl.program_id(0), tl.program_id(1)
    i_b, i_h = i_bh // H, i_bh % H
    if IS_VARLEN:
        i_n, i_t = (
            tl.load(chunk_indices + i_t * 2).to(tl.int32),
            tl.load(chunk_indices + i_t * 2 + 1).to(tl.int32),
        )
        bos, eos = (
            tl.load(cu_seqlens + i_n).to(tl.int32),
            tl.load(cu_seqlens + i_n + 1).to(tl.int32),
        )
        T = eos - bos
    else:
        bos, eos = i_b * T, i_b * T + T

    A += (bos * H + i_h) * 32
    Ad += (bos * H + i_h) * 16
    Ai += (bos * H + i_h) * 32

    p_A_21 = tl.make_block_ptr(A, (T, 32), (H * 32, 1), (i_t * 32 + 16, 0), (16, 16), (1, 0))
    p_Ad_11 = tl.make_block_ptr(Ad, (T, 16), (H * 16, 1), (i_t * 32, 0), (16, 16), (1, 0))
    p_Ad_22 = tl.make_block_ptr(Ad, (T, 16), (H * 16, 1), (i_t * 32 + 16, 0), (16, 16), (1, 0))
    p_Ai_11 = tl.make_block_ptr(Ai, (T, 32), (H * 32, 1), (i_t * 32, 0), (16, 16), (1, 0))
    p_Ai_22 = tl.make_block_ptr(Ai, (T, 32), (H * 32, 1), (i_t * 32 + 16, 16), (16, 16), (1, 0))
    p_Ai_21 = tl.make_block_ptr(Ai, (T, 32), (H * 32, 1), (i_t * 32 + 16, 0), (16, 16), (1, 0))

    A_21 = tl.load(p_A_21, boundary_check=(0, 1)).to(tl.float32)
    Ai_11 = tl.load(p_Ad_11, boundary_check=(0, 1)).to(tl.float32)
    Ai_22 = tl.load(p_Ad_22, boundary_check=(0, 1)).to(tl.float32)
    Ai_21 = -tl.dot(
        tl.dot(Ai_22, A_21, input_precision="ieee"),
        Ai_11,
        input_precision="ieee",
    )
    tl.store(
        p_Ai_11,
        Ai_11.to(p_Ai_11.dtype.element_ty, fp_downcast_rounding="rtne"),
        boundary_check=(0, 1),
    )
    tl.store(
        p_Ai_22,
        Ai_22.to(p_Ai_22.dtype.element_ty, fp_downcast_rounding="rtne"),
        boundary_check=(0, 1),
    )
    tl.store(
        p_Ai_21,
        Ai_21.to(p_Ai_21.dtype.element_ty, fp_downcast_rounding="rtne"),
        boundary_check=(0, 1),
    )

    # zero out the upper-right 16 * 16 block (rows 0 ~ 15, cols 16 ~ 31)
    offs_m = i_t * 32 + tl.arange(0, 16)
    offs_n = 16 + tl.arange(0, 16)
    mask_store = (offs_m[:, None] < T) & (offs_n[None, :] < BT)
    ptr_Ai = Ai + offs_m[:, None] * (H * BT) + offs_n[None, :]
    zero_block = tl.zeros((16, 16), dtype=ptr_Ai.dtype.element_ty)
    tl.store(ptr_Ai, zero_block, mask=mask_store)

@triton.heuristics({"IS_VARLEN": lambda args: args["cu_seqlens"] is not None})
@triton.jit(do_not_specialize=["T", "H"])
def merge_16x16_to_64x64_inverse_kernel(
    A,
    Ad,
    Ai,
    cu_seqlens,
    chunk_indices,
    T,
    H,
    BT: tl.constexpr,
    IS_VARLEN: tl.constexpr,
):
    i_t, i_bh = tl.program_id(0), tl.program_id(1)
    i_b, i_h = i_bh // H, i_bh % H
    if IS_VARLEN:
        i_n, i_t_val = (
            tl.load(chunk_indices + i_t * 2).to(tl.int32),
            tl.load(chunk_indices + i_t * 2 + 1).to(tl.int32),
        )
        bos, eos = (
            tl.load(cu_seqlens + i_n).to(tl.int32),
            tl.load(cu_seqlens + i_n + 1).to(tl.int32),
        )
        T = eos - bos
        i_t = i_t_val
    else:
        bos, eos = i_b * T, i_b * T + T

    # Base pointers (already offset by batch and head)
    A += (bos * H + i_h) * 64
    Ad += (bos * H + i_h) * 16
    Ai += (bos * H + i_h) * 64

    # load Ai_22 (Ad block at row i_t * 64 + 16, col 0, 16 * 16)
    offs_m = i_t * 64 + 16 + tl.arange(0, 16)
    offs_n = tl.arange(0, 16)
    mask_Ad = (offs_m[:, None] < T) & (offs_n[None, :] < 16)
    ptr_Ad = Ad + offs_m[:, None] * (H * 16) + offs_n[None, :]
    Ai_22 = tl.load(ptr_Ad, mask=mask_Ad, other=0.0).to(tl.float32)

    # load A_21 (A block at row i_t * 64 + 16, col 0, 16 * 16)
    mask_A = (offs_m[:, None] < T) & (offs_n[None, :] < 64)
    ptr_A = A + offs_m[:, None] * (H * 64) + offs_n[None, :]
    A_21 = tl.load(ptr_A, mask=mask_A, other=0.0).to(tl.float32)
    tmp = tl.dot(Ai_22, A_21, input_precision="ieee")

    # load Ai_11 (Ad block at row i_t * 64, col 0, 16 * 16)
    offs_m = i_t * 64 + tl.arange(0, 16)
    offs_n = tl.arange(0, 16)
    mask_Ad = (offs_m[:, None] < T) & (offs_n[None, :] < 16)
    ptr_Ad = Ad + offs_m[:, None] * (H * 16) + offs_n[None, :]
    Ai_11 = tl.load(ptr_Ad, mask=mask_Ad, other=0.0).to(tl.float32)

    Ai_21 = -tl.dot(tmp, Ai_11, input_precision="ieee")

    # load Ai_44 (Ad block at row i_t * 64 + 48, col 0, 16 * 16)
    offs_m = i_t * 64 + 48 + tl.arange(0, 16)
    offs_n = tl.arange(0, 16)
    mask_Ad = (offs_m[:, None] < T) & (offs_n[None, :] < 16)
    ptr_Ad = Ad + offs_m[:, None] * (H * 16) + offs_n[None, :]
    Ai_44 = tl.load(ptr_Ad, mask=mask_Ad, other=0.0).to(tl.float32)

    # load A_43 (Ad block at row i_t * 64 + 48, col 32, 16 * 16)
    offs_n = 32 + tl.arange(0, 16)
    mask_A = (offs_m[:, None] < T) & (offs_n[None, :] < 64)
    ptr_A = A + offs_m[:, None] * (H * 64) + offs_n[None, :]
    A_43 = tl.load(ptr_A, mask=mask_A, other=0.0).to(tl.float32)
    tmp = tl.dot(Ai_44, A_43, input_precision="ieee")

    # load Ai_33 (Ad block at row i_t * 64 + 32, col 0, 16 * 16)
    offs_m = i_t * 64 + 32 + tl.arange(0, 16)
    offs_n = tl.arange(0, 16)
    mask_Ad = (offs_m[:, None] < T) & (offs_n[None, :] < 16)
    ptr_Ad = Ad + offs_m[:, None] * (H * 16) + offs_n[None, :]
    Ai_33 = tl.load(ptr_Ad, mask=mask_Ad, other=0.0).to(tl.float32)

    Ai_43 = -tl.dot(tmp, Ai_33, input_precision="ieee")

    # build Ai_22_32 (32 * 32)
    Ai_22_32 = tl.zeros((32, 32), tl.float32)
    Ai_22_32 = insert_slice(Ai_22_32, Ai_33, (0, 0), (16, 16), (1, 1))
    Ai_22_32 = insert_slice(Ai_22_32, Ai_44, (16, 16), (16, 16), (1, 1))
    Ai_22_32 = insert_slice(Ai_22_32, Ai_43, (16, 0), (16, 16), (1, 1))

    # load A_21_32 (A block at row i_t * 64 + 32, col 0, 32 * 32)
    offs_m = i_t * 64 + 32 + tl.arange(0, 32)
    offs_n = tl.arange(0, 32)
    mask_A = (offs_m[:, None] < T) & (offs_n[None, :] < 64)
    ptr_A = A + offs_m[:, None] * (H * 64) + offs_n[None, :]
    A_21_32 = tl.load(ptr_A, mask=mask_A, other=0.0).to(tl.float32)
    tmp = tl.dot(Ai_22_32, A_21_32, input_precision="ieee")

    # build Ai_11_32 (32 * 32)
    Ai_11_32 = tl.zeros((32, 32), tl.float32)
    Ai_11_32 = insert_slice(Ai_11_32, Ai_11, (0, 0), (16, 16), (1, 1))
    Ai_11_32 = insert_slice(Ai_11_32, Ai_22, (16, 16), (16, 16), (1, 1))
    Ai_11_32 = insert_slice(Ai_11_32, Ai_21, (16, 0), (16, 16), (1, 1))

    Ai_21_32 = -tl.dot(tmp, Ai_11_32, input_precision="ieee")

    # store Ai_11_32 to (i_t * 64, 0)
    offs_m = i_t * 64 + tl.arange(0, 32)
    offs_n = tl.arange(0, 32)
    mask_store = (offs_m[:, None] < T) & (offs_n[None, :] < 64)
    ptr_Ai = Ai + offs_m[:, None] * (H * 64) + offs_n[None, :]
    tl.store(ptr_Ai, Ai_11_32.to(ptr_Ai.dtype.element_ty, fp_downcast_rounding="rtne"), mask=mask_store)

    # store Ai_22_32 to (i_t * 64 + 32, 32)
    offs_m = i_t * 64 + 32 + tl.arange(0, 32)
    offs_n = 32 + tl.arange(0, 32)
    mask_store = (offs_m[:, None] < T) & (offs_n[None, :] < 64)
    ptr_Ai = Ai + offs_m[:, None] * (H * 64) + offs_n[None, :]
    tl.store(ptr_Ai, Ai_22_32.to(ptr_Ai.dtype.element_ty, fp_downcast_rounding="rtne"), mask=mask_store)

    # store Ai_21_32 to (i_t * 64 + 32, 32)
    offs_n = tl.arange(0, 32)
    mask_store = (offs_m[:, None] < T) & (offs_n[None, :] < 64)
    ptr_Ai = Ai + offs_m[:, None] * (H * 64) + offs_n[None, :]
    tl.store(ptr_Ai, Ai_21_32.to(ptr_Ai.dtype.element_ty, fp_downcast_rounding="rtne"), mask=mask_store)

    # zero out the upper-right 32 * 32 block (rows 0 ~ 31, cols 32 ~ 63)
    offs_m = i_t * 64 + tl.arange(0, 32)
    offs_n = 32 + tl.arange(0, 32)
    mask_store = (offs_m[:, None] < T) & (offs_n[None, :] < BT)
    ptr_Ai = Ai + offs_m[:, None] * (H * BT) + offs_n[None, :]
    zero_block = tl.zeros((32, 32), dtype=ptr_Ai.dtype.element_ty)
    tl.store(ptr_Ai, zero_block, mask=mask_store)

# ===== end inlined ST =====

def _prepare_chunk_indices(cu_seqlens, chunk_size, cu_seqlens_cpu=None):
    lens = torch.diff(cu_seqlens)
    lens = torch.where(lens > 0, lens, torch.zeros_like(lens))
    nchunks = torch.ceil(lens.to(torch.float64) / chunk_size).to(torch.int64)
    parts = [torch.arange(int(n), dtype=torch.int64) for n in nchunks.tolist() if n > 0]
    if not parts:
        indices = torch.empty((0,), dtype=torch.int64)
    else:
        indices = torch.cat(parts)
    return torch.stack([indices.eq(0).cumsum(0) - 1, indices], 1).to(cu_seqlens)


fla_pkg = types.ModuleType("fla")
fla_pkg.__path__ = []
sys.modules["fla"] = fla_pkg

utils_mod = types.ModuleType("fla.utils")
utils_mod.prepare_chunk_indices = _prepare_chunk_indices
sys.modules["fla.utils"] = utils_mod


def ref_16x16_block(A):
    B, T, H, BT = A.shape
    ref = torch.zeros_like(A, dtype=torch.float32)
    for b in range(B):
        for t0 in range(0, T, BT):
            for h in range(H):
                sub = A[b, t0 : t0 + BT, h, :].to(torch.float32)
                sub = sub[:, :BT]
                I = torch.eye(BT, dtype=torch.float32)
                inv = torch.linalg.inv(I + sub)
                ref[b, t0 : t0 + BT, h, :BT] = inv
    return ref


def run_case(name, B, T, H, BT, seed=0):
    torch.manual_seed(seed)
    dev = torch.device("npu", torch.npu.current_device())
    A = torch.randn(B, T, H, BT, dtype=torch.float32, device=dev)
    r = torch.arange(BT, device=dev)
    blk_mask = (r[:, None] > r[None, :]).to(torch.float32)
    A = (A.view(B, T // BT, BT, H, BT) * blk_mask.view(1, 1, BT, 1, BT)).reshape(B, T, H, BT)
    Ad = torch.empty(B, T, H, 16, dtype=torch.float32, device=dev)

    LARGE_BLOCK_T = 128
    NT = triton.cdiv(T, LARGE_BLOCK_T)
    EXTRACT_SLICE_STRIDE_1 = LARGE_BLOCK_T // 32

    solve_tril_16x16_kernel[(NT, B * H)](
        A,
        Ad,
        None,
        torch.empty(0, dtype=torch.int64, device=dev),
        T,
        H,
        BT=BT,
        LARGE_BLOCK_T=LARGE_BLOCK_T,
        EXTRACT_SLICE_STRIDE_1=EXTRACT_SLICE_STRIDE_1,
    )
    torch.npu.synchronize()

    got = Ad[:, :, :, :BT].cpu()
    exp = ref_16x16_block(A.cpu().to(torch.float32))
    ok = torch.allclose(got, exp, atol=1e-3, rtol=1e-3)
    print(f"[{'PASS' if ok else 'FAIL'}] {name}: B={B} T={T} H={H} BT={BT}")
    if not ok:
        d = (got - exp).abs()
        print(f"  max_diff={d.max().item():.6f}")
        idx = (d.view(-1).argmax().item())
        b_i, t_i, h_i, c_i = np.unravel_index(idx, d.shape)
        print(f"  argmax at (b={b_i}, t={t_i}, h={h_i}, c={c_i}) got={got[b_i,t_i,h_i,c_i].item():.4f} exp={exp[b_i,t_i,h_i,c_i].item():.4f}")
        nb = T // BT
        for j in range(min(nb, 4)):
            gb = got[0, j * BT : (j + 1) * BT, 0, :].numpy()
            eb = exp[0, j * BT : (j + 1) * BT, 0, :].numpy()
            db = (gb - eb)
            ab = np.abs(db)
            print(f"  blk j={j} h=0 max_diff={ab.max():.6f} rowmax={ab.max(1).tolist()}")
            if j == 0:
                print("  A[0,0:6,0,0:6]:")
                print(np.array2string(A[0, 0:6, 0, 0:6].cpu().numpy(), precision=2))
                print("  got[0,0:6,0,0:6]:")
                print(np.array2string(gb[:6, :6], precision=4))
                print("  exp[0,0:6,0,0:6]:")
                print(np.array2string(eb[:6, :6], precision=4))
    return ok


def test_solve_tril_16x16_kernel():
    ok1 = run_case("tril16-single", B=1, T=16, H=1, BT=16, seed=1)
    ok2 = run_case("tril16-smoke", B=1, T=64, H=2, BT=16, seed=1)
    assert ok1 and ok2, "solve_tril_16x16_kernel FAILED"
    print("[ALL PASS] solve_tril_16x16_kernel")


if __name__ == "__main__":
    test_solve_tril_16x16_kernel()

# -*- coding: utf-8 -*-
import os
import sys
import types
import time
import traceback

os.environ.setdefault("TRITON_BACKENDS_IN_TREE", "1")
os.environ.setdefault("TRITON_BACKEND", "opentile")
os.environ.setdefault("TRITON_ALWAYS_COMPILE", "1")

import triton
import triton.language as tl
import torch

_vllm_utils = types.ModuleType("vllm.triton_utils")
_vllm_utils.tl = tl
_vllm_utils.triton = triton
_vllm_utils.tldevice = types.SimpleNamespace(
    fast_dividef=lambda x, y: x / y,
    fast_expf=tl.exp,
    fast_logf=tl.log,
    fast_log2f=tl.log2,
)
_vllm_pkg = types.ModuleType("vllm")
_vllm_pkg.triton_utils = _vllm_utils
sys.modules.setdefault("vllm", _vllm_pkg)
sys.modules["vllm.triton_utils"] = _vllm_utils
sys.modules["vllm"].triton_utils = _vllm_utils

_math_pkg = types.ModuleType("vllm.utils")
sys.modules.setdefault("vllm.utils", _math_pkg)
_math_mod = types.ModuleType("vllm.utils.math_utils")
sys.modules["vllm.utils.math_utils"] = _math_mod



def next_power_of_2(n: int) -> int:
    if n <= 0:
        return 1
    return 1 << (n - 1).bit_length()


VECTORCORE_NUM = 32


def get_vectorcore_num() -> int:
    return VECTORCORE_NUM


@triton.jit
def get_element(data, index):
    idx = index[0]
    n: tl.constexpr = data.shape[0]
    mask = tl.arange(0, n) == idx
    return tl.sum(tl.where(mask, data.to(tl.int32), 0))


@triton.jit(do_not_specialize=["replace_from", "replace_to", "vec_len"])
def expand_kernel(
    output_ptr,  # [num_tokens]
    input_ptr,  # [batch_size]
    cu_num_tokens_ptr,  # [batch_size]
    replace_from,
    replace_to,
    vec_len,
    MAX_NUM_TOKENS: tl.constexpr,
    BLOCK_SIZE: tl.constexpr,
):
    req_idx = tl.program_id(0)
    offset = req_idx * BLOCK_SIZE + tl.arange(0, BLOCK_SIZE)
    len_mask = offset < vec_len

    # Mask the load itself: tl.where does not prevent reading before the
    # buffer start (both arms are always evaluated), so lane offset == 0 must
    # be masked out at the load. other=0 keeps num_tokens deterministic (0)
    # for out-of-range lanes, which the store mask below relies on.
    start_idx = tl.load(cu_num_tokens_ptr + offset - 1, mask=len_mask & (offset > 0), other=0)
    end_idx = tl.load(cu_num_tokens_ptr + offset, len_mask, other=0)
    num_tokens = end_idx - start_idx

    src_val = tl.load(input_ptr + offset, len_mask)
    src_val = tl.where(src_val == replace_from, replace_to, src_val)

    for i in tl.range(0, BLOCK_SIZE):
        num_tokens1 = get_element(num_tokens, (i,))
        start_idx1 = get_element(start_idx, (i,))
        src_val1 = get_element(src_val, (i,))
        offset1 = tl.arange(0, MAX_NUM_TOKENS)
        tl.store(output_ptr + start_idx1 + offset1, src_val1, mask=offset1 < num_tokens1)

@triton.jit(
    do_not_specialize=[
        "max_spec_len",
        "vec_len",
    ]
)
def rejection_random_sample_kernel(
    output_token_ids_ptr,  # [batch_size, max_spec_len + 1]
    cu_num_draft_tokens_ptr,  # [batch_size]
    draft_token_ids_ptr,  # [num_tokens]
    draft_probs_ptr,  # [num_tokens, vocab_size] or None
    target_probs_ptr,  # [num_tokens, vocab_size] or [num_tokens, selected_vocab_size] if ENABLE_REDUCE_SAMPLING
    target_indices_ptr,  # [num_tokens, selected_vocab_size] global vocab indices, only used if ENABLE_REDUCE_SAMPLING
    bonus_token_ids_ptr,  # [batch_size]
    recovered_token_ids_ptr,  # [num_tokens]
    uniform_probs_ptr,  # [num_tokens]
    is_greedy_ptr,  # [batch_size]
    max_spec_len,
    vocab_size,  # vocab_size or selected_vocab_size if ENABLE_REDUCE_SAMPLING
    global_vocab_size,  # global vocab size for draft_probs indexing (only used if ENABLE_REDUCE_SAMPLING)
    vec_len,
    ori_target_probs_ptr,  # [num_tokens, ori_vocab_size] original probs for entropy
    synthetic_conditional_rates_ptr,  # [num_speculative_tokens] or None
    NO_ORI_TARGET_PROBS: tl.constexpr,
    NO_DRAFT_PROBS: tl.constexpr,
    ENABLE_REDUCE_SAMPLING: tl.constexpr,  # Whether using reduce sampling
    SYNTHETIC_MODE: tl.constexpr,
    ENTROPY_VERIFY: tl.constexpr,
    BLOCK_SIZE: tl.constexpr,
    VOCAB_BLOCK_SIZE: tl.constexpr = 512,
    POSTERIOR_THRESHOLD: tl.constexpr = 0.95,
    POSTERIOR_ALPHA: tl.constexpr = 0.4,
    SUB_BLOCK: tl.constexpr = 4096,
    EPSILON: tl.constexpr = 1e-10,
):
    block_idx = tl.program_id(0)
    offsets = block_idx * BLOCK_SIZE + tl.arange(0, BLOCK_SIZE)
    mask = offsets < vec_len
    is_greedy = tl.load(is_greedy_ptr + offsets, mask, other=1)
    not_greedy_mask = is_greedy == 0
    # Mask the load itself: tl.where does not prevent reading before the
    # buffer start (both arms are always evaluated), so lane offsets == 0 must
    # be masked out at the load.
    start_idxs = tl.load(cu_num_draft_tokens_ptr + offsets - 1, mask=not_greedy_mask & (offsets > 0), other=0)
    end_idxs = tl.load(cu_num_draft_tokens_ptr + offsets, not_greedy_mask, other=0)
    n_num_draft_tokens = end_idxs - start_idxs

    for req_i in range(BLOCK_SIZE):
        not_greedy = get_element(not_greedy_mask, (req_i,))
        if not_greedy:
            rejected = False
            start_idx = get_element(start_idxs, (req_i,))
            req_idx = block_idx * BLOCK_SIZE + req_i
            num_draft_tokens = get_element(n_num_draft_tokens, (req_i,))

            for pos in range(num_draft_tokens):
                if not rejected:
                    if SYNTHETIC_MODE:
                        # Synthetic: accept draft token with prob
                        # conditional_rates[pos], bypassing target/draft prob
                        # comparison. Output may be incorrect - benchmarking only.
                        token_idx = start_idx + pos
                        draft_token_id = tl.load(draft_token_ids_ptr + token_idx)
                        uniform_prob = tl.load(uniform_probs_ptr + token_idx)
                        rate = tl.load(synthetic_conditional_rates_ptr + pos)
                        accepted = (uniform_prob < rate) & (draft_token_id >= 0)
                        if accepted:
                            tl.store(
                                output_token_ids_ptr + req_idx * (max_spec_len + 1) + pos,
                                draft_token_id,
                            )
                        else:
                            rejected = True
                            recovered = tl.load(recovered_token_ids_ptr + token_idx)
                            tl.store(
                                output_token_ids_ptr + req_idx * (max_spec_len + 1) + pos,
                                recovered,
                            )
                    elif ENABLE_REDUCE_SAMPLING:
                        token_idx = start_idx + pos
                        draft_token_id = tl.load(draft_token_ids_ptr + token_idx)

                        if draft_token_id == -1:
                            rejected = True
                            token_id = tl.load(recovered_token_ids_ptr + token_idx)
                        else:
                            target_prob = 0.0
                            found = False

                            for v_offset in range(0, vocab_size, VOCAB_BLOCK_SIZE):
                                if not found:
                                    vocab_offsets = v_offset + tl.arange(0, VOCAB_BLOCK_SIZE)
                                    vocab_mask = vocab_offsets < vocab_size

                                    candidate_indices = tl.load(
                                        target_indices_ptr + token_idx * vocab_size + vocab_offsets,
                                        mask=vocab_mask,
                                        other=-1,
                                    )

                                    match_mask = candidate_indices == draft_token_id

                                    candidate_probs = tl.load(
                                        target_probs_ptr + token_idx * vocab_size + vocab_offsets,
                                        mask=vocab_mask,
                                        other=0.0,
                                    )

                                    current_match_prob = tl.sum(candidate_probs * match_mask, axis=0)
                                    if current_match_prob > 0.0:
                                        target_prob = current_match_prob
                                        found = True

                            if NO_DRAFT_PROBS:
                                draft_prob = 1
                            else:
                                draft_prob = tl.load(draft_probs_ptr + token_idx * global_vocab_size + draft_token_id)

                            uniform_prob = tl.load(uniform_probs_ptr + token_idx)

                            # Acceptance condition
                            if draft_prob > 0 and target_prob / draft_prob >= uniform_prob:
                                # Accept
                                token_id = draft_token_id
                            else:
                                # Reject - use recovered token
                                rejected = True
                                token_id = tl.load(recovered_token_ids_ptr + token_idx)

                        tl.store(output_token_ids_ptr + req_idx * (max_spec_len + 1) + pos, token_id)
                    else:
                        token_idx = start_idx + pos
                        draft_token_id = tl.load(draft_token_ids_ptr + token_idx)
                        if draft_token_id == -1:
                            rejected = True
                            token_id = tl.load(recovered_token_ids_ptr + token_idx)
                        else:
                            target_prob = tl.load(target_probs_ptr + token_idx * global_vocab_size + draft_token_id)
                            if NO_DRAFT_PROBS:
                                draft_prob = 1
                            else:
                                draft_prob = tl.load(draft_probs_ptr + token_idx * global_vocab_size + draft_token_id)
                            uniform_prob = tl.load(uniform_probs_ptr + token_idx)

                            if ENTROPY_VERIFY:
                                loop = (vocab_size + SUB_BLOCK - 1) // SUB_BLOCK
                                entropy = 0.0
                                for loop_i in range(loop):
                                    vocab_start = loop_i * SUB_BLOCK
                                    vocab_offset = vocab_start + tl.arange(0, SUB_BLOCK)
                                    vocab_mask = vocab_offset < vocab_size
                                    if NO_ORI_TARGET_PROBS:
                                        probs = tl.load(
                                            target_probs_ptr + token_idx * vocab_size + vocab_offset,
                                            vocab_mask,
                                            other=0,
                                        )
                                    else:
                                        probs = tl.load(
                                            ori_target_probs_ptr + token_idx * vocab_size + vocab_offset,
                                            vocab_mask,
                                            other=0,
                                        )
                                    log_probs = tl.log(probs + EPSILON)
                                    entropy_contrib = -probs * log_probs
                                    entropy += tl.sum(entropy_contrib)

                                exp_neg_entropy = tl.exp(-entropy * POSTERIOR_ALPHA)
                                threshold_by_entropy = exp_neg_entropy
                                threshold = tl.minimum(threshold_by_entropy, POSTERIOR_THRESHOLD)
                                _uniform_prob = threshold * uniform_prob
                            else:
                                _uniform_prob = uniform_prob
                            # NOTE(woosuk): While the draft probability should never be 0,
                            # we check it to avoid NaNs. If it happens to be 0, we reject.
                            if draft_prob > 0 and target_prob / draft_prob >= _uniform_prob:
                                # Accept.
                                token_id = draft_token_id
                            else:
                                # Reject. Use recovered token.
                                rejected = True
                                token_id = tl.load(recovered_token_ids_ptr + token_idx)
                        tl.store(output_token_ids_ptr + req_idx * (max_spec_len + 1) + pos, token_id)

            if not rejected:
                # If all tokens are accepted, append the bonus token.
                bonus_token_id = tl.load(bonus_token_ids_ptr + req_idx)
                tl.store(
                    output_token_ids_ptr + req_idx * (max_spec_len + 1) + num_draft_tokens,
                    bonus_token_id,
                )

RESULT = "/tmp/rs_randomsample_res.txt"


def append(line):
    with open(RESULT, "a") as f:
        f.write(line + "\n")


def done(stat, case, t0, msg=""):
    line = f"[{stat}] {case} elapsed={time.time() - t0:.1f}s {msg}"
    print(line, flush=True)
    append(line)
    sys.stdout.flush()
    if stat != "OK":
        raise AssertionError(line)


def check(name, cond, detail=""):
    if not cond:
        raise AssertionError(f"{name} failed {detail}")
    print(f"  check {name} PASS {detail}", flush=True)




def run_expand(x, cu, replace_from, replace_to, max_num_tokens, grid, block):
    # x: [batch_size] per-request src value; cu: [batch_size] closed-token counts
    batch_size = x.shape[0]
    ex = torch.full([int(cu[-1].cpu())], -1, dtype=torch.int32, device=cu.device)
    expand_kernel[(grid,)](
        ex, x, cu, replace_from, replace_to, batch_size,
        MAX_NUM_TOKENS=max_num_tokens, BLOCK_SIZE=block, num_warps=1,
    )
    return ex.cpu().tolist()


def case_random_sample():
    dev = "npu"
    def run(draft, tprob, uniform, recovered_val, vocab=64):
        out = torch.full([1, 2], -1, dtype=torch.int32, device=dev)
        cu = torch.tensor([1], dtype=torch.int64, device=dev)
        d = torch.tensor([draft], dtype=torch.int32, device=dev)
        tp = torch.full([1, vocab], 1e-6, dtype=torch.float32, device=dev)
        tp[0, draft] = tprob
        bonus = torch.tensor([7], dtype=torch.int32, device=dev)
        rec = torch.tensor([recovered_val], dtype=torch.int32, device=dev)
        unif = torch.tensor([uniform], dtype=torch.float32, device=dev)
        greedy = torch.zeros([1], dtype=torch.int32, device=dev)
        rejection_random_sample_kernel[(1,)](
            out, cu, d, None, tp, None, bonus, rec, unif, greedy,
            1, vocab, vocab, 1, None,
            None,
            NO_ORI_TARGET_PROBS=True, NO_DRAFT_PROBS=True,
            ENABLE_REDUCE_SAMPLING=False, SYNTHETIC_MODE=False,
            ENTROPY_VERIFY=False, BLOCK_SIZE=1, num_warps=1,
        )
        return out.cpu().tolist()

    # accept: target_prob(0.9)/1 >= 0.1 -> draft token, bonus at pos1
    got = run(5, 0.9, 0.1, 9)
    check("random accept", got == [[5, 7]], str(got))
    # reject: target_prob(0.01)/1 < 0.5 -> recovered at pos0, no bonus
    got2 = run(5, 0.01, 0.5, 9)
    check("random reject", got2 == [[9, -1]], str(got2))



def test_rejection_random_sample_kernel():
    if not torch.npu.is_available():
        raise AssertionError("npu NOT available, abort")
    print(f"triton={__import__('triton').__version__} torch={torch.__version__}", flush=True)
    t0 = time.time()
    case_random_sample()
    done("OK", "random_sample", t0)


if __name__ == "__main__":
    test_rejection_random_sample_kernel()

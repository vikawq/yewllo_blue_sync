# SPDX-License-Identifier: Apache-2.0
# SPDX-FileCopyrightText: Copyright contributors to the vLLM project

from __future__ import annotations
import torch
import torch_npu
import triton
import triton.language as tl


@triton.jit
def _fused_post_conv_kernel(
    mixed_qkv_ptr,
    a_ptr,
    b_ptr,
    A_log_ptr,
    dt_bias_ptr,
    q_ptr,
    k_ptr,
    v_ptr,
    g_ptr,
    beta_ptr,
    stride_x_tok,
    stride_a_tok,
    stride_b_tok,
    stride_q_tok,
    stride_k_tok,
    stride_v_tok,
    L,
    H: tl.constexpr,
    HV: tl.constexpr,
    K: tl.constexpr,
    V: tl.constexpr,
    APPLY_L2NORM: tl.constexpr,
    L2NORM_EPS: tl.constexpr,
    OUTPUT_G_EXP: tl.constexpr,
    SOFTPLUS_THRESHOLD: tl.constexpr,
    BLOCK_T: tl.constexpr,
    BK: tl.constexpr,
    BV: tl.constexpr,
):
    """Single fused kernel for post-conv1d preparation.

    Grid: (ceil(L, BLOCK_T), H + HV)
      - program_id(1) in [0, H):    Q/K head processing + l2norm
      - program_id(1) in [H, H+HV): V head processing + gating
    """
    i_tb = tl.program_id(0)
    i_head = tl.program_id(1)
    HK: tl.constexpr = H * K
    offs_t = i_tb * BLOCK_T + tl.arange(0, BLOCK_T)
    mask_t = offs_t < L
    if i_head < H:
        i_h = i_head
        offs_k = tl.arange(0, BK)
        mask_k = offs_k < K
        mask_2d = mask_t[:, None] & mask_k[None, :]
        q_offsets = offs_t[:, None] * stride_x_tok + i_h * K + offs_k[None, :]
        q_f32 = tl.load(mixed_qkv_ptr + q_offsets, mask=mask_2d, other=0).to(tl.float32)
        k_offsets = offs_t[:, None] * stride_x_tok + HK + i_h * K + offs_k[None, :]
        k_f32 = tl.load(mixed_qkv_ptr + k_offsets, mask=mask_2d, other=0).to(tl.float32)
        if APPLY_L2NORM:
            q_sq_sum = tl.sum(q_f32 * q_f32, axis=1)
            q_inv = 1.0 / tl.sqrt(q_sq_sum + L2NORM_EPS)
            q_f32 = q_f32 * q_inv[:, None]
            k_sq_sum = tl.sum(k_f32 * k_f32, axis=1)
            k_inv = 1.0 / tl.sqrt(k_sq_sum + L2NORM_EPS)
            k_f32 = k_f32 * k_inv[:, None]
        q_out = offs_t[:, None] * stride_q_tok + i_h * K + offs_k[None, :]
        tl.store(q_ptr + q_out, q_f32.to(q_ptr.dtype.element_ty), mask=mask_2d)
        k_out = offs_t[:, None] * stride_k_tok + i_h * K + offs_k[None, :]
        tl.store(k_ptr + k_out, k_f32.to(k_ptr.dtype.element_ty), mask=mask_2d)
    else:
        i_hv = i_head - H
        offs_v = tl.arange(0, BV)
        mask_v = offs_v < V
        mask_2d = mask_t[:, None] & mask_v[None, :]
        V_OFFSET: tl.constexpr = 2 * H * K
        v_offsets = (
            offs_t[:, None] * stride_x_tok + V_OFFSET + i_hv * V + offs_v[None, :]
        )
        v_vals = tl.load(mixed_qkv_ptr + v_offsets, mask=mask_2d, other=0)
        v_out = offs_t[:, None] * stride_v_tok + i_hv * V + offs_v[None, :]
        tl.store(v_ptr + v_out, v_vals, mask=mask_2d)
        A_log_val = tl.load(A_log_ptr + i_hv).to(tl.float32)
        dt_bias_val = tl.load(dt_bias_ptr + i_hv).to(tl.float32)
        a_offsets = offs_t * stride_a_tok + i_hv
        b_offsets = offs_t * stride_b_tok + i_hv
        a_vals = tl.load(a_ptr + a_offsets, mask=mask_t, other=0).to(tl.float32)
        b_vals = tl.load(b_ptr + b_offsets, mask=mask_t, other=0).to(tl.float32)
        x = a_vals + dt_bias_val
        sp = tl.where(x > 0, x + tl.log(1.0 + tl.exp(-x)), tl.log(1.0 + tl.exp(x)))
        sp = tl.where(x <= SOFTPLUS_THRESHOLD, sp, x)
        g_vals = -tl.exp(A_log_val) * sp
        if OUTPUT_G_EXP:
            g_vals = tl.exp(g_vals)
        beta_vals = tl.sigmoid(b_vals)
        gb_offsets = offs_t * HV + i_hv
        tl.store(g_ptr + gb_offsets, g_vals, mask=mask_t)
        tl.store(beta_ptr + gb_offsets, beta_vals, mask=mask_t)


def test_fused_post_conv_prep():
    generator = torch.Generator().manual_seed(20261009)
    rows, h, hv, k, v = (3, 8, 16, 128, 128)
    x, a, b = (
        torch.randn((rows, 4096), generator=generator).to(torch.float16),
        torch.randn((rows, hv), generator=generator).to(torch.float16),
        torch.randn((rows, hv), generator=generator).to(torch.float16),
    )
    alog = torch.randn((hv,), generator=generator).to(torch.float32) * 0.2
    bias = torch.randn((hv,), generator=generator).to(torch.float32) * 0.2
    a[0, 0] = 24.0
    a[0, 1] = -24.0
    x_npu, a_npu, b_npu = (x.npu(), a.npu(), b.npu())
    q_out = torch.empty((rows, h, k), dtype=x.dtype, device=x_npu.device)
    k_out = torch.empty_like(q_out)
    v_out = torch.empty((rows, hv, v), dtype=x.dtype, device=x_npu.device)
    g_out = torch.empty((rows, hv), dtype=torch.float32, device=x_npu.device)
    beta_out = torch.empty_like(g_out)
    _fused_post_conv_kernel[1, h + hv](
        mixed_qkv_ptr=x_npu,
        a_ptr=a_npu,
        b_ptr=b_npu,
        A_log_ptr=alog.npu(),
        dt_bias_ptr=bias.npu(),
        q_ptr=q_out,
        k_ptr=k_out,
        v_ptr=v_out,
        g_ptr=g_out,
        beta_ptr=beta_out,
        stride_x_tok=x_npu.stride(0),
        stride_a_tok=a_npu.stride(0),
        stride_b_tok=b_npu.stride(0),
        stride_q_tok=q_out.stride(0),
        stride_k_tok=k_out.stride(0),
        stride_v_tok=v_out.stride(0),
        L=rows,
        H=h,
        HV=hv,
        K=k,
        V=v,
        APPLY_L2NORM=True,
        L2NORM_EPS=1e-06,
        OUTPUT_G_EXP=False,
        SOFTPLUS_THRESHOLD=20.0,
        BLOCK_T=16,
        BK=triton.next_power_of_2(k),
        BV=triton.next_power_of_2(v),
        num_warps=4,
        num_stages=2,
    )
    result = (q_out, k_out, v_out, g_out, beta_out)
    q, kx, vx = x.split([h * k, h * k, hv * v], dim=-1)
    q = q.reshape(rows, h, k).float()
    kx = kx.reshape(rows, h, k).float()
    q = q * torch.rsqrt(q.square().sum(-1, keepdim=True) + 1e-06)
    kx = kx * torch.rsqrt(kx.square().sum(-1, keepdim=True) + 1e-06)
    g = -torch.exp(alog) * torch.nn.functional.softplus(a.float() + bias, threshold=20)
    refs = [q, kx, vx.reshape(rows, hv, v), g, torch.sigmoid(b.float())]
    for name, actual, reference in zip(["q", "k", "v", "g", "beta"], result, refs):
        actual_output = actual.cpu()
        expected_output = reference
        expected_output = expected_output.to(actual_output.dtype)
        torch.testing.assert_close(
            (actual_output).float(),
            (expected_output).float(),
            atol=0.0005 if actual.dtype == torch.float16 else 0.0001,
            rtol=0.002 if actual.dtype == torch.float16 else 0.0001,
            check_dtype=False,
        )
        assert (
            torch.isfinite(actual_output).all()
            and torch.isfinite(expected_output).all()
        )
    print("PASS: fused_post_conv_prep")


if __name__ == "__main__":
    test_fused_post_conv_prep()

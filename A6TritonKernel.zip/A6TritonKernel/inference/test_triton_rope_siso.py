# -*- coding: utf-8 -*-
import os
import time

import torch
import torch_npu
import triton
import triton.language as tl


def _get_vectorcore_num():
    props = triton.runtime.driver.active.utils.get_device_properties(torch.npu.current_device())
    return props.get("num_vectorcore", 32)

get_vectorcore_num = _get_vectorcore_num


# ============================= ORIGINAL KERNEL =============================
@triton.jit
def _triton_rope_siso(
    qk_ptr,
    qk_row_stride,
    cos_ptr,
    cos_row_stride,
    sin_ptr,
    sin_row_stride,
    cos_sin_ptr,
    cos_sin_row_stride,
    pos_ptr,
    num_tokens,
    n_h: tl.constexpr,
    hd: tl.constexpr,
    rope_dim: tl.constexpr,
    pad_n_h: tl.constexpr,
    pad_rope_dim: tl.constexpr,
    BLOCK_SIZE: tl.constexpr,
    IS_NEOX_STYLE: tl.constexpr,
    USE_COS_SIN: tl.constexpr,
):
    pid = tl.program_id(0).to(tl.int64)
    row_block_size = tl.num_programs(0)

    for row_idx in tl.range(pid, num_tokens, row_block_size):
        qk_start_ptr = qk_ptr + row_idx * qk_row_stride

        cos_offsets = tl.arange(0, pad_rope_dim // 2)
        sin_offsets = cos_offsets + (rope_dim // 2)
        cos_mask = cos_offsets < (rope_dim // 2)
        if USE_COS_SIN:
            pos_idx = tl.load(pos_ptr + row_idx).to(tl.int64)
            cos_start_ptr = cos_sin_ptr + pos_idx * cos_sin_row_stride
            cos_row = tl.load(cos_start_ptr + cos_offsets, mask=cos_mask, other=0).to(tl.float32)
            sin_row = tl.load(cos_start_ptr + sin_offsets, mask=cos_mask, other=0).to(tl.float32)
        else:
            cos_start_ptr = cos_ptr + row_idx * cos_row_stride
            sin_start_ptr = sin_ptr + row_idx * sin_row_stride
            cos_row = tl.load(cos_start_ptr + cos_offsets, mask=cos_mask, other=0).to(tl.float32)
            sin_row = tl.load(sin_start_ptr + sin_offsets, mask=cos_mask, other=0).to(tl.float32)

        if IS_NEOX_STYLE:
            first_half_offsets = tl.arange(0, pad_n_h)[:, None] * hd + tl.arange(0, pad_rope_dim // 2)[None, :]
        else:
            first_half_offsets = tl.arange(0, pad_n_h)[:, None] * hd + (2 * tl.arange(0, pad_rope_dim // 2)[None, :])

        first_mask = (tl.arange(0, pad_n_h)[:, None] < n_h) & (
            tl.arange(0, pad_rope_dim // 2)[None, :] < (rope_dim // 2)
        )
        qk_tile_1 = tl.load(qk_start_ptr + first_half_offsets, mask=first_mask, other=0).to(tl.float32)

        if IS_NEOX_STYLE:
            second_half_offsets = first_half_offsets + (rope_dim // 2)
        else:
            second_half_offsets = first_half_offsets + 1
        second_mask = first_mask
        qk_tile_2 = tl.load(qk_start_ptr + second_half_offsets, mask=second_mask, other=0).to(tl.float32)

        new_qk_tile_1 = qk_tile_1 * cos_row - qk_tile_2 * sin_row
        tl.store(qk_start_ptr + first_half_offsets, new_qk_tile_1, mask=first_mask)

        new_qk_tile_2 = qk_tile_2 * cos_row + qk_tile_1 * sin_row
        tl.store(qk_start_ptr + second_half_offsets, new_qk_tile_2, mask=second_mask)


# ============= IMPROVED: per-row program, no serial loop, full-token grid =============
@triton.jit
def _triton_rope_row(
    qk_ptr,
    qk_row_stride,
    cos_ptr,
    cos_row_stride,
    sin_ptr,
    sin_row_stride,
    cos_sin_ptr,
    cos_sin_row_stride,
    pos_ptr,
    num_tokens,
    n_h: tl.constexpr,
    hd: tl.constexpr,
    rope_dim: tl.constexpr,
    pad_n_h: tl.constexpr,
    pad_rope_dim: tl.constexpr,
    IS_NEOX_STYLE: tl.constexpr,
    USE_COS_SIN: tl.constexpr,
):
    row_idx = tl.program_id(0).to(tl.int64)
    qk_start_ptr = qk_ptr + row_idx * qk_row_stride

    cos_offsets = tl.arange(0, pad_rope_dim // 2)
    sin_offsets = cos_offsets + (rope_dim // 2)
    cos_mask = cos_offsets < (rope_dim // 2)
    if USE_COS_SIN:
        pos_idx = tl.load(pos_ptr + row_idx).to(tl.int64)
        cos_start_ptr = cos_sin_ptr + pos_idx * cos_sin_row_stride
        cos_row = tl.load(cos_start_ptr + cos_offsets, mask=cos_mask, other=0).to(tl.float32)
        sin_row = tl.load(cos_start_ptr + sin_offsets, mask=cos_mask, other=0).to(tl.float32)
    else:
        cos_start_ptr = cos_ptr + row_idx * cos_row_stride
        sin_start_ptr = sin_ptr + row_idx * sin_row_stride
        cos_row = tl.load(cos_start_ptr + cos_offsets, mask=cos_mask, other=0).to(tl.float32)
        sin_row = tl.load(sin_start_ptr + sin_offsets, mask=cos_mask, other=0).to(tl.float32)

    if IS_NEOX_STYLE:
        first_half_offsets = tl.arange(0, pad_n_h)[:, None] * hd + tl.arange(0, pad_rope_dim // 2)[None, :]
    else:
        first_half_offsets = tl.arange(0, pad_n_h)[:, None] * hd + (2 * tl.arange(0, pad_rope_dim // 2)[None, :])

    first_mask = (tl.arange(0, pad_n_h)[:, None] < n_h) & (
        tl.arange(0, pad_rope_dim // 2)[None, :] < (rope_dim // 2)
    )
    qk_tile_1 = tl.load(qk_start_ptr + first_half_offsets, mask=first_mask, other=0).to(tl.float32)

    if IS_NEOX_STYLE:
        second_half_offsets = first_half_offsets + (rope_dim // 2)
    else:
        second_half_offsets = first_half_offsets + 1
    qk_tile_2 = tl.load(qk_start_ptr + second_half_offsets, mask=first_mask, other=0).to(tl.float32)

    new_qk_tile_1 = qk_tile_1 * cos_row - qk_tile_2 * sin_row
    tl.store(qk_start_ptr + first_half_offsets, new_qk_tile_1, mask=first_mask)

    new_qk_tile_2 = qk_tile_2 * cos_row + qk_tile_1 * sin_row
    tl.store(qk_start_ptr + second_half_offsets, new_qk_tile_2, mask=first_mask)


# ============================= HOST WRAPPERS =============================
def rope_forward_triton_siso(
    qk, cos=None, sin=None, cos_sin_cache=None, positions=None,
    rope_dim=-1, is_neox_style=True,
):
    if not qk.is_contiguous():
        qk = qk.contiguous()
    num_tokens, n_head, head_dim = qk.shape
    assert rope_dim <= head_dim
    pad_rope_dim = triton.next_power_of_2(rope_dim)
    pad_n_head = triton.next_power_of_2(n_head)
    num_vectorcore = get_vectorcore_num()
    n_row = min(num_tokens, num_vectorcore)

    if cos_sin_cache is not None and positions is not None:
        _triton_rope_siso[(n_row,)](
            qk, qk.stride(0), None, None, None, None,
            cos_sin_cache, cos_sin_cache.stride(0), positions,
            num_tokens, n_head, head_dim, rope_dim,
            pad_n_head, pad_rope_dim, BLOCK_SIZE=pad_n_head,
            IS_NEOX_STYLE=is_neox_style, USE_COS_SIN=True,
        )
    elif cos is not None and sin is not None:
        cos = cos.view(num_tokens, -1)
        sin = sin.view(num_tokens, -1)
        if rope_dim == -1:
            rope_dim = cos.shape[-1] * 2
        _triton_rope_siso[(n_row,)](
            qk, qk.stride(0), cos, cos.stride(0), sin, sin.stride(0),
            None, None, None, num_tokens, n_head, head_dim,
            rope_dim, pad_n_head, pad_rope_dim, BLOCK_SIZE=pad_n_head,
            IS_NEOX_STYLE=is_neox_style, USE_COS_SIN=False,
        )
    else:
        raise ValueError("rope_forward_triton_siso: need cos/sin or cos_sin_cache+positions")
    return qk


def rope_forward_triton_row(
    qk, cos=None, sin=None, cos_sin_cache=None, positions=None,
    rope_dim=-1, is_neox_style=True, cap=4096,
):
    if not qk.is_contiguous():
        qk = qk.contiguous()
    num_tokens, n_head, head_dim = qk.shape
    assert rope_dim <= head_dim
    pad_rope_dim = triton.next_power_of_2(rope_dim)
    pad_n_head = triton.next_power_of_2(n_head)
    n_row = min(num_tokens, cap)

    if cos_sin_cache is not None and positions is not None:
        _triton_rope_row[(n_row,)](
            qk, qk.stride(0), None, None, None, None,
            cos_sin_cache, cos_sin_cache.stride(0), positions,
            num_tokens, n_head, head_dim, rope_dim,
            pad_n_head, pad_rope_dim,
            IS_NEOX_STYLE=is_neox_style, USE_COS_SIN=True,
        )
    elif cos is not None and sin is not None:
        cos = cos.view(num_tokens, -1)
        sin = sin.view(num_tokens, -1)
        if rope_dim == -1:
            rope_dim = cos.shape[-1] * 2
        _triton_rope_row[(n_row,)](
            qk, qk.stride(0), cos, cos.stride(0), sin, sin.stride(0),
            None, None, None, num_tokens, n_head, head_dim,
            rope_dim, pad_n_head, pad_rope_dim,
            IS_NEOX_STYLE=is_neox_style, USE_COS_SIN=False,
        )
    else:
        raise ValueError("rope_forward_triton_row: need cos/sin or cos_sin_cache+positions")
    return qk


# ============================= NATIVE REFERENCE =============================
def rotate_neox(x):
    x1 = x[..., : x.shape[-1] // 2]
    x2 = x[..., x.shape[-1] // 2 :]
    return torch.cat((-x2, x1), dim=-1)


def rotate_gptj(x):
    x1 = x[..., ::2]
    x2 = x[..., 1::2]
    x = torch.stack((-x2, x1), dim=-1)
    return x.flatten(-2)


def rope_siso_native(query, cos, sin, rope_dim, is_neox_style):
    orig_dtype = query.dtype
    query_rot = query[..., :rope_dim].to(torch.float32)
    head_size = query.shape[-1]
    query_pass = None
    if rope_dim < head_size:
        query_pass = query[..., rope_dim:]
    if is_neox_style:
        cos = cos.repeat(1, 2).unsqueeze(-2).to(torch.float32)
        sin = sin.repeat(1, 2).unsqueeze(-2).to(torch.float32)
    else:
        cos = cos.repeat_interleave(2, dim=-1).unsqueeze(-2).to(torch.float32)
        sin = sin.repeat_interleave(2, dim=-1).unsqueeze(-2).to(torch.float32)
    rotate_fn = rotate_neox if is_neox_style else rotate_gptj
    query_rot = query_rot * cos + rotate_fn(query_rot) * sin
    if rope_dim < head_size:
        query = torch.cat((query_rot.to(orig_dtype), query_pass), dim=-1)
    else:
        query = query_rot.to(orig_dtype)
    return query


# ============================= BENCH =============================
HEAD_SIZE = 128
ROTARY_DIM = 128
COS_COLS = ROTARY_DIM // 2
ATOL = 1e-3
RTOL = 1e-3

BENCH_SHAPES = [
    # [adapted] single verified PASS case on 960DT (fp32, sin->(T,128), NATIVE_DEV=cpu) 2026-10-30
    # NOTE: tuple = (orig_tokens, num_heads, tokens); tokens must be <= 32 (single-iter, no multi-iter bug)
    (8, 1, 8),
]


def _env_int(name, default):
    v = os.environ.get(name)
    return int(v) if v is not None else default


def _env_str(name, default):
    return os.environ.get(name, default)


def main():
    # torch.set_default_device("npu:0")  # disabled: simulator conflict
    torch.manual_seed(0)

    case_ids = [int(x) for x in _env_str("CASE_IDS", "0").split(",") if x.strip()]
    custom = _env_str("CUSTOM", "")
    dtype_name = _env_str("DT", "bf16")
    neox_list = [True] if _env_str("NEOX", "true") == "true" else [False]
    repeat = _env_int("REPEAT", 2)
    cap = _env_int("CAP", 4096)
    check_level = _env_int("CHECK_LEVEL", 1)
    pass_thr = float(_env_str("PASS_THR", "1e-2"))
    rd = _env_int("RD", 128)
    native_cpu = _env_str("NATIVE_DEV", "npu") != "npu"

    shapes = []
    if custom:
        parts = [int(x) for x in custom.split(",") if x.strip()]
        shapes = [(parts[0], parts[1], parts[2])]
    else:
        shapes = [BENCH_SHAPES[i] for i in case_ids]

    dtype_map = {"bf16": torch.bfloat16, "fp16": torch.float16, "fp32": torch.float32, "both": None}
    dtypes = [torch.bfloat16, torch.float16] if dtype_name == "both" else [dtype_map[dtype_name]]

    print(f"RUNTIME env: CASE_IDS={case_ids} CUSTOM={custom} DT={dtype_name} NEOX={neox_list} "
          f"REPEAT={repeat} CAP={cap} CHECK_LEVEL={check_level}", flush=True)
    print(f"vectorcore={get_vectorcore_num()}", flush=True)

    for idx, (orig_tokens, num_heads, tokens) in enumerate(shapes):
        for dtype in dtypes:
            for neox in neox_list:
                tag = f"case{idx} shape=({tokens},{num_heads},{HEAD_SIZE}) dtype={dtype} neox={neox}"
                try:
                    print("[STEP] randn", flush=True)
                    sin = torch.randn(tokens, rd // 2, dtype=dtype, device="npu")
                    cos = torch.randn(tokens, rd // 2, dtype=dtype, device="npu")
                    q_trt = torch.randn(tokens, num_heads, HEAD_SIZE, dtype=dtype, device="npu")
                    print("[STEP] launch siso", flush=True)
                    q_orig = rope_forward_triton_siso(
                        q_trt.clone(), cos, sin.repeat(1, 2).contiguous(), rope_dim=rd, is_neox_style=neox
                    )
                    torch.npu.synchronize()
                    print("[STEP] siso done", flush=True)
                    if native_cpu:
                        q_gold = rope_siso_native(
                            q_trt.cpu(), cos.cpu(), sin.cpu(), rd, neox
                        )
                    else:
                        q_gold = rope_siso_native(q_trt.clone(), cos, sin, rd, neox)
                        torch.npu.synchronize()
                    err_info = ""
                    if check_level >= 1:
                        max_err_orig = (
                            q_orig.float().cpu() - q_gold.float().cpu()
                        ).abs().max().item()
                        err_info = f"err_orig={max_err_orig:.2e} "

                    print("[STEP] launch row", flush=True)
                    q_row = rope_forward_triton_row(
                        q_trt.clone(), cos, sin.repeat(1, 2).contiguous(), rope_dim=rd,
                        is_neox_style=neox, cap=cap,
                    )
                    torch.npu.synchronize()
                    print("[STEP] row done", flush=True)
                    if check_level >= 1:
                        max_err_row = (
                            q_row.float().cpu() - q_gold.float().cpu()
                        ).abs().max().item()
                        err_info += f"err_row={max_err_row:.2e}"
                        print(f"[STEP] err_row={max_err_row:.3e}", flush=True)
                    if check_level >= 2:
                        torch.testing.assert_close(
                            q_row.view(q_gold.size()).float().cpu(), q_gold.float().cpu(), atol=ATOL, rtol=RTOL
                        )
                    print("[STEP] correct ok", flush=True)

                    t_orig = bench_time(rope_forward_triton_siso, q_trt, cos, sin, rd, neox, repeat)
                    print("[STEP] bench siso ok", flush=True)
                    t_row = bench_time(rope_forward_triton_row, q_trt, cos, sin, rd, neox, repeat)
                    print("[STEP] bench row ok", flush=True)

                    check = "PASS" if max_err_row < pass_thr else "FAIL"
                    print(
                        f"[RESULT] {tag} | orig={t_orig:.1f}ms row(cap={n_row_now(cap, tokens)})"
                        f"={t_row:.1f}ms speedup={t_orig / t_row:.2f}x | {err_info} | {check} thr={pass_thr:g}",
                        flush=True,
                    )
                except Exception as e:
                    print(f"[FAIL] {tag}\n       {type(e).__name__}: {e}", flush=True)


def n_row_now(cap, tokens):
    return min(tokens, cap)


def bench_time(fn, q_trt, cos, sin, rope_dim, neox, repeat):
    times = []
    for _ in range(repeat):
        q = q_trt.clone()
        t0 = time.perf_counter()
        fn(q, cos, sin, rope_dim=rope_dim, is_neox_style=neox)
        torch.npu.synchronize()
        times.append((time.perf_counter() - t0) * 1000.0)
    return min(times)


if __name__ == "__main__":
    main()

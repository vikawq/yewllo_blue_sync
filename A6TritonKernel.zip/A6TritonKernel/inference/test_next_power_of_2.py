import triton
from triton import constexpr_function


@constexpr_function
def next_power_of_2(n: int):
    """Return the smallest power of 2 greater than or equal to n"""
    n -= 1
    n |= n >> 1
    n |= n >> 2
    n |= n >> 4
    n |= n >> 8
    n |= n >> 16
    n |= n >> 32
    n += 1
    return n


def test_next_power_of_2():
    inputs = {
        0,
        1,
        2,
        3,
        5,
        7,
        8,
        9,
        31,
        32,
        33,
        63,
        64,
        65,
        127,
        128,
        129,
        4095,
        4096,
        4097,
        248320,
    }
    for bit in range(1, 64):
        inputs.update(((1 << bit) - 1, 1 << bit, (1 << bit) + 1))
    for n in sorted(inputs):
        expected = 0 if n == 0 else 1 << (n - 1).bit_length()
        assert triton.next_power_of_2(n) == next_power_of_2(n) == expected
    print("PASS: next_power_of_2")


if __name__ == "__main__":
    test_next_power_of_2()

# -*- coding: utf-8 -*-
import os
import sys
import types
import time
import traceback

os.environ.setdefault("TRITON_BACKENDS_IN_TREE", "1")
os.environ.setdefault("TRITON_BACKEND", "opentile")
os.environ.setdefault("TRITON_ALWAYS_COMPILE", "1")

import triton
import triton.language as tl
import torch

_vllm_utils = types.ModuleType("vllm.triton_utils")
_vllm_utils.tl = tl
_vllm_utils.triton = triton
_vllm_utils.tldevice = types.SimpleNamespace(
    fast_dividef=lambda x, y: x / y,
    fast_expf=tl.exp,
    fast_logf=tl.log,
    fast_log2f=tl.log2,
)
_vllm_pkg = types.ModuleType("vllm")
_vllm_pkg.triton_utils = _vllm_utils
sys.modules.setdefault("vllm", _vllm_pkg)
sys.modules["vllm.triton_utils"] = _vllm_utils
sys.modules["vllm"].triton_utils = _vllm_utils

_math_pkg = types.ModuleType("vllm.utils")
sys.modules.setdefault("vllm.utils", _math_pkg)
_math_mod = types.ModuleType("vllm.utils.math_utils")
sys.modules["vllm.utils.math_utils"] = _math_mod


def next_power_of_2(n: int) -> int:
    if n <= 0:
        return 1
    return 1 << (n - 1).bit_length()


VECTORCORE_NUM = 32


def get_vectorcore_num() -> int:
    return VECTORCORE_NUM


@triton.jit
def get_element(data, index):
    idx = index[0]
    n: tl.constexpr = data.shape[0]
    mask = tl.arange(0, n) == idx
    return tl.sum(tl.where(mask, data.to(tl.int32), 0))


@triton.jit(do_not_specialize=["max_spec_len"])
def bonus_renew(
    bonus_token_ids_ptr,
    position,
    output_token_ids_ptr,
    max_spec_len,
    num_tokens1,
):
    bonus_token_id = tl.load(bonus_token_ids_ptr + position)
    tl.store(output_token_ids_ptr + position * (max_spec_len + 1) + num_tokens1, bonus_token_id)


@triton.jit(do_not_specialize=["vec_len", "max_spec_len"])
def rejection_greedy_sample_triton(
    output_token_ids_ptr,  # [batch_size, max_spec_len + 1]
    cu_num_draft_tokens_ptr,  # [batch_size]
    draft_token_ids_ptr,  # [num_tokens]
    target_argmax_ptr,  # [num_tokens]
    bonus_token_ids_ptr,  # [batch_size]
    is_greedy_ptr,  # [batch_size] or None
    vec_len,
    max_spec_len,
    uniform_probs_ptr,  # [num_tokens] or None (synthetic only)
    synthetic_conditional_rates_ptr,  # [num_speculative_tokens] or None
    SYNTHETIC_MODE: tl.constexpr,
    BLOCK_SIZE: tl.constexpr,
):
    block_idx = tl.program_id(0)
    offset = block_idx * BLOCK_SIZE + tl.arange(0, BLOCK_SIZE)
    mask = offset < vec_len

    if is_greedy_ptr is None:
        is_greedy_mask = mask
    else:
        is_greedy = tl.load(is_greedy_ptr + offset, mask=mask, other=0)
        is_greedy_mask = mask & (is_greedy != 0)

    start_idx = tl.load(cu_num_draft_tokens_ptr + offset - 1, mask=is_greedy_mask & (offset > 0), other=0)
    end_idx = tl.load(cu_num_draft_tokens_ptr + offset, is_greedy_mask, other=0)
    num_draft_tokens = end_idx - start_idx

    for pos in tl.range(0, BLOCK_SIZE):
        num_tokens1 = get_element(num_draft_tokens, (pos,))
        rejected = False
        start_idx1 = get_element(start_idx, (pos,))
        is_greedy_mask1 = get_element(is_greedy_mask, (pos,))
        position = block_idx * BLOCK_SIZE + pos
        for i in range(num_tokens1):
            if not rejected:
                draft_token_id = tl.load(draft_token_ids_ptr + start_idx1 + i)
                target_argmax_id = tl.load(target_argmax_ptr + start_idx1 + i)
                if SYNTHETIC_MODE:
                    uniform_prob = tl.load(uniform_probs_ptr + start_idx1 + i)
                    rate = tl.load(synthetic_conditional_rates_ptr + i)
                    accepted = (uniform_prob < rate) & (draft_token_id >= 0)
                    if accepted:
                        tl.store(
                            output_token_ids_ptr + position * (max_spec_len + 1) + i,
                            draft_token_id,
                        )
                    else:
                        tl.store(
                            output_token_ids_ptr + position * (max_spec_len + 1) + i,
                            target_argmax_id,
                        )
                        rejected = True
                else:
                    tl.store(
                        output_token_ids_ptr + position * (max_spec_len + 1) + i,
                        target_argmax_id,
                    )
                    if draft_token_id != target_argmax_id:
                        rejected = True

        if not rejected and is_greedy_mask1:
            bonus_renew(
                bonus_token_ids_ptr,
                position,
                output_token_ids_ptr,
                max_spec_len,
                num_tokens1,
            )


RESULT = "/tmp/rs_greedy_full_res.txt"


def append(line):
    with open(RESULT, "a") as f:
        f.write(line + "\n")


def done(stat, case, t0, msg=""):
    line = f"[{stat}] {case} elapsed={time.time() - t0:.1f}s {msg}"
    print(line, flush=True)
    append(line)
    sys.stdout.flush()
    if stat != "OK":
        raise AssertionError(line)


def check(name, cond, detail=""):
    if not cond:
        raise AssertionError(f"{name} failed {detail}")
    print(f"  check {name} PASS {detail}", flush=True)


def run_full(out, cu, draft, argmax, bonus, is_greedy, max_spec_len, grid, block):
    rejection_greedy_sample_triton[(grid,)](
        out, cu, draft, argmax, bonus, is_greedy,
        out.shape[0], max_spec_len, None, None,
        SYNTHETIC_MODE=False, BLOCK_SIZE=block, num_warps=1,
    )


def ref_full(draft_lists, argmax_lists, bonus, is_greedy, max_spec_len):
    """
    参考实现，对齐 kernel 语义：
    - is_greedy=0 的请求被 kernel 的 is_greedy_mask 跳过，输出保持 -1；
    - is_greedy=1 的请求走 accept/reject 逻辑，全部 accept 时在位置 n 写 bonus。
    """
    batch = len(draft_lists)
    out = [[-1] * (max_spec_len + 1) for _ in range(batch)]
    for b in range(batch):
        if not is_greedy[b]:
            continue
        n = len(draft_lists[b])
        rejected = False
        for i in range(n):
            d = draft_lists[b][i]
            a = argmax_lists[b][i]
            if rejected:
                continue
            out[b][i] = a
            if d != a:
                rejected = True
        if not rejected:
            if n <= max_spec_len:
                out[b][n] = bonus[b]
    return out


def case_greedy_full():
    dev = "npu"
    max_spec_len = 3
    batch = 3

    # b0: all accepted -> draft 41,42,43 -> bonus at pos3
    # b1: draft [5, 9] with argmax [5, 9] accepted both -> bonus at pos2
    # b2: draft [7, 8], argmax [7, 100] -> accept pos0(7), reject pos1 -> out[1]=100, no bonus
    #
    # cu 按 kernel 契约：cu[0] 是第一个请求的结束位置，
    # cu[i] 是第 i 个请求的结束位置（kernel 用 cu[offset-1] 到 cu[offset]）。
    cu = torch.tensor([3, 5, 7], dtype=torch.int64, device=dev)
    draft = torch.tensor([41, 42, 43, 5, 9, 7, 8], dtype=torch.int32, device=dev)
    argmax = torch.tensor([41, 42, 43, 5, 9, 7, 100], dtype=torch.int64, device=dev)
    bonus = torch.tensor([77, 88, 99], dtype=torch.int32, device=dev)
    greedy = torch.tensor([1, 1, 1], dtype=torch.int32, device=dev)
    out = torch.full([batch, max_spec_len + 1], -1, dtype=torch.int32, device=dev)

    run_full(out, cu, draft, argmax, bonus, greedy, max_spec_len, 1, 16)
    got = out.cpu().tolist()

    exp = ref_full(
        [[41, 42, 43], [5, 9], [7, 8]],
        [[41, 42, 43], [5, 9], [7, 100]],
        [77, 88, 99], [1, 1, 1], max_spec_len,
    )
    check("greedy-full multi-accept/reject", got == exp, f"got={got} exp={exp}")

    # 非 greedy：kernel 的 is_greedy_mask 会把 is_greedy=0 的请求整个跳过，
    # 输出保持 -1。ref_full 对非 greedy 请求也输出 -1，与 kernel 行为一致。
    greedy0 = torch.zeros([batch], dtype=torch.int32, device=dev)
    out.zero_().sub_(1)
    run_full(out, cu, draft, argmax, bonus, greedy0, max_spec_len, 1, 16)
    got2 = out.cpu().tolist()
    exp2 = ref_full(
        [[41, 42, 43], [5, 9], [7, 8]],
        [[41, 42, 43], [5, 9], [7, 100]],
        [77, 88, 99], [0, 0, 0], max_spec_len,
    )
    check("greedy-full no-bonus", got2 == exp2, f"got={got2} exp={exp2}")


def test_rejection_greedy_sample_triton():
    if not torch.npu.is_available():
        raise AssertionError("npu NOT available, abort")
    print(f"triton={__import__('triton').__version__} torch={torch.__version__}", flush=True)
    t0 = time.time()
    case_greedy_full()
    done("OK", "greedy_full", t0)


if __name__ == "__main__":
    test_rejection_greedy_sample_triton()
import os
import sys

import torch
import torch_npu
import triton
import triton.language as tl


@triton.heuristics({"IS_VARLEN": lambda args: args["cu_seqlens"] is not None})
@triton.jit(do_not_specialize=["T", "H", "Hg", "K", "V"])
def recompute_w_u_fwd_kernel(
    k,
    v,
    beta,
    w,
    u,
    A,
    g,
    cu_seqlens,
    chunk_indices,
    T,
    H,
    Hg,
    K,
    V,
    BT: tl.constexpr,
    BK: tl.constexpr,
    BV: tl.constexpr,
    IS_VARLEN: tl.constexpr,
):
    T_max = T
    i_t_o = tl.program_id(0)

    for i_bh in range(H):
        i_b, i_h = i_bh // H, i_bh % H
        if IS_VARLEN:
            i_n, i_t = (
                tl.load(chunk_indices + i_t_o * 2).to(tl.int32),
                tl.load(chunk_indices + i_t_o * 2 + 1).to(tl.int32),
            )
            bos, eos = tl.load(cu_seqlens + i_n).to(tl.int32), tl.load(cu_seqlens + i_n + 1).to(tl.int32)
            T = eos - bos
        else:
            bos, eos = i_b * T, i_b * T + T

        offs_t = tl.arange(0, BT)
        global_offs_t = i_t * BT + offs_t
        mask_t = global_offs_t < T

        offs_t_2d = global_offs_t[:, None]
        offs_bt = tl.arange(0, BT)[None, :]
        ptr_A = A + (bos * H + i_h) * BT + offs_t_2d * (H * BT) + offs_bt * 1
        mask_A = mask_t[:, None]
        b_A = tl.load(ptr_A, mask=mask_A, other=0.0).to(tl.float32)

        ptr_g = g + bos + i_h * T_max + global_offs_t
        b_g = tl.exp(tl.load(ptr_g, mask=mask_t, other=0.0)).to(tl.float32)

        ptr_beta = beta + bos + i_h * T_max + global_offs_t
        b_beta = tl.load(ptr_beta, mask=mask_t, other=0.0).to(tl.float32)

        for i_v in range(tl.cdiv(V, BV)):
            offs_v = i_v * BV + tl.arange(0, BV)[None, :]
            mask_v = (mask_t[:, None]) & (offs_v < V)

            ptr_v = v + (bos * H + i_h) * V + offs_t_2d * (H * V) + offs_v * 1
            b_v = tl.load(ptr_v, mask=mask_v, other=0.0).to(tl.float32)

            b_vb = b_v * b_beta[:, None]
            b_u = tl.dot(b_A, b_vb, allow_tf32=False)

            ptr_u = u + (bos * H + i_h) * V + offs_t_2d * (H * V) + offs_v * 1
            tl.store(ptr_u, b_u.to(ptr_u.dtype.element_ty), mask=mask_v)

        for i_k in range(tl.cdiv(K, BK)):
            offs_k = i_k * BK + tl.arange(0, BK)[None, :]
            mask_k = (mask_t[:, None]) & (offs_k < K)
            ptr_k = k + (bos * Hg + i_h // (H // Hg)) * K + offs_t_2d * (Hg * K) + offs_k * 1
            b_k = tl.load(ptr_k, mask=mask_k, other=0.0).to(tl.float32)

            b_kb = b_k * b_beta[:, None] * b_g[:, None]
            b_w = tl.dot(b_A, b_kb)

            ptr_w = w + (bos * H + i_h) * K + offs_t_2d * (H * K) + offs_k * 1
            tl.store(ptr_w, b_w.to(ptr_w.dtype.element_ty), mask=mask_k)


def test_recompute_w_u_fwd_kernel():
    B, T, H, Hg, K, V, BT, BK, BV = 1, 40, 4, 2, 32, 32, 16, 16, 16

    n_seq = 2
    seglen = T // n_seq
    cu_seqlens = torch.arange(n_seq + 1, dtype=torch.int32, device="npu") * seglen
    n_chunk = (seglen + BT - 1) // BT
    chunk_indices = torch.tensor(
        [[s, c] for s in range(n_seq) for c in range(n_chunk)], dtype=torch.int32, device="npu"
    )
    NT = len(chunk_indices)

    torch.manual_seed(0)
    k = (torch.randn(B, T, Hg, K, device="npu", dtype=torch.float16) * 0.5)
    v = (torch.randn(B, T, H, V, device="npu", dtype=torch.float16) * 0.5)
    beta = torch.rand(B, T, H, device="npu", dtype=torch.float32) * 0.5
    g_cumsum = torch.linspace(0, 0.5, B * T * H, device="npu", dtype=torch.float32).reshape(B, T, H)
    A = torch.randn(B, T, H, BT, device="npu", dtype=torch.float16) * 0.5

    beta_k = beta.transpose(1, 2).contiguous()
    g_k = g_cumsum.transpose(1, 2).contiguous()

    w = torch.zeros(B, T, H, K, device="npu", dtype=torch.float16)
    u = torch.zeros(B, T, H, V, device="npu", dtype=torch.float16)

    print("=== launch kernel ===")
    print(f"shapes: k={tuple(k.shape)} v={tuple(v.shape)} A={tuple(A.shape)}")
    print(f"beta_k={tuple(beta_k.shape)} g_k={tuple(g_k.shape)}")
    print(f"cu_seqlens={cu_seqlens.cpu().tolist()}")
    print(f"chunk_indices={chunk_indices.cpu().tolist()} NT={NT}")

    recompute_w_u_fwd_kernel[(NT, B)](
        k=k,
        v=v,
        beta=beta_k,
        w=w,
        u=u,
        A=A,
        g=g_k,
        cu_seqlens=cu_seqlens,
        chunk_indices=chunk_indices,
        T=T,
        H=H,
        Hg=Hg,
        K=K,
        V=V,
        BT=BT,
        BK=BK,
        BV=BV,
        num_warps=4,
        num_stages=3,
    )
    torch.npu.synchronize()
    print("kernel done, w[0,0,0,:4]=", w.cpu()[0, 0, 0, :4].tolist())
    print("kernel done, u[0,0,0,:4]=", u.cpu()[0, 0, 0, :4].tolist())

    print("=== reference check ===")
    A_cpu = A.float().cpu()
    k_cpu = k.float().cpu()
    v_cpu = v.float().cpu()
    beta_cpu = beta.float().cpu()
    g_cpu = g_cumsum.float().cpu()
    w_ref = torch.zeros(B, T, H, K, dtype=torch.float32)
    u_ref = torch.zeros(B, T, H, V, dtype=torch.float32)
    ci = chunk_indices.cpu().tolist()
    cu = cu_seqlens.cpu().tolist()

    try:
        for i_t_o in range(NT):
            i_n, i_t = ci[i_t_o]
            bos, eos = cu[i_n], cu[i_n + 1]
            T_loc = eos - bos
            if i_t * BT >= T_loc:
                continue
            n = min(T_loc - i_t * BT, BT)
            rows = bos + i_t * BT + torch.arange(n)
            for i_h in range(H):
                hg = i_h // (H // Hg)
                bt = bos + i_t * BT + torch.arange(BT)
                inb = bt < eos
                bt_safe = bt.clamp(max=T - 1).long()
                beta_h = beta_cpu[0, bt_safe, i_h] * inb.float()
                g_h = torch.exp(g_cpu[0, bt_safe, i_h] * inb.float())
                k_h = k_cpu[0, bt_safe, hg, :] * inb[:, None].float()
                v_h = v_cpu[0, bt_safe, i_h, :] * inb[:, None].float()
                u_ref[0, rows, i_h, :] = A_cpu[0, rows, i_h, :] @ (v_h * beta_h[:, None])
                w_ref[0, rows, i_h, :] = A_cpu[0, rows, i_h, :] @ (k_h * beta_h[:, None] * g_h[:, None])
    except Exception:
        import traceback

        traceback.print_exc()
        return 1

    w_npu = w.cpu().float()
    u_npu = u.cpu().float()
    dw = (w_npu - w_ref).abs()
    du = (u_npu - u_ref).abs()
    print(f"w max_abs_diff={dw.max().item():.6e}")
    print(f"u max_abs_diff={du.max().item():.6e}")
    print(f"w allclose={torch.allclose(w_npu, w_ref, atol=1e-2, rtol=1e-2)}")
    print(f"u allclose={torch.allclose(u_npu, u_ref, atol=1e-2, rtol=1e-2)}")
    assert dw.max().item() < 1e-2, f"w diff too large: {dw.max().item():.6e}"
    assert du.max().item() < 1e-2, f"u diff too large: {du.max().item():.6e}"
    print("RESULT: PASS")


if __name__ == "__main__":
    test_recompute_w_u_fwd_kernel()

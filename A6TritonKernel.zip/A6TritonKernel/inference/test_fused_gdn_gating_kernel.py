import os
import sys

import torch
import torch_npu
import triton
import triton.language as tl


@triton.jit(do_not_specialize=["seq_len", "NUM_HEADS", "NUM_BATCHES", "beta", "threshold", "ROW_ITER"])
def fused_gdn_gating_kernel(
    g,
    beta_output,
    A_log,
    a,
    b,
    dt_bias,
    seq_len,
    NUM_HEADS,
    NUM_BATCHES,
    beta,
    threshold,
    BLK_HEADS: tl.constexpr,
    BLK_BATCHES: tl.constexpr,
    ROW_ITER,
):
    i_b, i_s = tl.program_id(0), tl.program_id(1)
    COL_ITER = tl.cdiv(NUM_HEADS, BLK_HEADS)

    for row_idx in range(0, ROW_ITER):
        batch_off = i_b * ROW_ITER * BLK_BATCHES + row_idx * BLK_BATCHES + tl.arange(0, BLK_BATCHES)

        for col_idx in range(0, COL_ITER):
            head_off = col_idx * BLK_HEADS + tl.arange(0, BLK_HEADS)

            off = batch_off[:, None] * seq_len * NUM_HEADS + i_s * NUM_HEADS + head_off[None, :]
            head_mask = head_off < NUM_HEADS
            mask = head_mask[None, :] & (batch_off[:, None] < NUM_BATCHES)

            blk_A_log = tl.load(A_log + head_off, mask=head_mask)
            blk_a = tl.load(a + off, mask=mask)
            blk_b = tl.load(b + off, mask=mask)
            blk_bias = tl.load(dt_bias + head_off, mask=head_mask)

            x = blk_a.to(tl.float32) + blk_bias.to(tl.float32)[None, :]
            softplus_x = tl.where(beta * x <= threshold, (1 / beta) * tl.log(1 + tl.exp(beta * x)), x)

            blk_g = -tl.exp(blk_A_log.to(tl.float32)) * softplus_x
            tl.store(g + off, blk_g.to(g.dtype.element_ty), mask=mask)

            blk_beta_output = tl.sigmoid(blk_b.to(tl.float32))
            tl.store(beta_output + off, blk_beta_output.to(beta_output.dtype.element_ty), mask=mask)


def test_fused_gdn_gating_kernel():
    batch = 40
    num_heads = 32
    seq_len = 1
    progs = 4
    beta = 1.0
    threshold = 20.0
    BLK_HEADS = 8
    BLK_BATCHES = 64
    ROW_ITER = 1

    torch.manual_seed(0)
    a = torch.rand(batch, num_heads, device="npu", dtype=torch.float32) * 18.0
    b = -torch.randn(batch, num_heads, device="npu", dtype=torch.float32).abs() * 2.0
    dt_bias = torch.rand(num_heads, device="npu", dtype=torch.float32) * 1.0
    A_log = torch.randn(num_heads, device="npu", dtype=torch.float32).abs() * 0.3

    g = torch.empty(1, batch, num_heads, device="npu", dtype=torch.float32)
    beta_output = torch.empty(1, batch, num_heads, device="npu", dtype=b.dtype)

    print("=== launch kernel ===")
    print(f"batch={batch} num_heads={num_heads} seq_len={seq_len} progs={progs}")
    print(f"a={tuple(a.shape)} b={tuple(b.shape)} dt_bias={tuple(dt_bias.shape)} A_log={tuple(A_log.shape)}")
    print(f"grid=({progs}, {seq_len}) COL_ITER={triton.cdiv(num_heads, BLK_HEADS)} ROW_ITER={ROW_ITER}")

    fused_gdn_gating_kernel[(progs, seq_len)](
        g,
        beta_output,
        A_log,
        a,
        b,
        dt_bias,
        seq_len,
        num_heads,
        batch,
        beta,
        threshold,
        BLK_HEADS=BLK_HEADS,
        BLK_BATCHES=BLK_BATCHES,
        ROW_ITER=ROW_ITER,
    )
    torch.npu.synchronize()
    print("kernel done")
    print("g[0,0,:4]=", g.cpu()[0, 0, :4].tolist())
    print("beta_output[0,0,:4]=", beta_output.cpu()[0, 0, :4].tolist())

    print("=== reference check ===")
    a_cpu = a.cpu()
    b_cpu = b.cpu()
    bias_cpu = dt_bias.cpu()
    A_log_cpu = A_log.cpu()

    x_ref = a_cpu + bias_cpu[None, :]
    softplus_ref = torch.where(
        beta * x_ref <= threshold, (1 / beta) * torch.log1p(torch.exp(torch.clamp(beta * x_ref, max=threshold))), x_ref
    )
    g_ref = -torch.exp(A_log_cpu)[None, :] * softplus_ref
    beta_out_ref = torch.sigmoid(b_cpu)

    g_npu = g.cpu()
    bo_npu = beta_output.cpu().float()
    dg = (g_npu - g_ref).abs()
    dbo = (bo_npu - beta_out_ref).abs()
    print(f"g max_abs_diff={dg.max().item():.6e}")
    print(f"beta_output max_abs_diff={dbo.max().item():.6e}")
    print(f"g allclose={torch.allclose(g_npu, g_ref, atol=1e-2, rtol=1e-2)}")
    print(f"beta_output allclose={torch.allclose(bo_npu, beta_out_ref, atol=1e-2, rtol=1e-2)}")
    assert dg.max().item() < 1e-2, f"g diff too large: {dg.max().item():.6e}"
    assert dbo.max().item() < 1e-2, f"beta_output diff too large: {dbo.max().item():.6e}"
    print("RESULT: PASS")


if __name__ == "__main__":
    test_fused_gdn_gating_kernel()

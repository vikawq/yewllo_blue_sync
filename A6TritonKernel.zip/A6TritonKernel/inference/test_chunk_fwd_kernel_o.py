import torch
import torch_npu
import triton
import triton.language as tl


@triton.jit
def safe_exp(x):
    return tl.exp(tl.where(x <= 0, x, float("-inf")))


@triton.heuristics(
    {
        "USE_G": lambda args: args["g"] is not None,
        "IS_VARLEN": lambda args: args["cu_seqlens"] is not None,
    }
)
@triton.jit(do_not_specialize=["chunk_offsets", "scale", "T", "H", "Hg", "K", "V"])
def chunk_fwd_kernel_o(
    q,
    k,
    v,
    h,
    g,
    o,
    cu_seqlens,
    chunk_offsets,
    scale,
    T,
    H,
    Hg,
    K,
    V,
    BT: tl.constexpr,
    BK: tl.constexpr,
    BV: tl.constexpr,
    USE_G: tl.constexpr,
    IS_VARLEN: tl.constexpr,
):
    i_v, i_nh = (tl.program_id(0), tl.program_id(1))
    i_n, i_h = (i_nh // H, i_nh % H)
    T_max = T
    if IS_VARLEN:
        bos, eos = (
            tl.load(cu_seqlens + i_n).to(tl.int32),
            tl.load(cu_seqlens + i_n + 1).to(tl.int32),
        )
        T = eos - bos
        NT = tl.cdiv(T, BT)
        boh = tl.load(chunk_offsets + i_n).to(tl.int64)
    else:
        bos, eos = (i_n * T, i_n * T + T)
        NT = tl.cdiv(T, BT)
        boh = i_n * NT
    q += (bos * Hg + i_h // (H // Hg)) * K
    k += (bos * Hg + i_h // (H // Hg)) * K
    v += (bos * H + i_h) * V
    o += (bos * H + i_h) * V
    for i_t in range(NT):
        i_tg = boh + i_t
        h_base = h + (i_tg * H + i_h).to(tl.int64) * K * V
        b_o = tl.zeros([BT, BV], dtype=tl.float32)
        b_A = tl.zeros([BT, BT], dtype=tl.float32)
        for i_k in range(tl.cdiv(K, BK)):
            p_q = tl.make_block_ptr(
                q, (T, K), (Hg * K, 1), (i_t * BT, i_k * BK), (BT, BK), (1, 0)
            )
            p_k = tl.make_block_ptr(
                k, (K, T), (1, Hg * K), (i_k * BK, i_t * BT), (BK, BT), (0, 1)
            )
            p_h = tl.make_block_ptr(
                h_base, (K, V), (V, 1), (i_k * BK, i_v * BV), (BK, BV), (1, 0)
            )
            b_q = tl.load(p_q, boundary_check=(0, 1))
            b_k = tl.load(p_k, boundary_check=(0, 1))
            b_h = tl.load(p_h, boundary_check=(0, 1))
            b_o += tl.dot(b_q, b_h)
            b_A += tl.dot(b_q, b_k)
        if USE_G:
            offs_t = i_t * BT + tl.arange(0, BT)
            mask_t = offs_t < T
            g_ptr = g + bos + i_h * T_max
            b_g = tl.load(g_ptr + offs_t, mask=mask_t, other=0.0)
            b_o = b_o * tl.exp(b_g)[:, None]
            b_A = b_A * safe_exp(b_g[:, None] - b_g[None, :])
        o_i = tl.arange(0, BT).to(tl.float32)
        m_A = o_i[:, None] >= o_i[None, :]
        b_A = tl.where(m_A, b_A, 0)
        p_v = tl.make_block_ptr(
            v, (T, V), (H * V, 1), (i_t * BT, i_v * BV), (BT, BV), (1, 0)
        )
        p_o = tl.make_block_ptr(
            o, (T, V), (H * V, 1), (i_t * BT, i_v * BV), (BT, BV), (1, 0)
        )
        b_v = tl.load(p_v, boundary_check=(0, 1))
        b_o = b_o * scale + tl.dot(b_A.to(b_v.dtype), b_v) * scale
        tl.store(p_o, b_o.to(p_o.dtype.element_ty), boundary_check=(0, 1))


def test_chunk_fwd_kernel_o():
    t, h, hg, k, v, bt = (3, 32, 16, 128, 128, 64)
    scale = 0.08838834764831845
    assert h >= hg and h % hg == 0
    gen = torch.Generator().manual_seed(20261010)
    q = (torch.randn((1, t, hg, k), generator=gen) * 0.1).half()
    key = (torch.randn((1, t, hg, k), generator=gen) * 0.1).half()
    value_head_major = (torch.randn((1, h, t, v), generator=gen) * 0.1).half()
    value = value_head_major.permute(0, 2, 1, 3).contiguous()
    state_head_major = (torch.randn((1, h, 1, k, v), generator=gen) * 0.1).half()
    state = state_head_major.permute(0, 2, 1, 3, 4).contiguous()
    g = (
        (-torch.arange(1, t + 1).float() * 0.04)[None, None, :]
        .expand(1, h, t)
        .contiguous()
    )
    initial = torch.full((t * h * v + 64,), 23.0, dtype=torch.float16)
    out = initial.npu()
    seq = torch.tensor([0, t], dtype=torch.int32)
    offset = torch.tensor([0, 1], dtype=torch.int32)
    chunk_fwd_kernel_o[1, h](
        q.npu(),
        key.npu(),
        value.npu(),
        state.npu(),
        g.npu(),
        out,
        seq.npu(),
        offset.npu(),
        scale,
        t,
        h,
        hg,
        k,
        v,
        BT=bt,
        BK=128,
        BV=128,
        num_warps=4,
        num_stages=2,
    )
    expected = torch.empty((1, t, h, v), dtype=torch.float32)
    for head in range(h):
        query = q[0, :, head // 2].float()
        keys = key[0, :, head // 2].float()
        history = query @ state[0, 0, head].float()
        scores = query @ keys.T
        decay = torch.exp(g[0, head, :, None] - g[0, head, None, :])
        causal = torch.tril(scores * decay).half().float()
        expected[0, :, head] = (
            history * torch.exp(g[0, head])[:, None]
            + causal @ value[0, :, head].float()
        ) * scale
    actual = out.cpu()
    actual_chunk_output = actual[: t * h * v].reshape(1, t, h, v).cpu()
    expected_chunk_output = expected
    expected_chunk_output = expected_chunk_output.to(actual_chunk_output.dtype)
    torch.testing.assert_close(
        (actual_chunk_output).float(),
        (expected_chunk_output).float(),
        atol=0.0003,
        rtol=0.003,
        check_dtype=False,
    )
    assert (
        torch.isfinite(actual_chunk_output).all()
        and torch.isfinite(expected_chunk_output).all()
    )
    actual_output_tail_guard = actual[t * h * v :].cpu()
    expected_output_tail_guard = initial[t * h * v :]
    expected_output_tail_guard = expected_output_tail_guard.to(
        actual_output_tail_guard.dtype
    )
    torch.testing.assert_close(
        (actual_output_tail_guard).float(),
        (expected_output_tail_guard).float(),
        atol=0,
        rtol=0,
        check_dtype=False,
    )
    assert (
        torch.isfinite(actual_output_tail_guard).all()
        and torch.isfinite(expected_output_tail_guard).all()
    )
    print("PASS: chunk_fwd_kernel_o")


if __name__ == "__main__":
    test_chunk_fwd_kernel_o()

#
# Copyright (c) 2025 Huawei Technologies Co., Ltd. All Rights Reserved.
# This file is a part of the vllm-ascend project.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#

import torch
import torch_npu
import triton
import triton.language as tl
from triton.language.extra.cann.extension import get_element


@triton.jit
def sample_recovered_tokens_kernel(
    output_token_ids_ptr,
    cu_num_draft_tokens_ptr,
    draft_token_ids_ptr,
    draft_probs_ptr,
    target_probs_ptr,
    target_indices_ptr,
    q_ptr,
    vocab_size,
    global_vocab_size,
    NO_DRAFT_PROBS: tl.constexpr,
    ENABLE_REDUCE_SAMPLING: tl.constexpr,
    SUB_BLOCK: tl.constexpr,
    VOCAB_BLOCK_SIZE: tl.constexpr = 512,
):
    req_idx = tl.program_id(0)
    pos = tl.program_id(1)
    prev_req_idx = tl.maximum(req_idx - 1, 0)
    start_idx = tl.where(
        req_idx == 0, 0, tl.load(cu_num_draft_tokens_ptr + prev_req_idx)
    )
    end_idx = tl.load(cu_num_draft_tokens_ptr + req_idx)
    num_draft_tokens = end_idx - start_idx
    if pos >= num_draft_tokens:
        return
    token_idx = start_idx + pos
    if ENABLE_REDUCE_SAMPLING:
        C = vocab_size
        n_loop = tl.cdiv(C, VOCAB_BLOCK_SIZE)
        global_max_p = tl.full((), -float("inf"), tl.float32)
        global_recovered_id = tl.full((), -1, tl.int64)
        draft_token_id = tl.load(draft_token_ids_ptr + token_idx).to(tl.int64)
        for li in range(n_loop):
            c_start = li * VOCAB_BLOCK_SIZE
            offs = c_start + tl.arange(0, VOCAB_BLOCK_SIZE)
            mask = offs < C
            tprob = tl.load(
                target_probs_ptr + token_idx * C + offs, mask=mask, other=0.0
            ).to(tl.float32)
            gidx = tl.load(
                target_indices_ptr + token_idx * C + offs, mask=mask, other=0
            ).to(tl.int64)
            if NO_DRAFT_PROBS:
                is_draft = (gidx == draft_token_id) & mask
                prob = tl.where(is_draft, 0.0, tprob)
            else:
                valid = (gidx >= 0) & (gidx < global_vocab_size) & mask
                dprob = tl.load(
                    draft_probs_ptr + token_idx * global_vocab_size + gidx,
                    mask=valid,
                    other=0.0,
                ).to(tl.float32)
                prob = tl.maximum(tprob - dprob, 0.0)
            qv = tl.load(q_ptr + req_idx * C + offs, mask=mask, other=1.0).to(
                tl.float32
            )
            bad_q = (
                (qv <= 0) | (qv != qv) | (qv == float("inf")) | (qv == -float("inf"))
            )
            score = tl.where(bad_q, float("-inf"), prob / qv)
            score = tl.where(mask, score, float("-inf"))
            block_best_score = tl.max(score, axis=0)
            block_best_idx = tl.argmax(score, axis=0).to(tl.int64)
            block_best_global_id = tl.load(
                target_indices_ptr + token_idx * C + (c_start + block_best_idx)
            ).to(tl.int64)
            better = block_best_score > global_max_p
            global_max_p = tl.where(better, block_best_score, global_max_p)
            global_recovered_id = tl.where(
                better, block_best_global_id, global_recovered_id
            )
        tl.store(output_token_ids_ptr + token_idx, global_recovered_id)
    else:
        vocab_size = global_vocab_size
        loop = (vocab_size + SUB_BLOCK - 1) // SUB_BLOCK
        global_recovered_id = -1
        global_max_p = -1.0
        if NO_DRAFT_PROBS:
            draft_token_id = tl.load(draft_token_ids_ptr + start_idx + pos)
            for loop_i in range(loop):
                vocab_start = loop_i * SUB_BLOCK
                vocab_offset = vocab_start + tl.arange(0, SUB_BLOCK)
                prob = tl.load(
                    target_probs_ptr + (start_idx + pos) * vocab_size + vocab_offset,
                    mask=vocab_offset < vocab_size,
                    other=0,
                )
                prob = tl.where(vocab_offset == draft_token_id, 0.0, prob)
                q = tl.load(
                    q_ptr + req_idx * vocab_size + vocab_offset,
                    mask=vocab_offset < vocab_size,
                    other=float("-inf"),
                )
                new_p = prob / q
                recovered_id = tl.argmax(new_p, axis=-1)
                max_p = get_element(new_p, (recovered_id,))
                if max_p > global_max_p:
                    global_max_p = max_p
                    global_recovered_id = vocab_start + recovered_id
        else:
            for loop_i in range(loop):
                vocab_start = loop_i * SUB_BLOCK
                vocab_offset = vocab_start + tl.arange(0, SUB_BLOCK)
                draft_prob = tl.load(
                    draft_probs_ptr + (start_idx + pos) * vocab_size + vocab_offset,
                    mask=vocab_offset < vocab_size,
                    other=0,
                )
                target_prob = tl.load(
                    target_probs_ptr + (start_idx + pos) * vocab_size + vocab_offset,
                    mask=vocab_offset < vocab_size,
                    other=0,
                )
                prob = tl.maximum(target_prob - draft_prob, 0)
                q = tl.load(
                    q_ptr + req_idx * vocab_size + vocab_offset,
                    mask=vocab_offset < vocab_size,
                    other=float("-inf"),
                )
                new_p = prob / q
                recovered_id = tl.argmax(new_p, axis=-1)
                max_p = get_element(new_p, (recovered_id,))
                if max_p > global_max_p:
                    global_max_p = max_p
                    global_recovered_id = vocab_start + recovered_id
        tl.store(output_token_ids_ptr + start_idx + pos, global_recovered_id)


def test_sample_recovered_tokens_kernel():
    size = 248320
    p = torch.full((1, size), 1e-06, dtype=torch.float32)
    p[0, 17] = 1.0
    p[0, -3] = 0.8
    p[0, 4101] = 0.7
    p /= p.sum()
    q = torch.linspace(0.9, 1.1, size).reshape(1, size)
    out = torch.tensor([-1], dtype=torch.int32).npu()
    sample_recovered_tokens_kernel[1, 1](
        out,
        torch.tensor([1], dtype=torch.int32).npu(),
        torch.tensor([17], dtype=torch.int32).npu(),
        None,
        p.npu(),
        None,
        q.npu(),
        size,
        size,
        NO_DRAFT_PROBS=True,
        ENABLE_REDUCE_SAMPLING=False,
        SUB_BLOCK=4096,
        multibuffer=False,
    )
    adjusted = p.clone()
    adjusted[0, 17] = 0
    actual_recovered = out.cpu()
    expected_recovered = (adjusted / q).argmax(-1).int()
    expected_recovered = expected_recovered.to(actual_recovered.dtype)
    torch.testing.assert_close(
        actual_recovered, expected_recovered, atol=0, rtol=0, check_dtype=False
    )
    assert (
        torch.isfinite(actual_recovered).all()
        and torch.isfinite(expected_recovered).all()
    )
    print("PASS: sample_recovered_tokens_kernel")


if __name__ == "__main__":
    test_sample_recovered_tokens_kernel()

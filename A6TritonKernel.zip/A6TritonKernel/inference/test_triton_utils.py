import os
import sys
import types
from types import SimpleNamespace

os.environ.setdefault("TRITON_BACKENDS_IN_TREE", "1")
os.environ.setdefault("TRITON_BACKEND", "opentile")
os.environ.setdefault("TRITON_ALWAYS_COMPILE", "1")

import triton
import triton.language as tl

vllm_utils = types.ModuleType("vllm.triton_utils")
vllm_utils.HAS_TRITON = True
vllm_utils.triton = triton
vllm_utils.tl = SimpleNamespace(
    insert_slice=lambda *a, **k: None,
    extract_slice=lambda *a, **k: None,
    get_element=lambda *a, **k: None,
)
sys.modules.setdefault("vllm", types.ModuleType("vllm"))
sys.modules["vllm.triton_utils"] = vllm_utils
sys.modules["vllm"].triton_utils = vllm_utils

vllm_ascend = types.ModuleType("vllm_ascend")
envs_mod = types.ModuleType("vllm_ascend.envs")
envs_mod.VLLM_ASCEND_ROPE_UB_SIZE_KB = 0
vllm_ascend.envs = envs_mod
sys.modules.setdefault("vllm_ascend", vllm_ascend)
sys.modules["vllm_ascend.envs"] = envs_mod

import torch
import numpy as np

if not (hasattr(torch, "npu") and torch.npu.is_available()):
    raise RuntimeError("no NPU device visible")



from typing import Any
HAS_TRITON = vllm_utils.HAS_TRITON
envs = vllm_ascend.envs

_NUM_AICORE = -1

_NUM_VECTORCORE = -1

_UB_SIZE_BYTES = -1

DEFAULT_UB_SIZE_BYTES = 192 * 1024

_MIN_UB_SIZE_BYTES = 4 * 1024

_UB_SIZE_PROPERTY_KEYS = (
    "ub_size",
    "max_ub_size",
    "unified_buffer_size",
    "max_shared_memory",
    "max_shared_mem",
)

def init_device_properties_triton():
    global _NUM_AICORE, _NUM_VECTORCORE, _UB_SIZE_BYTES
    if _NUM_AICORE == -1 and HAS_TRITON:
        device_properties: dict[str, Any] = triton.runtime.driver.active.utils.get_device_properties(
            torch.npu.current_device()
        )
        _NUM_AICORE = device_properties.get("num_aicore", -1)
        _NUM_VECTORCORE = device_properties.get("num_vectorcore", -1)
        assert _NUM_AICORE > 0 and _NUM_VECTORCORE > 0, "Failed to detect device properties."

        # Detect UB size: try each candidate key from device properties.
        # Reject values below _MIN_UB_SIZE_BYTES: some driver versions return
        # sentinels (e.g., 1) when UB info is unavailable, which would produce
        # absurdly small tiles and kernel compilation failures.
        for key in _UB_SIZE_PROPERTY_KEYS:
            value = device_properties.get(key)
            if isinstance(value, (int, float)) and value >= _MIN_UB_SIZE_BYTES:
                _UB_SIZE_BYTES = int(value)
                break
        # Fall back to safe default if not found or invalid.
        if _UB_SIZE_BYTES <= 0:
            _UB_SIZE_BYTES = DEFAULT_UB_SIZE_BYTES

        # Allow env var override for debugging or unsupported hardware.
        env_override = envs.VLLM_ASCEND_ROPE_UB_SIZE_KB
        if env_override > 0:
            _UB_SIZE_BYTES = env_override * 1024

def get_aicore_num():
    global _NUM_AICORE
    assert _NUM_AICORE > 0, "Device properties not initialized. Please call init_device_properties_triton() first."
    return _NUM_AICORE

def get_vectorcore_num():
    global _NUM_VECTORCORE
    assert _NUM_VECTORCORE > 0, "Device properties not initialized. Please call init_device_properties_triton() first."
    return _NUM_VECTORCORE

def get_ub_size_bytes():
    """Return the Unified Buffer (UB) size in bytes for the current NPU.

    Used by Triton kernels to dynamically size tiles so they fit within UB.
    The value is auto-detected from device properties during
    ``init_device_properties_triton()``, with a safe fallback of 192 KB
    (covering Ascend 910B/A3). Override via ``VLLM_ASCEND_ROPE_UB_SIZE_KB``.
    """
    global _UB_SIZE_BYTES
    assert _UB_SIZE_BYTES > 0, "Device properties not initialized. Please call init_device_properties_triton() first."
    return _UB_SIZE_BYTES

# ===== end inlined TU =====

print("=== step 1: raw device_properties dict ===")
dev = torch.npu.current_device()
props = triton.runtime.driver.active.utils.get_device_properties(dev)
for k in sorted(props.keys()):
    print(f"  {k} = {props[k]!r}")

num_aicore = props.get("num_aicore", -1)
num_vectorcore = props.get("num_vectorcore", -1)
num_cubecore = props.get("num_cubecore", -1)
print(f"  -> num_aicore={num_aicore} num_vectorcore={num_vectorcore} num_cubecore={num_cubecore}")

print("=== step 2: call init_device_properties_triton() ===")
init_device_properties_triton()

print("=== step 3: getters ===")
aicore = get_aicore_num()
vec = get_vectorcore_num()
ub = get_ub_size_bytes()
print(f"  get_aicore_num()={aicore}")
print(f"  get_vectorcore_num()={vec}")
print(f"  get_ub_size_bytes()={ub}")

ok = aicore > 0 and vec > 0 and ub > 0
print(f"=== RESULT: {'PASS' if ok else 'FAIL'} _NUM_AICORE={_NUM_AICORE} _NUM_VECTORCORE={_NUM_VECTORCORE} _UB_SIZE_BYTES={_UB_SIZE_BYTES} ===")
sys.exit(0 if ok else 1)
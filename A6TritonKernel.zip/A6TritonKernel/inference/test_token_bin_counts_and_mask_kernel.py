# SPDX-License-Identifier: Apache-2.0
# SPDX-FileCopyrightText: Copyright contributors to the vLLM project
#
# Copyright (c) 2025 Huawei Technologies Co., Ltd. All Rights Reserved.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
# This file is a part of the vllm-ascend project.
#
# Triton-Ascend implementation of get_token_bin_counts_and_mask.
# Migrated from model_executor/layers/utils.get_token_bin_counts_and_mask.
# Reference: https://github.com/vllm-project/vllm-ascend/pull/6979

import torch
import torch_npu
import triton
import triton.language as tl


@triton.jit(
    do_not_specialize=["tokens_batch_stride", "batch_size", "seq_len", "total_blocks"]
)
def token_bin_counts_and_mask_kernel(
    tokens_ptr,
    tokens_batch_stride,
    tokens_seq_stride,
    batch_size,
    seq_len,
    vocab_size,
    bin_counts_ptr,
    tp_rank,
    counts_batch_stride,
    counts_vocab_stride,
    total_blocks,
    SEQ_BLOCK: tl.constexpr,
):
    """Count token occurrences per batch row.

    1D grid with grid-stride loop: each program processes blocks at
    stride=num_programs to stay within the Triton-Ascend coreDim
    limit (65535) while distributing work evenly across cores.
    """
    pid = tl.program_id(axis=0)
    num_progs = tl.num_programs(axis=0)
    vocab_start_idx = tp_rank * vocab_size
    n_seq_blocks = tl.cdiv(seq_len, SEQ_BLOCK)
    for linear_block in tl.range(pid, total_blocks, num_progs):
        batch_idx = linear_block // n_seq_blocks
        seq_block_id = linear_block - batch_idx * n_seq_blocks
        seq_start = seq_block_id * SEQ_BLOCK
        batch_tokens_start = tokens_ptr + batch_idx * tokens_batch_stride
        batch_counts_start = bin_counts_ptr + batch_idx * counts_batch_stride
        pos_offsets = seq_start + tl.arange(0, SEQ_BLOCK)
        pos_mask = pos_offsets < seq_len
        token = tl.load(
            batch_tokens_start + pos_offsets * tokens_seq_stride,
            mask=pos_mask,
            other=vocab_size + vocab_start_idx,
        )
        local_token = token - vocab_start_idx
        token_in_range = (
            pos_mask & (token >= vocab_start_idx) & (local_token < vocab_size)
        )
        safe_local_token = tl.where(token_in_range, local_token, 0)
        count_ptr = batch_counts_start + safe_local_token * counts_vocab_stride
        tl.atomic_add(count_ptr, 1, mask=token_in_range)


def test_token_bin_counts_and_mask_kernel():
    seq, vocab, stride = (107, 248320, 107)
    logical = torch.arange(seq, dtype=torch.int64) % 13
    logical[0] = -1
    logical[1] = vocab
    logical[2] = vocab - 1
    backing = torch.full(((seq - 1) * stride + 1,), -1, dtype=torch.int64)
    backing[::stride] = logical
    initial = torch.zeros((1, vocab + 8), dtype=torch.int32)
    initial[:, vocab:] = -99
    out = initial.npu()
    token_bin_counts_and_mask_kernel[1,](
        backing.npu(), 107, 107, 1, seq, vocab, out, 0, vocab, 1, 1, SEQ_BLOCK=256
    )
    valid = logical[(logical >= 0) & (logical < vocab)]
    expected = torch.bincount(valid, minlength=vocab).int().reshape(1, vocab)
    actual = out.cpu()
    actual_counts = actual[:, :vocab].cpu()
    expected_counts = expected
    expected_counts = expected_counts.to(actual_counts.dtype)
    torch.testing.assert_close(
        actual_counts, expected_counts, atol=0, rtol=0, check_dtype=False
    )
    assert torch.isfinite(actual_counts).all() and torch.isfinite(expected_counts).all()
    actual_tail_guard = actual[:, vocab:].cpu()
    expected_tail_guard = initial[:, vocab:]
    expected_tail_guard = expected_tail_guard.to(actual_tail_guard.dtype)
    torch.testing.assert_close(
        actual_tail_guard, expected_tail_guard, atol=0, rtol=0, check_dtype=False
    )
    assert (
        torch.isfinite(actual_tail_guard).all()
        and torch.isfinite(expected_tail_guard).all()
    )
    print("PASS: token_bin_counts_and_mask_kernel")


if __name__ == "__main__":
    test_token_bin_counts_and_mask_kernel()

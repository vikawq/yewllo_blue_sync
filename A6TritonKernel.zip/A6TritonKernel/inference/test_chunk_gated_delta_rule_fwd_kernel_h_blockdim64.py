# SPDX-License-Identifier: Apache-2.0
# SPDX-FileCopyrightText: Copyright contributors to the vLLM project
# SPDX-FileCopyrightText: Songlin Yang, Yu Zhang
#
# This file contains code copied from the flash-linear-attention project.
# The original source code was licensed under the MIT license and included
# the following copyright notice:
# Copyright (c) 2023-2025, Songlin Yang, Yu Zhang
# ruff: noqa: E501
# mypy: ignore-errors

import torch
import torch_npu
import triton
import triton.language as tl


@triton.jit
def safe_exp(x):
    return tl.exp(tl.where(x <= 0, x, float("-inf")))


@triton.heuristics(
    {
        "USE_G": lambda args: args["g"] is not None,
        "USE_INITIAL_STATE": lambda args: args["h0"] is not None,
        "STORE_FINAL_STATE": lambda args: args["ht"] is not None,
        "SAVE_NEW_VALUE": lambda args: args["v_new"] is not None,
        "IS_VARLEN": lambda args: args["cu_seqlens"] is not None,
    }
)
@triton.jit(do_not_specialize=["T", "H", "Hg", "K", "V"])
def chunk_gated_delta_rule_fwd_kernel_h_blockdim64(
    k,
    v,
    w,
    v_new,
    g,
    h,
    h0,
    ht,
    cu_seqlens,
    chunk_offsets,
    h_update,
    T,
    H,
    Hg,
    K,
    V,
    BT: tl.constexpr,
    USE_G: tl.constexpr,
    USE_INITIAL_STATE: tl.constexpr,
    STORE_FINAL_STATE: tl.constexpr,
    SAVE_NEW_VALUE: tl.constexpr,
    IS_VARLEN: tl.constexpr,
):
    i_nh = tl.program_id(1)
    i_n, i_h = (i_nh // H, i_nh % H)
    T_max = 1 * T
    if IS_VARLEN:
        bos, eos = (
            tl.load(cu_seqlens + i_n).to(tl.int32),
            tl.load(cu_seqlens + i_n + 1).to(tl.int32),
        )
        T = eos - bos
        NT = tl.cdiv(T, BT)
        boh = tl.load(chunk_offsets + i_n).to(tl.int32)
    else:
        bos, eos = (i_n * T, i_n * T + T)
        NT = tl.cdiv(T, BT)
        boh = i_n * NT
    stride_v = H * V
    stride_k = Hg * K
    stride_w = H * K
    b_h1_bv1 = tl.zeros([128, 64], dtype=tl.float32)
    b_h1_bv2 = tl.zeros([128, 64], dtype=tl.float32)
    v_start1 = 0
    v_start2 = 64
    offs_k = tl.arange(0, 128)[:, None]
    offs_v1 = v_start1 + tl.arange(0, 64)[None, :]
    offs_v2 = v_start2 + tl.arange(0, 64)[None, :]
    mask_kv1 = (offs_k < K) & (offs_v1 < V)
    mask_kv2 = (offs_k < K) & (offs_v2 < V)
    if USE_INITIAL_STATE:
        h0_ptr = h0 + i_nh * K * V
        ptr_h0_bv1 = h0_ptr + offs_k * V + offs_v1 * 1
        b_h1_bv1 += tl.load(ptr_h0_bv1, mask=mask_kv1, other=0.0).to(tl.float32)
        ptr_h0_bv2 = h0_ptr + offs_k * V + offs_v2 * 1
        b_h1_bv2 += tl.load(ptr_h0_bv2, mask=mask_kv2, other=0.0).to(tl.float32)
    for i_t in range(NT):
        h_base = h + (boh + i_t) * H * K * V + i_h * K * V
        p_h1_bv1 = tl.make_block_ptr(
            h_base, (K, V), (V, 1), (0, v_start1), (128, 64), (1, 0)
        )
        tl.store(
            p_h1_bv1, b_h1_bv1.to(p_h1_bv1.dtype.element_ty), boundary_check=(0, 1)
        )
        p_h1_bv2 = tl.make_block_ptr(
            h_base, (K, V), (V, 1), (0, v_start2), (128, 64), (1, 0)
        )
        tl.store(
            p_h1_bv2, b_h1_bv2.to(p_h1_bv2.dtype.element_ty), boundary_check=(0, 1)
        )
        offs_t_wv = (i_t * BT + tl.arange(0, BT))[:, None]
        offs_k_wv = tl.arange(0, 128)[None, :]
        mask_w = (offs_t_wv < T) & (offs_k_wv < K)
        w_base = w + bos * H * K + i_h * K
        ptr_w = w_base + offs_t_wv * stride_w + offs_k_wv * 1
        b_w = tl.load(ptr_w, mask=mask_w, other=0.0)
        k_base = k + bos * Hg * K + i_h // (H // Hg) * K
        p_k = tl.make_block_ptr(
            k_base, (K, T), (1, stride_k), (0, i_t * BT), (128, BT), (0, 1)
        )
        b_k = tl.load(p_k, boundary_check=(0, 1))
        v_new_base = v_new + bos * H * V + i_h * V
        last_idx = min((i_t + 1) * BT, T) - 1
        b_g_last = tl.load(g + bos + i_h * T_max + last_idx)
        offs_t = i_t * BT + tl.arange(0, BT)
        mask_t = offs_t < T
        g_ptr = g + bos + i_h * T_max
        b_g = tl.load(g_ptr + offs_t, mask=mask_t, other=0.0)
        b_g = safe_exp(b_g_last - b_g)
        b_g_last = tl.exp(b_g_last)
        offs_t_v = (i_t * BT + tl.arange(0, BT))[:, None]
        mask_v1 = (offs_t_v < T) & (offs_v1 < V)
        v_base = v + bos * H * V + i_h * V
        ptr_v1 = v_base + offs_t_v * stride_v + offs_v1 * 1
        b_v1 = tl.load(ptr_v1, mask=mask_v1, other=0.0)
        b_v_new1 = b_v1.to(tl.float32)
        b_v_new1 -= tl.dot(b_w, b_h1_bv1.to(b_w.dtype))
        if SAVE_NEW_VALUE:
            p_v_new1 = tl.make_block_ptr(
                v_new_base,
                (T, V),
                (stride_v, 1),
                (i_t * BT, v_start1),
                (BT, 64),
                (1, 0),
            )
            tl.store(
                p_v_new1, b_v_new1.to(p_v_new1.dtype.element_ty), boundary_check=(0, 1)
            )
        if USE_G:
            b_v_new1 = b_v_new1 * b_g[:, None]
            b_h1_bv1 = b_h1_bv1 * b_g_last
        b_v_new1 = b_v_new1.to(k.dtype.element_ty)
        b_h1_bv1 += tl.dot(b_k, b_v_new1)
        mask_v2 = (offs_t_v < T) & (offs_v2 < V)
        ptr_v2 = v_base + offs_t_v * stride_v + offs_v2 * 1
        b_v2 = tl.load(ptr_v2, mask=mask_v2, other=0.0)
        b_v_new2 = b_v2.to(tl.float32)
        b_v_new2 -= tl.dot(b_w, b_h1_bv2.to(b_w.dtype))
        if SAVE_NEW_VALUE:
            p_v_new2 = tl.make_block_ptr(
                v_new_base,
                (T, V),
                (stride_v, 1),
                (i_t * BT, v_start2),
                (BT, 64),
                (1, 0),
            )
            tl.store(
                p_v_new2, b_v_new2.to(p_v_new2.dtype.element_ty), boundary_check=(0, 1)
            )
        if USE_G:
            b_v_new2 = b_v_new2 * b_g[:, None]
            b_h1_bv2 = b_h1_bv2 * b_g_last
        b_v_new2 = b_v_new2.to(k.dtype.element_ty)
        b_h1_bv2 += tl.dot(b_k, b_v_new2)
    if STORE_FINAL_STATE:
        ht_ptr = ht + i_nh * K * V
        p_ht1_bv1 = tl.make_block_ptr(
            ht_ptr, (K, V), (V, 1), (0, v_start1), (128, 64), (1, 0)
        )
        tl.store(
            p_ht1_bv1, b_h1_bv1.to(p_ht1_bv1.dtype.element_ty), boundary_check=(0, 1)
        )
        p_ht1_bv2 = tl.make_block_ptr(
            ht_ptr, (K, V), (V, 1), (0, v_start2), (128, 64), (1, 0)
        )
        tl.store(
            p_ht1_bv2, b_h1_bv2.to(p_ht1_bv2.dtype.element_ty), boundary_check=(0, 1)
        )


def test_chunk_gated_delta_rule_fwd_kernel_h_blockdim64():
    generator = torch.Generator().manual_seed(20261009)
    t, h, hg, k = (3, 32, 16, 128)
    kval = (torch.randn((1, t, hg, k), generator=generator) * 0.1).to(torch.float16)
    w = (torch.randn((1, t, h, k), generator=generator) * 0.1).to(torch.float16)
    g = (
        -torch.arange(1, t + 1, dtype=torch.float32)[None, None, :]
        .expand(1, h, t)
        .clone()
        * 0.04
    )
    t, h, hg, k, kv, w, g = (t, h, hg, k, kval, w, g)
    v = 128
    u = (torch.randn((1, t, h, v), generator=generator) * 0.2).to(torch.float16)
    h0 = (torch.randn((1, h, k, v), generator=generator) * 0.1).to(torch.float32)
    hn = torch.full((1, 1, h, k, v), 23.0, dtype=torch.float16).npu()
    vn = torch.full_like(u, 23.0).npu()
    htn = torch.full_like(h0, 23.0).npu()
    upd = torch.full((1, 1, h, k, k), 23.0, dtype=torch.float16)
    updn = upd.npu()
    chunk_gated_delta_rule_fwd_kernel_h_blockdim64[1, h](
        kv.npu(),
        u.npu(),
        w.npu(),
        vn,
        g.npu(),
        hn,
        h0.npu(),
        htn,
        torch.tensor([0, t], dtype=torch.int32).npu(),
        torch.tensor([0, 1], dtype=torch.int32).npu(),
        updn,
        t,
        h,
        hg,
        k,
        v,
        BT=64,
        num_warps=4,
        num_stages=2,
    )
    residual = torch.empty_like(u, dtype=torch.float32)
    final = torch.empty_like(h0)
    for head in range(h):
        residual[0, :, head] = (
            u[0, :, head].float() - w[0, :, head].float() @ h0[0, head].half().float()
        )
        decay = torch.exp(g[0, head, -1] - g[0, head])
        weighted = (residual[0, :, head] * decay[:, None]).half().float()
        final[0, head] = (
            h0[0, head] * torch.exp(g[0, head, -1])
            + kv[0, :, head // 2].float().T @ weighted
        )
    actual_h_initial_snapshot = hn.cpu()
    expected_h_initial_snapshot = h0[:, None]
    expected_h_initial_snapshot = expected_h_initial_snapshot.to(
        actual_h_initial_snapshot.dtype
    )
    torch.testing.assert_close(
        (actual_h_initial_snapshot).float(),
        (expected_h_initial_snapshot).float(),
        atol=0,
        rtol=0,
        check_dtype=False,
    )
    assert (
        torch.isfinite(actual_h_initial_snapshot).all()
        and torch.isfinite(expected_h_initial_snapshot).all()
    )
    actual_v_new = vn.cpu()
    expected_v_new = residual
    expected_v_new = expected_v_new.to(actual_v_new.dtype)
    torch.testing.assert_close(
        (actual_v_new).float(),
        (expected_v_new).float(),
        atol=0.0005,
        rtol=0.003,
        check_dtype=False,
    )
    assert torch.isfinite(actual_v_new).all() and torch.isfinite(expected_v_new).all()
    actual_final_state = htn.cpu()
    expected_final_state = final
    expected_final_state = expected_final_state.to(actual_final_state.dtype)
    torch.testing.assert_close(
        (actual_final_state).float(),
        (expected_final_state).float(),
        atol=0.0003,
        rtol=0.003,
        check_dtype=False,
    )
    assert (
        torch.isfinite(actual_final_state).all()
        and torch.isfinite(expected_final_state).all()
    )
    actual_h_update_unused = updn.cpu()
    expected_h_update_unused = upd
    expected_h_update_unused = expected_h_update_unused.to(actual_h_update_unused.dtype)
    torch.testing.assert_close(
        (actual_h_update_unused).float(),
        (expected_h_update_unused).float(),
        atol=0,
        rtol=0,
        check_dtype=False,
    )
    assert (
        torch.isfinite(actual_h_update_unused).all()
        and torch.isfinite(expected_h_update_unused).all()
    )
    print("PASS: chunk_gated_delta_rule_fwd_kernel_h_blockdim64")


if __name__ == "__main__":
    test_chunk_gated_delta_rule_fwd_kernel_h_blockdim64()

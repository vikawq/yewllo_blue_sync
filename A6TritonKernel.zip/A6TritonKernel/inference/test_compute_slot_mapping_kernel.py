import os
import sys
import types

os.environ.setdefault("TRITON_BACKENDS_IN_TREE", "1")
os.environ.setdefault("TRITON_BACKEND", "opentile")
os.environ.setdefault("TRITON_ALWAYS_COMPILE", "1")

import triton
import triton.language as tl

try:
    from triton.backends.ascend import compiler as C

    _orig = C.linalg_to_bin_enable_npu_compile_910_95

    def _compile_with_nolicm(linalg, metadata, opt):
        with open("/tmp/csm_linalg.mlir", "w") as _f:
            _f.write(linalg)
        bo = metadata.get("bisheng_options")
        if bo and "-disable-machine-licm" not in bo:
            metadata["bisheng_options"] = bo + " -mllvm -disable-machine-licm"
        return _orig(linalg, metadata, opt)

    C.linalg_to_bin_enable_npu_compile_910_95 = _compile_with_nolicm
except Exception:
    pass

import torch
import numpy as np

vllm_utils = types.ModuleType("vllm.triton_utils")
vllm_utils.tl = tl
vllm_utils.triton = triton
sys.modules.setdefault("vllm", types.ModuleType("vllm"))
sys.modules["vllm.triton_utils"] = vllm_utils
sys.modules["vllm"].triton_utils = vllm_utils

if not (hasattr(torch, "npu") and torch.npu.is_available()):
    raise RuntimeError("no NPU device visible")



def _next_power_of_2(value: int) -> int:

    return 1 << (value - 1).bit_length()

@triton.jit(do_not_specialize=["num_tokens", "max_num_tokens"])

def _compute_slot_mapping_kernel(

    num_tokens,

    max_num_tokens,

    query_start_loc_ptr,  # [num_reqs + 1], int32

    positions_ptr,  # [num_tokens], int64

    block_table_ptr,  # [max_num_reqs, max_num_blocks_per_req], int32 (flat)

    block_table_stride,  # max_num_blocks_per_req

    block_size,  # Logical block size used by the attention kernel

    slot_mapping_ptr,  # [max_num_tokens], int32

    KV_CACHE_BLOCK_SIZE: tl.constexpr,  # Physical KV cache allocation block size

    BLOCKS_PER_KV_BLOCK: tl.constexpr,  # KV_CACHE_BLOCK_SIZE = BLOCKS_PER_KV_BLOCK * block_size

    TOTAL_CP_WORLD_SIZE: tl.constexpr,

    TOTAL_CP_RANK: tl.constexpr,

    CP_KV_CACHE_INTERLEAVE_SIZE: tl.constexpr,

    PAD_ID: tl.constexpr,

    TILE_BLOCK_SIZE: tl.constexpr,

    BLOCK_TABLE_WINDOW_SIZE: tl.constexpr,

    IS_CIRCULAR: tl.constexpr = False,

):

    req_idx = tl.program_id(0)



    if req_idx == tl.num_programs(0) - 1:

        # Pad remaining slots for CUDA graph compatibility.

        for i in range(num_tokens, max_num_tokens, TILE_BLOCK_SIZE):

            offsets = i + tl.arange(0, TILE_BLOCK_SIZE)

            tl.store(

                slot_mapping_ptr + offsets,

                PAD_ID,

                mask=offsets < max_num_tokens,

            )

        return



    start_idx = tl.load(query_start_loc_ptr + req_idx).to(tl.int64)

    end_idx = tl.load(query_start_loc_ptr + req_idx + 1).to(tl.int64)



    row_offset = req_idx * block_table_stride

    block_table_offsets = tl.arange(0, BLOCK_TABLE_WINDOW_SIZE)

    for i in range(start_idx, end_idx, TILE_BLOCK_SIZE):

        offsets = i + tl.arange(0, TILE_BLOCK_SIZE)

        mask = offsets < end_idx

        pos = tl.load(positions_ptr + offsets, mask=mask, other=0).to(tl.int32)

        if IS_CIRCULAR:

            block_indices = tl.full((TILE_BLOCK_SIZE,), 0, tl.int32)

            slot_offsets = pos % block_size

        elif TOTAL_CP_WORLD_SIZE == 1:

            block_indices = pos // block_size

            slot_offsets = pos - block_indices * block_size

        else:

            virtual_block_size = KV_CACHE_BLOCK_SIZE * TOTAL_CP_WORLD_SIZE

            virtual_block_indices = pos // virtual_block_size

            virtual_block_offsets = pos - virtual_block_indices * virtual_block_size

            is_local = (virtual_block_offsets // CP_KV_CACHE_INTERLEAVE_SIZE) % TOTAL_CP_WORLD_SIZE == TOTAL_CP_RANK

            local_block_offsets = (

                virtual_block_offsets // (TOTAL_CP_WORLD_SIZE * CP_KV_CACHE_INTERLEAVE_SIZE)

            ) * CP_KV_CACHE_INTERLEAVE_SIZE + (virtual_block_offsets % CP_KV_CACHE_INTERLEAVE_SIZE)



            block_indices = virtual_block_indices * BLOCKS_PER_KV_BLOCK + local_block_offsets // block_size

            slot_offsets = local_block_offsets % block_size



        INT32_MAX = 2147483647

        valid_block_indices = tl.where(mask, block_indices, INT32_MAX)

        block_idx_base = tl.min(valid_block_indices, axis=0)

        block_table_window_offsets = block_idx_base + block_table_offsets

        block_table_window = tl.load(

            block_table_ptr + row_offset + block_table_window_offsets,

            mask=block_table_window_offsets < block_table_stride,

            other=0,

        ).to(tl.float32)

        if TOTAL_CP_WORLD_SIZE == 1:

            relative_block_indices = tl.where(mask, block_indices - block_idx_base, 0)

        else:

            relative_block_indices = tl.where(mask & is_local, block_indices - block_idx_base, 0)

        block_numbers = tl.gather(block_table_window, relative_block_indices, 0).to(tl.int32)

        slot_ids = block_numbers * block_size + slot_offsets

        if IS_CIRCULAR:

            slot_ids = tl.where(pos >= 0, slot_ids, PAD_ID)

        if TOTAL_CP_WORLD_SIZE != 1:

            slot_ids = tl.where(is_local, slot_ids, PAD_ID)

        tl.store(slot_mapping_ptr + offsets, slot_ids, mask=mask)

@triton.jit

def _compute_slot_mapping_request(

    start_idx,

    end_idx,

    req_idx,

    positions_ptr,

    block_table_ptr,

    block_table_stride,

    block_size,

    slot_mapping_ptr,

    is_circular,

    KV_CACHE_BLOCK_SIZE: tl.constexpr,

    BLOCKS_PER_KV_BLOCK: tl.constexpr,

    TOTAL_CP_WORLD_SIZE: tl.constexpr,

    TOTAL_CP_RANK: tl.constexpr,

    CP_KV_CACHE_INTERLEAVE_SIZE: tl.constexpr,

    PAD_ID: tl.constexpr,

    TILE_BLOCK_SIZE: tl.constexpr,

    BLOCK_TABLE_WINDOW_SIZE: tl.constexpr,

):

    row_offset = req_idx * block_table_stride

    block_table_offsets = tl.arange(0, BLOCK_TABLE_WINDOW_SIZE)

    for i in range(start_idx, end_idx, TILE_BLOCK_SIZE):

        offsets = i + tl.arange(0, TILE_BLOCK_SIZE)

        mask = offsets < end_idx

        pos = tl.load(positions_ptr + offsets, mask=mask, other=0).to(tl.int32)

        if TOTAL_CP_WORLD_SIZE == 1:

            block_indices = tl.where(is_circular, 0, pos // block_size)

            slot_offsets = pos % block_size

        else:

            virtual_block_size = KV_CACHE_BLOCK_SIZE * TOTAL_CP_WORLD_SIZE

            virtual_block_indices = pos // virtual_block_size

            virtual_block_offsets = pos - virtual_block_indices * virtual_block_size

            is_local = (virtual_block_offsets // CP_KV_CACHE_INTERLEAVE_SIZE) % TOTAL_CP_WORLD_SIZE == TOTAL_CP_RANK

            local_block_offsets = (

                virtual_block_offsets // (TOTAL_CP_WORLD_SIZE * CP_KV_CACHE_INTERLEAVE_SIZE)

            ) * CP_KV_CACHE_INTERLEAVE_SIZE + (virtual_block_offsets % CP_KV_CACHE_INTERLEAVE_SIZE)



            block_indices = virtual_block_indices * BLOCKS_PER_KV_BLOCK + local_block_offsets // block_size

            slot_offsets = local_block_offsets % block_size



        INT32_MAX = 2147483647

        valid_block_indices = tl.where(mask, block_indices, INT32_MAX)

        block_idx_base = tl.min(valid_block_indices, axis=0)

        block_table_window_offsets = block_idx_base + block_table_offsets

        block_table_window = tl.load(

            block_table_ptr + row_offset + block_table_window_offsets,

            mask=block_table_window_offsets < block_table_stride,

            other=0,

        ).to(tl.float32)

        if TOTAL_CP_WORLD_SIZE == 1:

            relative_block_indices = tl.where(mask, block_indices - block_idx_base, 0)

        else:

            relative_block_indices = tl.where(mask & is_local, block_indices - block_idx_base, 0)

        block_numbers = tl.gather(block_table_window, relative_block_indices, 0).to(tl.int32)

        slot_ids = block_numbers * block_size + slot_offsets

        slot_ids = tl.where(is_circular & (pos < 0), PAD_ID, slot_ids)

        if TOTAL_CP_WORLD_SIZE != 1:

            slot_ids = tl.where(is_local, slot_ids, PAD_ID)

        tl.store(slot_mapping_ptr + offsets, slot_ids, mask=mask)

@triton.jit(do_not_specialize=["num_tokens", "max_num_tokens"])

def _compute_slot_mapping_fused_groups_kernel(

    num_tokens,

    max_num_tokens,

    query_start_loc_ptr,

    positions_ptr,

    block_table_addrs_ptr,

    slot_mapping_addrs_ptr,

    block_table_strides_ptr,

    block_sizes_ptr,

    is_circular_ptr,

    HAS_CIRCULAR: tl.constexpr,

    PAD_ID: tl.constexpr,

    NUM_REQS: tl.constexpr,

    TILE_BLOCK_SIZE: tl.constexpr,

    PARALLEL_TILES: tl.constexpr,

    BLOCK_TABLE_WINDOW_SIZE: tl.constexpr,

):

    program_idx = tl.program_id(0)

    programs_per_group: tl.constexpr = NUM_REQS * PARALLEL_TILES + 1

    group_idx = program_idx // programs_per_group

    group_program_idx = program_idx - group_idx * programs_per_group



    block_table_addr = tl.load(block_table_addrs_ptr + group_idx)

    slot_mapping_addr = tl.load(slot_mapping_addrs_ptr + group_idx)

    block_table_ptr = tl.cast(block_table_addr, tl.pointer_type(tl.int32))

    slot_mapping_ptr = tl.cast(slot_mapping_addr, tl.pointer_type(tl.int32))



    if group_program_idx == programs_per_group - 1:

        for i in range(num_tokens, max_num_tokens, TILE_BLOCK_SIZE):

            offsets = i + tl.arange(0, TILE_BLOCK_SIZE)

            tl.store(

                slot_mapping_ptr + offsets,

                PAD_ID,

                mask=offsets < max_num_tokens,

            )

        return



    req_idx = group_program_idx // PARALLEL_TILES

    tile_idx = group_program_idx - req_idx * PARALLEL_TILES

    start_idx = tl.load(query_start_loc_ptr + req_idx).to(tl.int64)

    end_idx = tl.load(query_start_loc_ptr + req_idx + 1).to(tl.int64)

    block_table_stride = tl.load(block_table_strides_ptr + group_idx)

    block_size = tl.load(block_sizes_ptr + group_idx)

    is_circular = tl.load(is_circular_ptr + group_idx) if HAS_CIRCULAR else False

    row_offset = req_idx * block_table_stride

    block_table_offsets = tl.arange(0, BLOCK_TABLE_WINDOW_SIZE)

    for i in range(

        start_idx + tile_idx * TILE_BLOCK_SIZE,

        end_idx,

        TILE_BLOCK_SIZE * PARALLEL_TILES,

    ):

        offsets = i + tl.arange(0, TILE_BLOCK_SIZE)

        mask = offsets < end_idx

        pos = tl.load(positions_ptr + offsets, mask=mask, other=0).to(tl.int32)

        block_indices = tl.where(is_circular, 0, pos // block_size)

        slot_offsets = pos % block_size



        INT32_MAX = 2147483647

        valid_block_indices = tl.where(mask, block_indices, INT32_MAX)

        block_idx_base = tl.min(valid_block_indices, axis=0)

        block_table_window_offsets = block_idx_base + block_table_offsets

        block_table_window = tl.load(

            block_table_ptr + row_offset + block_table_window_offsets,

            mask=block_table_window_offsets < block_table_stride,

            other=0,

        ).to(tl.float32)

        relative_block_indices = tl.where(mask, block_indices - block_idx_base, 0)

        block_numbers = tl.gather(block_table_window, relative_block_indices, 0).to(tl.int32)

        slot_ids = block_numbers * block_size + slot_offsets

        slot_ids = tl.where(is_circular & (pos < 0), PAD_ID, slot_ids)

        tl.store(slot_mapping_ptr + offsets, slot_ids, mask=mask)

@triton.jit(do_not_specialize=["num_tokens", "max_num_tokens"])

def _compute_slot_mapping_fused_groups_adaptive_kernel(

    num_tokens,

    max_num_tokens,

    query_start_loc_ptr,

    positions_ptr,

    block_table_addrs_ptr,

    slot_mapping_addrs_ptr,

    block_table_strides_ptr,

    block_sizes_ptr,

    is_circular_ptr,

    HAS_CIRCULAR: tl.constexpr,

    PAD_ID: tl.constexpr,

    NUM_REQS: tl.constexpr,

    SMALL_TILE_BLOCK_SIZE: tl.constexpr,

    SMALL_BLOCK_TABLE_WINDOW_SIZE: tl.constexpr,

    LARGE_BLOCK_TABLE_WINDOW_SIZE: tl.constexpr,

):

    program_idx = tl.program_id(0)

    programs_per_group: tl.constexpr = NUM_REQS + 1

    group_idx = program_idx // programs_per_group

    group_program_idx = program_idx - group_idx * programs_per_group



    block_table_addr = tl.load(block_table_addrs_ptr + group_idx)

    slot_mapping_addr = tl.load(slot_mapping_addrs_ptr + group_idx)

    block_table_ptr = tl.cast(block_table_addr, tl.pointer_type(tl.int32))

    slot_mapping_ptr = tl.cast(slot_mapping_addr, tl.pointer_type(tl.int32))



    if group_program_idx == NUM_REQS:

        for i in range(num_tokens, max_num_tokens, 1024):

            offsets = i + tl.arange(0, 1024)

            tl.store(

                slot_mapping_ptr + offsets,

                PAD_ID,

                mask=offsets < max_num_tokens,

            )

        return



    req_idx = group_program_idx

    start_idx = tl.load(query_start_loc_ptr + req_idx).to(tl.int64)

    end_idx = tl.load(query_start_loc_ptr + req_idx + 1).to(tl.int64)

    block_table_stride = tl.load(block_table_strides_ptr + group_idx)

    block_size = tl.load(block_sizes_ptr + group_idx)

    is_circular = tl.load(is_circular_ptr + group_idx) if HAS_CIRCULAR else False

    request_tokens = end_idx - start_idx

    if request_tokens <= SMALL_TILE_BLOCK_SIZE:

        _compute_slot_mapping_request(

            start_idx,

            end_idx,

            req_idx,

            positions_ptr,

            block_table_ptr,

            block_table_stride,

            block_size,

            slot_mapping_ptr,

            is_circular,

            1,

            1,

            1,

            0,

            1,

            PAD_ID,

            SMALL_TILE_BLOCK_SIZE,

            SMALL_BLOCK_TABLE_WINDOW_SIZE,

        )

    else:

        _compute_slot_mapping_request(

            start_idx,

            end_idx,

            req_idx,

            positions_ptr,

            block_table_ptr,

            block_table_stride,

            block_size,

            slot_mapping_ptr,

            is_circular,

            1,

            1,

            1,

            0,

            1,

            PAD_ID,

            1024,

            LARGE_BLOCK_TABLE_WINDOW_SIZE,

        )

def _select_slot_mapping_launch_config(

    num_reqs: int,

    num_tokens: int,

    max_tile_block_size: int = 1024,

) -> tuple[int, int]:

    tile_block_size = max_tile_block_size

    if num_reqs > 1:

        tokens_per_req = (num_tokens + num_reqs - 1) // num_reqs

        tokens_per_req = 1 if tokens_per_req < 1 else tokens_per_req

        request_tile = _next_power_of_2(tokens_per_req)

        request_tile = 16 if request_tile < 16 else request_tile

        tile_block_size = request_tile if request_tile < max_tile_block_size else max_tile_block_size



    parallel_tiles = (num_tokens + tile_block_size - 1) // tile_block_size

    parallel_tiles = 4 if parallel_tiles > 4 else parallel_tiles

    if num_reqs == 1:

        parallel_tiles = parallel_tiles if num_tokens >= 2 * tile_block_size else 1

    elif num_reqs == 2 and num_tokens >= 4 * tile_block_size:

        parallel_tiles = 2

    else:

        parallel_tiles = 1

    return tile_block_size, parallel_tiles

def compute_slot_mapping_fused_groups(

    group_count,

    num_reqs,

    num_tokens,

    max_num_tokens,

    query_start_loc_ptr,

    positions_ptr,

    block_table_addrs_ptr,

    slot_mapping_addrs_ptr,

    block_table_strides_ptr,

    block_sizes_ptr,

    min_block_size,

    *,

    pad_id,

    is_circular_ptr=None,

):

    tile_block_size, parallel_tiles = _select_slot_mapping_launch_config(num_reqs, num_tokens)

    block_table_window_size = _next_power_of_2((tile_block_size + min_block_size - 1) // min_block_size + 1)

    if num_reqs > 1 and tile_block_size < 1024:

        _compute_slot_mapping_fused_groups_adaptive_kernel[(group_count * (num_reqs + 1),)](

            num_tokens,

            max_num_tokens,

            query_start_loc_ptr,

            positions_ptr,

            block_table_addrs_ptr,

            slot_mapping_addrs_ptr,

            block_table_strides_ptr,

            block_sizes_ptr,

            is_circular_ptr,

            HAS_CIRCULAR=is_circular_ptr is not None,

            PAD_ID=pad_id,

            NUM_REQS=num_reqs,

            SMALL_TILE_BLOCK_SIZE=tile_block_size,

            SMALL_BLOCK_TABLE_WINDOW_SIZE=block_table_window_size,

            LARGE_BLOCK_TABLE_WINDOW_SIZE=_next_power_of_2((1024 + min_block_size - 1) // min_block_size + 1),

        )

    else:

        programs_per_group = num_reqs * parallel_tiles + 1

        _compute_slot_mapping_fused_groups_kernel[(group_count * programs_per_group,)](

            num_tokens,

            max_num_tokens,

            query_start_loc_ptr,

            positions_ptr,

            block_table_addrs_ptr,

            slot_mapping_addrs_ptr,

            block_table_strides_ptr,

            block_sizes_ptr,

            is_circular_ptr,

            HAS_CIRCULAR=is_circular_ptr is not None,

            PAD_ID=pad_id,

            NUM_REQS=num_reqs,

            TILE_BLOCK_SIZE=tile_block_size,

            PARALLEL_TILES=parallel_tiles,

            BLOCK_TABLE_WINDOW_SIZE=block_table_window_size,

        )

# ===== end inlined CSM =====

def np_next_pow2(v):
    return 1 << (v - 1).bit_length()


def ref_sim(float_block_numbers):
    return float_block_numbers.astype(np.float32)


def ref_kernel1(query_start_loc, positions, block_table, block_table_stride, block_size,
                num_tokens, max_num_tokens, pad_id, tile, window, is_circular):
    nr = len(query_start_loc) - 1
    slot = np.full(max_num_tokens, pad_id, dtype=np.int32)
    for req_idx in range(nr):
        s, e = query_start_loc[req_idx], query_start_loc[req_idx + 1]
        row_offset = req_idx * block_table_stride
        for i in range(s, e, tile):
            offs = np.arange(i, min(i + tile, e))
            pos = positions[offs]
            if is_circular:
                b_idx = np.zeros_like(pos, dtype=np.int64)
                s_off = pos % block_size
            else:
                b_idx = pos // block_size
                s_off = pos - b_idx * block_size
            valid = np.where(offs < e, b_idx, 2_147_483_647)
            base = int(valid.min())
            win = np.zeros(window, dtype=np.float32)
            for j in range(window):
                if base + j < block_table_stride:
                    win[j] = block_table.reshape(-1)[row_offset + base + j]
            rel = np.where(offs < e, b_idx - base, 0).astype(np.int64)
            bnum = np.array([win[r] for r in rel]).astype(np.int32)
            ids = bnum * block_size + s_off
            slot[offs] = ids
    return slot


def run_kernel1(case_name, nr, token_list, block_size, stride, num_tokens, max_num_tokens,
                pad_id, tile, window, is_circular):
    dev = torch.device("npu", torch.npu.current_device())
    query = torch.tensor([0] + list(np.cumsum(token_list)), dtype=torch.int32, device=dev)
    positions = torch.tensor([t for tl_ in token_list for t in range(tl_)], dtype=torch.int64, device=dev)
    phys = 10
    bt_np = np.zeros((nr, stride), dtype=np.int32)
    for r in range(nr):
        total = token_list[r]
        nb = (total + block_size - 1) // block_size
        for b in range(nb):
            bt_np[r, b] = phys + r * 100 + b
    block_table = torch.from_numpy(bt_np).to(device=dev)
    slot = torch.full((max_num_tokens,), -7, dtype=torch.int32, device=dev)
    grid = (nr + 1,)
    _compute_slot_mapping_kernel[grid](
        num_tokens, max_num_tokens,
        query, positions, block_table, stride, block_size, slot,
        KV_CACHE_BLOCK_SIZE=block_size,
        BLOCKS_PER_KV_BLOCK=1,
        TOTAL_CP_WORLD_SIZE=1,
        TOTAL_CP_RANK=0,
        CP_KV_CACHE_INTERLEAVE_SIZE=1,
        PAD_ID=pad_id,
        TILE_BLOCK_SIZE=tile,
        BLOCK_TABLE_WINDOW_SIZE=window,
        IS_CIRCULAR=is_circular,
    )
    torch.npu.synchronize()
    got = slot.cpu().numpy()
    exp = ref_kernel1(query.cpu().numpy(), positions.cpu().numpy(), bt_np, stride, block_size,
                      num_tokens, max_num_tokens, pad_id, tile, window, is_circular)
    ok = np.array_equal(got, exp)
    print(f"[{'PASS' if ok else 'FAIL'}] kernel1 {case_name} nr={nr} nt={num_tokens} bs={block_size}")
    if not ok:
        print("  got:", got.tolist())
        print("  exp:", exp.tolist())
    return ok


def run_fused(case_name, nr, token_list, block_size, stride, max_num_tokens, pad_id, tile, window, is_circular):
    dev = torch.device("npu", torch.npu.current_device())
    num_tokens = sum(token_list)
    query = torch.tensor([0] + list(np.cumsum(token_list)), dtype=torch.int32, device=dev)
    positions = torch.tensor([t for tl_ in token_list for t in range(tl_)], dtype=torch.int64, device=dev)
    phys = 10
    bt_np = np.zeros((nr, stride), dtype=np.int32)
    for r in range(nr):
        total = token_list[r]
        nb = (total + block_size - 1) // block_size
        for b in range(nb):
            bt_np[r, b] = phys + r * 100 + b
    block_table = torch.from_numpy(bt_np).to(device=dev)

    g = 1
    slot_np = np.full((max_num_tokens,), -7, dtype=np.int32)
    slot = torch.from_numpy(slot_np).to(device=dev)
    bt_addrs = torch.tensor([block_table.data_ptr()], dtype=torch.int64, device=dev)
    sm_addrs = torch.tensor([slot.data_ptr()], dtype=torch.int64, device=dev)
    strides = torch.tensor([stride], dtype=torch.int32, device=dev)
    bsizes = torch.tensor([block_size], dtype=torch.int32, device=dev)
    circ = torch.tensor([1 if is_circular else 0], dtype=torch.int32, device=dev) if is_circular else None

    compute_slot_mapping_fused_groups(
        g, nr, num_tokens, max_num_tokens,
        query, positions, bt_addrs, sm_addrs, strides, bsizes, block_size,
        pad_id=pad_id, is_circular_ptr=circ,
    )
    torch.npu.synchronize()
    got = slot.cpu().numpy()
    exp = ref_fused(query.cpu().numpy(), positions.cpu().numpy(), bt_np, stride, block_size,
                    num_tokens, max_num_tokens, pad_id, tile, window, is_circular)
    ok = np.array_equal(got, exp)
    print(f"[{'PASS' if ok else 'FAIL'}] fused {case_name} nr={nr} nt={num_tokens} bs={block_size}")
    if not ok:
        print("  got:", got.tolist())
        print("  exp:", exp.tolist())
    return ok


def test_compute_slot_mapping_kernel():
    ok = True
    pad_id = 1024
    ok &= run_kernel1("basic", 2, [5, 7], 4, 16, 12, 16, pad_id, 4, 32, False)
    ok &= run_kernel1("circular", 1, [6], 4, 16, 6, 16, pad_id, 4, 32, True)
    assert ok, "compute_slot_mapping_kernel FAILED"
    print("[ALL PASS] compute_slot_mapping_kernel")


if __name__ == "__main__":
    test_compute_slot_mapping_kernel()

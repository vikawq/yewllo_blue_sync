# Adapt from https://github.com/vllm-project/vllm/blob/main/vllm/model_executor/layers/fla/ops/l2norm.py
# SPDX-License-Identifier: Apache-2.0
# SPDX-FileCopyrightText: Copyright contributors to the vLLM project
# SPDX-FileCopyrightText: Songlin Yang, Yu Zhang
#
# This file contains code copied from the flash-linear-attention project.
# The original source code was licensed under the MIT license and included
# the following copyright notice:
# Copyright (c) 2023-2025, Songlin Yang, Yu Zhang

import torch
import torch_npu
import triton
import triton.language as tl


@triton.jit(do_not_specialize=["eps", "M", "NUM_CHUNKS"])
def l2norm_fwd_kernel2_loop(
    X, Y, eps, M, N: tl.constexpr, MBLOCK: tl.constexpr, NUM_CHUNKS
):
    base_row = tl.program_id(0) * (NUM_CHUNKS * MBLOCK)
    rindex = tl.arange(0, N)[None, :]
    for chunk in range(NUM_CHUNKS):
        row_idx = base_row + chunk * MBLOCK + tl.arange(0, MBLOCK)[:, None]
        xmask = row_idx < M
        xs = tl.load(X + (rindex + N * row_idx), mask=xmask, other=0.0).to(tl.float32)
        square = xs * xs
        square_sum = tl.sum(square, 1)[:, None]
        rsqrt = tl.rsqrt(square_sum + eps)
        tl.store(Y + (rindex + N * row_idx), xs * rsqrt, xmask)


def test_l2norm_fwd_kernel2_loop():
    generator = torch.Generator().manual_seed(20261009)
    m, n = (5, 128)
    x = torch.randn((m, n), generator=generator).to(torch.float16)
    x[0].zero_()
    initial = torch.full((m + 8, n), 23.0, dtype=x.dtype)
    xn, yn = (x.npu(), initial.npu())
    l2norm_fwd_kernel2_loop[64,](xn, yn, 1e-06, m, n, 69, 1)
    output = yn.cpu()
    reference = x.float() * torch.rsqrt(
        x.float().square().sum(-1, keepdim=True) + 1e-06
    )
    actual_normalized = output[:m].cpu()
    expected_normalized = reference
    expected_normalized = expected_normalized.to(actual_normalized.dtype)
    torch.testing.assert_close(
        (actual_normalized).float(),
        (expected_normalized).float(),
        atol=0.0005,
        rtol=0.002,
        check_dtype=False,
    )
    assert (
        torch.isfinite(actual_normalized).all()
        and torch.isfinite(expected_normalized).all()
    )
    actual_tail_guard = output[m:].cpu()
    expected_tail_guard = initial[m:]
    expected_tail_guard = expected_tail_guard.to(actual_tail_guard.dtype)
    torch.testing.assert_close(
        (actual_tail_guard).float(),
        (expected_tail_guard).float(),
        atol=0,
        rtol=0,
        check_dtype=False,
    )
    assert (
        torch.isfinite(actual_tail_guard).all()
        and torch.isfinite(expected_tail_guard).all()
    )
    print("PASS: l2norm_fwd_kernel2_loop")


if __name__ == "__main__":
    test_l2norm_fwd_kernel2_loop()

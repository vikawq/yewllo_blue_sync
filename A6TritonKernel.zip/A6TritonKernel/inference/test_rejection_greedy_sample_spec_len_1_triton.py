# -*- coding: utf-8 -*-
import os
import sys
import types
import time
import traceback

os.environ.setdefault("TRITON_BACKENDS_IN_TREE", "1")
os.environ.setdefault("TRITON_BACKEND", "opentile")
os.environ.setdefault("TRITON_ALWAYS_COMPILE", "1")

import triton
import triton.language as tl
import torch

_vllm_utils = types.ModuleType("vllm.triton_utils")
_vllm_utils.tl = tl
_vllm_utils.triton = triton
_vllm_utils.tldevice = types.SimpleNamespace(
    fast_dividef=lambda x, y: x / y,
    fast_expf=tl.exp,
    fast_logf=tl.log,
    fast_log2f=tl.log2,
)
_vllm_pkg = types.ModuleType("vllm")
_vllm_pkg.triton_utils = _vllm_utils
sys.modules.setdefault("vllm", _vllm_pkg)
sys.modules["vllm.triton_utils"] = _vllm_utils
sys.modules["vllm"].triton_utils = _vllm_utils

_math_pkg = types.ModuleType("vllm.utils")
sys.modules.setdefault("vllm.utils", _math_pkg)
_math_mod = types.ModuleType("vllm.utils.math_utils")
sys.modules["vllm.utils.math_utils"] = _math_mod



def next_power_of_2(n: int) -> int:
    if n <= 0:
        return 1
    return 1 << (n - 1).bit_length()


VECTORCORE_NUM = 32


def get_vectorcore_num() -> int:
    return VECTORCORE_NUM


@triton.jit
def get_element(data, index):
    idx = index[0]
    n: tl.constexpr = data.shape[0]
    mask = tl.arange(0, n) == idx
    return tl.sum(tl.where(mask, data.to(tl.int32), 0))


@triton.jit(do_not_specialize=["replace_from", "replace_to", "vec_len"])
def expand_kernel(
    output_ptr,  # [num_tokens]
    input_ptr,  # [batch_size]
    cu_num_tokens_ptr,  # [batch_size]
    replace_from,
    replace_to,
    vec_len,
    MAX_NUM_TOKENS: tl.constexpr,
    BLOCK_SIZE: tl.constexpr,
):
    req_idx = tl.program_id(0)
    offset = req_idx * BLOCK_SIZE + tl.arange(0, BLOCK_SIZE)
    len_mask = offset < vec_len

    # Mask the load itself: tl.where does not prevent reading before the
    # buffer start (both arms are always evaluated), so lane offset == 0 must
    # be masked out at the load. other=0 keeps num_tokens deterministic (0)
    # for out-of-range lanes, which the store mask below relies on.
    start_idx = tl.load(cu_num_tokens_ptr + offset - 1, mask=len_mask & (offset > 0), other=0)
    end_idx = tl.load(cu_num_tokens_ptr + offset, len_mask, other=0)
    num_tokens = end_idx - start_idx

    src_val = tl.load(input_ptr + offset, len_mask)
    src_val = tl.where(src_val == replace_from, replace_to, src_val)

    for i in tl.range(0, BLOCK_SIZE):
        num_tokens1 = get_element(num_tokens, (i,))
        start_idx1 = get_element(start_idx, (i,))
        src_val1 = get_element(src_val, (i,))
        offset1 = tl.arange(0, MAX_NUM_TOKENS)
        tl.store(output_ptr + start_idx1 + offset1, src_val1, mask=offset1 < num_tokens1)

@triton.jit(do_not_specialize=["vec_len"])
def rejection_greedy_sample_spec_len_1_triton(
    output_token_ids_ptr,  # [batch_size, 2]
    draft_token_ids_ptr,  # [num_tokens]
    target_argmax_ptr,  # [num_tokens]
    bonus_token_ids_ptr,
    vec_len,
    uniform_probs_ptr,  # [num_tokens] or None (synthetic only)
    synthetic_conditional_rates_ptr,  # [num_speculative_tokens] or None
    SYNTHETIC_MODE: tl.constexpr,
    BLOCK_SIZE: tl.constexpr,
):
    block_idx = tl.program_id(0)
    offset = block_idx * BLOCK_SIZE + tl.arange(0, BLOCK_SIZE)
    mask = offset < vec_len

    draft_token_id = tl.load(draft_token_ids_ptr + offset, mask)
    target_argmax_id = tl.load(target_argmax_ptr + offset, mask)
    bonus_token_id = tl.load(bonus_token_ids_ptr + offset, mask)

    if SYNTHETIC_MODE:
        # Synthetic: accept the draft token with prob conditional_rates[0],
        # regardless of target match. Accepted => emit draft token (pos 0) and
        # the bonus token (pos 1); rejected => emit target_argmax (pos 0).
        uniform_prob = tl.load(uniform_probs_ptr + offset, mask)
        # spec_len == 1 => only position 0.
        rate = tl.load(synthetic_conditional_rates_ptr + 0)
        accepted = (uniform_prob < rate) & (draft_token_id >= 0) & mask
        # Cast both arms to int32: draft_token_id is int32, target_argmax_id is
        # int64 (from argmax); tl.where requires matching dtypes.
        token_id = tl.where(accepted, draft_token_id.to(tl.int32), target_argmax_id.to(tl.int32))
        tl.store(output_token_ids_ptr + offset * 2, token_id, mask)
        accept_mask = accepted
    else:
        tl.store(output_token_ids_ptr + offset * 2, target_argmax_id, mask)
        accept_mask = (draft_token_id == target_argmax_id) & mask
    tl.store(output_token_ids_ptr + offset * 2 + 1, bonus_token_id, accept_mask)

RESULT = "/tmp/rs_greedyspec1_res.txt"


def append(line):
    with open(RESULT, "a") as f:
        f.write(line + "\n")


def done(stat, case, t0, msg=""):
    line = f"[{stat}] {case} elapsed={time.time() - t0:.1f}s {msg}"
    print(line, flush=True)
    append(line)
    sys.stdout.flush()
    if stat != "OK":
        raise AssertionError(line)


def check(name, cond, detail=""):
    if not cond:
        raise AssertionError(f"{name} failed {detail}")
    print(f"  check {name} PASS {detail}", flush=True)




def run_expand(x, cu, replace_from, replace_to, max_num_tokens, grid, block):
    # x: [batch_size] per-request src value; cu: [batch_size] closed-token counts
    batch_size = x.shape[0]
    ex = torch.full([int(cu[-1].cpu())], -1, dtype=torch.int32, device=cu.device)
    expand_kernel[(grid,)](
        ex, x, cu, replace_from, replace_to, batch_size,
        MAX_NUM_TOKENS=max_num_tokens, BLOCK_SIZE=block, num_warps=1,
    )
    return ex.cpu().tolist()


def case_greedy_spec1():
    dev = "npu"
    def run(draft, argmax, bonus):
        out = torch.full([1, 2], -1, dtype=torch.int32, device=dev)
        d = torch.tensor([draft], dtype=torch.int32, device=dev)
        t = torch.tensor([argmax], dtype=torch.int64, device=dev)
        b = torch.tensor([bonus], dtype=torch.int32, device=dev)
        rejection_greedy_sample_spec_len_1_triton[(1,)](
            out, d, t, b, 1, None, None,
            SYNTHETIC_MODE=False, BLOCK_SIZE=1, num_warps=1,
        )
        return out.cpu().tolist()

    # accept: draft == target_argmax -> bonus at pos 1
    got = run(42, 42, 7)
    check("greedy accept", got == [[42, 7]], str(got))
    # reject: draft != target_argmax -> no bonus, keep -1
    got2 = run(1, 2, 7)
    check("greedy reject", got2 == [[2, -1]], str(got2))



def test_rejection_greedy_sample_spec_len_1_triton():
    if not torch.npu.is_available():
        raise AssertionError("npu NOT available, abort")
    print(f"triton={__import__('triton').__version__} torch={torch.__version__}", flush=True)
    t0 = time.time()
    case_greedy_spec1()
    done("OK", "greedy_spec1", t0)


if __name__ == "__main__":
    test_rejection_greedy_sample_spec_len_1_triton()

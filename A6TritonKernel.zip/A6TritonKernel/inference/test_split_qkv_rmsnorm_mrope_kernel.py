import sys

import torch
import torch_npu
import triton
import triton.language as tl
from triton.language.extra.cann.extension import extract_slice, insert_slice

try:
    from triton.backends.ascend import compiler as C

    _gcb = C.get_common_bishengir_compile_options

    def _gcb_patched(metadata):
        opts = list(_gcb(metadata))
        opts += ["--simt-vf-dynamic-size=300", "--save-temps=/tmp/itmp_qkv"]
        return opts

    C.get_common_bishengir_compile_options = _gcb_patched
except Exception:
    pass


@triton.jit(
    do_not_specialize=["num_tokens", "front_core_num", "num_tokens_each_front_core", "num_tokens_each_tail_core"]
)
def split_qkv_rmsnorm_mrope_kernel(
    in_qkv_ptr: torch.Tensor,
    q_weight_ptr: torch.Tensor,
    q_bias_ptr: torch.Tensor,
    k_weight_ptr: torch.Tensor,
    k_bias_ptr: torch.Tensor,
    cos_sin_ptr: torch.Tensor,
    out_q_ptr: torch.Tensor,
    out_k_ptr: torch.Tensor,
    out_v_ptr: torch.Tensor,
    out_gate_ptr: torch.Tensor,
    num_tokens,
    front_core_num,
    num_tokens_each_front_core,
    num_tokens_each_tail_core,
    num_q_heads: tl.constexpr,
    num_kv_heads: tl.constexpr,
    head_size: tl.constexpr,
    q_size: tl.constexpr,
    kv_size: tl.constexpr,
    eps: tl.constexpr,
    mrope_section_t,
    mrope_section_h,
    mrope_section_w,
    has_bias: tl.constexpr,
    is_interleaved: tl.constexpr,
    rope_dim: tl.constexpr,
    half_rope_dim: tl.constexpr,
    IS_PARTIAL_ROPE: tl.constexpr,
    gate_size: tl.constexpr,
):
    block_idx = tl.program_id(0)

    loop_num = num_tokens_each_front_core
    if block_idx >= front_core_num:
        loop_num = num_tokens_each_tail_core

    block_offset = num_tokens_each_front_core * block_idx
    if block_idx >= front_core_num:
        block_offset = (
            num_tokens_each_front_core * front_core_num + (block_idx - front_core_num) * num_tokens_each_tail_core
        )

    q_rmsnorm_weight = tl.load(q_weight_ptr + tl.arange(0, head_size))
    k_rmsnorm_weight = tl.load(k_weight_ptr + tl.arange(0, head_size))

    if has_bias:
        q_bias = tl.load(q_bias_ptr + tl.arange(0, head_size))
        k_bias = tl.load(k_bias_ptr + tl.arange(0, head_size))

    for index in range(loop_num):
        ## load ##
        # q
        in_q_offset = in_qkv_ptr + (block_offset + index) * (q_size + gate_size + 2 * kv_size)
        if gate_size > 0:
            in_q_gate_tensor = (
                tl.load(in_q_offset + tl.arange(0, q_size + gate_size))
                .to(tl.float32)
                .reshape(num_q_heads, head_size * 2)
            )
            in_q_tensor = extract_slice(
                in_q_gate_tensor,
                offsets=(0, 0),
                sizes=(num_q_heads, head_size),
                strides=(1, 1),
            )
            in_gate_tensor = extract_slice(
                in_q_gate_tensor,
                offsets=(0, head_size),
                sizes=(num_q_heads, head_size),
                strides=(1, 1),
            ).reshape(q_size)
        else:
            in_q_tensor = tl.load(in_q_offset + tl.arange(0, q_size)).to(tl.float32).reshape(num_q_heads, head_size)

        # k
        in_k_offset = in_q_offset + q_size + gate_size
        in_k_tensor = tl.load(in_k_offset + tl.arange(0, kv_size)).to(tl.float32).reshape(num_kv_heads, head_size)
        # v
        in_v_offset = in_k_offset + kv_size
        in_v_tensor = tl.load(in_v_offset + tl.arange(0, kv_size))

        # cos, sin
        cos_offsets = tl.arange(0, half_rope_dim)
        if is_interleaved:
            h_mask = ((cos_offsets % 3) == 1) & (cos_offsets <= 3 * mrope_section_h)
            w_mask = ((cos_offsets % 3) == 2) & (cos_offsets <= 3 * mrope_section_w)
            t_mask = ~(h_mask | w_mask)
        else:
            t_mask = cos_offsets < mrope_section_t
            h_mask = (mrope_section_t - 1 < cos_offsets) & (cos_offsets < mrope_section_t + mrope_section_h)
            w_mask = (mrope_section_t + mrope_section_h - 1 < cos_offsets) & (
                cos_offsets < mrope_section_t + mrope_section_h + mrope_section_w
            )

        t_cos_offset = cos_sin_ptr + (block_offset + index) * rope_dim
        h_cos_offset = t_cos_offset + num_tokens * rope_dim
        w_cos_offset = h_cos_offset + num_tokens * rope_dim

        t_sin_offset = cos_sin_ptr + (block_offset + index) * rope_dim + half_rope_dim
        h_sin_offset = t_sin_offset + num_tokens * rope_dim
        w_sin_offset = h_sin_offset + num_tokens * rope_dim

        t_cos_tensor = tl.load(t_cos_offset + cos_offsets, mask=t_mask, other=0)
        h_cos_tensor = tl.load(h_cos_offset + cos_offsets, mask=h_mask, other=0)
        w_cos_tensor = tl.load(w_cos_offset + cos_offsets, mask=w_mask, other=0)
        t_sin_tensor = tl.load(t_sin_offset + cos_offsets, mask=t_mask, other=0)
        h_sin_tensor = tl.load(h_sin_offset + cos_offsets, mask=h_mask, other=0)
        w_sin_tensor = tl.load(w_sin_offset + cos_offsets, mask=w_mask, other=0)

        cos_tensor = (t_cos_tensor + h_cos_tensor + w_cos_tensor).to(tl.float32).reshape(1, half_rope_dim)
        cos_tensor = tl.broadcast_to(cos_tensor, (2, half_rope_dim)).reshape(1, rope_dim)

        sin_tensor = (t_sin_tensor + h_sin_tensor + w_sin_tensor).to(tl.float32).reshape(1, half_rope_dim)
        sin_tensor = tl.broadcast_to(sin_tensor, (2, half_rope_dim)).reshape(1, rope_dim)

        ## compute ##
        # q-rmsnorm
        squares = in_q_tensor * in_q_tensor
        variances = tl.sum(squares, axis=1) / head_size
        reciprocal_std = (1 / tl.sqrt(variances + eps)).reshape(num_q_heads, 1)
        q_normalized = in_q_tensor * reciprocal_std
        q_normalized = q_normalized * q_rmsnorm_weight
        if has_bias:
            q_normalized = q_normalized + q_bias

        # k-rmsnorm
        squares = in_k_tensor * in_k_tensor
        variances = tl.sum(squares, axis=1) / head_size
        reciprocal_std = (1 / tl.sqrt(variances + eps)).reshape(num_kv_heads, 1)
        k_normalized = in_k_tensor * reciprocal_std
        k_normalized = k_normalized * k_rmsnorm_weight
        if has_bias:
            k_normalized = k_normalized + k_bias

        # q-mrope
        x1 = extract_slice(
            q_normalized,
            offsets=(0, 0),
            sizes=(num_q_heads, half_rope_dim),
            strides=(1, 1),
        )
        x2 = extract_slice(
            q_normalized,
            offsets=(0, half_rope_dim),
            sizes=(num_q_heads, half_rope_dim),
            strides=(1, 1),
        )
        cat_x = tl.zeros((num_q_heads, rope_dim), dtype=tl.float32)
        cat_x = insert_slice(
            cat_x,
            -x2,
            offsets=(0, 0),
            sizes=(num_q_heads, half_rope_dim),
            strides=(1, 1),
        )
        cat_x = insert_slice(
            cat_x,
            x1,
            offsets=(0, half_rope_dim),
            sizes=(num_q_heads, half_rope_dim),
            strides=(1, 1),
        )
        if IS_PARTIAL_ROPE:
            orig_qk = extract_slice(
                q_normalized,
                offsets=(0, 0),
                sizes=(num_q_heads, rope_dim),
                strides=(1, 1),
            )
        else:
            orig_qk = q_normalized
        roped_q = cat_x * sin_tensor + orig_qk * cos_tensor

        # k-mrope
        y1 = extract_slice(
            k_normalized,
            offsets=(0, 0),
            sizes=(num_kv_heads, half_rope_dim),
            strides=(1, 1),
        )
        y2 = extract_slice(
            k_normalized,
            offsets=(0, half_rope_dim),
            sizes=(num_kv_heads, half_rope_dim),
            strides=(1, 1),
        )
        cat_y = tl.zeros((num_kv_heads, rope_dim), dtype=tl.float32)
        cat_y = insert_slice(
            cat_y,
            -y2,
            offsets=(0, 0),
            sizes=(num_kv_heads, half_rope_dim),
            strides=(1, 1),
        )
        cat_y = insert_slice(
            cat_y,
            y1,
            offsets=(0, half_rope_dim),
            sizes=(num_kv_heads, half_rope_dim),
            strides=(1, 1),
        )
        if IS_PARTIAL_ROPE:
            orig_qk = extract_slice(
                k_normalized,
                offsets=(0, 0),
                sizes=(num_kv_heads, rope_dim),
                strides=(1, 1),
            )
        else:
            orig_qk = k_normalized
        roped_k = cat_y * sin_tensor + orig_qk * cos_tensor

        if IS_PARTIAL_ROPE:
            q_normalized = insert_slice(
                q_normalized,
                roped_q,
                offsets=(0, 0),
                sizes=(num_q_heads, rope_dim),
                strides=(1, 1),
            )
            k_normalized = insert_slice(
                k_normalized,
                roped_k,
                offsets=(0, 0),
                sizes=(num_kv_heads, rope_dim),
                strides=(1, 1),
            )
        else:
            q_normalized = roped_q
            k_normalized = roped_k

        ## store ##
        # out_q
        out_q_offset = out_q_ptr + (block_offset + index) * q_size
        out_q_indices = tl.arange(0, q_size)
        tl.store(out_q_offset + out_q_indices, q_normalized.reshape(q_size))

        # out_k
        out_k_offset = out_k_ptr + (block_offset + index) * kv_size
        out_k_indices = tl.arange(0, kv_size)
        tl.store(out_k_offset + out_k_indices, k_normalized.reshape(kv_size))

        # out_v
        out_v_offset = out_v_ptr + (block_offset + index) * kv_size
        tl.store(out_v_offset + tl.arange(0, kv_size), in_v_tensor)

        # out_gate
        if gate_size > 0:
            out_gate_offset = out_gate_ptr + (block_offset + index) * gate_size
            tl.store(out_gate_offset + tl.arange(0, gate_size), in_gate_tensor)


def test_split_qkv_rmsnorm_mrope_kernel():
    num_tokens = 8
    core_num = 4
    # 缩小 shape 避免 UB overflow：
    #   head_size 256 -> 64, num_q_heads 16 -> 8, rope_dim 64 -> 32
    # q_size 从 4096 降到 512，gate_size 同步降到 512，
    # 循环体内同时驻留的 fp32 张量规模降到原来的 1/8 左右。
    num_q_heads = 8
    num_kv_heads = 2
    head_size = 64
    rope_dim = 32
    half_rope_dim = rope_dim // 2
    # mrope_section 三者之和必须等于 half_rope_dim (=16)
    mrope_section = [6, 5, 5]
    eps = 1e-6
    is_interleaved = True
    has_gate = True
    has_bias = False

    q_size = num_q_heads * head_size
    kv_size = num_kv_heads * head_size
    gate_size = q_size if has_gate else 0
    IS_PARTIAL_ROPE = rope_dim != head_size

    front_core_num = num_tokens % core_num
    num_tokens_each_front_core = (num_tokens + core_num - 1) // core_num
    tail_core_num = core_num - front_core_num
    num_tokens_each_tail_core = num_tokens // core_num
    total_core = front_core_num + tail_core_num
    block_dim = total_core if total_core < core_num else core_num

    torch.manual_seed(0)
    qkv = (torch.randn(num_tokens, q_size + gate_size + 2 * kv_size, dtype=torch.float32) * 0.5).to(torch.float16)
    q_weight = torch.randn(head_size, dtype=torch.float32).abs() + 0.5
    k_weight = torch.randn(head_size, dtype=torch.float32).abs() + 0.5
    q_bias = None
    k_bias = None
    cos_sin = torch.zeros(3, num_tokens, rope_dim, dtype=torch.float32)
    theta = torch.linspace(0, 1.5, rope_dim // 2, dtype=torch.float32)
    for p in range(3):
        cos_sin[p, :, : half_rope_dim] = torch.cos(theta + p * 0.1)
        cos_sin[p, :, half_rope_dim:] = torch.sin(theta + p * 0.1)
    cos_sin = cos_sin.half().contiguous()

    qkv = qkv.npu().contiguous()
    q_weight = q_weight.npu().half().contiguous()
    k_weight = k_weight.npu().half().contiguous()
    cos_sin = cos_sin.npu().contiguous()

    q_output = torch.empty(num_tokens, q_size, device="npu", dtype=qkv.dtype)
    k_output = torch.empty(num_tokens, kv_size, device="npu", dtype=qkv.dtype)
    v_output = torch.empty(num_tokens, kv_size, device="npu", dtype=qkv.dtype)
    gate_output = torch.empty(num_tokens, gate_size, device="npu", dtype=qkv.dtype)

    print("=== launch kernel ===")
    print(f"num_tokens={num_tokens} block_dim={block_dim} core_num={core_num}")
    print(f"front_core_num={front_core_num} each_front={num_tokens_each_front_core} each_tail={num_tokens_each_tail_core}")
    print(f"q_size={q_size} kv_size={kv_size} gate_size={gate_size} rope_dim={rope_dim} IS_PARTIAL_ROPE={IS_PARTIAL_ROPE}")
    print(f"qkv={tuple(qkv.shape)} cos_sin={tuple(cos_sin.shape)}")

    split_qkv_rmsnorm_mrope_kernel[(block_dim,)](
        qkv,
        q_weight,
        q_bias,
        k_weight,
        k_bias,
        cos_sin,
        q_output,
        k_output,
        v_output,
        gate_output,
        num_tokens,
        front_core_num,
        num_tokens_each_front_core,
        num_tokens_each_tail_core,
        num_q_heads,
        num_kv_heads,
        head_size,
        q_size,
        kv_size,
        eps,
        mrope_section[0],
        mrope_section[1],
        mrope_section[2],
        has_bias,
        is_interleaved,
        rope_dim,
        half_rope_dim,
        IS_PARTIAL_ROPE,
        gate_size,
    )
    torch.npu.synchronize()
    print("kernel done")
    print("q[0,:4]=", q_output.cpu()[0, :4].tolist())
    print("k[0,:4]=", k_output.cpu()[0, :4].tolist())
    print("v[0,:4]=", v_output.cpu()[0, :4].tolist())
    print("gate[0,:4]=", gate_output.cpu()[0, :4].tolist())

    print("=== reference check ===")
    qkv_c = qkv.float().cpu()
    qw_c = q_weight.float().cpu()
    kw_c = k_weight.float().cpu()
    cs_c = cos_sin.float().cpu()

    offs = torch.arange(half_rope_dim)
    h_mask = ((offs % 3) == 1) & (offs <= 3 * mrope_section[1])
    w_mask = ((offs % 3) == 2) & (offs <= 3 * mrope_section[2])
    t_mask = ~(h_mask | w_mask)
    cos_plane = cs_c[0, :, :half_rope_dim] * t_mask[None, :] + cs_c[1, :, :half_rope_dim] * h_mask[None, :] + cs_c[2, :, :half_rope_dim] * w_mask[None, :]
    sin_plane = cs_c[0, :, half_rope_dim:] * t_mask[None, :] + cs_c[1, :, half_rope_dim:] * h_mask[None, :] + cs_c[2, :, half_rope_dim:] * w_mask[None, :]
    cos_full = cos_plane[:, None, :].expand(num_tokens, 2, half_rope_dim).reshape(num_tokens, rope_dim)
    sin_full = sin_plane[:, None, :].expand(num_tokens, 2, half_rope_dim).reshape(num_tokens, rope_dim)

    q_ref = torch.empty(num_tokens, q_size, dtype=torch.float32)
    k_ref = torch.empty(num_tokens, kv_size, dtype=torch.float32)
    v_ref = torch.empty(num_tokens, kv_size, dtype=torch.float32)
    gate_ref = torch.empty(num_tokens, gate_size, dtype=torch.float32)

    for t in range(num_tokens):
        qg = qkv_c[t, : q_size + gate_size].reshape(num_q_heads, head_size * 2)
        q_row = qg[:, :head_size]
        gate_row = qg[:, head_size:].reshape(q_size)
        k_row = qkv_c[t, q_size + gate_size : q_size + gate_size + kv_size].reshape(num_kv_heads, head_size)
        v_row = qkv_c[t, q_size + gate_size + kv_size : q_size + gate_size + 2 * kv_size]

        q_n = q_row / torch.sqrt((q_row * q_row).sum(1, keepdim=True) / head_size + eps) * qw_c[None, :]
        k_n = k_row / torch.sqrt((k_row * k_row).sum(1, keepdim=True) / head_size + eps) * kw_c[None, :]

        qx1 = q_n[:, :half_rope_dim]
        qx2 = q_n[:, half_rope_dim:rope_dim]
        qcat = torch.zeros(num_q_heads, rope_dim, dtype=torch.float32)
        qcat[:, :half_rope_dim] = -qx2
        qcat[:, half_rope_dim:] = qx1
        q_roped = qcat * sin_full[t][None, :] + q_n[:, :rope_dim] * cos_full[t][None, :]
        q_n = q_n.clone()
        q_n[:, :rope_dim] = q_roped

        kx1 = k_n[:, :half_rope_dim]
        kx2 = k_n[:, half_rope_dim:rope_dim]
        kcat = torch.zeros(num_kv_heads, rope_dim, dtype=torch.float32)
        kcat[:, :half_rope_dim] = -kx2
        kcat[:, half_rope_dim:] = kx1
        k_roped = kcat * sin_full[t][None, :] + k_n[:, :rope_dim] * cos_full[t][None, :]
        k_n = k_n.clone()
        k_n[:, :rope_dim] = k_roped

        q_ref[t] = q_n.reshape(q_size)
        k_ref[t] = k_n.reshape(kv_size)
        v_ref[t] = v_row
        gate_ref[t] = gate_row

    qc = q_output.float().cpu()
    kc = k_output.float().cpu()
    vc = v_output.float().cpu()
    gc = gate_output.float().cpu()
    dq = (qc - q_ref).abs()
    dk = (kc - k_ref).abs()
    dv = (vc - v_ref).abs()
    dg = (gc - gate_ref).abs()
    print(f"q max_abs_diff={dq.max().item():.6e}")
    print(f"k max_abs_diff={dk.max().item():.6e}")
    print(f"v max_abs_diff={dv.max().item():.6e}")
    print(f"gate max_abs_diff={dg.max().item():.6e}")
    print(f"q allclose={torch.allclose(qc, q_ref, atol=1e-2, rtol=1e-2)}")
    print(f"k allclose={torch.allclose(kc, k_ref, atol=1e-2, rtol=1e-2)}")
    print(f"v allclose={torch.allclose(vc, v_ref, atol=1e-2, rtol=1e-2)}")
    print(f"gate allclose={torch.allclose(gc, gate_ref, atol=1e-2, rtol=1e-2)}")
    ok = (
        dq.max().item() < 1e-2
        and dk.max().item() < 1e-2
        and dv.max().item() < 1e-2
        and dg.max().item() < 1e-2
    )
    assert ok, f"qkv diff too large: q={dq.max().item():.6e} k={dk.max().item():.6e} v={dv.max().item():.6e} g={dg.max().item():.6e}"
    print("RESULT: PASS")


if __name__ == "__main__":
    test_split_qkv_rmsnorm_mrope_kernel()
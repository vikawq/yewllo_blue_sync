# Copyright (c) 2025 Huawei Technologies Co., Ltd. All Rights Reserved.
# This file is a part of the vllm-ascend project.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

import torch
import torch_npu
import triton
import triton.language as tl


@triton.jit
def _build_final_chunk_indices_kernel(
    update_chunk_offsets_ptr,
    out_final_chunk_indices_ptr,
    num_seqs,
    BLOCK_SIZE: tl.constexpr,
):
    pid = tl.program_id(0)
    offsets = pid * BLOCK_SIZE + tl.arange(0, BLOCK_SIZE)
    mask = offsets < num_seqs
    final_indices = (
        tl.load(update_chunk_offsets_ptr + offsets + 1, mask=mask, other=0).to(tl.int32)
        - 1
    )
    tl.store(
        out_final_chunk_indices_ptr + offsets,
        final_indices.to(out_final_chunk_indices_ptr.dtype.element_ty),
        mask=mask,
    )


def test_build_final_chunk_indices_kernel():
    n, block = (20, 256)
    lengths = torch.arange(n, dtype=torch.int32) % 4 + 1
    offsets = torch.cat([torch.zeros(1, dtype=torch.int32), lengths.cumsum(0).int()])
    initial = torch.full((n + 4,), -99, dtype=torch.int32)
    out = initial.npu()
    _build_final_chunk_indices_kernel[1,](offsets.npu(), out, n, BLOCK_SIZE=block)
    actual = out.cpu()
    actual_indices = actual[:n].cpu()
    expected_indices = offsets[1:] - 1
    expected_indices = expected_indices.to(actual_indices.dtype)
    torch.testing.assert_close(
        actual_indices, expected_indices, atol=0, rtol=0, check_dtype=False
    )
    assert (
        torch.isfinite(actual_indices).all() and torch.isfinite(expected_indices).all()
    )
    actual_tail_guard = actual[n:].cpu()
    expected_tail_guard = initial[n:]
    expected_tail_guard = expected_tail_guard.to(actual_tail_guard.dtype)
    torch.testing.assert_close(
        actual_tail_guard, expected_tail_guard, atol=0, rtol=0, check_dtype=False
    )
    assert (
        torch.isfinite(actual_tail_guard).all()
        and torch.isfinite(expected_tail_guard).all()
    )
    print("PASS: _build_final_chunk_indices_kernel")


if __name__ == "__main__":
    test_build_final_chunk_indices_kernel()

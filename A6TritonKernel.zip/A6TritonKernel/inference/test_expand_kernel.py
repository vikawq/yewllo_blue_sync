# -*- coding: utf-8 -*-
import os
import sys
import types
import time
import traceback

os.environ.setdefault("TRITON_BACKENDS_IN_TREE", "1")
os.environ.setdefault("TRITON_BACKEND", "opentile")
os.environ.setdefault("TRITON_ALWAYS_COMPILE", "1")

import triton
import triton.language as tl
import torch

_vllm_utils = types.ModuleType("vllm.triton_utils")
_vllm_utils.tl = tl
_vllm_utils.triton = triton
_vllm_utils.tldevice = types.SimpleNamespace(
    fast_dividef=lambda x, y: x / y,
    fast_expf=tl.exp,
    fast_logf=tl.log,
    fast_log2f=tl.log2,
)
_vllm_pkg = types.ModuleType("vllm")
_vllm_pkg.triton_utils = _vllm_utils
sys.modules.setdefault("vllm", _vllm_pkg)
sys.modules["vllm.triton_utils"] = _vllm_utils
sys.modules["vllm"].triton_utils = _vllm_utils

_math_pkg = types.ModuleType("vllm.utils")
sys.modules.setdefault("vllm.utils", _math_pkg)
_math_mod = types.ModuleType("vllm.utils.math_utils")
sys.modules["vllm.utils.math_utils"] = _math_mod



def next_power_of_2(n: int) -> int:
    if n <= 0:
        return 1
    return 1 << (n - 1).bit_length()


VECTORCORE_NUM = 32


def get_vectorcore_num() -> int:
    return VECTORCORE_NUM


@triton.jit
def get_element(data, index):
    idx = index[0]
    n: tl.constexpr = data.shape[0]
    mask = tl.arange(0, n) == idx
    return tl.sum(tl.where(mask, data.to(tl.int32), 0))


@triton.jit(do_not_specialize=["replace_from", "replace_to", "vec_len"])
def expand_kernel(
    output_ptr,  # [num_tokens]
    input_ptr,  # [batch_size]
    cu_num_tokens_ptr,  # [batch_size]
    replace_from,
    replace_to,
    vec_len,
    MAX_NUM_TOKENS: tl.constexpr,
    BLOCK_SIZE: tl.constexpr,
):
    req_idx = tl.program_id(0)
    offset = req_idx * BLOCK_SIZE + tl.arange(0, BLOCK_SIZE)
    len_mask = offset < vec_len

    # Mask the load itself: tl.where does not prevent reading before the
    # buffer start (both arms are always evaluated), so lane offset == 0 must
    # be masked out at the load. other=0 keeps num_tokens deterministic (0)
    # for out-of-range lanes, which the store mask below relies on.
    start_idx = tl.load(cu_num_tokens_ptr + offset - 1, mask=len_mask & (offset > 0), other=0)
    end_idx = tl.load(cu_num_tokens_ptr + offset, len_mask, other=0)
    num_tokens = end_idx - start_idx

    src_val = tl.load(input_ptr + offset, len_mask)
    src_val = tl.where(src_val == replace_from, replace_to, src_val)

    for i in tl.range(0, BLOCK_SIZE):
        num_tokens1 = get_element(num_tokens, (i,))
        start_idx1 = get_element(start_idx, (i,))
        src_val1 = get_element(src_val, (i,))
        offset1 = tl.arange(0, MAX_NUM_TOKENS)
        tl.store(output_ptr + start_idx1 + offset1, src_val1, mask=offset1 < num_tokens1)

RESULT = "/tmp/rs_expand_res.txt"


def append(line):
    with open(RESULT, "a") as f:
        f.write(line + "\n")


def done(stat, case, t0, msg=""):
    line = f"[{stat}] {case} elapsed={time.time() - t0:.1f}s {msg}"
    print(line, flush=True)
    append(line)
    sys.stdout.flush()
    if stat != "OK":
        raise AssertionError(line)


def check(name, cond, detail=""):
    if not cond:
        raise AssertionError(f"{name} failed {detail}")
    print(f"  check {name} PASS {detail}", flush=True)




def run_expand(x, cu, replace_from, replace_to, max_num_tokens, grid, block):
    # x: [batch_size] per-request src value; cu: [batch_size] closed-token counts
    batch_size = x.shape[0]
    ex = torch.full([int(cu[-1].cpu())], -1, dtype=torch.int32, device=cu.device)
    expand_kernel[(grid,)](
        ex, x, cu, replace_from, replace_to, batch_size,
        MAX_NUM_TOKENS=max_num_tokens, BLOCK_SIZE=block, num_warps=1,
    )
    return ex.cpu().tolist()


def case_expand():
    dev = "npu"
    # batch=1, single token, no replace
    got = run_expand(
        torch.tensor([5], dtype=torch.int32, device=dev),
        torch.tensor([1], dtype=torch.int64, device=dev), 0, 1, 8, 1, 1)
    check("expand no-replace", got == [5], str(got))

    # batch=1, single token, replace 0->1
    got2 = run_expand(
        torch.tensor([0], dtype=torch.int32, device=dev),
        torch.tensor([1], dtype=torch.int64, device=dev), 0, 1, 8, 1, 1)
    check("expand replace 0->1", got2 == [1], str(got2))

    # batch=1, request yields 2 tokens: src value repeated twice
    got3 = run_expand(
        torch.tensor([3], dtype=torch.int32, device=dev),
        torch.tensor([2], dtype=torch.int64, device=dev), 0, 1, 8, 1, 1)
    check("expand batch1 len2", got3 == [3, 3], str(got3))

    # batch=2, request0 has 1 token (10), request1 has 2 tokens (20)
    got4 = run_expand(
        torch.tensor([10, 20], dtype=torch.int32, device=dev),
        torch.tensor([1, 3], dtype=torch.int64, device=dev), 0, 1, 8, 2, 1)
    check("expand batch2", got4 == [10, 20, 20], str(got4))

    # batch=2 with replace: request0=0->1, request1=9 (kept), total=2 tokens
    got5 = run_expand(
        torch.tensor([0, 9], dtype=torch.int32, device=dev),
        torch.tensor([1, 2], dtype=torch.int64, device=dev), 0, 1, 8, 2, 1)
    check("expand batch2 replace", got5 == [1, 9], str(got5))



def test_expand_kernel():
    if not torch.npu.is_available():
        raise AssertionError("npu NOT available, abort")
    print(f"triton={__import__('triton').__version__} torch={torch.__version__}", flush=True)
    t0 = time.time()
    case_expand()
    done("OK", "expand", t0)


if __name__ == "__main__":
    test_expand_kernel()

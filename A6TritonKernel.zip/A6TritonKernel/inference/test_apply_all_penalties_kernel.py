# SPDX-License-Identifier: Apache-2.0
# SPDX-FileCopyrightText: Copyright contributors to the vLLM project
#
# Copyright (c) 2025 Huawei Technologies Co., Ltd. All Rights Reserved.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
# This file is a part of the vllm-ascend project.
#
# Triton-Ascend implementation of apply_penalties.
# Migrated from model_executor/layers/utils.apply_penalties.
# Reference: https://github.com/vllm-project/vllm-ascend/pull/6979

import torch
import torch_npu
import triton
import triton.language as tl


@triton.jit(do_not_specialize=["num_seqs"])
def apply_all_penalties_kernel(
    logits_ptr,
    prompt_mask_ptr,
    output_mask_ptr,
    output_bin_counts_ptr,
    repetition_penalties_ptr,
    frequency_penalties_ptr,
    presence_penalties_ptr,
    num_seqs,
    vocab_size,
    stride_logits_seq,
    stride_logits_vocab,
    stride_prompt_mask_seq,
    stride_prompt_mask_vocab,
    stride_output_mask_seq,
    stride_output_mask_vocab,
    stride_bin_counts_seq,
    stride_bin_counts_vocab,
    BLOCK_SIZE: tl.constexpr,
):
    """Apply repetition, frequency, and presence penalties to logits in place."""
    pid = tl.program_id(axis=0)
    num_programs = tl.num_programs(axis=0)
    seqs_per_program = (num_seqs + num_programs - 1) // num_programs
    start_seq = pid * seqs_per_program
    end_seq = tl.minimum(start_seq + seqs_per_program, num_seqs)
    for seq_idx in range(start_seq, end_seq):
        repetition_penalty = tl.load(repetition_penalties_ptr + seq_idx)
        frequency_penalty = tl.load(frequency_penalties_ptr + seq_idx)
        presence_penalty = tl.load(presence_penalties_ptr + seq_idx)
        for vocab_start in range(0, vocab_size, BLOCK_SIZE):
            vocab_offsets = vocab_start + tl.arange(0, BLOCK_SIZE)
            mask = vocab_offsets < vocab_size
            logits_offset = (
                seq_idx * stride_logits_seq + vocab_offsets * stride_logits_vocab
            )
            prompt_mask_offset = (
                seq_idx * stride_prompt_mask_seq
                + vocab_offsets * stride_prompt_mask_vocab
            )
            output_mask_offset = (
                seq_idx * stride_output_mask_seq
                + vocab_offsets * stride_output_mask_vocab
            )
            counts_offset = (
                seq_idx * stride_bin_counts_seq
                + vocab_offsets * stride_bin_counts_vocab
            )
            logits = tl.load(logits_ptr + logits_offset, mask=mask, other=0.0)
            prompt_mask_val = tl.load(
                prompt_mask_ptr + prompt_mask_offset, mask=mask, other=False
            )
            output_mask_val = tl.load(
                output_mask_ptr + output_mask_offset, mask=mask, other=False
            )
            output_bin_counts = tl.load(
                output_bin_counts_ptr + counts_offset, mask=mask, other=0
            ).to(tl.float32)
            need_repetition_penalty = (prompt_mask_val | output_mask_val).to(tl.int1)
            penalty_factor = tl.where(need_repetition_penalty, repetition_penalty, 1.0)
            scaling = tl.where(
                (logits > 0.0).to(tl.int1), 1.0 / penalty_factor, penalty_factor
            )
            updated = logits * scaling
            updated -= frequency_penalty * output_bin_counts
            updated -= presence_penalty * output_mask_val.to(tl.float32)
            tl.store(logits_ptr + logits_offset, updated, mask=mask)


def test_apply_all_penalties_kernel():
    n, vocab, block = (1, 248320, 2048)
    positions = torch.arange(vocab).reshape(n, vocab)
    logits = ((positions % 101).float() - 50) / 10
    prompt = positions % 3 == 0
    output = positions % 5 == 0
    counts = torch.where(output, (positions % 4 + 1).int(), 0)
    repeat = torch.tensor([1.2])
    frequency = torch.tensor([0.3])
    presence = torch.tensor([0.4])
    actual = logits.npu()
    apply_all_penalties_kernel[1,](
        actual,
        prompt.npu(),
        output.npu(),
        counts.npu(),
        repeat.npu(),
        frequency.npu(),
        presence.npu(),
        n,
        vocab,
        vocab,
        1,
        vocab,
        1,
        vocab,
        1,
        vocab,
        1,
        BLOCK_SIZE=block,
    )
    factor = torch.where(prompt | output, repeat[:, None], 1.0)
    expected = (
        torch.where(logits > 0, logits / factor, logits * factor)
        - frequency[:, None] * counts
        - presence[:, None] * output
    )
    actual_logits = actual.cpu()
    expected_logits = expected
    expected_logits = expected_logits.to(actual_logits.dtype)
    torch.testing.assert_close(
        (actual_logits).float(),
        (expected_logits).float(),
        atol=1e-05,
        rtol=1e-05,
        check_dtype=False,
    )
    assert torch.isfinite(actual_logits).all() and torch.isfinite(expected_logits).all()
    print("PASS: apply_all_penalties_kernel")


if __name__ == "__main__":
    test_apply_all_penalties_kernel()

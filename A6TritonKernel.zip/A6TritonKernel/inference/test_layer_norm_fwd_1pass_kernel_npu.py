# Adapt from https://github.com/fla-org/flash-linear-attention/blob/main/fla/modules/layernorm_gated.py
# Copyright (c) 2024, Tri Dao.
# Based on the Triton LayerNorm tutorial: https://triton-lang.org/main/getting-started/tutorials/05-layer-norm.html
# For the backward pass, we keep weight_grad and bias_grad in registers and accumulate.
# This backward pass is faster for dimensions up to 8k, but after that it's much slower due to register spilling.
# The models we train have hidden dim up to 8k anyway (e.g. Llama 70B), so this is fine.
# mypy: ignore-errors

import torch
import torch_npu
import triton
import triton.language as tl


@triton.heuristics({"HAS_BIAS": lambda args: args["B"] is not None})
@triton.heuristics({"HAS_Z": lambda args: args["Z"] is not None})
@triton.jit(
    do_not_specialize=["stride_x_row", "stride_y_row", "stride_z_row", "M", "N", "eps"]
)
def _layer_norm_fwd_1pass_kernel_npu(
    X,
    Y,
    W,
    B,
    Z,
    Mean,
    Rstd,
    stride_x_row,
    stride_y_row,
    stride_z_row,
    M,
    N,
    eps,
    BLOCK_M: tl.constexpr,
    BLOCK_N: tl.constexpr,
    HAS_BIAS: tl.constexpr,
    HAS_Z: tl.constexpr,
    NORM_BEFORE_GATE: tl.constexpr,
    IS_RMS_NORM: tl.constexpr,
):
    pid_m = tl.program_id(0)
    group = tl.program_id(1)
    if not IS_RMS_NORM:
        Mean += group * M
    Rstd += group * M
    W += group * N
    if HAS_BIAS:
        B += group * N
    rows = pid_m * BLOCK_M + tl.arange(0, BLOCK_M)
    cols = tl.arange(0, BLOCK_N)
    row_mask = rows < M
    col_mask = cols < N
    w = tl.load(W + cols, mask=col_mask).to(tl.float32)
    if HAS_BIAS:
        b = tl.load(B + cols, mask=col_mask).to(tl.float32)
    x_ptrs = X + rows[:, None] * stride_x_row + cols[None, :] + group * N
    x = tl.load(x_ptrs, mask=row_mask[:, None] & col_mask[None, :]).to(tl.float32)
    if HAS_Z:
        z_ptrs = Z + rows[:, None] * stride_z_row + cols[None, :] + group * N
        z = tl.load(z_ptrs, mask=row_mask[:, None] & col_mask[None, :]).to(tl.float32)
        if not NORM_BEFORE_GATE:
            x *= z * tl.sigmoid(z)
    if not IS_RMS_NORM:
        mean = tl.sum(x, axis=1) / N
        xbar = tl.where(col_mask[None, :], x - mean[:, None], 0.0)
        var = tl.sum(xbar * xbar, axis=1) / N
        tl.store(Mean + rows, mean, mask=row_mask)
    else:
        xbar = tl.where(col_mask[None, :], x, 0.0)
        var = tl.sum(xbar * xbar, axis=1) / N
    rstd = 1.0 / tl.sqrt(var + eps)
    tl.store(Rstd + rows, rstd, mask=row_mask)
    if not IS_RMS_NORM:
        x_hat = (x - mean[:, None]) * rstd[:, None]
    else:
        x_hat = x * rstd[:, None]
    y = x_hat * w[None, :]
    if HAS_BIAS:
        y += b[None, :]
    if HAS_Z and NORM_BEFORE_GATE:
        y *= z * tl.sigmoid(z)
    y_ptrs = Y + rows[:, None] * stride_y_row + cols[None, :] + group * N
    tl.store(y_ptrs, y, mask=row_mask[:, None] & col_mask[None, :])


def test_layer_norm_fwd_1pass_kernel_npu():
    generator = torch.Generator().manual_seed(20261009)
    m, n, bm = (5, 128, 64)
    x, z, w = (
        torch.randn((m, n), generator=generator).to(torch.float16),
        torch.randn((m, n), generator=generator).to(torch.float16),
        torch.randn((n,), generator=generator).to(torch.float16),
    )
    yi = torch.full((bm, n), 23.0, dtype=x.dtype)
    ri = torch.full((bm,), 23.0, dtype=torch.float32)
    yn, rn = (yi.npu(), ri.npu())
    _layer_norm_fwd_1pass_kernel_npu[1, 1](
        x.npu(),
        yn,
        w.npu(),
        None,
        z.npu(),
        None,
        rn,
        n,
        n,
        n,
        m,
        n,
        1e-06,
        BLOCK_M=bm,
        BLOCK_N=n,
        HAS_BIAS=False,
        HAS_Z=True,
        NORM_BEFORE_GATE=True,
        IS_RMS_NORM=True,
    )
    rstd = torch.rsqrt(x.float().square().mean(-1) + 1e-06)
    y = x.float() * rstd[:, None] * w.float() * z.float() * torch.sigmoid(z.float())
    actual = yn.cpu()
    rs = rn.cpu()
    actual_output = actual[:m].cpu()
    expected_output = y
    expected_output = expected_output.to(actual_output.dtype)
    torch.testing.assert_close(
        (actual_output).float(),
        (expected_output).float(),
        atol=0.001,
        rtol=0.003,
        check_dtype=False,
    )
    assert torch.isfinite(actual_output).all() and torch.isfinite(expected_output).all()
    actual_rstd = rs[:m].cpu()
    expected_rstd = rstd
    expected_rstd = expected_rstd.to(actual_rstd.dtype)
    torch.testing.assert_close(
        (actual_rstd).float(),
        (expected_rstd).float(),
        atol=1e-05,
        rtol=0.0001,
        check_dtype=False,
    )
    assert torch.isfinite(actual_rstd).all() and torch.isfinite(expected_rstd).all()
    actual_output_tail_guard = actual[m:].cpu()
    expected_output_tail_guard = yi[m:]
    expected_output_tail_guard = expected_output_tail_guard.to(
        actual_output_tail_guard.dtype
    )
    torch.testing.assert_close(
        (actual_output_tail_guard).float(),
        (expected_output_tail_guard).float(),
        atol=0,
        rtol=0,
        check_dtype=False,
    )
    assert (
        torch.isfinite(actual_output_tail_guard).all()
        and torch.isfinite(expected_output_tail_guard).all()
    )
    actual_rstd_tail_guard = rs[m:].cpu()
    expected_rstd_tail_guard = ri[m:]
    expected_rstd_tail_guard = expected_rstd_tail_guard.to(actual_rstd_tail_guard.dtype)
    torch.testing.assert_close(
        (actual_rstd_tail_guard).float(),
        (expected_rstd_tail_guard).float(),
        atol=0,
        rtol=0,
        check_dtype=False,
    )
    assert (
        torch.isfinite(actual_rstd_tail_guard).all()
        and torch.isfinite(expected_rstd_tail_guard).all()
    )
    print("PASS: _layer_norm_fwd_1pass_kernel_npu")


if __name__ == "__main__":
    test_layer_norm_fwd_1pass_kernel_npu()

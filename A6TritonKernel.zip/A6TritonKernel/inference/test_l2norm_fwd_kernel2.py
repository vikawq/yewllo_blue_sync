# SPDX-License-Identifier: Apache-2.0
# SPDX-FileCopyrightText: Copyright contributors to the vLLM project
# SPDX-FileCopyrightText: Songlin Yang, Yu Zhang
#
# This file contains code copied from the flash-linear-attention project.
# The original source code was licensed under the MIT license and included
# the following copyright notice:
# Copyright (c) 2023-2025, Songlin Yang, Yu Zhang

import torch
import torch_npu
import triton
import triton.language as tl


@triton.jit
def l2norm_fwd_kernel2(
    X, Y, eps, M, N: tl.constexpr, BD: tl.constexpr, MBLOCK: tl.constexpr
):
    xoffset = tl.program_id(0) * MBLOCK
    row_idx = xoffset + tl.arange(0, MBLOCK)[:, None]
    xmask = row_idx < M
    rindex = tl.arange(0, BD)[None, :]
    cmask = rindex < N
    mask = xmask & cmask
    xs = tl.load(X + (rindex + N * row_idx), mask, other=0.0).to(tl.float32)
    square = tl.broadcast_to(xs * xs, [MBLOCK, BD])
    square_sum = tl.sum(tl.where(xmask, square, 0), 1)[:, None]
    rsqrt = tl.rsqrt(square_sum + eps)
    tl.store(Y + (rindex + N * row_idx), xs * rsqrt, mask)


def test_l2norm_fwd_kernel2():
    m, n, block_m, block_d = (5, 128, 32, 128)
    eps = 1e-06
    generator = torch.Generator().manual_seed(20261008)
    x_cpu = torch.randn(m, n, generator=generator).to(torch.float16)
    x_cpu[0].zero_()
    x_cpu[1] *= 0.001
    sentinel = 23.0
    y_initial = torch.full((block_m, n), sentinel, dtype=x_cpu.dtype)
    x, storage = (x_cpu.npu(), y_initial.npu())
    l2norm_fwd_kernel2[1,](x, storage, eps, m, n, block_d, block_m)
    actual_storage = storage.cpu()
    actual = actual_storage[:m]
    x_fp32 = x_cpu.float()
    expected = (
        x_fp32 * torch.rsqrt((x_fp32 * x_fp32).sum(dim=1, keepdim=True) + eps)
    ).to(x_cpu.dtype)
    atol, rtol = (0.0005, 0.002)
    guards_ok = torch.equal(actual_storage[m:], y_initial[m:])
    torch.testing.assert_close(
        (actual).float(), (expected).float(), atol=atol, rtol=rtol
    )
    assert torch.isfinite(actual).all()
    assert (actual[0] == 0).all()
    assert guards_ok
    print("PASS: l2norm_fwd_kernel2")


if __name__ == "__main__":
    test_l2norm_fwd_kernel2()

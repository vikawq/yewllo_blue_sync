import os
import sys
import types

os.environ.setdefault("TRITON_BACKENDS_IN_TREE", "1")
os.environ.setdefault("TRITON_BACKEND", "opentile")
# 强制走编译缓存，避免同一特化重复编译导致“一直跑不完”。
os.environ["TRITON_ALWAYS_COMPILE"] = "0"

import triton
import triton.language as tl

import torch
import numpy as np

vllm_utils = types.ModuleType("vllm.triton_utils")
vllm_utils.tl = tl
vllm_utils.triton = triton
sys.modules.setdefault("vllm", types.ModuleType("vllm"))
sys.modules["vllm.triton_utils"] = vllm_utils
sys.modules["vllm"].triton_utils = vllm_utils

try:
    from triton.backends.ascend import compiler as C

    _orig = C.linalg_to_bin_enable_npu_compile_910_95

    def _compile_with_nolicm(linalg, metadata, opt):
        bo = metadata.get("bisheng_options")
        if bo and "-disable-machine-licm" not in bo:
            metadata["bisheng_options"] = bo + " -mllvm -disable-machine-licm"
        return _orig(linalg, metadata, opt)

    C.linalg_to_bin_enable_npu_compile_910_95 = _compile_with_nolicm
except Exception:
    pass

if not (hasattr(torch, "npu") and torch.npu.is_available()):
    raise RuntimeError("no NPU device available")

pkg = types.ModuleType("csum_pkg")
utils_mod = types.ModuleType("csum_pkg.utils")


def prepare_chunk_indices(cu_seqlens, chunk_size=64):
    cu = cu_seqlens.cpu().tolist() if isinstance(cu_seqlens, torch.Tensor) else list(cu_seqlens)
    inds = []
    for s in range(len(cu) - 1):
        seq_len = cu[s + 1] - cu[s]
        n = (seq_len + chunk_size - 1) // chunk_size
        for c in range(n):
            inds.append((s, c))
    return torch.tensor(inds, dtype=torch.int32)


utils_mod.prepare_chunk_indices = prepare_chunk_indices
pkg.utils = utils_mod
sys.modules["csum_pkg"] = pkg
sys.modules["csum_pkg.utils"] = utils_mod

@triton.heuristics(
    {"HAS_SCALE": lambda args: args["scale"] is not None, "IS_VARLEN": lambda args: args["cu_seqlens"] is not None}
)
@triton.jit(do_not_specialize=["T"])
def chunk_local_cumsum_scalar_kernel(
    s,
    o,
    scale,
    cu_seqlens,
    chunk_indices,
    T,
    H: tl.constexpr,
    BLOCK_T: tl.constexpr,
    REVERSE: tl.constexpr,
    HAS_SCALE: tl.constexpr,
    IS_VARLEN: tl.constexpr,
    HEAD_FIRST: tl.constexpr,
    CHUNK_SIZE: tl.constexpr = 64,
    OUT_DTYPE: tl.constexpr = tl.float32,
):
    i_block, i_b = tl.program_id(0), tl.program_id(1)
    N_CHUNKS: tl.constexpr = BLOCK_T // CHUNK_SIZE

    if IS_VARLEN:
        i_s, i_block = (
            tl.load(chunk_indices + i_block * 2).to(tl.int32),
            tl.load(chunk_indices + i_block * 2 + 1).to(tl.int32),
        )
        bos, eos = tl.load(cu_seqlens + i_s).to(tl.int32), tl.load(cu_seqlens + i_s + 1).to(tl.int32)
        T = eos - bos
    else:
        bos, eos = i_b * T, i_b * T + T

    if HEAD_FIRST:
        ptr_s = tl.make_block_ptr(s + bos * H, (H, T), (T, 1), (0, i_block * BLOCK_T), (H, BLOCK_T), (1, 0))
        ptr_o = tl.make_block_ptr(o + bos * H, (H, T), (T, 1), (0, i_block * BLOCK_T), (H, BLOCK_T), (1, 0))
        b_s = tl.load(ptr_s, boundary_check=(0,)).to(tl.float32)
        b_s = tl.reshape(b_s, (H, N_CHUNKS, CHUNK_SIZE))
        b_s = tl.trans(b_s, (2, 0, 1))
        b_o = tl.cumsum(b_s, axis=0, reverse=REVERSE)
        if HAS_SCALE:
            b_o *= scale
        b_o = tl.trans(b_o, (2, 0, 1))
        b_o = tl.reshape(b_o, (H, BLOCK_T))
    else:
        ptr_s = tl.make_block_ptr(s + bos * H, (T, H), (H, 1), (i_block * BLOCK_T, 0), (BLOCK_T, H), (1, 0))
        ptr_o = tl.make_block_ptr(o + bos * H, (T, H), (H, 1), (i_block * BLOCK_T, 0), (BLOCK_T, H), (1, 0))
        b_s = tl.load(ptr_s, boundary_check=(0,)).to(tl.float32)
        b_s = tl.reshape(b_s, (N_CHUNKS, CHUNK_SIZE, H))
        b_s = tl.trans(b_s, (1, 0, 2))
        b_o = tl.cumsum(b_s, axis=0, reverse=REVERSE)
        if HAS_SCALE:
            b_o *= scale
        b_o = tl.trans(b_o, (1, 0, 2))
        b_o = tl.reshape(b_o, (BLOCK_T, H))

    tl.store(ptr_o, b_o.to(OUT_DTYPE), boundary_check=(0,))
    return


def chunk_local_cumsum_scalar(
    g,
    chunk_size,
    reverse: bool = False,
    scale: float = None,
    cu_seqlens: torch.Tensor | None = None,
    block_indices: torch.Tensor | None = None,
    head_first: bool = False,
    output_dtype: torch.Tensor | None = torch.float,
):
    if head_first:
        B, H, T = g.shape
    else:
        B, T, H = g.shape
    assert chunk_size == 2 ** (chunk_size.bit_length() - 1), "chunk_size must be a power of 2"

    # 把 BLOCK_T clamp 到 [chunk_size, 64]。
    # H=64, chunk_size=16 -> BLOCK_T=64, N_CHUNKS=4, 单块 [64,64] fp32 ≈ 16KB。
    # 需要更大块时把 _BLOCK_T_CAP 调回 128。
    _BLOCK_T_CAP = 64
    OPTIM_BLOCK_SIZE = triton.next_power_of_2((2**18) // (H * chunk_size))
    OPTIM_BLOCK_SIZE = min(OPTIM_BLOCK_SIZE, _BLOCK_T_CAP)
    OPTIM_BLOCK_SIZE = max(OPTIM_BLOCK_SIZE, chunk_size)

    if cu_seqlens is not None and block_indices is None:
        block_indices = prepare_chunk_indices(cu_seqlens, chunk_size=OPTIM_BLOCK_SIZE)
    num_blocks = len(block_indices) if cu_seqlens is not None else triton.cdiv(T, OPTIM_BLOCK_SIZE)
    out_dtype = output_dtype or g.dtype
    g_org, g = g, torch.empty_like(g, dtype=out_dtype)
    _TL_DTYPES = {
        torch.float16: tl.float16,
        torch.bfloat16: tl.bfloat16,
        torch.float32: tl.float32,
        torch.float64: tl.float64,
        torch.int32: tl.int32,
        torch.int64: tl.int64,
    }
    grid = (num_blocks, B)
    chunk_local_cumsum_scalar_kernel[grid](
        s=g_org,
        o=g,
        scale=scale,
        cu_seqlens=cu_seqlens,
        chunk_indices=block_indices,
        T=T,
        H=H,
        BLOCK_T=OPTIM_BLOCK_SIZE,
        CHUNK_SIZE=chunk_size,
        HEAD_FIRST=head_first,
        REVERSE=reverse,
        OUT_DTYPE=_TL_DTYPES.get(out_dtype, tl.float32),
        num_warps=4,
        num_stages=2,
    )
    return g


def chunk_local_cumsum(
    g: torch.Tensor,
    chunk_size: int,
    reverse: bool = False,
    scale: float = None,
    cu_seqlens: torch.Tensor | None = None,
    head_first: bool = False,
    output_dtype: torch.dtype | None = torch.float,
    **kwargs,
) -> torch.Tensor:
    if cu_seqlens is not None:
        assert g.shape[0] == 1, "Only batch size 1 is supported when cu_seqlens are provided"
    if len(g.shape) == 3:
        return chunk_local_cumsum_scalar(
            g=g,
            chunk_size=chunk_size,
            reverse=reverse,
            scale=scale,
            cu_seqlens=cu_seqlens,
            block_indices=kwargs.get("block_indices"),
            head_first=head_first,
            output_dtype=output_dtype,
        )
    else:
        raise ValueError(
            f"chunk_local_cumsum: Unsupported input shape {g.shape}, "
            f"which should be (B, T, H, D) if `head_first=False` "
            f"or (B, H, T, D) otherwise"
        )


def ref_cumsum(g_np, chunk_size, head_first, reverse, scale):
    g = g_np.copy().astype(np.float32)
    if head_first:
        B, H, T = g.shape
    else:
        B, T, H = g.shape
    if head_first:
        x = g.transpose(0, 2, 1)
        B, T, H = x.shape
    else:
        x = g
    T_pad = ((T + chunk_size - 1) // chunk_size) * chunk_size
    pad = np.zeros((B, T_pad - T, H), dtype=np.float32)
    x = np.concatenate([x, pad], axis=1)
    n_ch = T_pad // chunk_size
    z = x.reshape(B, n_ch, chunk_size, H)
    if reverse:
        z = np.flip(z, axis=2)
        z = z.cumsum(axis=2)
        z = np.flip(z, axis=2)
    else:
        z = z.cumsum(axis=2)
    if scale is not None:
        z = z * scale
    z = z.reshape(B, T_pad, H)[:, :T, :]
    if head_first:
        z = z.transpose(0, 2, 1)
    return z.astype(np.float32)


def run_case(name, g_npu, chunk_size, head_first, reverse, scale, cu_seqlens=None):
    out = chunk_local_cumsum(
        g_npu, chunk_size, reverse=reverse, scale=scale,
        cu_seqlens=cu_seqlens, head_first=head_first, output_dtype=torch.float32,
    )
    torch.npu.synchronize()
    got = out.cpu().numpy()
    g_np = g_npu.cpu().numpy()
    if cu_seqlens is not None:
        cu = cu_seqlens.cpu().numpy()
        exp = np.zeros_like(g_np, dtype=np.float32)
        B, T, H = g_np.shape
        for s in range(len(cu) - 1):
            bos, eos = cu[s], cu[s + 1]
            seg = g_np[:, bos:eos, :]
            r = ref_cumsum(seg, chunk_size, head_first, reverse, scale)
            exp[:, bos:eos, :] = r
    else:
        exp = ref_cumsum(g_np, chunk_size, head_first, reverse, scale)
    ok = np.allclose(got, exp, atol=1e-4, rtol=1e-4)
    print(f"[{'PASS' if ok else 'FAIL'}] {name}: shape={tuple(g_npu.shape)} chunk={chunk_size} hf={head_first} rev={reverse} scale={scale} varlen={cu_seqlens is not None}", flush=True)
    if not ok:
        diff = np.abs(got - exp).max()
        print(f"  max_diff={diff:.6f}  got[:4]={got.reshape(-1)[:4]} exp[:4]={exp.reshape(-1)[:4]}", flush=True)
    return ok


def test_chunk_local_cumsum_scalar_kernel():
    ok = True
    dev = torch.device("npu", torch.npu.current_device())
    seed = 3

    # 只保留 1 个用例，减少特化/编译次数：
    # HEAD_FIRST=False, REVERSE=False, HAS_SCALE=False, IS_VARLEN=False
    torch.manual_seed(seed)
    g = torch.randn(1, 32, 4, dtype=torch.float16, device=dev)
    ok &= run_case("basic-hf0", g, 4, False, False, None)

    assert ok, "chunk_local_cumsum_scalar_kernel FAILED"
    print("[ALL PASS] chunk_local_cumsum_scalar_kernel", flush=True)


if __name__ == "__main__":
    test_chunk_local_cumsum_scalar_kernel()
import sys

import torch
import torch_npu
import triton
import triton.language as tl


@triton.jit(
    do_not_specialize=[
        "batch",
        "state_len",
        "num_cache_lines",
        "stride_x_seq",
        "stride_x_token",
        "stride_conv_state_seq",
        "stride_state_indices",
        "stride_o_seq",
        "stride_o_token",
    ]
)
def _causal_conv1d_update_kernel_npu_tiled(
    x_ptr,
    w_ptr,
    bias_ptr,
    conv_state_ptr,
    conv_state_indices_ptr,
    num_accepted_tokens_ptr,
    query_start_loc_ptr,
    block_idx_last_scheduled_token,
    initial_state_idx,
    o_ptr,
    batch: tl.int32,
    dim: tl.constexpr,
    seqlen: tl.constexpr,
    state_len,
    num_cache_lines,
    stride_x_seq,
    stride_x_dim: tl.constexpr,
    stride_x_token,
    stride_w_dim: tl.constexpr,
    stride_w_width: tl.constexpr,
    stride_conv_state_seq,
    stride_conv_state_dim: tl.constexpr,
    stride_conv_state_tok: tl.constexpr,
    stride_state_indices,
    stride_o_seq,
    stride_o_dim: tl.constexpr,
    stride_o_token,
    pad_slot_id: tl.constexpr,
    HAS_BIAS: tl.constexpr,
    KERNEL_WIDTH: tl.constexpr,
    SILU_ACTIVATION: tl.constexpr,
    IS_VARLEN: tl.constexpr,
    IS_APC_ENABLED: tl.constexpr,
    IS_SPEC_DECODING: tl.constexpr,
    NP2_STATELEN: tl.constexpr,
    USE_PAD_SLOT: tl.constexpr,
    BLOCK_N: tl.constexpr,
    B_TILE: tl.constexpr,
    T_CHUNK: tl.constexpr,
):
    pid_b = tl.program_id(0)
    pid_c = tl.program_id(1)

    idx_feats = pid_c * BLOCK_N + tl.arange(0, BLOCK_N)
    mask_w = idx_feats < dim

    w_base = w_ptr + idx_feats * stride_w_dim
    w_col0 = tl.zeros((BLOCK_N,), dtype=tl.float32)
    w_col1 = tl.zeros((BLOCK_N,), dtype=tl.float32)
    w_col2 = tl.zeros((BLOCK_N,), dtype=tl.float32)
    w_col3 = tl.zeros((BLOCK_N,), dtype=tl.float32)
    w_col4 = tl.zeros((BLOCK_N,), dtype=tl.float32)
    w_col5 = tl.zeros((BLOCK_N,), dtype=tl.float32)
    if KERNEL_WIDTH >= 1:
        w_col0 = tl.load(w_base + 0 * stride_w_width, mask=mask_w, other=0.0).to(tl.float32)
    if KERNEL_WIDTH >= 2:
        w_col1 = tl.load(w_base + 1 * stride_w_width, mask=mask_w, other=0.0).to(tl.float32)
    if KERNEL_WIDTH >= 3:
        w_col2 = tl.load(w_base + 2 * stride_w_width, mask=mask_w, other=0.0).to(tl.float32)
    if KERNEL_WIDTH >= 4:
        w_col3 = tl.load(w_base + 3 * stride_w_width, mask=mask_w, other=0.0).to(tl.float32)
    if KERNEL_WIDTH >= 5:
        w_col4 = tl.load(w_base + 4 * stride_w_width, mask=mask_w, other=0.0).to(tl.float32)
    if KERNEL_WIDTH >= 6:
        w_col5 = tl.load(w_base + 5 * stride_w_width, mask=mask_w, other=0.0).to(tl.float32)

    if HAS_BIAS:
        acc_bias = tl.load(bias_ptr + idx_feats, mask=mask_w, other=0.0).to(tl.float32)
    else:
        acc_bias = tl.zeros((BLOCK_N,), dtype=tl.float32)

    tok_vec = tl.arange(0, T_CHUNK)

    for bi in tl.static_range(0, B_TILE):
        b = pid_b * B_TILE + bi
        lane_active = b < batch

        if IS_APC_ENABLED:
            conv_state_init = tl.load(initial_state_idx + b, mask=lane_active, other=0).to(tl.int32)
            current_last_index = tl.load(block_idx_last_scheduled_token + b, mask=lane_active, other=0).to(tl.int32)
        else:
            conv_state_init = tl.full((), 0, tl.int32)
            current_last_index = tl.full((), 0, tl.int32)

        conv_states_input_coord = tl.load(
            conv_state_indices_ptr + b * stride_state_indices + conv_state_init, mask=lane_active, other=0
        ).to(tl.int64)

        if USE_PAD_SLOT:
            lane_active = lane_active & (conv_states_input_coord != pad_slot_id)

        if IS_VARLEN:
            qs = tl.load(query_start_loc_ptr + b, mask=lane_active, other=0).to(tl.int64)
            qe = tl.load(query_start_loc_ptr + (b + 1), mask=lane_active, other=0).to(tl.int64)
            seqlen_run = (qe - qs).to(tl.int32)
            state_len_run = (state_len - (seqlen - seqlen_run)).to(tl.int32)
            x_offset = (qs * stride_x_token).to(tl.int64)
            o_offset = (qs * stride_o_token).to(tl.int64)
        else:
            seqlen_run = tl.full((), seqlen, tl.int32)
            state_len_run = tl.full((), state_len, tl.int32)
            x_offset = (b * stride_x_seq).to(tl.int64)
            o_offset = (b * stride_o_seq).to(tl.int64)

        lane_active = lane_active & (seqlen_run > 0)

        if IS_SPEC_DECODING:
            conv_state_token_offset = tl.load(num_accepted_tokens_ptr + b, mask=lane_active, other=1).to(tl.int64) - 1
            shift = tl.full((), 1, tl.int32)
        else:
            conv_state_token_offset = tl.full((), 0, tl.int64)
            shift = seqlen_run

        conv_states_base = (
            conv_state_ptr + conv_states_input_coord * stride_conv_state_seq + idx_feats * stride_conv_state_dim
        )
        prior_tokens = conv_states_base + conv_state_token_offset * stride_conv_state_tok

        col0 = tl.zeros((BLOCK_N,), dtype=tl.float16)
        col1 = tl.zeros((BLOCK_N,), dtype=tl.float16)
        col2 = tl.zeros((BLOCK_N,), dtype=tl.float16)
        col3 = tl.zeros((BLOCK_N,), dtype=tl.float16)
        col4 = tl.zeros((BLOCK_N,), dtype=tl.float16)
        if KERNEL_WIDTH >= 2:
            col0 = tl.load(prior_tokens + 0 * stride_conv_state_tok, mask=lane_active & mask_w, other=0.0).to(
                tl.float16
            )
        if KERNEL_WIDTH >= 3:
            col1 = tl.load(prior_tokens + 1 * stride_conv_state_tok, mask=lane_active & mask_w, other=0.0).to(
                tl.float16
            )
        if KERNEL_WIDTH >= 4:
            col2 = tl.load(prior_tokens + 2 * stride_conv_state_tok, mask=lane_active & mask_w, other=0.0).to(
                tl.float16
            )
        if KERNEL_WIDTH >= 5:
            col3 = tl.load(prior_tokens + 3 * stride_conv_state_tok, mask=lane_active & mask_w, other=0.0).to(
                tl.float16
            )
        if KERNEL_WIDTH >= 6:
            col4 = tl.load(prior_tokens + 4 * stride_conv_state_tok, mask=lane_active & mask_w, other=0.0).to(
                tl.float16
            )

        conv_states_offset = tl.load(
            conv_state_indices_ptr + b * stride_state_indices + current_last_index, mask=lane_active, other=0
        ).to(tl.int64)

        use_shift = seqlen_run < state_len_run
        use_tail = seqlen_run >= state_len_run

        zero_i32 = tl.full((), 0, tl.int32)
        keep_shift = tl.where(use_shift, (state_len_run - seqlen_run), zero_i32).to(tl.int32)
        tail_start = tl.where(use_tail, (seqlen_run - state_len_run), zero_i32).to(tl.int32)

        state_src_base = (
            conv_state_ptr
            + conv_states_input_coord * stride_conv_state_seq
            + conv_state_token_offset * stride_conv_state_tok
            + idx_feats * stride_conv_state_dim
        )
        state_dst_base = conv_state_ptr + conv_states_offset * stride_conv_state_seq + idx_feats * stride_conv_state_dim

        x_base = x_ptr + x_offset + idx_feats * stride_x_dim

        for t0 in tl.static_range(0, NP2_STATELEN, T_CHUNK):
            dst_tok = (t0 + tok_vec).to(tl.int32)
            src_tok = (dst_tok + shift).to(tl.int32)
            m_tok = use_shift & (dst_tok < keep_shift) & (src_tok < state_len_run) & (dst_tok < state_len_run)
            m = (
                (lane_active & m_tok)[:, None]
                & mask_w[None, :]
                & (conv_states_input_coord < num_cache_lines)
                & (conv_states_offset < num_cache_lines)
            )

            src_ptrs = state_src_base[None, :] + src_tok[:, None] * stride_conv_state_tok
            dst_ptrs = state_dst_base[None, :] + dst_tok[:, None] * stride_conv_state_tok
            vals = tl.load(src_ptrs, mask=m, other=0.0)
            tl.store(dst_ptrs, vals, mask=m)

        for t0 in tl.static_range(0, seqlen, T_CHUNK):
            x_tok = (t0 + tok_vec).to(tl.int32)
            dst_tok = (keep_shift + x_tok).to(tl.int32)
            m_tok = use_shift & (x_tok < seqlen_run) & (dst_tok < state_len_run)
            m = (lane_active & m_tok)[:, None] & mask_w[None, :] & (conv_states_offset < num_cache_lines)

            x_ptrs = x_base[None, :] + x_tok[:, None] * stride_x_token
            dst_ptrs = state_dst_base[None, :] + dst_tok[:, None] * stride_conv_state_tok
            x_vals = tl.load(x_ptrs, mask=m, other=0.0)
            tl.store(dst_ptrs, x_vals, mask=m)

        for t0 in tl.static_range(0, NP2_STATELEN, T_CHUNK):
            dst_tok = (t0 + tok_vec).to(tl.int32)
            x_tok = (tail_start + dst_tok).to(tl.int32)
            m_tok = use_tail & (dst_tok < state_len_run) & (x_tok < seqlen_run)
            m = (lane_active & m_tok)[:, None] & mask_w[None, :] & (conv_states_offset < num_cache_lines)

            x_ptrs = x_base[None, :] + x_tok[:, None] * stride_x_token
            dst_ptrs = state_dst_base[None, :] + dst_tok[:, None] * stride_conv_state_tok
            x_vals = tl.load(x_ptrs, mask=m, other=0.0)
            tl.store(dst_ptrs, x_vals, mask=m)

        x_base_1d = x_base
        o_base_1d = o_ptr + o_offset + idx_feats * stride_o_dim

        acc_preload = acc_bias

        for idx_token in tl.range(seqlen_run):
            acc = acc_preload

            matrix_w = w_col0
            matrix_x = col0
            for j in tl.static_range(KERNEL_WIDTH):
                if KERNEL_WIDTH == 1:
                    x_ptrs_1d = x_base_1d + idx_token * stride_x_token
                    matrix_x = tl.load(x_ptrs_1d, mask=lane_active & mask_w, other=0.0).to(tl.float16)
                    matrix_w = w_col0
                elif KERNEL_WIDTH == 2:
                    if j == 1:
                        matrix_w = w_col1
                        x_ptrs_1d = x_base_1d + idx_token * stride_x_token
                        matrix_x = tl.load(x_ptrs_1d, mask=lane_active & mask_w, other=0.0).to(tl.float16)
                elif KERNEL_WIDTH == 3:
                    if j == 1:
                        matrix_w = w_col1
                        matrix_x = col1
                    elif j == 2:
                        matrix_w = w_col2
                        x_ptrs_1d = x_base_1d + idx_token * stride_x_token
                        matrix_x = tl.load(x_ptrs_1d, mask=lane_active & mask_w, other=0.0).to(tl.float16)
                elif KERNEL_WIDTH == 4:
                    if j == 1:
                        matrix_w = w_col1
                        matrix_x = col1
                    elif j == 2:
                        matrix_w = w_col2
                        matrix_x = col2
                    elif j == 3:
                        matrix_w = w_col3
                        x_ptrs_1d = x_base_1d + idx_token * stride_x_token
                        matrix_x = tl.load(x_ptrs_1d, mask=lane_active & mask_w, other=0.0).to(tl.float16)
                elif KERNEL_WIDTH == 5:
                    if j == 1:
                        matrix_w = w_col1
                        matrix_x = col1
                    elif j == 2:
                        matrix_w = w_col2
                        matrix_x = col2
                    elif j == 3:
                        matrix_w = w_col3
                        matrix_x = col3
                    elif j == 4:
                        matrix_w = w_col4
                        x_ptrs_1d = x_base_1d + idx_token * stride_x_token
                        matrix_x = tl.load(x_ptrs_1d, mask=lane_active & mask_w, other=0.0).to(tl.float16)
                elif KERNEL_WIDTH == 6:
                    if j == 1:
                        matrix_w = w_col1
                        matrix_x = col1
                    elif j == 2:
                        matrix_w = w_col2
                        matrix_x = col2
                    elif j == 3:
                        matrix_w = w_col3
                        matrix_x = col3
                    elif j == 4:
                        matrix_w = w_col4
                        matrix_x = col4
                    elif j == 5:
                        matrix_w = w_col5
                        x_ptrs_1d = x_base_1d + idx_token * stride_x_token
                        matrix_x = tl.load(x_ptrs_1d, mask=lane_active & mask_w, other=0.0).to(tl.float16)

                acc += matrix_x.to(tl.float32) * matrix_w

            if KERNEL_WIDTH == 2:
                col0 = matrix_x
            elif KERNEL_WIDTH == 3:
                col0 = col1
                col1 = matrix_x
            elif KERNEL_WIDTH == 4:
                col0 = col1
                col1 = col2
                col2 = matrix_x
            elif KERNEL_WIDTH == 5:
                col0 = col1
                col1 = col2
                col2 = col3
                col3 = matrix_x
            elif KERNEL_WIDTH == 6:
                col0 = col1
                col1 = col2
                col2 = col3
                col3 = col4
                col4 = matrix_x

            if SILU_ACTIVATION:
                acc = acc / (1.0 + tl.exp(-acc))

            o_ptrs = o_base_1d + idx_token * stride_o_token
            tl.store(o_ptrs, acc, mask=lane_active & mask_w)


def test_causal_conv1d_update_kernel_npu_tiled():
    batch = 1
    dim = 256
    seqlen = 4
    width = 4
    eff_state_len = 6
    num_cache_lines = 8
    BLOCK_N = 256
    B_TILE = 1
    T_CHUNK = 1
    np2_statelen = triton.next_power_of_2(eff_state_len)
    pad_slot_id = -1
    has_bias = False
    silu = True
    is_varlen = True
    is_apc = False
    is_spec = True

    torch.manual_seed(0)
    num_tokens = seqlen * batch  # 4

    x = (-torch.rand(num_tokens, dim, device="npu") * 3.0 - 1.0).half().contiguous()  # in [-4,-1]
    weight = (torch.rand(width, dim, device="npu") * 0.5 + 0.1).half().contiguous()  # positive
    w_t = weight.transpose(0, 1).contiguous()  # (dim, width)

    conv_state = (-torch.rand(num_cache_lines, dim, eff_state_len, device="npu") * 2.0 - 0.5).half()
    conv_state = conv_state.transpose(1, 2).contiguous()  # (lines, state_len_total=6, dim)
    state_len_total = conv_state.shape[1]

    conv_state_indices = torch.zeros(batch, 1, dtype=torch.int32, device="npu")  # coord=0
    num_accepted_tokens = torch.ones(batch, dtype=torch.int32, device="npu")
    query_start_loc = torch.arange(batch + 1, dtype=torch.int32, device="npu") * seqlen

    out = torch.empty(num_tokens, dim, device="npu", dtype=x.dtype)

    stride_x_seq = 0
    stride_x_dim = 1
    stride_x_token = dim
    stride_w_dim = 1
    stride_w_width = dim
    stride_cs_seq = state_len_total * dim
    stride_cs_tok = dim
    stride_cs_dim = 1
    stride_si = 1
    stride_o_seq = 0
    stride_o_dim = 1
    stride_o_token = dim

    cs_pre = conv_state.float().cpu().clone()  # pre-update snapshot (before kernel mutates in place)

    print("=== launch kernel ===")
    print(f"batch={batch} dim={dim} seqlen={seqlen} eff_state_len={eff_state_len} num_cache_lines={num_cache_lines}")
    print(f"x={tuple(x.shape)} w={tuple(w_t.shape)} conv_state={tuple(conv_state.shape)}")
    print(f"indices={conv_state_indices.cpu().tolist()} acc={num_accepted_tokens.cpu().tolist()}")
    print(f"grid=({triton.cdiv(batch, B_TILE)},{triton.cdiv(dim, BLOCK_N)}) BLOCK_N={BLOCK_N} B_TILE={B_TILE} T_CHUNK={T_CHUNK} NP2_STATELEN={np2_statelen}")

    _causal_conv1d_update_kernel_npu_tiled[
        (triton.cdiv(batch, B_TILE), triton.cdiv(dim, BLOCK_N))
    ](
        x,
        w_t,
        None,
        conv_state,
        conv_state_indices,
        num_accepted_tokens,
        query_start_loc,
        None,
        None,
        out,
        batch,
        dim,
        seqlen,
        eff_state_len,
        num_cache_lines,
        stride_x_seq,
        stride_x_dim,
        stride_x_token,
        stride_w_dim,
        stride_w_width,
        stride_cs_seq,
        stride_cs_dim,
        stride_cs_tok,
        stride_si,
        stride_o_seq,
        stride_o_dim,
        stride_o_token,
        pad_slot_id,
        HAS_BIAS=has_bias,
        KERNEL_WIDTH=width,
        SILU_ACTIVATION=silu,
        IS_VARLEN=is_varlen,
        IS_APC_ENABLED=is_apc,
        IS_SPEC_DECODING=is_spec,
        NP2_STATELEN=np2_statelen,
        USE_PAD_SLOT=True,
        BLOCK_N=BLOCK_N,
        B_TILE=B_TILE,
        T_CHUNK=T_CHUNK,
    )
    torch.npu.synchronize()
    print("kernel done")
    print("out[0,:4]=", out.cpu()[0, :4].tolist())
    print("conv_state[0,:,0:2]=", conv_state.cpu()[0, :, :2].tolist()[:2])

    print("=== reference check ===")
    cs_before = cs_pre  # pre-update snapshot taken before kernel launch
    cs_after = conv_state.float().cpu()  # kernel-updated state
    x_c = x.float().cpu()  # (nt, dim)
    w_c = w_t.float().cpu()  # (dim, width)
    si_c = conv_state_indices.cpu()
    acc_c = num_accepted_tokens.cpu().tolist()
    qs_c = query_start_loc.cpu().tolist()

    cs_expect = cs_before.clone()
    o_ref = torch.zeros(num_tokens, dim, dtype=torch.float32)
    o_refB = torch.zeros(num_tokens, dim, dtype=torch.float32)

    wA = w_c  # (dim, width), standard layout w[f][k]
    wB = w_c.reshape(-1)  # kernel reads w_col_k[f] at flat index k*dim+f  -> treat as (width, dim)

    for b in range(batch):
        coord = int(si_c[b].item())
        if coord == pad_slot_id:
            continue
        qs = qs_c[b]
        qe = qs_c[b + 1]
        seqlen_run = qe - qs
        state_len_run = eff_state_len - (seqlen - seqlen_run)
        if seqlen_run <= 0:
            continue
        tok_off = acc_c[b] - 1
        shift = 1

        hist = cs_before[coord, tok_off : tok_off + width - 1, :].clone()  # (3, dim)

        dst_line = cs_expect[coord]  # (statelen_total, dim) in-place update
        if seqlen_run < state_len_run:
            keep = state_len_run - seqlen_run
            src_rows = cs_before[coord, shift + tok_off : shift + tok_off + keep, :]
            dst_line[0:keep] = src_rows
            dst_line[keep : keep + seqlen_run] = x_c[qs : qs + seqlen_run]
        else:
            tail_start = seqlen_run - state_len_run
            dst_line[0:state_len_run] = x_c[qs + tail_start : qs + tail_start + state_len_run]

        h = hist
        for t in range(seqlen_run):
            xt = x_c[qs + t]
            acc = wA[:, 0] * h[0] + wA[:, 1] * h[1] + wA[:, 2] * h[2] + wA[:, 3] * xt
            accB = wB[0 * dim : 1 * dim] * h[0] + wB[1 * dim : 2 * dim] * h[1] + wB[2 * dim : 3 * dim] * h[2] + wB[3 * dim : 4 * dim] * xt
            if silu:
                acc = acc / (1.0 + torch.exp(-acc))
                accB = accB / (1.0 + torch.exp(-accB))
            o_ref[qs + t] = acc
            o_refB[qs + t] = accB
            h = torch.stack([h[1], h[2], xt])

    oc = out.float().cpu()
    do = (oc - o_ref).abs()
    doB = (oc - o_refB).abs()
    dcs = (cs_after - cs_expect).abs()
    print(f"out max_abs_diff (layout A w[f][k])     = {do.max().item():.6e}")
    print(f"out max_abs_diff (layout B k*dim+f flat) = {doB.max().item():.6e}")
    print(f"out allclose A={torch.allclose(oc, o_ref, atol=1e-2, rtol=1e-2)}  B={torch.allclose(oc, o_refB, atol=1e-2, rtol=1e-2)}")
    print(f"conv_state max_abs_diff={dcs.max().item():.6e}")
    print(f"conv_state allclose={torch.allclose(cs_after, cs_expect, atol=1e-2, rtol=1e-2)}")
    ok = min(do.max().item(), doB.max().item()) < 1e-2 and dcs.max().item() < 1e-2
    assert ok, f"conv1d FAILED outA={do.max().item():.6e} outB={doB.max().item():.6e} cs={dcs.max().item():.6e}"
    print("RESULT: PASS")


if __name__ == "__main__":
    test_causal_conv1d_update_kernel_npu_tiled()

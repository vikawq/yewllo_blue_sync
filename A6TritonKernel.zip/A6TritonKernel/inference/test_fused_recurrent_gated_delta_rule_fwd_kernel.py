# -*- coding: utf-8 -*-
import os
import sys
import types
import time
import traceback

os.environ.setdefault("TRITON_BACKENDS_IN_TREE", "1")
os.environ.setdefault("TRITON_BACKEND", "opentile")
os.environ.setdefault("TRITON_ALWAYS_COMPILE", "1")

import triton
import triton.language as tl
import torch

_vllm_utils = types.ModuleType("vllm.triton_utils")
_vllm_utils.tl = tl
_vllm_utils.triton = triton
_vllm_utils.tldevice = types.SimpleNamespace(
    fast_dividef=lambda x, y: x / y,
    fast_expf=tl.exp,
    fast_logf=tl.log,
    fast_log2f=tl.log2,
)
_vllm_pkg = types.ModuleType("vllm")
_vllm_pkg.triton_utils = _vllm_utils
sys.modules.setdefault("vllm", _vllm_pkg)
sys.modules["vllm.triton_utils"] = _vllm_utils
sys.modules["vllm"].triton_utils = _vllm_utils

_math_pkg = types.ModuleType("vllm.utils")
sys.modules.setdefault("vllm.utils", _math_pkg)
_math_mod = types.ModuleType("vllm.utils.math_utils")
sys.modules["vllm.utils.math_utils"] = _math_mod


div = lambda x, y: x / y
exp = tl.exp
log = tl.log
log2 = tl.log2


@triton.heuristics(
    {
        "USE_INITIAL_STATE": lambda args: args["h0"] is not None,
        "IS_VARLEN": lambda args: args["cu_seqlens"] is not None,
        "IS_CONTINUOUS_BATCHING": lambda args: args["ssm_state_indices"] is not None,
        "IS_SPEC_DECODING": lambda args: args["num_accepted_tokens"] is not None,
    }
)
@triton.jit(do_not_specialize=["N", "T"])
def fused_recurrent_gated_delta_rule_fwd_kernel(
    q,
    k,
    v,
    g,
    beta,
    o,
    h0,
    ht,
    cu_seqlens,
    ssm_state_indices,
    num_accepted_tokens,
    scale,
    N: tl.constexpr,  # num of sequences
    T: tl.constexpr,  # num of tokens
    B: tl.constexpr,
    H: tl.constexpr,
    HV: tl.constexpr,
    K: tl.constexpr,
    V: tl.constexpr,
    BK: tl.constexpr,
    BV: tl.constexpr,
    stride_init_state_token: tl.constexpr,
    stride_final_state_token: tl.constexpr,
    stride_indices_seq: tl.constexpr,
    stride_indices_tok: tl.constexpr,
    USE_INITIAL_STATE: tl.constexpr,  # whether to use initial state
    INPLACE_FINAL_STATE: tl.constexpr,  # whether to store final state inplace
    IS_BETA_HEADWISE: tl.constexpr,  # whether beta is headwise vector or scalar,
    USE_QK_L2NORM_IN_KERNEL: tl.constexpr,
    IS_VARLEN: tl.constexpr,
    IS_CONTINUOUS_BATCHING: tl.constexpr,
    IS_SPEC_DECODING: tl.constexpr,
    IS_KDA: tl.constexpr,
):
    i_k, i_v, i_nh = tl.program_id(0), tl.program_id(1), tl.program_id(2)
    i_n, i_hv = i_nh // HV, i_nh % HV
    i_h = i_hv // (HV // H)
    if IS_VARLEN:
        bos, eos = tl.load(cu_seqlens + i_n).to(tl.int64), tl.load(cu_seqlens + i_n + 1).to(tl.int64)
        all = T
        T = eos - bos
    else:
        bos, eos = i_n * T, i_n * T + T
        all = B * T

    if T == 0:
        # no tokens to process for this sequence
        return

    o_k = i_k * BK + tl.arange(0, BK)
    o_v = i_v * BV + tl.arange(0, BV)

    mask_k = o_k < K
    mask_v = o_v < V
    mask_h = mask_k[:, None] & mask_v[None, :]

    b_h = tl.zeros([BK, BV], dtype=tl.float32)
    if USE_INITIAL_STATE:
        if IS_CONTINUOUS_BATCHING:
            if IS_SPEC_DECODING:
                i_t = tl.load(num_accepted_tokens + i_n).to(tl.int64) - 1
            else:
                i_t = 0
            p_h0 = (
                h0 + tl.load(ssm_state_indices + i_n * stride_indices_seq + i_t).to(tl.int64) * stride_init_state_token
            )
        else:
            p_h0 = h0 + bos * HV * K * V
        p_h0 = p_h0 + i_hv * K * V + o_k[:, None] * V + o_v[None, :]
        b_h += tl.load(p_h0, mask=mask_h, other=0).to(tl.float32)

    for i_t in range(0, T):
        p_q = q + (bos * H + i_h) * K + o_k + H * K * i_t
        p_k = k + (bos * H + i_h) * K + o_k + H * K * i_t
        p_v = v + (bos * HV + i_hv) * V + o_v + HV * V * i_t

        if IS_BETA_HEADWISE:
            p_beta = beta + (bos * HV + i_hv) * V + o_v + HV * V * i_t
        else:
            p_beta = beta + bos * HV + i_hv + HV * i_t

        if not IS_KDA:
            p_g = g + bos * HV + i_hv + HV * i_t
        else:
            p_gk = g + (bos * HV + i_hv + HV * i_t) * K + o_k

        p_o = o + ((i_k * all + bos) * HV + i_hv) * V + o_v + HV * V * i_t

        b_q = tl.load(p_q, mask=mask_k, other=0).to(tl.float32)
        b_k = tl.load(p_k, mask=mask_k, other=0).to(tl.float32)
        b_v = tl.load(p_v, mask=mask_v, other=0).to(tl.float32)

        if USE_QK_L2NORM_IN_KERNEL:
            b_q = b_q / tl.sqrt(tl.sum(b_q * b_q) + 1e-6)
            b_k = b_k / tl.sqrt(tl.sum(b_k * b_k) + 1e-6)
        b_q = b_q * scale
        # [BK, BV]
        # b_h *= tl.exp(b_g)
        if not IS_KDA:
            b_g = tl.load(p_g).to(tl.float32)
            b_h *= exp(b_g)
        else:
            b_gk = tl.load(p_gk).to(tl.float32)
            b_h *= exp(b_gk[:, None])
        # [BV]
        b_v -= tl.sum(b_h * b_k[:, None], 0)
        if IS_BETA_HEADWISE:
            b_beta = tl.load(p_beta, mask=mask_v, other=0).to(tl.float32)
        else:
            b_beta = tl.load(p_beta).to(tl.float32)
        b_v *= b_beta
        # [BK, BV]
        b_h += b_k[:, None] * b_v[None, :]
        # [BV]
        b_o = tl.sum(b_h * b_q[:, None], 0)
        tl.store(p_o, b_o.to(p_o.dtype.element_ty), mask=mask_v)

        # keep the states for multi-query tokens
        if INPLACE_FINAL_STATE:
            p_ht = (
                ht + tl.load(ssm_state_indices + i_n * stride_indices_seq + i_t).to(tl.int64) * stride_final_state_token
            )
        else:
            p_ht = ht + (bos + i_t) * stride_final_state_token
        p_ht = p_ht + i_hv * K * V + o_k[:, None] * V + o_v[None, :]
        tl.store(p_ht, b_h.to(p_ht.dtype.element_ty), mask=mask_h)

RESULT = "/tmp/rs_sg_res.txt"


def _envint(name, default):
    return int(os.environ.get(name, default))

N = _envint("SG_N", 2)
T = _envint("SG_T", 64)
H = _envint("SG_H", 2)
HV = _envint("SG_HV", 4)
K = _envint("SG_K", 32)
V = _envint("SG_V", 32)

def append(line):
    with open(RESULT, "a") as f:
        f.write(line + "\n")

def done(stat, case, t0, msg=""):
    line = "[%s] %s elapsed=%.1fs %s" % (stat, case, time.time() - t0, msg)
    print(line, flush=True)
    append(line)
    sys.stdout.flush()
    if stat != "OK":
        raise AssertionError(line)

def check(name, cond, detail=""):
    if not cond:
        raise AssertionError("%s failed %s" % (name, detail))
    print("  check %s PASS %s" % (name, detail), flush=True)


_sg_target = getattr(fused_recurrent_gated_delta_rule_fwd_kernel, "fn",
                     fused_recurrent_gated_delta_rule_fwd_kernel)
for _p in getattr(_sg_target, "params", []):
    if getattr(_p, "name", None) in ("N", "T"):
        _p.do_not_specialize = False
        _p.do_not_specialize_on_alignment = False

def make_inputs(N, T, H, HV, K, V, dtype, KDA, BH, seed=0):
    torch.manual_seed(seed)
    dev = "npu"
    bos = torch.linspace(0, T, N + 1, dtype=torch.int32, device=dev)
    cu = bos
    indices = torch.arange(N, dtype=torch.int32, device=dev)
    q = torch.randn(T, H, K, dtype=dtype, device=dev)
    k = torch.randn(T, H, K, dtype=dtype, device=dev)
    v = torch.randn(T, HV, V, dtype=dtype, device=dev)
    if KDA:
        g = -torch.full((T, HV, K), 0.05, dtype=torch.float32, device=dev)
    else:
        g = -torch.full((T, HV), 0.05, dtype=torch.float32, device=dev)
    if BH:
        beta = torch.rand(T, HV, V, dtype=torch.float32, device=dev).mul(0.01).add(0.005)
    else:
        beta = torch.rand(T, HV, dtype=torch.float32, device=dev).mul(0.01).add(0.005)
    o = torch.empty(T, HV, V, dtype=dtype, device=dev)
    h0 = torch.randn(N, HV, K, V, dtype=torch.float32, device=dev).mul(0.02)
    ht = torch.zeros(T, HV, K, V, dtype=torch.float32, device=dev)
    scale = K ** -0.5
    return dict(q=q, k=k, v=v, g=g, beta=beta, o=o, h0=h0, ht=ht,
                cu=cu, indices=indices, scale=scale)

def launch(t, N, T, B, H, HV, K, V, KDA, BH):
    grid = (K // K, V // V, N * HV)  # NK=1, NV=1
    fused_recurrent_gated_delta_rule_fwd_kernel[(1, 1, N * HV)](
        t["q"], t["k"], t["v"], t["g"], t["beta"], t["o"],
        t["h0"], t["ht"], t["cu"], t["indices"], None,  # num_accepted_tokens->None
        t["scale"],
        N=N, T=T, B=B, H=H, HV=HV, K=K, V=V, BK=K, BV=V,
        stride_init_state_token=HV * K * V,
        stride_final_state_token=HV * K * V,
        stride_indices_seq=1,
        stride_indices_tok=0,
        USE_INITIAL_STATE=True,
        INPLACE_FINAL_STATE=False,
        IS_BETA_HEADWISE=BH,
        USE_QK_L2NORM_IN_KERNEL=False,
        IS_VARLEN=True,
        IS_CONTINUOUS_BATCHING=True,
        IS_SPEC_DECODING=False,
        IS_KDA=KDA,
        num_warps=1,
        num_stages=3,
    )
    torch.npu.synchronize()

def ref_delta_rule(t, N, T, H, HV, K, V, KDA, BH, scale):
    q = t["q"].cpu().double()
    k = t["k"].cpu().double()
    v = t["v"].cpu().double()
    g = t["g"].cpu().double()
    beta = t["beta"].cpu().double()
    h0 = t["h0"].cpu().double()
    cu = t["cu"].cpu().tolist()
    i_hv_map = torch.arange(HV, dtype=torch.long) // (HV // H)  # [HV]
    o = torch.zeros(T, HV, V, dtype=torch.float64)
    h = h0.clone()
    for n in range(N):
        bos, eos = int(cu[n]), int(cu[n + 1])
        for tt in range(bos, eos):
            if KDA:
                h[n] = h[n] * torch.exp(g[tt])[:, :, None]
            else:
                h[n] = h[n] * torch.exp(g[tt])[:, None, None]
            hk = k[tt][i_hv_map]  # [HV, K]
            vd = v[tt] - torch.einsum("hkv,hk->hv", h[n], hk)
            if BH:
                vd = vd * beta[tt]
            else:
                vd = vd * beta[tt][:, None]
            h[n] = h[n] + torch.einsum("hk,hv->hkv", hk, vd)
            qk = q[tt][i_hv_map] * scale
            o[tt] = torch.einsum("hkv,hk->hv", h[n], qk)
    return o, h

def run_case(name, KDA, BH, dtype=torch.bfloat16):
    t0 = time.time()
    K_, V_ = K, V
    t = make_inputs(N, T, H, HV, K_, V_, dtype, KDA, BH)
    launch(t, N, T, N, H, HV, K_, V_, KDA, BH)
    o_ref, h_ref = ref_delta_rule(t, N, T, H, HV, K_, V_, KDA, BH, t["scale"])
    o_got = t["o"].cpu().double()
    ht_got = t["ht"].cpu().double()  # [T, HV, K, V]
    cu = t["cu"].cpu().tolist()
    ht_final = torch.stack([ht_got[int(cu[n + 1]) - 1].cpu().double() for n in range(N)])

    o_abs = (o_got - o_ref).abs().max().item()
    ht_abs = (ht_final - h_ref).abs().max().item()
    o_ok = torch.allclose(o_got, o_ref, rtol=0.05, atol=0.05)
    ht_ok = torch.allclose(ht_final, h_ref, rtol=0.01, atol=0.01)
    check(name + " o-vs-ref", o_ok, "max_abs_o=%.3e" % o_abs)
    check(name + " ht-vs-ref", ht_ok, "max_abs_ht=%.3e" % ht_abs)
    done("OK", name, t0)

def test_fused_recurrent_gated_delta_rule_fwd_kernel_main():
    if not torch.npu.is_available():
        raise AssertionError("npu NOT available, abort")
    print("shape=N%d,T%d,H%d,HV%d,K%d,V%d triton=%s torch=%s" % (
        N, T, H, HV, K, V,
        __import__("triton").__version__, torch.__version__), flush=True)
    run_case("sg_main_varlen_contbatch", KDA=False, BH=False)


def test_fused_recurrent_gated_delta_rule_fwd_kernel_kda():
    if not torch.npu.is_available():
        raise AssertionError("npu NOT available, abort")
    run_case("sg_kda", KDA=True, BH=False)


def test_fused_recurrent_gated_delta_rule_fwd_kernel_headwise():
    if not torch.npu.is_available():
        raise AssertionError("npu NOT available, abort")
    run_case("sg_headwise", KDA=False, BH=True)


if __name__ == "__main__":
    test_fused_recurrent_gated_delta_rule_fwd_kernel_main()
    # test_fused_recurrent_gated_delta_rule_fwd_kernel_kda()
    # test_fused_recurrent_gated_delta_rule_fwd_kernel_headwise()

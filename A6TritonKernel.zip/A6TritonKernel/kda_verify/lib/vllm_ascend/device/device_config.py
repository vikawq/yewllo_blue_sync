def is_950() -> bool:
    """Return True on A5/950 hardware. Without an NPU device, returns False;
    the DCP harness forces it to True via its LaunchSpy context."""
    try:
        import torch

        if hasattr(torch, "npu") and torch.npu.is_available():
            name = torch.npu.get_device_name(0)
            return "950" in name
    except Exception:
        pass
    return False

_initialized = False


def init_device_properties_triton(*args, **kwargs):
    global _initialized
    _initialized = True


def get_vectorcore_num() -> int:
    """Best-effort number of vector cores; falls back to a sane default when
    no NPU is reachable."""
    try:
        import torch

        if hasattr(torch, "npu") and torch.npu.is_available():
            props = torch.npu.get_device_properties(0)
            if hasattr(props, "vector_core_num"):
                return int(props.vector_core_num)
            if hasattr(props, "multi_processor_count"):
                return int(props.multi_processor_count)
    except Exception:
        pass
    return 48

# SPDX-License-Identifier: Apache-2.0
# SPDX-FileCopyrightText: Copyright contributors to the vLLM project
"""Triton kernels for the Qwen4Exp weight-free QSA path.

Adapted from ``vllm/models/qwen4_exp/nvidia/ops/qsa.py``.  The kernels are
shared with upstream; device validation and top-k dispatch are specialized
for triton-ascend and torch-npu.
"""

from __future__ import annotations

import math

import torch
from vllm.triton_utils import HAS_TRITON, tl, triton

_LOGITS_WORKSPACE_BYTES = 128 * 1024 * 1024


@triton.jit
def _qsa_mqa_paged_kernel(
    q_ptr,
    k_cache_ptr,
    page_table_ptr,
    token_to_req_ptr,
    query_positions_ptr,
    sequence_lengths_ptr,
    visible_blocks_ptr,
    logits_ptr,
    stride_q_row,
    stride_q_head,
    stride_q_dim,
    stride_cache_block,
    stride_cache_token,
    stride_cache_dim,
    stride_table_req,
    stride_table_page,
    stride_logits_row,
    num_rows,
    num_columns,
    num_pages,
    num_requests,
    score_divisor,
    PAGE_SIZE: tl.constexpr,
    PAGE_TABLE_WIDTH: tl.constexpr,
    NUM_HEADS: tl.constexpr,
    HEAD_DIM: tl.constexpr,
    BLOCK_N: tl.constexpr,
    BLOCK_D: tl.constexpr,
    TILES_PER_PROG: tl.constexpr,
    TILES_PER_PAGE: tl.constexpr,
    PAGE_PROGRAM: tl.constexpr,
    STAGES: tl.constexpr,
    MAX_N: tl.constexpr,
    COMPRESS_RATIO: tl.constexpr,
) -> None:
    row = tl.program_id(0)
    dims = tl.arange(0, BLOCK_D)
    heads = tl.arange(0, MAX_N)
    request = tl.load(token_to_req_ptr + row)
    safe_request = tl.minimum(tl.maximum(request, 0), num_requests - 1)
    query_position = tl.load(query_positions_ptr + row)
    sequence_length = tl.load(
        sequence_lengths_ptr + safe_request,
        mask=(request >= 0) & (request < num_requests),
        other=0,
    )
    visible = tl.minimum(
        (query_position + 1) // COMPRESS_RATIO,
        sequence_length // COMPRESS_RATIO,
    )
    if tl.program_id(1) == 0:
        tl.store(visible_blocks_ptr + row, visible)
    tile_start = tl.program_id(1) * TILES_PER_PROG
    # Every logits column must be defined because torch.topk reads the full
    # capacity.  Visible padding is written as -inf rather than left stale.
    tile_end = tl.minimum(tile_start + TILES_PER_PROG, tl.cdiv(num_columns, BLOCK_N))

    # Pad the small head axis to a tensor-core-compatible N dimension.
    query = tl.load(
        q_ptr + row * stride_q_row + heads[None, :] * stride_q_head + dims[:, None] * stride_q_dim,
        mask=(heads[None, :] < NUM_HEADS) & (dims[:, None] < HEAD_DIM),
        other=0.0,
    )
    column_offsets = tl.arange(0, BLOCK_N)
    if PAGE_PROGRAM:
        # A page program reuses one request/page-table lookup and one physical
        # base address across the three contiguous 64-row tiles of a 192-row
        # compressed cache page.  This path is bounded to small row batches by
        # the Python wrapper; larger batches retain the one-tile M1 fallback.
        logical_page = tl.program_id(1)
        physical_page = tl.load(
            page_table_ptr + safe_request * stride_table_req + logical_page * stride_table_page,
            mask=(request >= 0) & (request < num_requests) & (logical_page < PAGE_TABLE_WIDTH),
            other=-1,
        )
        safe_physical_page = tl.maximum(physical_page, 0).to(tl.int64)
        page_base = k_cache_ptr + safe_physical_page * stride_cache_block
        physical_page_valid = (physical_page >= 0) & (physical_page < num_pages)
        for tile_in_page in tl.static_range(0, TILES_PER_PAGE):
            page_offset = tile_in_page * BLOCK_N + column_offsets
            columns = logical_page * PAGE_SIZE + page_offset
            live = columns < visible
            page_valid = live & physical_page_valid
            keys = tl.load(
                page_base + page_offset[:, None] * stride_cache_token + dims[None, :] * stride_cache_dim,
                mask=page_valid[:, None] & (dims[None, :] < HEAD_DIM),
                other=0.0,
                eviction_policy="evict_first",
            )
            scores = tl.dot(keys, query, out_dtype=tl.float32)
            scores = tl.where(heads[None, :] < NUM_HEADS, tl.maximum(scores, 0.0), 0.0)
            score = tl.sum(scores, axis=1) / score_divisor
            tl.store(
                logits_ptr + row * stride_logits_row + columns,
                tl.where(page_valid, score, -float("inf")),
                mask=columns < num_columns,
            )
    else:
        for tile in tl.range(tile_start, tile_end, num_stages=STAGES):
            logical_page = tile // TILES_PER_PAGE
            page_offset = (tile % TILES_PER_PAGE) * BLOCK_N + column_offsets
            columns = logical_page * PAGE_SIZE + page_offset
            live = columns < visible
            physical_page = tl.load(
                page_table_ptr + safe_request * stride_table_req + logical_page * stride_table_page,
                mask=(request >= 0) & (request < num_requests) & (logical_page < PAGE_TABLE_WIDTH),
                other=-1,
            )
            page_valid = live & (physical_page >= 0) & (physical_page < num_pages)
            # physical_page * block stride can overflow int32 for large caches.
            safe_physical_page = tl.maximum(physical_page, 0).to(tl.int64)
            keys = tl.load(
                k_cache_ptr
                + safe_physical_page * stride_cache_block
                + page_offset[:, None] * stride_cache_token
                + dims[None, :] * stride_cache_dim,
                mask=page_valid[:, None] & (dims[None, :] < HEAD_DIM),
                other=0.0,
                eviction_policy="evict_first",
            )
            scores = tl.dot(keys, query, out_dtype=tl.float32)
            scores = tl.where(heads[None, :] < NUM_HEADS, tl.maximum(scores, 0.0), 0.0)
            score = tl.sum(scores, axis=1) / score_divisor
            # topk consumes the full capacity, so invalid columns must contain
            # a deterministic sentinel instead of retaining stale storage.
            tl.store(
                logits_ptr + row * stride_logits_row + columns,
                tl.where(page_valid, score, -float("inf")),
                mask=columns < num_columns,
            )


@triton.jit
def _expand_qsa_indices_kernel(
    block_indices_ptr,
    query_positions_ptr,
    sequence_lengths_ptr,
    token_to_req_ptr,
    output_ptr,
    stride_blocks_row,
    stride_blocks_column,
    stride_output_row,
    stride_output_column,
    rows,
    num_requests,
    BLOCK_TOPK: tl.constexpr,
    COMPRESS_RATIO: tl.constexpr,
    TOKEN_TOPK: tl.constexpr,
    OUTPUT_WIDTH: tl.constexpr,
    COLUMN_BLOCK: tl.constexpr,
) -> None:
    row = tl.program_id(0)
    columns = tl.program_id(1) * COLUMN_BLOCK + tl.arange(0, COLUMN_BLOCK)
    query_position = tl.load(query_positions_ptr + row)
    request = tl.load(token_to_req_ptr + row)
    safe_request = tl.minimum(tl.maximum(request, 0), num_requests - 1)
    sequence_length = tl.load(
        sequence_lengths_ptr + safe_request,
        mask=(request >= 0) & (request < num_requests),
        other=0,
    )
    complete_blocks = tl.minimum(
        tl.minimum(
            (query_position + 1) // COMPRESS_RATIO,
            sequence_length // COMPRESS_RATIO,
        ),
        BLOCK_TOPK,
    )
    expanded_count = complete_blocks * COMPRESS_RATIO
    tail_start = ((query_position + 1) // COMPRESS_RATIO) * COMPRESS_RATIO
    tail_count = (query_position + 1) - tail_start

    is_expanded = columns < expanded_count
    block_rank = columns // COMPRESS_RATIO
    offset = columns % COMPRESS_RATIO
    safe_rank = tl.minimum(block_rank, BLOCK_TOPK - 1)
    block = tl.load(
        block_indices_ptr + row * stride_blocks_row + safe_rank * stride_blocks_column,
        mask=(row < rows) & is_expanded,
        other=-1,
    )
    expanded = block * COMPRESS_RATIO + offset
    tail_offset = columns - expanded_count
    is_tail = (columns >= expanded_count) & (tail_offset < tail_count) & (tail_offset < COMPRESS_RATIO - 1)
    token = tl.where(is_expanded, expanded, tail_start + tail_offset)
    valid = (row < rows) & (columns < OUTPUT_WIDTH) & (is_expanded | is_tail) & (token >= 0) & (token < sequence_length)
    tl.store(
        output_ptr + row * stride_output_row + columns * stride_output_column,
        tl.where(valid, token, -1),
        mask=(row < rows) & (columns < OUTPUT_WIDTH),
    )


@triton.jit
def _qsa_sparse_paged_gqa_splitk_kernel(
    q_ptr,
    k_cache_ptr,
    v_cache_ptr,
    indices_ptr,
    block_table_ptr,
    token_to_req_ptr,
    partial_output_ptr,
    partial_lse_ptr,
    output_ptr,
    stride_q_row,
    stride_q_head,
    stride_k_block,
    stride_k_token,
    stride_k_head,
    stride_v_block,
    stride_v_token,
    stride_v_head,
    stride_indices_row,
    stride_table_req,
    stride_output_row,
    stride_output_head,
    num_rows,
    num_cache_blocks,
    num_requests,
    TOPK: tl.constexpr,
    PAGE_SIZE: tl.constexpr,
    PAGE_TABLE_WIDTH: tl.constexpr,
    GROUP_SIZE: tl.constexpr,
    HEAD_DIM: tl.constexpr,
    NUM_QUERY_HEADS: tl.constexpr,
    NUM_SPLITS: tl.constexpr,
    NUM_TILES: tl.constexpr,
    BLOCK_M: tl.constexpr,
    BLOCK_N: tl.constexpr,
) -> None:
    row = tl.program_id(0)
    kv_head = tl.program_id(1)
    split_id = tl.program_id(2)
    request = tl.load(token_to_req_ptr + row)
    safe_request = tl.minimum(tl.maximum(request, 0), num_requests - 1)

    head_offsets = tl.arange(0, BLOCK_M)
    dim_offsets = tl.arange(0, HEAD_DIM)
    column_offsets = tl.arange(0, BLOCK_N)
    first_head = kv_head * GROUP_SIZE
    query = tl.load(
        q_ptr + row * stride_q_row + (first_head + head_offsets[:, None]) * stride_q_head + dim_offsets[None, :],
        mask=head_offsets[:, None] < GROUP_SIZE,
        other=0.0,
    )

    max_value = tl.full((BLOCK_M,), -1.0e20, dtype=tl.float32)
    normalizer = tl.zeros((BLOCK_M,), dtype=tl.float32)
    accumulator = tl.zeros((BLOCK_M, HEAD_DIM), dtype=tl.float32)
    softmax_scale_log2: tl.constexpr = (HEAD_DIM**-0.5) * 1.4426950408889634

    # Dynamic bounds avoid padded main-loop iterations for uneven splits.
    split_tile_start = split_id * NUM_TILES // NUM_SPLITS
    split_tile_end = (split_id + 1) * NUM_TILES // NUM_SPLITS
    for tile in range(split_tile_start, split_tile_end):
        columns = tile * BLOCK_N + column_offsets
        logical_token = tl.load(
            indices_ptr + row * stride_indices_row + columns,
            mask=columns < TOPK,
            other=-1,
        )
        safe_token = tl.maximum(logical_token, 0)
        logical_page = safe_token // PAGE_SIZE
        page_offset = safe_token % PAGE_SIZE
        valid = (request >= 0) & (request < num_requests) & (logical_token >= 0) & (logical_page < PAGE_TABLE_WIDTH)
        physical_page = tl.load(
            block_table_ptr + safe_request * stride_table_req + tl.minimum(logical_page, PAGE_TABLE_WIDTH - 1),
            mask=valid,
            other=-1,
        )
        valid &= (physical_page >= 0) & (physical_page < num_cache_blocks)
        # physical_page * block stride can overflow int32 for large caches.
        safe_page = tl.maximum(physical_page, 0).to(tl.int64)
        # Load K in its source-contiguous [token, head_dim] layout.  Loading
        # it directly as [head_dim, token] makes the scattered token axis the
        # innermost address expression, which Triton-Ascend lowers to costly
        # scalarized gathers and UB reformats.  The transpose stays in UB and
        # preserves the [head_dim, token] layout expected by the QK dot.
        key_rows = tl.load(
            k_cache_ptr
            + safe_page[:, None] * stride_k_block
            + page_offset[:, None] * stride_k_token
            + kv_head * stride_k_head
            + dim_offsets[None, :],
            mask=valid[:, None],
            other=0.0,
        )
        keys = tl.trans(key_rows)
        values = tl.load(
            v_cache_ptr
            + safe_page[:, None] * stride_v_block
            + page_offset[:, None] * stride_v_token
            + kv_head * stride_v_head
            + dim_offsets[None, :],
            mask=valid[:, None],
            other=0.0,
        )
        scores = tl.dot(query, keys)
        # Scaling scores avoids re-quantizing a scaled query to BF16.
        scores *= softmax_scale_log2
        scores = tl.where(valid[None, :], scores, -1.0e20)
        next_max = tl.maximum(max_value, tl.max(scores, axis=1))
        alpha = tl.math.exp2(max_value - next_max)
        probabilities = tl.where(valid[None, :], tl.math.exp2(scores - next_max[:, None]), 0.0)
        accumulator = tl.dot(
            probabilities.to(values.dtype),
            values,
            acc=accumulator * alpha[:, None],
        )
        normalizer = normalizer * alpha + tl.sum(probabilities, axis=1)
        max_value = next_max

    has_values = normalizer > 0
    normalized_output = tl.where(
        has_values[:, None],
        accumulator / tl.maximum(normalizer[:, None], 1.0e-20),
        0.0,
    )
    output_mask = head_offsets[:, None] < GROUP_SIZE
    if NUM_SPLITS == 1:
        tl.store(
            output_ptr
            + row * stride_output_row
            + (first_head + head_offsets[:, None]) * stride_output_head
            + dim_offsets[None, :],
            normalized_output,
            mask=output_mask,
        )
    else:
        partial_lse = tl.where(
            has_values,
            max_value + tl.math.log2(tl.maximum(normalizer, 1.0e-20)),
            -float("inf"),
        )
        tl.store(
            partial_output_ptr
            + ((split_id * num_rows + row) * NUM_QUERY_HEADS + first_head + head_offsets[:, None]) * HEAD_DIM
            + dim_offsets[None, :],
            normalized_output,
            mask=output_mask,
        )
        tl.store(
            partial_lse_ptr + (split_id * num_rows + row) * NUM_QUERY_HEADS + first_head + head_offsets,
            partial_lse,
            mask=head_offsets < GROUP_SIZE,
        )


@triton.jit
def _qsa_merge_splitk_kernel(
    partial_output_ptr,
    partial_lse_ptr,
    output_ptr,
    stride_output_row,
    stride_output_head,
    num_rows,
    HEAD_DIM: tl.constexpr,
    NUM_QUERY_HEADS: tl.constexpr,
    NUM_SPLITS: tl.constexpr,
    BLOCK_SPLITS: tl.constexpr,
) -> None:
    row = tl.program_id(0)
    head = tl.program_id(1)
    split_offsets = tl.arange(0, BLOCK_SPLITS)
    dim_offsets = tl.arange(0, HEAD_DIM)
    split_mask = split_offsets < NUM_SPLITS
    lse = tl.load(
        partial_lse_ptr + (split_offsets * num_rows + row) * NUM_QUERY_HEADS + head,
        mask=split_mask,
        other=-float("inf"),
    )
    lse_max = tl.max(lse, axis=0)
    has_values = lse_max > -float("inf")
    shifted = tl.where(split_mask & has_values, lse - lse_max, -float("inf"))
    weights = tl.math.exp2(shifted)
    denominator = tl.sum(weights, axis=0)
    partial_output = tl.load(
        partial_output_ptr
        + ((split_offsets[:, None] * num_rows + row) * NUM_QUERY_HEADS + head) * HEAD_DIM
        + dim_offsets[None, :],
        mask=split_mask[:, None],
        other=0.0,
    )
    merged = tl.sum(partial_output * weights[:, None], axis=0)
    merged = tl.where(denominator > 0, merged / denominator, 0.0)
    tl.store(
        output_ptr + row * stride_output_row + head * stride_output_head + dim_offsets,
        merged,
    )


@triton.jit
def _store_qsa_rows_kernel(
    cache_ptr,
    slots_ptr,
    rows_ptr,
    stride_cache_block,
    stride_cache_token,
    stride_cache_dim,
    stride_rows_row,
    stride_rows_dim,
    num_rows,
    num_blocks,
    PAGE_SIZE: tl.constexpr,
    WIDTH: tl.constexpr,
    BLOCK_D: tl.constexpr,
) -> None:
    row = tl.program_id(0)
    dims = tl.arange(0, BLOCK_D)
    slot = tl.load(slots_ptr + row)
    valid = (row < num_rows) & (slot >= 0) & (slot < num_blocks * PAGE_SIZE)
    block = tl.maximum(slot, 0) // PAGE_SIZE
    token = tl.maximum(slot, 0) % PAGE_SIZE
    values = tl.load(
        rows_ptr + row * stride_rows_row + dims * stride_rows_dim,
        mask=valid & (dims < WIDTH),
        other=0,
    )
    tl.store(
        cache_ptr + block * stride_cache_block + token * stride_cache_token + dims * stride_cache_dim,
        values,
        mask=valid & (dims < WIDTH),
    )


@triton.jit
def _compress_qsa_groups_kernel(
    raw_keys_ptr,  # this step's raw key rows, straight from activations
    raw_positions_ptr,  # this step's per-token positions
    compressor_state_cache_ptr,  # per-request ring of previous raw keys
    rope_cache_ptr,  # packed RoPE position tail of the ring
    compressor_state_table_ptr,
    token_to_req_ptr,
    query_start_loc_ptr,
    logical_positions_ptr,
    compressed_slots_ptr,
    pooled_ptr,
    first_positions_ptr,
    stride_raw_row,
    stride_raw_dim,
    stride_raw_positions_row,
    stride_raw_positions_dim,
    stride_compressor_state_block,
    stride_compressor_state_token,
    stride_compressor_state_dim,
    stride_rope_block,
    stride_rope_token,
    stride_rope_dim,
    stride_compressor_state_table_req,
    stride_pooled_row,
    stride_pooled_dim,
    stride_positions_row,
    stride_positions_dim,
    num_rows,
    num_compressor_state_blocks,
    num_requests,
    COMPRESSOR_STATE_SIZE: tl.constexpr,
    COMPRESS_RATIO: tl.constexpr,
    HEAD_DIM: tl.constexpr,
    BLOCK_D: tl.constexpr,
    LOAD_ROPE_POSITIONS: tl.constexpr,
) -> None:
    row = tl.program_id(0)
    dims = tl.arange(0, BLOCK_D)
    request = tl.load(token_to_req_ptr + row)
    end_position = tl.load(logical_positions_ptr + row)
    compressed_slot = tl.load(compressed_slots_ptr + row)
    valid_request = (request >= 0) & (request < num_requests)
    safe_request = tl.minimum(tl.maximum(request, 0), num_requests - 1)
    query_row_start = tl.load(query_start_loc_ptr + safe_request, mask=valid_request, other=0)
    query_row_end = tl.load(query_start_loc_ptr + safe_request + 1, mask=valid_request, other=0)
    chunk_start_position = end_position - (row - query_row_start)
    compressor_state_block = tl.load(
        compressor_state_table_ptr + safe_request * stride_compressor_state_table_req,
        mask=valid_request,
        other=-1,
    )
    valid_compressor_state_block = (compressor_state_block >= 0) & (
        compressor_state_block < num_compressor_state_blocks
    )
    valid_row = (
        (row < num_rows)
        & valid_request
        & (row >= query_row_start)
        & (row < query_row_end)
        & (end_position >= COMPRESS_RATIO - 1)
        & (compressed_slot >= 0)
    )
    accumulator = tl.zeros((BLOCK_D,), dtype=tl.float32)

    # A group can span the compressor-state ring (older members) and this
    # step's raw rows (members at positions >= chunk_start_position).
    for group_offset in tl.range(0, COMPRESS_RATIO):
        position = end_position - (COMPRESS_RATIO - 1 - group_offset)
        use_raw = position >= chunk_start_position
        raw_row = query_row_start + position - chunk_start_position
        raw_values = tl.load(
            raw_keys_ptr + raw_row * stride_raw_row + dims * stride_raw_dim,
            mask=valid_row
            & use_raw
            & (raw_row >= query_row_start)
            & (raw_row < query_row_end)
            & (raw_row < num_rows)
            & (dims < HEAD_DIM),
            other=0.0,
        ).to(tl.float32)
        compressor_state_values = tl.load(
            compressor_state_cache_ptr
            + tl.maximum(compressor_state_block, 0).to(tl.int64) * stride_compressor_state_block
            + (position % COMPRESSOR_STATE_SIZE) * stride_compressor_state_token
            + dims * stride_compressor_state_dim,
            mask=valid_row & ~use_raw & valid_compressor_state_block & (dims < HEAD_DIM),
            other=0.0,
        ).to(tl.float32)
        accumulator += tl.where(use_raw, raw_values, compressor_state_values)

    tl.store(
        pooled_ptr + row * stride_pooled_row + dims * stride_pooled_dim,
        accumulator / COMPRESS_RATIO,
        mask=(row < num_rows) & (dims < HEAD_DIM),
    )

    position_dims = tl.arange(0, 4)
    first_position = end_position - COMPRESS_RATIO + 1
    if LOAD_ROPE_POSITIONS:
        first_from_raw = first_position >= chunk_start_position
        raw_first_row = query_row_start + first_position - chunk_start_position
        raw_position_values = tl.load(
            raw_positions_ptr + raw_first_row * stride_raw_positions_row + position_dims * stride_raw_positions_dim,
            mask=valid_row
            & first_from_raw
            & (raw_first_row >= query_row_start)
            & (raw_first_row < query_row_end)
            & (raw_first_row < num_rows)
            & (position_dims < 3),
            other=0,
        )
        compressor_state_position_values = tl.load(
            rope_cache_ptr
            + tl.maximum(compressor_state_block, 0).to(tl.int64) * stride_rope_block
            + (first_position % COMPRESSOR_STATE_SIZE) * stride_rope_token
            + position_dims * stride_rope_dim,
            mask=valid_row & ~first_from_raw & valid_compressor_state_block & (position_dims < 3),
            other=0,
        )
        position_values = tl.where(
            first_from_raw,
            raw_position_values,
            compressor_state_position_values,
        )
    else:
        position_values = tl.where(valid_row, first_position, 0)
    tl.store(
        first_positions_ptr + row * stride_positions_row + position_dims * stride_positions_dim,
        position_values,
        mask=(row < num_rows) & (position_dims < 3),
    )


@triton.jit
def _gemma_rmsnorm_neox_rope(
    x,
    pos_t,
    pos_h,
    pos_w,
    row_valid,
    cos_sin_ptr,
    cos_sin_stride,
    num_rope_positions,
    norm_weight_ptr,
    eps,
    IS_MROPE: tl.constexpr,
):
    """Apply Gemma RMSNorm and NeoX RoPE to register-resident rows."""

    tile_t: tl.constexpr = x.shape[0]
    tile_h: tl.constexpr = x.shape[1]
    head_dim: tl.constexpr = x.shape[2]
    rows: tl.constexpr = tile_t * tile_h
    rotary_dim: tl.constexpr = head_dim // 2
    rotary_half: tl.constexpr = rotary_dim // 2

    pairs = tl.arange(0, rotary_half)
    valid_t = row_valid[:, None] & (pos_t[:, None] >= 0) & (pos_t[:, None] < num_rope_positions)

    if IS_MROPE:
        valid_h = row_valid[:, None] & (pos_h[:, None] >= 0) & (pos_h[:, None] < num_rope_positions)

        valid_w = row_valid[:, None] & (pos_w[:, None] >= 0) & (pos_w[:, None] < num_rope_positions)

        h_mask = (pairs % 3) == 1
        w_mask = (pairs % 3) == 2
        t_mask = ~(h_mask | w_mask)

        base = cos_sin_ptr + pairs[None, :]

        cos = tl.load(base + pos_t[:, None] * cos_sin_stride, mask=valid_t & t_mask[None, :], other=0.0)

        cos += tl.load(base + pos_h[:, None] * cos_sin_stride, mask=valid_h & h_mask[None, :], other=0.0)

        cos += tl.load(base + pos_w[:, None] * cos_sin_stride, mask=valid_w & w_mask[None, :], other=0.0)

        sin = tl.load(base + pos_t[:, None] * cos_sin_stride + rotary_half, mask=valid_t & t_mask[None, :], other=0.0)

        sin += tl.load(base + pos_h[:, None] * cos_sin_stride + rotary_half, mask=valid_h & h_mask[None, :], other=0.0)

        sin += tl.load(base + pos_w[:, None] * cos_sin_stride + rotary_half, mask=valid_w & w_mask[None, :], other=0.0)
    else:
        cos = tl.load(cos_sin_ptr + pos_t[:, None] * cos_sin_stride + pairs[None, :], mask=valid_t, other=0.0)

        sin = tl.load(
            cos_sin_ptr + pos_t[:, None] * cos_sin_stride + rotary_half + pairs[None, :], mask=valid_t, other=0.0
        )

    cos = tl.reshape(
        tl.broadcast_to(
            cos[:, None, :],
            (tile_t, tile_h, rotary_half),
        ),
        (rows, rotary_half),
    )

    sin = tl.reshape(
        tl.broadcast_to(
            sin[:, None, :],
            (tile_t, tile_h, rotary_half),
        ),
        (rows, rotary_half),
    )

    x = tl.reshape(x, (rows, head_dim)).to(tl.float32)
    weight = tl.load(norm_weight_ptr + tl.arange(0, head_dim)).to(tl.float32)
    weight += 1.0

    rrms = tl.rsqrt(tl.sum(x * x, axis=1) / head_dim + eps)
    y = x * rrms[:, None] * weight[None, :]
    y = y.to(cos.dtype)

    rotated, passthrough = tl.split(
        tl.permute(
            tl.reshape(y, (rows, 2, rotary_dim)),
            (0, 2, 1),
        )
    )

    rotary_first, rotary_second = tl.split(
        tl.permute(
            tl.reshape(
                rotated,
                (rows, 2, rotary_half),
            ),
            (0, 2, 1),
        )
    )

    rotated_first = rotary_first * cos - rotary_second * sin
    rotated_second = rotary_second * cos + rotary_first * sin

    rotated = tl.reshape(
        tl.permute(
            tl.join(rotated_first, rotated_second),
            (0, 2, 1),
        ),
        (rows, rotary_dim),
    )
    result = tl.reshape(
        tl.permute(tl.join(rotated, passthrough), (0, 2, 1)),
        (rows, head_dim),
    )
    return tl.reshape(
        result,
        (tile_t, tile_h, head_dim),
    )


@triton.jit(
    do_not_specialize=[
        "num_tokens",
        "num_requests",
        "num_state_blocks",
        "num_compressed_blocks",
        "num_rope_positions",
    ]
)
def _qsa_update_compressed_cache_kernel(
    raw_keys_ptr,
    raw_keys_stride_token,
    positions_ptr,
    positions_stride_axis,
    positions_stride_token,
    cos_sin_ptr,
    cos_sin_stride,
    num_rope_positions,
    k_norm_weight_pr,
    eps,
    state_cache_ptr,
    state_cache_stride_block,
    state_cache_stride_token,
    state_cache_stride_dim,
    state_positions_ptr,
    state_positions_stride_block,
    state_positions_stride_token,
    state_positions_stride_axis,
    state_block_table_ptr,
    state_block_table_stride_request,
    query_start_loc_ptr,
    logical_positions_ptr,
    compressed_slots_ptr,
    k_work_metadata_ptr,
    k_work_metadata_stride_work,
    k_work_metadata_stride_field,
    compressed_cache_ptr,
    compressed_cache_stride_block,
    compressed_cache_stride_token,
    compressed_cache_stride_dim,
    num_tokens,
    num_requests,
    num_state_blocks,
    num_compressed_blocks,
    HEAD_DIM: tl.constexpr,
    COMPRESS_RATIO: tl.constexpr,
    STATE_SIZE: tl.constexpr,
    COMPRESSED_PAGE_SIZE: tl.constexpr,
    IS_2D_POSITIONS: tl.constexpr,
    IS_MROPE: tl.constexpr,
    CACHE_HAS_ROPE_POSITIONS: tl.constexpr,
):
    """Produce completed compressed K groups and store them directly."""
    work_id = tl.program_id(0)
    request = tl.load(k_work_metadata_ptr + work_id * k_work_metadata_stride_work)
    work_in_request = tl.load(
        k_work_metadata_ptr + work_id * k_work_metadata_stride_work + k_work_metadata_stride_field
    )
    valid_request = (request >= 0) & (request < num_requests) & (work_in_request >= 0)
    if not valid_request:
        return

    query_start = tl.load(query_start_loc_ptr + request)
    query_end = tl.load(query_start_loc_ptr + request + 1)

    valid_query = (query_start >= 0) & (query_end > query_start) & (query_end <= num_tokens)

    if not valid_query:
        return

    query_length = query_end - query_start

    chunk_end = tl.load(logical_positions_ptr + query_end - 1)
    chunk_start = chunk_end - query_length + 1

    num_groups = (chunk_end + 1) // COMPRESS_RATIO - chunk_start // COMPRESS_RATIO

    if work_in_request >= num_groups:
        return

    first_boundary = ((chunk_start + COMPRESS_RATIO) // COMPRESS_RATIO) * COMPRESS_RATIO - 1
    end_position = first_boundary + work_in_request * COMPRESS_RATIO

    boundary_token = query_start + end_position - chunk_start

    valid_boundary = (boundary_token >= query_start) & (boundary_token < query_end) & (boundary_token < num_tokens)
    if not valid_boundary:
        return

    compressed_slot = tl.load(compressed_slots_ptr + boundary_token)
    valid_compressed_slot = (compressed_slot >= 0) & (compressed_slot < num_compressed_blocks * COMPRESSED_PAGE_SIZE)
    if not valid_compressed_slot:
        return

    state_block = tl.load(state_block_table_ptr + request * state_block_table_stride_request)
    valid_state_block = (state_block >= 0) & (state_block < num_state_blocks)

    dims = tl.arange(0, HEAD_DIM)
    compressed_block = (compressed_slot // COMPRESSED_PAGE_SIZE).to(tl.int64)
    compressed_offset = compressed_slot % COMPRESSED_PAGE_SIZE
    compressed_row_ptr = (
        compressed_cache_ptr
        + compressed_block * compressed_cache_stride_block
        + compressed_offset * compressed_cache_stride_token
        + dims * compressed_cache_stride_dim
    )

    # Match the unfused Torch path for inconsistent cache metadata. A valid
    # compressed slot must not retain stale contents when its raw-state block
    # is unavailable, regardless of whether this group crosses the chunk edge.
    if not valid_state_block:
        tl.store(
            compressed_row_ptr,
            tl.zeros((HEAD_DIM,), dtype=tl.float32),
        )
        return

    safe_state_block = tl.maximum(
        state_block,
        0,
    ).to(tl.int64)

    group_offsets = tl.arange(
        0,
        COMPRESS_RATIO,
    )

    source_positions = end_position - (COMPRESS_RATIO - 1) + group_offsets
    source_in_current_chunk = source_positions >= chunk_start
    source_tokens = query_start + source_positions - chunk_start
    valid_source_tokens = (source_tokens >= query_start) & (source_tokens < query_end) & (source_tokens < num_tokens)
    safe_source_tokens = tl.maximum(
        source_tokens,
        0,
    )
    current_values = tl.load(
        raw_keys_ptr + safe_source_tokens[:, None] * raw_keys_stride_token + dims[None, :],
        mask=(source_in_current_chunk[:, None] & valid_source_tokens[:, None]),
        other=0.0,
    ).to(tl.float32)

    state_offsets = source_positions % STATE_SIZE
    cached_values = tl.load(
        state_cache_ptr
        + safe_state_block * state_cache_stride_block
        + state_offsets[:, None] * state_cache_stride_token
        + dims[None, :] * state_cache_stride_dim,
        mask=((~source_in_current_chunk)[:, None] & valid_state_block),
        other=0.0,
    ).to(tl.float32)

    members = tl.where(source_in_current_chunk[:, None], current_values, cached_values)
    pooled = (tl.sum(members, axis=0) / COMPRESS_RATIO).to(tl.bfloat16)

    first_position = end_position - COMPRESS_RATIO + 1
    if CACHE_HAS_ROPE_POSITIONS:
        first_in_current_chunk = first_position >= chunk_start
        first_token = query_start + first_position - chunk_start
        valid_first_token = (first_token >= query_start) & (first_token < query_end) & (first_token < num_tokens)
        safe_first_token = tl.maximum(
            first_token,
            0,
        )
        load_current_position = first_in_current_chunk & valid_first_token
        current_pos_t = tl.load(
            positions_ptr + safe_first_token * positions_stride_token,
            mask=load_current_position,
            other=0,
        )
        if IS_2D_POSITIONS:
            current_pos_h = tl.load(
                positions_ptr + positions_stride_axis + safe_first_token * positions_stride_token,
                mask=load_current_position,
                other=0,
            )
            current_pos_w = tl.load(
                positions_ptr + 2 * positions_stride_axis + safe_first_token * positions_stride_token,
                mask=load_current_position,
                other=0,
            )
        else:
            current_pos_h = current_pos_t
            current_pos_w = current_pos_t

        cached_position_address = (
            state_positions_ptr
            + safe_state_block * state_positions_stride_block
            + (first_position % STATE_SIZE) * state_positions_stride_token
        )

        load_cached_position = (~first_in_current_chunk) & valid_state_block
        cached_pos_t = tl.load(
            cached_position_address,
            mask=load_cached_position,
            other=0,
        )
        cached_pos_h = tl.load(
            cached_position_address + state_positions_stride_axis, mask=load_cached_position, other=0
        )
        cached_pos_w = tl.load(
            cached_position_address + 2 * state_positions_stride_axis, mask=load_cached_position, other=0
        )

        pos_t_scalar = tl.where(
            first_in_current_chunk,
            current_pos_t.to(tl.int64),
            cached_pos_t,
        )

        pos_h_scalar = tl.where(
            first_in_current_chunk,
            current_pos_h.to(tl.int64),
            cached_pos_h,
        )

        pos_w_scalar = tl.where(
            first_in_current_chunk,
            current_pos_w.to(tl.int64),
            cached_pos_w,
        )
    else:
        pos_t_scalar = first_position
        pos_h_scalar = first_position
        pos_w_scalar = first_position

    valid_position = (pos_t_scalar >= 0) & (pos_t_scalar < num_rope_positions)
    if IS_MROPE:
        valid_position &= (
            (pos_h_scalar >= 0)
            & (pos_h_scalar < num_rope_positions)
            & (pos_w_scalar >= 0)
            & (pos_w_scalar < num_rope_positions)
        )
    if not valid_position:
        return

    singleton = tl.arange(0, 1)
    pos_t = pos_t_scalar + singleton
    pos_h = pos_h_scalar + singleton
    pos_w = pos_w_scalar + singleton
    row_valid = valid_position & (singleton == 0)

    normalized_rotated = _gemma_rmsnorm_neox_rope(
        tl.reshape(pooled, (1, 1, HEAD_DIM)),
        pos_t,
        pos_h,
        pos_w,
        row_valid,
        cos_sin_ptr,
        cos_sin_stride,
        num_rope_positions,
        k_norm_weight_pr,
        eps,
        IS_MROPE,
    )
    normalized_rotated = tl.reshape(normalized_rotated, (HEAD_DIM,))
    tl.store(compressed_row_ptr, normalized_rotated)


def qsa_fused_update_compressed_cache(
    raw_keys: torch.Tensor,
    positions: torch.Tensor,
    cos_sin_cache: torch.Tensor,
    k_norm_weight: torch.Tensor,
    eps: float,
    state_cache: torch.Tensor,
    state_position_cache: torch.Tensor | None,
    state_block_table: torch.Tensor,
    query_start_loc: torch.Tensor,
    logical_positions: torch.Tensor,
    compressed_cache: torch.Tensor,
    compressed_slots: torch.Tensor,
    k_work_metadata: torch.Tensor,
    *,
    compress_ratio: int,
    mrope_section: tuple[int, int, int] | None = None,
) -> None:
    """Fuse QSA K compression, norm, RoPE, and compressed-cache store.

    Raw-state cache commit is intentionally handled by a later kernel. The
    caller owns the common device, dtype, and metadata-consistency contract.
    """
    if raw_keys.device.type != "npu" or not HAS_TRITON:
        raise RuntimeError("fused QSA cache update requires NPU and Triton")

    if raw_keys.ndim == 3:
        raw_keys = raw_keys[:, 0]
    num_tokens, head_dim = raw_keys.shape
    if num_tokens == 0 or k_work_metadata.shape[0] == 0:
        return

    # These constraints affect tl.arange shapes or packed-cache addressing;
    # the remaining tensor contracts are guaranteed by the QSA cache owner.
    assert head_dim == 128 and raw_keys.dtype == torch.bfloat16
    assert compress_ratio > 1 and compress_ratio & (compress_ratio - 1) == 0

    if positions.ndim == 2 and positions.shape[0] == 1:
        positions = positions[0]
    is_2d_positions = positions.ndim == 2
    assert positions.shape == ((3, num_tokens) if is_2d_positions else (num_tokens,))
    if is_2d_positions:
        positions_stride_axis, positions_stride_token = positions.stride()
    else:
        positions_stride_axis = 0
        positions_stride_token = positions.stride(0)

    is_mrope = bool(mrope_section)
    if is_mrope:
        # The helper uses the fixed Qwen interleaved [11, 11, 10] layout.
        assert mrope_section == (11, 11, 10)
        assert state_position_cache is not None
    cache_has_rope_positions = state_position_cache is not None
    if state_position_cache is None:
        state_position_cache = logical_positions
        state_positions_stride_block = 0
        state_positions_stride_token = 0
        state_positions_stride_axis = 0
    else:
        state_positions_stride_block = state_position_cache.stride(0)
        state_positions_stride_token = state_position_cache.stride(1)
        state_positions_stride_axis = state_position_cache.stride(3)

    num_requests = min(state_block_table.shape[0], query_start_loc.shape[0] - 1)
    _qsa_update_compressed_cache_kernel[(k_work_metadata.shape[0],)](
        raw_keys,
        raw_keys.stride(0),
        positions,
        positions_stride_axis,
        positions_stride_token,
        cos_sin_cache,
        cos_sin_cache.stride(0),
        cos_sin_cache.shape[0],
        k_norm_weight,
        eps,
        state_cache,
        state_cache.stride(0),
        state_cache.stride(1),
        state_cache.stride(3),
        state_position_cache,
        state_positions_stride_block,
        state_positions_stride_token,
        state_positions_stride_axis,
        state_block_table,
        state_block_table.stride(0),
        query_start_loc,
        logical_positions,
        compressed_slots,
        k_work_metadata,
        k_work_metadata.stride(0),
        k_work_metadata.stride(1),
        compressed_cache,
        compressed_cache.stride(0),
        compressed_cache.stride(1),
        compressed_cache.stride(3),
        num_tokens,
        num_requests,
        state_cache.shape[0],
        compressed_cache.shape[0],
        HEAD_DIM=head_dim,
        COMPRESS_RATIO=compress_ratio,
        STATE_SIZE=state_cache.shape[1],
        COMPRESSED_PAGE_SIZE=compressed_cache.shape[1],
        IS_2D_POSITIONS=is_2d_positions,
        IS_MROPE=is_mrope,
        CACHE_HAS_ROPE_POSITIONS=cache_has_rope_positions,
        num_warps=4,
    )


def _validate_mqa(q: torch.Tensor) -> None:
    if q.ndim != 3 or q.shape[1] <= 0 or q.shape[2] <= 0:
        raise ValueError("QSA query must be [rows, heads, head_dim]")


def qsa_mqa_paged(
    q: torch.Tensor,
    k_cache: torch.Tensor,
    page_table: torch.Tensor,
    token_to_req: torch.Tensor,
    query_positions: torch.Tensor,
    sequence_lengths: torch.Tensor,
    compress_ratio: int,
    num_columns: int | None = None,
    score_scale: float | None = None,
) -> tuple[torch.Tensor, torch.Tensor]:
    """Compute QSA scores directly from a paged compressed-key cache."""

    _validate_mqa(q)
    if q.device.type != "npu" or not HAS_TRITON:
        raise RuntimeError("paged QSA scoring requires NPU and Triton")
    if k_cache.ndim != 4 or k_cache.shape[2] != 1:
        raise ValueError("QSA cache must be [pages, page_size, 1, head_dim]")
    if k_cache.shape[3] != q.shape[2]:
        raise ValueError("QSA query and cache dimensions must match")
    if page_table.ndim != 2:
        raise ValueError("QSA page table must be two-dimensional")
    if q.shape[0] and (not all(k_cache.shape[:2]) or not all(page_table.shape)):
        raise ValueError("QSA paged scoring cache and page table must be nonempty")
    if token_to_req.shape != (q.shape[0],):
        raise ValueError("QSA request mapping must match query rows")
    if query_positions.shape != (q.shape[0],):
        raise ValueError("QSA query positions must match query rows")
    if sequence_lengths.shape != (page_table.shape[0],):
        raise ValueError("QSA sequence lengths must match page-table requests")
    if compress_ratio <= 0:
        raise ValueError("QSA compression ratio must be positive")
    score_divisor = math.sqrt(q.shape[2]) if score_scale is None else score_scale
    if score_divisor <= 0:
        raise ValueError("QSA score scale must be positive")

    capacity = page_table.shape[1] * k_cache.shape[1]
    columns = capacity if num_columns is None else num_columns
    if columns < 0:
        raise ValueError("QSA score width must be non-negative")
    logits = torch.empty((q.shape[0], columns), dtype=torch.float32, device=q.device)
    visible_blocks = torch.empty(q.shape[0], dtype=torch.int32, device=q.device)
    if not q.shape[0] or not columns:
        return logits, visible_blocks
    BLOCK_N = 64
    if k_cache.shape[1] % BLOCK_N:
        raise ValueError("QSA compressed page size must be divisible by the score tile")
    BLOCK_D = max(16, triton.next_power_of_2(q.shape[2]))
    MAX_N = max(16, triton.next_power_of_2(q.shape[1]))
    # A3 requires the per-program paged tile to retain its naturally aligned
    # 64-row layout.  The GB300 eight-tile reuse profile can lower to an
    # unaligned UB vector access once the row batch exceeds 32.
    page_program = 1 < q.shape[0] <= 32
    tiles_per_program = k_cache.shape[1] // BLOCK_N if page_program else 1
    _qsa_mqa_paged_kernel[(q.shape[0], triton.cdiv(columns, BLOCK_N * tiles_per_program))](
        q,
        k_cache,
        page_table,
        token_to_req,
        query_positions,
        sequence_lengths,
        visible_blocks,
        logits,
        q.stride(0),
        q.stride(1),
        q.stride(2),
        k_cache.stride(0),
        k_cache.stride(1),
        k_cache.stride(3),
        page_table.stride(0),
        page_table.stride(1),
        logits.stride(0),
        q.shape[0],
        columns,
        k_cache.shape[0],
        page_table.shape[0],
        float(score_divisor),
        PAGE_SIZE=k_cache.shape[1],
        PAGE_TABLE_WIDTH=page_table.shape[1],
        NUM_HEADS=q.shape[1],
        HEAD_DIM=q.shape[2],
        BLOCK_N=BLOCK_N,
        BLOCK_D=BLOCK_D,
        TILES_PER_PROG=tiles_per_program,
        TILES_PER_PAGE=k_cache.shape[1] // BLOCK_N,
        PAGE_PROGRAM=page_program,
        STAGES=2,
        MAX_N=MAX_N,
        COMPRESS_RATIO=compress_ratio,
        num_warps=2,
    )
    return logits, visible_blocks


def expand_qsa_block_indices_npu(
    block_indices: torch.Tensor,
    query_positions: torch.Tensor,
    sequence_lengths: torch.Tensor,
    token_to_req: torch.Tensor,
    compress_ratio: int,
    token_topk: int,
    out: torch.Tensor | None = None,
) -> torch.Tensor:
    """Expand compressed blocks and compact the causal tail of the open group."""

    if block_indices.device.type != "npu" or not HAS_TRITON:
        raise RuntimeError("QSA NPU expansion requires Triton")
    if token_topk % compress_ratio:
        raise ValueError("QSA token top-k must be divisible by compression ratio")
    block_topk = token_topk // compress_ratio
    output_width = token_topk + compress_ratio - 1
    if block_indices.shape != (query_positions.numel(), block_topk):
        raise ValueError("QSA compressed top-k has an invalid shape")
    if token_to_req.shape != query_positions.shape:
        raise ValueError("QSA request mapping must match query positions")
    if sequence_lengths.ndim != 1 or not sequence_lengths.shape[0]:
        raise ValueError("QSA request sequence lengths must be nonempty")
    if out is None:
        out = torch.empty(
            (block_indices.shape[0], output_width),
            dtype=torch.int32,
            device=block_indices.device,
        )
    elif out.shape != (block_indices.shape[0], output_width):
        raise ValueError("QSA expansion output has an invalid shape")
    if not block_indices.shape[0]:
        return out
    column_block = 256
    _expand_qsa_indices_kernel[(block_indices.shape[0], triton.cdiv(output_width, column_block))](
        block_indices,
        query_positions,
        sequence_lengths,
        token_to_req,
        out,
        block_indices.stride(0),
        block_indices.stride(1),
        out.stride(0),
        out.stride(1),
        block_indices.shape[0],
        sequence_lengths.shape[0],
        BLOCK_TOPK=block_topk,
        COMPRESS_RATIO=compress_ratio,
        TOKEN_TOPK=token_topk,
        OUTPUT_WIDTH=output_width,
        COLUMN_BLOCK=column_block,
        num_warps=4,
    )
    return out


def expand_qsa_block_indices_e3(
    block_indices: torch.Tensor,
    query_positions: torch.Tensor,
    sequence_lengths: torch.Tensor,
    token_to_req: torch.Tensor,
    compress_ratio: int,
    token_topk: int,
    out: torch.Tensor,
) -> torch.Tensor:
    """Expand ratio-4 compressed groups with the graph-safe AscendC E3 op."""
    if compress_ratio != 4 or token_topk != 2048:
        raise ValueError("QSA E3 requires ratio=4 and token_topk=2048")
    if block_indices.shape != (query_positions.numel(), 512):
        raise ValueError("QSA E3 compressed groups must have shape [rows, 512]")
    if out.shape != (block_indices.shape[0], 2051):
        raise ValueError("QSA E3 output must have shape [rows, 2051]")
    row_requests = token_to_req.to(torch.int64)
    row_sequence_lengths = sequence_lengths[row_requests]
    positions = query_positions.to(torch.int32)
    complete_groups = torch.minimum(
        torch.minimum(
            (positions + 1).floor_divide(compress_ratio),
            row_sequence_lengths.floor_divide(compress_ratio),
        ),
        torch.full_like(positions, 512),
    ).to(torch.int32)
    tail_start = ((positions + 1).floor_divide(compress_ratio) * compress_ratio).to(torch.int32)
    tail_count = torch.minimum(
        positions + 1 - tail_start,
        torch.full_like(positions, compress_ratio - 1),
    ).to(torch.int32)
    return torch.ops._C_ascend.qsa_expand_e3_out(
        block_indices,
        complete_groups,
        tail_start,
        tail_count,
        sequence_lengths.to(torch.int32),
        token_to_req.to(torch.int32),
        out,
    )


def qsa_select_paged_tokens(
    q: torch.Tensor,
    k_cache: torch.Tensor,
    page_table: torch.Tensor,
    token_to_req: torch.Tensor,
    query_positions: torch.Tensor,
    sequence_lengths: torch.Tensor,
    token_topk: int,
    compress_ratio: int,
    out: torch.Tensor | None = None,
    *,
    use_e3: bool = False,
) -> torch.Tensor:
    """Score, select, and expand QSA indices without host synchronization."""

    rows = q.shape[0]
    output_width = token_topk + compress_ratio - 1
    if out is None:
        out = torch.empty((rows, output_width), dtype=torch.int32, device=q.device)
    if out.shape != (rows, output_width):
        raise ValueError("QSA selection output has an invalid shape")
    if not rows:
        return out

    columns = page_table.shape[1] * k_cache.shape[1]
    block_topk = token_topk // compress_ratio
    if block_topk > columns:
        raise ValueError(
            "QSA top-k exceeds the compressed cache capacity: "
            f"block_topk={block_topk}, capacity={columns}, "
            f"page_table_width={page_table.shape[1]}, "
            f"storage_block_size={k_cache.shape[1]}"
        )
    # torch.topk needs substantial temporary storage in addition to logits.
    # Bound the row batch so a 4096-token eager prefill does not create a
    # multi-GiB transient while decode D4 x max_num_seqs=32 remains one chunk.
    max_rows_per_chunk = 128
    rows_per_chunk = min(
        max_rows_per_chunk,
        max(1, _LOGITS_WORKSPACE_BYTES // max(columns * 4, 1)),
    )
    chunk_rows = min(rows, rows_per_chunk)
    blocks_buffer = torch.empty((chunk_rows, block_topk), dtype=torch.int32, device=q.device)
    for row_start in range(0, rows, rows_per_chunk):
        row_end = min(row_start + rows_per_chunk, rows)
        row_slice = slice(row_start, row_end)
        logits, _ = qsa_mqa_paged(
            q[row_slice],
            k_cache,
            page_table,
            token_to_req[row_slice],
            query_positions[row_slice],
            sequence_lengths,
            compress_ratio,
        )
        blocks = blocks_buffer[: row_end - row_start]
        blocks.copy_(torch.topk(logits, block_topk, dim=-1).indices.to(torch.int32))
        if use_e3:
            expand_qsa_block_indices_e3(
                blocks,
                query_positions[row_slice],
                sequence_lengths,
                token_to_req[row_slice],
                compress_ratio,
                token_topk,
                out[row_slice],
            )
        else:
            expand_qsa_block_indices_npu(
                blocks,
                query_positions[row_slice],
                sequence_lengths,
                token_to_req[row_slice],
                compress_ratio,
                token_topk,
                out[row_slice],
            )
    return out


def qsa_sparse_paged_attention(
    q: torch.Tensor,
    k_cache: torch.Tensor,
    v_cache: torch.Tensor,
    logical_indices: torch.Tensor,
    block_table: torch.Tensor,
    token_to_req: torch.Tensor,
    out: torch.Tensor | None = None,
) -> torch.Tensor:
    """Run sparse GQA directly over paged BF16 K/V caches."""

    if q.device.type != "npu" or not HAS_TRITON:
        raise RuntimeError("paged QSA sparse attention requires NPU and Triton")
    if q.ndim != 3 or k_cache.ndim != 4 or v_cache.shape != k_cache.shape:
        raise ValueError("QSA sparse attention received invalid Q/K/V shapes")
    if logical_indices.ndim != 2 or logical_indices.shape[0] != q.shape[0]:
        raise ValueError("QSA indices must have one row per query")
    if token_to_req.shape != (q.shape[0],) or block_table.ndim != 2:
        raise ValueError("QSA sparse attention metadata has invalid shapes")
    if not all(k_cache.shape[:3]) or not all(block_table.shape):
        raise ValueError("QSA sparse attention cache and block table must be nonempty")
    if logical_indices.shape[1] <= 0:
        raise ValueError("QSA sparse attention requires a positive selection width")
    if q.shape[2] != k_cache.shape[3] or q.shape[1] % k_cache.shape[2]:
        raise ValueError("QSA sparse attention requires valid grouped-query heads")
    head_dim = q.shape[2]
    assert head_dim >= 16 and (head_dim & (head_dim - 1)) == 0
    assert q.dtype == k_cache.dtype == v_cache.dtype == torch.bfloat16
    assert logical_indices.dtype == block_table.dtype == torch.int32
    assert token_to_req.dtype == torch.int32
    assert q.device == k_cache.device == v_cache.device
    assert q.device == logical_indices.device == block_table.device
    assert q.device == token_to_req.device
    assert q.stride(2) == k_cache.stride(3) == v_cache.stride(3) == 1
    assert logical_indices.stride(1) == block_table.stride(1) == 1
    assert token_to_req.stride(0) == 1
    if out is None:
        out = torch.empty_like(q)
    if out.shape != q.shape:
        raise ValueError("QSA sparse output must match its query")
    assert out.dtype == q.dtype and out.device == q.device
    assert out.stride(2) == 1
    if not q.shape[0]:
        return out

    group_size = q.shape[1] // k_cache.shape[2]
    block_m = triton.next_power_of_2(group_size)
    base_programs = q.shape[0] * k_cache.shape[2]
    small_profile_limit = 8 if block_m <= 8 else 4

    # Tuned on GB300 for the Qwen-Air TP1, TP2, and TP4 attention shapes.
    # Narrow tiles favor decode; wide tiles improve throughput for prefill.
    if base_programs <= small_profile_limit:
        block_n, target_splits, partial_warps = 16, 64, 4
    elif base_programs < 32:
        block_n, target_splits, partial_warps = 16, 32, 4
    elif base_programs <= 256:
        block_n, target_splits, partial_warps = 64, 8, 2
    elif base_programs <= 512:
        block_n, target_splits, partial_warps = 64, 4, 2
    else:
        block_n, target_splits, partial_warps = 64, 1, 2

    num_tiles = triton.cdiv(logical_indices.shape[1], block_n)
    # Avoid empty splits when the selection width is smaller than the profile.
    max_useful_splits = 1 << (num_tiles.bit_length() - 1)
    num_splits = min(max_useful_splits, target_splits)

    # Split=1 writes output directly and compiles out all workspace accesses.
    if num_splits == 1:
        partial_output = out
        partial_lse = out
    else:
        # FP32 partials preserve accuracy when merging independently normalized
        # splits.
        partial_output = torch.empty((num_splits, *q.shape), dtype=torch.float32, device=q.device)
        partial_lse = torch.empty(
            (num_splits, q.shape[0], q.shape[1]),
            dtype=torch.float32,
            device=q.device,
        )

    partial_grid = (q.shape[0], k_cache.shape[2], num_splits)
    _qsa_sparse_paged_gqa_splitk_kernel[partial_grid](
        q,
        k_cache,
        v_cache,
        logical_indices,
        block_table,
        token_to_req,
        partial_output,
        partial_lse,
        out,
        q.stride(0),
        q.stride(1),
        k_cache.stride(0),
        k_cache.stride(1),
        k_cache.stride(2),
        v_cache.stride(0),
        v_cache.stride(1),
        v_cache.stride(2),
        logical_indices.stride(0),
        block_table.stride(0),
        out.stride(0),
        out.stride(1),
        q.shape[0],
        k_cache.shape[0],
        block_table.shape[0],
        TOPK=logical_indices.shape[1],
        PAGE_SIZE=k_cache.shape[1],
        PAGE_TABLE_WIDTH=block_table.shape[1],
        GROUP_SIZE=group_size,
        HEAD_DIM=q.shape[2],
        NUM_QUERY_HEADS=q.shape[1],
        NUM_SPLITS=num_splits,
        NUM_TILES=num_tiles,
        BLOCK_M=block_m,
        BLOCK_N=block_n,
        num_warps=partial_warps,
        num_stages=2,
    )
    if num_splits == 1:
        return out

    _qsa_merge_splitk_kernel[(q.shape[0], q.shape[1])](
        partial_output,
        partial_lse,
        out,
        out.stride(0),
        out.stride(1),
        q.shape[0],
        HEAD_DIM=q.shape[2],
        NUM_QUERY_HEADS=q.shape[1],
        NUM_SPLITS=num_splits,
        BLOCK_SPLITS=triton.next_power_of_2(num_splits),
        num_warps=2,
        num_stages=1,
    )
    return out


def qsa_store_cache_rows(
    cache: torch.Tensor,
    slot_mapping: torch.Tensor,
    rows: torch.Tensor,
) -> None:
    """Store fixed-width rows in a QSA cache without boolean indexing."""

    if cache.device.type != "npu" or not HAS_TRITON:
        raise RuntimeError("QSA NPU cache stores require Triton")
    if cache.ndim != 4 or cache.shape[2] != 1:
        raise ValueError("QSA cache must be [pages, page_size, 1, width]")
    if not all(cache.shape):
        raise ValueError("QSA cache dimensions must be nonzero")
    if rows.ndim == 3:
        if rows.shape[1] != 1:
            raise ValueError("QSA cache rows must have one head")
        rows = rows[:, 0]
    if rows.ndim != 2 or rows.shape[1] != cache.shape[3]:
        raise ValueError("QSA cache rows have an incompatible width")

    # Target prefill can have more graph-padded slots than rows, while an MTP
    # draft pass can have more rows than active slots. Only their aligned
    # prefix denotes real cache updates; the remainder is capacity padding.
    # Both lengths are static graph dimensions, so no host sync is introduced.
    slot_mapping = slot_mapping.reshape(-1)
    num_updates = min(slot_mapping.shape[0], rows.shape[0])
    slot_mapping = slot_mapping[:num_updates]
    rows = rows[:num_updates]
    if not num_updates:
        return
    _store_qsa_rows_kernel[(num_updates,)](
        cache,
        slot_mapping,
        rows,
        cache.stride(0),
        cache.stride(1),
        cache.stride(3),
        rows.stride(0),
        rows.stride(1),
        num_updates,
        cache.shape[0],
        PAGE_SIZE=cache.shape[1],
        WIDTH=cache.shape[3],
        BLOCK_D=triton.next_power_of_2(cache.shape[3]),
        num_warps=4,
    )


def qsa_compress_groups_with_ratio(
    raw_keys: torch.Tensor,  # this step's raw key rows [rows, 1, head_size]
    raw_positions: torch.Tensor,  # this step's positions [rows, 1, 3] int64
    compressor_state_cache: torch.Tensor,
    compressor_state_block_table: torch.Tensor,
    token_to_req: torch.Tensor,
    query_start_loc: torch.Tensor,
    logical_positions: torch.Tensor,
    compressed_slots: torch.Tensor,
    compress_ratio: int,
    rope_cache: torch.Tensor | None = None,
) -> tuple[torch.Tensor, torch.Tensor]:
    """Pool completed groups from the compressor-state ring and raw token rows."""

    if raw_keys.device.type != "npu" or not HAS_TRITON:
        raise RuntimeError("QSA NPU compression requires Triton")
    rows = token_to_req.numel()
    if compress_ratio <= 0:
        raise ValueError("QSA compression ratio must be positive")
    if raw_keys.ndim != 3 or raw_keys.shape[:2] != (rows, 1):
        raise ValueError("QSA raw keys must be [rows, 1, head_size]")
    if raw_positions.shape != (rows, 1, 3) or raw_positions.dtype != torch.int64:
        raise ValueError("QSA raw positions must be [rows, 1, 3] int64")
    if logical_positions.shape != (rows,) or compressed_slots.shape != (rows,):
        raise ValueError("QSA compression metadata must match token rows")
    if compressor_state_cache.ndim != 4 or compressor_state_cache.shape[2] != 1:
        raise ValueError("QSA compressor-state cache has an invalid shape")
    if (
        # The ring is wider than one group so speculative rows cannot alias
        # onto the committed keys of the group still being collected.
        compressor_state_cache.shape[1] < compress_ratio
        or compressor_state_cache.shape[3] != raw_keys.shape[2]
        or compressor_state_cache.dtype != raw_keys.dtype
    ):
        raise ValueError("QSA compressor-state cache does not match the compression layout")
    if compressor_state_block_table.ndim != 2 or compressor_state_block_table.shape[1] < 1:
        raise ValueError("QSA compressor-state block table must contain one block per request")
    if query_start_loc.ndim != 1 or query_start_loc.shape[0] < 2:
        raise ValueError("QSA query starts must contain a terminal offset")
    num_requests = query_start_loc.shape[0] - 1
    if compressor_state_block_table.shape[0] < num_requests:
        raise ValueError("QSA compressor-state block table has too few request rows")
    if rope_cache is not None and (
        rope_cache.ndim != 4
        or rope_cache.shape[:3] != compressor_state_cache.shape[:3]
        or rope_cache.shape[3] != 3
        or rope_cache.dtype != torch.int64
    ):
        raise ValueError("QSA packed position view has an invalid shape or dtype")
    if rows and (not all(compressor_state_cache.shape) or not all(compressor_state_block_table.shape)):
        raise ValueError("QSA compressor-state cache and block table must be nonempty")
    pooled = torch.empty(
        (rows, 1, raw_keys.shape[2]),
        dtype=raw_keys.dtype,
        device=raw_keys.device,
    )
    first_positions = torch.empty((rows, 3), dtype=torch.int64, device=raw_keys.device)
    if not rows:
        return pooled, first_positions
    if rope_cache is None:
        rope_cache = compressor_state_cache
        load_rope_positions = False
    else:
        load_rope_positions = True
    _compress_qsa_groups_kernel[(rows,)](
        raw_keys,
        raw_positions,
        compressor_state_cache,
        rope_cache,
        compressor_state_block_table,
        token_to_req,
        query_start_loc,
        logical_positions,
        compressed_slots,
        pooled,
        first_positions,
        raw_keys.stride(0),
        raw_keys.stride(2),
        raw_positions.stride(0),
        raw_positions.stride(2),
        compressor_state_cache.stride(0),
        compressor_state_cache.stride(1),
        compressor_state_cache.stride(3),
        rope_cache.stride(0),
        rope_cache.stride(1),
        rope_cache.stride(3),
        compressor_state_block_table.stride(0),
        pooled.stride(0),
        pooled.stride(2),
        first_positions.stride(0),
        first_positions.stride(1),
        rows,
        compressor_state_cache.shape[0],
        num_requests,
        COMPRESSOR_STATE_SIZE=compressor_state_cache.shape[1],
        COMPRESS_RATIO=compress_ratio,
        HEAD_DIM=raw_keys.shape[2],
        LOAD_ROPE_POSITIONS=load_rope_positions,
        BLOCK_D=triton.next_power_of_2(raw_keys.shape[2]),
        num_warps=4,
    )
    return pooled, first_positions


__all__ = [
    "expand_qsa_block_indices_npu",
    "qsa_compress_groups_with_ratio",
    "qsa_fused_update_compressed_cache",
    "qsa_mqa_paged",
    "qsa_select_paged_tokens",
    "qsa_sparse_paged_attention",
    "qsa_store_cache_rows",
]

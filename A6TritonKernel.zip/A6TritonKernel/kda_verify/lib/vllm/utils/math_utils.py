def cdiv(a, b):
    return (a + b - 1) // b


def next_power_of_2(x):
    if x < 1:
        return 1
    return 1 << (x - 1).bit_length()

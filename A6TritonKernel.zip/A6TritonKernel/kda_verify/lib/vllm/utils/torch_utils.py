def direct_register_custom_op(*args, **kwargs):
    def _deco(fn):
        return fn

    if args and callable(args[0]) and not kwargs:
        return _deco(args[0])
    return _deco

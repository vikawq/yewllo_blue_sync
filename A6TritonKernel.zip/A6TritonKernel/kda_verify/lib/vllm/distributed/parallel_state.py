class GroupCoordinator:
    """Minimal stand-in for vllm's parallel-state group used only in type hints."""

    def __init__(self, world_size: int = 1):
        self.world_size = world_size
        self.device_group = None

    def all_gather(self, tensor, dim=0):
        return tensor


_groups: dict = {}

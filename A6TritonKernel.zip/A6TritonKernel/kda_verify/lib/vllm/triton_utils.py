# Triton utils shim for self-contained kda_verify.
# Provides just the symbols used by the vendored kernel sources.
import triton
import triton.language as tl

HAS_TRITON = True

__all__ = ["tl", "triton", "HAS_TRITON"]

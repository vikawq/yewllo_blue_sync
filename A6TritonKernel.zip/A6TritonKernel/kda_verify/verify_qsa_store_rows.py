"""
Qwen3.8 Flash Next QSA rows store kernel verification.

Verifies _store_qsa_rows_kernel via qsa_store_cache_rows against an
independent CPU-loop reference. The kernel writes rows into a paged QSA
cache per slot mapping; it is a pure copy (no arithmetic reduction), so
the tolerance is exact: rtol=0, atol=0.

Source baseline: vllm-ascend PR #17762, head commit c6245117753db5e4a3e6fa761adfc6e0f8ee2a3b
Kernel: vllm_ascend/ops/triton/qwen4_exp/qsa.py:414 (_store_qsa_rows_kernel)
Wrapper: vllm_ascend/ops/triton/qwen4_exp/qsa.py:1484 (qsa_store_cache_rows)

Kernel semantics (from source):
    row = program_id(0)
    slot = slots[row]
    valid = (row < num_rows) & (0 <= slot < P*S)
    page = max(slot,0) // S; offset = max(slot,0) % S
    if valid: cache[page, offset, 0, :W] = rows[row, :W]
    Invalid slots write nothing. num_updates = min(rows.shape[0], slots.numel()).

Usage on NPU:
    python verify_qsa_store_rows.py
    python verify_qsa_store_rows.py --pattern minimal
    python verify_qsa_store_rows.py --pattern addressing
    python verify_qsa_store_rows.py --pattern supplementary
    python verify_qsa_store_rows.py --pattern all
"""
import argparse
import os
import sys
from dataclasses import dataclass

import torch

# --- Self-contained path bootstrap ---
BASE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(BASE, "lib"))
# ------------------------------------

try:
    from vllm_ascend.ops.triton.qwen4_exp.qsa import qsa_store_cache_rows
except ImportError:
    print(
        "[ERROR] Cannot import vllm_ascend.ops.triton.qwen4_exp.qsa.\n"
        "This kernel exists in PR #17762 (commit c624511), not in main 37197ea.\n"
        "Add that PR's checkout to sys.path or install it first."
    )
    sys.exit(1)

DEVICE = "npu"
SENTINEL = -7.0  # cache init value, distinct from any row value


# ---------------------------------------------------------------------------
# Independent reference (CPU loop, no NPU kernel involved)
# ---------------------------------------------------------------------------

def store_rows_reference(cache_before: torch.Tensor, slots: torch.Tensor, rows: torch.Tensor) -> torch.Tensor:
    """Independent reference: aligned-prefix writes, invalid slots skipped."""
    expected = cache_before.clone()
    S = cache_before.shape[1]  # page_size
    capacity = cache_before.shape[0] * S
    n = min(rows.shape[0], slots.numel())
    for i in range(n):
        slot = int(slots[i].cpu())
        if 0 <= slot < capacity:
            expected[slot // S, slot % S, 0] = rows[i].reshape(-1).to(cache_before.dtype)
    return expected


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

@dataclass
class TestResult:
    name: str
    passed: bool
    detail: str = ""


def make_rows(n: int, w: int, dtype: torch.dtype) -> torch.Tensor:
    """Each row and each column distinct, BF16-representable, non-zero."""
    idx = torch.arange(n, dtype=torch.float32, device=DEVICE)
    cols = torch.linspace(0.25, 2.0, w, dtype=torch.float32, device=DEVICE)
    return (idx[:, None] + cols[None, :] + 0.125).to(dtype)


def make_cache(pages: int, page_size: int, width: int, dtype: torch.dtype) -> torch.Tensor:
    return torch.full((pages, page_size, 1, width), SENTINEL, dtype=dtype, device=DEVICE)


def run_case(
    name: str,
    cache: torch.Tensor,
    slots: torch.Tensor,
    rows: torch.Tensor,
    rows_is_view_src: bool = False,
    extra_checks: bool = True,
) -> list:
    """Run one store case and verify against the reference."""
    results = []
    cache_before = cache.clone()
    rows_before = rows.clone()
    slots_before = slots.clone()

    ret = qsa_store_cache_rows(cache, slots, rows)
    torch.npu.synchronize()

    expected = store_rows_reference(cache_before, slots_before, rows_before)

    # 1. Exact element-wise match (pure copy, no arithmetic).
    try:
        torch.testing.assert_close(cache, expected, rtol=0, atol=0)
        results.append(TestResult(f"{name}_exact_match", True))
    except AssertionError as e:
        max_diff = (cache.float() - expected.float()).abs().max().item()
        results.append(TestResult(f"{name}_exact_match", False, f"max_diff={max_diff:.6e}\n{str(e)[:400]}"))

    if extra_checks:
        # 2. In-place: the original cache allocation must be modified.
        results.append(TestResult(
            f"{name}_inplace_return_none", ret is None,
            f"expected None, got {type(ret)}",
        ))

        # 3. rows/slots unmodified.
        rows_ok = torch.equal(rows, rows_before) if rows.shape == rows_before.shape else True
        results.append(TestResult(f"{name}_rows_unmodified", rows_ok))
        slots_ok = torch.equal(slots.reshape(-1), slots_before.reshape(-1))
        results.append(TestResult(f"{name}_slots_unmodified", slots_ok))

        # 4. Unselected positions keep sentinel (proves no over-write).
        mask_changed = (cache != cache_before)
        exp_changed = (expected != cache_before)
        untouched_ok = torch.equal(mask_changed, exp_changed)
        results.append(TestResult(f"{name}_untouched_unchanged", untouched_ok))

    return results


def int64_slots(values: list) -> torch.Tensor:
    return torch.tensor(values, dtype=torch.int64, device=DEVICE)


# ---------------------------------------------------------------------------
# Test cases
# ---------------------------------------------------------------------------

def test_minimal_kv():
    """Main K/V minimal functional case: full 256-dim write at page0/offset0."""
    cache = make_cache(1, 1, 256, torch.bfloat16)
    rows = make_rows(1, 256, torch.bfloat16)
    slots = int64_slots([0])
    return run_case("minimal_kv", cache, slots, rows)


def test_minimal_kv_3d_rows():
    """Same minimal case with 3D rows [1,1,256] (rows[:,0] adapter branch)."""
    cache = make_cache(1, 1, 256, torch.bfloat16)
    rows = make_rows(1, 1 * 256, torch.bfloat16).reshape(1, 1, 256)
    slots = int64_slots([0])
    return run_case("minimal_kv_3d_rows", cache, slots, rows)


def test_page_size_192_last_offset():
    """page_size=192 candidate: write to the last in-page offset (slot=191)."""
    cache = make_cache(1, 192, 256, torch.bfloat16)
    rows = make_rows(1, 256, torch.bfloat16)
    slots = int64_slots([191])
    return run_case("page192_last_offset", cache, slots, rows)


def test_recommended_addressing():
    """Recommended addressing case: pages 0/1, non-zero offset, non-monotonic,
    negative slot, capacity-bound violation, unselected slot unchanged.
    cache [2,2,1,256] capacity=4; slots [0,3,2,-1,4]:
      0 -> page0/off0; 3 -> page1/off1; 2 -> page1/off0;
     -1 -> ignored;  4 -> out-of-bounds ignored; slot1 never written."""
    cache = make_cache(2, 2, 256, torch.bfloat16)
    rows = make_rows(5, 256, torch.bfloat16)
    slots = int64_slots([0, 3, 2, -1, 4])
    results = run_case("addressing", cache, slots, rows)

    # Explicit spot checks against the spec.
    # slot0 -> cache[0,0,0] = row0; slot3 -> cache[1,1,0] = row1;
    # slot2 -> cache[1,0,0] = row2; slot1 (cache[0,1,0]) keeps sentinel.
    r = TestResult(
        "addressing_slot1_keeps_sentinel",
        (cache[0, 1, 0] == SENTINEL).all().item(),
    )
    results.append(r)
    return results


def test_multi_page_real_page_size():
    """cache [2,192,1,256], slots [191,192,383]: page boundary + last slot."""
    cache = make_cache(2, 192, 256, torch.bfloat16)
    rows = make_rows(3, 256, torch.bfloat16)
    slots = int64_slots([191, 192, 383])
    return run_case("multi_page_192", cache, slots, rows)


def test_rows_fewer_than_slots():
    """rows [1,256], slots [0,3]: only the aligned prefix (row0->slot0) is
    written; slot3 must NOT be updated."""
    cache = make_cache(2, 2, 256, torch.bfloat16)
    rows = make_rows(1, 256, torch.bfloat16)
    slots = int64_slots([0, 3])
    results = run_case("rows_fewer", cache, slots, rows)
    results.append(TestResult(
        "rows_fewer_slot3_unchanged",
        (cache[1, 1, 0] == SENTINEL).all().item(),
    ))
    return results


def test_slots_fewer_than_rows():
    """rows [2,256], slots [3]: the second row is ignored."""
    cache = make_cache(2, 2, 256, torch.bfloat16)
    rows = make_rows(2, 256, torch.bfloat16)
    slots = int64_slots([3])
    results = run_case("slots_fewer", cache, slots, rows)
    # Only cache[1,1] == row0; cache[0,0] untouched.
    results.append(TestResult(
        "slots_fewer_only_slot3_written",
        (cache[0, 0, 0] == SENTINEL).all().item(),
    ))
    return results


def test_empty_update():
    """rows [0,256], slots empty: no kernel launch, cache unchanged."""
    cache = make_cache(2, 2, 256, torch.bfloat16)
    rows = make_rows(0, 256, torch.bfloat16)
    slots = int64_slots([])
    return run_case("empty_update", cache, slots, rows)


def test_all_invalid_slots():
    """rows [2,256], slots [-1,4], capacity 4: nothing changes."""
    cache = make_cache(2, 2, 256, torch.bfloat16)
    rows = make_rows(2, 256, torch.bfloat16)
    slots = int64_slots([-1, 4])
    results = run_case("all_invalid", cache, slots, rows)
    results.append(TestResult(
        "all_invalid_cache_unchanged",
        torch.equal(cache, torch.full_like(cache, SENTINEL)),
    ))
    return results


def test_3d_rows_recommended():
    """3D rows [5,1,256] with the recommended addressing slots."""
    cache = make_cache(2, 2, 256, torch.bfloat16)
    rows = make_rows(5, 256, torch.bfloat16).reshape(5, 1, 256)
    slots = int64_slots([0, 3, 2, -1, 4])
    return run_case("rows_3d", cache, slots, rows)


def test_non_power2_width():
    """cache [2,2,1,257], rows [5,257]: BLOCK_D=512, column mask dims<257.
    Generic store test; not the main K/V width."""
    cache = make_cache(2, 2, 257, torch.bfloat16)
    rows = make_rows(5, 257, torch.bfloat16)
    slots = int64_slots([0, 3, 2, -1, 4])
    return run_case("non_power2_w257", cache, slots, rows)


def test_noncontiguous_rows():
    """rows as a strided view [5,256] from [5,512] (feature stride)."""
    src = make_rows(5, 512, torch.bfloat16)
    rows = src[:, ::2]  # [5,256], feature stride=2
    cache = make_cache(2, 2, 256, torch.bfloat16)
    slots = int64_slots([0, 3, 2, -1, 4])
    return run_case("rows_strided_view", cache, slots, rows)


def test_noncontiguous_rows_row_gap():
    """rows with a row gap: [5,256] view from [10,256] taking every other row."""
    src = make_rows(10, 256, torch.bfloat16)
    rows = src[::2]  # row stride = 512 elements
    cache = make_cache(2, 2, 256, torch.bfloat16)
    slots = int64_slots([0, 3, 2, -1, 4])
    return run_case("rows_row_gap", cache, slots, rows)


def test_noncontiguous_cache():
    """cache as a strided view [2,2,1,256] from [2,2,1,512]: feature stride,
    original storage updated, gap columns untouched."""
    src = make_cache(2, 2, 512, torch.bfloat16)
    cache = src[..., ::2]  # [2,2,1,256], feature stride=2
    assert not cache.is_contiguous()

    cache_before = cache.clone()
    rows = make_rows(5, 256, torch.bfloat16)
    slots = int64_slots([0, 3, 2, -1, 4])

    qsa_store_cache_rows(cache, slots, rows)
    torch.npu.synchronize()

    expected = store_rows_reference(cache_before, slots, rows)
    r1 = TestResult("cache_strided_exact_match", torch.equal(cache, expected))

    # Gap columns (odd indices in the underlying storage) must stay sentinel.
    gap_untouched = (src[..., 1::2] == SENTINEL).all().item()
    r2 = TestResult("cache_strided_gap_untouched", gap_untouched)
    return [r1, r2]


def test_indexer_width_128():
    """Indexer cache width W=128 BF16 (same store entry, different call site)."""
    cache = make_cache(2, 2, 128, torch.bfloat16)
    rows = make_rows(5, 128, torch.bfloat16)
    slots = int64_slots([0, 3, 2, -1, 4])
    return run_case("indexer_w128", cache, slots, rows)


def test_position_width_3():
    """Position cache width W=3: covers column mask (BLOCK_D=4, dims<3)."""
    dtype = torch.float32  # position cache uses its actual dtype; test FP32
    cache = make_cache(2, 2, 3, dtype)
    rows = make_rows(5, 3, dtype)
    slots = int64_slots([0, 3, 2, -1, 4])
    return run_case("position_w3", cache, slots, rows)


def test_position_width_3_bf16():
    """Position cache width W=3 in BF16 dtype variant."""
    cache = make_cache(2, 2, 3, torch.bfloat16)
    rows = make_rows(5, 3, torch.bfloat16)
    slots = int64_slots([0, 3, 2, -1, 4])
    return run_case("position_w3_bf16", cache, slots, rows)


def test_return_none_and_inplace():
    """Verify the wrapper returns None and modifies cache in place (identity)."""
    cache = make_cache(1, 1, 256, torch.bfloat16)
    rows = make_rows(1, 256, torch.bfloat16)
    slots = int64_slots([0])
    ret = qsa_store_cache_rows(cache, slots, rows)
    torch.npu.synchronize()
    r1 = TestResult("return_none", ret is None, f"got {type(ret)}")
    r2 = TestResult(
        "inplace_modified",
        not torch.equal(cache, torch.full_like(cache, SENTINEL)),
        "cache was not modified in place",
    )
    return [r1, r2]


# ---------------------------------------------------------------------------
# Runner
# ---------------------------------------------------------------------------

TEST_GROUPS = {
    "minimal": [
        ("minimal_kv", test_minimal_kv),
        ("minimal_kv_3d", test_minimal_kv_3d_rows),
        ("page192_last", test_page_size_192_last_offset),
        ("return_none", test_return_none_and_inplace),
    ],
    "addressing": [
        # SKIP:         ("recommended_addressing", test_recommended_addressing),
        # SKIP:         ("multi_page_192", test_multi_page_real_page_size),
        # SKIP:         ("rows_fewer", test_rows_fewer_than_slots),
        # SKIP:         ("slots_fewer", test_slots_fewer_than_rows),
    ],
    "supplementary": [
        # SKIP:         ("empty_update", test_empty_update),
        # SKIP:         ("all_invalid", test_all_invalid_slots),
        # SKIP:         ("rows_3d", test_3d_rows_recommended),
        # SKIP:         ("non_power2_w257", test_non_power2_width),
        # SKIP:         ("rows_strided_view", test_noncontiguous_rows),
        # SKIP:         ("rows_row_gap", test_noncontiguous_rows_row_gap),
        # SKIP:         ("cache_strided_view", test_noncontiguous_cache),
        # SKIP:         ("indexer_w128", test_indexer_width_128),
        # SKIP:         ("position_w3", test_position_width_3),
        # SKIP:         ("position_w3_bf16", test_position_width_3_bf16),
    ],
    "all": None,
}


def run_tests(pattern: str):
    all_results = []
    groups = TEST_GROUPS.items() if pattern == "all" else [(pattern, TEST_GROUPS.get(pattern, []))]
    for group_name, tests in groups:
        if tests is None:
            continue
        for name, fn in tests:
            print(f"--- Running: {name}")
            try:
                all_results.extend(fn())
            except Exception as e:
                all_results.append(TestResult(name, False, f"EXCEPTION: {type(e).__name__}: {e}"))

    print("\n" + "=" * 70)
    print("SUMMARY")
    print("=" * 70)
    passed = sum(1 for r in all_results if r.passed)
    failed = sum(1 for r in all_results if not r.passed)
    for r in all_results:
        status = "PASS" if r.passed else "FAIL"
        line = f"  [{status}] {r.name}"
        if not r.passed and r.detail:
            line += f"\n         {r.detail}"
        print(line)
    print("-" * 70)
    print(f"  Total: {len(all_results)}  Passed: {passed}  Failed: {failed}")
    print("=" * 70)
    return 0 if failed == 0 else 1


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="QSA _store_qsa_rows_kernel verification")
    parser.add_argument(
        "--pattern", type=str, default="all",
        choices=["minimal", "addressing", "supplementary", "all"],
    )
    args = parser.parse_args()
    sys.exit(run_tests(args.pattern))

---
name: profiling-analyze-compare
description: Compare two explicitly labeled Ascend/PyTorch Profiler exports from a real-machine environment (reference) and a simulation environment (candidate), preserving the PyTorch-first operator, device I/O Shape, DP/TP/EP/PP/CP/DCP, communication, overlap, memory, and evidence rules of analyze-ascend-profiling. Use when users need Chinese fidelity or gap reports between real and simulated profiling, including optional causal mapping to user-specified local inference code or GitHub/GitCode repository URLs and commits.
---

# 对比真机与仿真 Profiling

把真机固定为 `reference`，把仿真固定为 `candidate`。所有差值均写成“仿真 - 真机”，所有比率均写成“仿真 / 真机”。最终报告使用中文；算子名、字段名、代码符号和 URL 保留原文。

## Prompt 角色门禁

要求用户在 prompt 中明确写出：

```text
真机 Profiling（reference）：<目录>
仿真 Profiling（candidate）：<目录>
```

如果只有两个目录但没有明确“真机/仿真”角色，立即停止比较并只询问两者分别是什么。不得根据目录名、时间戳、机器名或性能高低猜测角色。

推荐用户同时提供：模型标识、同一 workload/request 标识、阶段（prefill/decode 等）、Profiler schedule、容差，以及可选的模型推理代码仓 URL/本地路径和 commit/tag/branch。完整模板见 [references/prompt-template.md](references/prompt-template.md)。

## 必须执行的流程

1. 完整阅读 [references/base-analysis-playbook.md](references/base-analysis-playbook.md)，沿用单环境 PyTorch-first 证据和时间语义。
2. 完整阅读 [references/comparison-playbook.md](references/comparison-playbook.md) 和 [references/report-contract.md](references/report-contract.md)。
3. 验证真机、仿真和输出目录互不混淆；输出目录不得位于任何原始 Profiling 根目录内。
4. 使用内置脚本分别抽取两侧并生成确定性对比：

```powershell
python scripts/compare_ascend_profiles.py `
  --real "<real-profile-root>" `
  --sim "<simulation-profile-root>" `
  --output "<comparison-output>" `
  --real-model "<model>" --sim-model "<model>" `
  --real-workload-id "<workload>" --sim-workload-id "<workload>" `
  --real-phase "<phase>" --sim-phase "<phase>" `
  --real-schedule-id "<schedule>" --sim-schedule-id "<schedule>" `
  --code-repo "<optional-url-or-local-path>" `
  --code-ref "<optional-commit-tag-or-branch>"
```

如果真机与仿真使用不同代码仓或版本，改用 `--real-code-repo/--real-code-ref` 和 `--sim-code-repo/--sim-code-ref`；不得用一侧源码解释另一侧运行。

5. 先读 `comparison/comparison_summary.md`、`comparability_gates.csv`、`coverage_comparison.csv` 和 `comparison_manifest.json`。
6. 若时间解释不是 `是`，仍完成结构/Shape/路径比较，但不得把时间比率写成仿真性能准确度结论。
7. 依次分析：PyTorch operator -> device execution/I-O Shape -> communication/group/message -> step/overlap -> memory。不得从 CANN Top 列表起笔。
8. 如果用户提供代码仓或本地代码，完整阅读 [references/source-code-evidence.md](references/source-code-evidence.md)，读取相关源码并把差异映射到固定 commit 下的 symbol/行号。
9. 如果完成了源码读取，先把固定 commit 的证据写入 `comparison/source_evidence.csv`，把跨文件调用/dispatch/guard 边写入 `comparison/source_symbol_edges.csv`；未提供源码时跳过，不得伪造空结论。
10. 使用内置渲染器生成报告契约规定的六份中文报告：

```powershell
python scripts/render_compare_reports.py `
  --comparison-output "<comparison-output>" `
  --top 20
```

11. 审阅并补充 `<comparison-output>/reports` 中的推断、替代解释和源码因果，但不得改写确定性数值、方向或证据。目录中只保留契约规定的六份主报告。
12. 验证所有数字、方向、单位、join key、证据路径和源码链接；确认两侧原始数据未修改。

## 三层保真度必须分开

- **结构/路径保真度**：PyTorch operator 集合、调用数、Shape bucket、device kernel/format/dtype、通信类型/group/peer。
- **时间保真度**：同语义窗口的 per-call、Device Self、Stage、transit、wait、not-overlapped 和 rank imbalance。
- **系统保真度**：真实频率、cache、内存分配、链路竞争、同步与 overlap 是否被仿真建模。

结构一致不等于时间准确，Shape 一致不等于 tensor value、routing、address、cache state 或 workload 一致。仿真未建模的指标写 `不适用/未建模`，不得当成 0。

## 对齐原则

- 先对齐 model、workload、phase、schedule、world size 和 DP/TP/EP/PP/CP/DCP，再比较时间。
- rank 优先按并行坐标对齐，global rank 仅作消歧；不得比较不同 shard/阶段的 rank。
- PyTorch operator 按 `rank coordinate + operator + input Shape` 聚合；调用栈差异单列。
- device operator 按 `rank coordinate + name/type/core + I/O Shape/dtype/format` 对齐。
- communication 按 `rank coordinate + category/type/group/parallel axis` 对齐，同时比较 message、transit、wait、sync 和 not-overlapped。
- Step 默认按同 rank 内的语义阶段和顺序对齐，不能仅因 Step ID 相同就认定是同一步。
- 只在双方字段都存在且语义一致时计算/解释比率；缺失与 0 严格区分。

## 代码证据原则

- 优先使用用户指定的本地 checkout；否则打开用户提供的 GitHub/GitCode URL。需要跨文件追踪时再做最小范围的只读获取。
- 尽可能把 branch/tag 固定到 commit，并使用永久链接；无法固定时明确写“分支随时间可变”。
- 从 Profiler 差异反查 operator/module/call stack，再定位 dispatch、Shape、并行 group、通信、graph/cache 路径。
- 源码只能证明某路径“可能/按条件会”执行；只有 runtime marker、call stack、flow 或配置同时吻合时，才把它与本次 Profiling 绑定。
- 私有仓不可访问时，不索要密钥；要求用户提供可读的本地 checkout、文件或永久链接，并继续完成不依赖源码的比较。

## 交付前验证

- Prompt 中真机/仿真角色明确，报告每页都保持同一方向。
- 六份报告存在且为中文。
- `comparability_gates.csv` 中未通过/待确认项已反映在结论强度中。
- PyTorch、device、communication、step、memory 的 unmatched entity 均有解释，不被静默丢弃。
- 每个时间比率注明真机值、仿真值、单位、`仿真/真机` 和是否允许解释。
- 代码结论引用 repo、commit/ref、文件、symbol/行号和永久链接；无法访问的内容标为未知。
- 不修改两侧原始 Profiling，不把大 trace 或完整仓库内容复制进报告。

---
name: profiling-analyze-compare
description: Compare two explicitly labeled Ascend/PyTorch Profiler exports from a real-machine environment (reference) and a simulation environment (candidate), selecting exactly one comparable rank and one reproducibly sampled process-thread, then reporting Chinese PyTorch operator sequences, direct input/output shapes, thread heatmaps, device I/O, communication, overlap, memory, and optional Perfetto visual review. Use for real-vs-simulation fidelity analysis and causal mapping to user-specified local code, .sh launch locators, or GitHub/GitCode repositories and commits.
---

# 对比真机与仿真 Profiling

把真机固定为 `reference`，把仿真固定为 `candidate`。所有差值均写成“仿真 - 真机”，所有比率均写成“仿真 / 真机”。最终报告使用中文；算子名、字段名、代码符号和 URL 保留原文。

## Prompt 角色门禁

要求用户在 prompt 中明确写出：

```text
真机 Profiling（reference）：<目录>
仿真 Profiling（candidate）：<目录>
```

如果只有两个目录但没有明确“真机/仿真”角色，立即停止比较并只询问两者分别是什么。不得根据目录名、时间戳、机器名或性能高低猜测角色。

推荐用户同时提供：模型标识、同一 workload/request 标识、阶段（prefill/decode 等）、Profiler schedule、容差，以及可选的模型推理代码 locator（仓库、具体 `.sh`、全是 `.sh` 的目录、GitHub/GitCode blob/tree URL）和 commit/tag/branch。完整模板见 [references/prompt-template.md](references/prompt-template.md)。

## 本 Skill 的强制分析范围

- 每侧只分析一个 `ASCEND_PROFILER_OUTPUT`。用户可显式指定 Rank；否则按已知 DP/TP/EP/PP/CP/DCP 选择一个可比 pair，并记录完整候选拓扑。不得汇总其它 Rank 的算子耗时。
- 每侧只分析所选 Rank 中一个 process-thread。用户可显式提供 pid/tid；否则用固定 seed + SHA-256 可复现抽样，并优先按 process/thread 名与算子指纹对齐仿真线程。
- 单 Rank 结果不得用于评价 rank imbalance、慢 Rank、跨 Rank max/min 或 CV；一个 process-thread 也不得外推为进程内全部线程。

## 必须执行的流程

1. 完整阅读 [references/base-analysis-playbook.md](references/base-analysis-playbook.md)，沿用单环境 PyTorch-first 证据和时间语义；其中多 Rank 汇总/不平衡分析在本 Skill 中由“只分析一个 Rank”的规则覆盖。
2. 完整阅读 [references/comparison-playbook.md](references/comparison-playbook.md) 和 [references/report-contract.md](references/report-contract.md)。
3. 验证真机、仿真和输出目录互不混淆；输出目录不得位于任何原始 Profiling 根目录内。
4. 使用内置脚本分别抽取两侧并生成确定性对比：

```powershell
python scripts/compare_ascend_profiles.py `
  --real "<real-profile-root>" `
  --sim "<simulation-profile-root>" `
  --output "<comparison-output>" `
  --real-model "<model>" --sim-model "<model>" `
  --real-workload-id "<workload>" --sim-workload-id "<workload>" `
  --real-phase "<phase>" --sim-phase "<phase>" `
  --real-schedule-id "<schedule>" --sim-schedule-id "<schedule>" `
  --thread-seed "0" `
  --code-repo "<optional-url-or-local-path>" `
  --code-ref "<optional-commit-tag-or-branch>" `
  --code-entry "<optional-.sh-file-or-directory>"
```

如果要指定 Rank，使用 `--real-rank/--sim-rank`；如果要指定线程，成对提供 `--real-pid/--real-tid` 与 `--sim-pid/--sim-tid`。如果真机与仿真使用不同代码仓、版本或入口，改用 `--real-code-repo/--real-code-ref/--real-code-entry` 和对应的 `--sim-*` 参数；不得用一侧源码解释另一侧运行。

5. 先读 `comparison/selected_rank_pair.csv`、`selected_thread_pair.csv`、`comparison_summary.md`、`comparability_gates.csv`、`coverage_comparison.csv` 和 `comparison_manifest.json`。确认两侧各只有一个 Rank，线程选择可审计且对齐置信度足以支撑后续措辞。
6. 若时间解释不是 `是`，仍完成结构/Shape/路径比较，但不得把时间比率写成仿真性能准确度结论。
7. 先读 `selected_thread_operator_events.csv`、`selected_thread_operator_summary.csv`、`selected_thread_operator_comparison.csv`、`selected_thread_sequence_diff.csv` 和 `selected_thread_operator_heatmap.csv`，回答所选 process-thread 具体执行了哪些 PyTorch operator、以什么顺序/Shape/时长分布执行；再分析单 Rank 汇总的 PyTorch -> device I/O -> communication -> step/overlap -> memory。不得从 CANN Top 列表起笔。
8. 如果用户提供代码仓或本地代码，完整阅读 [references/source-code-evidence.md](references/source-code-evidence.md)。若 locator 是本地 `.sh` 或目录，先静态解析入口，绝不执行仓库代码：

```powershell
python scripts/resolve_source_entrypoints.py `
  --repo-root "<fixed-local-checkout>" `
  --entry "<.sh-file-or-directory>" `
  --output "<comparison-output>/comparison/source_analysis/<real-or-sim>" `
  --environment "<real-or-sim>"
```

随后只读 Python AST/源码，把 `.sh -> launcher -> Python entry -> main -> model forward/dispatch -> torch/custom op/collective` 与所选线程的 call stack、module、operator 顺序和 Shape 结合：

```powershell
python scripts/map_thread_operators_to_source.py `
  --repo-root "<fixed-local-checkout>" `
  --source-analysis-dir "<comparison-output>/comparison/source_analysis/<real-or-sim>" `
  --thread-events "<comparison-output>/comparison/selected_thread_operator_events.csv" `
  --output "<comparison-output>/comparison" `
  --environment "<real-or-sim>"
```

主比较脚本会对可读的本地 locator 自动执行以上两个静态步骤。映射写入 `comparison/thread_operator_source_map.csv`；只有静态可达性时标 `静态候选`，不得写成运行事实。输出目录必须位于源码仓之外，保证用户仓库只读。
9. 如果完成了源码读取，先把固定 commit 的证据写入 `comparison/source_evidence.csv`，把跨文件调用/dispatch/guard 边写入 `comparison/source_symbol_edges.csv`；未提供源码时跳过，不得伪造空结论。
10. 对两侧所选线程做 Perfetto 视觉复核。先调用工作区依赖发现工具定位 Node.js 与 `playwright-core`，再分别运行：

```powershell
$env:PERFETTO_PLAYWRIGHT_NODE_MODULES="<trusted-runtime-node_modules>"
node scripts/render_perfetto_trace.mjs `
  --trace "<selected-rank>/trace_view.json" `
  --output "<comparison-output>/comparison/perfetto/<real-or-sim>" `
  --pid "<selected-pid>" --tid "<selected-tid>"
```

依赖目录必须由显式的 `PERFETTO_PLAYWRIGHT_NODE_MODULES` 指向 Codex/受信运行时，不能指向待分析代码仓；脚本不会从当前工作目录或 `NODE_PATH` 加载依赖。脚本只允许 `https://ui.perfetto.dev/` 官方 origin；先加载 UI 并把 trace 读入本地主页内存，再阻断 Service Worker、将浏览器上下文切换为离线，只有 manifest 证明 `offline_before_trace_post=true` 后才以 `localOnly` 交给已加载的 UI。生成 HTML、可读文本、浏览器日志、截图和 manifest。必须读取 SQL 热点表/文本、打开 `perfetto_ui_frame.html`，并用图像查看工具检查 `perfetto_ui.png`。时间线主体是 Canvas，HTML 源码本身不包含全部色块；截图/HTML 是视觉佐证，本地 CSV 是数值基准。不得点击 Share 或生成公开链接。网络、浏览器、依赖或离线门禁不可用时在 `perfetto_visual_review.json` 明确写“视觉复核未执行”及原因，不得伪称已打开。

11. 使用内置渲染器生成报告契约规定的六份中文报告：

```powershell
python scripts/render_compare_reports.py `
  --comparison-output "<comparison-output>" `
  --top 20
```

12. 审阅并补充 `<comparison-output>/reports` 中的推断、Perfetto 视觉观察、替代解释和源码因果，但不得改写确定性数值、方向或证据。目录中只保留契约规定的六份主报告。
13. 验证所有数字、方向、单位、单 Rank pair join key、pid/tid、证据路径和源码链接；确认两侧原始数据未修改。

## 三层保真度必须分开

- **结构/路径保真度**：PyTorch operator 集合、调用数、Shape bucket、device kernel/format/dtype、通信类型/group/peer。
- **时间保真度**：同语义窗口的 per-call、Device Self、Stage、transit、wait 和 not-overlapped；当前单 Rank 模式不评价 rank imbalance。
- **系统保真度**：真实频率、cache、内存分配、链路竞争、同步与 overlap 是否被仿真建模。

结构一致不等于时间准确，Shape 一致不等于 tensor value、routing、address、cache state 或 workload 一致。仿真未建模的指标写 `不适用/未建模`，不得当成 0。

## 对齐原则

- 先对齐 model、workload、phase、schedule、完整拓扑上下文和所选 Rank 的 DP/TP/EP/PP/CP/DCP，再比较时间。
- 只选择一个 Rank pair；优先按并行坐标对齐，global rank 仅登记/消歧且不得进入跨环境实体主键。
- 线程候选必须至少包含具体 PyTorch dispatcher/custom `cpu_op`；ProfilerStep、module/autograd scope、CANN/kernel 不作为线程候选的唯一依据。
- PyTorch operator 按 `rank coordinate + operator + input Shape + 直接可观测的 output Shape` 聚合；没有直接 Output Shape 证据时保留未知，调用栈差异单列。
- device operator 按 `rank coordinate + name/type/core + I/O Shape/dtype/format` 对齐。
- communication 按 `rank coordinate + category/type/group/parallel axis` 对齐，同时比较 message、transit、wait、sync 和 not-overlapped。
- Step 默认按同 rank 内的语义阶段和顺序对齐，不能仅因 Step ID 相同就认定是同一步。
- 只在双方字段都存在、真机分母非 0 且语义一致时计算/解释比率；双方实测 0 时 delta=0，但 ratio/percent 因分母为 0 保持不可计算，缺失与 0 严格区分。

## 代码证据原则

- 优先使用用户指定的本地 checkout；否则打开用户提供的 GitHub/GitCode URL。需要跨文件追踪时再做最小范围的只读获取。
- 用户只给一个 `.sh` 或全是 `.sh` 的位置时，把它视为入口线索而非搜索边界；静态追踪 source/include、launcher、Python target 和 model path，绝不运行、source、eval 或 import 仓库代码。
- 尽可能把 branch/tag 固定到 commit，并使用永久链接；无法固定时明确写“分支随时间可变”。
- 从 Profiler 差异反查 operator/module/call stack，再定位 dispatch、Shape、并行 group、通信、graph/cache 路径。
- 源码只能证明某路径“可能/按条件会”执行；只有 runtime marker、call stack、flow 或配置同时吻合时，才把它与本次 Profiling 绑定。
- 私有仓不可访问时，不索要密钥；要求用户提供可读的本地 checkout、文件或永久链接，并继续完成不依赖源码的比较。

## 交付前验证

- Prompt 中真机/仿真角色明确，报告每页都保持同一方向。
- `selected_rank_pair.csv` 恰有一行；`selected_thread_pair.csv` 在成功时真机/仿真各一行（共两行），失败时由 `thread_analysis_status.json` 明确记录 trace 缺失/无法选择。
- 热力图 deepest/exclusive 的同环境单个时间桶各算子占比合计不超过 100%，嵌套 inclusive 时长不重复当作利用率。
- Perfetto 结论同时引用截图和 SQL/文本；只有两侧 PID/TID/trace SHA-256 与当前选择匹配时标完成，未实际加载时明确标未执行。
- 六份报告存在且为中文。
- `comparability_gates.csv` 中未通过/待确认项已反映在结论强度中。
- 所选线程及单 Rank 的 PyTorch、device、communication、step、memory unmatched entity 均有解释，不被静默丢弃。
- 每个时间比率注明真机值、仿真值、单位、`仿真/真机` 和是否允许解释。
- 代码结论引用 repo、commit/ref、文件、symbol/行号和永久链接；无法访问的内容标为未知。
- 不修改两侧原始 Profiling，不把大 trace 或完整仓库内容复制进报告。

# 真机/仿真 Profiling 对比手册

## 目录

1. 比较目标与方向
2. 可比性门禁
3. Rank、阶段与实体对齐
4. PyTorch operator 对比
5. Device execution 与 Shape 对比
6. 通信与并行拓扑对比
7. Step、重叠、内存与时间保真度
8. 差值、比率与缺失值
9. 结构差异到代码假设
10. 单 process-thread、热力图与 Perfetto
11. 失败模式

## 1. 比较目标与方向

固定角色：

```text
reference = 真机
candidate = 仿真
delta = 仿真 - 真机
ratio = 仿真 / 真机
```

不要在某些表中改用“真机/仿真”。所有 CSV 和报告标题都重复说明方向。

分别回答三个问题：

1. **结构/路径保真度**：仿真是否执行了真机观察到的 PyTorch operator、Shape、kernel 和通信结构？
2. **时间保真度**：在工作负载和阶段一致时，仿真是否复现 per-call、Step、通信和 rank 相对关系？
3. **系统保真度**：仿真是否实际建模了频率、cache、内存、链路、同步、调度和 overlap？

结构不一致时，先解释路径差异，不要优先讨论时长误差。结构一致但系统模型缺失时，只能评价路径，不能评价真实硬件时间。

本 Skill 的比较单位固定为：每侧一个所选 Rank，以及所选 Rank 内一个所选 process-thread。完整 Rank 清单只用于寻找可比 pair 和验证拓扑上下文，不参与算子/时间聚合。

## 2. 可比性门禁

按顺序检查：

| 门禁 | 通过条件 | 失败后的允许结论 |
|---|---|---|
| 角色 | Prompt 明确真机与仿真 | 不执行，要求用户标注 |
| 模型/代码版本 | 模型标识、权重/配置、关键代码版本一致 | 可列结构差异，不能归因于仿真 |
| Workload | batch、input/output length、请求/数据集、并发一致 | 仅按实际 Shape 分桶，不比较整体时间 |
| 阶段 | prefill/decode/capture/warmup 等一致 | 分阶段后再比；无法分则时间不可比 |
| Schedule | wait/warmup/active/repeat 和 Step 数一致 | 只比较可对齐子窗口 |
| 并行拓扑 | world size、DP/TP/EP/PP/CP/DCP 和 group 成员一致 | 不做逐 rank 比率；只做受限聚合观察 |
| 主证据覆盖 | 两侧同类主文件存在、Shape/Stack 配置兼容 | 缺失维度标未知，不把缺失当 0 |
| 时间语义 | 同一单位、self/total、wall/kernel、wait/transit 口径 | 只做结构比较 |

`compare_ascend_profiles.py` 自动检查可观测门禁，但 model、workload、phase 和 schedule 仍需用户/metadata 证明。脚本显示 `待人工确认` 时，报告不能自动升级为“时间可比”。

## 3. Rank、阶段与实体对齐

### 3.1 Rank 对齐

只选择一个 Rank pair。首选匹配键：

```text
(DP, TP, EP, PP, CP, DCP)
```

device id、host PID、目录序号可能因环境不同而变化，不作为主键。global rank 仅作确定性选择时的次要消歧，不进入跨环境 operator/device/communication 主键。并行坐标缺失时若双方各只有一个候选可以低置信配对，否则列出未知/冲突，不从 global rank 猜并行坐标。

默认 Rank 选择是确定性的，不随机：优先最少并行坐标冲突、最多已知坐标一致，再以稳定路径排序。用户用 `--real-rank/--sim-rank` 指定时仍记录选择器、候选数、方法与置信度。输出 `selected_rank_pair.csv/json` 和 `full_topology_context.csv`。

比较层统一使用 `selected-rank-pair` 作为 join key；原始 global rank 可不同。只分析一个 Rank 后严禁输出 rank imbalance、慢 Rank、跨 Rank max/min 或 CV 结论。

### 3.2 Step 对齐

Step ID 可能偏移。按以下顺序对齐：

1. 显式 phase/range/request ID；
2. 同 rank 内相同语义阶段的顺序；
3. operator/Shape 序列指纹；
4. 原始 Step ID。

脚本默认生成 `step_ordinal`；它只是顺序对齐候选。若两侧 Step 数不同、阶段混合或序列明显不同，报告应覆盖这一默认并标为不可比。

### 3.3 Unmatched entity

对 union 而非 intersection 做报告：

- `仅真机`：仿真漏路径、未采集或归一化失败的候选；
- `仅仿真`：仿真多路径、额外 instrumentation 或命名差异的候选；
- `两侧存在但 count 不同`：workload、control path、bucket 或 capture 窗口差异候选。

不要静默丢弃 unmatched entity。先排除名称规范化、文件覆盖和窗口不齐，再讨论仿真缺陷。

比较层必须读取每个 rank 的未截断 `pytorch_operator_shapes.csv`、`device_operator_shapes.csv` 和通信明细。`summary.md`、全局 Top-N CSV 只用于浏览，不能用 Top-N 缺失证明实体不存在。检查单环境摘要中的 `comparison_full_signatures_written=true`；若旧抽取结果没有该标志，重新运行内置分析器。

## 4. PyTorch operator 对比

默认对齐键：

```text
(selected rank pair, operator name, normalized input Shape)
```

调用栈不放入主键，因为真机/仿真的安装路径或行号可能不同；把 call-stack ID/样例作为差异字段。比较：

- operator presence；
- input Shape/bucket 集合；
- calls；
- Host Self/Total；
- Device Self/Total；
- call stack/module。

解释顺序：

1. operator/Shape 是否一致；
2. calls 是否一致；
3. call stack/module 是否对应同一语义路径；
4. 最后才比较 per-call 和 total 时间。

`operator_details.csv` 没有 PyTorch output Shape。若所选 `trace_view.json` 的 PyTorch event args 直接给出 `Output Dims/Output Shapes/Output Shape`，保留该直接证据；否则两侧都不得从 kernel 猜写，只有 flow/DB/runtime marker 建立一一映射时才能补充。

线程级 operator 不能从 `operator_details.csv` 过滤，因为它没有 pid/tid；必须直接解析所选 Rank 的 `trace_view.json`。线程级事实与 Rank 汇总事实分表保存，不互相冒充。

## 5. Device execution 与 Shape 对比

默认对齐键：

```text
(rank coordinate, name, type, accelerator core,
 input Shape/dtype/format, output Shape/dtype/format)
```

比较：presence、calls、total/avg/max duration、wait、kernel implementation、format/dtype。常见模式：

| 差异 | 优先解释 |
|---|---|
| PyTorch 一致、kernel 名不同 | backend lowering/tiling/fusion/版本差异 |
| operator 一致、I/O Shape 不同 | padding/sharding/bucket/workload 不一致 |
| Shape 一致、format/dtype 不同 | cast/layout/lowering 配置差异 |
| 结构完全一致、duration 不同 | 时间模型、频率、cache、contention；先查系统建模 |
| 仿真缺 kernel 但 PyTorch 存在 | fusion、未建模、采集覆盖或关联差异 |

设备 kernel duration 求和不是 wall-clock。仿真可能序列化真实并行 stream，也可能省略等待；必须结合 Step 和 overlap。

## 6. 通信与并行拓扑对比

默认对齐键：

```text
(rank coordinate, p2p/collective, collective type, group, parallel axis)
```

分别比较：

- communication kernel I/O Shape 与 calls；
- communication.json 的 message size、transit、wait、sync；
- matrix 的 peer/link/transport；
- step_trace 的 communication-not-overlapped；
- 通信前后 compute context。

确定性输出中，`communication_kernel_comparison.csv` 专门保存通信执行算子的名称、并行坐标、完整 I/O Shape/dtype/format、calls、duration 与 wait；`communication_comparison.csv` 保存 collective/group/message/transit/wait/sync，二者不得互相替代。

解释顺序：

1. group/member/parallel axis 是否一致；
2. collective type、calls 和 message 是否一致；
3. peer/link/transport 是否被仿真建模；
4. transit/wait/sync 是否有同一语义；
5. not-overlapped 对 Stage 的贡献。

常见结论边界：

- message 相同但 transit 不同：可怀疑链路时间模型，不等于通信路径正确；
- kernel duration 相同但 wait 不同：可怀疑同步/到达时间，不把 AICPU duration 当 wire time；
- 仿真 message 为 0 或缺失：先判断“未建模/未导出”，不能直接判定没有通信；
- group 名不同：若成员和轴相同，可作为命名差异；成员未知时不能合并。

## 7. Step、重叠、内存与时间保真度

### 7.1 时间层级

按层级分别评价：

```text
per-call operator/kernel
rank-local summed device work
communication transit/wait
communication-not-overlapped
Step/Stage wall-clock
end-to-end request latency（只有外部日志时）
```

下层比率一致不保证上层一致，反之亦然。只有 Stage 是 Profiler 墙钟分解；不能用 kernel sum 代替。

### 7.2 建议指标

- 绝对差：`sim - real`；
- 相对差：`(sim - real) / real`；
- 比率：`sim / real`；
- 排名保真度：热点排序是否稳定；
- 单 Rank 模式不计算 rank imbalance；需要该指标时必须另采并显式分析多 Rank；
- overlap 保真度：not-overlapped/Stage；
- 结构覆盖率：真机实体中有多少在仿真存在；
- 仿真额外率：仿真实体中有多少真机不存在。

未给项目容差时只报告数值，不擅自宣布通过/失败。

### 7.3 内存

比较 allocated/reserved/active 峰值和 operator allocation。仿真可能没有 allocator/fragmentation 模型；缺文件或全空时写“未建模/未采集待确认”，不能当成零内存。

## 8. 差值、比率与缺失值

严格区分：

| 状态 | 输出 |
|---|---|
| 两侧都有数值，真机非 0 | 正常计算 delta/ratio/percent |
| 两侧都是 0 | delta=0；ratio/percent 因分母为 0 而不可计算，并确认 0 是实测值 |
| 真机为 0、仿真非 0 | ratio 不可计算，保留绝对差 |
| 任一侧字段缺失 | `缺失/不可计算` |
| 仿真明确不建模 | `不适用/未建模` |
| 口径不一致 | 保留原值，禁止比率解释 |

不要把空字符串、`N/A`、缺文件或 parser 不支持转换为 0。

总时间差必须同时检查 calls。total 变化可分解为：

```text
调用数变化 + per-call 变化 + Shape/path 变化
```

## 9. 结构差异到代码假设

使用 Profiler 证据缩小源码范围：

```text
operator/call stack mismatch
  -> module/dispatch/guard
Shape mismatch
  -> padding/bucket/shard/length producer
kernel/format mismatch
  -> backend lowering/fusion/dtype/layout config
communication mismatch
  -> process group/routing/split/collective selection
Step/graph mismatch
  -> scheduler/capture/replay/cache path
```

代码条件本身不证明本次执行。把结论分成：

- `源码事实`：固定 commit 中存在某 guard/dispatch/shape 计算；
- `运行事实`：Profiler/metadata/call stack 显示本次执行；
- `关联推断`：两者条件吻合，可能解释差异；
- `未知`：缺少 runtime value/marker。

## 10. 单 process-thread、热力图与 Perfetto

### 10.1 Chrome Trace 解析

`analyze_trace_threads.py` 必须流式读取顶层数组或 `{ "traceEvents": [...] }`，不得对大 trace 使用 `json.load`。支持：

- `M`：`process_name`、`thread_name` 等 metadata；metadata 可能在文件末尾；
- `X`：完整 slice，使用 `ts + dur`；
- `B/E`：按 `(pid, tid)` 的完整事件栈 LIFO 配对，`B` 的 name/args 为主；
- flow/async/instant/counter 不当作 thread-local operator slice。

孤立 `E`、未闭合 `B`、负 duration、args 非对象、同 tid 不同 pid、非单调事件都记录告警，不能悄悄修成正常时长。pid/tid 作为不透明字符串保存，lane 主键必须是 `(pid, tid)`。

具体 PyTorch operator 优先由 `cat=cpu_op` 识别，并以 `aten::/prims::/torch::/torch_npu::/npu::/quantized::/c10d::` 补强。排除 ProfilerStep、python/module/autograd/user scope、CANN/kernel 元数据。候选线程至少有一个 dispatcher/custom cpu_op。

### 10.2 线程随机选择与对齐

“随机选一个”必须可复现：用 `seed + lane semantic key` 的 SHA-256 排序选择，记录 seed、算法版本、选择哈希和候选清单；不得依赖 Python hash 或输入枚举顺序。

优先在双方共同的规范化 `(process_name, thread_name)` 语义组中选；重名才用 `operator + Shape + count` 指纹消歧。无共同名称时，先选真机线程，再用名称/指纹寻找仿真线程。无法可靠对齐则标低置信或 `unaligned`，禁止强做逐线程时间因果结论。用户显式 pid/tid 时验证 lane 存在且有具体 PyTorch operator。

### 10.3 热力图

固定 64 个（可配置）lane-relative 时间桶：x 轴为归一化线程窗口，y 轴为 operator，分别绘制真机/仿真。每个 cell 至少记录 overlap calls、inclusive overlap、deepest/exclusive coverage、bin share 和 dominant operator。

嵌套 slice 的 inclusive duration 会重复，不能直接作为占用率；热力图主色值使用 deepest/exclusive interval union，任一 bin 的占比不得超过 100%。跨环境只有时间门禁通过时才解释绝对微秒，否则只比较归一化分布与顺序。

### 10.4 Perfetto 内容复核与可选截图

使用 `render_perfetto_trace.mjs` 通过官方 embedding API 打开 `https://ui.perfetto.dev/`。UI 完成 PING/PONG 后，先把 trace 读入 localhost 主页内存，再阻断 Service Worker 并将 Playwright 上下文切为离线；只有 `offline_before_trace_post=true` 时才以 `localOnly` 送入已加载的 UI。URL query/启动命令必须按所选 pid/tid 展示 SQL 热点表和 debug slice track。保存 frame HTML、body text、browser log、PNG screenshot、manifest。

只允许官方 `https://ui.perfetto.dev` origin，并对 PING/PONG、trace `postMessage` 校验精确 origin/source；不得使用 `*`。Playwright 只从显式 `PERFETTO_PLAYWRIGHT_NODE_MODULES` 指定的 Codex/受信运行时绝对目录加载，禁止从 `NODE_PATH`、当前工作目录或用户代码仓加载。`localOnly` 不单独作为机密性边界；manifest 必须同时记录断网时间、Service Worker 数和离线先于 trace post 的门禁。清理旧产物前先确认 trace 与 output/固定 artifact 不重叠。真机、仿真两侧 manifest 成功、离线门禁通过且 PID/TID/trace SHA-256 匹配后，分析代理必须实际读取 SQL 热点表、body text 或 frame HTML，并在 `perfetto_visual_review.json` 写入 `status="完成"`、实际 `review_methods`（如 `html`、`text`、`sql`）、两侧 `reviewed_environments` 和非空 `observations`，才可把“Perfetto 内容复核”标为完成。截图不是内容复核的硬门禁；只有确实查看两张 PNG 后才能写 `screenshot_reviewed=true` 并评价 Canvas 颜色、条块、轨道布局或可见空白区。

实现依据只使用 Perfetto 官方文档：[Perfetto UI](https://perfetto.dev/docs/visualization/perfetto-ui)、[Embedding API reference](https://perfetto.dev/docs/visualization/embedding-api-reference)、[Embedding walkthrough](https://perfetto.dev/docs/visualization/embedding-the-ui)、[Commands/automation](https://perfetto.dev/docs/visualization/commands-automation-reference) 和 [PerfettoSQL](https://perfetto.dev/docs/analysis/perfetto-sql-getting-started)。

Perfetto 时间线主体是 Canvas；静态 HTML 不包含完整条块和颜色，但其中的 DOM、可读文本与 SQL 结果可以直接解析，用于 operator、calls、duration、查询表和页面状态复核。数值事实以本地 trace parser CSV（或 Perfetto SQL 明细）为准。未查看截图时只限制 Canvas 像素级/布局结论，不影响 HTML/SQL 内容复核。没有浏览器、网络或依赖时写“Perfetto 内容复核未执行”，不得伪称读过渲染结果；不得点击 Share。

## 11. 失败模式

### 两个目录未标角色

停止并询问，不运行脚本。

### 拓扑不同

仍确定性选择一个冲突最少的 Rank pair，生成 inventory 和结构差异，但禁止所选 Rank 时间比率外推。若用户确实要比较缩放行为，另建“不同拓扑 scaling”任务，不把它称为仿真保真度。

### 一侧缺 trace_view.json 或没有具体 PyTorch 线程

继续单 Rank CSV 对比；线程序列、热力图和 Perfetto 标为受限/未知。缺失不是零事件。不得用 CANN/device kernel lane 代替 PyTorch process-thread。

### Workload/phase 不明

按实际 Shape 和序列分桶；所有时间结论标待确认。建议补充 request ID、input/output length、batch、phase marker。

### 一侧缺主文件

仅在双方都有证据的维度比较。把缺失维度列入 coverage report，并建议用相同 profiler flags 重采。

### 仿真时间是估算量

记录估算时间的定义和单位。若它不是 Profiler 的同口径 duration/Stage，不与真机直接相除；可独立报告 estimator error contract。

### 代码仓与运行版本不一致

不做行级因果绑定。要求运行 commit/build ID，或把源码结论明确标为“当前仓版本参考”。

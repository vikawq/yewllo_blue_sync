# 真机/仿真 Profiling 对比手册

## 目录

1. 比较目标与方向
2. 可比性门禁
3. Rank、阶段与实体对齐
4. PyTorch operator 对比
5. Device execution 与 Shape 对比
6. 通信与并行拓扑对比
7. Step、重叠、内存与时间保真度
8. 差值、比率与缺失值
9. 结构差异到代码假设
10. 失败模式

## 1. 比较目标与方向

固定角色：

```text
reference = 真机
candidate = 仿真
delta = 仿真 - 真机
ratio = 仿真 / 真机
```

不要在某些表中改用“真机/仿真”。所有 CSV 和报告标题都重复说明方向。

分别回答三个问题：

1. **结构/路径保真度**：仿真是否执行了真机观察到的 PyTorch operator、Shape、kernel 和通信结构？
2. **时间保真度**：在工作负载和阶段一致时，仿真是否复现 per-call、Step、通信和 rank 相对关系？
3. **系统保真度**：仿真是否实际建模了频率、cache、内存、链路、同步、调度和 overlap？

结构不一致时，先解释路径差异，不要优先讨论时长误差。结构一致但系统模型缺失时，只能评价路径，不能评价真实硬件时间。

## 2. 可比性门禁

按顺序检查：

| 门禁 | 通过条件 | 失败后的允许结论 |
|---|---|---|
| 角色 | Prompt 明确真机与仿真 | 不执行，要求用户标注 |
| 模型/代码版本 | 模型标识、权重/配置、关键代码版本一致 | 可列结构差异，不能归因于仿真 |
| Workload | batch、input/output length、请求/数据集、并发一致 | 仅按实际 Shape 分桶，不比较整体时间 |
| 阶段 | prefill/decode/capture/warmup 等一致 | 分阶段后再比；无法分则时间不可比 |
| Schedule | wait/warmup/active/repeat 和 Step 数一致 | 只比较可对齐子窗口 |
| 并行拓扑 | world size、DP/TP/EP/PP/CP/DCP 和 group 成员一致 | 不做逐 rank 比率；只做受限聚合观察 |
| 主证据覆盖 | 两侧同类主文件存在、Shape/Stack 配置兼容 | 缺失维度标未知，不把缺失当 0 |
| 时间语义 | 同一单位、self/total、wall/kernel、wait/transit 口径 | 只做结构比较 |

`compare_ascend_profiles.py` 自动检查可观测门禁，但 model、workload、phase 和 schedule 仍需用户/metadata 证明。脚本显示 `待人工确认` 时，报告不能自动升级为“时间可比”。

## 3. Rank、阶段与实体对齐

### 3.1 Rank 对齐

首选键：

```text
(DP, TP, EP, PP, CP, DCP, global rank as tie-breaker)
```

device id、host PID、目录序号可能因环境不同而变化，不作为主键。并行坐标缺失时，可以暂用 global rank，但必须标记置信度降低；不能从 global rank 猜并行坐标。

### 3.2 Step 对齐

Step ID 可能偏移。按以下顺序对齐：

1. 显式 phase/range/request ID；
2. 同 rank 内相同语义阶段的顺序；
3. operator/Shape 序列指纹；
4. 原始 Step ID。

脚本默认生成 `step_ordinal`；它只是顺序对齐候选。若两侧 Step 数不同、阶段混合或序列明显不同，报告应覆盖这一默认并标为不可比。

### 3.3 Unmatched entity

对 union 而非 intersection 做报告：

- `仅真机`：仿真漏路径、未采集或归一化失败的候选；
- `仅仿真`：仿真多路径、额外 instrumentation 或命名差异的候选；
- `两侧存在但 count 不同`：workload、control path、bucket 或 capture 窗口差异候选。

不要静默丢弃 unmatched entity。先排除名称规范化、文件覆盖和窗口不齐，再讨论仿真缺陷。

比较层必须读取每个 rank 的未截断 `pytorch_operator_shapes.csv`、`device_operator_shapes.csv` 和通信明细。`summary.md`、全局 Top-N CSV 只用于浏览，不能用 Top-N 缺失证明实体不存在。检查单环境摘要中的 `comparison_full_signatures_written=true`；若旧抽取结果没有该标志，重新运行内置分析器。

## 4. PyTorch operator 对比

默认对齐键：

```text
(rank coordinate, operator name, normalized input Shape)
```

调用栈不放入主键，因为真机/仿真的安装路径或行号可能不同；把 call-stack ID/样例作为差异字段。比较：

- operator presence；
- input Shape/bucket 集合；
- calls；
- Host Self/Total；
- Device Self/Total；
- call stack/module。

解释顺序：

1. operator/Shape 是否一致；
2. calls 是否一致；
3. call stack/module 是否对应同一语义路径；
4. 最后才比较 per-call 和 total 时间。

`operator_details.csv` 没有 PyTorch output Shape。两侧都不得从 kernel 猜写；只有 flow/DB/runtime marker 建立映射时才能补充。

## 5. Device execution 与 Shape 对比

默认对齐键：

```text
(rank coordinate, name, type, accelerator core,
 input Shape/dtype/format, output Shape/dtype/format)
```

比较：presence、calls、total/avg/max duration、wait、kernel implementation、format/dtype。常见模式：

| 差异 | 优先解释 |
|---|---|
| PyTorch 一致、kernel 名不同 | backend lowering/tiling/fusion/版本差异 |
| operator 一致、I/O Shape 不同 | padding/sharding/bucket/workload 不一致 |
| Shape 一致、format/dtype 不同 | cast/layout/lowering 配置差异 |
| 结构完全一致、duration 不同 | 时间模型、频率、cache、contention；先查系统建模 |
| 仿真缺 kernel 但 PyTorch 存在 | fusion、未建模、采集覆盖或关联差异 |

设备 kernel duration 求和不是 wall-clock。仿真可能序列化真实并行 stream，也可能省略等待；必须结合 Step 和 overlap。

## 6. 通信与并行拓扑对比

默认对齐键：

```text
(rank coordinate, p2p/collective, collective type, group, parallel axis)
```

分别比较：

- communication kernel I/O Shape 与 calls；
- communication.json 的 message size、transit、wait、sync；
- matrix 的 peer/link/transport；
- step_trace 的 communication-not-overlapped；
- 通信前后 compute context。

确定性输出中，`communication_kernel_comparison.csv` 专门保存通信执行算子的名称、并行坐标、完整 I/O Shape/dtype/format、calls、duration 与 wait；`communication_comparison.csv` 保存 collective/group/message/transit/wait/sync，二者不得互相替代。

解释顺序：

1. group/member/parallel axis 是否一致；
2. collective type、calls 和 message 是否一致；
3. peer/link/transport 是否被仿真建模；
4. transit/wait/sync 是否有同一语义；
5. not-overlapped 对 Stage 的贡献。

常见结论边界：

- message 相同但 transit 不同：可怀疑链路时间模型，不等于通信路径正确；
- kernel duration 相同但 wait 不同：可怀疑同步/到达时间，不把 AICPU duration 当 wire time；
- 仿真 message 为 0 或缺失：先判断“未建模/未导出”，不能直接判定没有通信；
- group 名不同：若成员和轴相同，可作为命名差异；成员未知时不能合并。

## 7. Step、重叠、内存与时间保真度

### 7.1 时间层级

按层级分别评价：

```text
per-call operator/kernel
rank-local summed device work
communication transit/wait
communication-not-overlapped
Step/Stage wall-clock
end-to-end request latency（只有外部日志时）
```

下层比率一致不保证上层一致，反之亦然。只有 Stage 是 Profiler 墙钟分解；不能用 kernel sum 代替。

### 7.2 建议指标

- 绝对差：`sim - real`；
- 相对差：`(sim - real) / real`；
- 比率：`sim / real`；
- 排名保真度：热点排序是否稳定；
- rank imbalance 保真度：`max/min` 在两侧是否相近；
- overlap 保真度：not-overlapped/Stage；
- 结构覆盖率：真机实体中有多少在仿真存在；
- 仿真额外率：仿真实体中有多少真机不存在。

未给项目容差时只报告数值，不擅自宣布通过/失败。

### 7.3 内存

比较 allocated/reserved/active 峰值和 operator allocation。仿真可能没有 allocator/fragmentation 模型；缺文件或全空时写“未建模/未采集待确认”，不能当成零内存。

## 8. 差值、比率与缺失值

严格区分：

| 状态 | 输出 |
|---|---|
| 两侧都有数值，真机非 0 | 正常计算 delta/ratio/percent |
| 两侧都是 0 | ratio=1，delta=0，但确认 0 是实测值 |
| 真机为 0、仿真非 0 | ratio 不可计算，保留绝对差 |
| 任一侧字段缺失 | `缺失/不可计算` |
| 仿真明确不建模 | `不适用/未建模` |
| 口径不一致 | 保留原值，禁止比率解释 |

不要把空字符串、`N/A`、缺文件或 parser 不支持转换为 0。

总时间差必须同时检查 calls。total 变化可分解为：

```text
调用数变化 + per-call 变化 + Shape/path 变化
```

## 9. 结构差异到代码假设

使用 Profiler 证据缩小源码范围：

```text
operator/call stack mismatch
  -> module/dispatch/guard
Shape mismatch
  -> padding/bucket/shard/length producer
kernel/format mismatch
  -> backend lowering/fusion/dtype/layout config
communication mismatch
  -> process group/routing/split/collective selection
Step/graph mismatch
  -> scheduler/capture/replay/cache path
```

代码条件本身不证明本次执行。把结论分成：

- `源码事实`：固定 commit 中存在某 guard/dispatch/shape 计算；
- `运行事实`：Profiler/metadata/call stack 显示本次执行；
- `关联推断`：两者条件吻合，可能解释差异；
- `未知`：缺少 runtime value/marker。

## 10. 失败模式

### 两个目录未标角色

停止并询问，不运行脚本。

### 拓扑不同

生成 inventory 和结构差异，但禁止逐 rank 时间比率。若用户确实要比较缩放行为，另建“不同拓扑 scaling”任务，不把它称为仿真保真度。

### Workload/phase 不明

按实际 Shape 和序列分桶；所有时间结论标待确认。建议补充 request ID、input/output length、batch、phase marker。

### 一侧缺主文件

仅在双方都有证据的维度比较。把缺失维度列入 coverage report，并建议用相同 profiler flags 重采。

### 仿真时间是估算量

记录估算时间的定义和单位。若它不是 Profiler 的同口径 duration/Stage，不与真机直接相除；可独立报告 estimator error contract。

### 代码仓与运行版本不一致

不做行级因果绑定。要求运行 commit/build ID，或把源码结论明确标为“当前仓版本参考”。

# Prompt 模板

## 最小可执行模板

```text
使用 $profiling-analyze-compare 对比下面两个 Profiling：

真机 Profiling（reference）：<绝对路径>
仿真 Profiling（candidate）：<绝对路径>

请输出中文对比报告。
```

只有两个路径而没有明确角色时，不执行比较；询问用户哪个是真机、哪个是仿真。

## 推荐完整模板

```text
使用 $profiling-analyze-compare 做真机/仿真一致性分析。

真机 Profiling（reference）：<绝对路径>
仿真 Profiling（candidate）：<绝对路径>

模型：<model name/version>
真机 workload/request：<数据集、batch、input/output length、请求 ID 或配置摘要>
仿真 workload/request：<应与真机相同；写出实际值>
真机阶段：<prefill/decode/mixed/train/backward/...>
仿真阶段：<同上>
Profiler schedule：<wait/warmup/active/repeat，或配置文件路径>
并行配置：<world size, DP/TP/EP/PP/CP/DCP>

模型推理代码仓（可选，默认两侧共用）：<GitHub/GitCode URL 或本地 checkout>
代码版本（推荐 commit）：<commit/tag/branch>
如果两侧源码不同，请分别写：
- 真机代码仓/ref：<URL 或路径>@<commit>
- 仿真代码仓/ref：<URL 或路径>@<commit>
入口/相关模块（可选）：<serve.py、model runner、attention/MoE 路径等>

关注问题：<结构一致性、Shape、通信、仿真时延准确度、某个异常算子等>
允许差异阈值（可选）：<按指标列出，不提供则只报告数值、不擅自判定通过/失败>
输出目录：<位于两个原始 Profiling 目录之外>
```

## 解释规则

- 用户写“环境 A/B”而非“真机/仿真”时，要求补充角色。
- 用户只写一个 workload/phase 时，把它视为“用户声称两侧相同”，但仍用 metadata/Step/Shape 验证；冲突时以实际证据为准并标记门禁失败。
- 未给容差时，不创造统一的 5%/10% 阈值；报告绝对差、相对差和可比性，由用户或项目规范决定是否通过。
- 代码仓不是必填项。缺少代码时完成 Profiler 层比较，并把源码因果映射标为未知。

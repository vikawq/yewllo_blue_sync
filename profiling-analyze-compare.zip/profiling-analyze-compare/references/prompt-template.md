# Prompt 模板

## 最小可执行模板

```text
使用 $profiling-analyze-compare 对比下面两个 Profiling：

真机 Profiling（reference）：<绝对路径>
仿真 Profiling（candidate）：<绝对路径>

每侧只分析一个 Rank；Rank 未指定时请选择一个可比 pair。
每侧只分析一个 process-thread；pid/tid 未指定时请用固定 seed 可复现随机选择。
请输出中文对比报告，并读取 Perfetto 的 HTML/文本/SQL 对所选线程做内容复核；截图仅在需要判断 Canvas 布局时使用。
```

只有两个路径而没有明确角色时，不执行比较；询问用户哪个是真机、哪个是仿真。

## 推荐完整模板

```text
使用 $profiling-analyze-compare 做真机/仿真一致性分析。

真机 Profiling（reference）：<绝对路径>
仿真 Profiling（candidate）：<绝对路径>

模型：<model name/version>
真机 workload/request：<数据集、batch、input/output length、请求 ID 或配置摘要>
仿真 workload/request：<应与真机相同；写出实际值>
真机阶段：<prefill/decode/mixed/train/backward/...>
仿真阶段：<同上>
Profiler schedule：<wait/warmup/active/repeat，或配置文件路径>
并行配置：<world size, DP/TP/EP/PP/CP/DCP>
真机 Rank（可选）：<global rank、rank label 或 ASCEND_PROFILER_OUTPUT 路径；不知道写“未记录”>
仿真 Rank（可选）：<同上>
process-thread（可选）：<两侧 pid/tid；不知道写“随机选择，seed=0”>

模型推理代码位置（可选，默认两侧共用）：<GitHub/GitCode 仓/blob/tree URL、本地 checkout、具体 .sh，或全是 .sh 的目录>
代码版本（推荐 commit）：<commit/tag/branch>
如果两侧源码不同，请分别写：
- 真机代码仓/ref：<URL 或路径>@<commit>
- 仿真代码仓/ref：<URL 或路径>@<commit>
入口线索（可选）：<具体 .sh、.sh 目录、Python script/module 或启动命令；不知道写“未记录”>

关注问题：<结构一致性、Shape、通信、仿真时延准确度、某个异常算子等>
允许差异阈值（可选）：<按指标列出，不提供则只报告数值、不擅自判定通过/失败>
输出目录：<位于两个原始 Profiling 目录之外>
```

## 解释规则

- 用户写“环境 A/B”而非“真机/仿真”时，要求补充角色。
- 用户只写一个 workload/phase 时，把它视为“用户声称两侧相同”，但仍用 metadata/Step/Shape 验证；冲突时以实际证据为准并标记门禁失败。
- 未给容差时，不创造统一的 5%/10% 阈值；报告绝对差、相对差和可比性，由用户或项目规范决定是否通过。
- 代码仓不是必填项。缺少代码时完成 Profiler 层比较，并把源码因果映射标为未知。
- workload/request、phase 和 Profiler schedule/窗口标识都可以写“未记录”。Skill 仍执行结构、Shape 和路径比较，但时间门禁会是“待人工确认”或“否”，不得把时间比率写成仿真准确度。
- Rank 未指定时按并行坐标确定性选择一个 pair；process-thread 未指定时才随机，并用 seed + SHA-256 保证可复现。二者都必须在报告中列出实际选择结果。
- 代码只给 `.sh` 或一个全是 `.sh` 的位置是合法输入；Skill 会静态追踪 launcher 和 Python 入口，不会运行脚本。
- Perfetto/browser/网络不可用时仍生成本地算子热力图，并明确标注“Perfetto 内容复核未执行”。

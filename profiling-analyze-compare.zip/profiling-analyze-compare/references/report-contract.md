# 真机/仿真中文报告契约

必须生成且只生成以下六份 Markdown 主报告。正文、标题、表头、结论和建议使用中文；算子、代码符号、字段、路径和 URL 保留原文。每份报告开头重复：真机路径、仿真路径、差值方向 `仿真-真机`、比率方向 `仿真/真机`、时间解释门禁。

统一标签：

- `真机事实`：真机 Profiler/metadata/log 直接给出；
- `仿真事实`：仿真产物直接给出；
- `源码事实`：固定代码版本中直接存在；
- `推断`：由事实链推导，列出替代解释；
- `未知`：当前不可观测；
- `建议`：下一步动作。

缺失、实测 0、未建模和不适用必须分开。没有用户/项目容差时，不自行创造阈值判断通过或失败。

## 00_compare_executive_summary.md

必须包含：

1. 真机/仿真角色、模型/workload/phase/topology 和可比性等级；
2. 结构保真度、时间保真度、系统建模保真度各一句结论；
3. 五个最重要差异，优先 PyTorch/Shape/通信/Stage，不以 CANN Top 起笔；
4. 一个端到端差异链：`代码/配置 -> PyTorch -> device Shape/path -> communication -> Step`；
5. 仿真能复现、不能复现、尚未证明的内容；
6. 三个最小验证动作。

若时间门禁不是 `是`，首段必须写“时间保真度不可判定/待确认”，不能给总体百分比。

## 01_pair_identity_and_comparability.md

必须包含：

- 两个输入目录、role、文件 inventory、采集时间和版本；
- model、weight/config、workload、batch/sequence/concurrency、phase、schedule；
- world size 与 DP/TP/EP/PP/CP/DCP；
- rank 坐标映射表；
- 主证据 coverage 对照；
- 每个 comparability gate 的状态、证据和影响；
- 允许比较的维度与禁止解释的维度。

主表：

| 门禁 | 真机 | 仿真 | 状态 | 证据 | 对后续结论的影响 |
|---|---|---|---|---|---|

## 02_pytorch_operator_fidelity.md

必须以 PyTorch operator 为主体，包含：

- operator/Shape presence coverage；
- 仅真机、仅仿真和双方存在实体；
- calls、Host Self/Total、Device Self/Total 的真机值、仿真值、delta、ratio；
- Shape bucket 和动态 Shape 分布；
- call stack/module 差异；
- attention/MoE/KV/GEMM/norm/graph 等路径差异；
- total 差异拆解为 calls、per-call 和 Shape/path。

主表：

| Rank 坐标 | PyTorch operator | Input Shape | Presence | Calls 真/仿 | Device Self 真/仿 | 仿真/真机 | Call stack 差异 | 证据 |
|---|---|---|---|---|---|---:|---|---|

PyTorch output Shape 没有直接证据时继续写未知，不得从 device kernel 自动补齐。

## 03_execution_shape_and_path_fidelity.md

必须包含：

- device operator/kernel 的 presence、name/type/core；
- input/output Shape、dtype、format；
- calls、total/avg/max duration 和 wait；
- PyTorch 一致但 lowering/kernel/fusion 不同的路径；
- Shape 一致但 format/dtype/tiling 不同的路径；
- 仿真未建模或额外生成的 device entity；
- kernel sum 与 wall-clock 的区别。

主表：

| Rank 坐标 | Device operator | I/O Shape/dtype/format | Presence | Calls 真/仿 | Duration 真/仿 | 仿真/真机 | 路径解释 | 证据 |
|---|---|---|---|---|---|---:|---|---|

## 04_communication_step_and_system_fidelity.md

必须包含：

- collective/P2P、group、peer/link/transport、parallel axis；
- communication kernel I/O Shape 与 calls；
- message、transit、wait、sync、bandwidth；
- communication-not-overlapped、overlap、Stage、free；
- rank imbalance 在两侧的变化；
- memory allocated/reserved/active 和仿真 allocator 建模状态；
- 系统层未建模项清单。

通信主表：

| Rank/轴 | Type/Group/Peer | Presence | Message 真/仿 | Transit 真/仿 | Wait/Sync 真/仿 | Not-overlap 真/仿 | 证据 |
|---|---|---|---|---|---|---|---|

Step 主表：

| Rank | 语义阶段/Step 序号 | Stage 真/仿 | Compute 真/仿 | Communication 真/仿 | Not-overlap 真/仿 | 仿真/真机 | 可解释性 |
|---|---|---|---|---|---|---:|---|

必须原样包含：

> HCCL AICPU duration 可能包含等待或同步，不等同于链路传输时间；链路口径应以 communication.json/matrix 为准。

## 05_code_causality_and_actions.md

如果提供了代码仓，必须包含：

- repo URL/本地路径、provider、commit/tag/branch、是否为永久版本；
- 运行版本与被读源码版本是否一致；
- 从重大 Profiler 差异到代码 symbol 的证据链；
- guard/dispatch/Shape/group/graph/cache 的源码事实；
- runtime 事实、关联推断、替代解释和缺失值；
- 对仿真器、Profiler 采集和模型代码分别给出的改进建议。

代码证据表：

| Profiler 差异 | 源码事实 | Repo@commit | File/symbol/lines | Runtime 绑定证据 | 结论强度 | 永久链接 |
|---|---|---|---|---|---|---|

如果没有代码仓，明确写“未提供源码，不能做代码级因果绑定”，仍需给出下一步需要的 symbol/配置/hook。

结尾必须列出：

- 已确认的仿真缺口；
- 需要补证的候选缺口；
- 最小重采/单元测试/A-B 实验；
- 可自动化的回归指标；
- 若有用户容差，逐项给出通过/失败；否则仅给排序和数值。

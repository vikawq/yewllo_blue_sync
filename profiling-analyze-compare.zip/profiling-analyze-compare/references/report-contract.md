# 真机/仿真中文报告契约

必须生成且只生成以下六份 Markdown 主报告。正文、标题、表头、结论和建议使用中文；算子、代码符号、字段、路径和 URL 保留原文。每份报告开头重复：真机路径、仿真路径、差值方向 `仿真-真机`、比率方向 `仿真/真机`、时间解释门禁。

每份报告同时声明本次范围：每侧一个所选 Rank；线程级章节每侧一个所选 process-thread。其它 Rank/线程不在结论覆盖范围内。

统一标签：

- `真机事实`：真机 Profiler/metadata/log 直接给出；
- `仿真事实`：仿真产物直接给出；
- `源码事实`：固定代码版本中直接存在；
- `推断`：由事实链推导，列出替代解释；
- `未知`：当前不可观测；
- `建议`：下一步动作。

缺失、实测 0、未建模和不适用必须分开。没有用户/项目容差时，不自行创造阈值判断通过或失败。

## 00_compare_executive_summary.md

必须包含：

1. 真机/仿真角色、模型/workload/phase/topology 和可比性等级；
2. 所选 Rank pair、所选 process-thread、选择方法/seed/对齐置信度；
3. 结构保真度、时间保真度、系统建模保真度各一句结论；
4. 五个最重要差异，优先所选线程 PyTorch/Shape/通信/Stage，不以 CANN Top 起笔；
5. 一个端到端差异链：`.sh/代码/配置 -> Python/forward -> PyTorch -> device Shape/path -> communication -> Step`；
6. 仿真能复现、不能复现、尚未证明的内容；
7. 三个最小验证动作。

若时间门禁不是 `是`，首段必须写“时间保真度不可判定/待确认”，不能给总体百分比。

## 01_pair_identity_and_comparability.md

必须包含：

- 两个输入目录、role、文件 inventory、采集时间和版本；
- model、weight/config、workload、batch/sequence/concurrency、phase、schedule；
- 完整候选拓扑上下文与所选 Rank 的 DP/TP/EP/PP/CP/DCP；
- 恰好一行的 Rank pair 表，global rank 只登记、不作为实体主键；
- process/thread 候选数、选择 seed/SHA-256、pid/tid/name、对齐方法/分数/置信度；
- 主证据 coverage 对照；
- 每个 comparability gate 的状态、证据和影响；
- 声明 phase 与所选线程运行时阶段证据的交叉核验；出现 backward/FSDP/loss backward 时不得把用户误写的 `decode` 直接判为通过；
- 允许比较的维度与禁止解释的维度。

主表：

| 门禁 | 真机 | 仿真 | 状态 | 证据 | 对后续结论的影响 |
|---|---|---|---|---|---|

## 02_pytorch_operator_fidelity.md

必须以 PyTorch operator 为主体，包含：

- 所选 process-thread 实际执行的具体 PyTorch operator 序列、Input Shape、calls、inclusive/self 时间；
- 真机、仿真分别按各自 PyTorch-exclusive 时间排序的热点表，以及双方匹配的热点表；不能先用仅一侧的 autograd/module scope 填满 Top-N；
- 线程选择/对齐证据，无法对齐时的解释降级；
- normalized time-bin × operator 热力图，同时保留 inclusive overlap 与 calls，主色值使用 deepest/exclusive coverage，单 bin 不超过 100%；即使 operator 的 exclusive 为 0 也不能从热力图明细中删除；
- Perfetto SQL 热点表、渲染 HTML/文本的内容复核状态，以及可选截图复核状态；
- operator/Shape presence coverage；
- 仅真机、仅仿真和双方存在实体；
- calls、Host Self/Total、Device Self/Total 的真机值、仿真值、delta、ratio；
- Shape bucket 和动态 Shape 分布；
- call stack/module 差异；
- attention/MoE/KV/GEMM/norm/graph 等路径差异；
- total 差异拆解为 calls、per-call 和 Shape/path。

具体 dispatcher/custom operator（如 `aten::`、`npu::`）与 module/autograd/record-function scope 必须分表；`AddBackward0`、`CheckpointFunction`、FSDP scope 等不得冒充具体 PyTorch dispatcher 热点。热力图中的 `<未归属>` 只表示相邻已确认算子间的时间间隙，单列覆盖率且永不标为“主导算子”。序列表优先展示首批非 equal 差异并保留上下文，不能让长串开头 equal 行淹没首次分歧。

主表：

| Rank 坐标 | PyTorch operator | Input Shape | Presence | Calls 真/仿 | Device Self 真/仿 | 仿真/真机 | Call stack 差异 | 证据 |
|---|---|---|---|---|---|---:|---|---|

若 `trace_view.json` 的 PyTorch event 直接提供 `Output Dims/Output Shapes/Output Shape`，必须保留并按 output Shape 分桶；没有直接证据时继续写未知，不得从 device kernel 自动补齐。

线程主表至少包含：

| Process/thread 真/仿 | PyTorch operator | Input Shape | Output Shape | Presence | Calls 真/仿 | Self/Inclusive 真/仿 | Sequence 状态 | 源码映射 |
|---|---|---|---|---|---|---|---|---|

若 Perfetto 未实际加载，写“页面/SQL 自动读取未执行”及具体原因。报告必须拆分三个状态：页面/SQL 自动产物、Perfetto 内容复核、Canvas 截图复核。两侧 manifest 成功，且同时满足 `offline_before_trace_post=true`、Service Worker 数为 0、PID/TID/trace SHA-256 与当前所选线程一致，并存在 SQL 热点和 HTML/文本产物时，自动产物才写“完成”。分析代理实际读取 HTML/DOM/文本或 SQL 后，需在 `perfetto_visual_review.json` 写入 `status="完成"`、实际 `review_methods`、`reviewed_environments=["real","sim"]` 和非空 `observations`，内容复核即可写“完成”；截图不是硬门禁。只有 `screenshot_reviewed=true` 时才把 Canvas 截图复核写为“完成”。时间线为 Canvas，不能仅凭 HTML 源码或自动化 manifest 声称看到了颜色/条块/轨道几何；数值以本地 trace CSV 或 Perfetto SQL 为准。

## 03_execution_shape_and_path_fidelity.md

必须包含：

- device operator/kernel 的 presence、name/type/core；
- input/output Shape、dtype、format；
- calls、total/avg/max duration 和 wait；
- PyTorch 一致但 lowering/kernel/fusion 不同的路径；
- Shape 一致但 format/dtype/tiling 不同的路径；
- 仿真未建模或额外生成的 device entity；
- kernel sum 与 wall-clock 的区别。

主表：

| Rank 坐标 | Device operator | I/O Shape/dtype/format | Presence | Calls 真/仿 | Duration 真/仿 | 仿真/真机 | 路径解释 | 证据 |
|---|---|---|---|---|---|---:|---|---|

## 04_communication_step_and_system_fidelity.md

必须包含：

- collective/P2P、group、peer/link/transport、parallel axis；
- communication kernel I/O Shape 与 calls；
- message、transit、wait、sync、bandwidth；
- communication-not-overlapped、overlap、Stage、free；
- 明确声明单 Rank 范围，不输出 rank imbalance；
- memory allocated/reserved/active 和仿真 allocator 建模状态；
- 系统层未建模项清单。

raw communication group 数字是环境内句柄，不得直接作为跨环境身份。主对比至少按 `category + collective_type + 已证实 parallel_axis` 汇总，并把两侧 raw group 列表作为审计字段；raw-group 明细另表保留。只有规范的 `DP/TP/EP/PP/CP/DCP` 值才算已推断轴，`未知（...）`、`待全局拓扑推断` 等占位文案不得计数。普通 tensor `BroadcastTo` 不属于通信 kernel，除非同时有 HCCL/HCOM/COMMUNICATION core 等直接证据。

通信主表：

| Rank/轴 | Type/Group/Peer | Presence | Message 真/仿 | Transit 真/仿 | Wait/Sync 真/仿 | Not-overlap 真/仿 | 证据 |
|---|---|---|---|---|---|---|---|

Step 主表：

| Rank | 语义阶段/Step 序号 | Stage 真/仿 | Compute 真/仿 | Communication 真/仿 | Not-overlap 真/仿 | 仿真/真机 | 可解释性 |
|---|---|---|---|---|---|---:|---|

必须原样包含：

> HCCL AICPU duration 可能包含等待或同步，不等同于链路传输时间；链路口径应以 communication.json/matrix 为准。

## 05_code_causality_and_actions.md

如果提供了代码仓，必须包含：

- repo URL/本地路径、provider、commit/tag/branch、是否为永久版本；
- 运行版本与被读源码版本是否一致；
- 从重大 Profiler 差异到代码 symbol 的证据链；
- `.sh`/目录入口候选、source/include、wrapper/launcher、Python script/module、main/forward/dispatch 的静态链；
- 所选线程 operator 到代码 callsite/symbol 的映射方法与置信度；
- guard/dispatch/Shape/group/graph/cache 的源码事实；
- runtime 事实、关联推断、替代解释和缺失值；
- 对仿真器、Profiler 采集和模型代码分别给出的改进建议。
- 本地入口解析与线程源码映射的完成/受限/失败状态、首个 unresolved 及最小补证；失败不能被空表掩盖。

代码证据表：

| Profiler 差异 | 源码事实 | Repo@commit | File/symbol/lines | Runtime 绑定证据 | 结论强度 | 永久链接 |
|---|---|---|---|---|---|---|

如果没有代码仓，明确写“未提供源码，不能做代码级因果绑定”，仍需给出下一步需要的 symbol/配置/hook。

渲染器只接受 `comparison_manifest.json` 的 `status=complete` 且 schema 为当前版本；`running`、失败或旧 schema 必须拒绝，不能混用上一轮 CSV/Perfetto/源码产物。

只给 `.sh` 时不能止步于“文件存在”：静态追踪到 Python 入口并在同一固定仓库内继续找 model `forward/dispatch`。但不得执行 shell、导入仓库 Python，静态可达性只能标为候选；结合 call stack/module/runtime marker 后才可升级。

结尾必须列出：

- 已确认的仿真缺口；
- 需要补证的候选缺口；
- 最小重采/单元测试/A-B 实验；
- 可自动化的单 Rank/单线程回归指标；rank imbalance 必须另采多 Rank；
- 若有用户容差，逐项给出通过/失败；否则仅给排序和数值。

#!/usr/bin/env python3
"""对比显式标注的真机与仿真 Ascend/PyTorch Profiling。

真机固定作为 reference，仿真固定作为 candidate。脚本先调用同目录下沿用自
analyze-ascend-profiling 的流式汇总器，再按拓扑坐标、算子语义和 Shape 生成紧凑
对比证据。所有差值方向均为“仿真 - 真机”，所有比率均为“仿真 / 真机”。
"""

from __future__ import annotations

import argparse
import ast
import csv
import json
import math
import re
import subprocess
import sys
from collections import defaultdict
from pathlib import Path
from typing import Any, Callable, Iterable


UNKNOWN = {"", "未知", "unknown", "none", "null", "n/a", "na", "?"}
COORD_FIELDS = ["dp", "tp", "ep", "pp", "cp", "dcp", "global_rank"]
PRIMARY_FILES = {
    "operator_details.csv",
    "kernel_details.csv",
    "communication.json",
    "communication_matrix.json",
    "step_trace_time.csv",
}


def clean(value: Any, limit: int = 2000) -> str:
    text = "" if value is None else str(value).strip()
    text = re.sub(r"\s+", " ", text)
    return text if len(text) <= limit else text[: limit - 3] + "..."


def number(value: Any) -> float | None:
    text = clean(value).replace(",", "").rstrip("%")
    if text.lower() in UNKNOWN:
        return None
    try:
        result = float(text)
        return result if math.isfinite(result) else None
    except ValueError:
        return None


def write_csv(path: Path, rows: Iterable[dict[str, Any]], fields: list[str] | None = None) -> None:
    materialized = list(rows)
    path.parent.mkdir(parents=True, exist_ok=True)
    if fields is None:
        fields = []
        seen: set[str] = set()
        for row in materialized:
            for key in row:
                if key not in seen:
                    seen.add(key)
                    fields.append(key)
        if not fields:
            fields = ["message"]
    with path.open("w", newline="", encoding="utf-8-sig") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields, extrasaction="ignore")
        writer.writeheader()
        writer.writerows(materialized)


def write_json(path: Path, value: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8") as handle:
        json.dump(value, handle, ensure_ascii=False, indent=2)


def read_csv(path: Path) -> list[dict[str, str]]:
    if not path.exists():
        return []
    with path.open("r", newline="", encoding="utf-8-sig", errors="replace") as handle:
        rows: list[dict[str, str]] = []
        for line_number, row in enumerate(csv.DictReader(handle), start=2):
            materialized = dict(row)
            materialized["_evidence"] = f"{path}:{line_number}"
            rows.append(materialized)
        return rows


def read_json(path: Path, default: Any) -> Any:
    if not path.exists():
        return default
    with path.open("r", encoding="utf-8-sig", errors="replace") as handle:
        return json.load(handle)


def norm(value: Any) -> str:
    text = clean(value)
    return "未知" if text.lower() in UNKNOWN else text


def rank_key(row: dict[str, Any]) -> str:
    values = [f"{field}={norm(row.get(field))}" for field in COORD_FIELDS]
    return "|".join(values)


def display_rank(row: dict[str, Any]) -> str:
    return clean(row.get("rank")) or rank_key(row)


def shape_text(value: Any) -> str:
    text = clean(value, 5000)
    if text.startswith("未知"):
        return "未知"
    try:
        parsed = ast.literal_eval(text)
        if isinstance(parsed, (list, tuple, dict, int, float, str, type(None))):
            return json.dumps(parsed, ensure_ascii=False, separators=(",", ":"))
    except (ValueError, SyntaxError, MemoryError, RecursionError):
        pass
    return re.sub(r"\s+", "", text)


def collect_rank_csv(extracted: Path, filename: str) -> list[dict[str, str]]:
    rows: list[dict[str, str]] = []
    for path in sorted(extracted.glob(f"*/{filename}")):
        rows.extend(read_csv(path))
    return rows


def validate_comparison_extraction(extracted: Path, role: str) -> None:
    summary = read_json(extracted / "summary.json", {})
    ranks = summary.get("ranks", []) if isinstance(summary, dict) else []
    if not isinstance(ranks, list) or not ranks:
        raise ValueError(f"{role}摘要没有 rank 数据：{extracted / 'summary.json'}")
    for rank in ranks:
        if not isinstance(rank, dict):
            continue
        for domain in ("pytorch_operator", "device_operator"):
            data = rank.get(domain)
            if isinstance(data, dict) and not data.get("comparison_full_signatures_written"):
                raise ValueError(
                    f"{role}摘要来自旧版/截断抽取，缺少 {domain} 全量签名；请移除 --skip-extraction 重新抽取"
                )


def resolve_roots(real: Path, sim: Path, output: Path) -> tuple[Path, Path, Path]:
    real = real.resolve()
    sim = sim.resolve()
    output = output.resolve()
    for role, root in (("真机", real), ("仿真", sim)):
        if not root.exists() or not root.is_dir():
            raise ValueError(f"{role} Profiling 目录不存在：{root}")
    if real == sim:
        raise ValueError("真机与仿真 Profiling 不能指向同一目录；请显式提供两个产物")
    for role, root in (("真机", real), ("仿真", sim)):
        if output == root or root in output.parents:
            raise ValueError(f"输出目录不能位于{role} Profiling 根目录内")
    return real, sim, output


def run_analyzer(script: Path, source: Path, destination: Path, top_n: int) -> None:
    command = [
        sys.executable,
        str(script),
        "--input",
        str(source),
        "--output",
        str(destination),
        "--top",
        str(top_n),
    ]
    completed = subprocess.run(command, text=True, capture_output=True, encoding="utf-8", errors="replace")
    if completed.returncode:
        raise RuntimeError(
            f"单环境分析失败：{source}\nstdout:\n{completed.stdout}\nstderr:\n{completed.stderr}"
        )


def aggregate_rows(
    rows: list[dict[str, Any]],
    key_fn: Callable[[dict[str, Any]], tuple[str, ...]],
    metric_fields: list[str],
    text_fields: list[str],
) -> dict[tuple[str, ...], dict[str, Any]]:
    grouped: dict[tuple[str, ...], dict[str, Any]] = {}
    for source in rows:
        key = key_fn(source)
        item = grouped.setdefault(
            key,
            {
                "_key": key,
                "_records": 0,
                "_texts": defaultdict(set),
                "_metrics": defaultdict(float),
                "_metric_seen": set(),
                "_evidence": set(),
            },
        )
        item["_records"] += 1
        for field in metric_fields:
            value = number(source.get(field))
            if value is not None:
                item["_metrics"][field] += value
                item["_metric_seen"].add(field)
        for field in text_fields:
            value = clean(source.get(field), 5000)
            if value:
                item["_texts"][field].add(value)
        evidence = clean(source.get("_evidence"), 5000)
        if evidence:
            item["_evidence"].add(evidence)
        item.setdefault("_example", source)
    return grouped


def ratio_fields(real_value: float | None, sim_value: float | None) -> dict[str, Any]:
    if real_value is None or sim_value is None:
        return {"delta": "不可计算", "sim_over_real": "不可计算", "delta_percent": "不可计算"}
    delta = sim_value - real_value
    if real_value == 0:
        ratio: Any = 1.0 if sim_value == 0 else "不可计算（真机为0）"
        percent: Any = 0.0 if sim_value == 0 else "不可计算（真机为0）"
    else:
        ratio = sim_value / real_value
        percent = 100.0 * delta / real_value
    return {
        "delta": round(delta, 9),
        "sim_over_real": round(ratio, 9) if isinstance(ratio, float) else ratio,
        "delta_percent": round(percent, 6) if isinstance(percent, float) else percent,
    }


def compare_grouped(
    real: dict[tuple[str, ...], dict[str, Any]],
    sim: dict[tuple[str, ...], dict[str, Any]],
    key_names: list[str],
    metrics: list[str],
    text_fields: list[str],
    timing_allowed: str,
) -> list[dict[str, Any]]:
    output: list[dict[str, Any]] = []
    for key in sorted(set(real) | set(sim)):
        left = real.get(key)
        right = sim.get(key)
        presence = "两侧存在" if left and right else ("仅真机" if left else "仅仿真")
        row: dict[str, Any] = {name: value for name, value in zip(key_names, key)}
        row["presence"] = presence
        row["timing_interpretation_allowed"] = timing_allowed
        row["real_records"] = left["_records"] if left else 0
        row["sim_records"] = right["_records"] if right else 0
        row["record_count_match"] = "是" if row["real_records"] == row["sim_records"] else "否"
        row["real_evidence"] = json.dumps(sorted(left["_evidence"]), ensure_ascii=False) if left else "[]"
        row["sim_evidence"] = json.dumps(sorted(right["_evidence"]), ensure_ascii=False) if right else "[]"
        for field in metrics:
            left_value = left["_metrics"].get(field) if left and field in left["_metric_seen"] else None
            right_value = right["_metrics"].get(field) if right and field in right["_metric_seen"] else None
            row[f"real_{field}"] = "缺失" if left_value is None else round(left_value, 9)
            row[f"sim_{field}"] = "缺失" if right_value is None else round(right_value, 9)
            derived = ratio_fields(left_value, right_value)
            row[f"{field}_sim_minus_real"] = derived["delta"]
            row[f"{field}_sim_over_real"] = derived["sim_over_real"]
            row[f"{field}_delta_percent"] = derived["delta_percent"]
        for field in text_fields:
            left_text = sorted(left["_texts"].get(field, set())) if left else []
            right_text = sorted(right["_texts"].get(field, set())) if right else []
            row[f"real_{field}"] = json.dumps(left_text, ensure_ascii=False)
            row[f"sim_{field}"] = json.dumps(right_text, ensure_ascii=False)
            row[f"{field}_match"] = "是" if left_text == right_text else "否"
        output.append(row)
    return output


def add_per_call_metric(
    grouped: dict[tuple[str, ...], dict[str, Any]],
    total_field: str,
    output_field: str,
    calls_field: str = "calls",
) -> None:
    for item in grouped.values():
        if total_field not in item["_metric_seen"] or calls_field not in item["_metric_seen"]:
            continue
        calls = item["_metrics"].get(calls_field, 0.0)
        if calls <= 0:
            continue
        item["_metrics"][output_field] = item["_metrics"][total_field] / calls
        item["_metric_seen"].add(output_field)


def add_effect_decomposition(
    rows: list[dict[str, Any]],
    total_field: str,
    per_call_field: str,
    calls_field: str = "calls",
) -> None:
    for row in rows:
        real_calls = number(row.get(f"real_{calls_field}"))
        sim_calls = number(row.get(f"sim_{calls_field}"))
        real_avg = number(row.get(f"real_{per_call_field}"))
        sim_avg = number(row.get(f"sim_{per_call_field}"))
        if None in {real_calls, sim_calls, real_avg, sim_avg}:
            row[f"{total_field}_volume_effect"] = "不可计算"
            row[f"{total_field}_unit_cost_effect"] = "不可计算"
            continue
        row[f"{total_field}_volume_effect"] = round((sim_calls - real_calls) * real_avg, 9)
        row[f"{total_field}_unit_cost_effect"] = round(sim_calls * (sim_avg - real_avg), 9)


def pytorch_key(row: dict[str, Any]) -> tuple[str, ...]:
    return rank_key(row), clean(row.get("operator")), shape_text(row.get("input_shapes"))


def device_key(row: dict[str, Any]) -> tuple[str, ...]:
    return (
        rank_key(row),
        clean(row.get("operator")),
        clean(row.get("type")),
        shape_text(row.get("input_shapes")),
        shape_text(row.get("output_shapes")),
        clean(row.get("input_dtypes")),
        clean(row.get("output_dtypes")),
        clean(row.get("accelerator_core")),
        clean(row.get("input_formats")),
        clean(row.get("output_formats")),
    )


def communication_key(row: dict[str, Any]) -> tuple[str, ...]:
    return (
        rank_key(row),
        clean(row.get("category")),
        clean(row.get("collective_type")),
        clean(row.get("communication_group")),
        clean(row.get("parallel_axis")),
    )


def memory_key(row: dict[str, Any]) -> tuple[str, ...]:
    return rank_key(row), clean(row.get("component")), clean(row.get("device_type"))


def communication_link_key(row: dict[str, Any]) -> tuple[str, ...]:
    return (
        rank_key(row),
        clean(row.get("category")),
        clean(row.get("collective_type")),
        clean(row.get("communication_group")),
        clean(row.get("parallel_axis")),
        clean(row.get("link")),
    )


def step_rows_with_ordinal(rows: list[dict[str, Any]]) -> list[dict[str, Any]]:
    by_rank: dict[str, list[dict[str, Any]]] = defaultdict(list)
    for row in rows:
        by_rank[rank_key(row)].append(row)

    def step_sort(row: dict[str, Any]) -> tuple[int, float, str]:
        text = clean(row.get("step"))
        match = re.search(r"-?\d+(?:\.\d+)?", text)
        return (0, float(match.group())) if match else (1, 0.0, text)

    result: list[dict[str, Any]] = []
    for key, rank_rows in by_rank.items():
        for index, source in enumerate(sorted(rank_rows, key=step_sort), start=1):
            row = dict(source)
            row["step_ordinal"] = index
            row["rank_alignment_key"] = key
            result.append(row)
    return result


def step_key(row: dict[str, Any]) -> tuple[str, ...]:
    return str(row.get("rank_alignment_key") or rank_key(row)), str(row.get("step_ordinal"))


def profile_inputs(args: argparse.Namespace) -> list[dict[str, str]]:
    return [
        {
            "field": "model",
            "real": clean(args.real_model),
            "sim": clean(args.sim_model),
            "required_for_timing": "是",
        },
        {
            "field": "workload_id",
            "real": clean(args.real_workload_id),
            "sim": clean(args.sim_workload_id),
            "required_for_timing": "是",
        },
        {
            "field": "phase",
            "real": clean(args.real_phase),
            "sim": clean(args.sim_phase),
            "required_for_timing": "是",
        },
        {
            "field": "schedule_id",
            "real": clean(args.real_schedule_id),
            "sim": clean(args.sim_schedule_id),
            "required_for_timing": "是",
        },
    ]


def source_binding_rows(args: argparse.Namespace) -> list[dict[str, str]]:
    common_repo = clean(args.code_repo)
    common_ref = clean(args.code_ref)
    real_repo = clean(args.real_code_repo) or common_repo
    sim_repo = clean(args.sim_code_repo) or common_repo
    real_ref = clean(args.real_code_ref) or common_ref
    sim_ref = clean(args.sim_code_ref) or common_ref
    rows = []
    for environment, repository, requested_ref in (
        ("real/reference/真机", real_repo, real_ref),
        ("sim/candidate/仿真", sim_repo, sim_ref),
    ):
        rows.append(
            {
                "environment": environment,
                "repository_url_or_path": repository,
                "requested_ref": requested_ref,
                "resolved_commit": "待源码读取阶段解析" if repository else "未提供",
                "runtime_binding": "未验证" if repository else "未提供",
                "access_mode": "待解析" if repository else "不适用",
                "notes": "脚本仅登记；分析代理必须固定 commit 并补充运行版本证据",
            }
        )
    return rows


def compare_profile_inputs(rows: list[dict[str, str]]) -> list[dict[str, Any]]:
    output = []
    for row in rows:
        real = row["real"]
        sim = row["sim"]
        if not real or not sim:
            status = "待确认"
            detail = "至少一侧未显式提供"
        elif real == sim:
            status = "通过"
            detail = "两侧显式值一致"
        else:
            status = "不通过"
            detail = "两侧显式值不同"
        output.append({**row, "status": status, "detail": detail})
    return output


def topology_gates(real_dir: Path, sim_dir: Path) -> list[dict[str, Any]]:
    real_degrees = read_json(real_dir / "parallel_degrees.json", {})
    sim_degrees = read_json(sim_dir / "parallel_degrees.json", {})
    real_topology = read_csv(real_dir / "rank_topology.csv")
    sim_topology = read_csv(sim_dir / "rank_topology.csv")
    real_rank_keys = {rank_key(row) for row in real_topology}
    sim_rank_keys = {rank_key(row) for row in sim_topology}
    degree_fields = ["world_size_discovered", "dp", "tp", "ep", "pp", "cp", "dcp"]
    degree_match = all(str(real_degrees.get(field)) == str(sim_degrees.get(field)) for field in degree_fields)
    return [
        {
            "gate": "parallel_degrees",
            "status": "通过" if degree_match else "不通过",
            "real": json.dumps({field: real_degrees.get(field) for field in degree_fields}, ensure_ascii=False),
            "sim": json.dumps({field: sim_degrees.get(field) for field in degree_fields}, ensure_ascii=False),
            "impact": "不一致时不能做严格逐 rank 性能比率",
        },
        {
            "gate": "rank_coordinates",
            "status": "通过" if real_rank_keys == sim_rank_keys else "不通过",
            "real": json.dumps(sorted(real_rank_keys), ensure_ascii=False),
            "sim": json.dumps(sorted(sim_rank_keys), ensure_ascii=False),
            "impact": "不一致时仅能做聚合结构观察，不能把不同 shard/rank 直接相除",
        },
    ]


def rank_alignment_rows(real_dir: Path, sim_dir: Path) -> list[dict[str, Any]]:
    real = {rank_key(row): row for row in read_csv(real_dir / "rank_topology.csv")}
    sim = {rank_key(row): row for row in read_csv(sim_dir / "rank_topology.csv")}
    rows = []
    for key in sorted(set(real) | set(sim)):
        left = real.get(key, {})
        right = sim.get(key, {})
        rows.append(
            {
                "rank_alignment_key": key,
                "presence": "两侧存在" if left and right else ("仅真机" if left else "仅仿真"),
                "real_rank": clean(left.get("rank")),
                "sim_rank": clean(right.get("rank")),
                "real_device": clean(left.get("device")),
                "sim_device": clean(right.get("device")),
                "real_parallel_coordinate": clean(left.get("parallel_coordinate")),
                "sim_parallel_coordinate": clean(right.get("parallel_coordinate")),
                "alignment_method": "DP/TP/EP/PP/CP/DCP + global rank 消歧",
                "confidence": "高" if left and right else "未对齐",
            }
        )
    return rows


def coverage_gates(real_dir: Path, sim_dir: Path) -> tuple[list[dict[str, Any]], int, int]:
    real_rows = read_csv(real_dir / "source_coverage_all_ranks.csv")
    sim_rows = read_csv(sim_dir / "source_coverage_all_ranks.csv")

    def index(rows: list[dict[str, Any]]) -> dict[tuple[str, str], str]:
        return {(rank_key(row), clean(row.get("file"))): clean(row.get("present")) for row in rows}

    left = index(real_rows)
    right = index(sim_rows)
    output = []
    mismatch = 0
    missing_both = 0
    for key in sorted(set(left) | set(right)):
        real_present = left.get(key, "无记录")
        sim_present = right.get(key, "无记录")
        same = real_present == sim_present
        if key[1] in PRIMARY_FILES and not same:
            mismatch += 1
        if key[1] in PRIMARY_FILES and real_present != "是" and sim_present != "是":
            missing_both += 1
        output.append(
            {
                "rank_alignment_key": key[0],
                "file": key[1],
                "real_present": real_present,
                "sim_present": sim_present,
                "match": "是" if same else "否",
                "priority": "主证据" if key[1] in PRIMARY_FILES else "可选/辅助",
            }
        )
    return output, mismatch, missing_both


def timing_gate(
    gates: list[dict[str, Any]],
    input_gates: list[dict[str, Any]],
    coverage_mismatch: int,
    coverage_missing_both: int,
) -> str:
    if any(row["status"] == "不通过" for row in gates + input_gates):
        return "否"
    if coverage_mismatch:
        return "否"
    if any(row["status"] == "待确认" for row in input_gates):
        return "待人工确认"
    if coverage_missing_both:
        return "受限（双方均缺主证据）"
    return "是"


def mismatch_summary(name: str, rows: list[dict[str, Any]]) -> dict[str, Any]:
    presence = sum(1 for row in rows if row.get("presence") != "两侧存在")
    count_change = sum(
        1 for row in rows if row.get("presence") == "两侧存在" and row.get("record_count_match") == "否"
    )
    return {
        "dimension": name,
        "entities": len(rows),
        "matched_entities": len(rows) - presence,
        "presence_mismatches": presence,
        "record_count_mismatches": count_change,
    }


def top_deviations(rows: list[dict[str, Any]], metric: str, limit: int = 20) -> list[dict[str, Any]]:
    field = f"{metric}_delta_percent"
    candidates = []
    for row in rows:
        value = number(row.get(field))
        if value is None or row.get("presence") != "两侧存在":
            continue
        candidates.append((abs(value), row))
    return [row for _, row in sorted(candidates, key=lambda item: item[0], reverse=True)[:limit]]


def markdown_table(rows: list[dict[str, Any]], columns: list[tuple[str, str]], limit: int = 20) -> list[str]:
    if not rows:
        return ["_无数据_", ""]
    lines = ["| " + " | ".join(title for _, title in columns) + " |", "|" + "|".join(["---"] * len(columns)) + "|"]
    for row in rows[:limit]:
        values = [clean(row.get(field), 160).replace("|", "\\|") for field, _ in columns]
        lines.append("| " + " | ".join(values) + " |")
    lines.append("")
    return lines


def build_summary(
    real: Path,
    sim: Path,
    gates: list[dict[str, Any]],
    input_gates: list[dict[str, Any]],
    coverage_mismatch: int,
    timing_allowed: str,
    summaries: list[dict[str, Any]],
    pytorch: list[dict[str, Any]],
    device: list[dict[str, Any]],
    communication: list[dict[str, Any]],
    step: list[dict[str, Any]],
    source_bindings: list[dict[str, str]],
) -> str:
    structure_limited = any(row["status"] == "不通过" for row in gates)
    level = "结构对比受限" if structure_limited else "结构可比"
    lines = [
        "# 真机与仿真 Profiling 对比摘要",
        "",
        f"> 真机（reference）：`{real}`  ",
        f"> 仿真（candidate）：`{sim}`  ",
        "> 差值方向：仿真 - 真机；比率方向：仿真 / 真机。  ",
        f"> 自动判定：{level}；时间比率解释：{timing_allowed}。",
        "",
        "## 1. 可比性门禁",
        "",
    ]
    lines.extend(markdown_table(gates + input_gates, [("gate", "门禁"), ("field", "输入字段"), ("status", "状态"), ("real", "真机"), ("sim", "仿真"), ("impact", "影响"), ("detail", "说明")], 30))
    if coverage_mismatch:
        lines.extend([f"`事实`：主证据文件存在性有 {coverage_mismatch} 处不一致，相关维度不能直接作性能解释。", ""])
    lines.extend(["## 2. 结构保真度", ""])
    lines.extend(markdown_table(summaries, [("dimension", "维度"), ("entities", "实体数"), ("matched_entities", "两侧存在"), ("presence_mismatches", "仅一侧存在"), ("record_count_mismatches", "记录数不一致")], 20))
    lines.extend(["## 3. PyTorch 算子主要时间偏差", ""])
    lines.extend(markdown_table(top_deviations(pytorch, "device_self_us_total", 15), [("rank_alignment_key", "Rank 对齐键"), ("operator", "算子"), ("input_shapes", "输入 Shape"), ("real_device_self_us_total", "真机 Device Self(us)"), ("sim_device_self_us_total", "仿真 Device Self(us)"), ("device_self_us_total_sim_over_real", "仿真/真机"), ("device_self_us_total_delta_percent", "差异(%)")], 15))
    lines.extend(["## 4. 设备执行与通信偏差", ""])
    lines.extend(markdown_table(top_deviations(device, "duration_us_total", 10), [("operator", "执行算子"), ("input_shapes", "输入 Shape"), ("output_shapes", "输出 Shape"), ("real_duration_us_total", "真机(us)"), ("sim_duration_us_total", "仿真(us)"), ("duration_us_total_sim_over_real", "仿真/真机")], 10))
    lines.extend(markdown_table(top_deviations(communication, "transit_ms_total", 10), [("collective_type", "通信类型"), ("communication_group", "Group"), ("parallel_axis", "并行轴"), ("real_transit_size_mb_total", "真机消息(MB)"), ("sim_transit_size_mb_total", "仿真消息(MB)"), ("transit_ms_total_sim_over_real", "Transit 仿真/真机")], 10))
    lines.extend(["## 5. Step/墙钟偏差", ""])
    lines.extend(markdown_table(top_deviations(step, "stage_us", 20), [("rank_alignment_key", "Rank 对齐键"), ("step_ordinal", "Step 序号"), ("real_stage_us", "真机 Stage(us)"), ("sim_stage_us", "仿真 Stage(us)"), ("stage_us_sim_over_real", "仿真/真机"), ("stage_us_delta_percent", "差异(%)")], 20))
    lines.extend(["## 6. 模型代码证据", ""])
    provided_bindings = [row for row in source_bindings if row["repository_url_or_path"]]
    if provided_bindings:
        lines.extend(
            [
                "用户提供的环境-源码绑定：",
                "",
                *[
                    f"- {row['environment']}：`{row['repository_url_or_path']}` @ `{row['requested_ref'] or '未提供'}`"
                    for row in provided_bindings
                ],
                "",
                "脚本只记录代码仓上下文；最终报告必须由分析代理读取仓库网页或本地 checkout，固定 commit 后把差异映射到具体 symbol/行号。",
                "",
            ]
        )
    else:
        lines.extend(["`未知`：用户未提供模型代码仓，当前只能做 Profiler 证据层比较。", ""])
    lines.extend(
        [
            "## 7. 强制解释边界",
            "",
            "- 时间解释不是“是”时，CSV 中的算术比率只能用于定位，不能写成仿真精度或性能结论。",
            "- 算子/Shape/count 一致表示路径 ABI 更接近，不表示 tensor value、routing、address 或 cache state 一致。",
            "- 仿真可能不建模真实频率、cache、链路竞争、同步和 overlap；必须分别评价结构保真度与时间保真度。",
            "- HCCL kernel duration 不等于链路 transit；通信比较优先使用 communication.json/matrix。",
            "",
        ]
    )
    return "\n".join(lines)


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--real", required=True, type=Path, help="显式标注的真机 Profiling 根目录（reference）")
    parser.add_argument("--sim", required=True, type=Path, help="显式标注的仿真 Profiling 根目录（candidate）")
    parser.add_argument("--output", required=True, type=Path, help="位于两侧原始目录之外的输出目录")
    parser.add_argument("--top", type=int, default=500, help="每个单环境保留的 Top N，默认 500")
    parser.add_argument("--real-model", default="", help="真机模型标识")
    parser.add_argument("--sim-model", default="", help="仿真模型标识")
    parser.add_argument("--real-workload-id", default="", help="真机工作负载/请求标识")
    parser.add_argument("--sim-workload-id", default="", help="仿真工作负载/请求标识")
    parser.add_argument("--real-phase", default="", help="真机阶段，如 prefill/decode")
    parser.add_argument("--sim-phase", default="", help="仿真阶段，如 prefill/decode")
    parser.add_argument("--real-schedule-id", default="", help="真机 Profiler schedule/窗口标识")
    parser.add_argument("--sim-schedule-id", default="", help="仿真 Profiler schedule/窗口标识")
    parser.add_argument("--code-repo", default="", help="可选的 GitHub/GitCode/本地代码仓地址，仅记录到 manifest")
    parser.add_argument("--code-ref", default="", help="可选的 commit/tag/branch")
    parser.add_argument("--real-code-repo", default="", help="可选的真机代码仓；覆盖 --code-repo")
    parser.add_argument("--sim-code-repo", default="", help="可选的仿真代码仓；覆盖 --code-repo")
    parser.add_argument("--real-code-ref", default="", help="可选的真机 commit/tag/branch；覆盖 --code-ref")
    parser.add_argument("--sim-code-ref", default="", help="可选的仿真 commit/tag/branch；覆盖 --code-ref")
    parser.add_argument("--skip-extraction", action="store_true", help="复用 output/extracted 下已有的 real/sim 摘要")
    args = parser.parse_args()

    try:
        real_root, sim_root, output = resolve_roots(args.real, args.sim, args.output)
    except ValueError as exc:
        parser.error(str(exc))
    if args.top <= 0:
        parser.error("--top 必须为正数")

    analyzer = Path(__file__).with_name("summarize_ascend_profile.py")
    if not analyzer.is_file():
        parser.error(f"缺少内置单环境分析器：{analyzer}")
    real_extracted = output / "extracted" / "real"
    sim_extracted = output / "extracted" / "sim"
    output.mkdir(parents=True, exist_ok=True)
    if not args.skip_extraction:
        run_analyzer(analyzer, real_root, real_extracted, args.top)
        run_analyzer(analyzer, sim_root, sim_extracted, args.top)
    for role, path in (("真机", real_extracted), ("仿真", sim_extracted)):
        if not (path / "summary.json").exists():
            parser.error(f"{role}抽取结果不存在：{path}；请移除 --skip-extraction 或先生成摘要")
        try:
            validate_comparison_extraction(path, role)
        except ValueError as exc:
            parser.error(str(exc))

    gates = topology_gates(real_extracted, sim_extracted)
    rank_alignment = rank_alignment_rows(real_extracted, sim_extracted)
    input_rows = profile_inputs(args)
    input_gates = compare_profile_inputs(input_rows)
    for row in input_gates:
        row["gate"] = "explicit_pair_input"
        row["impact"] = "不一致或未确认时不能解释时间保真度"
    coverage, coverage_mismatch, coverage_missing_both = coverage_gates(real_extracted, sim_extracted)
    timing_allowed = timing_gate(
        gates,
        input_gates,
        coverage_mismatch,
        coverage_missing_both,
    )
    source_bindings = source_binding_rows(args)

    pytorch_metrics = [
        "calls",
        "host_self_us_total",
        "host_total_us_total",
        "device_self_us_total",
        "device_total_us_total",
        "device_aicore_self_us_total",
        "host_self_us_per_call",
        "device_self_us_per_call",
    ]
    pytorch_text = ["operator_family", "call_stack_id", "call_stack_sample"]
    real_pytorch = aggregate_rows(
        collect_rank_csv(real_extracted, "pytorch_operator_shapes.csv"),
        pytorch_key,
        pytorch_metrics,
        pytorch_text,
    )
    sim_pytorch = aggregate_rows(
        collect_rank_csv(sim_extracted, "pytorch_operator_shapes.csv"),
        pytorch_key,
        pytorch_metrics,
        pytorch_text,
    )
    for grouped in (real_pytorch, sim_pytorch):
        add_per_call_metric(grouped, "host_self_us_total", "host_self_us_per_call")
        add_per_call_metric(grouped, "device_self_us_total", "device_self_us_per_call")
    pytorch = compare_grouped(real_pytorch, sim_pytorch, ["rank_alignment_key", "operator", "input_shapes"], pytorch_metrics, pytorch_text, timing_allowed)
    add_effect_decomposition(pytorch, "device_self_us_total", "device_self_us_per_call")
    add_effect_decomposition(pytorch, "host_self_us_total", "host_self_us_per_call")

    device_metrics = [
        "calls",
        "duration_us_total",
        "duration_us_per_call",
        "duration_us_max",
        "wait_us_total",
    ]
    real_device = aggregate_rows(
        collect_rank_csv(real_extracted, "device_operator_shapes.csv"),
        device_key,
        device_metrics,
        [],
    )
    sim_device = aggregate_rows(
        collect_rank_csv(sim_extracted, "device_operator_shapes.csv"),
        device_key,
        device_metrics,
        [],
    )
    for grouped in (real_device, sim_device):
        add_per_call_metric(grouped, "duration_us_total", "duration_us_per_call")
    device = compare_grouped(
        real_device,
        sim_device,
        [
            "rank_alignment_key",
            "operator",
            "type",
            "input_shapes",
            "output_shapes",
            "input_dtypes",
            "output_dtypes",
            "accelerator_core",
            "input_formats",
            "output_formats",
        ],
        device_metrics,
        [],
        timing_allowed,
    )
    add_effect_decomposition(device, "duration_us_total", "duration_us_per_call")

    real_communication_kernels = aggregate_rows(
        collect_rank_csv(real_extracted, "communication_kernel_shapes.csv"),
        device_key,
        device_metrics,
        ["steps"],
    )
    sim_communication_kernels = aggregate_rows(
        collect_rank_csv(sim_extracted, "communication_kernel_shapes.csv"),
        device_key,
        device_metrics,
        ["steps"],
    )
    for grouped in (real_communication_kernels, sim_communication_kernels):
        add_per_call_metric(grouped, "duration_us_total", "duration_us_per_call")
    communication_kernels = compare_grouped(
        real_communication_kernels,
        sim_communication_kernels,
        [
            "rank_alignment_key",
            "operator",
            "type",
            "input_shapes",
            "output_shapes",
            "input_dtypes",
            "output_dtypes",
            "accelerator_core",
            "input_formats",
            "output_formats",
        ],
        device_metrics,
        ["steps"],
        timing_allowed,
    )
    add_effect_decomposition(communication_kernels, "duration_us_total", "duration_us_per_call")

    comm_metrics = [
        "calls",
        "wait_ms_total",
        "synchronization_ms_total",
        "transit_ms_total",
        "transit_size_mb_total",
        "weighted_bandwidth_gb_s",
        "wait_ms_per_call",
        "transit_ms_per_call",
        "transit_size_mb_per_call",
    ]
    real_comm_rows = collect_rank_csv(real_extracted, "communication_summary.csv")
    sim_comm_rows = collect_rank_csv(sim_extracted, "communication_summary.csv")
    real_comm = aggregate_rows(real_comm_rows, communication_key, comm_metrics, ["steps"])
    sim_comm = aggregate_rows(sim_comm_rows, communication_key, comm_metrics, ["steps"])
    for grouped in (real_comm, sim_comm):
        add_per_call_metric(grouped, "wait_ms_total", "wait_ms_per_call")
        add_per_call_metric(grouped, "transit_ms_total", "transit_ms_per_call")
        add_per_call_metric(grouped, "transit_size_mb_total", "transit_size_mb_per_call")
    communication = compare_grouped(real_comm, sim_comm, ["rank_alignment_key", "category", "collective_type", "communication_group", "parallel_axis"], comm_metrics, ["steps"], timing_allowed)
    add_effect_decomposition(communication, "transit_ms_total", "transit_ms_per_call")
    add_effect_decomposition(communication, "wait_ms_total", "wait_ms_per_call")

    link_metrics = ["transit_ms", "transit_size_mb", "bandwidth_gb_s"]
    real_links = aggregate_rows(
        collect_rank_csv(real_extracted, "communication_matrix_links.csv"),
        communication_link_key,
        link_metrics,
        ["transport_type", "source_op_name"],
    )
    sim_links = aggregate_rows(
        collect_rank_csv(sim_extracted, "communication_matrix_links.csv"),
        communication_link_key,
        link_metrics,
        ["transport_type", "source_op_name"],
    )
    communication_links = compare_grouped(
        real_links,
        sim_links,
        [
            "rank_alignment_key",
            "category",
            "collective_type",
            "communication_group",
            "parallel_axis",
            "link",
        ],
        link_metrics,
        ["transport_type", "source_op_name"],
        timing_allowed,
    )

    step_metrics = ["computing_us", "communication_us", "communication_not_overlapped_us", "overlapped_us", "free_us", "stage_us", "bubble_us", "preparing_us"]
    real_step_rows = step_rows_with_ordinal(read_csv(real_extracted / "step_trace_all_ranks.csv"))
    sim_step_rows = step_rows_with_ordinal(read_csv(sim_extracted / "step_trace_all_ranks.csv"))
    real_step = aggregate_rows(real_step_rows, step_key, step_metrics, ["step"])
    sim_step = aggregate_rows(sim_step_rows, step_key, step_metrics, ["step"])
    step = compare_grouped(real_step, sim_step, ["rank_alignment_key", "step_ordinal"], step_metrics, ["step"], timing_allowed)
    window_alignment = [
        {
            "rank_alignment_key": row.get("rank_alignment_key", ""),
            "step_ordinal": row.get("step_ordinal", ""),
            "presence": row.get("presence", ""),
            "real_step": row.get("real_step", "[]"),
            "sim_step": row.get("sim_step", "[]"),
            "alignment_method": "同 rank 内语义阶段确认后按 ordinal；当前脚本只给候选",
            "timing_interpretation_allowed": timing_allowed,
        }
        for row in step
    ]

    memory_metrics = ["max_allocated_mb", "max_reserved_mb", "max_active_mb"]
    real_memory = aggregate_rows(read_csv(real_extracted / "memory_peaks_all_ranks.csv"), memory_key, memory_metrics, ["device_type"])
    sim_memory = aggregate_rows(read_csv(sim_extracted / "memory_peaks_all_ranks.csv"), memory_key, memory_metrics, ["device_type"])
    memory = compare_grouped(
        real_memory,
        sim_memory,
        ["rank_alignment_key", "component", "device_type"],
        memory_metrics,
        [],
        timing_allowed,
    )

    comparison_dir = output / "comparison"
    write_csv(comparison_dir / "comparability_gates.csv", gates + input_gates)
    write_csv(comparison_dir / "rank_alignment.csv", rank_alignment)
    write_csv(comparison_dir / "window_alignment.csv", window_alignment)
    write_csv(comparison_dir / "coverage_comparison.csv", coverage)
    write_csv(comparison_dir / "source_bindings.csv", source_bindings)
    write_csv(comparison_dir / "pytorch_operator_comparison.csv", pytorch)
    write_csv(comparison_dir / "device_operator_comparison.csv", device)
    write_csv(comparison_dir / "communication_kernel_comparison.csv", communication_kernels)
    write_csv(comparison_dir / "communication_comparison.csv", communication)
    write_csv(comparison_dir / "communication_link_comparison.csv", communication_links)
    write_csv(comparison_dir / "step_comparison.csv", step)
    write_csv(comparison_dir / "memory_comparison.csv", memory)

    unmatched = []
    for dimension, rows in (
        ("pytorch", pytorch),
        ("device", device),
        ("communication_kernel", communication_kernels),
        ("communication", communication),
        ("communication_link", communication_links),
        ("step", step),
        ("memory", memory),
    ):
        for row in rows:
            if row.get("presence") != "两侧存在":
                unmatched.append({"dimension": dimension, **row})
    write_csv(comparison_dir / "unmatched_entities.csv", unmatched)

    summaries = [
        mismatch_summary("PyTorch operator", pytorch),
        mismatch_summary("device operator", device),
        mismatch_summary("communication kernel", communication_kernels),
        mismatch_summary("communication", communication),
        mismatch_summary("communication link", communication_links),
        mismatch_summary("step", step),
        mismatch_summary("memory", memory),
    ]
    manifest = {
        "schema_version": 1,
        "language": "zh-CN",
        "roles": {"real": "reference/真机", "sim": "candidate/仿真"},
        "difference_direction": "sim - real",
        "ratio_direction": "sim / real",
        "real_root": str(real_root),
        "sim_root": str(sim_root),
        "real_extracted": str(real_extracted),
        "sim_extracted": str(sim_extracted),
        "timing_interpretation_allowed": timing_allowed,
        "explicit_pair_inputs": input_rows,
        "source_bindings": source_bindings,
        "summary": summaries,
    }
    write_csv(comparison_dir / "comparison_summary.csv", summaries)
    write_csv(
        comparison_dir / "comparison_manifest.csv",
        [
            {
                "environment": "real/reference/真机",
                "profiling_root": str(real_root),
                "extracted_root": str(real_extracted),
                "difference_direction": "sim - real",
                "ratio_direction": "sim / real",
                "timing_interpretation_allowed": timing_allowed,
            },
            {
                "environment": "sim/candidate/仿真",
                "profiling_root": str(sim_root),
                "extracted_root": str(sim_extracted),
                "difference_direction": "sim - real",
                "ratio_direction": "sim / real",
                "timing_interpretation_allowed": timing_allowed,
            },
        ],
    )
    write_json(comparison_dir / "comparison_manifest.json", manifest)
    write_json(
        comparison_dir / "comparison_summary.json",
        {
            "gates": gates + input_gates,
            "coverage_primary_mismatches": coverage_mismatch,
            "coverage_primary_missing_on_both": coverage_missing_both,
            "dimensions": summaries,
        },
    )
    (comparison_dir / "comparison_summary.md").write_text(
        build_summary(
            real_root,
            sim_root,
            gates,
            input_gates,
            coverage_mismatch,
            timing_allowed,
            summaries,
            pytorch,
            device,
            communication,
            step,
            source_bindings,
        ),
        encoding="utf-8",
    )

    print(f"完成：真机(reference)={real_root}")
    print(f"完成：仿真(candidate)={sim_root}")
    print(f"时间比率解释：{timing_allowed}")
    print(f"请先阅读：{comparison_dir / 'comparison_summary.md'}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

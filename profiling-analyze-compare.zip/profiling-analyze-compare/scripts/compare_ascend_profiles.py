#!/usr/bin/env python3
"""对比显式标注的真机与仿真 Ascend/PyTorch Profiling。

真机固定作为 reference，仿真固定作为 candidate。脚本先调用同目录下沿用自
analyze-ascend-profiling 的流式汇总器，再按拓扑坐标、算子语义和 Shape 生成紧凑
对比证据。所有差值方向均为“仿真 - 真机”，所有比率均为“仿真 / 真机”。
"""

from __future__ import annotations

import argparse
import ast
import csv
import hashlib
import html
import json
import math
import os
import re
import shutil
import subprocess
import sys
import time
from collections import defaultdict
from dataclasses import asdict
from pathlib import Path
from typing import Any, Callable, Iterable
from urllib.parse import urlsplit, urlunsplit


UNKNOWN = {"", "未知", "unknown", "none", "null", "n/a", "na", "?"}
PARALLEL_FIELDS = ["dp", "tp", "ep", "pp", "cp", "dcp"]
COORD_FIELDS = [*PARALLEL_FIELDS, "global_rank"]
SELECTED_RANK_PAIR_ID = "selected-rank-pair"
PRIMARY_FILES = {
    "operator_details.csv",
    "kernel_details.csv",
    "communication.json",
    "communication_matrix.json",
    "step_trace_time.csv",
    "trace_view.json",
}
RANK_IN_LINK_PATTERN = re.compile(r"\d+")

COMPARISON_RANK_FIELDS = [
    "rank_pair_id",
    "real_rank",
    "sim_rank",
    "real_global_rank",
    "sim_global_rank",
    *[name for axis in PARALLEL_FIELDS for name in (f"real_{axis}", f"sim_{axis}")],
    "real_parallel_coordinate",
    "sim_parallel_coordinate",
    "parallel_coordinate_pair",
]


def utf8_child_environment() -> dict[str, str]:
    """Force Python child evidence to stay UTF-8 even when stdout is a Windows pipe."""
    environment = os.environ.copy()
    environment["PYTHONIOENCODING"] = "utf-8"
    environment["PYTHONUTF8"] = "1"
    return environment


def comparison_csv_schema(
    key_fields: list[str],
    metric_fields: list[str],
    text_fields: list[str] | None = None,
    effect_fields: list[str] | None = None,
) -> list[str]:
    """Return a stable schema even when a comparison domain has no rows."""
    fields = [
        *key_fields,
        "presence",
        "timing_interpretation_allowed",
        "real_records",
        "sim_records",
        "record_count_match",
        "real_evidence",
        "sim_evidence",
    ]
    for metric in metric_fields:
        fields.extend(
            [
                f"real_{metric}",
                f"sim_{metric}",
                f"real_{metric}_observed_records",
                f"real_{metric}_missing_records",
                f"sim_{metric}_observed_records",
                f"sim_{metric}_missing_records",
                f"{metric}_sim_minus_real",
                f"{metric}_sim_over_real",
                f"{metric}_delta_percent",
            ]
        )
    for field in text_fields or []:
        fields.extend([f"real_{field}", f"sim_{field}", f"{field}_match"])
    fields.extend(effect_fields or [])
    fields.extend(COMPARISON_RANK_FIELDS)
    # Preserve order while guarding against key/annotation aliases.
    return list(dict.fromkeys(fields))


PYTORCH_METRICS = [
    "calls",
    "host_self_us_total",
    "host_total_us_total",
    "device_self_us_total",
    "device_total_us_total",
    "device_aicore_self_us_total",
    "host_self_us_per_call",
    "device_self_us_per_call",
]
DEVICE_METRICS = ["calls", "duration_us_total", "duration_us_per_call", "duration_us_max", "wait_us_total"]
COMMUNICATION_METRICS = [
    "calls",
    "wait_ms_total",
    "synchronization_ms_total",
    "transit_ms_total",
    "transit_size_mb_total",
    "weighted_bandwidth_gb_s",
    "wait_ms_per_call",
    "transit_ms_per_call",
    "transit_size_mb_per_call",
]
STEP_METRICS = [
    "computing_us",
    "communication_us",
    "communication_not_overlapped_us",
    "overlapped_us",
    "free_us",
    "stage_us",
    "bubble_us",
    "preparing_us",
]
MEMORY_METRICS = ["max_allocated_mb", "max_reserved_mb", "max_active_mb"]

DEVICE_KEY_FIELDS = [
    "rank_alignment_key",
    "operator",
    "type",
    "input_shapes",
    "output_shapes",
    "input_dtypes",
    "output_dtypes",
    "accelerator_core",
    "input_formats",
    "output_formats",
]

EMPTY_CSV_SCHEMAS = {
    "pytorch_operator_comparison.csv": comparison_csv_schema(
        ["rank_alignment_key", "operator", "input_shapes"],
        PYTORCH_METRICS,
        ["operator_family", "call_stack_id", "call_stack_sample"],
        [
            "device_self_us_total_volume_effect",
            "device_self_us_total_unit_cost_effect",
            "host_self_us_total_volume_effect",
            "host_self_us_total_unit_cost_effect",
        ],
    ),
    "device_operator_comparison.csv": comparison_csv_schema(
        DEVICE_KEY_FIELDS,
        DEVICE_METRICS,
        effect_fields=["duration_us_total_volume_effect", "duration_us_total_unit_cost_effect"],
    ),
    "communication_kernel_comparison.csv": comparison_csv_schema(
        DEVICE_KEY_FIELDS,
        DEVICE_METRICS,
        ["steps"],
        ["duration_us_total_volume_effect", "duration_us_total_unit_cost_effect"],
    ),
    "communication_comparison.csv": comparison_csv_schema(
        ["rank_alignment_key", "category", "collective_type", "communication_group", "parallel_axis"],
        COMMUNICATION_METRICS,
        ["steps"],
        [
            "transit_ms_total_volume_effect",
            "transit_ms_total_unit_cost_effect",
            "wait_ms_total_volume_effect",
            "wait_ms_total_unit_cost_effect",
        ],
    ),
    "communication_collective_comparison.csv": comparison_csv_schema(
        ["rank_alignment_key", "category", "collective_type", "parallel_axis"],
        COMMUNICATION_METRICS,
        ["communication_group", "steps"],
        [
            "transit_ms_total_volume_effect",
            "transit_ms_total_unit_cost_effect",
            "wait_ms_total_volume_effect",
            "wait_ms_total_unit_cost_effect",
        ],
    ),
    "communication_link_comparison.csv": comparison_csv_schema(
        ["rank_alignment_key", "category", "collective_type", "communication_group", "parallel_axis", "link"],
        ["transit_ms", "transit_size_mb", "bandwidth_gb_s"],
        ["transport_type", "source_op_name"],
    ),
    "step_comparison.csv": comparison_csv_schema(
        ["rank_alignment_key", "step_ordinal"], STEP_METRICS, ["step"]
    ),
    "memory_comparison.csv": comparison_csv_schema(
        ["rank_alignment_key", "component", "device_type"], MEMORY_METRICS
    ),
    "window_alignment.csv": [
        "rank_alignment_key",
        "step_ordinal",
        "presence",
        "real_step",
        "sim_step",
        "alignment_method",
        "timing_interpretation_allowed",
        *COMPARISON_RANK_FIELDS,
    ],
    "unmatched_entities.csv": [
        "dimension",
        "rank_alignment_key",
        "operator",
        "input_shapes",
        "output_shapes",
        "category",
        "collective_type",
        "communication_group",
        "parallel_axis",
        "component",
        "device_type",
        "presence",
        *COMPARISON_RANK_FIELDS,
    ],
}


def clean(value: Any, limit: int = 2000) -> str:
    text = "" if value is None else str(value).strip()
    text = re.sub(r"\s+", " ", text)
    return text if len(text) <= limit else text[: limit - 3] + "..."


def number(value: Any) -> float | None:
    text = clean(value).replace(",", "").rstrip("%")
    if text.lower() in UNKNOWN:
        return None
    try:
        result = float(text)
        return result if math.isfinite(result) else None
    except ValueError:
        return None


def write_csv(path: Path, rows: Iterable[dict[str, Any]], fields: list[str] | None = None) -> None:
    materialized = list(rows)
    path.parent.mkdir(parents=True, exist_ok=True)
    if fields is None:
        fields = []
        seen: set[str] = set()
        for row in materialized:
            for key in row:
                if key not in seen:
                    seen.add(key)
                    fields.append(key)
        if not fields:
            fields = EMPTY_CSV_SCHEMAS.get(path.name, ["message"])
    with path.open("w", newline="", encoding="utf-8-sig") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields, extrasaction="ignore")
        writer.writeheader()
        writer.writerows(materialized)


def write_json(path: Path, value: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8") as handle:
        json.dump(value, handle, ensure_ascii=False, indent=2)


def read_csv(path: Path) -> list[dict[str, str]]:
    if not path.exists():
        return []
    with path.open("r", newline="", encoding="utf-8-sig", errors="replace") as handle:
        rows: list[dict[str, str]] = []
        for line_number, row in enumerate(csv.DictReader(handle), start=2):
            materialized = dict(row)
            materialized["_evidence"] = f"{path}:{line_number}"
            rows.append(materialized)
        return rows


def read_json(path: Path, default: Any) -> Any:
    if not path.exists():
        return default
    with path.open("r", encoding="utf-8-sig", errors="replace") as handle:
        return json.load(handle)


def norm(value: Any) -> str:
    text = clean(value)
    # Some launchers accidentally serialize scalar metadata as singleton
    # Python/JSON containers, e.g. ``("未知")`` or ``["10"]``.  Normalize the
    # former without flattening genuine multi-valued fields.
    candidate: Any = text
    for _ in range(3):
        try:
            parsed = ast.literal_eval(str(candidate))
        except (ValueError, SyntaxError, MemoryError, RecursionError):
            break
        if isinstance(parsed, (list, tuple)) and len(parsed) == 1:
            candidate = parsed[0]
            continue
        if isinstance(parsed, str):
            candidate = parsed
        break
    normalized = clean(candidate)
    return "未知" if normalized.lower() in UNKNOWN else normalized


def known_parallel_axis(value: Any) -> str:
    """Return a canonical DP/TP/... axis, or literal ``未知``.

    Verbose placeholders such as "未知（需结合 group 成员）" are not evidence
    and must never be counted as inferred axes.
    """
    text = norm(value).upper().replace("，", ",").replace(" ", "")
    if text == "未知" or text.startswith(("未知", "待确认", "待全局")):
        return "未知"
    tokens = [token for token in re.split(r"[,+]", text) if token]
    allowed = {field.upper() for field in PARALLEL_FIELDS}
    if not tokens or any(token not in allowed for token in tokens):
        return "未知"
    return "+".join(dict.fromkeys(tokens))


def coordinate_key(row: dict[str, Any], include_global_rank: bool = True) -> str:
    fields = COORD_FIELDS if include_global_rank else PARALLEL_FIELDS
    values = [f"{field}={norm(row.get(field))}" for field in fields]
    return "|".join(values)


def rank_key(row: dict[str, Any]) -> str:
    """Return the common join key for the one selected rank pair.

    Raw rank ids are intentionally excluded: real and simulation exports may use
    different global-rank numbering for the same semantic parallel coordinate.
    """
    explicit = clean(row.get("rank_pair_id") or row.get("rank_alignment_key"))
    if explicit:
        return explicit
    return SELECTED_RANK_PAIR_ID


def display_rank(row: dict[str, Any]) -> str:
    return clean(row.get("rank")) or rank_key(row)


def shape_text(value: Any) -> str:
    text = clean(value, 5000)
    if text.startswith("未知"):
        return "未知"
    try:
        parsed = ast.literal_eval(text)
        if isinstance(parsed, (list, tuple, dict, int, float, str, type(None))):
            return json.dumps(parsed, ensure_ascii=False, separators=(",", ":"))
    except (ValueError, SyntaxError, MemoryError, RecursionError):
        pass
    return re.sub(r"\s+", "", text)


def collect_rank_csv(extracted: Path, filename: str) -> list[dict[str, str]]:
    rows: list[dict[str, str]] = []
    for path in sorted(extracted.glob(f"*/{filename}")):
        rows.extend(read_csv(path))
    return rows


def topology_rank_map(candidates: list[dict[str, Any]]) -> dict[int, dict[str, Any]]:
    result: dict[int, dict[str, Any]] = {}
    for row in candidates:
        value = number(row.get("global_rank"))
        if value is None or not value.is_integer():
            continue
        result[int(value)] = row
    return result


def infer_parallel_axis_from_full_topology(
    row: dict[str, Any], ranks: dict[int, dict[str, Any]]
) -> str:
    current_value = number(row.get("global_rank"))
    if current_value is None or not current_value.is_integer():
        return "未知"
    current = int(current_value)
    peer_text = clean(row.get("peer_ranks")) or clean(row.get("link"))
    peer_ids = sorted(
        {
            int(value)
            for value in RANK_IN_LINK_PATTERN.findall(peer_text)
            if int(value) != current
        }
    )
    if not peer_ids or current not in ranks:
        return "未知"
    axes: set[str] = set()
    current_info = ranks[current]
    for peer in peer_ids:
        peer_info = ranks.get(peer)
        if not peer_info:
            continue
        changed = []
        for field in PARALLEL_FIELDS:
            left = clean(current_info.get(field)).lower()
            right = clean(peer_info.get(field)).lower()
            if left in UNKNOWN or right in UNKNOWN:
                continue
            if left != right:
                changed.append(field.upper())
        if len(changed) == 1:
            axes.add(changed[0])
        elif changed:
            axes.add("+".join(changed))
    return ",".join(sorted(axes)) if axes else "未知"


def collapse_parallel_axes(values: Iterable[str]) -> str:
    axes = {axis for value in values if (axis := known_parallel_axis(value)) != "未知"}
    return ",".join(sorted(axes)) if axes else "未知"


def enrich_selected_rank_communication_axes(
    extracted: Path,
    rank_candidates: list[dict[str, Any]],
    environment: str,
) -> dict[str, Any]:
    """Use only full-topology metadata to label the selected rank's communication rows."""
    ranks = topology_rank_map(rank_candidates)
    matrix_paths = sorted(extracted.glob("*/communication_matrix_links.csv"))
    matrix_rows: list[dict[str, Any]] = []
    exact_axes: dict[tuple[str, str, str, str], set[str]] = defaultdict(set)
    group_axes: dict[tuple[str, str, str], set[str]] = defaultdict(set)
    for path in matrix_paths:
        rows = read_csv(path)
        for row in rows:
            row.pop("_evidence", None)
            axis = infer_parallel_axis_from_full_topology(row, ranks)
            row["parallel_axis"] = axis
            row["parallel_axis_source"] = (
                "communication_matrix link + full_topology_context metadata"
                if axis != "未知"
                else "未知：peer 或 DP/TP/EP/PP/CP/DCP 坐标不完整"
            )
            matrix_rows.append(row)
            if axis == "未知":
                continue
            base = (
                clean(row.get("category")),
                clean(row.get("collective_type")),
                clean(row.get("communication_group")),
            )
            exact_axes[(*base, clean(row.get("step")))].add(axis)
            group_axes[base].add(axis)
        write_csv(path, rows)

    if matrix_rows:
        write_csv(extracted / "communication_matrix_all_ranks.csv", matrix_rows)

    def annotate_rows(path: Path, step_specific: bool) -> list[dict[str, Any]]:
        rows = read_csv(path)
        for row in rows:
            row.pop("_evidence", None)
            base = (
                clean(row.get("category")),
                clean(row.get("collective_type")),
                clean(row.get("communication_group")),
            )
            axes = (
                exact_axes.get((*base, clean(row.get("step"))), set())
                if step_specific
                else group_axes.get(base, set())
            )
            if not axes:
                axes = group_axes.get(base, set())
            axis = collapse_parallel_axes(axes)
            if known_parallel_axis(axis) != "未知":
                row["parallel_axis"] = axis
                row["parallel_axis_source"] = "communication_matrix link + full_topology_context metadata"
            else:
                row["parallel_axis"] = "未知"
                row["parallel_axis_source"] = "未知：无可对齐 matrix link/拓扑证据"
        if rows:
            write_csv(path, rows)
        return rows

    operation_rows: list[dict[str, Any]] = []
    summary_rows: list[dict[str, Any]] = []
    for path in sorted(extracted.glob("*/communication_ops.csv")):
        operation_rows.extend(annotate_rows(path, step_specific=True))
    for path in sorted(extracted.glob("*/communication_summary.csv")):
        summary_rows.extend(annotate_rows(path, step_specific=False))
    if operation_rows:
        write_csv(extracted / "communication_ops_all_ranks.csv", operation_rows)

    inferred_links = sum(known_parallel_axis(row.get("parallel_axis")) != "未知" for row in matrix_rows)
    inferred_operations = sum(
        known_parallel_axis(row.get("parallel_axis")) != "未知" for row in operation_rows
    )
    inferred_summaries = sum(
        known_parallel_axis(row.get("parallel_axis")) != "未知" for row in summary_rows
    )
    status = {
        "environment": environment,
        "status": "完成" if matrix_rows and inferred_links > 0 else "受限",
        "rank_metadata_candidates": len(rank_candidates),
        "rank_coordinates_indexed": len(ranks),
        "selected_rank_matrix_links": len(matrix_rows),
        "matrix_links_with_inferred_axis": inferred_links,
        "communication_ops_with_inferred_axis": inferred_operations,
        "communication_summaries_with_inferred_axis": inferred_summaries,
        "scope": "只读取其它 Rank 的目录坐标 metadata；不读取或聚合其性能明细",
        "limitation": "缺 communication_matrix link、peer global rank 或完整并行坐标时保持未知",
    }
    write_json(extracted / "communication_axis_enrichment.json", status)
    return status


def validate_comparison_extraction(extracted: Path, role: str) -> None:
    summary = read_json(extracted / "summary.json", {})
    if not isinstance(summary, dict) or summary.get("numeric_missing_semantics") != "strict-null-v1":
        raise ValueError(
            f"{role}摘要未声明 strict-null-v1 数值缺失语义；请移除 --skip-extraction 重新抽取"
        )
    ranks = summary.get("ranks", []) if isinstance(summary, dict) else []
    if not isinstance(ranks, list) or not ranks:
        raise ValueError(f"{role}摘要没有 rank 数据：{extracted / 'summary.json'}")
    if len(ranks) != 1:
        raise ValueError(
            f"{role}摘要包含 {len(ranks)} 个 Rank；当前 skill 强制单 Rank，请移除 --skip-extraction 重新抽取"
        )
    for rank in ranks:
        if not isinstance(rank, dict):
            continue
        for domain in ("pytorch_operator", "device_operator"):
            data = rank.get(domain)
            if isinstance(data, dict) and not data.get("comparison_full_signatures_written"):
                raise ValueError(
                    f"{role}摘要来自旧版/截断抽取，缺少 {domain} 全量签名；请移除 --skip-extraction 重新抽取"
                )


def paths_overlap(left: Path, right: Path) -> bool:
    left_resolved = left.resolve(strict=False)
    right_resolved = right.resolve(strict=False)
    return (
        left_resolved == right_resolved
        or left_resolved in right_resolved.parents
        or right_resolved in left_resolved.parents
    )


def remove_generated_tree(path: Path, allowed_parent: Path) -> None:
    """Remove one known generated directory without following links outside it."""
    if not path.exists():
        return
    if path.is_symlink():
        raise ValueError(f"拒绝清理符号链接形式的派生目录：{path}")
    resolved = path.resolve(strict=True)
    parent = allowed_parent.resolve(strict=True)
    if resolved == parent or parent not in resolved.parents:
        raise ValueError(f"拒绝清理允许范围之外的派生目录：{resolved}")
    shutil.rmtree(resolved)


def resolve_roots(real: Path, sim: Path, output: Path) -> tuple[Path, Path, Path]:
    real = real.resolve()
    sim = sim.resolve()
    output = output.resolve()
    for role, root in (("真机", real), ("仿真", sim)):
        if not root.exists() or not root.is_dir():
            raise ValueError(f"{role} Profiling 目录不存在：{root}")
    if paths_overlap(real, sim):
        raise ValueError("真机与仿真 Profiling 目录不得相同或互为祖先；请显式提供两个独立产物")
    for role, root in (("真机", real), ("仿真", sim)):
        if paths_overlap(output, root):
            raise ValueError(f"输出目录与{role} Profiling 根目录不得相同或互为祖先")
    return real, sim, output


def validate_code_output_separation(bindings: list[dict[str, str]], output: Path) -> None:
    for binding in bindings:
        locator = clean(binding.get("repository_url_or_path"), 8000) or clean(binding.get("subpath"), 8000)
        if not locator or urlsplit(locator).scheme.lower() in {"http", "https"}:
            continue
        candidate = Path(locator).resolve(strict=False)
        repo_root = find_local_repo_root(candidate)
        if paths_overlap(output, repo_root):
            raise ValueError(
                f"输出目录与本地源码仓不得相同或互为祖先：{output} <-> {repo_root}；"
                "请把对比输出放到源码仓之外"
            )


def discover_rank_candidates(root: Path, environment: str) -> list[dict[str, Any]]:
    """Lightly inventory rank exports without parsing their large payloads."""
    from summarize_ascend_profile import discover_outputs, rank_info

    rows: list[dict[str, Any]] = []
    for index, path in enumerate(discover_outputs(root)):
        info = rank_info(path)
        row = {
            "environment": environment,
            "candidate_index": index,
            "source": str(path.resolve()),
            **asdict(info),
            **info.annotation(),
        }
        row["coordinate_key"] = coordinate_key(row, include_global_rank=False)
        rows.append(row)
    if not rows:
        raise ValueError(f"{environment} 未找到 ASCEND_PROFILER_OUTPUT：{root}")
    return rows


def rank_selector_matches(row: dict[str, Any], selector: str) -> bool:
    wanted = clean(selector).casefold()
    if not wanted:
        return True
    source = Path(str(row.get("source", "")))
    aliases = {
        clean(row.get("rank_label")).casefold(),
        clean(row.get("rank")).casefold(),
        clean(row.get("global_rank")).casefold(),
        f"rank{clean(row.get('global_rank'))}".casefold(),
        source.name.casefold(),
        source.parent.name.casefold(),
        str(source).casefold(),
    }
    return wanted in aliases or str(source).casefold().endswith(wanted)


def filter_rank_candidates(
    rows: list[dict[str, Any]], selector: str, role: str
) -> list[dict[str, Any]]:
    if not clean(selector):
        return rows
    matches = [row for row in rows if rank_selector_matches(row, selector)]
    if not matches:
        raise ValueError(f"{role} rank 选择器未匹配任何导出：{selector}")
    if len(matches) > 1:
        choices = ", ".join(str(row.get("source")) for row in matches[:8])
        raise ValueError(f"{role} rank 选择器不唯一：{selector}；候选：{choices}")
    return matches


def rank_pair_score(real: dict[str, Any], sim: dict[str, Any]) -> tuple[Any, ...]:
    conflicts = 0
    matches = 0
    known = 0
    for field in PARALLEL_FIELDS:
        left = real.get(field)
        right = sim.get(field)
        if left is None or right is None or str(left) in UNKNOWN or str(right) in UNKNOWN:
            continue
        known += 1
        if str(left) == str(right):
            matches += 1
        else:
            conflicts += 1
    left_global = clean(real.get("global_rank"))
    right_global = clean(sim.get("global_rank"))
    same_global = (
        left_global.lower() not in UNKNOWN
        and right_global.lower() not in UNKNOWN
        and left_global == right_global
    )
    # Lower is better. Parallel-coordinate agreement outranks global-rank identity.
    return (
        conflicts,
        -matches,
        -known,
        0 if same_global else 1,
        str(real.get("source", "")).casefold(),
        str(sim.get("source", "")).casefold(),
    )


def select_rank_pair(
    real_rows: list[dict[str, Any]],
    sim_rows: list[dict[str, Any]],
    real_selector: str,
    sim_selector: str,
) -> dict[str, Any]:
    real_pool = filter_rank_candidates(real_rows, real_selector, "真机")
    sim_pool = filter_rank_candidates(sim_rows, sim_selector, "仿真")
    candidates = [(rank_pair_score(left, right), left, right) for left in real_pool for right in sim_pool]
    score, real, sim = min(candidates, key=lambda item: item[0])
    conflicts, neg_matches, neg_known, global_penalty, *_ = score
    matches = -int(neg_matches)
    known = -int(neg_known)
    if real_selector or sim_selector:
        method = "用户 rank 选择器约束后按并行坐标确定性配对"
    else:
        method = "按 DP/TP/EP/PP/CP/DCP 一致性确定性选择一个可比 Rank"
    if conflicts:
        confidence = "低"
    elif known == len(PARALLEL_FIELDS):
        confidence = "高"
    elif known:
        confidence = "中"
    elif len(real_rows) == len(sim_rows) == 1:
        confidence = "低（双方仅一个候选）"
    else:
        confidence = "低（并行坐标缺失）"
    digest = hashlib.sha256(
        f"{real.get('source')}\n{sim.get('source')}".encode("utf-8", errors="replace")
    ).hexdigest()[:12]
    return {
        "rank_pair_id": SELECTED_RANK_PAIR_ID,
        "selection_fingerprint": f"rank-pair-{digest}",
        "selection_method": method,
        "confidence": confidence,
        "parallel_fields_known_on_both": known,
        "parallel_fields_matched": matches,
        "parallel_field_conflicts": int(conflicts),
        "global_rank_match": "是" if not global_penalty else "否",
        "real_candidate_count": len(real_rows),
        "sim_candidate_count": len(sim_rows),
        "real_selector": clean(real_selector),
        "sim_selector": clean(sim_selector),
        "real": real,
        "sim": sim,
    }


def rank_pair_csv_row(selection: dict[str, Any]) -> dict[str, Any]:
    left = selection["real"]
    right = selection["sim"]
    row: dict[str, Any] = {
        key: value for key, value in selection.items() if key not in {"real", "sim"}
    }
    for prefix, source in (("real", left), ("sim", right)):
        for field in ["rank", "rank_label", "source", "global_rank", "device", *PARALLEL_FIELDS, "parallel_coordinate"]:
            row[f"{prefix}_{field}"] = source.get(field, "未知")
    return row


def run_analyzer(script: Path, source: Path, destination: Path, top_n: int) -> None:
    source = source.resolve(strict=True)
    destination = destination.resolve(strict=False)
    if paths_overlap(source, destination):
        raise RuntimeError(f"拒绝清理与原始 Rank 重叠的抽取目录：{destination} <-> {source}")
    if destination.exists():
        try:
            remove_generated_tree(destination, destination.parent)
        except ValueError as exc:
            raise RuntimeError(str(exc)) from exc
    command = [
        sys.executable,
        str(script),
        "--input",
        str(source),
        "--output",
        str(destination),
        "--top",
        str(top_n),
    ]
    completed = subprocess.run(
        command,
        text=True,
        capture_output=True,
        encoding="utf-8",
        errors="replace",
        env=utf8_child_environment(),
    )
    if completed.returncode:
        raise RuntimeError(
            f"单环境分析失败：{source}\nstdout:\n{completed.stdout}\nstderr:\n{completed.stderr}"
        )


def run_thread_analysis(
    script: Path,
    selection: dict[str, Any],
    destination: Path,
    args: argparse.Namespace,
) -> dict[str, Any]:
    for stem in (
        "trace_thread_inventory",
        "selected_thread_pair",
        "selected_thread_operator_events",
        "selected_thread_operator_summary",
        "selected_thread_operator_comparison",
        "selected_thread_sequence_diff",
        "selected_thread_operator_heatmap",
    ):
        for suffix in (".csv", ".json"):
            artifact = destination / f"{stem}{suffix}"
            if artifact.exists():
                artifact.unlink()
    for filename in ("operator_heatmap.html", "trace_thread_analysis_manifest.json"):
        artifact = destination / filename
        if artifact.exists():
            artifact.unlink()
    real_trace = Path(str(selection["real"]["source"])) / "trace_view.json"
    sim_trace = Path(str(selection["sim"]["source"])) / "trace_view.json"
    status: dict[str, Any] = {
        "status": "未执行",
        "real_trace": str(real_trace),
        "sim_trace": str(sim_trace),
        "real_trace_present": real_trace.is_file(),
        "sim_trace_present": sim_trace.is_file(),
        "selection_scope": "每侧所选 Rank 内一个 process-thread",
        "selection_seed": args.thread_seed,
    }
    if not real_trace.is_file() or not sim_trace.is_file():
        missing = []
        if not real_trace.is_file():
            missing.append("真机 trace_view.json")
        if not sim_trace.is_file():
            missing.append("仿真 trace_view.json")
        status.update(
            {
                "status": "受限",
                "reason": "缺少" + "、".join(missing),
                "impact": "无法比较具体 process-thread 的 PyTorch 执行序列与热力图；缺失不等于零事件",
            }
        )
        write_json(destination / "thread_analysis_status.json", status)
        return status
    if not script.is_file():
        raise RuntimeError(f"缺少内置线程分析器：{script}")
    command = [
        sys.executable,
        str(script),
        "--real-trace",
        str(real_trace),
        "--sim-trace",
        str(sim_trace),
        "--output",
        str(destination),
        "--seed",
        str(args.thread_seed),
        "--heatmap-bins",
        str(args.heatmap_bins),
    ]
    for option, value in (
        ("--real-pid", args.real_pid),
        ("--real-tid", args.real_tid),
        ("--sim-pid", args.sim_pid),
        ("--sim-tid", args.sim_tid),
    ):
        if clean(value):
            command.extend([option, str(value)])
    completed = subprocess.run(
        command,
        text=True,
        capture_output=True,
        encoding="utf-8",
        errors="replace",
        env=utf8_child_environment(),
    )
    if completed.returncode:
        status.update(
            {
                "status": "失败",
                "reason": "线程级 trace 解析器返回非零退出码",
                "stdout": clean(completed.stdout, 4000),
                "stderr": clean(completed.stderr, 4000),
            }
        )
        write_json(destination / "thread_analysis_status.json", status)
        raise RuntimeError(
            f"process-thread 分析失败\nstdout:\n{completed.stdout}\nstderr:\n{completed.stderr}"
        )
    thread_manifest = read_json(destination / "trace_thread_analysis_manifest.json", {})
    manifest_status = clean(thread_manifest.get("status")) if isinstance(thread_manifest, dict) else ""
    if manifest_status == "受限":
        annotate_thread_rank_context(selection, destination)
        status.update(
            {
                "status": "受限",
                "reason": clean(thread_manifest.get("reason") or "一侧没有具体 PyTorch process-thread 候选"),
                "impact": clean(
                    thread_manifest.get("impact")
                    or "无法比较具体 process-thread 的 PyTorch 执行序列与热力图；缺失不等于零事件",
                    2000,
                ),
                "stdout": clean(completed.stdout, 4000),
                "trace_manifest_status": manifest_status,
            }
        )
        write_json(destination / "thread_analysis_status.json", status)
        return status
    if manifest_status != "完成":
        status.update(
            {
                "status": "失败",
                "reason": "线程分析器未生成完成/受限状态 manifest",
                "stdout": clean(completed.stdout, 4000),
            }
        )
        write_json(destination / "thread_analysis_status.json", status)
        raise RuntimeError(status["reason"])
    annotate_thread_rank_context(selection, destination)
    status.update(
        {
            "status": "完成",
            "stdout": clean(completed.stdout, 4000),
            "deterministic_numeric_ground_truth": "selected_thread_operator_*.csv 与 selected_thread_operator_heatmap.csv",
        "perfetto_visual_role": "HTML/文本/SQL 可作内容复核，截图按需用于 Canvas 视觉复核；均不替代本地数值证据",
        }
    )
    write_json(destination / "thread_analysis_status.json", status)
    return status


def annotate_thread_rank_context(selection: dict[str, Any], destination: Path) -> None:
    """Attach selected DP/TP/... coordinates to every thread-level evidence row."""
    environment_stems = {
        "trace_thread_inventory",
        "selected_thread_pair",
        "selected_thread_operator_events",
        "selected_thread_operator_summary",
        "selected_thread_operator_heatmap",
    }
    pair_stems = {
        "selected_thread_operator_comparison",
        "selected_thread_sequence_diff",
    }
    def annotate(stem: str, rows: list[dict[str, Any]]) -> list[dict[str, Any]]:
        for row in rows:
            row.pop("_evidence", None)
            row["rank_pair_id"] = SELECTED_RANK_PAIR_ID
            if stem in environment_stems:
                side = selection["real"] if clean(row.get("environment")).startswith("real") else selection["sim"]
                row["rank"] = norm(side.get("rank"))
                row["global_rank"] = norm(side.get("global_rank"))
                row["parallel_coordinate"] = norm(side.get("parallel_coordinate"))
                for field in PARALLEL_FIELDS:
                    row[field] = norm(side.get(field))
            else:
                row["real_parallel_coordinate"] = norm(selection["real"].get("parallel_coordinate"))
                row["sim_parallel_coordinate"] = norm(selection["sim"].get("parallel_coordinate"))
                for field in PARALLEL_FIELDS:
                    row[f"real_{field}"] = norm(selection["real"].get(field))
                    row[f"sim_{field}"] = norm(selection["sim"].get(field))
        return rows

    for stem in sorted(environment_stems | pair_stems):
        csv_path = destination / f"{stem}.csv"
        if csv_path.exists():
            csv_rows = read_csv(csv_path)
            if csv_rows:
                write_csv(csv_path, annotate(stem, csv_rows))
        json_path = destination / f"{stem}.json"
        json_rows = read_json(json_path, [])
        if isinstance(json_rows, list):
            typed_rows = [dict(row) for row in json_rows if isinstance(row, dict)]
            write_json(json_path, annotate(stem, typed_rows))


def find_local_repo_root(path: Path) -> Path:
    start = path if path.is_dir() else path.parent
    for candidate in (start, *start.parents):
        if (candidate / ".git").exists():
            return candidate.resolve()
    return start.resolve()


def run_local_source_resolution(
    script: Path,
    bindings: list[dict[str, str]],
    destination: Path,
) -> list[dict[str, Any]]:
    if destination.exists():
        remove_generated_tree(destination, destination.parent)
    statuses: list[dict[str, Any]] = []
    for binding in bindings:
        environment = binding["environment"]
        locator = clean(binding.get("repository_url_or_path"), 8000)
        entry_hint = clean(binding.get("subpath"), 8000)
        parsed = urlsplit(locator or entry_hint)
        if parsed.scheme.lower() in {"http", "https"}:
            statuses.append(
                {
                    "environment": environment,
                    "status": "待网页只读分析",
                    "locator": locator or entry_hint,
                    "reason": "远程 GitHub/GitCode locator 必须由分析代理打开并固定到 commit",
                }
            )
            continue
        local_locator = Path(locator) if locator else (Path(entry_hint) if entry_hint else None)
        if local_locator is None:
            statuses.append({"environment": environment, "status": "未提供", "reason": "没有代码 locator"})
            continue
        try:
            local_locator = local_locator.resolve()
        except OSError as exc:
            statuses.append({"environment": environment, "status": "不可访问", "reason": clean(exc)})
            continue
        if not local_locator.exists():
            statuses.append(
                {
                    "environment": environment,
                    "status": "不可访问",
                    "locator": str(local_locator),
                    "reason": "本地代码 locator 不存在；Profiler-only 对比继续",
                }
            )
            continue
        repo_root = find_local_repo_root(local_locator)
        entry = entry_hint
        if not locator and entry_hint:
            entry = str(local_locator)
        elif locator and (local_locator.is_file() or local_locator != repo_root) and not entry:
            entry = str(local_locator)
        elif entry:
            entry_path = Path(entry)
            if not entry_path.is_absolute():
                entry = str((repo_root / entry_path).resolve())
        role_dir = "real" if environment.startswith("real") else "sim"
        output_dir = destination / role_dir
        command = [
            sys.executable,
            str(script),
            "--repo-root",
            str(repo_root),
            "--output",
            str(output_dir),
            "--environment",
            environment,
        ]
        if entry:
            command.extend(["--entry", entry])
        completed = subprocess.run(
            command,
            text=True,
            capture_output=True,
            encoding="utf-8",
            errors="replace",
            env=utf8_child_environment(),
        )
        status = {
            "environment": environment,
            "status": "完成" if completed.returncode == 0 else "失败",
            "locator": str(local_locator),
            "repo_root": str(repo_root),
            "entry": entry,
            "output": str(output_dir),
            "stdout": clean(completed.stdout, 4000),
            "stderr": clean(completed.stderr, 4000),
        }
        statuses.append(status)
        if completed.returncode == 0:
            binding["access_mode"] = "本地静态解析"
            binding["runtime_binding"] = "未验证（静态候选）"
            # Keep the environment binding beside the resolver artifacts so the
            # AST mapper can apply the same commit/runtime-evidence boundary.
            write_csv(output_dir / "source_bindings.csv", [binding])
    write_json(destination.parent / "source_analysis_status.json", statuses)
    return statuses


SOURCE_MAPPING_ARTIFACTS = (
    "thread_operator_source_map.csv",
    "source_symbol_edges.csv",
    "source_evidence.csv",
    "source_mapping_issues.csv",
    "source_mapping_summary.json",
    "source_mapping_summary.real.json",
    "source_mapping_summary.sim.json",
    "source_mapping_status.json",
)


def run_local_source_mapping(
    script: Path,
    source_statuses: list[dict[str, Any]],
    destination: Path,
    thread_analysis_status: dict[str, Any],
) -> list[dict[str, Any]]:
    """Map selected-thread events to local source without executing the repo."""
    for name in SOURCE_MAPPING_ARTIFACTS:
        path = destination / name
        if path.exists() and path.is_file():
            path.unlink()

    results: list[dict[str, Any]] = []
    thread_events = destination / "selected_thread_operator_events.csv"
    if thread_analysis_status.get("status") != "完成" or not thread_events.is_file():
        for status in source_statuses:
            results.append(
                {
                    "environment": status.get("environment", "未知"),
                    "status": "未执行",
                    "reason": "所选线程分析未完成，无法建立 runtime event 到源码的映射",
                }
            )
        write_json(destination / "source_mapping_status.json", results)
        return results

    for source_status in source_statuses:
        environment = clean(source_status.get("environment"))
        if source_status.get("status") != "完成":
            results.append(
                {
                    "environment": environment or "未知",
                    "status": "未执行",
                    "reason": clean(source_status.get("reason") or "本地源码入口解析未完成", 2000),
                }
            )
            continue
        repo_root = Path(str(source_status.get("repo_root", "")))
        source_analysis_dir = Path(str(source_status.get("output", "")))
        command = [
            sys.executable,
            str(script),
            "--repo-root",
            str(repo_root),
            "--source-analysis-dir",
            str(source_analysis_dir),
            "--thread-events",
            str(thread_events),
            "--output",
            str(destination),
            "--environment",
            environment,
        ]
        completed = subprocess.run(
            command,
            text=True,
            capture_output=True,
            encoding="utf-8",
            errors="replace",
            env=utf8_child_environment(),
        )
        result = {
            "environment": environment,
            "status": "完成" if completed.returncode == 0 else "失败",
            "repo_root": str(repo_root),
            "source_analysis_dir": str(source_analysis_dir),
            "thread_events": str(thread_events),
            "stdout": clean(completed.stdout, 4000),
            "stderr": clean(completed.stderr, 4000),
        }
        results.append(result)
    write_json(destination / "source_mapping_status.json", results)
    return results


def aggregate_rows(
    rows: list[dict[str, Any]],
    key_fn: Callable[[dict[str, Any]], tuple[str, ...]],
    metric_fields: list[str],
    text_fields: list[str],
) -> dict[tuple[str, ...], dict[str, Any]]:
    grouped: dict[tuple[str, ...], dict[str, Any]] = {}
    for source in rows:
        key = key_fn(source)
        item = grouped.setdefault(
            key,
            {
                "_key": key,
                "_records": 0,
                "_texts": defaultdict(set),
                "_metrics": defaultdict(float),
                "_metric_seen": set(),
                "_metric_counts": defaultdict(int),
                "_evidence": set(),
            },
        )
        item["_records"] += 1
        for field in metric_fields:
            value = number(source.get(field))
            if value is not None:
                item["_metrics"][field] += value
                item["_metric_seen"].add(field)
                item["_metric_counts"][field] += 1
        for field in text_fields:
            value = clean(source.get(field), 5000)
            if value:
                item["_texts"][field].add(value)
        evidence = clean(source.get("_evidence"), 5000)
        if evidence:
            item["_evidence"].add(evidence)
        item.setdefault("_example", source)
    return grouped


def complete_grouped_metric(item: dict[str, Any] | None, field: str) -> float | None:
    if not item or item["_records"] <= 0:
        return None
    if item["_metric_counts"].get(field, 0) != item["_records"]:
        return None
    return item["_metrics"].get(field)


def ratio_fields(real_value: float | None, sim_value: float | None) -> dict[str, Any]:
    if real_value is None or sim_value is None:
        return {"delta": "不可计算", "sim_over_real": "不可计算", "delta_percent": "不可计算"}
    delta = sim_value - real_value
    if real_value == 0:
        ratio: Any = "不可计算（真机为0）"
        percent: Any = "不可计算（真机为0）"
    else:
        ratio = sim_value / real_value
        percent = 100.0 * delta / real_value
    return {
        "delta": round(delta, 9),
        "sim_over_real": round(ratio, 9) if isinstance(ratio, float) else ratio,
        "delta_percent": round(percent, 6) if isinstance(percent, float) else percent,
    }


def compare_grouped(
    real: dict[tuple[str, ...], dict[str, Any]],
    sim: dict[tuple[str, ...], dict[str, Any]],
    key_names: list[str],
    metrics: list[str],
    text_fields: list[str],
    timing_allowed: str,
) -> list[dict[str, Any]]:
    output: list[dict[str, Any]] = []
    for key in sorted(set(real) | set(sim)):
        left = real.get(key)
        right = sim.get(key)
        presence = "两侧存在" if left and right else ("仅真机" if left else "仅仿真")
        row: dict[str, Any] = {name: value for name, value in zip(key_names, key)}
        row["presence"] = presence
        row["timing_interpretation_allowed"] = timing_allowed
        row["real_records"] = left["_records"] if left else 0
        row["sim_records"] = right["_records"] if right else 0
        row["record_count_match"] = "是" if row["real_records"] == row["sim_records"] else "否"
        row["real_evidence"] = json.dumps(sorted(left["_evidence"]), ensure_ascii=False) if left else "[]"
        row["sim_evidence"] = json.dumps(sorted(right["_evidence"]), ensure_ascii=False) if right else "[]"
        for field in metrics:
            left_value = complete_grouped_metric(left, field)
            right_value = complete_grouped_metric(right, field)
            left_observed = left["_metric_counts"].get(field, 0) if left else 0
            right_observed = right["_metric_counts"].get(field, 0) if right else 0
            row[f"real_{field}_observed_records"] = left_observed
            row[f"real_{field}_missing_records"] = left["_records"] - left_observed if left else 0
            row[f"sim_{field}_observed_records"] = right_observed
            row[f"sim_{field}_missing_records"] = right["_records"] - right_observed if right else 0
            row[f"real_{field}"] = "缺失" if left_value is None else round(left_value, 9)
            row[f"sim_{field}"] = "缺失" if right_value is None else round(right_value, 9)
            derived = ratio_fields(left_value, right_value)
            row[f"{field}_sim_minus_real"] = derived["delta"]
            row[f"{field}_sim_over_real"] = derived["sim_over_real"]
            row[f"{field}_delta_percent"] = derived["delta_percent"]
        for field in text_fields:
            left_text = sorted(left["_texts"].get(field, set())) if left else []
            right_text = sorted(right["_texts"].get(field, set())) if right else []
            row[f"real_{field}"] = json.dumps(left_text, ensure_ascii=False)
            row[f"sim_{field}"] = json.dumps(right_text, ensure_ascii=False)
            row[f"{field}_match"] = "是" if left_text == right_text else "否"
        output.append(row)
    return output


def add_per_call_metric(
    grouped: dict[tuple[str, ...], dict[str, Any]],
    total_field: str,
    output_field: str,
    calls_field: str = "calls",
) -> None:
    for item in grouped.values():
        total = complete_grouped_metric(item, total_field)
        calls = complete_grouped_metric(item, calls_field)
        if total is None or calls is None:
            continue
        if calls <= 0:
            continue
        item["_metrics"][output_field] = total / calls
        item["_metric_seen"].add(output_field)
        item["_metric_counts"][output_field] = item["_records"]


def add_effect_decomposition(
    rows: list[dict[str, Any]],
    total_field: str,
    per_call_field: str,
    calls_field: str = "calls",
) -> None:
    for row in rows:
        real_calls = number(row.get(f"real_{calls_field}"))
        sim_calls = number(row.get(f"sim_{calls_field}"))
        real_avg = number(row.get(f"real_{per_call_field}"))
        sim_avg = number(row.get(f"sim_{per_call_field}"))
        if None in {real_calls, sim_calls, real_avg, sim_avg}:
            row[f"{total_field}_volume_effect"] = "不可计算"
            row[f"{total_field}_unit_cost_effect"] = "不可计算"
            continue
        row[f"{total_field}_volume_effect"] = round((sim_calls - real_calls) * real_avg, 9)
        row[f"{total_field}_unit_cost_effect"] = round(sim_calls * (sim_avg - real_avg), 9)


def pytorch_key(row: dict[str, Any]) -> tuple[str, ...]:
    return rank_key(row), clean(row.get("operator")), shape_text(row.get("input_shapes"))


def device_key(row: dict[str, Any]) -> tuple[str, ...]:
    return (
        rank_key(row),
        clean(row.get("operator")),
        clean(row.get("type")),
        shape_text(row.get("input_shapes")),
        shape_text(row.get("output_shapes")),
        clean(row.get("input_dtypes")),
        clean(row.get("output_dtypes")),
        clean(row.get("accelerator_core")),
        clean(row.get("input_formats")),
        clean(row.get("output_formats")),
    )


def communication_key(row: dict[str, Any]) -> tuple[str, ...]:
    return (
        rank_key(row),
        clean(row.get("category")),
        clean(row.get("collective_type")),
        clean(row.get("communication_group")),
        known_parallel_axis(row.get("parallel_axis")),
    )


def communication_collective_key(row: dict[str, Any]) -> tuple[str, ...]:
    """Cross-environment key that excludes the non-portable raw group handle."""
    return (
        rank_key(row),
        clean(row.get("category")),
        clean(row.get("collective_type")),
        known_parallel_axis(row.get("parallel_axis")),
    )


def memory_key(row: dict[str, Any]) -> tuple[str, ...]:
    return rank_key(row), clean(row.get("component")), clean(row.get("device_type"))


def communication_link_key(row: dict[str, Any]) -> tuple[str, ...]:
    return (
        rank_key(row),
        clean(row.get("category")),
        clean(row.get("collective_type")),
        clean(row.get("communication_group")),
        known_parallel_axis(row.get("parallel_axis")),
        clean(row.get("link")),
    )


def step_rows_with_ordinal(rows: list[dict[str, Any]]) -> list[dict[str, Any]]:
    by_rank: dict[str, list[dict[str, Any]]] = defaultdict(list)
    for row in rows:
        by_rank[rank_key(row)].append(row)

    def step_sort(row: dict[str, Any]) -> tuple[int, float, str]:
        text = clean(row.get("step"))
        match = re.search(r"-?\d+(?:\.\d+)?", text)
        return (0, float(match.group())) if match else (1, 0.0, text)

    result: list[dict[str, Any]] = []
    for key, rank_rows in by_rank.items():
        for index, source in enumerate(sorted(rank_rows, key=step_sort), start=1):
            row = dict(source)
            row["step_ordinal"] = index
            row["rank_alignment_key"] = key
            result.append(row)
    return result


def step_key(row: dict[str, Any]) -> tuple[str, ...]:
    return str(row.get("rank_alignment_key") or rank_key(row)), str(row.get("step_ordinal"))


def profile_inputs(args: argparse.Namespace) -> list[dict[str, str]]:
    return [
        {
            "field": "model",
            "real": clean(args.real_model),
            "sim": clean(args.sim_model),
            "required_for_timing": "是",
        },
        {
            "field": "workload_id",
            "real": clean(args.real_workload_id),
            "sim": clean(args.sim_workload_id),
            "required_for_timing": "是",
        },
        {
            "field": "phase",
            "real": clean(args.real_phase),
            "sim": clean(args.sim_phase),
            "required_for_timing": "是",
        },
        {
            "field": "schedule_id",
            "real": clean(args.real_schedule_id),
            "sim": clean(args.sim_schedule_id),
            "required_for_timing": "是",
        },
    ]


def sanitize_code_locator(value: Any) -> tuple[str, str]:
    locator = clean(value, 8000)
    if not locator:
        return "", "否"
    parsed = urlsplit(locator)
    if parsed.scheme.lower() not in {"http", "https"}:
        return locator, "否"
    host = parsed.hostname or ""
    if parsed.port:
        host = f"{host}:{parsed.port}"
    safe_fragment = parsed.fragment if re.fullmatch(r"L\d+(?:-L\d+)?", parsed.fragment or "") else ""
    sanitized = urlunsplit((parsed.scheme.lower(), host, parsed.path, "", safe_fragment))
    redacted = sanitized != locator
    return sanitized, "是" if redacted else "否"


def locator_metadata(locator: str) -> tuple[str, str]:
    parsed = urlsplit(locator)
    if parsed.scheme.lower() in {"http", "https"}:
        host = (parsed.hostname or "").lower()
        provider = "GitHub" if host.endswith("github.com") else ("GitCode" if "gitcode" in host else "Web")
        if "/blob/" in parsed.path:
            kind = "blob_url"
        elif "/tree/" in parsed.path:
            kind = "tree_url"
        else:
            kind = "repository_url"
        return provider, kind
    if not locator:
        return "未提供", "未提供"
    path = Path(locator)
    if path.suffix.lower() == ".sh":
        return "local", "shell_file"
    return "local", "directory_or_checkout"


def source_binding_rows(args: argparse.Namespace) -> list[dict[str, str]]:
    common_repo = clean(args.code_repo, 8000)
    common_ref = clean(args.code_ref)
    common_entry = clean(args.code_entry, 8000)
    real_repo = clean(args.real_code_repo, 8000) or common_repo
    sim_repo = clean(args.sim_code_repo, 8000) or common_repo
    real_ref = clean(args.real_code_ref) or common_ref
    sim_ref = clean(args.sim_code_ref) or common_ref
    real_entry = clean(args.real_code_entry, 8000) or common_entry
    sim_entry = clean(args.sim_code_entry, 8000) or common_entry
    rows = []
    for environment, repository_raw, requested_ref, entry_raw in (
        ("real/reference/真机", real_repo, real_ref, real_entry),
        ("sim/candidate/仿真", sim_repo, sim_ref, sim_entry),
    ):
        repository, repo_redacted = sanitize_code_locator(repository_raw)
        entry, entry_redacted = sanitize_code_locator(entry_raw)
        provider, locator_kind = locator_metadata(repository or entry)
        has_locator = bool(repository or entry)
        rows.append(
            {
                "environment": environment,
                "input_locator_sanitized": repository or entry,
                "provider": provider,
                "locator_kind": locator_kind,
                "repository_url_or_path": repository,
                "requested_ref": requested_ref,
                "url_ref": "待网页固定" if repository.startswith(("http://", "https://")) else "不适用",
                "profiler_ref": "未发现",
                "resolved_commit": "待源码读取阶段解析" if has_locator else "未提供",
                "subpath": entry,
                "retrieved_at_utc": "未读取",
                "runtime_binding": "未验证" if has_locator else "未提供",
                "access_mode": "待解析" if has_locator else "不适用",
                "credentials_redacted": "是" if "是" in {repo_redacted, entry_redacted} else "否",
                "notes": "入口可仅为 .sh/全是 .sh 的目录；必须静态读取且固定 commit，不得执行仓库代码",
            }
        )
    return rows


def compare_profile_inputs(rows: list[dict[str, str]]) -> list[dict[str, Any]]:
    output = []
    for row in rows:
        real = row["real"]
        sim = row["sim"]
        if not real or not sim:
            status = "待确认"
            detail = "至少一侧未显式提供"
        elif real == sim:
            status = "通过"
            detail = "两侧显式值一致"
        else:
            status = "不通过"
            detail = "两侧显式值不同"
        output.append({**row, "status": status, "detail": detail})
    return output


BACKWARD_PHASE_PATTERN = re.compile(
    r"backward|(?:^|::|_)grad(?:$|::|_)|optimizer|zero_grad|loss_backward|"
    r"root_post_backward|pre_backward|post_backward",
    re.IGNORECASE,
)
PREFILL_PHASE_PATTERN = re.compile(r"prefill|prompt(?:_| )?encode", re.IGNORECASE)
DECODE_PHASE_PATTERN = re.compile(r"(?:^|[^a-z])decode(?:[^a-z]|$)|incremental", re.IGNORECASE)


def declared_phase_class(value: Any) -> str:
    text = norm(value).casefold()
    if text == "未知":
        return "未知"
    if any(token in text for token in ("train", "backward", "反向", "训练")):
        return "training/backward"
    if "decode" in text or "解码" in text:
        return "decode"
    if "prefill" in text or "预填充" in text:
        return "prefill"
    if "infer" in text or "推理" in text:
        return "inference"
    return text


def infer_runtime_phase(
    comparison_dir: Path,
    real_declared: Any,
    sim_declared: Any,
) -> tuple[list[dict[str, Any]], dict[str, Any]]:
    events = read_csv(comparison_dir / "selected_thread_operator_events.csv")
    observations: list[dict[str, Any]] = []
    for side, declared in (("real", real_declared), ("sim", sim_declared)):
        side_events = [
            row for row in events if str(row.get("environment", "")).casefold().startswith(side)
        ]
        buckets: dict[str, list[str]] = {
            "training/backward": [],
            "prefill": [],
            "decode": [],
        }
        for row in side_events:
            operator = clean(row.get("operator"), 1000)
            stack = clean(row.get("call_stack"), 4000)
            evidence = f"{operator} {stack}"
            if BACKWARD_PHASE_PATTERN.search(evidence):
                buckets["training/backward"].append(operator)
            if PREFILL_PHASE_PATTERN.search(evidence):
                buckets["prefill"].append(operator)
            if DECODE_PHASE_PATTERN.search(evidence):
                buckets["decode"].append(operator)
        if buckets["training/backward"]:
            observed = "training/backward"
        elif buckets["prefill"] and not buckets["decode"]:
            observed = "prefill"
        elif buckets["decode"] and not buckets["prefill"]:
            observed = "decode"
        else:
            observed = "未知"
        observations.append(
            {
                "environment": side,
                "declared_phase": norm(declared),
                "declared_phase_class": declared_phase_class(declared),
                "observed_phase": observed,
                "selected_thread_events": len(side_events),
                "backward_evidence_events": len(buckets["training/backward"]),
                "prefill_evidence_events": len(buckets["prefill"]),
                "decode_evidence_events": len(buckets["decode"]),
                "evidence_operators": json.dumps(
                    list(dict.fromkeys(buckets.get(observed, [])))[:20], ensure_ascii=False
                ),
            }
        )
    by_side = {str(row["environment"]): row for row in observations}
    real = by_side.get("real", {})
    sim = by_side.get("sim", {})
    real_observed = str(real.get("observed_phase", "未知"))
    sim_observed = str(sim.get("observed_phase", "未知"))
    real_declared_class = str(real.get("declared_phase_class", "未知"))
    sim_declared_class = str(sim.get("declared_phase_class", "未知"))

    def conflicts(declared: str, observed: str) -> bool:
        if observed == "未知" or declared == "未知":
            return False
        if declared == "inference" and observed == "training/backward":
            return True
        return declared in {"decode", "prefill", "training/backward"} and declared != observed

    reasons: list[str] = []
    if real_observed != "未知" and sim_observed != "未知" and real_observed != sim_observed:
        reasons.append("两侧运行时阶段证据不同")
    if conflicts(real_declared_class, real_observed):
        reasons.append("真机声明阶段与 trace 证据冲突")
    if conflicts(sim_declared_class, sim_observed):
        reasons.append("仿真声明阶段与 trace 证据冲突")
    if reasons:
        status = "不通过"
    elif real_observed == "未知" or sim_observed == "未知":
        status = "待确认"
        reasons.append("至少一侧没有足够的运行时阶段 marker/算子证据")
    else:
        status = "通过"
        reasons.append("两侧运行时阶段证据一致，且未发现与声明冲突")
    gate = {
        "gate": "runtime_phase_evidence",
        "field": "phase",
        "real": f"声明={norm(real_declared)}；观测={real_observed}",
        "sim": f"声明={norm(sim_declared)}；观测={sim_observed}",
        "status": status,
        "detail": "；".join(reasons),
        "impact": "阶段声明与 trace 证据冲突时，禁止解释真仿时间保真度，并应先修正 workload/phase 标签",
    }
    return observations, gate


def full_topology_signature(rows: list[dict[str, Any]]) -> dict[str, Any]:
    signature: dict[str, Any] = {"rank_exports_discovered": len(rows)}
    for field in PARALLEL_FIELDS:
        values = sorted(
            {
                str(row.get(field))
                for row in rows
                if clean(row.get(field)).lower() not in UNKNOWN
            }
        )
        signature[field] = values or ["未知"]
    # Axis-wise sets alone lose coordinate correlations, e.g. (0,1) versus
    # (1,0). Keep a sorted multiset so duplicate shards and unknown fields are
    # both represented in the comparability gate.
    signature["parallel_coordinate_multiset"] = sorted(
        coordinate_key(row, include_global_rank=False) for row in rows
    )
    return signature


def topology_gates(selection: dict[str, Any], real_all: list[dict[str, Any]], sim_all: list[dict[str, Any]]) -> list[dict[str, Any]]:
    real_signature = full_topology_signature(real_all)
    sim_signature = full_topology_signature(sim_all)
    degree_match = real_signature == sim_signature
    conflicts = int(selection.get("parallel_field_conflicts", 0))
    known = int(selection.get("parallel_fields_known_on_both", 0))
    coordinate_status = (
        "不通过"
        if conflicts
        else "通过"
        if known == len(PARALLEL_FIELDS)
        else "待确认"
    )
    left = selection["real"]
    right = selection["sim"]
    return [
        {
            "gate": "full_topology_context",
            "status": "通过" if degree_match else "不通过",
            "real": json.dumps(real_signature, ensure_ascii=False),
            "sim": json.dumps(sim_signature, ensure_ascii=False),
            "impact": "即使只分析一个 Rank，完整拓扑不一致时也不能宣称整体时间保真度",
        },
        {
            "gate": "selected_rank_parallel_coordinate",
            "status": coordinate_status,
            "real": coordinate_key(left, include_global_rank=False),
            "sim": coordinate_key(right, include_global_rank=False),
            "detail": f"DP/TP/EP/PP/CP/DCP 共同已知字段 {known}/{len(PARALLEL_FIELDS)} 个，冲突 {conflicts} 个；全部已知且无冲突才通过，global rank 仅登记、不作为主 join key",
            "impact": "冲突时不能把不同 shard/阶段的单 Rank 直接相除",
        },
        {
            "gate": "single_rank_scope",
            "status": "通过",
            "real": str(left.get("source", "")),
            "sim": str(right.get("source", "")),
            "detail": f"每侧仅抽取一个 Rank；真机候选 {len(real_all)}，仿真候选 {len(sim_all)}",
            "impact": "允许分析所选 Rank；禁止外推 rank imbalance、慢 Rank 或跨 Rank 分布",
        },
    ]


def rank_alignment_rows(selection: dict[str, Any]) -> list[dict[str, Any]]:
    left = selection["real"]
    right = selection["sim"]
    return [
        {
            "rank_alignment_key": SELECTED_RANK_PAIR_ID,
            "rank_pair_id": SELECTED_RANK_PAIR_ID,
            "presence": "两侧存在",
            "real_rank": clean(left.get("rank")),
            "sim_rank": clean(right.get("rank")),
            "real_global_rank": clean(left.get("global_rank")),
            "sim_global_rank": clean(right.get("global_rank")),
            "real_device": clean(left.get("device")),
            "sim_device": clean(right.get("device")),
            "real_parallel_coordinate": clean(left.get("parallel_coordinate")),
            "sim_parallel_coordinate": clean(right.get("parallel_coordinate")),
            "alignment_method": clean(selection.get("selection_method")),
            "confidence": clean(selection.get("confidence")),
        }
    ]


def coverage_gates(real_dir: Path, sim_dir: Path) -> tuple[list[dict[str, Any]], int, int]:
    real_rows = read_csv(real_dir / "source_coverage_all_ranks.csv")
    sim_rows = read_csv(sim_dir / "source_coverage_all_ranks.csv")

    def index(rows: list[dict[str, Any]]) -> dict[tuple[str, str], str]:
        return {(rank_key(row), clean(row.get("file"))): clean(row.get("present")) for row in rows}

    left = index(real_rows)
    right = index(sim_rows)
    output = []
    mismatch = 0
    missing_both = 0
    for key in sorted(set(left) | set(right)):
        real_present = left.get(key, "无记录")
        sim_present = right.get(key, "无记录")
        same = real_present == sim_present
        if key[1] in PRIMARY_FILES and not same:
            mismatch += 1
        if key[1] in PRIMARY_FILES and real_present != "是" and sim_present != "是":
            missing_both += 1
        output.append(
            {
                "rank_alignment_key": key[0],
                "file": key[1],
                "real_present": real_present,
                "sim_present": sim_present,
                "match": "是" if same else "否",
                "priority": "主证据" if key[1] in PRIMARY_FILES else "可选/辅助",
            }
        )
    return output, mismatch, missing_both


def timing_gate(
    gates: list[dict[str, Any]],
    input_gates: list[dict[str, Any]],
    coverage_mismatch: int,
    coverage_missing_both: int,
) -> str:
    if any(row["status"] == "不通过" for row in gates + input_gates):
        return "否"
    if coverage_mismatch:
        return "否"
    if any(row["status"] == "待确认" for row in gates + input_gates):
        return "待人工确认"
    if coverage_missing_both:
        return "受限（双方均缺主证据）"
    return "是"


def mismatch_summary(name: str, rows: list[dict[str, Any]]) -> dict[str, Any]:
    presence = sum(1 for row in rows if row.get("presence") != "两侧存在")
    count_change = sum(
        1 for row in rows if row.get("presence") == "两侧存在" and row.get("record_count_match") == "否"
    )
    return {
        "dimension": name,
        "entities": len(rows),
        "matched_entities": len(rows) - presence,
        "presence_mismatches": presence,
        "record_count_mismatches": count_change,
    }


def annotate_comparison_rank(rows: list[dict[str, Any]], selection: dict[str, Any]) -> None:
    left = selection["real"]
    right = selection["sim"]
    pair_text = f"真机 {norm(left.get('parallel_coordinate'))} / 仿真 {norm(right.get('parallel_coordinate'))}"
    for row in rows:
        row["rank_pair_id"] = SELECTED_RANK_PAIR_ID
        row["real_rank"] = norm(left.get("rank"))
        row["sim_rank"] = norm(right.get("rank"))
        row["real_global_rank"] = norm(left.get("global_rank"))
        row["sim_global_rank"] = norm(right.get("global_rank"))
        for axis in PARALLEL_FIELDS:
            row[f"real_{axis}"] = norm(left.get(axis))
            row[f"sim_{axis}"] = norm(right.get(axis))
        row["real_parallel_coordinate"] = norm(left.get("parallel_coordinate"))
        row["sim_parallel_coordinate"] = norm(right.get("parallel_coordinate"))
        row["parallel_coordinate_pair"] = pair_text


def top_deviations(rows: list[dict[str, Any]], metric: str, limit: int = 20) -> list[dict[str, Any]]:
    field = f"{metric}_delta_percent"
    candidates = []
    for row in rows:
        value = number(row.get(field))
        if value is None or row.get("presence") != "两侧存在":
            continue
        candidates.append((abs(value), row))
    return [row for _, row in sorted(candidates, key=lambda item: item[0], reverse=True)[:limit]]


def markdown_cell(value: Any, limit: int = 160) -> str:
    text = html.escape(clean(value, limit), quote=False).replace("`", "&#96;")
    text = text.replace("\\", "\\\\")
    for marker in ("!", "[", "]", "(", ")", "|"):
        text = text.replace(marker, "\\" + marker)
    return text


def markdown_table(rows: list[dict[str, Any]], columns: list[tuple[str, str]], limit: int = 20) -> list[str]:
    if not rows:
        return ["_无数据_", ""]
    lines = ["| " + " | ".join(title for _, title in columns) + " |", "|" + "|".join(["---"] * len(columns)) + "|"]
    for row in rows[:limit]:
        values = [markdown_cell(row.get(field), 160) for field, _ in columns]
        lines.append("| " + " | ".join(values) + " |")
    lines.append("")
    return lines


def build_summary(
    real: Path,
    sim: Path,
    gates: list[dict[str, Any]],
    input_gates: list[dict[str, Any]],
    coverage_mismatch: int,
    timing_allowed: str,
    summaries: list[dict[str, Any]],
    pytorch: list[dict[str, Any]],
    device: list[dict[str, Any]],
    communication: list[dict[str, Any]],
    step: list[dict[str, Any]],
    source_bindings: list[dict[str, str]],
) -> str:
    structure_limited = any(row["status"] == "不通过" for row in gates)
    level = "结构对比受限" if structure_limited else "结构可比"
    lines = [
        "# 真机与仿真 Profiling 对比摘要",
        "",
        f"> 真机（reference）：`{html.escape(str(real), quote=False).replace('`', '&#96;')}`  ",
        f"> 仿真（candidate）：`{html.escape(str(sim), quote=False).replace('`', '&#96;')}`  ",
        "> 分析范围：每侧仅一个选定 Rank；线程级部分仅分析一个可复现随机选择/显式指定的 process-thread。  ",
        "> 差值方向：仿真 - 真机；比率方向：仿真 / 真机。  ",
        f"> 自动判定：{level}；时间比率解释：{timing_allowed}。",
        "",
        "## 1. 可比性门禁",
        "",
    ]
    lines.extend(markdown_table(gates + input_gates, [("gate", "门禁"), ("field", "输入字段"), ("status", "状态"), ("real", "真机"), ("sim", "仿真"), ("impact", "影响"), ("detail", "说明")], 30))
    if coverage_mismatch:
        lines.extend([f"`事实`：主证据文件存在性有 {coverage_mismatch} 处不一致，相关维度不能直接作性能解释。", ""])
    lines.extend(["## 2. 结构保真度", ""])
    lines.extend(markdown_table(summaries, [("dimension", "维度"), ("entities", "实体数"), ("matched_entities", "两侧存在"), ("presence_mismatches", "仅一侧存在"), ("record_count_mismatches", "记录数不一致")], 20))
    lines.extend(["## 3. PyTorch 算子主要时间偏差", ""])
    lines.extend(markdown_table(top_deviations(pytorch, "device_self_us_total", 15), [("rank_alignment_key", "Rank 对齐键"), ("operator", "算子"), ("input_shapes", "输入 Shape"), ("real_device_self_us_total", "真机 Device Self(us)"), ("sim_device_self_us_total", "仿真 Device Self(us)"), ("device_self_us_total_sim_over_real", "仿真/真机"), ("device_self_us_total_delta_percent", "差异(%)")], 15))
    lines.extend(["## 4. 设备执行与通信偏差", ""])
    lines.extend(markdown_table(top_deviations(device, "duration_us_total", 10), [("operator", "执行算子"), ("input_shapes", "输入 Shape"), ("output_shapes", "输出 Shape"), ("real_duration_us_total", "真机(us)"), ("sim_duration_us_total", "仿真(us)"), ("duration_us_total_sim_over_real", "仿真/真机")], 10))
    lines.extend(markdown_table(top_deviations(communication, "transit_ms_total", 10), [("collective_type", "通信类型"), ("parallel_axis", "并行轴"), ("real_communication_group", "真机 raw Group"), ("sim_communication_group", "仿真 raw Group"), ("real_transit_size_mb_total", "真机消息(MB)"), ("sim_transit_size_mb_total", "仿真消息(MB)"), ("transit_ms_total_sim_over_real", "Transit 仿真/真机")], 10))
    lines.extend(["## 5. Step/墙钟偏差", ""])
    lines.extend(markdown_table(top_deviations(step, "stage_us", 20), [("rank_alignment_key", "Rank 对齐键"), ("step_ordinal", "Step 序号"), ("real_stage_us", "真机 Stage(us)"), ("sim_stage_us", "仿真 Stage(us)"), ("stage_us_sim_over_real", "仿真/真机"), ("stage_us_delta_percent", "差异(%)")], 20))
    lines.extend(["## 6. 模型代码证据", ""])
    provided_bindings = [row for row in source_bindings if row.get("input_locator_sanitized")]
    if provided_bindings:
        lines.extend(
            [
                "用户提供的环境-源码绑定：",
                "",
                *[
                    f"- {html.escape(str(row['environment']), quote=False)}：`{html.escape(str(row['repository_url_or_path'] or row['subpath']), quote=False).replace('`', '&#96;')}` @ `{html.escape(str(row['requested_ref'] or '未提供'), quote=False).replace('`', '&#96;')}`"
                    for row in provided_bindings
                ],
                "",
                "脚本只记录代码仓上下文；最终报告必须由分析代理读取仓库网页或本地 checkout，固定 commit 后把差异映射到具体 symbol/行号。",
                "",
            ]
        )
    else:
        lines.extend(["`未知`：用户未提供模型代码仓，当前只能做 Profiler 证据层比较。", ""])
    lines.extend(
        [
            "## 7. 强制解释边界",
            "",
            "- 时间解释不是“是”时，CSV 中的算术比率只能用于定位，不能写成仿真精度或性能结论。",
            "- 算子/Shape/count 一致表示路径 ABI 更接近，不表示 tensor value、routing、address 或 cache state 一致。",
            "- 仿真可能不建模真实频率、cache、链路竞争、同步和 overlap；必须分别评价结构保真度与时间保真度。",
            "- HCCL kernel duration 不等于链路 transit；通信比较优先使用 communication.json/matrix。",
            "",
        ]
    )
    return "\n".join(lines)


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--real", required=True, type=Path, help="显式标注的真机 Profiling 根目录（reference）")
    parser.add_argument("--sim", required=True, type=Path, help="显式标注的仿真 Profiling 根目录（candidate）")
    parser.add_argument("--output", required=True, type=Path, help="位于两侧原始目录之外的输出目录")
    parser.add_argument("--top", type=int, default=500, help="每个单环境保留的 Top N，默认 500")
    parser.add_argument("--real-model", default="", help="真机模型标识")
    parser.add_argument("--sim-model", default="", help="仿真模型标识")
    parser.add_argument("--real-workload-id", default="", help="真机工作负载/请求标识")
    parser.add_argument("--sim-workload-id", default="", help="仿真工作负载/请求标识")
    parser.add_argument("--real-phase", default="", help="真机阶段，如 prefill/decode")
    parser.add_argument("--sim-phase", default="", help="仿真阶段，如 prefill/decode")
    parser.add_argument("--real-schedule-id", default="", help="真机 Profiler schedule/窗口标识")
    parser.add_argument("--sim-schedule-id", default="", help="仿真 Profiler schedule/窗口标识")
    parser.add_argument("--real-rank", default="", help="可选：真机 Rank label/global rank/ASCEND_PROFILER_OUTPUT 路径")
    parser.add_argument("--sim-rank", default="", help="可选：仿真 Rank label/global rank/ASCEND_PROFILER_OUTPUT 路径")
    parser.add_argument("--thread-seed", type=int, default=0, help="process-thread 可复现随机选择 seed，默认 0")
    parser.add_argument("--real-pid", default="", help="可选：显式指定真机 process pid（需同时指定 --real-tid）")
    parser.add_argument("--real-tid", default="", help="可选：显式指定真机 thread tid（需同时指定 --real-pid）")
    parser.add_argument("--sim-pid", default="", help="可选：显式指定仿真 process pid（需同时指定 --sim-tid）")
    parser.add_argument("--sim-tid", default="", help="可选：显式指定仿真 thread tid（需同时指定 --sim-pid）")
    parser.add_argument("--heatmap-bins", type=int, default=64, help="线程算子热力图时间分桶数，默认 64")
    parser.add_argument("--code-repo", default="", help="可选的 GitHub/GitCode/本地代码 locator，可指向仓、.sh 或目录")
    parser.add_argument("--code-ref", default="", help="可选的 commit/tag/branch")
    parser.add_argument("--code-entry", default="", help="可选的共用入口线索，可为 .sh、全是 .sh 的目录、Python 文件/模块")
    parser.add_argument("--real-code-repo", default="", help="可选的真机代码仓；覆盖 --code-repo")
    parser.add_argument("--sim-code-repo", default="", help="可选的仿真代码仓；覆盖 --code-repo")
    parser.add_argument("--real-code-ref", default="", help="可选的真机 commit/tag/branch；覆盖 --code-ref")
    parser.add_argument("--sim-code-ref", default="", help="可选的仿真 commit/tag/branch；覆盖 --code-ref")
    parser.add_argument("--real-code-entry", default="", help="可选的真机入口线索；覆盖 --code-entry")
    parser.add_argument("--sim-code-entry", default="", help="可选的仿真入口线索；覆盖 --code-entry")
    parser.add_argument("--skip-extraction", action="store_true", help="复用 output/extracted 下已有的 real/sim 摘要")
    args = parser.parse_args()

    try:
        real_root, sim_root, output = resolve_roots(args.real, args.sim, args.output)
    except ValueError as exc:
        parser.error(str(exc))
    if args.top <= 0 or args.heatmap_bins <= 0:
        parser.error("--top 和 --heatmap-bins 必须为正数")
    for role, pid, tid in (("真机", args.real_pid, args.real_tid), ("仿真", args.sim_pid, args.sim_tid)):
        if bool(clean(pid)) != bool(clean(tid)):
            parser.error(f"{role}显式线程必须同时提供 pid 和 tid")
    source_bindings = source_binding_rows(args)
    try:
        validate_code_output_separation(source_bindings, output)
    except ValueError as exc:
        parser.error(str(exc))

    analyzer = Path(__file__).with_name("summarize_ascend_profile.py")
    if not analyzer.is_file():
        parser.error(f"缺少内置单环境分析器：{analyzer}")
    real_extracted = output / "extracted" / "real"
    sim_extracted = output / "extracted" / "sim"
    output.mkdir(parents=True, exist_ok=True)
    comparison_dir = output / "comparison"
    comparison_dir.mkdir(parents=True, exist_ok=True)
    run_id = hashlib.sha256(
        f"{os.getpid()}|{time.time_ns()}|{real_root}|{sim_root}|{output}".encode("utf-8")
    ).hexdigest()[:20]
    write_json(
        comparison_dir / "comparison_manifest.json",
        {
            "schema_version": 3,
            "status": "running",
            "run_id": run_id,
            "language": "zh-CN",
            "real_root": str(real_root),
            "sim_root": str(sim_root),
            "message": "本次对比尚未完成；报告渲染器必须拒绝读取此状态",
        },
    )
    stale_perfetto = comparison_dir / "perfetto"
    if stale_perfetto.exists():
        try:
            remove_generated_tree(stale_perfetto, comparison_dir)
        except ValueError as exc:
            parser.error(str(exc))
    stale_reports = output / "reports"
    if stale_reports.exists():
        try:
            remove_generated_tree(stale_reports, output)
        except ValueError as exc:
            parser.error(str(exc))
    try:
        real_rank_candidates = discover_rank_candidates(real_root, "real/reference/真机")
        sim_rank_candidates = discover_rank_candidates(sim_root, "sim/candidate/仿真")
        selected_rank_pair = select_rank_pair(
            real_rank_candidates,
            sim_rank_candidates,
            args.real_rank,
            args.sim_rank,
        )
    except ValueError as exc:
        parser.error(str(exc))
    selected_real_source = Path(str(selected_rank_pair["real"]["source"])).resolve(strict=True)
    selected_sim_source = Path(str(selected_rank_pair["sim"]["source"])).resolve(strict=True)
    if paths_overlap(selected_real_source, selected_sim_source):
        parser.error(
            "选中的真机与仿真 Rank 输出相同或互为祖先；拒绝继续，避免重复比较或清理原始输入"
        )
    full_topology_context = real_rank_candidates + sim_rank_candidates
    write_csv(comparison_dir / "full_topology_context.csv", full_topology_context)
    write_csv(comparison_dir / "selected_rank_pair.csv", [rank_pair_csv_row(selected_rank_pair)])
    write_json(comparison_dir / "selected_rank_pair.json", selected_rank_pair)
    if not args.skip_extraction:
        run_analyzer(analyzer, Path(str(selected_rank_pair["real"]["source"])), real_extracted, args.top)
        run_analyzer(analyzer, Path(str(selected_rank_pair["sim"]["source"])), sim_extracted, args.top)
    for role, path, expected_source in (
        ("真机", real_extracted, selected_rank_pair["real"]["source"]),
        ("仿真", sim_extracted, selected_rank_pair["sim"]["source"]),
    ):
        if not (path / "summary.json").exists():
            parser.error(f"{role}抽取结果不存在：{path}；请移除 --skip-extraction 或先生成摘要")
        try:
            validate_comparison_extraction(path, role)
        except ValueError as exc:
            parser.error(str(exc))
        if args.skip_extraction:
            source_root = clean(read_json(path / "summary.json", {}).get("source_root"))
            if Path(source_root).resolve() != Path(str(expected_source)).resolve():
                parser.error(
                    f"{role} --skip-extraction 摘要不是本次选中 Rank：{source_root} != {expected_source}"
                )

    communication_axis_status = [
        enrich_selected_rank_communication_axes(
            real_extracted, real_rank_candidates, "real/reference/真机"
        ),
        enrich_selected_rank_communication_axes(
            sim_extracted, sim_rank_candidates, "sim/candidate/仿真"
        ),
    ]
    write_json(comparison_dir / "communication_axis_enrichment.json", communication_axis_status)

    gates = topology_gates(selected_rank_pair, real_rank_candidates, sim_rank_candidates)
    rank_alignment = rank_alignment_rows(selected_rank_pair)
    input_rows = profile_inputs(args)
    input_gates = compare_profile_inputs(input_rows)
    for row in input_gates:
        row["gate"] = "explicit_pair_input"
        row["impact"] = "不一致或未确认时不能解释时间保真度"
    coverage, coverage_mismatch, coverage_missing_both = coverage_gates(real_extracted, sim_extracted)
    timing_allowed = timing_gate(
        gates,
        input_gates,
        coverage_mismatch,
        coverage_missing_both,
    )
    source_resolver = Path(__file__).with_name("resolve_source_entrypoints.py")
    if not source_resolver.is_file():
        parser.error(f"缺少内置源码入口静态解析器：{source_resolver}")
    try:
        source_analysis_status = run_local_source_resolution(
            source_resolver,
            source_bindings,
            comparison_dir / "source_analysis",
        )
    except ValueError as exc:
        parser.error(str(exc))
    thread_analyzer = Path(__file__).with_name("analyze_trace_threads.py")
    try:
        thread_analysis_status = run_thread_analysis(
            thread_analyzer,
            selected_rank_pair,
            comparison_dir,
            args,
        )
    except RuntimeError as exc:
        parser.error(str(exc))
    thread_analysis_status["run_id"] = run_id
    write_json(comparison_dir / "thread_analysis_status.json", thread_analysis_status)
    phase_observations, runtime_phase_gate = infer_runtime_phase(
        comparison_dir,
        args.real_phase,
        args.sim_phase,
    )
    input_gates.append(runtime_phase_gate)
    write_csv(comparison_dir / "runtime_phase_evidence.csv", phase_observations)
    write_json(
        comparison_dir / "runtime_phase_evidence.json",
        {"observations": phase_observations, "gate": runtime_phase_gate},
    )
    # The initial gate is needed before thread extraction, but the final timing
    # decision must also respect what the selected trace actually executed.
    timing_allowed = timing_gate(
        gates,
        input_gates,
        coverage_mismatch,
        coverage_missing_both,
    )
    source_mapper = Path(__file__).with_name("map_thread_operators_to_source.py")
    if not source_mapper.is_file():
        parser.error(f"缺少内置线程算子源码映射器：{source_mapper}")
    source_mapping_status = run_local_source_mapping(
        source_mapper,
        source_analysis_status,
        comparison_dir,
        thread_analysis_status,
    )
    perfetto_review_path = comparison_dir / "perfetto_visual_review.json"
    write_json(
        perfetto_review_path,
        {
            "status": "待内容复核" if thread_analysis_status.get("status") == "完成" else "未执行",
            "review_methods": [],
            "html_reviewed": False,
            "sql_reviewed": False,
            "screenshot_reviewed": False,
            "reviewed_environments": [],
            "observations": {},
            "ui": "https://ui.perfetto.dev/",
            "instructions": "使用 render_perfetto_trace.mjs 分别加载两侧本地 trace；先验证 offline_before_trace_post 和 Service Worker 阻断，再实际读取 SQL 热点表、HTML 或文本；截图仅在需要判断 Canvas 布局时查看",
            "evidence_boundary": "HTML/文本/SQL 可用于算子与表格内容复核；Perfetto 时间线为 Canvas，未查看截图时不得评价颜色、条块或轨道几何；数值以本地 trace CSV 或 Perfetto SQL 为准",
        },
    )

    pytorch_metrics = [
        "calls",
        "host_self_us_total",
        "host_total_us_total",
        "device_self_us_total",
        "device_total_us_total",
        "device_aicore_self_us_total",
        "host_self_us_per_call",
        "device_self_us_per_call",
    ]
    pytorch_text = ["operator_family", "call_stack_id", "call_stack_sample"]
    real_pytorch = aggregate_rows(
        collect_rank_csv(real_extracted, "pytorch_operator_shapes.csv"),
        pytorch_key,
        pytorch_metrics,
        pytorch_text,
    )
    sim_pytorch = aggregate_rows(
        collect_rank_csv(sim_extracted, "pytorch_operator_shapes.csv"),
        pytorch_key,
        pytorch_metrics,
        pytorch_text,
    )
    for grouped in (real_pytorch, sim_pytorch):
        add_per_call_metric(grouped, "host_self_us_total", "host_self_us_per_call")
        add_per_call_metric(grouped, "device_self_us_total", "device_self_us_per_call")
    pytorch = compare_grouped(real_pytorch, sim_pytorch, ["rank_alignment_key", "operator", "input_shapes"], pytorch_metrics, pytorch_text, timing_allowed)
    add_effect_decomposition(pytorch, "device_self_us_total", "device_self_us_per_call")
    add_effect_decomposition(pytorch, "host_self_us_total", "host_self_us_per_call")

    device_metrics = [
        "calls",
        "duration_us_total",
        "duration_us_per_call",
        "duration_us_max",
        "wait_us_total",
    ]
    real_device = aggregate_rows(
        collect_rank_csv(real_extracted, "device_operator_shapes.csv"),
        device_key,
        device_metrics,
        [],
    )
    sim_device = aggregate_rows(
        collect_rank_csv(sim_extracted, "device_operator_shapes.csv"),
        device_key,
        device_metrics,
        [],
    )
    for grouped in (real_device, sim_device):
        add_per_call_metric(grouped, "duration_us_total", "duration_us_per_call")
    device = compare_grouped(
        real_device,
        sim_device,
        [
            "rank_alignment_key",
            "operator",
            "type",
            "input_shapes",
            "output_shapes",
            "input_dtypes",
            "output_dtypes",
            "accelerator_core",
            "input_formats",
            "output_formats",
        ],
        device_metrics,
        [],
        timing_allowed,
    )
    add_effect_decomposition(device, "duration_us_total", "duration_us_per_call")

    real_communication_kernels = aggregate_rows(
        collect_rank_csv(real_extracted, "communication_kernel_shapes.csv"),
        device_key,
        device_metrics,
        ["steps"],
    )
    sim_communication_kernels = aggregate_rows(
        collect_rank_csv(sim_extracted, "communication_kernel_shapes.csv"),
        device_key,
        device_metrics,
        ["steps"],
    )
    for grouped in (real_communication_kernels, sim_communication_kernels):
        add_per_call_metric(grouped, "duration_us_total", "duration_us_per_call")
    communication_kernels = compare_grouped(
        real_communication_kernels,
        sim_communication_kernels,
        [
            "rank_alignment_key",
            "operator",
            "type",
            "input_shapes",
            "output_shapes",
            "input_dtypes",
            "output_dtypes",
            "accelerator_core",
            "input_formats",
            "output_formats",
        ],
        device_metrics,
        ["steps"],
        timing_allowed,
    )
    add_effect_decomposition(communication_kernels, "duration_us_total", "duration_us_per_call")

    comm_metrics = [
        "calls",
        "wait_ms_total",
        "synchronization_ms_total",
        "transit_ms_total",
        "transit_size_mb_total",
        "weighted_bandwidth_gb_s",
        "wait_ms_per_call",
        "transit_ms_per_call",
        "transit_size_mb_per_call",
    ]
    real_comm_rows = collect_rank_csv(real_extracted, "communication_summary.csv")
    sim_comm_rows = collect_rank_csv(sim_extracted, "communication_summary.csv")
    real_comm = aggregate_rows(real_comm_rows, communication_key, comm_metrics, ["steps"])
    sim_comm = aggregate_rows(sim_comm_rows, communication_key, comm_metrics, ["steps"])
    for grouped in (real_comm, sim_comm):
        add_per_call_metric(grouped, "wait_ms_total", "wait_ms_per_call")
        add_per_call_metric(grouped, "transit_ms_total", "transit_ms_per_call")
        add_per_call_metric(grouped, "transit_size_mb_total", "transit_size_mb_per_call")
    communication = compare_grouped(real_comm, sim_comm, ["rank_alignment_key", "category", "collective_type", "communication_group", "parallel_axis"], comm_metrics, ["steps"], timing_allowed)
    add_effect_decomposition(communication, "transit_ms_total", "transit_ms_per_call")
    add_effect_decomposition(communication, "wait_ms_total", "wait_ms_per_call")

    # Raw HCCL group ids are process-local handles and routinely differ across
    # real/simulation runs.  Preserve the raw-group table above for audit, but
    # build the primary cross-environment fidelity layer at collective+axis
    # granularity so different numeric handles do not turn every collective
    # into a false presence mismatch.
    real_collectives = aggregate_rows(
        real_comm_rows,
        communication_collective_key,
        comm_metrics,
        ["communication_group", "steps"],
    )
    sim_collectives = aggregate_rows(
        sim_comm_rows,
        communication_collective_key,
        comm_metrics,
        ["communication_group", "steps"],
    )
    for grouped in (real_collectives, sim_collectives):
        add_per_call_metric(grouped, "wait_ms_total", "wait_ms_per_call")
        add_per_call_metric(grouped, "transit_ms_total", "transit_ms_per_call")
        add_per_call_metric(grouped, "transit_size_mb_total", "transit_size_mb_per_call")
    communication_collectives = compare_grouped(
        real_collectives,
        sim_collectives,
        ["rank_alignment_key", "category", "collective_type", "parallel_axis"],
        comm_metrics,
        ["communication_group", "steps"],
        timing_allowed,
    )
    add_effect_decomposition(
        communication_collectives, "transit_ms_total", "transit_ms_per_call"
    )
    add_effect_decomposition(communication_collectives, "wait_ms_total", "wait_ms_per_call")

    link_metrics = ["transit_ms", "transit_size_mb", "bandwidth_gb_s"]
    real_links = aggregate_rows(
        collect_rank_csv(real_extracted, "communication_matrix_links.csv"),
        communication_link_key,
        link_metrics,
        ["transport_type", "source_op_name"],
    )
    sim_links = aggregate_rows(
        collect_rank_csv(sim_extracted, "communication_matrix_links.csv"),
        communication_link_key,
        link_metrics,
        ["transport_type", "source_op_name"],
    )
    communication_links = compare_grouped(
        real_links,
        sim_links,
        [
            "rank_alignment_key",
            "category",
            "collective_type",
            "communication_group",
            "parallel_axis",
            "link",
        ],
        link_metrics,
        ["transport_type", "source_op_name"],
        timing_allowed,
    )

    step_metrics = ["computing_us", "communication_us", "communication_not_overlapped_us", "overlapped_us", "free_us", "stage_us", "bubble_us", "preparing_us"]
    real_step_rows = step_rows_with_ordinal(read_csv(real_extracted / "step_trace_all_ranks.csv"))
    sim_step_rows = step_rows_with_ordinal(read_csv(sim_extracted / "step_trace_all_ranks.csv"))
    real_step = aggregate_rows(real_step_rows, step_key, step_metrics, ["step"])
    sim_step = aggregate_rows(sim_step_rows, step_key, step_metrics, ["step"])
    step = compare_grouped(real_step, sim_step, ["rank_alignment_key", "step_ordinal"], step_metrics, ["step"], timing_allowed)
    window_alignment = [
        {
            "rank_alignment_key": row.get("rank_alignment_key", ""),
            "step_ordinal": row.get("step_ordinal", ""),
            "presence": row.get("presence", ""),
            "real_step": row.get("real_step", "[]"),
            "sim_step": row.get("sim_step", "[]"),
            "alignment_method": "同 rank 内语义阶段确认后按 ordinal；当前脚本只给候选",
            "timing_interpretation_allowed": timing_allowed,
        }
        for row in step
    ]

    memory_metrics = ["max_allocated_mb", "max_reserved_mb", "max_active_mb"]
    real_memory = aggregate_rows(read_csv(real_extracted / "memory_peaks_all_ranks.csv"), memory_key, memory_metrics, ["device_type"])
    sim_memory = aggregate_rows(read_csv(sim_extracted / "memory_peaks_all_ranks.csv"), memory_key, memory_metrics, ["device_type"])
    memory = compare_grouped(
        real_memory,
        sim_memory,
        ["rank_alignment_key", "component", "device_type"],
        memory_metrics,
        [],
        timing_allowed,
    )

    for rows in (
        pytorch,
        device,
        communication_kernels,
        communication,
        communication_collectives,
        communication_links,
        step,
        window_alignment,
        memory,
    ):
        annotate_comparison_rank(rows, selected_rank_pair)

    comparison_dir = output / "comparison"
    write_csv(comparison_dir / "comparability_gates.csv", gates + input_gates)
    write_csv(comparison_dir / "rank_alignment.csv", rank_alignment)
    write_csv(comparison_dir / "window_alignment.csv", window_alignment)
    write_csv(comparison_dir / "coverage_comparison.csv", coverage)
    write_csv(comparison_dir / "source_bindings.csv", source_bindings)
    write_csv(comparison_dir / "pytorch_operator_comparison.csv", pytorch)
    write_csv(comparison_dir / "device_operator_comparison.csv", device)
    write_csv(comparison_dir / "communication_kernel_comparison.csv", communication_kernels)
    write_csv(comparison_dir / "communication_comparison.csv", communication)
    write_csv(
        comparison_dir / "communication_collective_comparison.csv",
        communication_collectives,
    )
    write_csv(comparison_dir / "communication_link_comparison.csv", communication_links)
    write_csv(comparison_dir / "step_comparison.csv", step)
    write_csv(comparison_dir / "memory_comparison.csv", memory)

    unmatched = []
    for dimension, rows in (
        ("pytorch", pytorch),
        ("device", device),
        ("communication_kernel", communication_kernels),
        ("communication", communication),
        ("communication_collective", communication_collectives),
        ("communication_link", communication_links),
        ("step", step),
        ("memory", memory),
    ):
        for row in rows:
            if row.get("presence") != "两侧存在":
                unmatched.append({"dimension": dimension, **row})
    write_csv(comparison_dir / "unmatched_entities.csv", unmatched)

    summaries = [
        mismatch_summary("PyTorch operator", pytorch),
        mismatch_summary("device operator", device),
        mismatch_summary("communication kernel", communication_kernels),
        mismatch_summary("communication", communication_collectives),
        mismatch_summary("communication link", communication_links),
        mismatch_summary("step", step),
        mismatch_summary("memory", memory),
    ]
    manifest = {
        "schema_version": 3,
        "status": "complete",
        "run_id": run_id,
        "language": "zh-CN",
        "roles": {"real": "reference/真机", "sim": "candidate/仿真"},
        "difference_direction": "sim - real",
        "ratio_direction": "sim / real",
        "real_root": str(real_root),
        "sim_root": str(sim_root),
        "real_extracted": str(real_extracted),
        "sim_extracted": str(sim_extracted),
        "analysis_scope": "每侧一个选定 Rank；每侧选定 Rank 内一个 process-thread",
        "selected_rank_pair": rank_pair_csv_row(selected_rank_pair),
        "thread_analysis": thread_analysis_status,
        "runtime_phase_evidence": phase_observations,
        "timing_interpretation_allowed": timing_allowed,
        "explicit_pair_inputs": input_rows,
        "source_bindings": source_bindings,
        "source_analysis": source_analysis_status,
        "source_mapping": source_mapping_status,
        "communication_axis_enrichment": communication_axis_status,
        "summary": summaries,
    }
    write_csv(comparison_dir / "comparison_summary.csv", summaries)
    write_csv(
        comparison_dir / "comparison_manifest.csv",
        [
            {
                "status": "complete",
                "run_id": run_id,
                "environment": "real/reference/真机",
                "profiling_root": str(real_root),
                "selected_rank_output": selected_rank_pair["real"]["source"],
                "extracted_root": str(real_extracted),
                "difference_direction": "sim - real",
                "ratio_direction": "sim / real",
                "timing_interpretation_allowed": timing_allowed,
            },
            {
                "status": "complete",
                "run_id": run_id,
                "environment": "sim/candidate/仿真",
                "profiling_root": str(sim_root),
                "selected_rank_output": selected_rank_pair["sim"]["source"],
                "extracted_root": str(sim_extracted),
                "difference_direction": "sim - real",
                "ratio_direction": "sim / real",
                "timing_interpretation_allowed": timing_allowed,
            },
        ],
    )
    write_json(comparison_dir / "comparison_manifest.json", manifest)
    write_json(
        comparison_dir / "comparison_summary.json",
        {
            "gates": gates + input_gates,
            "coverage_primary_mismatches": coverage_mismatch,
            "coverage_primary_missing_on_both": coverage_missing_both,
            "dimensions": summaries,
        },
    )
    (comparison_dir / "comparison_summary.md").write_text(
        build_summary(
            real_root,
            sim_root,
            gates,
            input_gates,
            coverage_mismatch,
            timing_allowed,
            summaries,
            pytorch,
            device,
            communication_collectives,
            step,
            source_bindings,
        ),
        encoding="utf-8",
    )

    print(f"完成：真机(reference)={real_root}")
    print(f"完成：仿真(candidate)={sim_root}")
    print(f"时间比率解释：{timing_allowed}")
    print(f"请先阅读：{comparison_dir / 'comparison_summary.md'}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

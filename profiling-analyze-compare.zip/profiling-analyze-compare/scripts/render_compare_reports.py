#!/usr/bin/env python3
"""把 compare_ascend_profiles.py 的确定性结果渲染为六份中文主报告。"""

from __future__ import annotations

import argparse
import ast
import csv
import html
import json
import math
import re
from pathlib import Path
from typing import Any, Iterable


REPORT_NAMES = [
    "00_compare_executive_summary.md",
    "01_pair_identity_and_comparability.md",
    "02_pytorch_operator_fidelity.md",
    "03_execution_shape_and_path_fidelity.md",
    "04_communication_step_and_system_fidelity.md",
    "05_code_causality_and_actions.md",
]


def read_csv(path: Path) -> list[dict[str, str]]:
    if not path.is_file():
        return []
    with path.open("r", newline="", encoding="utf-8-sig", errors="replace") as handle:
        return [dict(row) for row in csv.DictReader(handle)]


def read_json(path: Path) -> dict[str, Any]:
    if not path.is_file():
        return {}
    with path.open("r", encoding="utf-8-sig", errors="replace") as handle:
        value = json.load(handle)
    return value if isinstance(value, dict) else {}


def read_json_value(path: Path, default: Any) -> Any:
    if not path.is_file():
        return default
    with path.open("r", encoding="utf-8-sig", errors="replace") as handle:
        return json.load(handle)


def read_json_rows(path: Path) -> list[dict[str, Any]]:
    value = read_json_value(path, [])
    if not isinstance(value, list):
        return []
    return [dict(row) for row in value if isinstance(row, dict)]


def clean(value: Any, limit: int = 240) -> str:
    text = "" if value is None else str(value).strip()
    text = re.sub(r"\s+", " ", text)
    if not text:
        return "未知"
    if len(text) <= 256 and text[:1] in "([\"'" and text[-1:] in ")]\"'":
        try:
            parsed = ast.literal_eval(text)
            if isinstance(parsed, (list, tuple)) and len(parsed) == 1:
                parsed = parsed[0]
            if isinstance(parsed, (str, int, float)):
                text = str(parsed)
        except (ValueError, SyntaxError, MemoryError, RecursionError):
            pass
    text = text if len(text) <= limit else text[: limit - 3] + "..."
    # Trace/source strings are untrusted. Keep them inert in Markdown engines
    # that permit raw HTML, and prevent closing an enclosing code span.
    text = html.escape(text, quote=False).replace("`", "&#96;")
    text = text.replace("\\", "\\\\")
    for marker in ("!", "[", "]", "(", ")", "|"):
        text = text.replace(marker, "\\" + marker)
    return text


def number(value: Any) -> float | None:
    text = "" if value is None else str(value).strip().replace(",", "").rstrip("%")
    if text.lower() in {"", "未知", "缺失", "不可计算", "none", "null", "n/a", "na"}:
        return None
    try:
        parsed = float(text)
    except ValueError:
        return None
    return parsed if math.isfinite(parsed) else None


def md_table(
    rows: Iterable[dict[str, Any]],
    columns: list[tuple[str, str]],
    limit: int | None = None,
) -> str:
    materialized = list(rows)
    if limit is not None:
        materialized = materialized[:limit]
    if not materialized:
        return "_无可用数据_\n"
    lines = [
        "| " + " | ".join(title for _, title in columns) + " |",
        "|" + "|".join(["---"] * len(columns)) + "|",
    ]
    for row in materialized:
        lines.append("| " + " | ".join(clean(row.get(field)) for field, _ in columns) + " |")
    return "\n".join(lines) + "\n"


def deviation_score(row: dict[str, Any]) -> float:
    score = 1e15 if row.get("presence") not in {"", None, "两侧存在"} else 0.0
    for field, value in row.items():
        if field.endswith("_delta_percent"):
            parsed = number(value)
            if parsed is not None:
                score = max(score, abs(parsed))
    return score


def ranked(rows: list[dict[str, Any]]) -> list[dict[str, Any]]:
    return sorted(rows, key=deviation_score, reverse=True)


def metric_hotness(row: dict[str, Any], *fields: str) -> float:
    values = [number(row.get(field)) for field in fields]
    return max((abs(value) for value in values if value is not None), default=-1.0)


def concrete_pytorch_operator(value: Any) -> bool:
    name = str(value or "").strip().casefold()
    return name.startswith(("aten::", "prims::", "torch::", "torch_npu::", "npu::"))


def presence_counts(rows: list[dict[str, Any]]) -> tuple[int, int, int]:
    return (
        sum(row.get("presence") == "两侧存在" for row in rows),
        sum(row.get("presence") == "仅真机" for row in rows),
        sum(row.get("presence") == "仅仿真" for row in rows),
    )


def hot_thread_rows(rows: list[dict[str, Any]], side: str) -> list[dict[str, Any]]:
    field = f"{side}_self_us_total"
    return sorted(
        [row for row in rows if number(row.get(field)) is not None],
        key=lambda row: metric_hotness(row, field, f"{side}_inclusive_us_total"),
        reverse=True,
    )


def sequence_focus(rows: list[dict[str, Any]], limit: int) -> list[dict[str, Any]]:
    differences = [row for row in rows if row.get("match_type") != "equal"]
    if not differences:
        return rows[:limit]
    selected: dict[int, dict[str, Any]] = {}
    indexes = {int(float(row.get("diff_index", 0) or 0)) for row in differences[:limit]}
    for row in rows:
        index = int(float(row.get("diff_index", 0) or 0))
        if any(abs(index - target) <= 1 for target in indexes):
            selected[index] = row
    return [selected[index] for index in sorted(selected)][:limit]


def aggregate_heatmap_rows(rows: list[dict[str, Any]]) -> list[dict[str, Any]]:
    grouped: dict[tuple[str, str, str, str, str], dict[str, Any]] = {}
    for source in rows:
        key = (
            str(source.get("environment", "")),
            str(source.get("bin_index", "")),
            str(source.get("operator", "")),
            str(source.get("input_shapes", "")),
            str(source.get("output_shapes", "")),
        )
        if key not in grouped:
            grouped[key] = dict(source)
            row = grouped[key]
        else:
            row = grouped[key]
            for field in ("inclusive_overlap_us", "deepest_exclusive_us", "exclusive_us", "share_of_bin_percent"):
                row[field] = (number(row.get(field)) or 0.0) + (number(source.get(field)) or 0.0)
            row["call_count_overlapping"] = max(
                number(row.get("call_count_overlapping")) or 0.0,
                number(source.get("call_count_overlapping")) or 0.0,
            )
        if str(row.get("operator")) == "<未归属>":
            row["coverage_kind"] = "unattributed_gap"
            row["is_dominant"] = "否"
        else:
            row["coverage_kind"] = row.get("coverage_kind") or "pytorch_operator"
    return list(grouped.values())


def perfetto_sql_hotspots(runs: list[dict[str, Any]], limit_per_side: int = 8) -> list[dict[str, Any]]:
    output: list[dict[str, Any]] = []
    for run in runs:
        value = run.get("sql_rows")
        try:
            table = json.loads(value) if isinstance(value, str) else value
        except json.JSONDecodeError:
            continue
        if not isinstance(table, list) or len(table) < 2 or not isinstance(table[0], list):
            continue
        headers = [str(item) for item in table[0]]
        for values in table[1 : 1 + limit_per_side]:
            if not isinstance(values, list):
                continue
            item = {header: values[index] if index < len(values) else "" for index, header in enumerate(headers)}
            output.append(
                {
                    "environment": run.get("environment", ""),
                    "operator": item.get("operator", ""),
                    "calls": item.get("calls", ""),
                    "total_ms": item.get("total_ms", ""),
                    "avg_ms": item.get("avg_ms", ""),
                    "max_ms": item.get("max_ms", ""),
                }
            )
    return output


def perfetto_review_statuses(
    automation_status: str,
    review: dict[str, Any],
) -> tuple[str, str, list[str]]:
    """Return content status, optional Canvas status, and normalized review methods."""
    reviewed_environments = review.get("reviewed_environments", [])
    if not isinstance(reviewed_environments, list):
        reviewed_environments = []
    methods = review.get("review_methods", [])
    if not isinstance(methods, list):
        methods = []
    normalized_methods = {
        str(item).strip().lower() for item in methods if str(item).strip()
    }
    for field, method in (
        ("html_reviewed", "html"),
        ("sql_reviewed", "sql"),
        ("screenshot_reviewed", "screenshot"),
    ):
        if review.get(field) is True:
            normalized_methods.add(method)
    reviewed_sides = {str(item).strip().lower() for item in reviewed_environments}
    observations = review.get("observations")
    content_complete = bool(
        automation_status == "完成"
        and review.get("status") == "完成"
        and normalized_methods & {"html", "dom", "text", "sql", "screenshot"}
        and reviewed_sides >= {"real", "sim"}
        and observations
    )
    content_status = (
        "完成"
        if content_complete
        else "待内容复核"
        if automation_status == "完成"
        else "未执行/不完整"
    )
    screenshot_reviewed = review.get("screenshot_reviewed") is True
    canvas_complete = bool(
        automation_status == "完成"
        and screenshot_reviewed
        and reviewed_sides >= {"real", "sim"}
        and observations
    )
    canvas_status = (
        "完成"
        if canvas_complete
        else "记录不完整"
        if screenshot_reviewed
        else "未执行（可选，不影响内容复核）"
    )
    return content_status, canvas_status, sorted(normalized_methods)


def explicit_inputs(manifest: dict[str, Any]) -> dict[str, tuple[str, str]]:
    result: dict[str, tuple[str, str]] = {}
    for row in manifest.get("explicit_pair_inputs", []):
        if isinstance(row, dict):
            result[str(row.get("field", ""))] = (str(row.get("real", "")), str(row.get("sim", "")))
    return result


def common_header(
    title: str,
    manifest: dict[str, Any],
    thread_status: dict[str, Any] | None = None,
) -> str:
    scope = clean(manifest.get("analysis_scope", "每侧一个选定 Rank"))
    if thread_status and thread_status.get("status") != "完成":
        scope = "每侧一个选定 Rank；线程分析受限，未选择 process-thread"
    return "\n".join(
        [
            f"# {title}",
            "",
            f"> 真机（reference）：`{clean(manifest.get('real_root'), 1000)}`  ",
            f"> 仿真（candidate）：`{clean(manifest.get('sim_root'), 1000)}`  ",
            "> 差值方向：`仿真 - 真机`；比率方向：`仿真 / 真机`。  ",
            f"> 分析范围：`{scope}`。  ",
            f"> 时间解释门禁：`{clean(manifest.get('timing_interpretation_allowed'))}`。",
            "",
        ]
    )


def summary_map(rows: list[dict[str, str]]) -> dict[str, dict[str, str]]:
    return {row.get("dimension", ""): row for row in rows}


def metric_pair(row: dict[str, str], field: str, unit: str = "") -> str:
    real = clean(row.get(f"real_{field}"))
    sim = clean(row.get(f"sim_{field}"))
    suffix = f" {unit}" if unit else ""
    return f"{real}{suffix} / {sim}{suffix}"


def evidence_pair(row: dict[str, str]) -> str:
    return f"真机 {clean(row.get('real_evidence'), 140)}；仿真 {clean(row.get('sim_evidence'), 140)}"


def notable_items(
    thread: list[dict[str, str]],
    pytorch: list[dict[str, str]],
    device: list[dict[str, str]],
    communication: list[dict[str, str]],
    step: list[dict[str, str]],
) -> list[str]:
    items: list[str] = []
    thread_ranked = sorted(
        [row for row in thread if concrete_pytorch_operator(row.get("operator"))],
        key=lambda row: (
            row.get("presence") != "两侧存在",
            metric_hotness(row, "real_self_us_total", "sim_self_us_total"),
        ),
        reverse=True,
    )
    for row in thread_ranked[:2]:
        items.append(
            f"所选线程 PyTorch `{clean(row.get('operator'))}`，Shape `{clean(row.get('input_shapes'))}`，"
            f"presence={clean(row.get('presence'))}，exclusive 真/仿="
            f"{metric_pair(row, 'self_us_total', 'us')}，Calls 真/仿={metric_pair(row, 'calls')}。"
        )
    matched_pytorch = sorted(
        [
            row
            for row in pytorch
            if row.get("presence") == "两侧存在" and concrete_pytorch_operator(row.get("operator"))
        ],
        key=lambda row: metric_hotness(
            row,
            "device_self_us_total_delta_percent",
            "real_device_self_us_total",
            "sim_device_self_us_total",
        ),
        reverse=True,
    )
    for row in matched_pytorch[:1]:
        text = (
            f"PyTorch `{clean(row.get('operator'))}`，Shape `{clean(row.get('input_shapes'))}`，"
            f"presence={clean(row.get('presence'))}，Device Self 真/仿="
            f"{metric_pair(row, 'device_self_us_total', 'us')}，仿真/真机="
            f"{clean(row.get('device_self_us_total_sim_over_real'))}。"
        )
        items.append(text)
    for row in ranked(device)[:1]:
        text = (
            f"执行算子 `{clean(row.get('operator'))}`，I/O Shape "
            f"`{clean(row.get('input_shapes'))} -> {clean(row.get('output_shapes'))}`，"
            f"presence={clean(row.get('presence'))}，duration 真/仿="
            f"{metric_pair(row, 'duration_us_total', 'us')}，仿真/真机="
            f"{clean(row.get('duration_us_total_sim_over_real'))}。"
        )
        items.append(text)
    for row in ranked(communication)[:1]:
        text = (
            f"通信汇总 `{clean(row.get('collective_type'))}` / 轴 `{clean(row.get('parallel_axis'))}`，"
            f"presence={clean(row.get('presence'))}，message 真/仿="
            f"{metric_pair(row, 'transit_size_mb_total', 'MB')}，transit 仿真/真机="
            f"{clean(row.get('transit_ms_total_sim_over_real'))}。"
        )
        items.append(text)
    for row in ranked(step)[:1]:
        text = (
            f"Step ordinal `{clean(row.get('step_ordinal'))}`，原始 Step 真/仿="
            f"{clean(row.get('real_step'))} / {clean(row.get('sim_step'))}，Stage 真/仿="
            f"{metric_pair(row, 'stage_us', 'us')}，仿真/真机={clean(row.get('stage_us_sim_over_real'))}。"
        )
        items.append(text)
    return items[:5]


def report_00(data: dict[str, Any], top: int) -> str:
    manifest = data["manifest"]
    thread_status = data["thread_status"]
    thread_completed = thread_status.get("status") == "完成"
    timing = str(manifest.get("timing_interpretation_allowed", "未知"))
    inputs = explicit_inputs(manifest)
    summaries = summary_map(data["summary"])
    unmatched = sum(int(float(row.get("presence_mismatches", 0) or 0)) for row in data["summary"])
    pytorch_summary = summaries.get("PyTorch operator", {})
    device_summary = summaries.get("device operator", {})
    comm_summary = summaries.get("communication", {})
    executive_pytorch = [
        row for row in data["pytorch"] if concrete_pytorch_operator(row.get("operator"))
    ]
    executive_scopes = [
        row for row in data["pytorch"] if not concrete_pytorch_operator(row.get("operator"))
    ]
    pytorch_matched, pytorch_only_real, pytorch_only_sim = presence_counts(executive_pytorch)
    scope_matched, scope_only_real, scope_only_sim = presence_counts(executive_scopes)
    device_matched, device_only_real, device_only_sim = presence_counts(data["device"])
    comm_matched, comm_only_real, comm_only_sim = presence_counts(data["communication_collectives"])
    phase_gate = next(
        (row for row in data["gates"] if row.get("gate") == "runtime_phase_evidence"), {}
    )
    selected_rank = data["selected_rank"][0] if data["selected_rank"] else {}
    selected_threads = data["selected_thread"]
    real_thread = next((row for row in selected_threads if row.get("environment", "").startswith("real")), {})
    sim_thread = next((row for row in selected_threads if row.get("environment", "").startswith("sim")), {})
    thread_identity = (
        f"- 单 process-thread 真/仿：`pid={clean(real_thread.get('pid'))}, tid={clean(real_thread.get('tid'))}` / "
        f"`pid={clean(sim_thread.get('pid'))}, tid={clean(sim_thread.get('tid'))}`；对齐置信度 "
        f"`{clean(real_thread.get('alignment_confidence') or sim_thread.get('alignment_confidence'))}`。"
        if thread_completed
        else f"- 线程分析受限，未选择 process-thread；原因：{clean(thread_status.get('reason'))}；影响：{clean(thread_status.get('impact'), 1000)}。缺失不等于零算子。"
    )
    scope_boundary = (
        "- `边界` 本报告只分析一个 Rank 和一个 process-thread；不得据此评价 rank imbalance 或其它线程的执行覆盖。"
        if thread_completed
        else "- `边界` Rank 已选，但 process-thread 未选；不能做线程级算子覆盖、热力图、逐线程源码映射或 Perfetto 内容复核，也不得把缺失解释为零算子。"
    )
    lines = [common_header("真机与仿真 Profiling 对比执行摘要", manifest, thread_status)]
    lines.extend(
        [
            "## 1. 身份与可比性",
            "",
            f"- 模型真/仿：`{clean(inputs.get('model', ('', ''))[0])}` / `{clean(inputs.get('model', ('', ''))[1])}`。",
            f"- Workload 真/仿：`{clean(inputs.get('workload_id', ('', ''))[0])}` / `{clean(inputs.get('workload_id', ('', ''))[1])}`。",
            f"- 阶段真/仿：`{clean(inputs.get('phase', ('', ''))[0])}` / `{clean(inputs.get('phase', ('', ''))[1])}`。",
            f"- Trace 运行阶段核验：`{clean(phase_gate.get('status'))}`；真机 `{clean(phase_gate.get('real'))}`，仿真 `{clean(phase_gate.get('sim'))}`。{clean(phase_gate.get('detail'))}",
            f"- Schedule 真/仿：`{clean(inputs.get('schedule_id', ('', ''))[0])}` / `{clean(inputs.get('schedule_id', ('', ''))[1])}`。",
            f"- 单 Rank 真/仿：`{clean(selected_rank.get('real_rank'))}` / `{clean(selected_rank.get('sim_rank'))}`；选择置信度 `{clean(selected_rank.get('confidence'))}`。",
            thread_identity,
            "",
            "## 2. 三层保真度结论",
            "",
            f"- `真机事实/仿真事实` 结构保真度：具体 PyTorch dispatcher 匹配/仅真/仅仿={pytorch_matched}/{pytorch_only_real}/{pytorch_only_sim}（module/autograd scope={scope_matched}/{scope_only_real}/{scope_only_sim}），device={device_matched}/{device_only_real}/{device_only_sim}，通信 collective 汇总={comm_matched}/{comm_only_real}/{comm_only_sim}。raw group 数字仅作环境内审计，不作为跨环境身份。",
            (
                "- `推断` 时间保真度：可在已对齐窗口内解释真/仿差值和比率；单次观测不代表统计分布或回归阈值。"
                if timing == "是"
                else f"- `未知` 时间保真度不可判定/待确认：门禁为 `{clean(timing)}`，表内比率仅用于定位，不能写成仿真性能准确度。"
            ),
            "- `未知` 系统建模保真度：当前对比不能单独证明真实频率、cache、stream 并发、链路竞争、allocator 与同步模型已被仿真覆盖。",
            "",
            "## 3. 五个最重要差异",
            "",
        ]
    )
    items = notable_items(
        data["thread_comparison"],
        data["pytorch"],
        data["device"],
        data["communication_collectives"],
        data["step"],
    )
    lines.extend([f"{index}. {item}" for index, item in enumerate(items, start=1)] or ["1. `未知`：没有可用对比实体。"])
    lines.extend(
        [
            "",
            "## 4. 端到端差异链",
            "",
            "`推断`：模型输入/配置或运行时 dispatch 差异，可能先改变 PyTorch operator、调用次数或 Shape bucket，再改变 device lowering/kernel/format，继而改变通信 message/group/等待与 overlap，最终反映到 Step Stage。当前只有 Profiler 事实；没有源码和 runtime guard 证据时，不能把该链写成已确认因果。",
            "",
            "## 5. 能复现、不能复现、尚未证明",
            "",
            "- `真机事实/仿真事实` 能复现：标为“两侧存在”的 operator、I/O ABI、通信实体和对齐 Step。",
            "- `真机事实/仿真事实` 不能直接复现：标为“仅真机”或“仅仿真”的实体；先排除采集覆盖、命名和窗口差异。",
            "- `未知` 尚未证明：tensor value、routing、KV/cache state、实际并发、频率、链路竞争、源码分支和端到端请求延迟。",
            scope_boundary,
            "",
            "## 6. 三个最小验证动作",
            "",
            "1. 用同一 request、phase、schedule、并行拓扑和 Profiler flags 重采，保留 request/phase marker。",
            "2. 对首个 unmatched PyTorch/Shape 路径做单算子或最小 A/B，记录 guard、输入 Shape、kernel 与通信 group。",
            "3. 固定两侧运行 commit/build ID，并对仿真器的 kernel、通信、并发、cache、频率和 allocator 建模范围逐项声明。",
            "",
        ]
    )
    return "\n".join(lines)


def report_01(data: dict[str, Any], top: int) -> str:
    manifest = data["manifest"]
    gates = data["gates"]
    coverage = data["coverage"]
    missing_or_mismatch = [row for row in coverage if row.get("match") != "是" or (row.get("real_present") != "是" and row.get("sim_present") != "是")]
    thread_status = data["thread_status"]
    real_thread_inventory = sum(row.get("environment", "").startswith("real") for row in data["thread_inventory"])
    sim_thread_inventory = sum(row.get("environment", "").startswith("sim") for row in data["thread_inventory"])
    real_thread_candidates = sum(
        row.get("environment", "").startswith("real") and row.get("candidate") == "是"
        for row in data["thread_inventory"]
    )
    sim_thread_candidates = sum(
        row.get("environment", "").startswith("sim") and row.get("candidate") == "是"
        for row in data["thread_inventory"]
    )
    if thread_status.get("status") == "完成":
        thread_selection_statement = (
            f"`事实`：process-thread inventory 真机 {real_thread_inventory} 个、仿真 {sim_thread_inventory} 个；"
            f"其中具体 PyTorch 算子候选真机 {real_thread_candidates} 个、仿真 {sim_thread_candidates} 个；最终每侧恰选一个。"
        )
    else:
        thread_selection_statement = (
            f"`受限`：process-thread inventory 真机 {real_thread_inventory} 个、仿真 {sim_thread_inventory} 个；"
            f"其中具体 PyTorch 算子候选真机 {real_thread_candidates} 个、仿真 {sim_thread_candidates} 个。"
            f"状态 `{clean(thread_status.get('status'))}`；原因：{clean(thread_status.get('reason'))}；"
            f"影响：{clean(thread_status.get('impact'), 1000)}。未选择线程，缺失不等于零算子。"
        )
    lines = [common_header("配对身份、采集覆盖与可比性", manifest, thread_status)]
    lines.extend(
        [
            "## 1. 可比性门禁",
            "",
            md_table(gates, [("gate", "门禁"), ("field", "输入字段"), ("real", "真机"), ("sim", "仿真"), ("status", "状态"), ("detail", "证据/说明"), ("impact", "对后续结论的影响")]),
            "## 2. Rank 与并行坐标映射",
            "",
            "`事实`：只抽取并比较下表中的一个 Rank pair；`full_topology_context.csv` 仅用于配对门禁，不会汇总其它 Rank 的算子时间。",
            "",
            md_table(data["selected_rank"], [("selection_method", "选择方法"), ("confidence", "置信度"), ("real_rank", "真机 Rank"), ("sim_rank", "仿真 Rank"), ("real_global_rank", "真机 global rank"), ("sim_global_rank", "仿真 global rank"), ("real_parallel_coordinate", "真机 DP/TP/EP/PP/CP/DCP"), ("sim_parallel_coordinate", "仿真 DP/TP/EP/PP/CP/DCP"), ("real_source", "真机导出"), ("sim_source", "仿真导出")]),
            md_table(data["ranks"], [("rank_alignment_key", "对齐键"), ("real_rank", "真机 Rank"), ("sim_rank", "仿真 Rank"), ("real_parallel_coordinate", "真机 DP/TP/EP/PP/CP/DCP"), ("sim_parallel_coordinate", "仿真 DP/TP/EP/PP/CP/DCP"), ("presence", "Presence"), ("confidence", "置信度")], top),
            "## 3. process-thread 选择与对齐",
            "",
            thread_selection_statement,
            "",
            md_table(data["selected_thread"], [("environment", "环境"), ("rank", "Rank"), ("parallel_coordinate", "DP/TP/EP/PP/CP/DCP"), ("selection_method", "选择方法"), ("seed", "Seed"), ("selected_pair_fingerprint", "Pair 指纹"), ("selection_audit_steps", "SHA 选择审计"), ("process_name", "进程"), ("thread_name", "线程"), ("pid", "PID"), ("tid", "TID"), ("pytorch_operator_calls", "PyTorch Calls"), ("alignment_score", "对齐分"), ("alignment_confidence", "置信度"), ("timing_warning", "时间边界")]),
            "随机选择必须由 seed + SHA-256 审计；若线程名/算子指纹无法可靠对齐，线程级耗时只能列事实，不能强作真仿因果比较。",
            "",
            "## 4. Step/窗口对齐候选",
            "",
            md_table(data["windows"], [("rank_alignment_key", "Rank"), ("step_ordinal", "序号"), ("real_step", "真机 Step"), ("sim_step", "仿真 Step"), ("presence", "Presence"), ("alignment_method", "对齐方法"), ("timing_interpretation_allowed", "时间可解释性")], top),
            "## 5. 主证据 Coverage",
            "",
            f"`事实`：共检查 {len(coverage)} 个 rank/file 条目；不对称或双方均缺的条目 {len(missing_or_mismatch)} 个。缺失不是实测 0。",
            "",
            md_table(missing_or_mismatch or coverage, [("rank_alignment_key", "Rank"), ("file", "文件"), ("real_present", "真机"), ("sim_present", "仿真"), ("match", "一致"), ("priority", "优先级")], top),
            "## 6. 允许与禁止解释",
            "",
            "- 允许：双方有直接证据的 operator/Shape/presence、通信 message/group/link 和对齐 Step 事实。",
            "- 有条件允许：只有时间门禁为“是”时，才解释同口径时间差与仿真/真机比率。",
            "- 禁止：把缺文件当 0、把同名 Step 当同一步、把 global rank 相同当 shard 相同、把 kernel sum 当墙钟。",
            "- 禁止：用单 Rank 样本评价 rank imbalance，或把一个随机 process-thread 外推为进程内全部线程。",
            "- `未知`：采集时间、权重/config、batch/sequence/concurrency 等若未在元数据或用户输入中出现，需在正式结论前补齐。",
            "",
        ]
    )
    return "\n".join(lines)


def report_02(data: dict[str, Any], top: int) -> str:
    manifest = data["manifest"]
    all_pytorch_rows = data["pytorch"]
    concrete_rows = [row for row in all_pytorch_rows if concrete_pytorch_operator(row.get("operator"))]
    scope_rows = [row for row in all_pytorch_rows if not concrete_pytorch_operator(row.get("operator"))]
    matched_concrete = sorted(
        [row for row in concrete_rows if row.get("presence") == "两侧存在"],
        key=lambda row: metric_hotness(
            row,
            "device_self_us_total_delta_percent",
            "real_device_self_us_total",
            "sim_device_self_us_total",
        ),
        reverse=True,
    )
    unmatched_concrete = sorted(
        [row for row in concrete_rows if row.get("presence") != "两侧存在"],
        key=lambda row: metric_hotness(
            row, "real_device_self_us_total", "sim_device_self_us_total", "real_calls", "sim_calls"
        ),
        reverse=True,
    )
    thread_comparison = data["thread_comparison"]
    real_thread_hot = hot_thread_rows(thread_comparison, "real")
    sim_thread_hot = hot_thread_rows(thread_comparison, "sim")
    matched_thread = sorted(
        [row for row in thread_comparison if row.get("presence") == "两侧存在"],
        key=lambda row: metric_hotness(
            row, "self_us_total_delta_percent", "real_self_us_total", "sim_self_us_total"
        ),
        reverse=True,
    )
    focused_sequence = sequence_focus(data["thread_sequence"], top)
    heatmap_all = aggregate_heatmap_rows(data["thread_heatmap"])
    heatmap_rows = [
        row
        for row in heatmap_all
        if row.get("coverage_kind") != "unattributed_gap"
        and str(row.get("is_dominant", "")).lower() in {"是", "true", "1", "yes"}
    ]
    if not heatmap_rows:
        heatmap_rows = sorted(
            [row for row in heatmap_all if row.get("coverage_kind") != "unattributed_gap"],
            key=lambda row: number(row.get("share_of_bin_percent")) or 0.0,
            reverse=True,
        )
    heatmap_display: list[dict[str, Any]] = []
    per_environment = max(1, top // 2)
    for environment in ("real/reference/真机", "sim/candidate/仿真"):
        heatmap_display.extend(
            [row for row in heatmap_rows if row.get("environment") == environment][:per_environment]
        )
    heatmap_coverage: list[dict[str, Any]] = []
    for environment in ("real/reference/真机", "sim/candidate/仿真"):
        env_rows = [row for row in heatmap_all if row.get("environment") == environment]
        bins = {str(row.get("bin_index", "")) for row in env_rows}
        gap_percent = sum(
            number(row.get("share_of_bin_percent")) or 0.0
            for row in env_rows
            if row.get("coverage_kind") == "unattributed_gap"
            or row.get("operator") == "<未归属>"
        ) / max(1, len(bins))
        heatmap_coverage.append(
            {
                "environment": environment,
                "bins": len(bins),
                "pytorch_attributed_percent": round(max(0.0, 100.0 - gap_percent), 6),
                "unattributed_gap_percent": round(min(100.0, max(0.0, gap_percent)), 6),
            }
        )
    perfetto_review = data["perfetto_review"]
    perfetto_runs = data["perfetto_runs"]
    thread_status = data["thread_status"]
    trace_manifest = data["trace_thread_manifest"]
    expected_threads = {
        "real": next((row for row in data["selected_thread"] if row.get("environment", "").startswith("real")), {}),
        "sim": next((row for row in data["selected_thread"] if row.get("environment", "").startswith("sim")), {}),
    }
    expected_sha = {
        "real": str(trace_manifest.get("real_trace_sha256", "")),
        "sim": str(trace_manifest.get("sim_trace_sha256", "")),
    }
    seen_sides: set[str] = set()
    for run in perfetto_runs:
        environment = str(run.get("environment", "")).lower()
        side = "real" if environment.startswith("real") else "sim" if environment.startswith("sim") else ""
        expected = expected_threads.get(side, {})
        isolation_matches = bool(
            run.get("offline_before_trace_post") is True
            and str(run.get("service_worker_count", "")) == "0"
            and run.get("service_worker_guard") is True
            and run.get("offline_active_at")
        )
        run["isolation_status"] = "离线先于 trace post" if isolation_matches else "离线门禁缺失/失败"
        matches = bool(
            side
            and side not in seen_sides
            and run.get("status") == "success"
            and str(run.get("pid", "")) == str(expected.get("pid", ""))
            and str(run.get("tid", "")) == str(expected.get("tid", ""))
            and expected_sha.get(side)
            and str(run.get("trace_sha256", "")) == expected_sha.get(side)
            and isolation_matches
            and (number(run.get("canvas_count")) or 0) > 0
            and bool(perfetto_sql_hotspots([run], 1))
            and (
                Path(str(run.get("frame_html", ""))).is_file()
                or Path(str(run.get("body_text", ""))).is_file()
            )
        )
        run["binding_status"] = "匹配当前线程/trace" if matches else "不匹配或重复"
        if side:
            seen_sides.add(side)
    if perfetto_runs:
        perfetto_automation_status = (
            "完成"
            if seen_sides == {"real", "sim"}
            and all(row.get("binding_status") == "匹配当前线程/trace" for row in perfetto_runs)
            else "部分/不匹配"
        )
    else:
        perfetto_automation_status = "未执行"
    observations = perfetto_review.get("observations")
    perfetto_content_status, perfetto_canvas_status, normalized_review_methods = (
        perfetto_review_statuses(perfetto_automation_status, perfetto_review)
    )
    sql_hotspots = perfetto_sql_hotspots(perfetto_runs)
    thread_completed = thread_status.get("status") == "完成"
    thread_statement = (
        "`事实`：线程级表直接来自所选 Rank 的 `trace_view.json`，仅纳入具体 PyTorch dispatcher/custom `cpu_op` slice；CANN/kernel、ProfilerStep、module/autograd 范围不冒充具体算子。Output Shape 没有运行时直接证据时保持未知。"
        if thread_completed
        else f"`受限`：线程级分析状态 `{clean(thread_status.get('status'))}`；原因：{clean(thread_status.get('reason'))}；影响：{clean(thread_status.get('impact'), 1000)}。缺失不等于零事件。"
    )
    heatmap_intro = (
        "[打开本地自包含算子热力图](../comparison/operator_heatmap.html)。横轴为所选线程窗口的归一化时间桶，纵轴为算子；数值使用 deepest/exclusive 覆盖，避免嵌套 inclusive 时间重复累计。"
        if thread_completed
        else "线程级分析未完成，没有可解释的算子热力图；若目录中存在空白占位 HTML，也只用于说明受限状态，不代表零算子。"
    )
    matched, only_real, only_sim = presence_counts(concrete_rows)
    scope_matched, scope_only_real, scope_only_sim = presence_counts(scope_rows)
    lines = [common_header("PyTorch Operator 与调用路径保真度", manifest, thread_status)]
    lines.extend(
        [
            "## 1. 所选 process-thread 实际执行的 PyTorch 算子",
            "",
            thread_statement,
            "",
            "### 真机线程热点（按真机 PyTorch-exclusive 时间）",
            "",
            md_table(real_thread_hot, [("operator", "PyTorch operator"), ("input_shapes", "Input Shape"), ("output_shapes", "Output Shape"), ("presence", "Presence"), ("real_calls", "Calls 真"), ("real_self_us_total", "Exclusive 真(us)"), ("real_inclusive_us_total", "Inclusive 真(us)"), ("real_call_stack_sample", "真机栈")], top),
            "### 仿真线程热点（按仿真 PyTorch-exclusive 时间）",
            "",
            md_table(sim_thread_hot, [("operator", "PyTorch operator"), ("input_shapes", "Input Shape"), ("output_shapes", "Output Shape"), ("presence", "Presence"), ("sim_calls", "Calls 仿"), ("sim_self_us_total", "Exclusive 仿(us)"), ("sim_inclusive_us_total", "Inclusive 仿(us)"), ("sim_call_stack_sample", "仿真栈")], top),
            "### 两侧匹配的线程算子",
            "",
            md_table(matched_thread, [("operator", "PyTorch operator"), ("input_shapes", "Input Shape"), ("output_shapes", "Output Shape"), ("real_calls", "Calls 真"), ("sim_calls", "Calls 仿"), ("real_self_us_total", "Exclusive 真(us)"), ("sim_self_us_total", "Exclusive 仿(us)"), ("self_us_total_sim_over_real", "Exclusive 仿/真")], top),
            "### 算子序列首批差异（每个差异保留前后 1 个上下文）",
            "",
            md_table(focused_sequence, [("diff_index", "序号"), ("match_type", "类型"), ("real_operator", "真机 operator"), ("real_input_shapes", "真机 Input Shape"), ("real_output_shapes", "真机 Output Shape"), ("real_calls_in_run", "真机连续 Calls"), ("sim_operator", "仿真 operator"), ("sim_input_shapes", "仿真 Input Shape"), ("sim_output_shapes", "仿真 Output Shape"), ("sim_calls_in_run", "仿真连续 Calls")], top),
            "## 2. 算子热力图与 Perfetto 内容复核",
            "",
            heatmap_intro,
            "",
            md_table(heatmap_coverage, [("environment", "环境"), ("bins", "时间桶数"), ("pytorch_attributed_percent", "PyTorch 归属覆盖(%)"), ("unattributed_gap_percent", "未归属间隙(%)")]),
            "下表只展示真实 PyTorch 算子；`<未归属>` 是相邻算子之间的时间间隙，不再标成“主导算子”。",
            "",
            md_table(heatmap_display, [("environment", "环境"), ("bin_index", "时间桶"), ("operator", "主导/覆盖算子"), ("input_shapes", "Input Shape"), ("output_shapes", "Output Shape"), ("inclusive_overlap_us", "Inclusive overlap(us)"), ("deepest_exclusive_us", "Deepest/Exclusive(us)"), ("call_count_overlapping", "Overlap Calls"), ("share_of_bin_percent", "时间桶占比(%)"), ("is_dominant", "主导")]),
            f"`Perfetto 页面/SQL/HTML 自动产物`：状态 `{perfetto_automation_status}`；`Perfetto 内容复核`：状态 `{perfetto_content_status}`，方法 `{clean(sorted(normalized_review_methods))}`；`Canvas 截图复核`：状态 `{perfetto_canvas_status}`。HTML/DOM/文本与 SQL 可用于算子和表格内容分析；未查看截图时只是不评价 Canvas 颜色、条块和轨道几何。边界：{clean(perfetto_review.get('evidence_boundary') or perfetto_review.get('limitations'), 1000)}。",
            "",
            md_table(perfetto_runs, [("environment", "环境"), ("status", "状态"), ("binding_status", "当前运行绑定"), ("isolation_status", "网络隔离"), ("pid", "PID"), ("tid", "TID"), ("trace_sha256", "Trace SHA-256"), ("canvas_count", "Canvas"), ("sql_rows", "SQL 热点表"), ("screenshot", "截图"), ("frame_html", "渲染 HTML"), ("error", "错误")], 4),
            "### Perfetto SQL 中实际读取的热点",
            "",
            md_table(sql_hotspots, [("environment", "环境"), ("operator", "Operator"), ("calls", "Calls"), ("total_ms", "Total(ms)"), ("avg_ms", "Avg(ms)"), ("max_ms", "Max(ms)")], top),
            f"内容复核记录：{clean(observations, 1200) if observations else '未记录；需要实际读取两侧 HTML/文本/SQL（或按需查看截图）后填写 observations。'}",
            "",
            "## 3. 单 Rank Presence 与 Shape 覆盖",
            "",
            f"`事实`：所选单 Rank 的具体 dispatcher/custom PyTorch union 共 {len(concrete_rows)} 个实体；双方存在 {matched}，仅真机 {only_real}，仅仿真 {only_sim}。另有 module/autograd/scope 实体 {len(scope_rows)} 个（双方/仅真/仅仿={scope_matched}/{scope_only_real}/{scope_only_sim}），单独审计，不再挤占具体算子热点表。",
            "",
            "## 4. 两侧匹配的重点 PyTorch 实体",
            "",
            md_table(matched_concrete, [("parallel_coordinate_pair", "Rank/DP/TP/EP/PP/CP/DCP 真/仿"), ("operator", "PyTorch operator"), ("input_shapes", "Input Shape"), ("real_calls", "Calls 真"), ("sim_calls", "Calls 仿"), ("real_device_self_us_total", "Device Self 真(us)"), ("sim_device_self_us_total", "Device Self 仿(us)"), ("device_self_us_total_sim_over_real", "仿真/真机"), ("call_stack_id_match", "Call stack 一致")], top),
            "### 仅一侧存在的具体 PyTorch 算子/Shape",
            "",
            md_table(unmatched_concrete, [("operator", "PyTorch operator"), ("input_shapes", "Input Shape"), ("presence", "Presence"), ("real_calls", "Calls 真"), ("sim_calls", "Calls 仿"), ("real_device_self_us_total", "Device Self 真(us)"), ("sim_device_self_us_total", "Device Self 仿(us)"), ("real_evidence", "真机证据"), ("sim_evidence", "仿真证据")], top),
            "## 5. Calls、per-call 与总量拆解",
            "",
            "`推断`：总时间差必须拆成调用数变化、per-call 变化及 Shape/path 变化。CSV 已提供 `*_volume_effect` 与 `*_unit_cost_effect`；只有双方实体、窗口和时间语义可比时才解释。",
            "",
            md_table(matched_concrete, [("operator", "Operator"), ("input_shapes", "Shape"), ("device_self_us_total_sim_minus_real", "Device Self 仿-真(us)"), ("device_self_us_total_volume_effect", "调用量效应(us)"), ("device_self_us_total_unit_cost_effect", "单位成本效应(us)"), ("real_device_self_us_per_call", "真机 per-call(us)"), ("sim_device_self_us_per_call", "仿真 per-call(us)")], top),
            "## 6. 源码结合与解释边界",
            "",
            "- PyTorch output Shape 在 `operator_details.csv` 无直接证据时保持未知，不从 device kernel 反填。",
            "- call stack 作为差异属性，不作为跨环境主 join key；绝对路径和行号可能因安装位置或版本改变。",
            "- 线程表的 `self` 是排除嵌套 PyTorch operator 后的 PyTorch-exclusive 时间，不等同于排除该线程上所有非 PyTorch 子 slice 的通用 CPU Self。",
            "- 相同 operator/Shape 不证明 tensor value、mask、routing、KV slot 或 cache state 相同。",
            "- attention/MoE/KV/GEMM/norm/graph 路径需结合真实模型实体和源码后再命名；本报告不凭模糊 kernel 名猜测。",
            "- 源码映射优先使用 trace call stack/module/runtime marker；`.sh -> launcher -> Python entry -> forward/dispatch -> operator` 只做静态候选，未有运行证据时不能声称本次确实走过该分支。",
            "",
        ]
    )
    return "\n".join(lines)


def report_03(data: dict[str, Any], top: int) -> str:
    manifest = data["manifest"]
    rows = data["device"]
    matched_rows = sorted(
        [row for row in rows if row.get("presence") == "两侧存在"],
        key=lambda row: metric_hotness(
            row, "duration_us_total_delta_percent", "real_duration_us_total", "sim_duration_us_total"
        ),
        reverse=True,
    )
    unmatched_rows = sorted(
        [row for row in rows if row.get("presence") != "两侧存在"],
        key=lambda row: metric_hotness(row, "real_duration_us_total", "sim_duration_us_total"),
        reverse=True,
    )
    matched, only_real, only_sim = presence_counts(rows)
    lines = [common_header("执行算子、I/O Shape 与 Lowering 路径保真度", manifest, data["thread_status"])]
    lines.extend(
        [
            "## 1. 执行实体覆盖",
            "",
            f"`事实`：device union 共 {len(rows)} 个完整 ABI 实体，双方存在/仅真/仅仿={matched}/{only_real}/{only_sim}。主键包含 rank、name/type/core、input/output Shape、dtype 与 format。",
            "",
            "## 2. 两侧匹配的 Device operator/kernel",
            "",
            md_table(matched_rows, [("parallel_coordinate_pair", "Rank/DP/TP/EP/PP/CP/DCP 真/仿"), ("operator", "Device operator"), ("type", "Type"), ("input_shapes", "Input Shape"), ("output_shapes", "Output Shape"), ("input_dtypes", "Input dtype"), ("output_dtypes", "Output dtype"), ("input_formats", "Input format"), ("output_formats", "Output format"), ("accelerator_core", "Core"), ("real_calls", "Calls 真"), ("sim_calls", "Calls 仿"), ("real_duration_us_total", "Duration 真(us)"), ("sim_duration_us_total", "Duration 仿(us)"), ("duration_us_total_sim_over_real", "仿真/真机")], top),
            "### 仅一侧存在的 Device ABI 实体",
            "",
            md_table(unmatched_rows, [("operator", "Device operator"), ("type", "Type"), ("input_shapes", "Input Shape"), ("output_shapes", "Output Shape"), ("input_dtypes", "Input dtype"), ("output_dtypes", "Output dtype"), ("accelerator_core", "Core"), ("presence", "Presence"), ("real_calls", "Calls 真"), ("sim_calls", "Calls 仿"), ("real_duration_us_total", "Duration 真(us)"), ("sim_duration_us_total", "Duration 仿(us)"), ("real_evidence", "真机证据"), ("sim_evidence", "仿真证据")], top),
            "## 3. 路径解释",
            "",
            "- PyTorch 一致但 kernel/name 不同：优先检查 backend lowering、fusion、tiling、编译和版本。",
            "- Shape 一致但 dtype/format 不同：优先检查 cast、layout、padding 与 backend 配置。",
            "- PyTorch 存在但仿真缺 device 实体：可能是 fusion、未建模、采集覆盖或关联差异，不能直接判定漏算。",
            "- 结构完全一致但 duration 不同：检查仿真 timing model、真实频率/cache、并发 stream 与 contention。",
            "",
            "## 4. 时间口径边界",
            "",
            "`事实`：device duration 求和不是 Step 墙钟；真实环境可能并行执行多个 stream，仿真也可能序列化或省略等待。必须与 Step/overlap 联合解释。",
            "",
        ]
    )
    return "\n".join(lines)


def report_04(data: dict[str, Any], top: int) -> str:
    manifest = data["manifest"]
    communication_axis_status = data["communication_axis_status"]
    comm_kernels = ranked(data["communication_kernels"])
    comm = ranked(data["communication_collectives"])
    raw_comm = ranked(data["communication"])
    links = ranked(data["links"])
    steps = ranked(data["step"])
    memory = ranked(data["memory"])
    lines = [common_header("单 Rank 通信、Step、Overlap 与系统建模保真度", manifest, data["thread_status"])]
    lines.extend(
        [
            "## 1. 通信并行轴推断审计",
            "",
            md_table(communication_axis_status, [("environment", "环境"), ("status", "状态"), ("rank_metadata_candidates", "拓扑 Rank 数"), ("rank_coordinates_indexed", "坐标已索引"), ("selected_rank_matrix_links", "所选 Rank 链路"), ("matrix_links_with_inferred_axis", "链路轴已推断"), ("communication_ops_with_inferred_axis", "消息轴已推断"), ("communication_summaries_with_inferred_axis", "汇总轴已推断"), ("scope", "证据范围"), ("limitation", "限制")], 4),
            "`证据边界`：DP/TP/EP/PP/CP/DCP 只由全拓扑目录中的 Rank 坐标与所选 Rank 的 matrix peer/link 推断；其它 Rank 的性能明细不进入分析。无法形成唯一轴时保持“未知”，不按通信算子名称猜测。",
            "",
            "## 2. 通信执行算子与 I/O Shape",
            "",
            md_table(comm_kernels, [("parallel_coordinate_pair", "Rank/DP/TP/EP/PP/CP/DCP 真/仿"), ("operator", "通信算子"), ("type", "Type"), ("accelerator_core", "Core"), ("input_shapes", "Input Shape"), ("output_shapes", "Output Shape"), ("input_dtypes", "Input dtype"), ("output_dtypes", "Output dtype"), ("input_formats", "Input format"), ("output_formats", "Output format"), ("presence", "Presence"), ("real_calls", "Calls 真"), ("sim_calls", "Calls 仿"), ("real_duration_us_total", "Duration 真(us)"), ("sim_duration_us_total", "Duration 仿(us)"), ("real_wait_us_total", "Wait 真(us)"), ("sim_wait_us_total", "Wait 仿(us)"), ("real_evidence", "真机证据"), ("sim_evidence", "仿真证据")], top),
            "## 3. 跨环境可比的通信 collective 汇总",
            "",
            "`事实`：HCCL group 数字是进程内句柄，不能直接作为跨环境身份。主表按 category + collective type + 已证实并行轴汇总，同时保留两侧 raw group 列表。",
            "",
            md_table(comm, [("parallel_coordinate_pair", "Rank/DP/TP/EP/PP/CP/DCP 真/仿"), ("category", "类别"), ("collective_type", "Type"), ("parallel_axis", "并行轴"), ("presence", "Presence"), ("real_communication_group", "真机 raw Group"), ("sim_communication_group", "仿真 raw Group"), ("real_calls", "Calls 真"), ("sim_calls", "Calls 仿"), ("real_transit_size_mb_total", "Message 真(MB)"), ("sim_transit_size_mb_total", "Message 仿(MB)"), ("real_transit_ms_total", "Transit 真(ms)"), ("sim_transit_ms_total", "Transit 仿(ms)"), ("real_wait_ms_total", "Wait 真(ms)"), ("sim_wait_ms_total", "Wait 仿(ms)"), ("real_synchronization_ms_total", "Sync 真(ms)"), ("sim_synchronization_ms_total", "Sync 仿(ms)")], top),
            "### Raw group 明细（仅作环境内审计）",
            "",
            md_table(raw_comm, [("category", "类别"), ("collective_type", "Type"), ("communication_group", "Raw Group"), ("parallel_axis", "并行轴"), ("presence", "Presence"), ("real_calls", "Calls 真"), ("sim_calls", "Calls 仿"), ("real_wait_ms_total", "Wait 真(ms)"), ("sim_wait_ms_total", "Wait 仿(ms)")], top),
            "## 4. Peer/Link/Transport",
            "",
            md_table(links, [("parallel_coordinate_pair", "Rank/DP/TP/EP/PP/CP/DCP 真/仿"), ("collective_type", "Type"), ("communication_group", "Group"), ("parallel_axis", "轴"), ("link", "Peer/Link"), ("presence", "Presence"), ("real_transit_size_mb", "Message 真(MB)"), ("sim_transit_size_mb", "Message 仿(MB)"), ("real_transit_ms", "Transit 真(ms)"), ("sim_transit_ms", "Transit 仿(ms)"), ("real_transport_type", "Transport 真"), ("sim_transport_type", "Transport 仿")], top),
            "## 5. Step、通信非重叠与墙钟",
            "",
            md_table(steps, [("parallel_coordinate_pair", "Rank/DP/TP/EP/PP/CP/DCP 真/仿"), ("step_ordinal", "语义阶段/Step 序号"), ("real_step", "原始 Step 真"), ("sim_step", "原始 Step 仿"), ("real_stage_us", "Stage 真(us)"), ("sim_stage_us", "Stage 仿(us)"), ("real_computing_us", "Compute 真(us)"), ("sim_computing_us", "Compute 仿(us)"), ("real_communication_us", "Communication 真(us)"), ("sim_communication_us", "Communication 仿(us)"), ("real_communication_not_overlapped_us", "Not-overlap 真(us)"), ("sim_communication_not_overlapped_us", "Not-overlap 仿(us)"), ("stage_us_sim_over_real", "Stage 仿真/真机"), ("timing_interpretation_allowed", "可解释性")], top),
            "## 6. 内存与系统模型",
            "",
            md_table(memory, [("parallel_coordinate_pair", "Rank/DP/TP/EP/PP/CP/DCP 真/仿"), ("component", "组件"), ("device_type", "设备"), ("presence", "Presence"), ("real_max_allocated_mb", "Allocated 真(MB)"), ("sim_max_allocated_mb", "Allocated 仿(MB)"), ("real_max_reserved_mb", "Reserved 真(MB)"), ("sim_max_reserved_mb", "Reserved 仿(MB)"), ("real_max_active_mb", "Active 真(MB)"), ("sim_max_active_mb", "Active 仿(MB)")], top),
            "`未知`：若仿真没有 allocator、fragmentation、frequency、cache、stream contention、链路竞争或同步模型，相应维度应标为“未建模/不适用”，不能把缺失值解释为 0。当前严格只分析一个 Rank，因此不评价 rank imbalance、慢 Rank、跨 Rank max/min 或 CV。",
            "",
            "> HCCL AICPU duration 可能包含等待或同步，不等同于链路传输时间；链路口径应以 communication.json/matrix 为准。",
            "",
        ]
    )
    return "\n".join(lines)


def report_05(data: dict[str, Any], top: int) -> str:
    manifest = data["manifest"]
    bindings = data["bindings"]
    provided = [
        row
        for row in bindings
        if row.get("input_locator_sanitized") or row.get("repository_url_or_path") or row.get("subpath")
    ]
    source_evidence = data["source_evidence"]
    source_edges = data["source_edges"]
    entry_candidates = data["source_entry_candidates"]
    shell_chain = data["shell_launch_chain"]
    operator_source_map = data["operator_source_map"]
    source_mapping_status = data["source_mapping_status"]
    source_mapping_issues = data["source_mapping_issues"]
    source_analysis_status = data["source_analysis_status"]
    launch_candidates = data["launch_candidates"]
    source_runtime_config = data["source_runtime_config"]
    source_resolution_issues = data["source_resolution_issues"]
    lines = [common_header("模型源码因果证据与改进行动", manifest, data["thread_status"])]
    lines.extend(["## 1. 环境与源码绑定", ""])
    if provided:
        lines.extend(
            [
                md_table(provided, [("environment", "环境"), ("repository_url_or_path", "Repo/本地路径"), ("subpath", "入口线索"), ("provider", "Provider"), ("locator_kind", "Locator 类型"), ("requested_ref", "请求 ref"), ("resolved_commit", "解析 commit"), ("runtime_binding", "运行绑定"), ("credentials_redacted", "凭据已脱敏"), ("notes", "说明")]),
                "`边界`：分析代理必须打开用户给出的 GitHub/GitCode URL 或只读本地 checkout，把 branch/tag 固定到 commit，并核验该 commit 是否是 Profiling 运行版本。若 locator 只是 `.sh` 或全是 `.sh` 的目录，应继续静态追踪 launcher 与 Python 入口，绝不执行 shell/仓库代码。",
                "",
            ]
        )
    else:
        lines.extend(["`未知`：未提供源码，不能做代码级因果绑定；Profiler-only 对比仍然有效。", ""])
    lines.extend(["## 2. `.sh` 入口候选与静态启动链", ""])
    if source_analysis_status:
        lines.extend([md_table(source_analysis_status, [("environment", "环境"), ("status", "状态"), ("locator", "Locator"), ("entry", "入口"), ("reason", "原因"), ("stderr", "错误")], 4), ""])
    lines.append(md_table(entry_candidates, [("environment", "环境"), ("entry_path", "入口"), ("entry_kind", "类型"), ("selection_status", "选择状态"), ("selection_reason", "依据"), ("runtime_binding", "运行绑定"), ("confidence", "置信度"), ("limitations", "限制")], top) if entry_candidates else "_尚无入口候选；远程仓需先读取固定 commit，本地 locator 可运行静态入口解析器。_\n")
    lines.extend(["", md_table(shell_chain, [("environment", "环境"), ("step_index", "步骤"), ("source_path", "来源"), ("node_kind", "节点"), ("edge_type", "边"), ("target", "目标"), ("resolution_status", "解析状态"), ("confidence", "置信度"), ("notes", "说明")], top) if shell_chain else "_尚无 `.sh -> launcher -> Python` 静态链。_\n", ""])
    if launch_candidates:
        lines.extend(["### Python/launcher 候选", "", md_table(launch_candidates, [("environment", "环境"), ("source_path", "来源"), ("launcher", "Launcher"), ("python_mode", "Python 模式"), ("python_target", "Python 入口"), ("runtime_match", "运行匹配"), ("selection_status", "选择状态"), ("confidence", "置信度")], top), ""])
    if source_runtime_config:
        lines.extend(["### 脱敏运行配置", "", md_table(source_runtime_config, [("environment", "环境"), ("config_key", "配置键"), ("value_redacted", "脱敏值"), ("value_origin", "来源类型"), ("source_location", "位置"), ("runtime_observed", "运行观测"), ("confidence", "置信度")], top), ""])
    if source_resolution_issues:
        lines.extend(["### 入口解析限制", "", md_table(source_resolution_issues, [("environment", "环境"), ("issue_kind", "问题"), ("source_location", "位置"), ("impact", "影响"), ("minimum_user_input", "最小补充")], top), ""])
    lines.extend(["## 3. 所选线程算子到源码的映射", ""])
    if source_mapping_status:
        lines.extend([md_table(source_mapping_status, [("environment", "环境"), ("status", "状态"), ("repo_root", "源码仓"), ("source_analysis_dir", "入口解析证据"), ("reason", "未执行原因"), ("stderr", "错误")], 4), ""])
    lines.append(md_table(operator_source_map, [("environment", "环境"), ("pid", "PID"), ("tid", "TID"), ("event_id", "事件"), ("operator_name", "PyTorch operator"), ("input_shape", "Input Shape"), ("output_shape", "Output Shape"), ("python_entry", "Python 入口"), ("model_symbol", "Model symbol"), ("callsite_path", "Callsite"), ("line_start", "行"), ("mapping_method", "映射依据"), ("confidence", "置信度"), ("ambiguity_count", "候选数"), ("notes", "说明")], top) if operator_source_map else "_尚无 `thread_operator_source_map.csv`；算子与源码尚未形成运行时绑定。_\n")
    if source_mapping_issues:
        lines.extend(["", "### 映射限制与最小补证", "", md_table(source_mapping_issues, [("environment", "环境"), ("event_id", "事件"), ("issue_kind", "问题"), ("source_location", "位置"), ("impact", "影响"), ("minimum_user_input", "最小补充")], top)])
    lines.extend(["", "## 4. 已有源码证据", ""])
    if source_evidence:
        lines.append(md_table(source_evidence, [("evidence_id", "证据 ID"), ("environment", "环境"), ("repository", "Repo"), ("commit", "Commit"), ("path", "文件"), ("symbol", "Symbol"), ("line_start", "起始行"), ("line_end", "结束行"), ("evidence_kind", "类型"), ("permalink", "永久链接"), ("note", "说明")], top))
    else:
        lines.extend(["_尚无 `source_evidence.csv`；不得把静态源码中可能执行的分支写成本次运行事实。_", ""])
    lines.extend(["## 5. 跨文件符号边", ""])
    lines.append(
        md_table(source_edges, [("from_symbol", "调用方"), ("from_location", "位置"), ("edge_type", "边类型"), ("to_symbol", "被调用方"), ("to_location", "位置"), ("guard_or_config", "Guard/配置"), ("evidence_ids", "证据"), ("confidence", "置信度")], top)
        if source_edges
        else "_尚无 `source_symbol_edges.csv`；代码链保持未知。_\n"
    )
    lines.extend(
        [
            "## 6. Profiler 差异到源码的有界路径",
            "",
            "`推断`：优先从重大 unmatched operator/call stack/Shape/group/Step 差异出发，追踪 `入口/config -> guard/dispatch -> Shape/count/group producer -> PyTorch/custom op -> backend/communication call`。相同 commit 时先检查输入、配置、环境变量和运行时 backend；不同 commit 时只对已证实执行路径做有界 diff。",
            "",
            "## 7. 行动清单",
            "",
            "### 已确认的仿真缺口",
            "",
            "只有 `unmatched_entities.csv` 中经排除采集、命名、窗口和版本差异后仍成立的实体，才能列为已确认缺口；自动渲染不越过该证据门槛。",
            "",
            "### 需要补证的候选缺口",
            "",
            "- 运行 commit/build ID、模型配置和 runtime guard 值。",
            "- unmatched PyTorch/Shape 到实际 call site 的 stack/flow/marker。",
            "- process-group 成员、并行轴、message producer 与 peer/link 映射。",
            "- 仿真 timing、frequency/cache、stream、communication 与 allocator 能力声明。",
            "",
            "### 最小重采、单元测试与 A/B",
            "",
            "1. 同 request/phase/schedule 复采，增加 module/stack/Shape/flow 和源码 commit marker。",
            "2. 对首个结构差异固定输入做单算子或单层 A/B，同时记录 PyTorch、device 与通信事件。",
            "3. 固定同一 commit 后只改变真机/仿真 backend；若两侧 commit 不同，再做受控版本 A/B。",
            "",
            "### 可自动化回归指标",
            "",
            "- PyTorch/device/communication 结构覆盖率与仅一侧实体数。",
            "- calls、per-call、message/call、transit、wait、not-overlapped 与 Stage bias。",
            "- 所选 Rank 的内存峰值与系统未建模项计数；rank imbalance 必须另采多 Rank 后再评价。",
            "",
            "未提供项目容差时只给数值和排序，不自行宣布通过/失败。",
            "",
        ]
    )
    return "\n".join(lines)


def read_csv_tree(root: Path, filename: str) -> list[dict[str, str]]:
    rows = read_csv(root / filename)
    for path in sorted((root / "source_analysis").glob(f"**/{filename}")):
        rows.extend(read_csv(path))
    return rows


def load_perfetto_runs(comparison: Path) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    for path in sorted((comparison / "perfetto").glob("*/perfetto_manifest.json")):
        manifest = read_json(path)
        if not manifest:
            continue
        selection = manifest.get("selection") if isinstance(manifest.get("selection"), dict) else {}
        trace = manifest.get("trace") if isinstance(manifest.get("trace"), dict) else {}
        perfetto = manifest.get("perfetto") if isinstance(manifest.get("perfetto"), dict) else {}
        network_isolation = (
            perfetto.get("network_isolation")
            if isinstance(perfetto.get("network_isolation"), dict)
            else {}
        )
        rendered = manifest.get("rendered") if isinstance(manifest.get("rendered"), dict) else {}
        artifacts = manifest.get("artifacts") if isinstance(manifest.get("artifacts"), dict) else {}
        rows.append(
            {
                "environment": path.parent.name,
                "status": manifest.get("status", "未知"),
                "pid": selection.get("pid", ""),
                "tid": selection.get("tid", ""),
                "process_name": selection.get("process_name", ""),
                "thread_name": selection.get("thread_name", ""),
                "trace_path": trace.get("path", ""),
                "trace_sha256": trace.get("sha256", ""),
                "offline_before_trace_post": network_isolation.get("offline_before_trace_post", False),
                "service_worker_count": network_isolation.get("service_worker_count_after_render", ""),
                "service_worker_guard": network_isolation.get(
                    "service_worker_guard_visible_in_perfetto_frame", False
                ),
                "offline_active_at": network_isolation.get("offline_active_at", ""),
                "canvas_count": rendered.get("canvas_count", ""),
                "sql_rows": json.dumps(rendered.get("visible_query_grid_rows", []), ensure_ascii=False),
                "screenshot": (artifacts.get("screenshot") or {}).get("path", ""),
                "frame_html": (artifacts.get("frameHtml") or {}).get("path", ""),
                "body_text": (artifacts.get("text") or {}).get("path", ""),
                "error": (manifest.get("error") or {}).get("message", "") if isinstance(manifest.get("error"), dict) else "",
            }
        )
    return rows


def load_data(root: Path) -> dict[str, Any]:
    comparison = root / "comparison"
    manifest = read_json(comparison / "comparison_manifest.json")
    if not manifest:
        raise ValueError(f"缺少或无法读取 {comparison / 'comparison_manifest.json'}")
    if manifest.get("status") != "complete":
        raise ValueError(
            f"对比尚未完整完成（status={manifest.get('status', '未知')}），拒绝渲染陈旧或半成品证据"
        )
    try:
        schema_version = int(manifest.get("schema_version", 0) or 0)
    except (TypeError, ValueError):
        schema_version = 0
    if schema_version < 3:
        raise ValueError("comparison_manifest.json schema_version 过旧，请重新运行 compare_ascend_profiles.py")
    collective_path = comparison / "communication_collective_comparison.csv"
    phase_path = comparison / "runtime_phase_evidence.json"
    if not collective_path.is_file() or not phase_path.is_file():
        raise ValueError(
            "对比证据缺少 communication_collective_comparison.csv 或 runtime_phase_evidence.json；"
            "请使用新版 skill 重新运行 compare_ascend_profiles.py"
        )
    communication_axis_path = comparison / "communication_axis_enrichment.json"
    communication_axis_value = read_json_value(communication_axis_path, None)
    if not isinstance(communication_axis_value, list) or len(communication_axis_value) != 2:
        raise ValueError(
            "communication_axis_enrichment.json 必须是含真机/仿真各一行的两元素列表；"
            "当前产物陈旧、损坏或未完整生成，请重新运行 compare_ascend_profiles.py"
        )
    communication_axis_status: list[dict[str, Any]] = []
    communication_axis_roles: list[str] = []
    for value in communication_axis_value:
        if not isinstance(value, dict):
            raise ValueError(
                "communication_axis_enrichment.json 行结构无效，请重新运行 compare_ascend_profiles.py"
            )
        row = dict(value)
        environment = str(row.get("environment", "")).strip().lower()
        role = "real" if environment.startswith("real") else "sim" if environment.startswith("sim") else ""
        if not role or any(not str(row.get(field, "")).strip() for field in ("status", "scope", "limitation")):
            raise ValueError(
                "communication_axis_enrichment.json 缺环境/status/scope/limitation 审计字段；"
                "请重新运行 compare_ascend_profiles.py"
            )
        communication_axis_roles.append(role)
        communication_axis_status.append(row)
    if sorted(communication_axis_roles) != ["real", "sim"]:
        raise ValueError(
            "communication_axis_enrichment.json 必须恰含一行真机与一行仿真状态；"
            "请重新运行 compare_ascend_profiles.py"
        )
    data = {
        "manifest": manifest,
        "summary": read_csv(comparison / "comparison_summary.csv"),
        "gates": read_csv(comparison / "comparability_gates.csv"),
        "coverage": read_csv(comparison / "coverage_comparison.csv"),
        "selected_rank": read_csv(comparison / "selected_rank_pair.csv"),
        "selected_thread": read_csv(comparison / "selected_thread_pair.csv"),
        "thread_inventory": read_csv(comparison / "trace_thread_inventory.csv"),
        "thread_events": read_csv(comparison / "selected_thread_operator_events.csv"),
        "thread_summary": read_csv(comparison / "selected_thread_operator_summary.csv"),
        "thread_comparison": read_csv(comparison / "selected_thread_operator_comparison.csv"),
        "thread_sequence": read_csv(comparison / "selected_thread_sequence_diff.csv"),
        "thread_heatmap": read_csv(comparison / "selected_thread_operator_heatmap.csv"),
        "perfetto_review": read_json(comparison / "perfetto_visual_review.json"),
        "perfetto_runs": load_perfetto_runs(comparison),
        "thread_status": read_json(comparison / "thread_analysis_status.json"),
        "trace_thread_manifest": read_json(comparison / "trace_thread_analysis_manifest.json"),
        "ranks": read_csv(comparison / "rank_alignment.csv"),
        "windows": read_csv(comparison / "window_alignment.csv"),
        "pytorch": read_csv(comparison / "pytorch_operator_comparison.csv"),
        "device": read_csv(comparison / "device_operator_comparison.csv"),
        "communication_kernels": read_csv(comparison / "communication_kernel_comparison.csv"),
        "communication": read_csv(comparison / "communication_comparison.csv"),
        "communication_collectives": read_csv(collective_path),
        "communication_axis_status": communication_axis_status,
        "phase_evidence": read_json(phase_path),
        "links": read_csv(comparison / "communication_link_comparison.csv"),
        "step": read_csv(comparison / "step_comparison.csv"),
        "memory": read_csv(comparison / "memory_comparison.csv"),
        "unmatched": read_csv(comparison / "unmatched_entities.csv"),
        "bindings": read_csv(comparison / "source_bindings.csv"),
        "source_evidence": read_csv(comparison / "source_evidence.csv"),
        "source_edges": read_csv(comparison / "source_symbol_edges.csv"),
        "source_entry_candidates": read_csv_tree(comparison, "source_entrypoint_candidates.csv"),
        "shell_launch_chain": read_csv_tree(comparison, "shell_launch_chain.csv"),
        "operator_source_map": read_csv_tree(comparison, "thread_operator_source_map.csv")
        or read_csv_tree(comparison, "pytorch_operator_source_map.csv"),
        "source_mapping_status": read_json_rows(comparison / "source_mapping_status.json"),
        "source_mapping_issues": read_csv(comparison / "source_mapping_issues.csv"),
        "source_analysis_status": read_json_rows(comparison / "source_analysis_status.json"),
        "launch_candidates": read_csv_tree(comparison, "launch_command_candidates.csv"),
        "source_runtime_config": read_csv_tree(comparison, "source_runtime_config.csv"),
        "source_resolution_issues": read_csv_tree(comparison, "source_resolution_issues.csv"),
    }
    if len(data["selected_rank"]) != 1:
        raise ValueError("selected_rank_pair.csv 必须恰有一行")
    thread_status = data["thread_status"]
    if thread_status.get("status") == "完成":
        real_threads = [row for row in data["selected_thread"] if row.get("environment", "").startswith("real")]
        sim_threads = [row for row in data["selected_thread"] if row.get("environment", "").startswith("sim")]
        if len(real_threads) != 1 or len(sim_threads) != 1:
            raise ValueError("线程分析完成态要求 selected_thread_pair.csv 真机/仿真各一行")
        if not data["thread_comparison"] or not data["thread_heatmap"]:
            raise ValueError("线程分析完成态缺少算子比较或热力图证据")
        if not all(row.get("selected_pair_fingerprint") and row.get("selection_audit_steps") for row in data["selected_thread"]):
            raise ValueError("线程选择缺少 seed+SHA-256 排序审计字段")
        bin_shares: dict[tuple[str, str], float] = {}
        for row in data["thread_heatmap"]:
            try:
                share = float(row.get("share_of_bin_percent", 0) or 0)
            except ValueError as exc:
                raise ValueError("热力图 share_of_bin_percent 不是数值") from exc
            if share < -1e-9 or share > 100.000001:
                raise ValueError(f"热力图时间桶占比越界：{share}")
            key = (str(row.get("environment", "")), str(row.get("bin_index", "")))
            bin_shares[key] = bin_shares.get(key, 0.0) + share
        overflow = [(key, value) for key, value in bin_shares.items() if value > 100.000001]
        if overflow:
            raise ValueError(f"热力图同一环境/时间桶占比合计超过 100%：{overflow[0]}")
    return data


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--comparison-output", required=True, type=Path, help="compare_ascend_profiles.py 的顶层输出目录")
    parser.add_argument("--top", type=int, default=20, help="每张明细表最多渲染的实体数，默认 20")
    args = parser.parse_args()
    if args.top <= 0:
        parser.error("--top 必须为正数")
    root = args.comparison_output.resolve()
    if not root.is_dir():
        parser.error(f"对比输出目录不存在：{root}")
    try:
        data = load_data(root)
    except (ValueError, json.JSONDecodeError) as exc:
        parser.error(str(exc))

    reports = {
        REPORT_NAMES[0]: report_00(data, args.top),
        REPORT_NAMES[1]: report_01(data, args.top),
        REPORT_NAMES[2]: report_02(data, args.top),
        REPORT_NAMES[3]: report_03(data, args.top),
        REPORT_NAMES[4]: report_04(data, args.top),
        REPORT_NAMES[5]: report_05(data, args.top),
    }
    reports_dir = root / "reports"
    if reports_dir.exists():
        if reports_dir.is_symlink():
            parser.error(f"拒绝向符号链接报告目录写入：{reports_dir}")
        resolved_reports = reports_dir.resolve()
        if resolved_reports == root or root not in resolved_reports.parents:
            parser.error(f"报告目录越出对比输出范围：{resolved_reports}")
    reports_dir.mkdir(parents=True, exist_ok=True)
    # A comparison run owns this directory.  Remove regular files from an
    # earlier render so consumers never mistake a stale seventh report for
    # evidence from the current manifest.  Refuse links/directories instead of
    # following or recursively deleting an unexpected target.
    for stale in reports_dir.iterdir():
        if stale.is_symlink() or not stale.is_file():
            parser.error(f"报告目录含有非普通文件，拒绝清理：{stale}")
        stale.unlink()
    for name, content in reports.items():
        (reports_dir / name).write_text(content.rstrip() + "\n", encoding="utf-8")
    print(f"已生成 {len(reports)} 份中文报告：{reports_dir}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

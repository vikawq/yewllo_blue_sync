#!/usr/bin/env python3
"""把 compare_ascend_profiles.py 的确定性结果渲染为六份中文主报告。"""

from __future__ import annotations

import argparse
import csv
import json
import math
import re
from pathlib import Path
from typing import Any, Iterable


REPORT_NAMES = [
    "00_compare_executive_summary.md",
    "01_pair_identity_and_comparability.md",
    "02_pytorch_operator_fidelity.md",
    "03_execution_shape_and_path_fidelity.md",
    "04_communication_step_and_system_fidelity.md",
    "05_code_causality_and_actions.md",
]


def read_csv(path: Path) -> list[dict[str, str]]:
    if not path.is_file():
        return []
    with path.open("r", newline="", encoding="utf-8-sig", errors="replace") as handle:
        return [dict(row) for row in csv.DictReader(handle)]


def read_json(path: Path) -> dict[str, Any]:
    if not path.is_file():
        return {}
    with path.open("r", encoding="utf-8-sig", errors="replace") as handle:
        value = json.load(handle)
    return value if isinstance(value, dict) else {}


def clean(value: Any, limit: int = 240) -> str:
    text = "" if value is None else str(value).strip()
    text = re.sub(r"\s+", " ", text).replace("|", "\\|")
    if not text:
        return "未知"
    return text if len(text) <= limit else text[: limit - 3] + "..."


def number(value: Any) -> float | None:
    text = "" if value is None else str(value).strip().replace(",", "").rstrip("%")
    if text.lower() in {"", "未知", "缺失", "不可计算", "none", "null", "n/a", "na"}:
        return None
    try:
        parsed = float(text)
    except ValueError:
        return None
    return parsed if math.isfinite(parsed) else None


def md_table(
    rows: Iterable[dict[str, Any]],
    columns: list[tuple[str, str]],
    limit: int | None = None,
) -> str:
    materialized = list(rows)
    if limit is not None:
        materialized = materialized[:limit]
    if not materialized:
        return "_无可用数据_\n"
    lines = [
        "| " + " | ".join(title for _, title in columns) + " |",
        "|" + "|".join(["---"] * len(columns)) + "|",
    ]
    for row in materialized:
        lines.append("| " + " | ".join(clean(row.get(field)) for field, _ in columns) + " |")
    return "\n".join(lines) + "\n"


def deviation_score(row: dict[str, Any]) -> float:
    score = 1e15 if row.get("presence") not in {"", None, "两侧存在"} else 0.0
    for field, value in row.items():
        if field.endswith("_delta_percent"):
            parsed = number(value)
            if parsed is not None:
                score = max(score, abs(parsed))
    return score


def ranked(rows: list[dict[str, Any]]) -> list[dict[str, Any]]:
    return sorted(rows, key=deviation_score, reverse=True)


def explicit_inputs(manifest: dict[str, Any]) -> dict[str, tuple[str, str]]:
    result: dict[str, tuple[str, str]] = {}
    for row in manifest.get("explicit_pair_inputs", []):
        if isinstance(row, dict):
            result[str(row.get("field", ""))] = (str(row.get("real", "")), str(row.get("sim", "")))
    return result


def common_header(title: str, manifest: dict[str, Any]) -> str:
    return "\n".join(
        [
            f"# {title}",
            "",
            f"> 真机（reference）：`{clean(manifest.get('real_root'), 1000)}`  ",
            f"> 仿真（candidate）：`{clean(manifest.get('sim_root'), 1000)}`  ",
            "> 差值方向：`仿真 - 真机`；比率方向：`仿真 / 真机`。  ",
            f"> 时间解释门禁：`{clean(manifest.get('timing_interpretation_allowed'))}`。",
            "",
        ]
    )


def summary_map(rows: list[dict[str, str]]) -> dict[str, dict[str, str]]:
    return {row.get("dimension", ""): row for row in rows}


def metric_pair(row: dict[str, str], field: str, unit: str = "") -> str:
    real = clean(row.get(f"real_{field}"))
    sim = clean(row.get(f"sim_{field}"))
    suffix = f" {unit}" if unit else ""
    return f"{real}{suffix} / {sim}{suffix}"


def evidence_pair(row: dict[str, str]) -> str:
    return f"真机 {clean(row.get('real_evidence'), 140)}；仿真 {clean(row.get('sim_evidence'), 140)}"


def notable_items(
    pytorch: list[dict[str, str]],
    device: list[dict[str, str]],
    communication: list[dict[str, str]],
    step: list[dict[str, str]],
) -> list[str]:
    candidates: list[tuple[float, str]] = []
    for row in pytorch:
        text = (
            f"PyTorch `{clean(row.get('operator'))}`，Shape `{clean(row.get('input_shapes'))}`，"
            f"presence={clean(row.get('presence'))}，Device Self 真/仿="
            f"{metric_pair(row, 'device_self_us_total', 'us')}，仿真/真机="
            f"{clean(row.get('device_self_us_total_sim_over_real'))}。"
        )
        candidates.append((deviation_score(row), text))
    for row in device:
        text = (
            f"执行算子 `{clean(row.get('operator'))}`，I/O Shape "
            f"`{clean(row.get('input_shapes'))} -> {clean(row.get('output_shapes'))}`，"
            f"presence={clean(row.get('presence'))}，duration 真/仿="
            f"{metric_pair(row, 'duration_us_total', 'us')}，仿真/真机="
            f"{clean(row.get('duration_us_total_sim_over_real'))}。"
        )
        candidates.append((deviation_score(row), text))
    for row in communication:
        text = (
            f"通信 `{clean(row.get('collective_type'))}` / `{clean(row.get('communication_group'))}`，"
            f"presence={clean(row.get('presence'))}，message 真/仿="
            f"{metric_pair(row, 'transit_size_mb_total', 'MB')}，transit 仿真/真机="
            f"{clean(row.get('transit_ms_total_sim_over_real'))}。"
        )
        candidates.append((deviation_score(row), text))
    for row in step:
        text = (
            f"Step ordinal `{clean(row.get('step_ordinal'))}`，原始 Step 真/仿="
            f"{clean(row.get('real_step'))} / {clean(row.get('sim_step'))}，Stage 真/仿="
            f"{metric_pair(row, 'stage_us', 'us')}，仿真/真机={clean(row.get('stage_us_sim_over_real'))}。"
        )
        candidates.append((deviation_score(row), text))
    return [text for _, text in sorted(candidates, key=lambda item: item[0], reverse=True)[:5]]


def report_00(data: dict[str, Any], top: int) -> str:
    manifest = data["manifest"]
    timing = str(manifest.get("timing_interpretation_allowed", "未知"))
    inputs = explicit_inputs(manifest)
    summaries = summary_map(data["summary"])
    unmatched = sum(int(float(row.get("presence_mismatches", 0) or 0)) for row in data["summary"])
    pytorch_summary = summaries.get("PyTorch operator", {})
    device_summary = summaries.get("device operator", {})
    comm_summary = summaries.get("communication", {})
    lines = [common_header("真机与仿真 Profiling 对比执行摘要", manifest)]
    lines.extend(
        [
            "## 1. 身份与可比性",
            "",
            f"- 模型真/仿：`{clean(inputs.get('model', ('', ''))[0])}` / `{clean(inputs.get('model', ('', ''))[1])}`。",
            f"- Workload 真/仿：`{clean(inputs.get('workload_id', ('', ''))[0])}` / `{clean(inputs.get('workload_id', ('', ''))[1])}`。",
            f"- 阶段真/仿：`{clean(inputs.get('phase', ('', ''))[0])}` / `{clean(inputs.get('phase', ('', ''))[1])}`。",
            f"- Schedule 真/仿：`{clean(inputs.get('schedule_id', ('', ''))[0])}` / `{clean(inputs.get('schedule_id', ('', ''))[1])}`。",
            "",
            "## 2. 三层保真度结论",
            "",
            f"- `真机事实/仿真事实` 结构保真度：PyTorch 两侧实体 {clean(pytorch_summary.get('matched_entities'))} 个，device 两侧实体 {clean(device_summary.get('matched_entities'))} 个，通信两侧实体 {clean(comm_summary.get('matched_entities'))} 个；union 中共有 {unmatched} 个仅一侧实体，需逐项解释。",
            (
                "- `推断` 时间保真度：可在已对齐窗口内解释真/仿差值和比率；单次观测不代表统计分布或回归阈值。"
                if timing == "是"
                else f"- `未知` 时间保真度不可判定/待确认：门禁为 `{clean(timing)}`，表内比率仅用于定位，不能写成仿真性能准确度。"
            ),
            "- `未知` 系统建模保真度：当前对比不能单独证明真实频率、cache、stream 并发、链路竞争、allocator 与同步模型已被仿真覆盖。",
            "",
            "## 3. 五个最重要差异",
            "",
        ]
    )
    items = notable_items(data["pytorch"], data["device"], data["communication"], data["step"])
    lines.extend([f"{index}. {item}" for index, item in enumerate(items, start=1)] or ["1. `未知`：没有可用对比实体。"])
    lines.extend(
        [
            "",
            "## 4. 端到端差异链",
            "",
            "`推断`：模型输入/配置或运行时 dispatch 差异，可能先改变 PyTorch operator、调用次数或 Shape bucket，再改变 device lowering/kernel/format，继而改变通信 message/group/等待与 overlap，最终反映到 Step Stage。当前只有 Profiler 事实；没有源码和 runtime guard 证据时，不能把该链写成已确认因果。",
            "",
            "## 5. 能复现、不能复现、尚未证明",
            "",
            "- `真机事实/仿真事实` 能复现：标为“两侧存在”的 operator、I/O ABI、通信实体和对齐 Step。",
            "- `真机事实/仿真事实` 不能直接复现：标为“仅真机”或“仅仿真”的实体；先排除采集覆盖、命名和窗口差异。",
            "- `未知` 尚未证明：tensor value、routing、KV/cache state、实际并发、频率、链路竞争、源码分支和端到端请求延迟。",
            "",
            "## 6. 三个最小验证动作",
            "",
            "1. 用同一 request、phase、schedule、并行拓扑和 Profiler flags 重采，保留 request/phase marker。",
            "2. 对首个 unmatched PyTorch/Shape 路径做单算子或最小 A/B，记录 guard、输入 Shape、kernel 与通信 group。",
            "3. 固定两侧运行 commit/build ID，并对仿真器的 kernel、通信、并发、cache、频率和 allocator 建模范围逐项声明。",
            "",
        ]
    )
    return "\n".join(lines)


def report_01(data: dict[str, Any], top: int) -> str:
    manifest = data["manifest"]
    gates = data["gates"]
    coverage = data["coverage"]
    missing_or_mismatch = [row for row in coverage if row.get("match") != "是" or (row.get("real_present") != "是" and row.get("sim_present") != "是")]
    lines = [common_header("配对身份、采集覆盖与可比性", manifest)]
    lines.extend(
        [
            "## 1. 可比性门禁",
            "",
            md_table(gates, [("gate", "门禁"), ("field", "输入字段"), ("real", "真机"), ("sim", "仿真"), ("status", "状态"), ("detail", "证据/说明"), ("impact", "对后续结论的影响")]),
            "## 2. Rank 与并行坐标映射",
            "",
            md_table(data["ranks"], [("rank_alignment_key", "对齐键"), ("real_rank", "真机 Rank"), ("sim_rank", "仿真 Rank"), ("real_parallel_coordinate", "真机 DP/TP/EP/PP/CP/DCP"), ("sim_parallel_coordinate", "仿真 DP/TP/EP/PP/CP/DCP"), ("presence", "Presence"), ("confidence", "置信度")], top),
            "## 3. Step/窗口对齐候选",
            "",
            md_table(data["windows"], [("rank_alignment_key", "Rank"), ("step_ordinal", "序号"), ("real_step", "真机 Step"), ("sim_step", "仿真 Step"), ("presence", "Presence"), ("alignment_method", "对齐方法"), ("timing_interpretation_allowed", "时间可解释性")], top),
            "## 4. 主证据 Coverage",
            "",
            f"`事实`：共检查 {len(coverage)} 个 rank/file 条目；不对称或双方均缺的条目 {len(missing_or_mismatch)} 个。缺失不是实测 0。",
            "",
            md_table(missing_or_mismatch or coverage, [("rank_alignment_key", "Rank"), ("file", "文件"), ("real_present", "真机"), ("sim_present", "仿真"), ("match", "一致"), ("priority", "优先级")], top),
            "## 5. 允许与禁止解释",
            "",
            "- 允许：双方有直接证据的 operator/Shape/presence、通信 message/group/link 和对齐 Step 事实。",
            "- 有条件允许：只有时间门禁为“是”时，才解释同口径时间差与仿真/真机比率。",
            "- 禁止：把缺文件当 0、把同名 Step 当同一步、把 global rank 相同当 shard 相同、把 kernel sum 当墙钟。",
            "- `未知`：采集时间、权重/config、batch/sequence/concurrency 等若未在元数据或用户输入中出现，需在正式结论前补齐。",
            "",
        ]
    )
    return "\n".join(lines)


def report_02(data: dict[str, Any], top: int) -> str:
    manifest = data["manifest"]
    rows = ranked(data["pytorch"])
    only_real = sum(row.get("presence") == "仅真机" for row in rows)
    only_sim = sum(row.get("presence") == "仅仿真" for row in rows)
    matched = sum(row.get("presence") == "两侧存在" for row in rows)
    lines = [common_header("PyTorch Operator 与调用路径保真度", manifest)]
    lines.extend(
        [
            "## 1. Presence 与 Shape 覆盖",
            "",
            f"`事实`：union 共 {len(rows)} 个 `rank + operator + normalized input Shape` 实体；双方存在 {matched}，仅真机 {only_real}，仅仿真 {only_sim}。比较使用逐 rank 未截断签名，不以全局 Top-N 缺失判断实体不存在。",
            "",
            "## 2. 重点 PyTorch 实体",
            "",
            md_table(rows, [("rank_alignment_key", "Rank 坐标"), ("operator", "PyTorch operator"), ("input_shapes", "Input Shape"), ("presence", "Presence"), ("real_calls", "Calls 真"), ("sim_calls", "Calls 仿"), ("real_device_self_us_total", "Device Self 真(us)"), ("sim_device_self_us_total", "Device Self 仿(us)"), ("device_self_us_total_sim_over_real", "仿真/真机"), ("call_stack_id_match", "Call stack 一致"), ("real_evidence", "真机证据"), ("sim_evidence", "仿真证据")], top),
            "## 3. Calls、per-call 与总量拆解",
            "",
            "`推断`：总时间差必须拆成调用数变化、per-call 变化及 Shape/path 变化。CSV 已提供 `*_volume_effect` 与 `*_unit_cost_effect`；只有双方实体、窗口和时间语义可比时才解释。",
            "",
            md_table(rows, [("operator", "Operator"), ("input_shapes", "Shape"), ("device_self_us_total_sim_minus_real", "Device Self 仿-真(us)"), ("device_self_us_total_volume_effect", "调用量效应(us)"), ("device_self_us_total_unit_cost_effect", "单位成本效应(us)"), ("real_device_self_us_per_call", "真机 per-call(us)"), ("sim_device_self_us_per_call", "仿真 per-call(us)")], top),
            "## 4. 解释边界",
            "",
            "- PyTorch output Shape 在 `operator_details.csv` 无直接证据时保持未知，不从 device kernel 反填。",
            "- call stack 作为差异属性，不作为跨环境主 join key；绝对路径和行号可能因安装位置或版本改变。",
            "- 相同 operator/Shape 不证明 tensor value、mask、routing、KV slot 或 cache state 相同。",
            "- attention/MoE/KV/GEMM/norm/graph 路径需结合真实模型实体和源码后再命名；本报告不凭模糊 kernel 名猜测。",
            "",
        ]
    )
    return "\n".join(lines)


def report_03(data: dict[str, Any], top: int) -> str:
    manifest = data["manifest"]
    rows = ranked(data["device"])
    matched = sum(row.get("presence") == "两侧存在" for row in rows)
    lines = [common_header("执行算子、I/O Shape 与 Lowering 路径保真度", manifest)]
    lines.extend(
        [
            "## 1. 执行实体覆盖",
            "",
            f"`事实`：device union 共 {len(rows)} 个完整 ABI 实体，双方存在 {matched}。主键包含 rank、name/type/core、input/output Shape、dtype 与 format。",
            "",
            "## 2. Device operator/kernel 主表",
            "",
            md_table(rows, [("rank_alignment_key", "Rank 坐标"), ("operator", "Device operator"), ("type", "Type"), ("input_shapes", "Input Shape"), ("output_shapes", "Output Shape"), ("input_dtypes", "Input dtype"), ("output_dtypes", "Output dtype"), ("input_formats", "Input format"), ("output_formats", "Output format"), ("accelerator_core", "Core"), ("presence", "Presence"), ("real_calls", "Calls 真"), ("sim_calls", "Calls 仿"), ("real_duration_us_total", "Duration 真(us)"), ("sim_duration_us_total", "Duration 仿(us)"), ("duration_us_total_sim_over_real", "仿真/真机"), ("real_evidence", "真机证据"), ("sim_evidence", "仿真证据")], top),
            "## 3. 路径解释",
            "",
            "- PyTorch 一致但 kernel/name 不同：优先检查 backend lowering、fusion、tiling、编译和版本。",
            "- Shape 一致但 dtype/format 不同：优先检查 cast、layout、padding 与 backend 配置。",
            "- PyTorch 存在但仿真缺 device 实体：可能是 fusion、未建模、采集覆盖或关联差异，不能直接判定漏算。",
            "- 结构完全一致但 duration 不同：检查仿真 timing model、真实频率/cache、并发 stream 与 contention。",
            "",
            "## 4. 时间口径边界",
            "",
            "`事实`：device duration 求和不是 Step 墙钟；真实环境可能并行执行多个 stream，仿真也可能序列化或省略等待。必须与 Step/overlap 联合解释。",
            "",
        ]
    )
    return "\n".join(lines)


def report_04(data: dict[str, Any], top: int) -> str:
    manifest = data["manifest"]
    comm_kernels = ranked(data["communication_kernels"])
    comm = ranked(data["communication"])
    links = ranked(data["links"])
    steps = ranked(data["step"])
    memory = ranked(data["memory"])
    lines = [common_header("通信、Step、Overlap、Rank 与系统建模保真度", manifest)]
    lines.extend(
        [
            "## 1. 通信执行算子与 I/O Shape",
            "",
            md_table(comm_kernels, [("rank_alignment_key", "Rank/并行坐标"), ("operator", "通信算子"), ("type", "Type"), ("accelerator_core", "Core"), ("input_shapes", "Input Shape"), ("output_shapes", "Output Shape"), ("input_dtypes", "Input dtype"), ("output_dtypes", "Output dtype"), ("input_formats", "Input format"), ("output_formats", "Output format"), ("presence", "Presence"), ("real_calls", "Calls 真"), ("sim_calls", "Calls 仿"), ("real_duration_us_total", "Duration 真(us)"), ("sim_duration_us_total", "Duration 仿(us)"), ("real_wait_us_total", "Wait 真(us)"), ("sim_wait_us_total", "Wait 仿(us)"), ("real_evidence", "真机证据"), ("sim_evidence", "仿真证据")], top),
            "## 2. 通信消息、Group 与时间",
            "",
            md_table(comm, [("rank_alignment_key", "Rank/轴"), ("category", "类别"), ("collective_type", "Type"), ("communication_group", "Group"), ("parallel_axis", "并行轴"), ("presence", "Presence"), ("real_calls", "Calls 真"), ("sim_calls", "Calls 仿"), ("real_transit_size_mb_total", "Message 真(MB)"), ("sim_transit_size_mb_total", "Message 仿(MB)"), ("real_transit_ms_total", "Transit 真(ms)"), ("sim_transit_ms_total", "Transit 仿(ms)"), ("real_wait_ms_total", "Wait 真(ms)"), ("sim_wait_ms_total", "Wait 仿(ms)"), ("real_synchronization_ms_total", "Sync 真(ms)"), ("sim_synchronization_ms_total", "Sync 仿(ms)"), ("real_evidence", "真机证据"), ("sim_evidence", "仿真证据")], top),
            "## 3. Peer/Link/Transport",
            "",
            md_table(links, [("rank_alignment_key", "Rank"), ("collective_type", "Type"), ("communication_group", "Group"), ("parallel_axis", "轴"), ("link", "Peer/Link"), ("presence", "Presence"), ("real_transit_size_mb", "Message 真(MB)"), ("sim_transit_size_mb", "Message 仿(MB)"), ("real_transit_ms", "Transit 真(ms)"), ("sim_transit_ms", "Transit 仿(ms)"), ("real_transport_type", "Transport 真"), ("sim_transport_type", "Transport 仿")], top),
            "## 4. Step、通信非重叠与墙钟",
            "",
            md_table(steps, [("rank_alignment_key", "Rank"), ("step_ordinal", "语义阶段/Step 序号"), ("real_step", "原始 Step 真"), ("sim_step", "原始 Step 仿"), ("real_stage_us", "Stage 真(us)"), ("sim_stage_us", "Stage 仿(us)"), ("real_computing_us", "Compute 真(us)"), ("sim_computing_us", "Compute 仿(us)"), ("real_communication_us", "Communication 真(us)"), ("sim_communication_us", "Communication 仿(us)"), ("real_communication_not_overlapped_us", "Not-overlap 真(us)"), ("sim_communication_not_overlapped_us", "Not-overlap 仿(us)"), ("stage_us_sim_over_real", "Stage 仿真/真机"), ("timing_interpretation_allowed", "可解释性")], top),
            "## 5. 内存与系统模型",
            "",
            md_table(memory, [("rank_alignment_key", "Rank"), ("component", "组件"), ("device_type", "设备"), ("presence", "Presence"), ("real_max_allocated_mb", "Allocated 真(MB)"), ("sim_max_allocated_mb", "Allocated 仿(MB)"), ("real_max_reserved_mb", "Reserved 真(MB)"), ("sim_max_reserved_mb", "Reserved 仿(MB)"), ("real_max_active_mb", "Active 真(MB)"), ("sim_max_active_mb", "Active 仿(MB)")], top),
            "`未知`：若仿真没有 allocator、fragmentation、frequency、cache、stream contention、链路竞争或同步模型，相应维度应标为“未建模/不适用”，不能把缺失值解释为 0。当前单次小样本也不足以可靠评价 rank imbalance 分布；多 rank 时应分别比较两侧 max/min、CV 与慢 rank 坐标。",
            "",
            "> HCCL AICPU duration 可能包含等待或同步，不等同于链路传输时间；链路口径应以 communication.json/matrix 为准。",
            "",
        ]
    )
    return "\n".join(lines)


def report_05(data: dict[str, Any], top: int) -> str:
    manifest = data["manifest"]
    bindings = data["bindings"]
    provided = [row for row in bindings if row.get("repository_url_or_path")]
    source_evidence = data["source_evidence"]
    source_edges = data["source_edges"]
    lines = [common_header("模型源码因果证据与改进行动", manifest)]
    lines.extend(["## 1. 环境与源码绑定", ""])
    if provided:
        lines.extend(
            [
                md_table(provided, [("environment", "环境"), ("repository_url_or_path", "Repo/本地路径"), ("requested_ref", "请求 ref"), ("resolved_commit", "解析 commit"), ("runtime_binding", "运行绑定"), ("access_mode", "读取方式"), ("notes", "说明")]),
                "`未知`：自动渲染只登记用户输入，不访问仓库。分析代理必须打开用户给出的 GitHub/GitCode URL 或只读本地 checkout，把 branch/tag 固定到 commit，并核验该 commit 是否是 Profiling 运行版本。",
                "",
            ]
        )
    else:
        lines.extend(["`未知`：未提供源码，不能做代码级因果绑定；Profiler-only 对比仍然有效。", ""])
    lines.extend(["## 2. 已有源码证据", ""])
    if source_evidence:
        lines.append(md_table(source_evidence, [("evidence_id", "证据 ID"), ("environment", "环境"), ("repository", "Repo"), ("commit", "Commit"), ("path", "文件"), ("symbol", "Symbol"), ("line_start", "起始行"), ("line_end", "结束行"), ("evidence_kind", "类型"), ("permalink", "永久链接"), ("note", "说明")], top))
    else:
        lines.extend(["_尚无 `source_evidence.csv`；不得把静态源码中可能执行的分支写成本次运行事实。_", ""])
    lines.extend(["## 3. 跨文件符号边", ""])
    lines.append(
        md_table(source_edges, [("from_symbol", "调用方"), ("from_location", "位置"), ("edge_type", "边类型"), ("to_symbol", "被调用方"), ("to_location", "位置"), ("guard_or_config", "Guard/配置"), ("evidence_ids", "证据"), ("confidence", "置信度")], top)
        if source_edges
        else "_尚无 `source_symbol_edges.csv`；代码链保持未知。_\n"
    )
    lines.extend(
        [
            "## 4. Profiler 差异到源码的有界路径",
            "",
            "`推断`：优先从重大 unmatched operator/call stack/Shape/group/Step 差异出发，追踪 `入口/config -> guard/dispatch -> Shape/count/group producer -> PyTorch/custom op -> backend/communication call`。相同 commit 时先检查输入、配置、环境变量和运行时 backend；不同 commit 时只对已证实执行路径做有界 diff。",
            "",
            "## 5. 行动清单",
            "",
            "### 已确认的仿真缺口",
            "",
            "只有 `unmatched_entities.csv` 中经排除采集、命名、窗口和版本差异后仍成立的实体，才能列为已确认缺口；自动渲染不越过该证据门槛。",
            "",
            "### 需要补证的候选缺口",
            "",
            "- 运行 commit/build ID、模型配置和 runtime guard 值。",
            "- unmatched PyTorch/Shape 到实际 call site 的 stack/flow/marker。",
            "- process-group 成员、并行轴、message producer 与 peer/link 映射。",
            "- 仿真 timing、frequency/cache、stream、communication 与 allocator 能力声明。",
            "",
            "### 最小重采、单元测试与 A/B",
            "",
            "1. 同 request/phase/schedule 复采，增加 module/stack/Shape/flow 和源码 commit marker。",
            "2. 对首个结构差异固定输入做单算子或单层 A/B，同时记录 PyTorch、device 与通信事件。",
            "3. 固定同一 commit 后只改变真机/仿真 backend；若两侧 commit 不同，再做受控版本 A/B。",
            "",
            "### 可自动化回归指标",
            "",
            "- PyTorch/device/communication 结构覆盖率与仅一侧实体数。",
            "- calls、per-call、message/call、transit、wait、not-overlapped 与 Stage bias。",
            "- rank imbalance、内存峰值与系统未建模项计数。",
            "",
            "未提供项目容差时只给数值和排序，不自行宣布通过/失败。",
            "",
        ]
    )
    return "\n".join(lines)


def load_data(root: Path) -> dict[str, Any]:
    comparison = root / "comparison"
    manifest = read_json(comparison / "comparison_manifest.json")
    if not manifest:
        raise ValueError(f"缺少或无法读取 {comparison / 'comparison_manifest.json'}")
    return {
        "manifest": manifest,
        "summary": read_csv(comparison / "comparison_summary.csv"),
        "gates": read_csv(comparison / "comparability_gates.csv"),
        "coverage": read_csv(comparison / "coverage_comparison.csv"),
        "ranks": read_csv(comparison / "rank_alignment.csv"),
        "windows": read_csv(comparison / "window_alignment.csv"),
        "pytorch": read_csv(comparison / "pytorch_operator_comparison.csv"),
        "device": read_csv(comparison / "device_operator_comparison.csv"),
        "communication_kernels": read_csv(comparison / "communication_kernel_comparison.csv"),
        "communication": read_csv(comparison / "communication_comparison.csv"),
        "links": read_csv(comparison / "communication_link_comparison.csv"),
        "step": read_csv(comparison / "step_comparison.csv"),
        "memory": read_csv(comparison / "memory_comparison.csv"),
        "unmatched": read_csv(comparison / "unmatched_entities.csv"),
        "bindings": read_csv(comparison / "source_bindings.csv"),
        "source_evidence": read_csv(comparison / "source_evidence.csv"),
        "source_edges": read_csv(comparison / "source_symbol_edges.csv"),
    }


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--comparison-output", required=True, type=Path, help="compare_ascend_profiles.py 的顶层输出目录")
    parser.add_argument("--top", type=int, default=20, help="每张明细表最多渲染的实体数，默认 20")
    args = parser.parse_args()
    if args.top <= 0:
        parser.error("--top 必须为正数")
    root = args.comparison_output.resolve()
    if not root.is_dir():
        parser.error(f"对比输出目录不存在：{root}")
    try:
        data = load_data(root)
    except (ValueError, json.JSONDecodeError) as exc:
        parser.error(str(exc))

    reports = {
        REPORT_NAMES[0]: report_00(data, args.top),
        REPORT_NAMES[1]: report_01(data, args.top),
        REPORT_NAMES[2]: report_02(data, args.top),
        REPORT_NAMES[3]: report_03(data, args.top),
        REPORT_NAMES[4]: report_04(data, args.top),
        REPORT_NAMES[5]: report_05(data, args.top),
    }
    reports_dir = root / "reports"
    reports_dir.mkdir(parents=True, exist_ok=True)
    for name, content in reports.items():
        (reports_dir / name).write_text(content.rstrip() + "\n", encoding="utf-8")
    print(f"已生成 {len(reports)} 份中文报告：{reports_dir}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

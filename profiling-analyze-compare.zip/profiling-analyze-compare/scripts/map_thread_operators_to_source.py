#!/usr/bin/env python3
"""Map selected-thread PyTorch events to conservatively parsed local source.

Only Python's :mod:`ast` parser is used for project Python code. The script
never imports, executes, compiles, or evaluates repository modules.
"""

from __future__ import annotations

import argparse
import ast
import csv
import hashlib
import json
import os
import re
import sys
import tempfile
import tokenize
from collections import defaultdict, deque
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Iterable
from urllib.parse import quote, urlsplit, urlunsplit


MAP_FIELDS = [
    "environment",
    "rank_pair_id",
    "pid",
    "tid",
    "event_id",
    "event_index",
    "operator_name",
    "input_shape",
    "output_shape",
    "python_entry",
    "model_symbol",
    "callsite_path",
    "line_start",
    "line_end",
    "mapping_method",
    "runtime_evidence_ids",
    "source_evidence_ids",
    "confidence",
    "ambiguity_count",
    "notes",
]

EDGE_FIELDS = [
    "environment",
    "from_symbol",
    "from_location",
    "edge_type",
    "to_symbol",
    "to_location",
    "guard_or_config",
    "evidence_ids",
    "confidence",
]

EVIDENCE_FIELDS = [
    "evidence_id",
    "environment",
    "repository",
    "commit",
    "path",
    "line_start",
    "line_end",
    "symbol",
    "evidence_kind",
    "permalink",
    "content_sha256",
    "note",
]

ISSUE_FIELDS = [
    "issue_id",
    "environment",
    "event_id",
    "source_location",
    "issue_kind",
    "expression_redacted",
    "impact",
    "status",
    "minimum_user_input",
]

SENSITIVE_RE = re.compile(
    r"(?:token|pass(?:word)?|secret|api[_-]?key|private[_-]?key|cookie|credential|auth(?:orization)?)",
    re.IGNORECASE,
)

STACK_PATTERNS = [
    re.compile(
        r"File\s+[\"'](?P<path>[^\"']+\.py)[\"']\s*,\s*line\s+(?P<line>\d+)"
        r"(?:\s*,\s*in\s+(?P<symbol>[A-Za-z_][A-Za-z0-9_.<>]*))?",
        re.IGNORECASE,
    ),
    re.compile(
        r"(?P<path>(?:[A-Za-z]:[\\/]|/)?[^;\n()]*?\.py)\((?P<line>\d+)\)"
        r"(?::\s*(?P<symbol>[A-Za-z_][A-Za-z0-9_.<>]*))?"
    ),
    re.compile(
        r"(?P<path>(?:[A-Za-z]:[\\/]|/)?[^;\n:]*?\.py):(?P<line>\d+)"
        r"(?::(?:in\s+)?(?P<symbol>[A-Za-z_][A-Za-z0-9_.<>]*))?"
    ),
]

TENSOR_METHODS = {
    "abs", "add", "addmm", "argmax", "argmin", "bmm", "chunk", "clone", "contiguous",
    "copy_", "cos", "div", "embedding", "exp", "expand", "flatten", "gather", "index_select",
    "log", "masked_fill", "masked_fill_", "matmul", "max", "mean", "min", "mm", "mul", "narrow",
    "nonzero", "permute", "pow", "relu", "reshape", "scatter", "sigmoid", "sin", "softmax",
    "split", "squeeze", "stack", "sub", "sum", "tanh", "to", "transpose", "type_as", "unbind",
    "unsqueeze", "view", "where",
}

COLLECTIVES = {
    "all_gather", "all_gather_into_tensor", "all_reduce", "all_to_all", "all_to_all_single",
    "barrier", "broadcast", "gather", "isend", "irecv", "recv", "reduce", "reduce_scatter",
    "reduce_scatter_tensor", "scatter", "send",
}

OP_FAMILIES = [
    {"linear", "addmm"},
    {"matmul", "mm", "bmm"},
    {"layer_norm", "native_layer_norm", "layernorm"},
    {"rms_norm", "rmsnorm"},
    {"relu", "relu_"},
    {"silu", "silu_"},
    {"softmax", "_softmax"},
    {"scaled_dot_product_attention", "flash_attention", "attention"},
    {"all_reduce", "allreduce", "all_reduce_"},
    {"all_gather", "allgather", "all_gather_into_tensor"},
    {"reduce_scatter", "reduce_scatter_tensor", "reducescatter"},
]

EXCLUDED_DIRS = {
    ".git", ".hg", ".svn", ".venv", "venv", "env", "node_modules", "__pycache__",
    "site-packages", "dist", "build",
}


def sanitize_url(value: str) -> str:
    if not re.match(r"^https?://", value or "", re.IGNORECASE):
        return value
    try:
        parts = urlsplit(value)
    except ValueError:
        return "<invalid-url>"
    host = parts.hostname or ""
    if parts.port:
        host = f"{host}:{parts.port}"
    fragment = parts.fragment if re.fullmatch(r"L\d+(?:-L\d+)?", parts.fragment or "") else ""
    return urlunsplit((parts.scheme, host, parts.path, "", fragment))


def redact(value: str) -> str:
    value = re.sub(
        r"(?i)\b([A-Za-z_][A-Za-z0-9_]*(?:TOKEN|PASS(?:WORD)?|SECRET|API[_-]?KEY|COOKIE|CREDENTIAL|AUTH)[A-Za-z0-9_]*)\s*=\s*(?:\"[^\"]*\"|'[^']*'|[^\s;,]+)",
        lambda match: f"{match.group(1)}=[REDACTED]",
        value or "",
    )
    value = re.sub(
        r"(?i)(--(?:token|password|pass|secret|api[-_]?key|cookie|credential|auth))(?:=|\s+)(?:\"[^\"]*\"|'[^']*'|[^\s;,]+)",
        lambda match: f"{match.group(1)}=[REDACTED]",
        value,
    )
    return re.sub(r"https?://[^\s'\"]+", lambda match: sanitize_url(match.group(0)), value)


def stable_id(prefix: str, *parts: Any) -> str:
    payload = "\x1f".join(str(part) for part in parts)
    return f"{prefix}-{hashlib.sha256(payload.encode('utf-8')).hexdigest()[:16]}"


def read_csv(path: Path) -> list[dict[str, str]]:
    if not path.is_file():
        return []
    with path.open("r", encoding="utf-8-sig", newline="") as handle:
        return [dict(row) for row in csv.DictReader(handle)]


def write_merged_csv(
    path: Path,
    fields: list[str],
    rows: list[dict[str, Any]],
    environment: str,
    *,
    replace_environment: bool,
    identity_fields: list[str],
) -> None:
    existing = read_csv(path)
    if replace_environment:
        existing = [row for row in existing if row.get("environment", "") not in {environment}]
    all_fields = list(fields)
    for row in existing:
        for key in row:
            if key not in all_fields:
                all_fields.append(key)
    combined: list[dict[str, Any]] = []
    seen: set[tuple[str, ...]] = set()
    for row in [*existing, *rows]:
        key = tuple(str(row.get(field, "")) for field in identity_fields)
        if key in seen:
            continue
        seen.add(key)
        combined.append(row)
    with path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=all_fields, extrasaction="ignore")
        writer.writeheader()
        writer.writerows(combined)


def camel_to_snake(value: str) -> str:
    first = re.sub(r"(.)([A-Z][a-z]+)", r"\1_\2", value)
    return re.sub(r"([a-z0-9])([A-Z])", r"\1_\2", first).lower()


def operator_base(value: str) -> str:
    text = (value or "").strip().lower()
    if "::" in text:
        text = text.rsplit("::", 1)[-1]
    text = text.split(".", 1)[0]
    text = text.replace("-", "_")
    return text


def op_matches(event_op: str, source_op: str) -> tuple[bool, str]:
    event = operator_base(event_op)
    source = operator_base(source_op)
    if not event or not source:
        return False, "none"
    if event == source or event.rstrip("_") == source.rstrip("_"):
        return True, "exact"
    for family in OP_FAMILIES:
        normalized = {item.rstrip("_") for item in family}
        if event.rstrip("_") in normalized and source.rstrip("_") in normalized:
            return True, "family"
    return False, "none"


def dotted_name(node: ast.AST) -> str:
    if isinstance(node, ast.Name):
        return node.id
    if isinstance(node, ast.Attribute):
        parent = dotted_name(node.value)
        return f"{parent}.{node.attr}" if parent else node.attr
    if isinstance(node, ast.Subscript):
        return dotted_name(node.value)
    return ""


def literal_integers(node: ast.Call) -> tuple[int, ...]:
    values: set[int] = set()
    for item in [*node.args, *(keyword.value for keyword in node.keywords)]:
        for child in ast.walk(item):
            if isinstance(child, ast.Constant) and isinstance(child.value, int) and not isinstance(child.value, bool):
                values.add(child.value)
    return tuple(sorted(values))


def module_name_for(path: Path, root: Path) -> str:
    relative = path.relative_to(root)
    parts = list(relative.parts)
    if parts and parts[0] == "src":
        parts = parts[1:]
    if not parts:
        return ""
    filename = parts.pop()
    stem = Path(filename).stem
    if stem != "__init__":
        parts.append(stem)
    return ".".join(parts)


def relative_import_module(current_module: str, module: str | None, level: int) -> str:
    if level <= 0:
        return module or ""
    package_parts = current_module.split(".")[:-1]
    keep = max(0, len(package_parts) - level + 1)
    base = package_parts[:keep]
    if module:
        base.extend(module.split("."))
    return ".".join(part for part in base if part)


@dataclass
class ImportRecord:
    module: str
    imported_name: str
    alias: str
    line: int
    level: int = 0


@dataclass
class Symbol:
    path: Path
    module: str
    qualname: str
    name: str
    kind: str
    line_start: int
    line_end: int
    class_name: str = ""

    @property
    def identifier(self) -> str:
        return f"{self.path.as_posix()}::{self.qualname}"


@dataclass
class Callsite:
    path: Path
    module: str
    caller: str
    caller_class: str
    line_start: int
    line_end: int
    raw_callee: str
    canonical_callee: str
    source_op: str
    call_kind: str
    literal_ints: tuple[int, ...] = ()
    symbol_reachable: bool = False
    file_reachable: bool = False

    @property
    def identifier(self) -> str:
        return f"{self.path.as_posix()}:{self.line_start}:{self.line_end}:{self.caller}:{self.canonical_callee}"


@dataclass
class ParsedFile:
    path: Path
    module: str
    text: str
    tree: ast.AST
    aliases: dict[str, str]
    imports: list[ImportRecord]
    symbols: list[Symbol]
    calls: list[Callsite]
    module_attrs: dict[tuple[str, str], str]


class FileVisitor(ast.NodeVisitor):
    def __init__(
        self,
        path: Path,
        module: str,
        aliases: dict[str, str],
        module_attrs: dict[tuple[str, str], str],
    ) -> None:
        self.path = path
        self.module = module
        self.aliases = aliases
        self.module_attrs = module_attrs
        self.symbols: list[Symbol] = [Symbol(path, module, "<module>", "<module>", "module", 1, 1)]
        self.calls: list[Callsite] = []
        self.scope_stack: list[str] = ["<module>"]
        self.class_stack: list[str] = []

    @property
    def current_scope(self) -> str:
        return ".".join(item for item in self.scope_stack if item != "<module>") or "<module>"

    def visit_ClassDef(self, node: ast.ClassDef) -> Any:
        qualname = ".".join([*self.class_stack, node.name])
        self.symbols.append(
            Symbol(
                self.path,
                self.module,
                qualname,
                node.name,
                "class",
                node.lineno,
                getattr(node, "end_lineno", node.lineno),
                node.name,
            )
        )
        self.class_stack.append(node.name)
        self.scope_stack.append(node.name)
        self.generic_visit(node)
        self.scope_stack.pop()
        self.class_stack.pop()

    def _visit_function(self, node: ast.FunctionDef | ast.AsyncFunctionDef) -> Any:
        qualname = ".".join([*self.class_stack, node.name]) if self.class_stack else node.name
        self.symbols.append(
            Symbol(
                self.path,
                self.module,
                qualname,
                node.name,
                "method" if self.class_stack else "function",
                node.lineno,
                getattr(node, "end_lineno", node.lineno),
                self.class_stack[-1] if self.class_stack else "",
            )
        )
        self.scope_stack.append(node.name)
        self.generic_visit(node)
        self.scope_stack.pop()

    def visit_FunctionDef(self, node: ast.FunctionDef) -> Any:
        return self._visit_function(node)

    def visit_AsyncFunctionDef(self, node: ast.AsyncFunctionDef) -> Any:
        return self._visit_function(node)

    def canonical(self, raw: str) -> tuple[str, str, str]:
        if not raw:
            return "", "", "python_call"
        parts = raw.split(".")
        first = parts[0]
        canonical = self.aliases.get(first, first)
        if len(parts) > 1:
            canonical = ".".join([canonical, *parts[1:]])
        class_name = self.class_stack[-1] if self.class_stack else ""
        if raw.startswith("self.") and len(parts) == 2 and class_name:
            module_type = self.module_attrs.get((class_name, parts[1]))
            if module_type:
                return module_type, camel_to_snake(module_type.rsplit(".", 1)[-1]), "nn_module_call"
        lower = canonical.lower()
        last = canonical.rsplit(".", 1)[-1]
        if lower.startswith("torch.ops."):
            pieces = canonical.split(".")
            source_op = pieces[-1] if len(pieces) < 4 else pieces[-1]
            return canonical, source_op, "custom_op"
        if lower.startswith("torch.distributed") or (
            last.lower() in COLLECTIVES and any(prefix in lower for prefix in ("dist.", "distributed"))
        ):
            return canonical, last.lower(), "collective_call"
        if lower.startswith("torch."):
            return canonical, camel_to_snake(last), "torch_call"
        if len(parts) > 1 and parts[-1].lower() in TENSOR_METHODS:
            return f"tensor.{parts[-1]}", parts[-1].lower(), "tensor_method"
        return canonical, camel_to_snake(last), "python_call"

    def visit_Call(self, node: ast.Call) -> Any:
        raw = dotted_name(node.func)
        canonical, source_op, kind = self.canonical(raw)
        self.calls.append(
            Callsite(
                path=self.path,
                module=self.module,
                caller=self.current_scope,
                caller_class=self.class_stack[-1] if self.class_stack else "",
                line_start=node.lineno,
                line_end=getattr(node, "end_lineno", node.lineno),
                raw_callee=raw,
                canonical_callee=canonical,
                source_op=source_op,
                call_kind=kind,
                literal_ints=literal_integers(node),
            )
        )
        self.generic_visit(node)


@dataclass
class Budget:
    max_python_files: int
    max_python_bytes: int
    max_depth: int
    files_read: int = 0
    bytes_read: int = 0


class Mapper:
    def __init__(
        self,
        repo_root: Path,
        source_analysis_dir: Path,
        thread_events: Path,
        output: Path,
        environment: str,
        budget: Budget,
    ) -> None:
        self.repo_root = repo_root.resolve(strict=True)
        self.source_analysis_dir = source_analysis_dir.resolve(strict=True)
        self.thread_events_path = thread_events.resolve(strict=True)
        self.output = output.resolve(strict=False)
        self.environment = environment
        self.budget = budget
        self.inventory: list[Path] = []
        self.modules: dict[str, list[Path]] = defaultdict(list)
        self.parsed: dict[Path, ParsedFile] = {}
        self.entry_paths: list[Path] = []
        self.entry_labels: list[str] = []
        self.reachable_files: set[Path] = set()
        self.reachable_symbols: set[str] = set()
        self.map_rows: list[dict[str, Any]] = []
        self.edge_rows: list[dict[str, Any]] = []
        self.evidence_rows: list[dict[str, Any]] = []
        self.issue_rows: list[dict[str, Any]] = []
        self._issue_count = 0
        self._evidence_seen: set[str] = set()
        self._edge_seen: set[tuple[str, ...]] = set()
        self._stack_frame_cache: dict[str, list[tuple[Path, int, str, int]]] = {}
        self.partial = False
        self.binding = self._source_binding()

    def rel(self, path: Path) -> str:
        try:
            return path.resolve(strict=False).relative_to(self.repo_root).as_posix()
        except ValueError:
            return "<仓库外>"

    def inside_repo(self, path: Path) -> bool:
        try:
            path.resolve(strict=False).relative_to(self.repo_root)
            return True
        except ValueError:
            return False

    def has_symlink_component(self, path: Path) -> bool:
        try:
            lexical = Path(os.path.abspath(path))
            relative = lexical.relative_to(self.repo_root)
        except ValueError:
            return True
        current = self.repo_root
        for part in relative.parts:
            current = current / part
            try:
                if current.is_symlink():
                    return True
            except OSError:
                return True
        return False

    def add_issue(
        self,
        kind: str,
        *,
        event_id: str = "",
        location: str = "",
        expression: str = "",
        impact: str,
        minimum: str = "无需补充；保留为未知",
    ) -> None:
        self._issue_count += 1
        self.issue_rows.append(
            {
                "issue_id": f"map-issue-{self._issue_count:04d}",
                "environment": self.environment,
                "event_id": event_id,
                "source_location": location,
                "issue_kind": kind,
                "expression_redacted": redact(expression),
                "impact": impact,
                "status": "unresolved",
                "minimum_user_input": minimum,
            }
        )

    def _source_binding(self) -> dict[str, str]:
        rows = read_csv(self.source_analysis_dir / "source_bindings.csv")
        matching = [row for row in rows if row.get("environment", "") == self.environment]
        if not matching:
            return {}
        return matching[0]

    @property
    def binding_verified(self) -> bool:
        return self.binding.get("runtime_binding", "") == "已验证"

    @property
    def repository_label(self) -> str:
        value = self.binding.get("repository_url_or_path") or self.binding.get("repository_url")
        return sanitize_url(value) if value else str(self.repo_root)

    @property
    def commit_label(self) -> str:
        value = self.binding.get("resolved_commit", "")
        return "" if value.startswith("待") or value in {"未提供", ""} else value

    def permalink(self, path: Path, start: int, end: int) -> str:
        repository = self.repository_label
        commit = self.commit_label
        if not commit or not re.match(r"^https?://", repository, re.IGNORECASE):
            return ""
        base = repository.split("/blob/", 1)[0].split("/tree/", 1)[0].rstrip("/")
        if base.endswith(".git"):
            base = base[:-4]
        anchor = f"#L{start}" if start == end else f"#L{start}-L{end}"
        return f"{base}/blob/{quote(commit, safe='')}/{quote(self.rel(path), safe='/')}{anchor}"

    def discover_inventory(self) -> None:
        limit = max(10000, self.budget.max_python_files * 10)
        for current, dirnames, filenames in os.walk(self.repo_root, followlinks=False):
            current_path = Path(current)
            dirnames[:] = [
                name for name in sorted(dirnames)
                if name not in EXCLUDED_DIRS and not (current_path / name).is_symlink()
            ]
            for filename in sorted(filenames):
                if not filename.endswith(".py"):
                    continue
                lexical_path = current_path / filename
                if lexical_path.is_symlink():
                    continue
                path = lexical_path.resolve(strict=False)
                if not self.inside_repo(path):
                    continue
                self.inventory.append(path)
                module = module_name_for(path, self.repo_root)
                if module:
                    self.modules[module].append(path)
                if len(self.inventory) >= limit:
                    self.partial = True
                    self.add_issue(
                        "python_inventory_budget_exceeded",
                        location=self.rel(current_path),
                        expression=f"limit={limit}",
                        impact="Python 文件索引被截断，可能遗漏入口或 callsite",
                        minimum="缩小源码仓范围或提高 --max-python-files",
                    )
                    return

    def resolve_module(self, module: str) -> list[Path]:
        candidates = list(self.modules.get(module, []))
        if candidates:
            return sorted(set(candidates), key=self.rel)
        suffix = module.replace(".", "/")
        matches = [
            path for path in self.inventory
            if self.rel(path) in {f"{suffix}.py", f"{suffix}/__main__.py", f"{suffix}/__init__.py", f"src/{suffix}.py", f"src/{suffix}/__main__.py"}
        ]
        return sorted(set(matches), key=self.rel)

    def resolve_source_path(self, value: str) -> list[Path]:
        if not value or "$" in value or value.startswith("<"):
            return []
        raw = Path(value)
        attempts = [raw] if raw.is_absolute() else [self.repo_root / raw, self.repo_root / "src" / raw]
        exact = [
            path.resolve(strict=False) for path in attempts
            if not self.has_symlink_component(path) and path.resolve(strict=False).is_file()
        ]
        exact = [path for path in exact if self.inside_repo(path)]
        if exact:
            return sorted(set(exact), key=self.rel)
        normalized = value.replace("\\", "/").lstrip("./")
        matches = [
            path for path in self.inventory
            if self.rel(path).endswith(normalized) or normalized.endswith(self.rel(path))
        ]
        return sorted(set(matches), key=self.rel)

    def load_launch_entries(self) -> None:
        rows = read_csv(self.source_analysis_dir / "launch_command_candidates.csv")
        rows = [row for row in rows if row.get("environment", "") == self.environment]
        if not rows:
            self.add_issue(
                "launch_candidates_missing",
                location=str(self.source_analysis_dir / "launch_command_candidates.csv"),
                impact="无法从 .sh 静态链确定 Python 入口；将仅使用 trace 栈和仓库静态候选",
                minimum="先运行 resolve_source_entrypoints.py 或提供 Python 入口",
            )
            return
        rows.sort(
            key=lambda row: (
                0 if row.get("selection_status") == "analysis_selected" else 1,
                row.get("candidate_id", ""),
                row.get("python_target", ""),
            )
        )
        for row in rows:
            target = row.get("python_target", "")
            mode = row.get("python_mode", "")
            paths = self.resolve_module(target) if mode == "module" else self.resolve_source_path(target)
            if not paths:
                self.add_issue(
                    "python_entry_unresolved",
                    location=row.get("source_path", ""),
                    expression=target,
                    impact=f"无法解析 {mode or 'unknown'} Python 入口",
                    minimum="提供仓库内 Python script/module 或展开后的 runtime argv",
                )
                continue
            if len(paths) > 1:
                self.add_issue(
                    "python_entry_ambiguous",
                    location=row.get("source_path", ""),
                    expression=";".join(self.rel(path) for path in paths),
                    impact="同一 Python 入口对应多个仓库文件，不做随机选择",
                    minimum="提供精确 repo-relative path/module",
                )
            for path in paths:
                if path not in self.entry_paths:
                    self.entry_paths.append(path)
                    self.entry_labels.append(target)

    def _decode_python(self, path: Path) -> str | None:
        if path in self.parsed:
            return self.parsed[path].text
        if self.budget.files_read >= self.budget.max_python_files:
            self.partial = True
            self.add_issue(
                "python_file_budget_exceeded",
                location=self.rel(path),
                expression=f"max={self.budget.max_python_files}",
                impact="达到 Python 文件预算，静态图不完整",
                minimum="缩小源码范围或提高 --max-python-files",
            )
            return None
        try:
            size = path.stat().st_size
        except OSError as exc:
            self.add_issue("python_read_error", location=self.rel(path), expression=str(exc), impact="无法读取 Python 文件")
            return None
        if self.budget.bytes_read + size > self.budget.max_python_bytes:
            self.partial = True
            self.add_issue(
                "python_byte_budget_exceeded",
                location=self.rel(path),
                expression=f"size={size}",
                impact="达到 Python 字节预算，静态图不完整",
                minimum="缩小源码范围或提高 --max-python-bytes",
            )
            return None
        try:
            with tokenize.open(path) as handle:
                text = handle.read()
        except (OSError, SyntaxError, UnicodeError) as exc:
            self.add_issue("python_decode_error", location=self.rel(path), expression=str(exc), impact="Python 文件编码无法安全读取")
            return None
        self.budget.files_read += 1
        self.budget.bytes_read += len(text.encode("utf-8", errors="replace"))
        return text

    def parse_file(self, path: Path) -> ParsedFile | None:
        path = path.resolve(strict=False)
        if path in self.parsed:
            return self.parsed[path]
        if not self.inside_repo(path) or self.has_symlink_component(path) or path.suffix != ".py":
            self.add_issue(
                "python_path_rejected",
                location=self.rel(path),
                expression=str(path),
                impact="Python 路径越界、为 symlink 或非 .py，拒绝读取",
                minimum="提供仓库内普通 .py 文件",
            )
            return None
        text = self._decode_python(path)
        if text is None:
            return None
        try:
            tree = ast.parse(text, filename=self.rel(path), type_comments=True)
        except SyntaxError as exc:
            self.add_issue(
                "python_ast_error",
                location=f"{self.rel(path)}:{exc.lineno or ''}",
                expression=exc.msg,
                impact="ast.parse 失败，该文件不参与静态映射",
                minimum="提供与运行版本一致且语法完整的 Python 文件",
            )
            return None
        module = module_name_for(path, self.repo_root)
        imports: list[ImportRecord] = []
        aliases: dict[str, str] = {}
        for node in ast.walk(tree):
            if isinstance(node, ast.Import):
                for alias in node.names:
                    local_name = alias.asname or alias.name.split(".", 1)[0]
                    aliases[local_name] = alias.name
                    imports.append(ImportRecord(alias.name, "", local_name, node.lineno))
            elif isinstance(node, ast.ImportFrom):
                base = relative_import_module(module, node.module, node.level)
                for alias in node.names:
                    local_name = alias.asname or alias.name
                    canonical = f"{base}.{alias.name}" if base else alias.name
                    aliases[local_name] = canonical
                    imports.append(ImportRecord(base, alias.name, local_name, node.lineno, node.level))
        module_attrs: dict[tuple[str, str], str] = {}
        class_stack: list[str] = []

        class AttrCollector(ast.NodeVisitor):
            def visit_ClassDef(self, node: ast.ClassDef) -> Any:
                class_stack.append(node.name)
                self.generic_visit(node)
                class_stack.pop()

            def visit_Assign(self, node: ast.Assign) -> Any:
                if class_stack and isinstance(node.value, ast.Call):
                    raw = dotted_name(node.value.func)
                    parts = raw.split(".") if raw else []
                    canonical = aliases.get(parts[0], parts[0]) if parts else ""
                    if len(parts) > 1:
                        canonical = ".".join([canonical, *parts[1:]])
                    for target in node.targets:
                        if isinstance(target, ast.Attribute) and isinstance(target.value, ast.Name) and target.value.id == "self":
                            module_attrs[(class_stack[-1], target.attr)] = canonical
                self.generic_visit(node)

        AttrCollector().visit(tree)
        visitor = FileVisitor(path, module, aliases, module_attrs)
        visitor.visit(tree)
        module_symbol = visitor.symbols[0]
        module_symbol.line_end = max(1, len(text.splitlines()))
        parsed = ParsedFile(path, module, text, tree, aliases, imports, visitor.symbols, visitor.calls, module_attrs)
        self.parsed[path] = parsed
        return parsed

    def resolve_import_paths(self, parsed: ParsedFile, record: ImportRecord) -> list[Path]:
        candidates: list[Path] = []
        if record.module:
            candidates.extend(self.resolve_module(record.module))
        if record.imported_name and record.module:
            candidates.extend(self.resolve_module(f"{record.module}.{record.imported_name}"))
        return sorted(set(candidates), key=self.rel)

    def load_reachable_files(self) -> None:
        queue: deque[tuple[Path, int]] = deque((path, 0) for path in self.entry_paths)
        seen_depth: dict[Path, int] = {}
        while queue:
            path, depth = queue.popleft()
            old_depth = seen_depth.get(path)
            if old_depth is not None and old_depth <= depth:
                continue
            seen_depth[path] = depth
            if depth > self.budget.max_depth:
                self.partial = True
                self.add_issue(
                    "python_import_depth_exceeded",
                    location=self.rel(path),
                    expression=f"depth={depth}",
                    impact="达到 import 深度预算，静态可达图不完整",
                    minimum="提高 --max-depth 或提供更精确入口",
                )
                continue
            parsed = self.parse_file(path)
            if parsed is None:
                continue
            self.reachable_files.add(path)
            for record in parsed.imports:
                for target in self.resolve_import_paths(parsed, record):
                    queue.append((target, depth + 1))

    def parse_stack_frames(self, stack: str, event_id: str) -> list[tuple[Path, int, str, int]]:
        if event_id and event_id in self._stack_frame_cache:
            return self._stack_frame_cache[event_id]
        found: list[tuple[str, int, str, int]] = []
        seen_raw: set[tuple[str, int, str]] = set()
        for pattern in STACK_PATTERNS:
            for match in pattern.finditer(stack or ""):
                path_text = match.group("path").strip()
                line = int(match.group("line"))
                symbol = (match.groupdict().get("symbol") or "").strip()
                key = (path_text.replace("\\", "/"), line, symbol)
                if key not in seen_raw:
                    seen_raw.add(key)
                    found.append((path_text, line, symbol, match.start()))
        output: list[tuple[Path, int, str, int]] = []
        for path_text, line, symbol, position in sorted(found, key=lambda item: item[3]):
            matches = self.resolve_source_path(path_text)
            if len(matches) == 1:
                output.append((matches[0], line, symbol, position))
            elif len(matches) > 1:
                self.add_issue(
                    "stack_path_ambiguous",
                    event_id=event_id,
                    location=redact(path_text),
                    expression=";".join(self.rel(path) for path in matches),
                    impact="call stack path 对应多个仓库文件，不随机绑定",
                    minimum="提供完整 stack path 或固定源码 checkout",
                )
            else:
                self.add_issue(
                    "stack_path_unresolved",
                    event_id=event_id,
                    location=redact(path_text),
                    expression=Path(path_text).name,
                    impact="call stack 文件不在当前仓库快照内",
                    minimum="提供与 Profiling 匹配的源码版本或缺失文件",
                )
        if event_id:
            self._stack_frame_cache[event_id] = output
        return output

    def load_stack_files(self, events: list[dict[str, str]]) -> None:
        for event in events:
            for path, _, _, _ in self.parse_stack_frames(event.get("call_stack", ""), event.get("event_id", "")):
                self.parse_file(path)

    def parse_remaining_files(self) -> None:
        for path in self.inventory:
            if self.budget.files_read >= self.budget.max_python_files:
                break
            self.parse_file(path)

    def _symbol_for_call(self, call: Callsite) -> Symbol | None:
        parsed = self.parsed.get(call.path)
        if not parsed:
            return None
        matches = [symbol for symbol in parsed.symbols if symbol.qualname == call.caller]
        return matches[0] if matches else parsed.symbols[0]

    def _resolve_local_call(self, call: Callsite) -> list[Symbol]:
        parsed = self.parsed.get(call.path)
        if not parsed or not call.raw_callee:
            return []
        raw = call.raw_callee
        parts = raw.split(".")
        targets: list[Symbol] = []
        if raw.startswith("self.") and len(parts) == 2 and call.caller_class:
            wanted = f"{call.caller_class}.{parts[1]}"
            targets.extend(symbol for symbol in parsed.symbols if symbol.qualname == wanted)
        elif len(parts) == 1:
            targets.extend(symbol for symbol in parsed.symbols if symbol.name == parts[0] and symbol.kind in {"function", "class"})
            canonical = parsed.aliases.get(parts[0], "")
            if canonical and "." in canonical:
                module, name = canonical.rsplit(".", 1)
                for target_path in self.resolve_module(module):
                    target_file = self.parsed.get(target_path) or self.parse_file(target_path)
                    if target_file:
                        targets.extend(symbol for symbol in target_file.symbols if symbol.name == name)
        else:
            first = parts[0]
            alias_module = parsed.aliases.get(first, "")
            if alias_module:
                module = alias_module
                name = parts[-1]
                for target_path in self.resolve_module(module):
                    target_file = self.parsed.get(target_path) or self.parse_file(target_path)
                    if target_file:
                        targets.extend(symbol for symbol in target_file.symbols if symbol.name == name)
        unique = {symbol.identifier: symbol for symbol in targets}
        return sorted(unique.values(), key=lambda symbol: (self.rel(symbol.path), symbol.line_start, symbol.qualname))

    def build_graph(self) -> None:
        adjacency: dict[str, set[str]] = defaultdict(set)
        symbols_by_id: dict[str, Symbol] = {}
        for parsed in list(self.parsed.values()):
            for symbol in parsed.symbols:
                symbols_by_id[symbol.identifier] = symbol
            module_symbol = parsed.symbols[0]
            class_symbols = {symbol.name: symbol for symbol in parsed.symbols if symbol.kind == "class"}
            for symbol in parsed.symbols:
                if symbol.kind == "method" and symbol.name == "forward" and symbol.class_name in class_symbols:
                    self._add_edge(
                        class_symbols[symbol.class_name],
                        "override",
                        symbol.qualname,
                        f"{self.rel(symbol.path)}:{symbol.line_start}",
                        symbol.line_start,
                        "静态候选",
                    )
            for record in parsed.imports:
                for target_path in self.resolve_import_paths(parsed, record):
                    target_file = self.parsed.get(target_path)
                    if not target_file:
                        continue
                    target_symbol = target_file.symbols[0]
                    adjacency[module_symbol.identifier].add(target_symbol.identifier)
                    self._add_edge(
                        module_symbol,
                        "import",
                        target_symbol.qualname,
                        f"{self.rel(target_path)}:1",
                        record.line,
                        "静态候选",
                    )
            for call in parsed.calls:
                caller = self._symbol_for_call(call)
                if caller is None:
                    continue
                if call.call_kind in {"torch_call", "tensor_method", "nn_module_call", "custom_op", "collective_call"}:
                    edge_type = {
                        "custom_op": "custom_op",
                        "collective_call": "collective_call",
                    }.get(call.call_kind, "op_call")
                    self._add_edge(
                        caller,
                        edge_type,
                        call.canonical_callee,
                        "PyTorch/runtime API",
                        call.line_start,
                        "静态候选",
                    )
                elif re.search(r"(?:^|\.)(?:register|register_[A-Za-z_]+|dispatch|impl|custom_op)$", call.canonical_callee or call.raw_callee):
                    edge_type = "dispatch" if "dispatch" in (call.canonical_callee or call.raw_callee) else "register"
                    self._add_edge(
                        caller,
                        edge_type,
                        call.canonical_callee or call.raw_callee,
                        "静态 registry/dispatch",
                        call.line_start,
                        "静态候选",
                    )
                for target in self._resolve_local_call(call):
                    adjacency[caller.identifier].add(target.identifier)
                    self._add_edge(
                        caller,
                        "call",
                        target.qualname,
                        f"{self.rel(target.path)}:{target.line_start}",
                        call.line_start,
                        "静态候选",
                    )
        queue: deque[tuple[str, int]] = deque()
        for entry in self.entry_paths:
            parsed = self.parsed.get(entry)
            if parsed:
                queue.append((parsed.symbols[0].identifier, 0))
        while queue:
            symbol_id, depth = queue.popleft()
            if symbol_id in self.reachable_symbols or depth > self.budget.max_depth:
                continue
            self.reachable_symbols.add(symbol_id)
            for target in adjacency.get(symbol_id, set()):
                queue.append((target, depth + 1))
        for parsed in list(self.parsed.values()):
            for call in parsed.calls:
                symbol = self._symbol_for_call(call)
                call.file_reachable = call.path in self.reachable_files
                call.symbol_reachable = bool(symbol and symbol.identifier in self.reachable_symbols)

    def _add_edge(
        self,
        source_symbol: Symbol,
        edge_type: str,
        target_symbol: str,
        target_location: str,
        line: int,
        confidence: str,
    ) -> None:
        key = (
            self.environment,
            source_symbol.identifier,
            str(line),
            edge_type,
            target_symbol,
            target_location,
        )
        if key in self._edge_seen:
            return
        self._edge_seen.add(key)
        evidence_id = self.add_line_evidence(
            source_symbol.path,
            line,
            f"{source_symbol.module}:{source_symbol.qualname}",
            "source_symbol_edge",
            f"AST 静态边：{edge_type} -> {target_symbol}",
        )
        self.edge_rows.append(
            {
                "environment": self.environment,
                "from_symbol": f"{source_symbol.module}:{source_symbol.qualname}",
                "from_location": f"{self.rel(source_symbol.path)}:{line}",
                "edge_type": edge_type,
                "to_symbol": target_symbol,
                "to_location": target_location,
                "guard_or_config": "",
                "evidence_ids": evidence_id,
                "confidence": confidence,
            }
        )

    def source_lines_hash(self, path: Path, start: int, end: int) -> str:
        parsed = self.parsed.get(path)
        if not parsed:
            return ""
        lines = parsed.text.splitlines()
        snippet = "\n".join(lines[max(0, start - 1) : min(len(lines), end)])
        return hashlib.sha256(redact(snippet).encode("utf-8")).hexdigest()

    def add_line_evidence(
        self,
        path: Path,
        line: int,
        symbol: str,
        kind: str,
        note: str,
    ) -> str:
        evidence_id = stable_id(
            "src",
            self.environment,
            self.commit_label,
            self.rel(path),
            line,
            line,
            symbol,
            kind,
        )
        if evidence_id in self._evidence_seen:
            return evidence_id
        self._evidence_seen.add(evidence_id)
        self.evidence_rows.append(
            {
                "evidence_id": evidence_id,
                "environment": self.environment,
                "repository": self.repository_label,
                "commit": self.commit_label,
                "path": self.rel(path),
                "line_start": line,
                "line_end": line,
                "symbol": symbol,
                "evidence_kind": kind,
                "permalink": self.permalink(path, line, line),
                "content_sha256": self.source_lines_hash(path, line, line),
                "note": note,
            }
        )
        return evidence_id

    def add_evidence(self, call: Callsite, kind: str, note: str) -> str:
        symbol = f"{call.module}:{call.caller}"
        evidence_id = stable_id(
            "src",
            self.environment,
            self.commit_label,
            self.rel(call.path),
            call.line_start,
            call.line_end,
            symbol,
            kind,
        )
        if evidence_id in self._evidence_seen:
            return evidence_id
        self._evidence_seen.add(evidence_id)
        self.evidence_rows.append(
            {
                "evidence_id": evidence_id,
                "environment": self.environment,
                "repository": self.repository_label,
                "commit": self.commit_label,
                "path": self.rel(call.path),
                "line_start": call.line_start,
                "line_end": call.line_end,
                "symbol": symbol,
                "evidence_kind": kind,
                "permalink": self.permalink(call.path, call.line_start, call.line_end),
                "content_sha256": self.source_lines_hash(call.path, call.line_start, call.line_end),
                "note": note,
            }
        )
        return evidence_id

    def all_calls(self) -> list[Callsite]:
        return sorted(
            [call for parsed in self.parsed.values() for call in parsed.calls],
            key=lambda call: (self.rel(call.path), call.line_start, call.line_end, call.canonical_callee),
        )

    def event_shape_numbers(self, event: dict[str, str]) -> set[int]:
        return {int(value) for value in re.findall(r"(?<![A-Za-z])\d+", event.get("input_shapes", ""))}

    def sequence_score(self, call: Callsite, event_index: int, events: list[dict[str, str]]) -> int:
        parsed = self.parsed.get(call.path)
        if not parsed:
            return 0
        same_scope = [item for item in parsed.calls if item.caller == call.caller and item.call_kind != "python_call"]
        same_scope.sort(key=lambda item: (item.line_start, item.line_end))
        try:
            position = same_scope.index(call)
        except ValueError:
            return 0
        score = 0
        if event_index > 0 and position > 0:
            matched, _ = op_matches(events[event_index - 1].get("operator", ""), same_scope[position - 1].source_op)
            score += 1 if matched else 0
        if event_index + 1 < len(events) and position + 1 < len(same_scope):
            matched, _ = op_matches(events[event_index + 1].get("operator", ""), same_scope[position + 1].source_op)
            score += 1 if matched else 0
        return score

    def stack_candidates(self, event: dict[str, str]) -> list[tuple[Callsite, str, int, int]]:
        event_id = event.get("event_id", "")
        event_op = event.get("operator", "")
        candidates: list[tuple[Callsite, str, int, int]] = []
        for frame_order, (path, line, _, _) in enumerate(self.parse_stack_frames(event.get("call_stack", ""), event_id)):
            parsed = self.parsed.get(path) or self.parse_file(path)
            if not parsed:
                continue
            calls = [call for call in parsed.calls if call.line_start <= line <= call.line_end]
            matching = [call for call in calls if op_matches(event_op, call.source_op)[0]]
            selected = matching or calls
            for call in selected:
                match_kind = op_matches(event_op, call.source_op)[1]
                tier = 5 if matching and match_kind == "exact" else 4 if matching else 3
                candidates.append((call, "trace_call_stack_path_line", tier, -frame_order))
        return candidates

    def module_candidates(self, event: dict[str, str]) -> list[tuple[Callsite, str, int, int]]:
        hierarchy = event.get("module_hierarchy", "")
        if not hierarchy:
            return []
        words = {word.lower() for word in re.findall(r"[A-Za-z_][A-Za-z0-9_]*", hierarchy)}
        event_op = event.get("operator", "")
        output: list[tuple[Callsite, str, int, int]] = []
        for call in self.all_calls():
            class_match = bool(call.caller_class and call.caller_class.lower() in words)
            symbol_match = any(part.lower() in words for part in call.caller.split("."))
            op_match, match_kind = op_matches(event_op, call.source_op)
            if op_match and (class_match or symbol_match):
                output.append((call, "module_hierarchy+operator", 3 if match_kind == "exact" else 2, 0))
        return output

    def static_candidates(
        self,
        event: dict[str, str],
        event_index: int,
        events: list[dict[str, str]],
    ) -> list[tuple[Callsite, str, int, int]]:
        event_op = event.get("operator", "")
        calls: list[tuple[Callsite, str]] = []
        for call in self.all_calls():
            matched, match_kind = op_matches(event_op, call.source_op)
            if matched:
                calls.append((call, match_kind))
        if not calls:
            return []
        if any(kind == "exact" for _, kind in calls):
            calls = [(call, kind) for call, kind in calls if kind == "exact"]
        best_reach = max(2 if call.symbol_reachable else 1 if call.file_reachable else 0 for call, _ in calls)
        calls = [
            (call, kind) for call, kind in calls
            if (2 if call.symbol_reachable else 1 if call.file_reachable else 0) == best_reach
        ]
        shape_values = self.event_shape_numbers(event)
        output: list[tuple[Callsite, str, int, int]] = []
        for call, match_kind in calls:
            sequence = self.sequence_score(call, event_index, events)
            shape = len(shape_values.intersection(call.literal_ints))
            tier = 2 if best_reach == 2 else 1 if best_reach == 1 else 0
            method = "reachable_operator_basename" if best_reach else "operator_basename_unreachable"
            if sequence or shape:
                method += "+sequence_shape"
            output.append((call, method, tier, sequence * 10 + shape + (1 if match_kind == "exact" else 0)))
        return output

    def map_events(self, events: list[dict[str, str]]) -> None:
        entry_label = ";".join(dict.fromkeys(self.entry_labels))
        signature_cache: dict[tuple[str, ...], list[tuple[Callsite, str, int, int]]] = {}
        for event_index, event in enumerate(events):
            event_id = event.get("event_id", "") or stable_id("event", self.environment, event_index)
            signature = (
                event.get("operator", ""),
                event.get("call_stack", ""),
                event.get("module_hierarchy", ""),
                event.get("input_shapes", ""),
                events[event_index - 1].get("operator", "") if event_index > 0 else "",
                events[event_index + 1].get("operator", "") if event_index + 1 < len(events) else "",
            )
            candidates = signature_cache.get(signature)
            if candidates is None:
                candidates = self.stack_candidates(event)
                if not candidates:
                    candidates = self.module_candidates(event)
                if not candidates:
                    candidates = self.static_candidates(event, event_index, events)
                if candidates:
                    best_tier = max(item[2] for item in candidates)
                    candidates = [item for item in candidates if item[2] == best_tier]
                    deduplicated: dict[str, tuple[Callsite, str, int, int]] = {}
                    for item in candidates:
                        old = deduplicated.get(item[0].identifier)
                        if old is None or (item[2], item[3]) > (old[2], old[3]):
                            deduplicated[item[0].identifier] = item
                    candidates = list(deduplicated.values())
                    candidates.sort(
                        key=lambda item: (-item[3], self.rel(item[0].path), item[0].line_start, item[0].canonical_callee)
                    )
                signature_cache[signature] = candidates
            ambiguity = len(candidates)
            if ambiguity > 50:
                self.partial = True
                self.add_issue(
                    "callsite_candidates_truncated",
                    event_id=event_id,
                    expression=f"count={ambiguity}",
                    impact="同名 callsite 超过 50，仅输出确定性排序前 50 条；不视为消歧",
                    minimum="提供 call stack、module hierarchy 或更具体入口",
                )
                candidates = candidates[:50]
            if not candidates:
                self.map_rows.append(
                    {
                        "environment": self.environment,
                        "rank_pair_id": event.get("rank_pair_id", ""),
                        "pid": event.get("pid", ""),
                        "tid": event.get("tid", ""),
                        "event_id": event_id,
                        "event_index": event.get("event_ordinal") or event.get("source_event_index") or event_index + 1,
                        "operator_name": event.get("operator", ""),
                        "input_shape": event.get("input_shapes", ""),
                        "output_shape": event.get("output_shapes", ""),
                        "python_entry": entry_label,
                        "model_symbol": "",
                        "callsite_path": "",
                        "line_start": "",
                        "line_end": "",
                        "mapping_method": "unresolved",
                        "runtime_evidence_ids": ";".join(filter(None, [event_id, event.get("args_evidence_sha256", "")])),
                        "source_evidence_ids": "",
                        "confidence": "未知",
                        "ambiguity_count": 0,
                        "notes": "未找到可审计的仓库内 callsite；不会从算子名称伪造源码行",
                    }
                )
                continue
            for call, method, _, score in candidates:
                if method.startswith("trace_call_stack"):
                    confidence = "已证实" if self.binding_verified else "强关联"
                    evidence_kind = "runtime_stack_callsite"
                elif method.startswith("module_hierarchy"):
                    confidence = "强关联" if ambiguity == 1 else "静态候选"
                    evidence_kind = "module_hierarchy_callsite"
                else:
                    confidence = "静态候选"
                    evidence_kind = "static_operator_callsite"
                note = (
                    f"AST 静态解析；method={method}; candidate_score={score}; "
                    f"runtime_binding={self.binding.get('runtime_binding', '未验证') or '未验证'}"
                )
                if ambiguity > 1:
                    note += f"；共有 {ambiguity} 个候选，全部保留且未随机绑定"
                evidence_id = self.add_evidence(call, evidence_kind, note)
                self.map_rows.append(
                    {
                        "environment": self.environment,
                        "rank_pair_id": event.get("rank_pair_id", ""),
                        "pid": event.get("pid", ""),
                        "tid": event.get("tid", ""),
                        "event_id": event_id,
                        "event_index": event.get("event_ordinal") or event.get("source_event_index") or event_index + 1,
                        "operator_name": event.get("operator", ""),
                        "input_shape": event.get("input_shapes", ""),
                        "output_shape": event.get("output_shapes", ""),
                        "python_entry": entry_label,
                        "model_symbol": f"{call.module}:{call.caller}",
                        "callsite_path": self.rel(call.path),
                        "line_start": call.line_start,
                        "line_end": call.line_end,
                        "mapping_method": method,
                        "runtime_evidence_ids": ";".join(filter(None, [event_id, event.get("args_evidence_sha256", "")])),
                        "source_evidence_ids": evidence_id,
                        "confidence": confidence,
                        "ambiguity_count": ambiguity,
                        "notes": note,
                    }
                )

    def write_outputs(self) -> dict[str, Any]:
        self.output.mkdir(parents=True, exist_ok=True)
        write_merged_csv(
            self.output / "thread_operator_source_map.csv",
            MAP_FIELDS,
            self.map_rows,
            self.environment,
            replace_environment=True,
            identity_fields=["environment", "event_id", "callsite_path", "line_start", "mapping_method"],
        )
        write_merged_csv(
            self.output / "source_symbol_edges.csv",
            EDGE_FIELDS,
            self.edge_rows,
            self.environment,
            replace_environment=True,
            identity_fields=["environment", "from_location", "edge_type", "to_symbol", "to_location"],
        )
        write_merged_csv(
            self.output / "source_evidence.csv",
            EVIDENCE_FIELDS,
            self.evidence_rows,
            self.environment,
            replace_environment=True,
            identity_fields=["evidence_id"],
        )
        write_merged_csv(
            self.output / "source_mapping_issues.csv",
            ISSUE_FIELDS,
            self.issue_rows,
            self.environment,
            replace_environment=True,
            identity_fields=["environment", "event_id", "issue_kind", "source_location", "expression_redacted"],
        )
        summary = {
            "schema_version": 1,
            "environment": self.environment,
            "repo_root": str(self.repo_root),
            "static_ast_only": True,
            "repository_code_imported_or_executed": False,
            "runtime_binding": self.binding.get("runtime_binding", "未验证") or "未验证",
            "partial": self.partial,
            "python_entries": self.entry_labels,
            "counts": {
                "python_inventory": len(self.inventory),
                "python_files_parsed": len(self.parsed),
                "reachable_files": len(self.reachable_files),
                "reachable_symbols": len(self.reachable_symbols),
                "operator_source_rows": len(self.map_rows),
                "source_edges": len(self.edge_rows),
                "source_evidence": len(self.evidence_rows),
                "issues": len(self.issue_rows),
            },
            "budgets": {
                "max_python_files": self.budget.max_python_files,
                "max_python_bytes": self.budget.max_python_bytes,
                "max_depth": self.budget.max_depth,
                "files_read": self.budget.files_read,
                "bytes_read": self.budget.bytes_read,
            },
            "limitations": [
                "静态可达不等于本次运行实际执行",
                "同名多 callsite 无 runtime 消歧时全部保留，不随机绑定",
                "动态 import、registry、monkey patch、compile/fusion/custom backend 可能无法恢复",
            ],
        }
        role = "real" if self.environment.startswith("real") else "sim" if self.environment.startswith("sim") else hashlib.sha256(self.environment.encode("utf-8")).hexdigest()[:12]
        (self.output / f"source_mapping_summary.{role}.json").write_text(
            json.dumps(summary, ensure_ascii=False, indent=2) + "\n", encoding="utf-8"
        )
        summaries: list[dict[str, Any]] = []
        for summary_path in sorted(self.output.glob("source_mapping_summary.*.json")):
            try:
                value = json.loads(summary_path.read_text(encoding="utf-8-sig"))
            except (OSError, UnicodeError, json.JSONDecodeError):
                continue
            if isinstance(value, dict):
                summaries.append(value)
        (self.output / "source_mapping_summary.json").write_text(
            json.dumps({"schema_version": 1, "environments": summaries}, ensure_ascii=False, indent=2) + "\n",
            encoding="utf-8",
        )
        return summary

    def run(self) -> dict[str, Any]:
        if not self.binding:
            self.add_issue(
                "source_binding_missing",
                location=str(self.source_analysis_dir / "source_bindings.csv"),
                impact="没有环境-源码版本绑定；源码映射最高只能作为关联或静态候选",
                minimum="提供固定 commit，并把运行产物版本与源码绑定",
            )
        elif not self.binding_verified:
            self.add_issue(
                "source_runtime_binding_unverified",
                location=self.repository_label,
                expression=self.binding.get("runtime_binding", "未验证"),
                impact="源码可读但尚未证明是本次 Profiling 的运行版本",
                minimum="提供 metadata/build ID/启动日志中的 commit 证据",
            )
        if not self.commit_label:
            self.add_issue(
                "source_commit_unresolved",
                location=self.repository_label,
                impact="源码未固定 commit，行号与内容可能随时间变化",
                minimum="提供完整 commit SHA",
            )
        self.discover_inventory()
        self.load_launch_entries()
        events = [row for row in read_csv(self.thread_events_path) if row.get("environment", "") == self.environment]
        if not events:
            self.add_issue(
                "thread_events_missing",
                location=str(self.thread_events_path),
                expression=self.environment,
                impact="所选环境没有 thread operator event，无法做源码映射",
                minimum="提供包含该 environment 的 selected_thread_operator_events.csv",
            )
        self.load_reachable_files()
        self.load_stack_files(events)
        self.parse_remaining_files()
        self.build_graph()
        self.map_events(events)
        return self.write_outputs()


def write_simple_csv(path: Path, fields: list[str], rows: list[dict[str, Any]]) -> None:
    with path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields, extrasaction="ignore")
        writer.writeheader()
        writer.writerows(rows)


def run_self_test() -> int:
    environment = "real/reference/真机"
    with tempfile.TemporaryDirectory(prefix="thread-source-map-") as temporary:
        root = Path(temporary)
        repo = root / "repo"
        analysis = root / "analysis"
        output = root / "output"
        repo.mkdir()
        analysis.mkdir()
        app_text = """from model import ToyModel

raise RuntimeError('MUST_NOT_EXECUTE_REPOSITORY_CODE')

def main():
    model = ToyModel()
    return model

if __name__ == '__main__':
    main()
"""
        model_text = """import torch
import torch.nn.functional as F
import torch.distributed as dist

API_TOKEN = 'synthetic-secret-must-not-leak'

class ToyModel(torch.nn.Module):
    def forward(self, x, w):
        y = torch.matmul(x, w)
        y = F.relu(y)
        dist.all_reduce(y)
        y = torch.add(y, 1)
        y = torch.add(y, 2)
        return y
"""
        (repo / "app.py").write_text(app_text, encoding="utf-8")
        (repo / "model.py").write_text(model_text, encoding="utf-8")
        lines = model_text.splitlines()
        matmul_line = next(index for index, line in enumerate(lines, 1) if "torch.matmul" in line)
        reduce_line = next(index for index, line in enumerate(lines, 1) if "all_reduce" in line)
        write_simple_csv(
            analysis / "launch_command_candidates.csv",
            ["candidate_id", "environment", "source_path", "python_mode", "python_target", "selection_status"],
            [{
                "candidate_id": "entry-0001",
                "environment": environment,
                "source_path": "run.sh",
                "python_mode": "script",
                "python_target": "app.py",
                "selection_status": "analysis_selected",
            }],
        )
        write_simple_csv(
            analysis / "source_bindings.csv",
            ["environment", "repository_url_or_path", "resolved_commit", "runtime_binding"],
            [{
                "environment": environment,
                "repository_url_or_path": "https://example.invalid/repo?token=must-not-leak",
                "resolved_commit": "deadbeef",
                "runtime_binding": "已验证",
            }],
        )
        events_path = root / "selected_thread_operator_events.csv"
        event_fields = [
            "environment", "event_id", "source_event_index", "pid", "tid", "operator", "input_shapes",
            "output_shapes", "call_stack", "module_hierarchy", "args_evidence_sha256",
        ]
        write_simple_csv(
            events_path,
            event_fields,
            [
                {
                    "environment": environment,
                    "event_id": "evt-matmul",
                    "source_event_index": 1,
                    "pid": 100,
                    "tid": 200,
                    "operator": "aten::matmul",
                    "input_shapes": "[[2,4],[4,8]]",
                    "output_shapes": "未知",
                    "call_stack": f"{repo / 'model.py'}:{matmul_line}:in forward",
                    "module_hierarchy": "ToyModel",
                    "args_evidence_sha256": "runtime-matmul",
                },
                {
                    "environment": environment,
                    "event_id": "evt-relu",
                    "source_event_index": 2,
                    "pid": 100,
                    "tid": 200,
                    "operator": "aten::relu",
                    "input_shapes": "[[2,8]]",
                    "output_shapes": "未知",
                    "call_stack": "",
                    "module_hierarchy": "ToyModel",
                    "args_evidence_sha256": "runtime-relu",
                },
                {
                    "environment": environment,
                    "event_id": "evt-reduce",
                    "source_event_index": 3,
                    "pid": 100,
                    "tid": 200,
                    "operator": "c10d::all_reduce_",
                    "input_shapes": "[[2,8]]",
                    "output_shapes": "未知",
                    "call_stack": f"File \"{repo / 'model.py'}\", line {reduce_line}, in forward",
                    "module_hierarchy": "ToyModel",
                    "args_evidence_sha256": "runtime-reduce",
                },
                {
                    "environment": environment,
                    "event_id": "evt-add",
                    "source_event_index": 4,
                    "pid": 100,
                    "tid": 200,
                    "operator": "aten::add",
                    "input_shapes": "[[2,8]]",
                    "output_shapes": "未知",
                    "call_stack": "",
                    "module_hierarchy": "",
                    "args_evidence_sha256": "runtime-add",
                },
            ],
        )
        mapper = Mapper(
            repo,
            analysis,
            events_path,
            output,
            environment,
            Budget(max_python_files=20, max_python_bytes=200_000, max_depth=8),
        )
        summary = mapper.run()
        mapped = read_csv(output / "thread_operator_source_map.csv")
        edges = read_csv(output / "source_symbol_edges.csv")
        matmul = [row for row in mapped if row["event_id"] == "evt-matmul"]
        relu = [row for row in mapped if row["event_id"] == "evt-relu"]
        adds = [row for row in mapped if row["event_id"] == "evt-add"]
        assert len(matmul) == 1 and matmul[0]["confidence"] == "已证实"
        assert len(relu) == 1 and relu[0]["confidence"] in {"强关联", "静态候选"}
        assert len(adds) == 2 and all(int(row["ambiguity_count"]) == 2 for row in adds)
        assert any(row["edge_type"] == "collective_call" for row in edges)
        assert summary["repository_code_imported_or_executed"] is False
        for path in output.iterdir():
            if path.is_file():
                assert "synthetic-secret-must-not-leak" not in path.read_text(encoding="utf-8")
                assert "must-not-leak" not in path.read_text(encoding="utf-8")
    print("自测通过：AST-only 入口、栈、module、operator、collective、歧义保留和脱敏均有效。")
    return 0


def parse_args(argv: list[str] | None = None) -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--repo-root", type=Path, help="只读本地源码仓库根目录")
    parser.add_argument("--source-analysis-dir", type=Path, help="resolve_source_entrypoints.py 输出目录")
    parser.add_argument("--thread-events", type=Path, help="selected_thread_operator_events.csv")
    parser.add_argument("--output", type=Path, help="对比 comparison 输出目录")
    parser.add_argument("--environment", help="只映射该环境，如 real/reference/真机")
    parser.add_argument("--max-python-files", type=int, default=500, help="最多 ast.parse 的 Python 文件数")
    parser.add_argument("--max-python-bytes", type=int, default=8 * 1024 * 1024, help="最多读取 Python 总字节数")
    parser.add_argument("--max-depth", type=int, default=12, help="import/call 静态追踪最大深度")
    parser.add_argument("--self-test", action="store_true", help="运行内置合成回归")
    args = parser.parse_args(argv)
    if args.self_test:
        return args
    missing = [
        name for name in ("repo_root", "source_analysis_dir", "thread_events", "output", "environment")
        if getattr(args, name) in {None, ""}
    ]
    if missing:
        parser.error("缺少必需参数：" + ", ".join("--" + name.replace("_", "-") for name in missing))
    if args.max_python_files <= 0 or args.max_python_bytes <= 0 or args.max_depth < 0:
        parser.error("预算必须为正数（--max-depth 可为 0）")
    return args


def main(argv: list[str] | None = None) -> int:
    args = parse_args(argv)
    if args.self_test:
        return run_self_test()
    try:
        repo_root = args.repo_root.resolve(strict=True)
        source_analysis_dir = args.source_analysis_dir.resolve(strict=True)
        thread_events = args.thread_events.resolve(strict=True)
    except OSError as exc:
        print(f"错误：输入路径不可读：{exc}", file=sys.stderr)
        return 2
    if not repo_root.is_dir() or not source_analysis_dir.is_dir() or not thread_events.is_file():
        print("错误：repo/source-analysis 必须是目录，thread-events 必须是文件", file=sys.stderr)
        return 2
    output = args.output.resolve(strict=False)
    try:
        output.relative_to(repo_root)
        print("错误：--output 必须位于源码仓库之外，保证仓库只读", file=sys.stderr)
        return 2
    except ValueError:
        pass
    mapper = Mapper(
        repo_root,
        source_analysis_dir,
        thread_events,
        output,
        args.environment,
        Budget(args.max_python_files, args.max_python_bytes, args.max_depth),
    )
    summary = mapper.run()
    print(json.dumps(summary, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

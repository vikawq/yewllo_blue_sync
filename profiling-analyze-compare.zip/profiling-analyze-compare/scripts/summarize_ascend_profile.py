#!/usr/bin/env python3
"""流式汇总 Ascend/PyTorch Profiler 导出，并生成以 PyTorch 为主线的中文证据包。

脚本只依赖 Python 标准库，不修改 profiling 原始目录。它优先分析
operator_details.csv 中的 PyTorch 算子，再分析设备执行算子、通信、迭代、内存和
元数据。大 CSV 逐行读取；trace_view.json 只登记存在性，不整体载入内存。
"""

from __future__ import annotations

import argparse
import csv
import hashlib
import json
import math
import re
import shutil
import sys
from collections import defaultdict, deque
from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Any, Iterable, Iterator


try:
    csv.field_size_limit(sys.maxsize)
except OverflowError:
    csv.field_size_limit(2**31 - 1)


# Device kernel classification must be stricter than collective-name parsing.
# In particular, generic tensor kernels such as ``BroadcastTo`` are compute /
# layout operators and must not be reported as HCCL communication merely
# because their name contains "broadcast".
COMM_BACKEND_PATTERN = re.compile(r"hccl|hcom|mc2", re.IGNORECASE)
COMM_COLLECTIVE_KERNEL_PATTERN = re.compile(
    r"(?:^|[_:])(?:allreduce|allgather|reducescatter|alltoallv?c?|batchsendrecv)"
    r"(?:$|[_:])",
    re.IGNORECASE,
)
COLLECTIVE_PATTERN = re.compile(
    r"alltoallvc|alltoallv|alltoall|reducescatter|allreduce|allgather|"
    r"batchsendrecv|broadcast|reduce|scatter|gather|receive|recv|send|mc2",
    re.IGNORECASE,
)
KEY_COMPUTE_PATTERN = re.compile(
    r"attention|flash|matmul|gemm|moe|router|topk|gather|scatter|cache|\bkv\b|"
    r"rope|embedding|layer.?norm|rms.?norm|conv|softmax|linear",
    re.IGNORECASE,
)
COORD_PATTERN = re.compile(
    r"(?<![a-z0-9])(local[_-]?rank|global[_-]?rank|rank|device|dp|tp|ep|pp|dcp|cp)"
    r"[=_-]?(\d+)",
    re.IGNORECASE,
)
RANK_IN_LINK_PATTERN = re.compile(r"\d+")

COORD_FIELDS = ["global_rank", "local_rank", "device", "dp", "tp", "ep", "pp", "cp", "dcp"]
PARALLEL_FIELDS = ["dp", "tp", "ep", "pp", "cp", "dcp"]


MISSING_NUMERIC_TOKENS = {
    "",
    "N/A",
    "NA",
    "NONE",
    "NULL",
    "-",
    "UNKNOWN",
    "未知",
    "缺失",
    "不可计算",
}


def parse_float(value: Any) -> float | None:
    """Parse an exported measurement without turning absence into a real zero."""
    if value is None:
        return None
    text = str(value).strip().replace(",", "").rstrip("%")
    if text.upper() in MISSING_NUMERIC_TOKENS:
        return None
    try:
        number = float(text)
        return number if math.isfinite(number) else None
    except ValueError:
        return None


def parse_int(value: Any) -> int | None:
    number = parse_float(value)
    return int(number) if number is not None and number.is_integer() else None


def metric_value(value: float | None, digits: int = 6) -> float | str:
    return "缺失" if value is None else round(value, digits)


def numeric_sort_value(value: Any) -> float:
    number = parse_float(value)
    return number if number is not None else -math.inf


def complete_sum(values: Iterable[float | None]) -> float | None:
    materialized = list(values)
    if not materialized or any(value is None for value in materialized):
        return None
    return sum(value for value in materialized if value is not None)


def percent_value(numerator: float | None, denominator: float | None) -> float | str:
    if numerator is None or denominator is None:
        return "缺失"
    if denominator == 0:
        return "不可计算（分母为0）"
    return round(100.0 * numerator / denominator, 6)


def quotient_value(
    numerator: float | None, denominator: float | None, digits: int = 9
) -> float | str:
    if numerator is None or denominator is None:
        return "缺失"
    if denominator == 0:
        return "不可计算（分母为0）"
    return round(numerator / denominator, digits)


def clean_text(value: Any, limit: int = 1000) -> str:
    text = "" if value is None else str(value).strip()
    text = re.sub(r"\s+", " ", text)
    return text if len(text) <= limit else text[: limit - 3] + "..."


def row_value(row: dict[str, Any], *names: str) -> Any:
    if not row:
        return ""
    for name in names:
        if name in row:
            return row.get(name)
    lower = {str(key).strip().lower(): value for key, value in row.items()}
    for name in names:
        if name.strip().lower() in lower:
            return lower[name.strip().lower()]
    return ""


def stable_digest(text: str) -> str:
    return hashlib.sha1(text.encode("utf-8", errors="replace")).hexdigest()[:12]


def json_text(value: Any, limit: int = 2000) -> str:
    return clean_text(json.dumps(value, ensure_ascii=False, sort_keys=True), limit)


def write_csv(path: Path, rows: Iterable[dict[str, Any]], fields: list[str] | None = None) -> None:
    materialized = list(rows)
    path.parent.mkdir(parents=True, exist_ok=True)
    if fields is None:
        fields = []
        seen: set[str] = set()
        for row in materialized:
            for key in row:
                if key not in seen:
                    seen.add(key)
                    fields.append(key)
        if not fields:
            fields = ["message"]
    with path.open("w", newline="", encoding="utf-8-sig") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields, extrasaction="ignore")
        writer.writeheader()
        writer.writerows(materialized)


def write_json(path: Path, value: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8") as handle:
        json.dump(value, handle, ensure_ascii=False, indent=2)


@dataclass
class RankInfo:
    rank_label: str
    source: str
    global_rank: int | None = None
    local_rank: int | None = None
    device: int | None = None
    dp: int | None = None
    tp: int | None = None
    ep: int | None = None
    pp: int | None = None
    cp: int | None = None
    dcp: int | None = None
    coordinate_source: str = "目录名"

    def annotation(self) -> dict[str, Any]:
        result = {"rank": self.rank_label}
        for field_name in COORD_FIELDS:
            value = getattr(self, field_name)
            result[field_name] = "未知" if value is None else value
        result["parallel_coordinate"] = self.coordinate_text()
        return result

    def coordinate_text(self) -> str:
        parts = []
        for field_name in PARALLEL_FIELDS:
            value = getattr(self, field_name)
            parts.append(f"{field_name.upper()}={'?' if value is None else value}")
        return "/".join(parts)


@dataclass
class TimingAggregate:
    count: int = 0
    totals: dict[str, float] = field(default_factory=lambda: defaultdict(float))
    maxima: dict[str, float] = field(default_factory=lambda: defaultdict(float))
    minima: dict[str, float] = field(default_factory=dict)
    metric_counts: dict[str, int] = field(default_factory=lambda: defaultdict(int))
    examples: dict[str, str] = field(default_factory=dict)
    steps: set[str] = field(default_factory=set)

    def add(
        self,
        metrics: dict[str, float | None],
        examples: dict[str, str] | None = None,
        step: str = "",
    ) -> None:
        self.count += 1
        for key, value in metrics.items():
            if value is None:
                continue
            number = float(value)
            self.totals[key] += number
            self.maxima[key] = max(self.maxima.get(key, number), number)
            self.minima[key] = min(self.minima.get(key, number), number)
            self.metric_counts[key] += 1
        if examples:
            for key, value in examples.items():
                if value and key not in self.examples:
                    self.examples[key] = value
        if step and len(self.steps) < 100:
            self.steps.add(step)

    def metric_complete(self, key: str) -> bool:
        return self.count > 0 and self.metric_counts.get(key, 0) == self.count

    def total(self, key: str) -> float | None:
        return self.totals.get(key) if self.metric_complete(key) else None

    def maximum(self, key: str) -> float | None:
        return self.maxima.get(key) if self.metric_complete(key) else None


def rank_info(output_dir: Path) -> RankInfo:
    values: dict[str, int] = {}
    names = [output_dir.parent.name]
    names.extend(parent.name for parent in output_dir.parents[:5])
    for name in names:
        for raw_key, raw_value in COORD_PATTERN.findall(name):
            key = raw_key.lower().replace("-", "_")
            if key in {"rank", "global_rank"}:
                key = "global_rank"
            elif key == "localrank":
                key = "local_rank"
            values.setdefault(key, int(raw_value))

    # Ascend exports often use opaque timestamp/PID directory names.  Recover
    # rank and parallel coordinates from small profiler metadata files before
    # falling back to "unknown".  Only exact scalar metadata keys are accepted;
    # peer/link/group subtrees are ignored so a communication peer rank cannot
    # be mistaken for the current process rank.
    metadata_key_map = {
        "global_rank": "global_rank",
        "globalrank": "global_rank",
        "rank_id": "global_rank",
        "rankid": "global_rank",
        "local_rank": "local_rank",
        "localrank": "local_rank",
        "device_id": "device",
        "deviceid": "device",
        "device": "device",
        "dp_rank": "dp",
        "data_parallel_rank": "dp",
        "tp_rank": "tp",
        "tensor_parallel_rank": "tp",
        "tensor_model_parallel_rank": "tp",
        "ep_rank": "ep",
        "expert_parallel_rank": "ep",
        "pp_rank": "pp",
        "pipeline_parallel_rank": "pp",
        "cp_rank": "cp",
        "context_parallel_rank": "cp",
        "dcp_rank": "dcp",
        "distributed_context_parallel_rank": "dcp",
    }
    ignored_path_tokens = {"peer", "peers", "link", "links", "group", "groups", "member", "members"}

    def collect_metadata_scalars(value: Any, path: tuple[str, ...] = (), depth: int = 0) -> None:
        if depth > 8:
            return
        if isinstance(value, dict):
            for raw_key, child in value.items():
                key = re.sub(r"[^a-z0-9]+", "_", str(raw_key).strip().lower()).strip("_")
                child_path = (*path, key)
                if any(token in ignored_path_tokens for token in child_path):
                    continue
                canonical = metadata_key_map.get(key)
                if canonical and not isinstance(child, (dict, list, tuple)):
                    parsed = parse_int(child)
                    if parsed is not None:
                        values.setdefault(canonical, parsed)
                collect_metadata_scalars(child, child_path, depth + 1)
        elif isinstance(value, list):
            for child in value[:1000]:
                collect_metadata_scalars(child, path, depth + 1)

    metadata_paths: set[Path] = set()
    for directory in (output_dir, output_dir.parent, output_dir.parent.parent):
        if not directory.is_dir():
            continue
        for pattern in ("profiler_info*.json", "profiler_metadata*.json", "metadata*.json"):
            metadata_paths.update(path for path in directory.glob(pattern) if path.is_file())
    for metadata_path in sorted(metadata_paths):
        try:
            if metadata_path.stat().st_size > 16 * 1024 * 1024:
                continue
            with metadata_path.open("r", encoding="utf-8-sig", errors="replace") as handle:
                collect_metadata_scalars(json.load(handle))
        except (OSError, json.JSONDecodeError, UnicodeError):
            continue
    global_rank = values.get("global_rank")
    if "device" not in values:
        for candidate in (output_dir / "kernel_details.csv", output_dir / "step_trace_time.csv"):
            if not candidate.exists():
                continue
            try:
                first_row = next(read_csv_rows(candidate), {})
                raw_device = row_value(first_row, "Device_id", "Device ID", "Device")
                if str(raw_device).strip() != "":
                    parsed_device = parse_int(raw_device)
                    if parsed_device is not None:
                        values["device"] = parsed_device
                        break
            except (OSError, StopIteration):
                pass
    label = f"rank{global_rank}" if global_rank is not None else output_dir.parent.name
    return RankInfo(rank_label=label, source=str(output_dir), **values)


def discover_outputs(root: Path) -> list[Path]:
    if root.name == "ASCEND_PROFILER_OUTPUT" and root.is_dir():
        return [root]
    return sorted(path for path in root.rglob("ASCEND_PROFILER_OUTPUT") if path.is_dir())


def inventory(root: Path) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    for path in sorted(root.rglob("*")):
        if not path.is_file():
            continue
        stat = path.stat()
        rows.append(
            {
                "relative_path": str(path.relative_to(root)),
                "size_bytes": stat.st_size,
                "size_mb": round(stat.st_size / 1024 / 1024, 3),
            }
        )
    return rows


def read_csv_rows(path: Path) -> Iterator[dict[str, Any]]:
    with path.open("r", newline="", encoding="utf-8-sig", errors="replace") as handle:
        yield from csv.DictReader(handle)


def operator_family(name: str) -> str:
    lower = name.lower()
    if lower.startswith(("aten::", "prims::", "torch::", "torch_npu::", "npu::")):
        return "PyTorch/ATen"
    if "profilerstep" in lower:
        return "Profiler Step"
    if any(token in lower for token in ("module", "forward", "backward", "autograd")):
        return "Module/Autograd"
    return "Framework/Python"


def summarize_pytorch_operators(path: Path, rank: RankInfo, top_n: int) -> dict[str, Any]:
    by_signature: dict[tuple[str, str, str], TimingAggregate] = defaultdict(TimingAggregate)
    by_name: dict[str, TimingAggregate] = defaultdict(TimingAggregate)
    row_count = 0
    nonempty_shapes = 0
    nonempty_stacks = 0

    for row in read_csv_rows(path):
        row_count += 1
        name = clean_text(row_value(row, "Name"), 500) or "<unknown>"
        input_shapes = clean_text(row_value(row, "Input Shapes", "Input Dims"), 1600)
        call_stack = clean_text(row_value(row, "Call Stack"), 2000)
        if input_shapes:
            nonempty_shapes += 1
        if call_stack:
            nonempty_stacks += 1
        metrics = {
            "host_self_us": parse_float(row_value(row, "Host Self Duration(us)")),
            "host_total_us": parse_float(row_value(row, "Host Total Duration(us)")),
            "device_self_us": parse_float(row_value(row, "Device Self Duration(us)")),
            "device_total_us": parse_float(row_value(row, "Device Total Duration(us)")),
            "device_aicore_self_us": parse_float(row_value(row, "Device Self Duration With AICore(us)")),
            "device_aicore_total_us": parse_float(row_value(row, "Device Total Duration With AICore(us)")),
        }
        examples = {"call_stack": call_stack, "call_stack_id": stable_digest(call_stack) if call_stack else ""}
        stack_id = examples["call_stack_id"]
        by_signature[(name, input_shapes, stack_id)].add(metrics, examples)
        by_name[name].add(metrics, examples)

    annotation = rank.annotation()

    def materialize(values: dict[Any, TimingAggregate], with_shape: bool) -> list[dict[str, Any]]:
        result: list[dict[str, Any]] = []
        for key, aggregate in values.items():
            if with_shape:
                name, input_shapes, stack_id = key
            else:
                name, input_shapes, stack_id = key, "", aggregate.examples.get("call_stack_id", "")
            row: dict[str, Any] = {
                **annotation,
                "operator": name,
                "operator_family": operator_family(name),
                "input_shapes": input_shapes,
                "output_shapes": "未知（operator_details.csv 不提供）",
                "shape_source": "operator_details.csv:Input Shapes",
                "call_stack_id": stack_id,
                "call_stack_sample": aggregate.examples.get("call_stack", ""),
                "calls": aggregate.count,
            }
            for metric in (
                "host_self_us",
                "host_total_us",
                "device_self_us",
                "device_total_us",
                "device_aicore_self_us",
                "device_aicore_total_us",
            ):
                total = aggregate.total(metric)
                average = total / aggregate.count if total is not None and aggregate.count else None
                row[f"{metric}_total"] = metric_value(total)
                row[f"{metric}_avg"] = metric_value(average)
                row[f"{metric}_max"] = metric_value(aggregate.maximum(metric))
                row[f"{metric}_observed_records"] = aggregate.metric_counts.get(metric, 0)
                row[f"{metric}_missing_records"] = aggregate.count - aggregate.metric_counts.get(metric, 0)
            result.append(row)
        return sorted(
            result,
            key=lambda item: (
                numeric_sort_value(item.get("device_self_us_total")),
                numeric_sort_value(item.get("host_self_us_total")),
            ),
            reverse=True,
        )

    signature_rows = materialize(by_signature, True)
    name_rows = materialize(by_name, False)
    variants: list[dict[str, Any]] = []
    variants_by_name: dict[str, list[dict[str, Any]]] = defaultdict(list)
    for row in signature_rows:
        variants_by_name[str(row["operator"])].append(row)
    for name, rows in variants_by_name.items():
        shape_keys = {str(row["input_shapes"]) for row in rows}
        device_total = complete_sum(parse_float(row.get("device_self_us_total")) for row in rows)
        host_total = complete_sum(parse_float(row.get("host_self_us_total")) for row in rows)
        variants.append(
            {
                **annotation,
                "operator": name,
                "input_shape_variants": len(shape_keys),
                "calls": sum(int(row["calls"]) for row in rows),
                "device_self_us_total": metric_value(device_total),
                "host_self_us_total": metric_value(host_total),
                "top_input_shapes": json_text(
                    [
                        {
                            "shape": row["input_shapes"],
                            "calls": row["calls"],
                            "device_self_us": row["device_self_us_total"],
                        }
                        for row in rows[:5]
                    ]
                ),
            }
        )
    variants.sort(
        key=lambda item: (int(item["input_shape_variants"]), numeric_sort_value(item["device_self_us_total"])),
        reverse=True,
    )
    return {
        "row_count": row_count,
        "shape_coverage_percent": (
            round(100.0 * nonempty_shapes / row_count, 3) if row_count else "不可计算（无记录）"
        ),
        "stack_coverage_percent": (
            round(100.0 * nonempty_stacks / row_count, 3) if row_count else "不可计算（无记录）"
        ),
        # Comparison mode needs the complete aggregated signature universe.  The
        # caller writes these full compact tables, then keeps only Top N in
        # summary.json/summary.md.
        "name_rows": name_rows,
        "signature_rows": signature_rows,
        "variant_rows": variants,
    }


def kernel_signature(row: dict[str, Any]) -> tuple[str, ...]:
    return (
        clean_text(row_value(row, "Name", "Op Name"), 500),
        clean_text(row_value(row, "Type", "OP Type"), 200),
        clean_text(row_value(row, "Accelerator Core", "Task Type", "Core Type"), 100),
        clean_text(row_value(row, "Input Shapes", "Input Dims"), 1600),
        clean_text(row_value(row, "Input Data Types"), 500),
        clean_text(row_value(row, "Input Formats"), 500),
        clean_text(row_value(row, "Output Shapes", "Output Dims"), 1600),
        clean_text(row_value(row, "Output Data Types"), 500),
        clean_text(row_value(row, "Output Formats"), 500),
    )


def summarize_device_operators(path: Path, rank: RankInfo, top_n: int, event_limit: int) -> dict[str, Any]:
    by_name: dict[tuple[str, str, str], TimingAggregate] = defaultdict(TimingAggregate)
    by_signature: dict[tuple[str, ...], TimingAggregate] = defaultdict(TimingAggregate)
    communication: dict[tuple[str, ...], TimingAggregate] = defaultdict(TimingAggregate)
    row_count = 0
    shape_rows = 0
    first_start: float | None = None
    last_end: float | None = None
    timing_complete = True
    history: deque[dict[str, Any]] = deque(maxlen=3)
    pending_context: list[dict[str, Any]] = []
    comm_context_rows: list[dict[str, Any]] = []

    for row in read_csv_rows(path):
        row_count += 1
        signature = kernel_signature(row)
        name, op_type, core = signature[:3]
        duration = parse_float(row_value(row, "Duration(us)", "Task Duration(us)"))
        wait = parse_float(row_value(row, "Wait Time(us)", "Task Wait Time(us)"))
        start = parse_float(row_value(row, "Start Time(us)", "Task Start Time(us)"))
        step = clean_text(row_value(row, "Step Id", "Step"), 100)
        stream = clean_text(row_value(row, "Stream ID", "Stream Id"), 100)
        if start is None or duration is None:
            timing_complete = False
        else:
            first_start = start if first_start is None else min(first_start, start)
            event_end = start + duration
            last_end = event_end if last_end is None else max(last_end, event_end)
        if signature[3] or signature[6]:
            shape_rows += 1
        metrics = {"duration_us": duration, "wait_us": wait}
        by_name[(name, op_type, core)].add(metrics, step=step)
        by_signature[signature].add(metrics, step=step)
        combined = f"{name} {op_type}"
        is_comm = bool(
            str(core).strip().upper() == "COMMUNICATION"
            or COMM_BACKEND_PATTERN.search(combined)
            or COMM_COLLECTIVE_KERNEL_PATTERN.search(combined)
        )
        if is_comm:
            communication[signature].add(metrics, step=step)

        event = {
            "name": name,
            "type": op_type,
            "start_us": start,
            "duration_us": duration,
            "input_shapes": signature[3],
            "output_shapes": signature[6],
        }
        if not is_comm:
            for context in list(pending_context):
                context["next_compute"].append(event)
                if len(context["next_compute"]) >= 3:
                    comm_context_rows.append(context)
                    pending_context.remove(context)
            if KEY_COMPUTE_PATTERN.search(f"{name} {op_type}") or not history:
                history.append(event)
        elif len(comm_context_rows) + len(pending_context) < event_limit:
            pending_context.append(
                {
                    **rank.annotation(),
                    "step": step,
                    "stream": stream,
                    "communication_operator": name,
                    "collective_type": collective_type(name),
                    "start_us": start,
                    "duration_us": duration,
                    "input_shapes": signature[3],
                    "output_shapes": signature[6],
                    "previous_compute": list(history),
                    "next_compute": [],
                }
            )

    comm_context_rows.extend(pending_context)
    annotation = rank.annotation()

    def rows_from(values: dict[tuple[str, ...], TimingAggregate], shaped: bool) -> list[dict[str, Any]]:
        result: list[dict[str, Any]] = []
        for key, aggregate in values.items():
            if shaped:
                name, op_type, core, in_shape, in_dtype, in_format, out_shape, out_dtype, out_format = key
            else:
                name, op_type, core = key
                in_shape = in_dtype = in_format = out_shape = out_dtype = out_format = ""
            result.append(
                {
                    **annotation,
                    "operator": name,
                    "type": op_type,
                    "accelerator_core": core,
                    "input_shapes": in_shape or "未知（未采集 all-kernel headers）",
                    "input_dtypes": in_dtype,
                    "input_formats": in_format,
                    "output_shapes": out_shape or "未知（未采集 all-kernel headers）",
                    "output_dtypes": out_dtype,
                    "output_formats": out_format,
                    "shape_source": "kernel_details.csv",
                    "steps": ",".join(sorted(aggregate.steps)),
                    "calls": aggregate.count,
                    "duration_us_total": metric_value(aggregate.total("duration_us")),
                    "duration_us_avg": metric_value(
                        aggregate.total("duration_us") / aggregate.count
                        if aggregate.total("duration_us") is not None and aggregate.count
                        else None
                    ),
                    "duration_us_max": metric_value(aggregate.maximum("duration_us")),
                    "wait_us_total": metric_value(aggregate.total("wait_us")),
                }
            )
        return sorted(result, key=lambda item: numeric_sort_value(item["duration_us_total"]), reverse=True)

    name_rows = rows_from(by_name, False)
    signature_rows = rows_from(by_signature, True)
    comm_rows = rows_from(communication, True)
    formatted_context: list[dict[str, Any]] = []
    for context in comm_context_rows:
        formatted_context.append(
            {
                **{key: value for key, value in context.items() if key not in {"previous_compute", "next_compute"}},
                "previous_compute": json_text(context["previous_compute"], 3000),
                "next_compute": json_text(context["next_compute"], 3000),
                "path_status": "推断：仅按时间邻近，不能替代框架调用栈/依赖边",
            }
        )
    window_complete = timing_complete and first_start is not None and last_end is not None
    all_kernel_total = complete_sum(item.total("duration_us") for item in by_name.values())
    communication_kernel_total = complete_sum(item.total("duration_us") for item in communication.values())
    return {
        "row_count": row_count,
        "first_start_us": metric_value(first_start if window_complete else None),
        "last_end_us": metric_value(last_end if window_complete else None),
        "window_us": metric_value(max(0.0, last_end - first_start) if window_complete else None),
        "shape_coverage_percent": (
            round(100.0 * shape_rows / row_count, 3) if row_count else "不可计算（无记录）"
        ),
        "all_kernel_total_us": metric_value(all_kernel_total),
        "communication_kernel_total_us": metric_value(communication_kernel_total),
        "name_rows": name_rows,
        "signature_rows": signature_rows,
        "communication_rows": comm_rows,
        "communication_context_rows": formatted_context,
        "communication_context_truncated": len(formatted_context) >= event_limit,
    }


def collective_type(name: str) -> str:
    match = COLLECTIVE_PATTERN.search(name.replace("_", ""))
    return match.group(0).lower() if match else "unknown"


def group_name(name: str) -> str:
    if "@" in name:
        return clean_text(name.rsplit("@", 1)[-1], 300)
    match = re.search(r"(?:group|comm)[=_-]([a-z0-9_.:-]+)", name, re.I)
    return match.group(1) if match else "未知"


def communication_rows_from_json(value: Any, rank: RankInfo) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    if not isinstance(value, dict):
        return rows
    for step, step_data in value.items():
        if not isinstance(step_data, dict):
            continue
        for category in ("p2p", "collective"):
            operations = step_data.get(category, {})
            if not isinstance(operations, dict):
                continue
            for op_name, op_info in operations.items():
                if op_name == "Total Op Info" or not isinstance(op_info, dict):
                    continue
                time_info = op_info.get("Communication Time Info", {})
                bandwidth_info = op_info.get("Communication Bandwidth Info", {})
                if not isinstance(time_info, dict):
                    time_info = {}
                if not isinstance(bandwidth_info, dict):
                    bandwidth_info = {}
                transports: list[str] = []
                size_distribution: dict[str, Any] = {}
                transit_sizes: list[float | None] = []
                transit_times_bw: list[float | None] = []
                for transport, info in bandwidth_info.items():
                    if not isinstance(info, dict):
                        continue
                    transports.append(str(transport))
                    transit_sizes.append(parse_float(info.get("Transit Size(MB)")))
                    transit_times_bw.append(parse_float(info.get("Transit Time(ms)")))
                    if info.get("Size Distribution"):
                        size_distribution[str(transport)] = info.get("Size Distribution")
                transit_size = complete_sum(transit_sizes)
                transit_time_direct = parse_float(time_info.get("Transit Time(ms)"))
                transit_time_bw = complete_sum(transit_times_bw)
                transit_time = transit_time_direct if transit_time_direct is not None else transit_time_bw
                rows.append(
                    {
                        **rank.annotation(),
                        "step": step,
                        "category": category,
                        "communication_operator": clean_text(op_name, 600),
                        "collective_type": collective_type(op_name),
                        "communication_group": group_name(op_name),
                        "parallel_axis": "未知（需结合 group 成员或 matrix 链路）",
                        "start_us": metric_value(parse_float(time_info.get("Start Timestamp(us)")), 9),
                        "wait_ms": metric_value(parse_float(time_info.get("Wait Time(ms)")), 9),
                        "synchronization_ms": metric_value(
                            parse_float(time_info.get("Synchronization Time(ms)")), 9
                        ),
                        "transit_ms": metric_value(transit_time, 9),
                        "transit_size_mb": metric_value(transit_size, 9),
                        "bandwidth_gb_s": quotient_value(transit_size, transit_time, 9),
                        "wait_ratio": metric_value(parse_float(time_info.get("Wait Time Ratio")), 9),
                        "synchronization_ratio": metric_value(
                            parse_float(time_info.get("Synchronization Time Ratio")), 9
                        ),
                        "transports": ",".join(transports),
                        "size_distribution": json_text(size_distribution, 3000),
                        "input_shapes": "未知（communication.json 不提供 Tensor Shape）",
                        "output_shapes": "未知（communication.json 不提供 Tensor Shape）",
                        "shape_join_key": "collective_type + group + step；与 communication_kernel_shapes.csv 交叉核对",
                    }
                )
    return rows


def communication_matrix_rows(value: Any, rank: RankInfo) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    if not isinstance(value, dict):
        return rows
    for step, step_data in value.items():
        if not isinstance(step_data, dict):
            continue
        for category in ("p2p", "collective"):
            operations = step_data.get(category, {})
            if not isinstance(operations, dict):
                continue
            has_total = any("-total@" in str(name).lower() for name in operations)
            for op_name, links in operations.items():
                if not isinstance(links, dict) or op_name == "Total Op Info":
                    continue
                if has_total and "-total@" not in str(op_name).lower():
                    continue
                for link, info in links.items():
                    if not isinstance(info, dict):
                        continue
                    rows.append(
                        {
                            **rank.annotation(),
                            "step": step,
                            "category": category,
                            "communication_operator": clean_text(op_name, 600),
                            "collective_type": collective_type(op_name),
                            "communication_group": group_name(op_name),
                            "link": clean_text(link, 300),
                            "peer_ranks": ",".join(RANK_IN_LINK_PATTERN.findall(str(link))),
                            "parallel_axis": "待全局拓扑推断",
                            "transport_type": clean_text(info.get("Transport Type"), 200),
                            "transit_ms": metric_value(parse_float(info.get("Transit Time(ms)")), 9),
                            "transit_size_mb": metric_value(parse_float(info.get("Transit Size(MB)")), 9),
                            "bandwidth_gb_s": metric_value(parse_float(info.get("Bandwidth(GB/s)")), 9),
                            "source_op_name": clean_text(info.get("Op Name"), 600),
                        }
                    )
    return rows


def aggregate_communication(rows: list[dict[str, Any]]) -> list[dict[str, Any]]:
    values: dict[tuple[str, str, str], TimingAggregate] = defaultdict(TimingAggregate)
    examples: dict[tuple[str, str, str], dict[str, Any]] = {}
    for row in rows:
        key = (str(row["category"]), str(row["collective_type"]), str(row["communication_group"]))
        values[key].add(
            {
                "wait_ms": parse_float(row.get("wait_ms")),
                "synchronization_ms": parse_float(row.get("synchronization_ms")),
                "transit_ms": parse_float(row.get("transit_ms")),
                "transit_size_mb": parse_float(row.get("transit_size_mb")),
            },
            step=str(row.get("step", "")),
        )
        examples.setdefault(key, row)
    result: list[dict[str, Any]] = []
    for key, aggregate in values.items():
        example = examples[key]
        transit_ms = aggregate.total("transit_ms")
        transit_size = aggregate.total("transit_size_mb")
        result.append(
            {
                **{field: example.get(field, "未知") for field in ["rank", *COORD_FIELDS, "parallel_coordinate"]},
                "category": key[0],
                "collective_type": key[1],
                "communication_group": key[2],
                "parallel_axis": example.get("parallel_axis", "未知"),
                "steps": ",".join(sorted(aggregate.steps)),
                "calls": aggregate.count,
                "wait_ms_total": metric_value(aggregate.total("wait_ms"), 9),
                "synchronization_ms_total": metric_value(aggregate.total("synchronization_ms"), 9),
                "transit_ms_total": metric_value(transit_ms, 9),
                "transit_size_mb_total": metric_value(transit_size, 9),
                "weighted_bandwidth_gb_s": quotient_value(transit_size, transit_ms, 9),
            }
        )
    return sorted(result, key=lambda item: numeric_sort_value(item["transit_ms_total"]), reverse=True)


def read_json(path: Path) -> Any:
    with path.open("r", encoding="utf-8-sig", errors="replace") as handle:
        return json.load(handle)


def truncate_json(value: Any, depth: int = 0) -> Any:
    if depth >= 7:
        return "<max-depth>"
    if isinstance(value, dict):
        items = list(value.items())
        result = {str(key): truncate_json(item, depth + 1) for key, item in items[:100]}
        if len(items) > 100:
            result["<truncated-keys>"] = len(items) - 100
        return result
    if isinstance(value, list):
        result = [truncate_json(item, depth + 1) for item in value[:100]]
        if len(value) > 100:
            result.append(f"<truncated-items:{len(value) - 100}>")
        return result
    if isinstance(value, str):
        return clean_text(value, 1000)
    return value


def summarize_step_trace(path: Path, rank: RankInfo) -> list[dict[str, Any]]:
    result: list[dict[str, Any]] = []
    for row in read_csv_rows(path):
        computing = parse_float(row_value(row, "Computing"))
        comm = parse_float(row_value(row, "Communication"))
        comm_nonoverlap = parse_float(row_value(row, "Communication(Not Overlapped)"))
        stage = parse_float(row_value(row, "Stage"))
        result.append(
            {
                **rank.annotation(),
                "device_id": clean_text(row_value(row, "Device_id", "Device ID"), 100),
                "step": clean_text(row_value(row, "Step"), 100) or "聚合窗口",
                "computing_us": metric_value(computing),
                "communication_us": metric_value(comm),
                "communication_not_overlapped_us": metric_value(comm_nonoverlap),
                "overlapped_us": metric_value(parse_float(row_value(row, "Overlapped"))),
                "free_us": metric_value(parse_float(row_value(row, "Free"))),
                "stage_us": metric_value(stage),
                "bubble_us": metric_value(parse_float(row_value(row, "Bubble"))),
                "preparing_us": metric_value(parse_float(row_value(row, "Preparing"))),
                "communication_share_percent": percent_value(comm, stage),
                "nonoverlap_share_percent": percent_value(comm_nonoverlap, stage),
                "time_semantics": "step_trace_time.csv；空 Step 视为整个采集窗口",
            }
        )
    return result


def summarize_memory(output_dir: Path, rank: RankInfo, top_n: int) -> dict[str, Any]:
    result: dict[str, Any] = {"record_rows": [], "operator_rows": []}
    record_path = output_dir / "memory_record.csv"
    if record_path.exists():
        groups: dict[tuple[str, str], dict[str, Any]] = {}
        for row in read_csv_rows(record_path):
            component = clean_text(row_value(row, "Component"), 200)
            device_type = clean_text(row_value(row, "Device Type"), 100)
            key = (component, device_type)
            current = groups.setdefault(
                key,
                {
                    **rank.annotation(),
                    "component": component,
                    "device_type": device_type,
                    "records": 0,
                    "max_allocated_mb": None,
                    "max_reserved_mb": None,
                    "max_active_mb": None,
                    "_allocated_observed": 0,
                    "_reserved_observed": 0,
                    "_active_observed": 0,
                },
            )
            current["records"] += 1
            for output_field, observed_field, source_field in (
                ("max_allocated_mb", "_allocated_observed", "Total Allocated(MB)"),
                ("max_reserved_mb", "_reserved_observed", "Total Reserved(MB)"),
                ("max_active_mb", "_active_observed", "Total Active(MB)"),
            ):
                value = parse_float(row_value(row, source_field))
                if value is None:
                    continue
                current[observed_field] += 1
                previous = current[output_field]
                current[output_field] = value if previous is None else max(previous, value)
        record_rows: list[dict[str, Any]] = []
        for current in groups.values():
            for output_field, observed_field in (
                ("max_allocated_mb", "_allocated_observed"),
                ("max_reserved_mb", "_reserved_observed"),
                ("max_active_mb", "_active_observed"),
            ):
                complete = current[observed_field] == current["records"]
                current[output_field] = metric_value(current[output_field] if complete else None)
                current.pop(observed_field, None)
            record_rows.append(current)
        result["record_rows"] = sorted(
            record_rows, key=lambda item: numeric_sort_value(item["max_reserved_mb"]), reverse=True
        )

    operator_path = output_dir / "operator_memory.csv"
    if operator_path.exists():
        groups2: dict[str, TimingAggregate] = defaultdict(TimingAggregate)
        for row in read_csv_rows(operator_path):
            name = clean_text(row_value(row, "Name"), 500)
            groups2[name].add(
                {
                    "size_kb": parse_float(row_value(row, "Size(KB)")),
                    "duration_us": parse_float(row_value(row, "Duration(us)")),
                    "active_duration_us": parse_float(row_value(row, "Active Duration(us)")),
                }
            )
        rows: list[dict[str, Any]] = []
        for name, aggregate in groups2.items():
            rows.append(
                {
                    **rank.annotation(),
                    "operator": name,
                    "allocations": aggregate.count,
                    "allocated_kb_total": metric_value(aggregate.total("size_kb")),
                    "allocation_kb_max": metric_value(aggregate.maximum("size_kb")),
                    "duration_us_total": metric_value(aggregate.total("duration_us")),
                    "active_duration_us_total": metric_value(aggregate.total("active_duration_us")),
                }
            )
        result["operator_rows"] = sorted(
            rows, key=lambda item: numeric_sort_value(item["allocated_kb_total"]), reverse=True
        )[:top_n]
    return result


def summarize_generic_csv(path: Path, rank: RankInfo, top_n: int) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    for index, row in enumerate(read_csv_rows(path)):
        if index >= max(top_n * 20, 1000):
            break
        cleaned = {clean_text(key, 200): clean_text(value, 1000) for key, value in row.items()}
        rows.append({**rank.annotation(), **cleaned})
    duration_fields = ["Total Time(us)", "Duration(us)", "Time(us)", "Total Time(ms)"]
    rows.sort(
        key=lambda item: max(numeric_sort_value(item.get(field)) for field in duration_fields),
        reverse=True,
    )
    return rows[:top_n]


EXPECTED_FILES = {
    "operator_details.csv": ("PyTorch 算子、输入 Shape、调用栈、Host/Device 耗时", "主证据"),
    "kernel_details.csv": ("设备执行算子、可选输入/输出 Shape、时序", "主证据（设备侧）"),
    "communication.json": ("集合通信/P2P 的等待、同步、传输与消息量", "主证据（通信）"),
    "communication_matrix.json": ("rank/peer 链路、传输类型、带宽", "主证据（通信拓扑）"),
    "step_trace_time.csv": ("计算、通信、重叠、空闲、stage", "主证据（墙钟分解）"),
    "memory_record.csv": ("内存水位", "可选"),
    "operator_memory.csv": ("算子内存申请", "可选"),
    "api_statistic.csv": ("CANN API 调用开销", "次要诊断"),
    "op_statistic.csv": ("CANN/设备算子类型统计", "次要诊断"),
    "trace_view.json": ("完整时间线与框架-设备关联", "按需过滤，不整体载入"),
    "analysis.db": ("结构化关联数据", "按需检查 schema 后查询"),
}


def coverage_rows(output_dir: Path, rank: RankInfo) -> list[dict[str, Any]]:
    rows = []
    for name, (purpose, priority) in EXPECTED_FILES.items():
        path = output_dir / name
        rows.append(
            {
                **rank.annotation(),
                "file": name,
                "present": "是" if path.exists() else "否",
                "size_bytes": path.stat().st_size if path.exists() else "缺失（文件不存在）",
                "purpose": purpose,
                "priority": priority,
                "limitation": missing_limitation(name) if not path.exists() else "",
            }
        )
    return rows


def missing_limitation(name: str) -> str:
    mapping = {
        "operator_details.csv": "无法形成 PyTorch 主线，也无法获得框架输入 Shape/调用栈",
        "kernel_details.csv": "无法获得设备执行算子输入/输出 Shape 与通信邻接序列",
        "communication.json": "无法区分等待、同步、传输时间和消息量",
        "communication_matrix.json": "无法验证 peer/link/transport，也难以判断通信属于哪个并行轴",
        "step_trace_time.csv": "无法用墙钟口径区分计算、通信重叠和空闲",
        "memory_record.csv": "无法报告内存峰值",
        "operator_memory.csv": "无法定位算子级内存申请",
        "trace_view.json": "无法做精确框架-设备时序关联",
    }
    return mapping.get(name, "该分析维度不可用")


def summarize_rank(
    output_dir: Path,
    destination: Path,
    top_n: int,
    copy_json_max_mb: float,
    event_limit: int,
    rank_map: dict[int, dict[str, Any]],
) -> dict[str, Any]:
    rank = rank_info(output_dir)
    rank_out = destination / rank.rank_label
    rank_out.mkdir(parents=True, exist_ok=True)
    result: dict[str, Any] = {"rank_info": asdict(rank), "coverage": coverage_rows(output_dir, rank)}
    write_csv(rank_out / "source_coverage.csv", result["coverage"])

    operator_path = output_dir / "operator_details.csv"
    if operator_path.exists():
        operator_full = summarize_pytorch_operators(operator_path, rank, top_n)
        write_csv(rank_out / "pytorch_operator_top.csv", operator_full["name_rows"][:top_n])
        write_csv(rank_out / "pytorch_operator_shapes.csv", operator_full["signature_rows"])
        write_csv(rank_out / "pytorch_operator_shape_variants.csv", operator_full["variant_rows"])
        operator = dict(operator_full)
        operator["name_rows"] = operator_full["name_rows"][:top_n]
        operator["signature_rows"] = operator_full["signature_rows"][:top_n]
        operator["variant_rows"] = operator_full["variant_rows"][:top_n]
        operator["comparison_full_signatures_written"] = True
        result["pytorch_operator"] = operator

    kernel_path = output_dir / "kernel_details.csv"
    if kernel_path.exists():
        device_full = summarize_device_operators(kernel_path, rank, top_n, event_limit)
        write_csv(rank_out / "device_operator_top.csv", device_full["name_rows"][:top_n])
        write_csv(rank_out / "device_operator_shapes.csv", device_full["signature_rows"])
        write_csv(rank_out / "communication_kernel_shapes.csv", device_full["communication_rows"])
        write_csv(rank_out / "communication_context.csv", device_full["communication_context_rows"])
        device = dict(device_full)
        device["name_rows"] = device_full["name_rows"][:top_n]
        device["signature_rows"] = device_full["signature_rows"][:top_n]
        device["communication_rows"] = device_full["communication_rows"][:top_n]
        device["comparison_full_signatures_written"] = True
        result["device_operator"] = device

    comm_rows_full: list[dict[str, Any]] = []
    comm_summary_full: list[dict[str, Any]] = []
    communication_path = output_dir / "communication.json"
    if communication_path.exists():
        try:
            communication_value = read_json(communication_path)
            comm_rows_full = communication_rows_from_json(communication_value, rank)
            comm_summary_full = aggregate_communication(comm_rows_full)
            result["communication"] = {
                "row_count": len(comm_rows_full),
                "rows": comm_rows_full[:top_n],
                "summary": comm_summary_full[:top_n],
            }
            write_csv(rank_out / "communication_ops.csv", comm_rows_full)
            write_csv(rank_out / "communication_summary.csv", comm_summary_full)
            write_json(rank_out / "communication_structure_summary.json", truncate_json(communication_value))
            if communication_path.stat().st_size <= copy_json_max_mb * 1024 * 1024:
                shutil.copy2(communication_path, rank_out / communication_path.name)
        except Exception as exc:
            result["communication_error"] = f"{type(exc).__name__}: {exc}"

    matrix_path = output_dir / "communication_matrix.json"
    if matrix_path.exists():
        try:
            matrix_value = read_json(matrix_path)
            matrix_rows = communication_matrix_rows(matrix_value, rank)
            for matrix_row in matrix_rows:
                matrix_row["parallel_axis"] = infer_axis_for_link(matrix_row, rank_map)
            result["communication_matrix"] = {"row_count": len(matrix_rows), "rows": matrix_rows[:top_n]}
            write_csv(rank_out / "communication_matrix_links.csv", matrix_rows)
            write_json(rank_out / "communication_matrix_structure_summary.json", truncate_json(matrix_value))
            if matrix_path.stat().st_size <= copy_json_max_mb * 1024 * 1024:
                shutil.copy2(matrix_path, rank_out / matrix_path.name)
        except Exception as exc:
            result["communication_matrix_error"] = f"{type(exc).__name__}: {exc}"

    if comm_rows_full and result.get("communication_matrix", {}).get("rows"):
        axis_by_key: dict[tuple[str, str, str], set[str]] = defaultdict(set)
        for matrix_row in result["communication_matrix"]["rows"]:
            axis = str(matrix_row.get("parallel_axis", "未知"))
            if axis and axis != "未知":
                axis_by_key[
                    (
                        str(matrix_row.get("step", "")),
                        str(matrix_row.get("collective_type", "")),
                        str(matrix_row.get("communication_group", "")),
                    )
                ].add(axis)
        for comm_row in comm_rows_full:
            axes = axis_by_key.get(
                (
                    str(comm_row.get("step", "")),
                    str(comm_row.get("collective_type", "")),
                    str(comm_row.get("communication_group", "")),
                ),
                set(),
            )
            if axes:
                comm_row["parallel_axis"] = ",".join(sorted(axes))
        comm_summary_full = aggregate_communication(comm_rows_full)
        result["communication"]["rows"] = comm_rows_full[:top_n]
        result["communication"]["summary"] = comm_summary_full[:top_n]
        write_csv(rank_out / "communication_ops.csv", comm_rows_full)
        write_csv(rank_out / "communication_summary.csv", comm_summary_full)

    step_path = output_dir / "step_trace_time.csv"
    if step_path.exists():
        rows = summarize_step_trace(step_path, rank)
        result["step_trace"] = rows
        write_csv(rank_out / "step_trace_time.csv", rows)

    memory = summarize_memory(output_dir, rank, top_n)
    if memory["record_rows"] or memory["operator_rows"]:
        result["memory"] = memory
        write_csv(rank_out / "memory_peaks.csv", memory["record_rows"])
        write_csv(rank_out / "operator_memory_top.csv", memory["operator_rows"])

    for name in ["api_statistic.csv", "op_statistic.csv", "l2_cache.csv", "npu_module_mem.csv"]:
        path = output_dir / name
        if path.exists():
            rows = summarize_generic_csv(path, rank, top_n)
            key = path.stem
            result[key] = rows
            write_csv(rank_out / f"{key}_top.csv", rows)

    metadata_paths = [output_dir.parent / "profiler_metadata.json", *sorted(output_dir.parent.glob("profiler_info_*.json"))]
    metadata_summaries = []
    for path in metadata_paths:
        if not path.exists():
            continue
        try:
            value = read_json(path)
            summary = truncate_json(value)
            write_json(rank_out / f"{path.stem}_summary.json", summary)
            metadata_summaries.append({"file": path.name, "summary": summary})
        except Exception as exc:
            metadata_summaries.append({"file": path.name, "error": f"{type(exc).__name__}: {exc}"})
    result["metadata"] = metadata_summaries
    return result


def inferred_degrees(results: list[dict[str, Any]]) -> dict[str, Any]:
    degrees: dict[str, Any] = {}
    for field_name in PARALLEL_FIELDS:
        values = [result["rank_info"].get(field_name) for result in results]
        known = [int(value) for value in values if value is not None]
        degrees[field_name] = max(known) + 1 if known else "未知"
    degrees["world_size_discovered"] = len(results)
    return degrees


def infer_axis_for_link(row: dict[str, Any], ranks: dict[int, dict[str, Any]]) -> str:
    current_raw = row.get("global_rank")
    try:
        current = int(current_raw)
    except (TypeError, ValueError):
        return "未知"
    peer_ids = [int(value) for value in RANK_IN_LINK_PATTERN.findall(str(row.get("link", ""))) if int(value) != current]
    if not peer_ids:
        return "未知"
    axes: set[str] = set()
    current_info = ranks.get(current, {})
    for peer in peer_ids:
        peer_info = ranks.get(peer)
        if not peer_info:
            continue
        changed = []
        for field_name in PARALLEL_FIELDS:
            left = current_info.get(field_name)
            right = peer_info.get(field_name)
            if left is not None and right is not None and left != right:
                changed.append(field_name.upper())
        if len(changed) == 1:
            axes.add(changed[0])
        elif changed:
            axes.add("+".join(changed))
    return ",".join(sorted(axes)) if axes else "未知"


def annotate_matrix_axes(results: list[dict[str, Any]]) -> list[dict[str, Any]]:
    rank_map = {
        int(info["global_rank"]): info
        for result in results
        for info in [result["rank_info"]]
        if info.get("global_rank") is not None
    }
    rows: list[dict[str, Any]] = []
    for result in results:
        for row in result.get("communication_matrix", {}).get("rows", []):
            enriched = dict(row)
            enriched["parallel_axis"] = infer_axis_for_link(enriched, rank_map)
            rows.append(enriched)
    return rows


def combined_rows(results: list[dict[str, Any]], *keys: str) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    for result in results:
        value: Any = result
        for key in keys:
            if not isinstance(value, dict):
                value = None
                break
            value = value.get(key)
        if isinstance(value, list):
            rows.extend(value)
    return rows


def comparison_rows(
    rows: list[dict[str, Any]], key_fields: list[str], metric: str, count_field: str, top_n: int
) -> list[dict[str, Any]]:
    by_key: dict[tuple[str, ...], dict[str, Any]] = defaultdict(dict)
    for row in rows:
        key = tuple(str(row.get(field, "")) for field in key_fields)
        rank = str(row.get("rank", "unknown"))
        current = by_key[key]
        current.update({field: value for field, value in zip(key_fields, key)})
        for field, parser in ((metric, parse_float), (count_field, parse_int)):
            output_key = f"{rank}_{field}"
            state_key = f"_missing_{output_key}"
            incoming = parser(row.get(field))
            if current.get(state_key) or incoming is None:
                current[state_key] = True
                current[output_key] = "缺失"
                continue
            existing = parser(current.get(output_key)) if output_key in current else 0
            if existing is None:
                current[state_key] = True
                current[output_key] = "缺失"
            else:
                current[output_key] = existing + incoming
    output: list[dict[str, Any]] = []
    for item in by_key.values():
        for key in [key for key in item if key.startswith("_missing_")]:
            item.pop(key, None)
        raw_totals = [raw for key, raw in item.items() if key.endswith(f"_{metric}")]
        parsed_totals = [parse_float(raw) for raw in raw_totals]
        totals_complete = bool(parsed_totals) and all(value is not None for value in parsed_totals)
        totals = [value for value in parsed_totals if value is not None]
        ratio = (
            max(totals) / min(totals)
            if totals_complete and len(totals) >= 2 and all(value > 0 for value in totals)
            else None
        )
        item["max_min_ratio"] = round(ratio, 6) if ratio is not None else "不可比较"
        item["max_metric"] = metric_value(max(totals) if totals_complete else None)
        output.append(item)
    return sorted(output, key=lambda item: numeric_sort_value(item["max_metric"]), reverse=True)[:top_n]


def markdown_table(rows: list[dict[str, Any]], columns: list[tuple[str, str]], top_n: int = 15) -> list[str]:
    if not rows:
        return ["_无数据_", ""]
    lines = ["| " + " | ".join(title for _, title in columns) + " |", "|" + "|".join(["---"] * len(columns)) + "|"]
    for row in rows[:top_n]:
        values = [clean_text(row.get(key, ""), 160).replace("|", "\\|") for key, _ in columns]
        lines.append("| " + " | ".join(values) + " |")
    lines.append("")
    return lines


def build_report(root: Path, results: list[dict[str, Any]], degrees: dict[str, Any]) -> str:
    lines = [
        "# Ascend/PyTorch Profiling 流式摘要",
        "",
        f"> 源目录：`{root}`  ",
        f"> 发现 profile/rank：{len(results)}  ",
        "> 语言：中文；原始 profiling 文件未修改。",
        "",
        "## 1. 拓扑与采集完整度",
        "",
        f"发现的并行度（按目录坐标推导）：DP={degrees['dp']}、TP={degrees['tp']}、EP={degrees['ep']}、"
        f"PP={degrees['pp']}、CP={degrees['cp']}、DCP={degrees['dcp']}。缺失坐标保持“未知”，不按 rank 编号猜测。",
        "",
    ]
    topology_rows = []
    for result in results:
        info = result["rank_info"]
        pytorch = result.get("pytorch_operator", {})
        device = result.get("device_operator", {})
        missing_primary = [
            row["file"]
            for row in result.get("coverage", [])
            if row["present"] == "否" and str(row["priority"]).startswith("主证据")
        ]
        topology_rows.append(
            {
                "rank": info["rank_label"],
                "coordinate": RankInfo(**info).coordinate_text(),
                "pytorch_rows": pytorch.get("row_count", "未采集") if pytorch else "未采集",
                "pytorch_shape": pytorch.get("shape_coverage_percent", "未采集") if pytorch else "未采集",
                "device_rows": device.get("row_count", "未采集") if device else "未采集",
                "device_shape": device.get("shape_coverage_percent", "未采集") if device else "未采集",
                "missing": ",".join(missing_primary) or "无",
            }
        )
    lines.extend(
        markdown_table(
            topology_rows,
            [
                ("rank", "Rank"),
                ("coordinate", "并行坐标"),
                ("pytorch_rows", "PyTorch 行数"),
                ("pytorch_shape", "PyTorch 输入 Shape 覆盖(%)"),
                ("device_rows", "设备算子行数"),
                ("device_shape", "设备 I/O Shape 覆盖(%)"),
                ("missing", "缺失主证据"),
            ],
            50,
        )
    )

    lines.extend(["## 2. PyTorch 算子主线", ""])
    for result in results:
        info = result["rank_info"]
        lines.extend([f"### {info['rank_label']}（{RankInfo(**info).coordinate_text()}）", ""])
        operator = result.get("pytorch_operator", {})
        if not operator:
            lines.extend(["`未知`：缺少 operator_details.csv，不能进行 PyTorch 框架算子分析。", ""])
            continue
        lines.append(
            f"`事实`：共 {operator['row_count']} 条 PyTorch 算子记录；输入 Shape 覆盖率 "
            f"{operator['shape_coverage_percent']}%，调用栈覆盖率 {operator['stack_coverage_percent']}%。"
        )
        lines.append("")
        lines.extend(
            markdown_table(
                operator["signature_rows"],
                [
                    ("operator", "PyTorch 算子"),
                    ("input_shapes", "输入 Shape"),
                    ("calls", "调用数"),
                    ("device_self_us_total", "Device Self 总计(us)"),
                    ("host_self_us_total", "Host Self 总计(us)"),
                    ("call_stack_sample", "调用栈样例"),
                ],
            )
        )
    lines.extend(
        [
            "`事实`：当前 torch_npu 的 operator_details.csv 不导出 PyTorch 算子输出 Shape；上表不伪造该字段。",
            "设备执行层的输入/输出 Shape 见下一节及各 rank 的 `device_operator_shapes.csv`。",
            "",
            "## 3. 设备执行算子与 Shape（PyTorch 主线的下钻证据）",
            "",
        ]
    )
    for result in results:
        info = result["rank_info"]
        device = result.get("device_operator", {})
        lines.extend([f"### {info['rank_label']}", ""])
        if not device:
            lines.extend(["`未知`：缺少 kernel_details.csv。", ""])
            continue
        lines.extend(
            markdown_table(
                device["signature_rows"],
                [
                    ("operator", "执行算子"),
                    ("input_shapes", "输入 Shape"),
                    ("output_shapes", "输出 Shape"),
                    ("calls", "调用数"),
                    ("duration_us_total", "累计时长(us)"),
                    ("duration_us_max", "最大单次(us)"),
                ],
            )
        )

    lines.extend(["## 4. 通信算子、消息量与重叠", ""])
    for result in results:
        info = result["rank_info"]
        communication = result.get("communication", {})
        lines.extend([f"### {info['rank_label']}", ""])
        if communication:
            lines.extend(
                markdown_table(
                    communication["summary"],
                    [
                        ("collective_type", "通信类型"),
                        ("communication_group", "通信组"),
                        ("parallel_axis", "并行维度"),
                        ("calls", "调用数"),
                        ("transit_size_mb_total", "消息量(MB)"),
                        ("transit_ms_total", "传输(ms)"),
                        ("wait_ms_total", "等待(ms)"),
                        ("synchronization_ms_total", "同步(ms)"),
                    ],
                )
            )
        else:
            lines.extend(["`未知`：缺少或无法解析 communication.json。", ""])
        kernel_comm = result.get("device_operator", {}).get("communication_rows", [])
        if kernel_comm:
            lines.extend(
                markdown_table(
                    kernel_comm,
                    [
                        ("operator", "通信执行算子"),
                        ("input_shapes", "输入 Shape"),
                        ("output_shapes", "输出 Shape"),
                        ("calls", "调用数"),
                        ("duration_us_total", "Kernel 累计(us)"),
                    ],
                    10,
                )
            )

    lines.extend(["## 5. Step/墙钟口径与内存", ""])
    step_rows = combined_rows(results, "step_trace")
    lines.extend(
        markdown_table(
            step_rows,
            [
                ("rank", "Rank"),
                ("step", "Step"),
                ("stage_us", "Stage(us)"),
                ("computing_us", "计算(us)"),
                ("communication_us", "通信(us)"),
                ("communication_not_overlapped_us", "未重叠通信(us)"),
                ("free_us", "空闲(us)"),
                ("nonoverlap_share_percent", "未重叠占比(%)"),
            ],
            50,
        )
    )
    memory_rows = combined_rows(results, "memory", "record_rows")
    if memory_rows:
        lines.extend(
            markdown_table(
                memory_rows,
                [
                    ("rank", "Rank"),
                    ("component", "组件"),
                    ("device_type", "设备"),
                    ("max_allocated_mb", "峰值已分配(MB)"),
                    ("max_reserved_mb", "峰值保留(MB)"),
                    ("max_active_mb", "峰值活跃(MB)"),
                ],
                30,
            )
        )

    lines.extend(
        [
            "## 6. 解释边界与后续报告要求",
            "",
            "- PyTorch 分析以 `operator_details.csv` 为主；CANN API/op statistic 只用于解释 launch、runtime 或设备侧异常。",
            "- `Device Total` 可能包含子算子；跨算子构成优先使用 `Device Self`，避免嵌套重复计时。",
            "- kernel duration 求和不等于墙钟；多 stream 会重叠。墙钟分解优先使用 `step_trace_time.csv`。",
            "- HCCL AICPU duration 可能包含等待/同步，不等于链路传输时间；传输口径优先使用 `communication.json`。",
            "- 通信并行维度只有在 matrix 链路与完整 DP/TP/EP/PP/CP/DCP 坐标能唯一对应时才能标为事实，否则保持未知。",
            "- 最终六份报告必须使用中文，并用 `事实`、`推断`、`未知`、`建议` 标注结论。",
            "",
        ]
    )
    return "\n".join(lines)


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--input", required=True, type=Path, help="Profiling 根目录")
    parser.add_argument("--output", required=True, type=Path, help="紧凑摘要输出目录")
    parser.add_argument("--top", type=int, default=200, help="每类保留的 Top N，默认 200")
    parser.add_argument(
        "--copy-json-max-mb",
        type=float,
        default=10.0,
        help="小于该大小的通信 JSON 同时复制，默认 10 MB",
    )
    parser.add_argument(
        "--communication-event-limit",
        type=int,
        default=50000,
        help="每 rank 最多保留的通信邻接事件数，默认 50000",
    )
    args = parser.parse_args()

    root = args.input.resolve()
    output = args.output.resolve()
    if not root.exists() or not root.is_dir():
        parser.error(f"输入目录不存在：{root}")
    if output == root or root in output.parents:
        parser.error("输出目录不能位于 profiling 输入目录内，避免污染原始数据")
    if args.top <= 0 or args.communication_event_limit <= 0:
        parser.error("--top 和 --communication-event-limit 必须为正数")

    output.mkdir(parents=True, exist_ok=True)
    write_csv(output / "file_inventory.csv", inventory(root))
    outputs = discover_outputs(root)
    if not outputs:
        parser.error(f"未找到 ASCEND_PROFILER_OUTPUT：{root}")

    discovered_infos = [rank_info(path) for path in outputs]
    rank_map = {
        int(info.global_rank): asdict(info)
        for info in discovered_infos
        if info.global_rank is not None
    }
    results = [
        summarize_rank(
            path,
            output,
            args.top,
            args.copy_json_max_mb,
            args.communication_event_limit,
            rank_map,
        )
        for path in outputs
    ]
    degrees = inferred_degrees(results)
    topology = []
    for result in results:
        info = RankInfo(**result["rank_info"])
        topology.append({**info.annotation(), "source": info.source, "coordinate_source": info.coordinate_source})
    write_csv(output / "rank_topology.csv", topology)
    write_json(output / "parallel_degrees.json", degrees)

    pytorch_rows = combined_rows(results, "pytorch_operator", "signature_rows")
    device_rows = combined_rows(results, "device_operator", "signature_rows")
    communication_rows = combined_rows(results, "communication", "rows")
    step_rows = combined_rows(results, "step_trace")
    memory_rows = combined_rows(results, "memory", "record_rows")
    coverage = combined_rows(results, "coverage")
    matrix_rows = annotate_matrix_axes(results)

    write_csv(output / "pytorch_operators_all_ranks.csv", pytorch_rows)
    write_csv(output / "device_operators_all_ranks.csv", device_rows)
    write_csv(output / "communication_ops_all_ranks.csv", communication_rows)
    write_csv(output / "communication_matrix_all_ranks.csv", matrix_rows)
    write_csv(output / "step_trace_all_ranks.csv", step_rows)
    write_csv(output / "memory_peaks_all_ranks.csv", memory_rows)
    write_csv(output / "source_coverage_all_ranks.csv", coverage)

    pytorch_comparison = comparison_rows(
        pytorch_rows,
        ["operator", "input_shapes"],
        "device_self_us_total",
        "calls",
        args.top,
    )
    device_comparison = comparison_rows(
        device_rows,
        ["operator", "input_shapes", "output_shapes"],
        "duration_us_total",
        "calls",
        args.top,
    )
    comm_summary_rows = combined_rows(results, "communication", "summary")
    communication_comparison = comparison_rows(
        comm_summary_rows,
        ["collective_type", "communication_group"],
        "transit_ms_total",
        "calls",
        args.top,
    )
    write_csv(output / "pytorch_operator_rank_comparison.csv", pytorch_comparison)
    write_csv(output / "device_operator_rank_comparison.csv", device_comparison)
    write_csv(output / "communication_rank_comparison.csv", communication_comparison)

    compact = {
        "schema_version": 3,
        "numeric_missing_semantics": "strict-null-v1",
        "language": "zh-CN",
        "source_root": str(root),
        "parallel_degrees": degrees,
        "ranks": results,
    }
    write_json(output / "summary.json", compact)
    (output / "summary.md").write_text(build_report(root, results, degrees), encoding="utf-8")

    print(f"完成：发现 {len(results)} 个 rank/profile 导出")
    print(f"摘要目录：{output}")
    print(f"请先阅读：{output / 'summary.md'}")
    if any(result.get("pytorch_operator") is None for result in results):
        print("警告：至少一个 rank 缺少 operator_details.csv，PyTorch 主线不完整。")
    if len(results) < 2:
        print("警告：只发现一个 rank，不能验证跨 rank 负载与通信平衡。")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

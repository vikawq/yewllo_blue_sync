#!/usr/bin/env node

import {createHash, randomUUID} from 'node:crypto';
import {createReadStream} from 'node:fs';
import {access, mkdir, realpath, rm, stat, writeFile} from 'node:fs/promises';
import {createServer} from 'node:http';
import {basename, delimiter, dirname, isAbsolute, relative, resolve, sep} from 'node:path';
import {createRequire} from 'node:module';

const DEFAULT_UI_URL = 'https://ui.perfetto.dev/';
const PERFETTO_UI_ORIGIN = 'https://ui.perfetto.dev';
const TRUSTED_NODE_MODULES_ENV = 'PERFETTO_PLAYWRIGHT_NODE_MODULES';
const DEFAULT_TIMEOUT_MS = 180_000;
const ARTIFACT_NAMES = {
  screenshot: 'perfetto_ui.png',
  frameHtml: 'perfetto_ui_frame.html',
  text: 'perfetto_ui_text.txt',
  browserLog: 'perfetto_browser.log',
  manifest: 'perfetto_manifest.json',
};
let preparedOutputDirForFallback = null;

function usage() {
  return `Usage:
  node render_perfetto_trace.mjs \\
    --trace <trace_view.json> --output <directory> \\
    --pid <process-id> --tid <thread-id> \\
    [--process-name <name>] [--thread-name <name>] \\
    [--ui-url <url>] [--browser <executable>] [--timeout-ms <milliseconds>]

Required:
  --trace       Local Chrome/Perfetto trace JSON file.
  --output      Directory for the screenshot, rendered HTML/text, log, and manifest.
  --pid         Process id selected for PyTorch operator analysis.
  --tid         Thread id selected for PyTorch operator analysis.

Optional:
  --process-name  Additional exact process-name constraint in PerfettoSQL.
  --thread-name   Additional exact thread-name constraint in PerfettoSQL.
  --ui-url        Optional URL whose origin must be exactly ${PERFETTO_UI_ORIGIN};
                  it is canonicalized to ${DEFAULT_UI_URL}.
  --browser       Chrome/Edge executable; auto-detected on Windows when omitted.
  --timeout-ms    Overall UI load/render timeout (default: ${DEFAULT_TIMEOUT_MS}).

Dependency:
  Set ${TRUSTED_NODE_MODULES_ENV} to an explicit trusted node_modules root.
`;
}

function parseArgs(argv) {
  const options = {};
  const valueOptions = new Set([
    '--trace', '--output', '--pid', '--tid', '--process-name', '--thread-name',
    '--ui-url', '--browser', '--timeout-ms',
  ]);
  for (let index = 0; index < argv.length; index += 1) {
    const arg = argv[index];
    if (arg === '--help' || arg === '-h') {
      options.help = true;
      continue;
    }
    if (!valueOptions.has(arg)) throw new Error(`Unknown argument: ${arg}`);
    if (index + 1 >= argv.length || argv[index + 1].startsWith('--')) {
      throw new Error(`Missing value for ${arg}`);
    }
    const key = arg.slice(2).replaceAll('-', '_');
    options[key] = argv[index + 1];
    index += 1;
  }
  return options;
}

function required(options, key) {
  const value = options[key];
  if (value === undefined || value === '') throw new Error(`Missing required --${key.replaceAll('_', '-')}`);
  return value;
}

function parseNonNegativeInteger(value, label) {
  if (!/^\d+$/.test(String(value))) throw new Error(`${label} must be a non-negative integer: ${value}`);
  const parsed = Number(value);
  if (!Number.isSafeInteger(parsed)) throw new Error(`${label} is outside JavaScript's safe integer range: ${value}`);
  return parsed;
}

function validateOptionalName(value, label) {
  if (value === undefined) return undefined;
  if (value.includes('\0')) throw new Error(`${label} cannot contain a NUL byte`);
  if (value.length > 512) throw new Error(`${label} is too long (maximum 512 characters)`);
  return value;
}

function normalizeUiUrl(value) {
  const parsed = new URL(value || DEFAULT_UI_URL);
  if (parsed.username || parsed.password) throw new Error('--ui-url must not contain credentials');
  if (parsed.origin !== PERFETTO_UI_ORIGIN) {
    throw new Error(`--ui-url origin must be exactly ${PERFETTO_UI_ORIGIN}`);
  }
  return DEFAULT_UI_URL;
}

function sqlLiteral(value) {
  return `'${String(value).replaceAll("'", "''")}'`;
}

function htmlEscape(value) {
  return String(value)
    .replaceAll('&', '&amp;')
    .replaceAll('<', '&lt;')
    .replaceAll('>', '&gt;')
    .replaceAll('"', '&quot;')
    .replaceAll("'", '&#39;');
}

async function exists(path) {
  try {
    await access(path);
    return true;
  } catch {
    return false;
  }
}

async function sha256File(path) {
  const hash = createHash('sha256');
  for await (const chunk of createReadStream(path)) hash.update(chunk);
  return hash.digest('hex');
}

function pathIsWithin(parentPath, childPath) {
  const childRelative = relative(parentPath, childPath);
  return childRelative === '' || (
    childRelative !== '..'
    && !childRelative.startsWith(`..${sep}`)
    && !isAbsolute(childRelative)
  );
}

function pathsOverlap(firstPath, secondPath) {
  return pathIsWithin(firstPath, secondPath) || pathIsWithin(secondPath, firstPath);
}

async function canonicalizeProspectivePath(inputPath) {
  let cursor = resolve(inputPath);
  const missingParts = [];
  while (true) {
    try {
      const existing = await realpath(cursor);
      return resolve(existing, ...missingParts);
    } catch (error) {
      if (!['ENOENT', 'ENOTDIR'].includes(error?.code)) throw error;
      const parent = dirname(cursor);
      if (parent === cursor) return resolve(inputPath);
      missingParts.unshift(basename(cursor));
      cursor = parent;
    }
  }
}

async function validateTraceOutputIsolation(tracePath, outputDir) {
  const fixedPaths = Object.values(ARTIFACT_NAMES).map((name) => resolve(outputDir, name));
  const candidates = [{label: '--output', path: outputDir}].concat(
    fixedPaths.map((path) => ({label: 'fixed artifact', path})),
  );
  const canonicalTrace = await canonicalizeProspectivePath(tracePath);
  for (const candidate of candidates) {
    if (pathsOverlap(tracePath, candidate.path)) {
      throw new Error(
        `Unsafe path overlap: --trace (${tracePath}) and ${candidate.label} (${candidate.path}) ` +
        'must not be equal or contain one another',
      );
    }
    const canonicalCandidate = await canonicalizeProspectivePath(candidate.path);
    if (pathsOverlap(canonicalTrace, canonicalCandidate)) {
      throw new Error(
        `Unsafe canonical path overlap: --trace (${canonicalTrace}) and ${candidate.label} ` +
        `(${canonicalCandidate}) must not be equal or contain one another`,
      );
    }
  }
}

async function prepareOutputDirectory(traceValue, outputValue) {
  const tracePath = resolve(traceValue);
  const outputDir = resolve(outputValue);
  const traceDetails = await stat(tracePath);
  if (!traceDetails.isFile()) throw new Error(`--trace is not a file: ${tracePath}`);
  await validateTraceOutputIsolation(tracePath, outputDir);
  await mkdir(outputDir, {recursive: true});
  await clearFixedArtifacts(outputDir);
  return {tracePath, traceDetails, outputDir};
}

function buildSql({pid, tid, processName, threadName}) {
  const identity = [`p.pid = ${pid}`, `t.tid = ${tid}`];
  if (processName !== undefined) identity.push(`p.name = ${sqlLiteral(processName)}`);
  if (threadName !== undefined) identity.push(`t.name = ${sqlLiteral(threadName)}`);
  const lowerName = "lower(COALESCE(s.name, ''))";
  const lowerCategory = "lower(COALESCE(s.category, ''))";
  const compactCategory = `replace(replace(${lowerCategory}, ' ', ''), char(9), '')`;
  const wrappedCategory = `(',' || ${compactCategory} || ',')`;
  const isCpuOp = `(
        ${wrappedCategory} GLOB '*,cpu_op,*'
        OR ${wrappedCategory} GLOB '*,*.cpu_op,*'
      )`;
  const knownNamespace = [
    'aten', 'prims', 'torch', 'torch_npu', 'npu', 'quantized', 'c10d', 'distributed',
  ].map((namespace) => `${lowerName} GLOB '${namespace}::*'`).join('\n        OR ');
  const forbiddenCategory = [
    'kernel', 'cann', 'runtime', 'driver', 'acl', 'hccl', 'memcpy',
    'python_function', 'user_annotation',
  ].map((part) => `${lowerCategory} GLOB '*${part}*'`).join('\n        OR ');
  const structuralScope = `(
        ${lowerName} GLOB '*profiler*step*'
        OR ${lowerName} GLOB '*pytorch*profiler*'
        OR ${lowerName} GLOB 'autograd::*'
        OR ${lowerName} GLOB 'python::*'
        OR ${lowerName} GLOB 'python *'
        OR ${lowerName} GLOB 'module::*'
        OR ${lowerName} GLOB 'module *'
        OR ${lowerName} = 'forward'
        OR ${lowerName} GLOB 'forward#*'
        OR ${lowerName} GLOB 'forward(*'
        OR ${lowerName} GLOB '*.forward'
        OR ${lowerName} GLOB '*.forward#*'
        OR ${lowerName} GLOB '*.forward(*'
        OR ${lowerName} GLOB '*#forward'
        OR ${lowerName} GLOB '*#forward#*'
        OR ${lowerName} GLOB '*#forward(*'
        OR ${lowerName} GLOB 'optimizer.*'
      )`;
  const deviceName = `(
        ${lowerName} GLOB 'cann*'
        OR ${lowerName} GLOB 'acl*'
        OR ${lowerName} GLOB 'rt*'
        OR ${lowerName} GLOB 'hccl*'
      )`;
  const operatorPredicate = `(
      (
        ${knownNamespace}
        OR (${isCpuOp} AND (instr(s.name, '::') > 1 OR ${lowerName} = 'record_param_comms'))
      )
      AND NOT (${forbiddenCategory})
      AND NOT ${structuralScope}
      AND NOT ${deviceName}
    )`;
  const fromAndWhere = `
    FROM slice s
    JOIN thread_track tt ON s.track_id = tt.id
    JOIN thread t ON tt.utid = t.utid
    JOIN process p ON t.upid = p.upid
    WHERE ${identity.join('\n      AND ')}
      AND s.dur >= 0
      AND ${operatorPredicate}`;
  return {
    debugTrack: `
      SELECT s.ts AS ts, s.dur AS dur, s.name AS name
      ${fromAndWhere}
      ORDER BY s.ts`,
    hotspot: `
      SELECT s.name AS operator,
             COUNT(*) AS calls,
             ROUND(SUM(s.dur) / 1000000.0, 6) AS total_ms,
             ROUND(AVG(s.dur) / 1000000.0, 6) AS avg_ms,
             ROUND(MAX(s.dur) / 1000000.0, 6) AS max_ms
      ${fromAndWhere}
      GROUP BY s.name
      ORDER BY SUM(s.dur) DESC
      LIMIT 100`,
  };
}

function jsonForInlineScript(value) {
  return JSON.stringify(value).replaceAll('<', '\\u003c');
}

function buildHostHtml(config) {
  return `<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <title>Local Perfetto trace renderer</title>
  <style>
    html, body { margin: 0; height: 100%; overflow: hidden; }
    #status { box-sizing: border-box; height: 28px; padding: 5px 8px; font: 13px/18px sans-serif; }
    #perfetto { display: block; width: 100%; height: calc(100% - 28px); border: 0; }
  </style>
</head>
<body>
  <div id="status">waiting-for-perfetto</div>
  <iframe id="perfetto" title="Perfetto UI"></iframe>
  <script type="module">
    const config = ${jsonForInlineScript(config)};
    const iframe = document.querySelector('#perfetto');
    const status = document.querySelector('#status');
    const commands = [
      {id: 'dev.perfetto.CollapseTracksByRegex', args: ['.*']},
      {id: 'dev.perfetto.AddDebugSliceTrack', args: [config.debugTrackSql, config.debugTrackTitle]},
      {id: 'dev.perfetto.RunQueryAndShowTab', args: [config.hotspotSql, config.hotspotTitle]},
    ];
    const route = new URLSearchParams({
      mode: 'embedded',
      pid: String(config.pid),
      tid: String(config.tid),
      query: config.hotspotSql,
      startupCommands: JSON.stringify(commands),
    });
    iframe.src = config.uiUrl + '#!/?' + route.toString();
    let handshakeAccepted = false;
    const ping = setInterval(() => iframe.contentWindow.postMessage('PING', config.uiOrigin), 100);
    const handshakeTimeout = setTimeout(() => {
      clearInterval(ping);
      status.textContent = 'error: timeout waiting for Perfetto PONG';
    }, config.timeoutMs);
    window.addEventListener('message', async function onMessage(event) {
      if (handshakeAccepted || event.origin !== config.uiOrigin ||
          event.source !== iframe.contentWindow || event.data !== 'PONG') return;
      handshakeAccepted = true;
      clearInterval(ping);
      clearTimeout(handshakeTimeout);
      status.textContent = 'perfetto-ready';
      try {
        const response = await fetch(config.traceRoute, {cache: 'no-store'});
        if (!response.ok) throw new Error('trace fetch failed: HTTP ' + response.status);
        const buffer = await response.arrayBuffer();
        const offline = await window[config.offlineBinding]({traceBytes: buffer.byteLength});
        if (!offline?.offline) throw new Error('browser context did not confirm offline mode');
        iframe.contentWindow.postMessage({perfetto: {
          buffer,
          title: config.traceTitle,
          fileName: config.fileName,
          localOnly: true,
          keepApiOpen: false,
        }}, config.uiOrigin);
        status.textContent = 'trace-posted offline-before-post=true pid=' + config.pid +
          ' tid=' + config.tid + ' bytes=' + buffer.byteLength;
      } catch (error) {
        status.textContent = 'error: ' + (error?.stack || error);
      }
    });
  </script>
</body>
</html>`;
}

async function loadPlaywright() {
  const attempts = [];
  const rawValue = process.env[TRUSTED_NODE_MODULES_ENV];
  if (!rawValue) {
    throw new Error(`${TRUSTED_NODE_MODULES_ENV} must name an explicit trusted node_modules root`);
  }
  const roots = [];
  for (const rawRoot of rawValue.split(delimiter).filter(Boolean)) {
    if (!isAbsolute(rawRoot)) {
      attempts.push(`${TRUSTED_NODE_MODULES_ENV}: ignored non-absolute dependency root ${rawRoot}`);
      continue;
    }
    roots.push({path: resolve(rawRoot), source: TRUSTED_NODE_MODULES_ENV});
  }
  const seenRoots = new Set();
  const scriptRequire = createRequire(import.meta.url);
  for (const root of roots) {
    const key = process.platform === 'win32' ? root.path.toLowerCase() : root.path;
    if (seenRoots.has(key)) continue;
    seenRoots.add(key);
    for (const packageName of ['playwright-core', 'playwright']) {
      const packageDir = resolve(root.path, packageName);
      try {
        if (!(await exists(resolve(packageDir, 'package.json')))) {
          attempts.push(`${packageName} in ${root.source} (${root.path}): package.json not found`);
          continue;
        }
        const module = scriptRequire(packageDir);
        if (module.chromium) {
          return {chromium: module.chromium, packageName, dependencyRoot: root.path, dependencySource: root.source};
        }
        attempts.push(`${packageName} in ${root.source} (${root.path}): chromium export not found`);
      } catch (error) {
        attempts.push(`${packageName} in ${root.source} (${root.path}): ${error.code || error.message}`);
      }
    }
  }
  throw new Error(
    'Playwright is unavailable in explicitly configured trusted dependency roots. Set ' +
    `${TRUSTED_NODE_MODULES_ENV} to an absolute trusted node_modules directory. ` +
    `Resolution attempts: ${attempts.join('; ')}`,
  );
}

async function detectBrowser(explicitPath) {
  if (explicitPath) {
    const path = resolve(explicitPath);
    if (!(await exists(path))) throw new Error(`Browser executable does not exist: ${path}`);
    return path;
  }
  const candidates = process.platform === 'win32'
    ? [
        'C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe',
        'C:\\Program Files (x86)\\Google\\Chrome\\Application\\chrome.exe',
        process.env.LOCALAPPDATA && resolve(process.env.LOCALAPPDATA, 'Google', 'Chrome', 'Application', 'chrome.exe'),
        'C:\\Program Files\\Microsoft\\Edge\\Application\\msedge.exe',
        'C:\\Program Files (x86)\\Microsoft\\Edge\\Application\\msedge.exe',
      ]
    : ['/usr/bin/google-chrome', '/usr/bin/chromium', '/usr/bin/chromium-browser'];
  for (const candidate of candidates.filter(Boolean)) {
    if (await exists(candidate)) return candidate;
  }
  throw new Error('No Chrome/Edge executable was auto-detected; pass --browser <executable>');
}

async function closeServer(server) {
  if (!server?.listening) return;
  await new Promise((resolveClose) => server.close(resolveClose));
}

async function artifactInventory(outputDir) {
  const result = {};
  for (const [kind, name] of Object.entries(ARTIFACT_NAMES)) {
    const path = resolve(outputDir, name);
    try {
      const details = await stat(path);
      result[kind] = {path, exists: true, bytes: details.size};
    } catch {
      result[kind] = {path, exists: false, bytes: 0};
    }
  }
  return result;
}

async function clearFixedArtifacts(outputDir) {
  for (const name of Object.values(ARTIFACT_NAMES)) {
    await rm(resolve(outputDir, name), {force: true});
  }
}

async function writeFailurePlaceholder(outputDir, error) {
  const message = `Perfetto rendering failed\n${error.stack || error.message || error}\n`;
  const textPath = resolve(outputDir, ARTIFACT_NAMES.text);
  const htmlPath = resolve(outputDir, ARTIFACT_NAMES.frameHtml);
  await writeFile(textPath, message, 'utf8');
  await writeFile(htmlPath, `<!doctype html><meta charset="utf-8"><pre>${htmlEscape(message)}</pre>`, 'utf8');
}

async function run(options) {
  const prepared = await prepareOutputDirectory(
    required(options, 'trace'),
    required(options, 'output'),
  );
  const {tracePath, traceDetails, outputDir} = prepared;
  preparedOutputDirForFallback = outputDir;
  const startedAt = new Date();
  const manifest = {
    schema_version: 1,
    status: 'running',
    started_at: startedAt.toISOString(),
    finished_at: null,
    elapsed_ms: null,
    selection: null,
    trace: null,
    perfetto: null,
    browser: null,
    sql: null,
    rendered: null,
    artifacts: null,
    error: null,
  };
  const logs = [];
  let server;
  let browser;
  let page;
  let perfettoFrame;
  let runError;
  const networkIsolation = {
    service_workers: 'playwright-block-plus-compatible-register-stub',
    service_worker_count_after_render: null,
    service_worker_guard_visible_in_perfetto_frame: null,
    offline_requested_at: null,
    offline_active_at: null,
    offline_before_trace_post: false,
    post_offline_request_urls: [],
  };

  try {
    const pid = parseNonNegativeInteger(required(options, 'pid'), '--pid');
    const tid = parseNonNegativeInteger(required(options, 'tid'), '--tid');
    const processName = validateOptionalName(options.process_name, '--process-name');
    const threadName = validateOptionalName(options.thread_name, '--thread-name');
    const timeoutMs = options.timeout_ms === undefined
      ? DEFAULT_TIMEOUT_MS
      : parseNonNegativeInteger(options.timeout_ms, '--timeout-ms');
    if (timeoutMs < 1_000) throw new Error('--timeout-ms must be at least 1000');
    const uiUrl = normalizeUiUrl(options.ui_url || DEFAULT_UI_URL);
    const browserPath = await detectBrowser(options.browser);
    const sql = buildSql({pid, tid, processName, threadName});
    const nameSuffix = [processName, threadName].filter(Boolean).join(' / ');
    const debugTrackTitle = `PyTorch算子时间线 pid=${pid} tid=${tid}${nameSuffix ? ` ${nameSuffix}` : ''}`;
    const hotspotTitle = `PyTorch算子热点 pid=${pid} tid=${tid}${nameSuffix ? ` ${nameSuffix}` : ''}`;
    const traceToken = randomUUID();
    const offlineBinding = `__codexPerfettoSetOffline_${traceToken.replaceAll('-', '')}`;
    const traceRoute = `/trace/${traceToken}`;
    const traceTitle = `PyTorch trace pid=${pid} tid=${tid}`;

    manifest.selection = {pid, tid, process_name: processName ?? null, thread_name: threadName ?? null};
    manifest.trace = {
      path: tracePath,
      file_name: basename(tracePath),
      bytes: traceDetails.size,
      sha256: await sha256File(tracePath),
    };
    manifest.perfetto = {
      ui_url: uiUrl,
      ui_origin: PERFETTO_UI_ORIGIN,
      embedded: true,
      local_only: true,
      message_origin_enforced: true,
      post_message_target_origin: PERFETTO_UI_ORIGIN,
      network_isolation: networkIsolation,
    };
    manifest.sql = {debug_track: sql.debugTrack, hotspot: sql.hotspot};

    const hostHtml = buildHostHtml({
      uiUrl,
      uiOrigin: PERFETTO_UI_ORIGIN,
      traceRoute,
      offlineBinding,
      traceTitle,
      fileName: basename(tracePath),
      pid,
      tid,
      timeoutMs,
      debugTrackSql: sql.debugTrack,
      hotspotSql: sql.hotspot,
      debugTrackTitle,
      hotspotTitle,
    });
    server = createServer((request, response) => {
      const pathname = new URL(request.url || '/', 'http://127.0.0.1').pathname;
      response.setHeader('Cache-Control', 'no-store');
      if (pathname === traceRoute) {
        response.statusCode = 200;
        response.setHeader('Content-Type', 'application/json');
        response.setHeader('Content-Length', String(traceDetails.size));
        const stream = createReadStream(tracePath);
        stream.on('error', (error) => {
          logs.push(`[host:trace-error] ${error.stack || error}`);
          if (!response.headersSent) response.statusCode = 500;
          response.destroy(error);
        });
        stream.pipe(response);
        return;
      }
      if (pathname === '/favicon.ico') {
        response.statusCode = 204;
        response.end();
        return;
      }
      response.statusCode = 200;
      response.setHeader('Content-Type', 'text/html; charset=utf-8');
      response.end(hostHtml);
    });
    server.on('clientError', (error, socket) => {
      logs.push(`[host:client-error] ${error.stack || error}`);
      socket.end('HTTP/1.1 400 Bad Request\r\n\r\n');
    });
    await new Promise((resolveListen, rejectListen) => {
      server.once('error', rejectListen);
      server.listen(0, '127.0.0.1', resolveListen);
    });
    const address = server.address();
    const hostUrl = `http://127.0.0.1:${address.port}/`;

    const playwright = await loadPlaywright();
    browser = await playwright.chromium.launch({headless: true, executablePath: browserPath});
    manifest.browser = {
      automation_package: playwright.packageName,
      dependency_root: playwright.dependencyRoot,
      dependency_source: playwright.dependencySource,
      executable: browserPath,
      version: browser.version(),
      headless: true,
    };
    const context = await browser.newContext({
      viewport: {width: 1600, height: 1000},
      serviceWorkers: 'block',
    });
    // Perfetto expects register() to resolve to a registration-like object.
    // Provide that compatibility surface while Playwright blocks actual
    // Service Worker creation as a second, browser-level boundary.
    await context.addInitScript(() => {
      const container = navigator.serviceWorker;
      if (!container) return;
      const registration = {
        installing: null,
        waiting: null,
        active: null,
        scope: `${location.origin}/`,
        updateViaCache: 'none',
        onupdatefound: null,
        addEventListener() {},
        removeEventListener() {},
        dispatchEvent() { return true; },
        update() { return Promise.resolve(); },
        unregister() { return Promise.resolve(true); },
      };
      Object.defineProperties(container, {
        register: {value: async () => registration, configurable: false, writable: false},
        getRegistration: {value: async () => undefined, configurable: false, writable: false},
        getRegistrations: {value: async () => [], configurable: false, writable: false},
      });
      Object.defineProperty(globalThis, '__codexServiceWorkerBlocked', {
        value: true,
        configurable: false,
        writable: false,
      });
    });
    page = await context.newPage();
    await page.exposeBinding(offlineBinding, async ({frame}, request) => {
      if (frame !== page.mainFrame()) {
        throw new Error('offline transition may only be requested by the localhost main frame');
      }
      if (Number(request?.traceBytes) !== traceDetails.size) {
        throw new Error('offline transition trace byte count mismatch');
      }
      if (!networkIsolation.offline_active_at) {
        networkIsolation.offline_requested_at = new Date().toISOString();
        await context.setOffline(true);
        networkIsolation.offline_active_at = new Date().toISOString();
      }
      networkIsolation.offline_before_trace_post = true;
      return {offline: true, activatedAt: networkIsolation.offline_active_at};
    });
    page.on('console', (message) => logs.push(`[console:${message.type()}] ${message.text()}`));
    page.on('pageerror', (error) => logs.push(`[pageerror] ${error.stack || error}`));
    page.on('requestfailed', (request) => {
      logs.push(`[requestfailed] ${request.url()} :: ${request.failure()?.errorText || 'unknown'}`);
    });
    page.on('request', (request) => {
      if (networkIsolation.offline_active_at && networkIsolation.post_offline_request_urls.length < 200) {
        networkIsolation.post_offline_request_urls.push(request.url());
      }
    });
    const deadline = Date.now() + timeoutMs;
    const remaining = () => {
      const value = deadline - Date.now();
      if (value <= 0) throw new Error(`Timed out after ${timeoutMs}ms while rendering Perfetto`);
      return value;
    };
    await page.goto(hostUrl, {waitUntil: 'domcontentloaded', timeout: remaining()});
    await page.waitForFunction(
      () => document.querySelector('#status')?.textContent?.startsWith('trace-posted'),
      undefined,
      {timeout: remaining()},
    );
    const iframeElement = await page.$('#perfetto');
    perfettoFrame = await iframeElement?.contentFrame();
    if (!perfettoFrame) throw new Error('Perfetto iframe was not created');
    await perfettoFrame.waitForFunction(
      ({title}) => {
        const text = document.body?.innerText || '';
        return text.includes(title) && /Returned\s+\d+\s+rows/.test(text);
      },
      {title: hotspotTitle},
      {timeout: remaining()},
    );
    await page.waitForTimeout(Math.min(1500, remaining()));

    networkIsolation.service_worker_count_after_render = context.serviceWorkers().length;
    networkIsolation.service_worker_guard_visible_in_perfetto_frame = await perfettoFrame.evaluate(
      () => globalThis.__codexServiceWorkerBlocked === true,
    );

    const frameHtml = await perfettoFrame.content();
    const bodyText = await perfettoFrame.locator('body').innerText();
    const visibleGridRows = await perfettoFrame.locator('[role="table"]').last().locator('[role="row"]').evaluateAll(
      (rows) => rows.map((row) => Array.from(row.querySelectorAll('[role="columnheader"], [role="cell"]'))
        .map((cell) => (
          cell.querySelector('.pf-grid-cell__content, .pf-grid-header-cell__title-wrapper')?.textContent || ''
        ).trim())),
    );
    await writeFile(resolve(outputDir, ARTIFACT_NAMES.frameHtml), frameHtml, 'utf8');
    await writeFile(resolve(outputDir, ARTIFACT_NAMES.text), bodyText, 'utf8');
    await page.screenshot({path: resolve(outputDir, ARTIFACT_NAMES.screenshot), fullPage: false});
    manifest.rendered = {
      host_url: hostUrl,
      iframe_url: perfettoFrame.url(),
      frame_title: await perfettoFrame.title(),
      body_text_characters: bodyText.length,
      canvas_count: await perfettoFrame.locator('canvas').count(),
      visible_query_grid_rows: visibleGridRows,
    };
    manifest.status = 'success';
  } catch (error) {
    runError = error instanceof Error ? error : new Error(String(error));
    manifest.status = 'failure';
    manifest.error = {name: runError.name, message: runError.message, stack: runError.stack};
    logs.push(`[fatal] ${runError.stack || runError}`);
    await rm(resolve(outputDir, ARTIFACT_NAMES.screenshot), {force: true});
    await rm(resolve(outputDir, ARTIFACT_NAMES.browserLog), {force: true});
    await writeFailurePlaceholder(outputDir, runError);
  } finally {
    if (browser) {
      try {
        await browser.close();
      } catch (error) {
        logs.push(`[browser-close-error] ${error.stack || error}`);
      }
    }
    if (server) {
      try {
        await closeServer(server);
      } catch (error) {
        logs.push(`[server-close-error] ${error.stack || error}`);
      }
    }
    await writeFile(resolve(outputDir, ARTIFACT_NAMES.browserLog), `${logs.join('\n')}\n`, 'utf8');
    manifest.finished_at = new Date().toISOString();
    manifest.elapsed_ms = Date.now() - startedAt.getTime();
    manifest.artifacts = await artifactInventory(outputDir);
    manifest.artifacts.manifest = {
      path: resolve(outputDir, ARTIFACT_NAMES.manifest),
      exists: true,
      bytes: null,
    };
    await writeFile(resolve(outputDir, ARTIFACT_NAMES.manifest), `${JSON.stringify(manifest, null, 2)}\n`, 'utf8');
  }
  return {manifest, error: runError};
}

let manifestWritten = false;
try {
  const argv = process.argv.slice(2);
  const options = parseArgs(argv);
  if (options.help) {
    console.log(usage());
  } else {
    const result = await run(options);
    manifestWritten = true;
    if (result.error) throw result.error;
    const manifest = result.manifest;
    console.log(JSON.stringify({
      status: manifest.status,
      screenshot: manifest.artifacts.screenshot.path,
      frame_html: manifest.artifacts.frameHtml.path,
      text: manifest.artifacts.text.path,
      manifest: resolve(required(options, 'output'), ARTIFACT_NAMES.manifest),
    }, null, 2));
  }
} catch (error) {
  const failure = error instanceof Error ? error : new Error(String(error));
  if (!manifestWritten && preparedOutputDirForFallback) {
    try {
      const outputDir = preparedOutputDirForFallback;
      await clearFixedArtifacts(outputDir);
      const manifestPath = resolve(outputDir, ARTIFACT_NAMES.manifest);
      await writeFailurePlaceholder(outputDir, failure);
      await writeFile(resolve(outputDir, ARTIFACT_NAMES.browserLog), `[fatal] ${failure.stack || failure}\n`, 'utf8');
      const artifacts = await artifactInventory(outputDir);
      artifacts.manifest = {path: manifestPath, exists: true, bytes: null};
      await writeFile(manifestPath, `${JSON.stringify({
        schema_version: 1,
        status: 'failure',
        started_at: new Date().toISOString(),
        finished_at: new Date().toISOString(),
        error: {name: failure.name, message: failure.message, stack: failure.stack},
        artifacts,
      }, null, 2)}\n`, 'utf8');
    } catch (manifestError) {
      console.error(`Additionally failed to write failure manifest: ${manifestError.stack || manifestError}`);
    }
  }
  console.error(`Perfetto rendering failed: ${failure.message}`);
  process.exitCode = 1;
}

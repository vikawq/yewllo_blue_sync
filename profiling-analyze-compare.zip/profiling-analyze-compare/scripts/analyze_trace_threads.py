#!/usr/bin/env python3
"""对比两个 Chrome/Ascend trace_view.json 中一个可复现选择的 PyTorch 线程。

脚本只依赖 Python 标准库。它以流式方式读取顶层事件数组或 ``traceEvents``
数组：第一遍建立 process-thread 候选清单，选择真机线程并在仿真侧做语义对齐；
第二遍只保留两个被选线程的 PyTorch operator slice。输出 CSV/JSON 证据、序列
差异以及基于 deepest/exclusive 时间的自包含 HTML 热力图。

真机固定为 reference，仿真固定为 candidate。差值均为 ``sim - real``，比率
均为 ``sim / real``。脚本不修改输入 trace；输出 Shape 只采用 operator 事件
``args`` 中直接记录的证据，缺失时保持未知，也不从设备 kernel 反推。
"""

from __future__ import annotations

import argparse
import csv
import difflib
import hashlib
import heapq
import html
import io
import json
import math
import re
import sys
import tempfile
from collections import Counter, defaultdict
from pathlib import Path
from typing import Any, Iterable, Iterator


UNKNOWN_OUTPUT_SHAPE = "未知（trace_view.json 未直接提供可信的 PyTorch 输出 Shape）"
UNKNOWN_INPUT_SHAPE = "未知（未采集）"
SCHEMA_VERSION = 2
SELECTION_ALGORITHM = "sha256-semantic-lane-v1"
MAX_EVENT_JSON_CHARS = 64 * 1024 * 1024
MAX_TEXT_FIELD = 4000
MAX_SEQUENCE_RUNS = 20000
MAX_WARNINGS = 1000

KNOWN_PYTORCH_NAMESPACES = {
    "aten",
    "prims",
    "torch",
    "torch_npu",
    "npu",
    "quantized",
    "c10d",
    "distributed",
}
FORBIDDEN_CATEGORY_PARTS = (
    "kernel",
    "cann",
    "runtime",
    "driver",
    "acl",
    "hccl",
    "memcpy",
    "python_function",
    "user_annotation",
)
SCOPE_PATTERN = re.compile(
    r"profiler\s*step|pytorch\s*profiler|autograd::engine::evaluate_function|"
    r"^python(::|\s)|^module(::|\s)|(^|[.#])forward($|[#(])|^optimizer\.",
    re.IGNORECASE,
)
NAMESPACE_PATTERN = re.compile(r"^([A-Za-z_][A-Za-z0-9_.]*)::")
THREAD_ID_PATTERN = re.compile(r"\bthread\s+[-+]?\d+\b", re.IGNORECASE)
SPACE_PATTERN = re.compile(r"\s+")
OUTPUT_SHAPE_ALIASES = (
    "Output Dims",
    "Output Shapes",
    "Output Shape",
    "Output Dimensions",
)

THREAD_RANK_FIELDS = "rank_pair_id,rank,global_rank,parallel_coordinate,dp,tp,ep,pp,cp,dcp".split(",")
THREAD_PAIR_RANK_FIELDS = (
    "rank_pair_id,real_parallel_coordinate,sim_parallel_coordinate,"
    "real_dp,sim_dp,real_tp,sim_tp,real_ep,sim_ep,real_pp,sim_pp,real_cp,sim_cp,real_dcp,sim_dcp"
).split(",")
THREAD_ARTIFACT_FIELDS = {
    "trace_thread_inventory": (
        "environment,pid,tid,process_name,thread_name,normalized_process_name,normalized_thread_name,"
        "semantic_lane_key,duration_events,pytorch_operator_calls,distinct_pytorch_operator_signatures,"
        "pytorch_operator_duration_us,first_operator_ts_us,last_operator_end_us,shape_coverage_percent,"
        "output_shape_coverage_percent,stack_coverage_percent,operator_fingerprint,operator_multiset,"
        "candidate,reject_reason"
    ).split(",") + THREAD_RANK_FIELDS,
    "selected_thread_pair": (
        "environment,pid,tid,process_name,thread_name,normalized_process_name,normalized_thread_name,"
        "pytorch_operator_calls,distinct_pytorch_operator_signatures,operator_fingerprint,selection_algorithm,"
        "seed,selection_method,selection_audit_steps,selected_pair_fingerprint,alignment_score,"
        "alignment_confidence,process_name_match,thread_name_match,operator_fingerprint_weighted_jaccard,"
        "timing_warning"
    ).split(",") + THREAD_RANK_FIELDS,
    "selected_thread_operator_events": (
        "environment,event_id,source_event_index,source_end_event_index,ph_original,pid,tid,process_name,"
        "thread_name,category,operator,operator_namespace,classification_reason,start_us,duration_us,end_us,"
        "depth,parent_event_id,parent_operator,nesting_status,self_duration_us,input_shapes,input_dtypes,"
        "input_strides,output_shapes,output_shape_evidence,output_shape_status,call_stack,module_hierarchy,"
        "external_id,record_function_id,sequence_number,fwd_thread_id,ev_idx,correlation_id,"
        "args_evidence_sha256,evidence,event_ordinal"
    ).split(",") + THREAD_RANK_FIELDS,
    "selected_thread_operator_summary": (
        "environment,pid,tid,process_name,thread_name,operator,operator_namespace,input_shapes,output_shapes,"
        "output_shape_status_counts,output_shape_evidence,calls,inclusive_us_total,inclusive_us_avg,"
        "inclusive_us_max,self_us_total,self_us_avg,self_us_max,first_start_us,last_end_us,"
        "stack_coverage_percent,call_stack_sample,event_ids"
    ).split(",") + THREAD_RANK_FIELDS,
    "selected_thread_operator_comparison": (
        "operator,input_shapes,output_shapes,presence,real_output_shape_status_counts,"
        "sim_output_shape_status_counts,real_output_shape_evidence,sim_output_shape_evidence,"
        "real_call_stack_sample,sim_call_stack_sample,real_event_ids,sim_event_ids,real_calls,sim_calls,"
        "calls_sim_minus_real,calls_sim_over_real,calls_delta_percent,real_inclusive_us_total,"
        "sim_inclusive_us_total,inclusive_us_total_sim_minus_real,inclusive_us_total_sim_over_real,"
        "inclusive_us_total_delta_percent,real_inclusive_us_avg,sim_inclusive_us_avg,"
        "inclusive_us_avg_sim_minus_real,inclusive_us_avg_sim_over_real,inclusive_us_avg_delta_percent,"
        "real_inclusive_us_max,sim_inclusive_us_max,inclusive_us_max_sim_minus_real,"
        "inclusive_us_max_sim_over_real,inclusive_us_max_delta_percent,real_self_us_total,sim_self_us_total,"
        "self_us_total_sim_minus_real,self_us_total_sim_over_real,self_us_total_delta_percent,"
        "real_self_us_avg,sim_self_us_avg,self_us_avg_sim_minus_real,self_us_avg_sim_over_real,"
        "self_us_avg_delta_percent,real_self_us_max,sim_self_us_max,self_us_max_sim_minus_real,"
        "self_us_max_sim_over_real,self_us_max_delta_percent"
    ).split(",") + THREAD_PAIR_RANK_FIELDS,
    "selected_thread_sequence_diff": (
        "diff_index,match_type,real_run_index,real_operator,real_input_shapes,real_output_shapes,"
        "real_calls_in_run,real_start_ordinal,real_end_ordinal,sim_run_index,sim_operator,sim_input_shapes,"
        "sim_output_shapes,sim_calls_in_run,sim_start_ordinal,sim_end_ordinal"
    ).split(",") + THREAD_PAIR_RANK_FIELDS,
    "selected_thread_operator_heatmap": (
        "environment,bin_index,normalized_start,normalized_end,bin_start_us,bin_end_us,bin_duration_us,"
        "operator,input_shapes,output_shapes,call_count_overlapping,inclusive_overlap_us,deepest_exclusive_us,"
        "exclusive_us,share_of_bin_percent,share_of_bin,is_dominant,nesting_status"
    ).split(",") + THREAD_RANK_FIELDS,
}


def clean_text(value: Any, limit: int = MAX_TEXT_FIELD) -> str:
    if value is None:
        return ""
    if isinstance(value, (dict, list, tuple)):
        text = json.dumps(value, ensure_ascii=False, separators=(",", ":"), sort_keys=True)
    else:
        text = str(value)
    text = SPACE_PATTERN.sub(" ", text).strip()
    return text if len(text) <= limit else text[: limit - 3] + "..."


def finite_number(value: Any) -> float | None:
    if isinstance(value, bool) or value is None:
        return None
    try:
        result = float(value)
    except (TypeError, ValueError):
        return None
    return result if math.isfinite(result) else None


def canonical_id(value: Any) -> str:
    if value is None:
        return ""
    if isinstance(value, bool):
        return "true" if value else "false"
    if isinstance(value, int):
        return str(value)
    if isinstance(value, float) and math.isfinite(value):
        return str(int(value)) if value.is_integer() else format(value, ".17g")
    return clean_text(value, 256)


def compact_json(value: Any, limit: int = MAX_TEXT_FIELD) -> str:
    if value is None or value == "":
        return ""
    try:
        text = json.dumps(value, ensure_ascii=False, separators=(",", ":"), sort_keys=True)
    except (TypeError, ValueError):
        text = str(value)
    return clean_text(text, limit)


def stable_hash(*parts: Any, length: int = 64) -> str:
    payload = "\x1f".join(str(part) for part in parts)
    return hashlib.sha256(payload.encode("utf-8", errors="replace")).hexdigest()[:length]


def strict_json_loads(raw: str) -> Any:
    def reject_constant(value: str) -> None:
        raise ValueError(f"JSON 不允许非有限常量 {value}")

    return json.loads(raw, parse_constant=reject_constant)


def normalized_arg_key(key: Any) -> str:
    return re.sub(r"[^a-z0-9]", "", str(key).lower())


def arg_value(args: dict[str, Any], *aliases: str) -> Any:
    if not args:
        return None
    indexed = {normalized_arg_key(key): value for key, value in args.items()}
    for alias in aliases:
        key = normalized_arg_key(alias)
        if key in indexed:
            return indexed[key]
    return None


def normalize_output_shape_value(value: Any) -> str:
    """Normalize a directly recorded output-shape value without inferring it."""

    if value is None or isinstance(value, bool):
        return ""
    if isinstance(value, str):
        text = clean_text(value)
        if not text or text.lower() in {"null", "none", "unknown", "n/a", "na"}:
            return ""
        # Profiler versions sometimes serialize a shape array as a string.
        # Parse only JSON containers; arbitrary text remains verbatim evidence.
        if text[0] in "[{":
            try:
                parsed = strict_json_loads(text)
            except (ValueError, json.JSONDecodeError):
                return text
            if parsed is None or isinstance(parsed, bool):
                return ""
            return compact_json(parsed)
        return text
    if isinstance(value, (int, float)):
        # A scalar tensor is represented by [] rather than a bare number. A
        # numeric value under a shape-looking key is too ambiguous to trust.
        return ""
    return compact_json(value)


def output_shape_candidates(
    args: dict[str, Any], source: str
) -> list[tuple[str, str]]:
    aliases = {normalized_arg_key(alias) for alias in OUTPUT_SHAPE_ALIASES}
    output: list[tuple[str, str]] = []
    for key, value in args.items():
        if normalized_arg_key(key) not in aliases:
            continue
        normalized = normalize_output_shape_value(value)
        if normalized:
            output.append((f"{source}.{clean_text(key, 200)}", normalized))
    return output


def resolve_output_shape(
    begin_args: dict[str, Any], paired_end_args: dict[str, Any] | None = None
) -> tuple[str, str, str]:
    """Return normalized shape, direct-evidence locations, and evidence status."""

    if paired_end_args is None:
        candidates = output_shape_candidates(begin_args, "event.args")
        endpoint_shapes = {"event.args": sorted({shape for _, shape in candidates})}
    else:
        begin_candidates = output_shape_candidates(begin_args, "B.args")
        end_candidates = output_shape_candidates(paired_end_args, "E.args")
        candidates = begin_candidates + end_candidates
        endpoint_shapes = {
            "B.args": sorted({shape for _, shape in begin_candidates}),
            "E.args": sorted({shape for _, shape in end_candidates}),
        }
    endpoint_shapes = {key: value for key, value in endpoint_shapes.items() if value}
    unique_shapes = sorted({shape for _, shape in candidates})
    evidence = compact_json(sorted({location for location, _ in candidates}), 16000)
    if not unique_shapes:
        return UNKNOWN_OUTPUT_SHAPE, "", "无直接证据"
    if len(unique_shapes) == 1:
        status = "直接证据"
        if paired_end_args is not None and len(endpoint_shapes) == 2:
            status = "直接证据一致（B/E）"
        return unique_shapes[0], evidence, status
    conflict = clean_text(
        f"冲突（直接 Output Shape 证据不一致：{compact_json(endpoint_shapes, 16000)}）",
        MAX_TEXT_FIELD,
    )
    return conflict, evidence, "直接证据冲突"


class JSONCharReader:
    """Small buffered character reader used to avoid loading a complete trace."""

    def __init__(self, handle: Any, chunk_size: int = 1024 * 1024) -> None:
        self.handle = handle
        self.chunk_size = chunk_size
        self.buffer = ""
        self.position = 0
        self.absolute_position = 0
        self.eof = False

    def _compact(self) -> None:
        if self.position > self.chunk_size and self.position > len(self.buffer) // 2:
            self.buffer = self.buffer[self.position :]
            self.position = 0

    def _fill(self, count: int = 1) -> None:
        while len(self.buffer) - self.position < count and not self.eof:
            self._compact()
            chunk = self.handle.read(self.chunk_size)
            if chunk == "":
                self.eof = True
                break
            self.buffer += chunk

    def peek(self) -> str:
        self._fill(1)
        return self.buffer[self.position] if self.position < len(self.buffer) else ""

    def get(self) -> str:
        char = self.peek()
        if char:
            self.position += 1
            self.absolute_position += 1
        return char

    def skip_ws(self) -> None:
        while self.peek() and self.peek().isspace():
            self.get()

    def expect(self, expected: str) -> None:
        self.skip_ws()
        actual = self.get()
        if actual != expected:
            raise ValueError(
                f"JSON 位置 {self.absolute_position}: 期望 {expected!r}，实际 {actual!r}"
            )

    def read_raw_value(self, capture: bool = True) -> str:
        self.skip_ws()
        first = self.peek()
        if not first:
            raise ValueError(f"JSON 位置 {self.absolute_position}: 意外到达文件末尾")
        # Scalars are captured even in skip mode so json.loads can validate
        # escapes, numbers and literals. Large unknown arrays/objects remain
        # streaming and are structurally validated without materialization.
        effective_capture = capture or first not in "[{"
        output = io.StringIO() if effective_capture else None
        captured_count = 0

        def append(char: str) -> None:
            nonlocal captured_count
            if effective_capture:
                captured_count += len(char)
                if captured_count > MAX_EVENT_JSON_CHARS:
                    raise ValueError("单个 JSON event 超过 64 MiB 安全上限")
                if output is None:
                    raise RuntimeError("内部错误：capture=True 但没有输出缓冲区")
                output.write(char)

        if first in "[{":
            closing_stack: list[str] = []
            in_string = False
            escaped = False
            while True:
                char = self.get()
                if not char:
                    raise ValueError("复合 JSON value 未闭合")
                append(char)
                if in_string:
                    if escaped:
                        escaped = False
                    elif char == "\\":
                        escaped = True
                    elif char == '"':
                        in_string = False
                    continue
                if char == '"':
                    in_string = True
                elif char in "[{":
                    closing_stack.append("}" if char == "{" else "]")
                elif char in "]}":
                    if not closing_stack or char != closing_stack[-1]:
                        raise ValueError(
                            f"JSON 位置 {self.absolute_position}: 容器闭合符 {char!r} 不匹配"
                        )
                    closing_stack.pop()
                    if not closing_stack:
                        break
            return "" if output is None else output.getvalue()

        if first == '"':
            escaped = False
            first_char = True
            while True:
                char = self.get()
                if not char:
                    raise ValueError("JSON string 未闭合")
                append(char)
                if first_char:
                    first_char = False
                elif escaped:
                    escaped = False
                elif char == "\\":
                    escaped = True
                elif char == '"':
                    break
            return "" if output is None else output.getvalue()

        while self.peek() and self.peek() not in ",]}" and not self.peek().isspace():
            append(self.get())
        if captured_count == 0:
            raise ValueError(f"JSON 位置 {self.absolute_position}: value 为空")
        return "" if output is None else output.getvalue()

    def read_value(self) -> Any:
        raw = self.read_raw_value(capture=True)
        if len(raw) > MAX_EVENT_JSON_CHARS:
            raise ValueError("单个 JSON event 超过 64 MiB 安全上限")
        return strict_json_loads(raw)

    def skip_value(self, depth: int = 0) -> None:
        """Validate and discard one JSON value without materializing containers."""
        if depth > 1000:
            raise ValueError("JSON 嵌套超过 1000 层安全上限")
        self.skip_ws()
        first = self.peek()
        if first == "{":
            self.get()
            self.skip_ws()
            if self.peek() == "}":
                self.get()
                return
            while True:
                key = self.read_value()
                if not isinstance(key, str):
                    raise ValueError(f"JSON 位置 {self.absolute_position}: object key 不是字符串")
                self.expect(":")
                self.skip_value(depth + 1)
                self.skip_ws()
                separator = self.get()
                if separator == "}":
                    return
                if separator != ",":
                    raise ValueError(
                        f"JSON 位置 {self.absolute_position}: object member 后期望 ',' 或 '}}'"
                    )
        if first == "[":
            self.get()
            self.skip_ws()
            if self.peek() == "]":
                self.get()
                return
            while True:
                self.skip_value(depth + 1)
                self.skip_ws()
                separator = self.get()
                if separator == "]":
                    return
                if separator != ",":
                    raise ValueError(
                        f"JSON 位置 {self.absolute_position}: array element 后期望 ',' 或 ']'"
                    )
        raw = self.read_raw_value(capture=True)
        strict_json_loads(raw)


def _iter_json_array(reader: JSONCharReader) -> Iterator[Any]:
    reader.expect("[")
    reader.skip_ws()
    if reader.peek() == "]":
        reader.get()
        return
    while True:
        yield reader.read_value()
        reader.skip_ws()
        separator = reader.get()
        if separator == "]":
            return
        if separator != ",":
            raise ValueError(
                f"JSON 位置 {reader.absolute_position}: 数组元素后期望 ',' 或 ']'，实际 {separator!r}"
            )


def iter_trace_events(path: Path) -> Iterator[dict[str, Any]]:
    """Yield Chrome trace events from a top-level array or traceEvents member."""

    with path.open("r", encoding="utf-8-sig", errors="strict") as handle:
        reader = JSONCharReader(handle)
        reader.skip_ws()
        first = reader.peek()
        if first == "[":
            for value in _iter_json_array(reader):
                # Yield an empty placeholder for malformed/non-object elements
                # so enumerate() remains the exact traceEvents array index.
                yield value if isinstance(value, dict) else {}
            reader.skip_ws()
            if reader.peek():
                raise ValueError(
                    f"JSON 位置 {reader.absolute_position}: 顶层数组后存在多余内容"
                )
            return
        if first != "{":
            raise ValueError("trace 必须是顶层 JSON 数组或包含 traceEvents 数组的对象")

        reader.expect("{")
        found = False
        reader.skip_ws()
        if reader.peek() == "}":
            reader.get()
        else:
            while True:
                key = reader.read_value()
                if not isinstance(key, str):
                    raise ValueError("顶层 JSON object 的 key 不是字符串")
                reader.expect(":")
                if key == "traceEvents" and not found:
                    found = True
                    reader.skip_ws()
                    if reader.peek() != "[":
                        raise ValueError("traceEvents 不是 JSON 数组")
                    for value in _iter_json_array(reader):
                        yield value if isinstance(value, dict) else {}
                else:
                    reader.skip_value()
                reader.skip_ws()
                separator = reader.get()
                if separator == "}":
                    break
                if separator != ",":
                    raise ValueError(
                        f"JSON 位置 {reader.absolute_position}: object member 后期望 ',' 或 '}}'"
                    )
        if not found:
            raise ValueError("顶层 JSON object 中没有 traceEvents 数组")
        reader.skip_ws()
        if reader.peek():
            raise ValueError(
                f"JSON 位置 {reader.absolute_position}: 顶层 object 后存在多余内容"
            )


def event_args(event: dict[str, Any]) -> dict[str, Any]:
    value = event.get("args")
    return value if isinstance(value, dict) else {}


def category_tokens(event: dict[str, Any]) -> set[str]:
    raw = clean_text(event.get("cat"), 1000).lower()
    return {part.strip() for part in raw.split(",") if part.strip()}


def classify_pytorch_operator(event: dict[str, Any]) -> tuple[bool, str, str]:
    name = clean_text(event.get("name"), 1000)
    lower_name = name.lower()
    tokens = category_tokens(event)
    is_cpu_op = "cpu_op" in tokens or any(token.endswith(".cpu_op") for token in tokens)

    if not name or SCOPE_PATTERN.search(name):
        return False, "结构 scope/metadata，非具体 operator", ""
    if any(part in token for token in tokens for part in FORBIDDEN_CATEGORY_PARTS) and not is_cpu_op:
        return False, "设备/CANN/runtime 类 category", ""
    if lower_name.startswith(("cann", "acl", "rt", "hccl")) and not is_cpu_op:
        return False, "设备/CANN/runtime 名称", ""

    match = NAMESPACE_PATTERN.match(name)
    namespace = match.group(1) if match else ""
    if namespace.lower() in KNOWN_PYTORCH_NAMESPACES:
        if any("kernel" in token for token in tokens):
            return False, "kernel track 上的 namespace 名称", namespace
        return True, f"PyTorch namespace:{namespace}", namespace
    if is_cpu_op and namespace:
        return True, f"cpu_op custom namespace:{namespace}", namespace
    if is_cpu_op and lower_name in {"record_param_comms"}:
        return True, "cpu_op 特定通信 operator", "c10d"
    return False, "不是可确认的具体 PyTorch cpu_op/namespace", namespace


def normalize_lane_name(value: Any, kind: str) -> str:
    text = clean_text(value, 500).lower()
    if not text:
        return ""
    text = THREAD_ID_PATTERN.sub("thread <id>", text)
    if kind == "process":
        text = re.sub(r"\bpid\s*[:=#-]?\s*\d+\b", "pid <id>", text)
    return SPACE_PATTERN.sub(" ", text).strip()


def lane_key(event: dict[str, Any]) -> tuple[str, str] | None:
    pid = canonical_id(event.get("pid"))
    tid = canonical_id(event.get("tid"))
    return (pid, tid) if pid and tid else None


def selected_arg_fields(
    args: dict[str, Any], paired_end_args: dict[str, Any] | None = None
) -> dict[str, str]:
    input_shapes_value = arg_value(args, "Input Dims", "Input Shapes", "Input Shape")
    input_types_value = arg_value(args, "Input type", "Input types", "Input Data Types")
    input_strides_value = arg_value(args, "Input Strides", "Input stride")
    call_stack_value = arg_value(args, "Call stack", "Call Stack", "Stack")
    module_value = arg_value(args, "Module Hierarchy", "Module", "Module hierarchy")
    output_shapes, output_shape_evidence, output_shape_status = resolve_output_shape(
        args, paired_end_args
    )
    selected = {
        "input_shapes": compact_json(input_shapes_value) or UNKNOWN_INPUT_SHAPE,
        "input_dtypes": compact_json(input_types_value),
        "input_strides": compact_json(input_strides_value),
        "output_shapes": output_shapes,
        "output_shape_evidence": output_shape_evidence,
        "output_shape_status": output_shape_status,
        "call_stack": clean_text(call_stack_value),
        "module_hierarchy": clean_text(module_value),
        "external_id": clean_text(arg_value(args, "External id", "External ID"), 500),
        "record_function_id": clean_text(arg_value(args, "Record function id", "Record Function ID"), 500),
        "sequence_number": clean_text(arg_value(args, "Sequence number", "Sequence Number"), 500),
        "fwd_thread_id": clean_text(arg_value(args, "Fwd thread id", "Forward thread id"), 500),
        "ev_idx": clean_text(arg_value(args, "Ev Idx", "Event Index"), 500),
        "correlation_id": clean_text(arg_value(args, "correlation", "Correlation id", "Correlation ID"), 500),
    }
    selected["args_evidence_sha256"] = stable_hash(
        *[f"{key}={value}" for key, value in sorted(selected.items()) if key != "args_evidence_sha256"]
    )
    return selected


def build_slice(
    event: dict[str, Any],
    environment: str,
    trace_path: Path,
    start_index: int,
    end_index: int | None,
    ph_original: str,
) -> tuple[dict[str, Any] | None, str]:
    pid_hint = canonical_id(event.get("pid")) or "<missing>"
    tid_hint = canonical_id(event.get("tid")) or "<missing>"
    name_hint = clean_text(event.get("name"), 300) or "<missing>"
    end_hint = "" if end_index is None else f",end_index={end_index}"
    context = (
        f"traceEvents[{start_index}{end_hint}] ph={ph_original} "
        f"pid={pid_hint},tid={tid_hint},name={name_hint}"
    )
    key = lane_key(event)
    if key is None:
        return None, f"{context}: duration event 缺少 pid/tid"
    ts = finite_number(event.get("ts"))
    if ph_original == "X":
        duration = finite_number(event.get("dur"))
    else:
        end_ts = finite_number(event.get("_paired_end_ts"))
        duration = None if ts is None or end_ts is None else end_ts - ts
    end_ts = None if ts is None or duration is None else ts + duration
    if (
        ts is None
        or duration is None
        or duration < 0
        or not math.isfinite(duration)
        or end_ts is None
        or not math.isfinite(end_ts)
    ):
        return None, f"{context}: duration event 缺少有效有限 ts/dur、溢出或 B/E 时间反转"

    include, reason, namespace = classify_pytorch_operator(event)
    args = event_args(event)
    paired_end_args = event.get("_paired_end_args") if ph_original == "B/E" else None
    selected = selected_arg_fields(
        args, paired_end_args if isinstance(paired_end_args, dict) else {}
    ) if ph_original == "B/E" else selected_arg_fields(args)
    name = clean_text(event.get("name"), 1000)
    pid, tid = key
    event_id = stable_hash(
        environment,
        pid,
        tid,
        start_index,
        "" if end_index is None else end_index,
        format(ts, ".17g"),
        format(duration, ".17g"),
        name,
        length=20,
    )
    row: dict[str, Any] = {
        "environment": environment,
        "event_id": event_id,
        "source_event_index": start_index,
        "source_end_event_index": "" if end_index is None else end_index,
        "ph_original": ph_original,
        "pid": pid,
        "tid": tid,
        "process_name": "",
        "thread_name": "",
        "category": clean_text(event.get("cat"), 1000),
        "operator": name,
        "operator_namespace": namespace,
        "classification_reason": reason,
        "is_pytorch_operator": include,
        "start_us": ts,
        "duration_us": duration,
        "end_us": end_ts,
        "depth": 0,
        "parent_event_id": "",
        "parent_operator": "",
        "nesting_status": "未计算",
        "self_duration_us": duration,
        **selected,
        "evidence": f"{trace_path}:traceEvents[{start_index}]",
    }
    return row, ""


def _new_lane(pid: str, tid: str) -> dict[str, Any]:
    return {
        "pid": pid,
        "tid": tid,
        "duration_events": 0,
        "pytorch_operator_calls": 0,
        "pytorch_operator_duration_us": 0.0,
        "first_operator_ts_us": None,
        "last_operator_end_us": None,
        "shape_calls": 0,
        "output_shape_calls": 0,
        "stack_calls": 0,
        "invalid_duration_events": 0,
        "operator_counter": Counter(),
    }


def scan_trace(path: Path, environment: str) -> tuple[list[dict[str, Any]], list[str]]:
    lanes: dict[tuple[str, str], dict[str, Any]] = {}
    process_names: dict[str, str] = {}
    thread_names: dict[tuple[str, str], str] = {}
    begin_stacks: dict[tuple[str, str], list[tuple[dict[str, Any], int]]] = defaultdict(list)
    last_ts_by_lane: dict[tuple[str, str], float] = {}
    pids_by_tid: dict[str, set[str]] = defaultdict(set)
    warned_shared_tids: set[str] = set()
    warnings: list[str] = []
    warning_overflow = 0

    def warn(message: str) -> None:
        nonlocal warning_overflow
        if len(warnings) < MAX_WARNINGS:
            warnings.append(message)
        else:
            warning_overflow += 1

    def register(row: dict[str, Any] | None, error: str) -> None:
        if row is None:
            if error:
                warn(error)
            return
        key = (str(row["pid"]), str(row["tid"]))
        lane = lanes.setdefault(key, _new_lane(*key))
        lane["duration_events"] += 1
        if not row["is_pytorch_operator"]:
            return
        lane["pytorch_operator_calls"] += 1
        lane["pytorch_operator_duration_us"] += float(row["duration_us"])
        lane["first_operator_ts_us"] = (
            float(row["start_us"])
            if lane["first_operator_ts_us"] is None
            else min(float(lane["first_operator_ts_us"]), float(row["start_us"]))
        )
        lane["last_operator_end_us"] = (
            float(row["end_us"])
            if lane["last_operator_end_us"] is None
            else max(float(lane["last_operator_end_us"]), float(row["end_us"]))
        )
        if row["input_shapes"] != UNKNOWN_INPUT_SHAPE:
            lane["shape_calls"] += 1
        if row["output_shape_status"] in {"直接证据", "直接证据一致（B/E）"}:
            lane["output_shape_calls"] += 1
        if row["call_stack"]:
            lane["stack_calls"] += 1
        signature = (
            str(row["operator"]),
            str(row["input_shapes"]),
            str(row["output_shapes"]),
        )
        lane["operator_counter"][signature] += 1

    for index, event in enumerate(iter_trace_events(path)):
        ph = clean_text(event.get("ph"), 8)
        if "args" in event and not isinstance(event.get("args"), dict):
            warn(
                f"traceEvents[{index}] ph={ph or '<missing>'} 的 args 不是 object；按空 args 处理"
            )
        key_for_order = lane_key(event)
        if key_for_order is not None:
            pid_for_order, tid_for_order = key_for_order
            pids_by_tid[tid_for_order].add(pid_for_order)
            if len(pids_by_tid[tid_for_order]) > 1 and tid_for_order not in warned_shared_tids:
                warn(
                    f"tid={tid_for_order} 同时出现在多个 pid={sorted(pids_by_tid[tid_for_order])}；lane 始终按 (pid,tid) 区分"
                )
                warned_shared_tids.add(tid_for_order)
            if ph in {"X", "B", "E"}:
                timestamp = finite_number(event.get("ts"))
                previous_timestamp = last_ts_by_lane.get(key_for_order)
                if timestamp is not None:
                    if previous_timestamp is not None and timestamp < previous_timestamp:
                        warn(
                            f"traceEvents[{index}] pid={pid_for_order},tid={tid_for_order} ts={timestamp} "
                            f"小于上一文件序事件 ts={previous_timestamp}；保留原始顺序并标记非单调"
                        )
                    last_ts_by_lane[key_for_order] = timestamp
        if ph == "M":
            name = clean_text(event.get("name"), 200).lower()
            args = event_args(event)
            metadata_name = clean_text(arg_value(args, "name"), 1000)
            pid = canonical_id(event.get("pid"))
            tid = canonical_id(event.get("tid"))
            if name == "process_name" and pid and metadata_name:
                if pid in process_names and process_names[pid] != metadata_name:
                    warn(f"pid={pid} 存在冲突 process_name metadata，采用最后值")
                process_names[pid] = metadata_name
            elif name == "thread_name" and pid and tid and metadata_name:
                key = (pid, tid)
                if key in thread_names and thread_names[key] != metadata_name:
                    warn(f"pid={pid},tid={tid} 存在冲突 thread_name metadata，采用最后值")
                thread_names[key] = metadata_name
            continue

        if ph == "X":
            row, error = build_slice(event, environment, path, index, None, "X")
            register(row, error)
            continue

        if ph == "B":
            key = lane_key(event)
            if key is None:
                warn(f"traceEvents[{index}] B event 缺少 pid/tid")
            else:
                begin_stacks[key].append((event, index))
            continue

        if ph == "E":
            key = lane_key(event)
            if key is None or not begin_stacks.get(key):
                warn(f"traceEvents[{index}] 孤立 E event")
                continue
            begin, begin_index = begin_stacks[key].pop()
            begin = dict(begin)
            begin["_paired_end_ts"] = event.get("ts")
            begin["_paired_end_args"] = event_args(event)
            row, error = build_slice(begin, environment, path, begin_index, index, "B/E")
            register(row, error)

    unclosed = sum(len(stack) for stack in begin_stacks.values())
    if unclosed:
        warn(f"trace 结束时有 {unclosed} 个未闭合 B event；已排除其 timing")
    if warning_overflow:
        warnings.append(f"另有 {warning_overflow} 条重复/额外解析告警未展开")

    inventory: list[dict[str, Any]] = []
    for key, lane in sorted(lanes.items()):
        pid, tid = key
        process_name = process_names.get(pid, "")
        thread_name = thread_names.get(key, "")
        normalized_process = normalize_lane_name(process_name, "process")
        normalized_thread = normalize_lane_name(thread_name, "thread")
        counter: Counter[tuple[str, str, str]] = lane["operator_counter"]
        fingerprint_payload = [
            {
                "operator": op,
                "input_shapes": input_shape,
                "output_shapes": output_shape,
                "calls": calls,
            }
            for (op, input_shape, output_shape), calls in sorted(counter.items())
        ]
        calls = int(lane["pytorch_operator_calls"])
        inventory.append(
            {
                "environment": environment,
                "pid": pid,
                "tid": tid,
                "process_name": process_name,
                "thread_name": thread_name,
                "normalized_process_name": normalized_process,
                "normalized_thread_name": normalized_thread,
                "semantic_lane_key": f"{normalized_process}|{normalized_thread}",
                "duration_events": lane["duration_events"],
                "pytorch_operator_calls": calls,
                "distinct_pytorch_operator_signatures": len(counter),
                "pytorch_operator_duration_us": round(float(lane["pytorch_operator_duration_us"]), 6),
                "first_operator_ts_us": "" if lane["first_operator_ts_us"] is None else lane["first_operator_ts_us"],
                "last_operator_end_us": "" if lane["last_operator_end_us"] is None else lane["last_operator_end_us"],
                "shape_coverage_percent": (
                    round(100.0 * lane["shape_calls"] / calls, 3)
                    if calls
                    else "不可计算（无 PyTorch 算子）"
                ),
                "output_shape_coverage_percent": round(
                    100.0 * lane["output_shape_calls"] / calls, 3
                ) if calls else "不可计算（无 PyTorch 算子）",
                "stack_coverage_percent": (
                    round(100.0 * lane["stack_calls"] / calls, 3)
                    if calls
                    else "不可计算（无 PyTorch 算子）"
                ),
                "operator_fingerprint": stable_hash(compact_json(fingerprint_payload, MAX_EVENT_JSON_CHARS)),
                "operator_multiset": compact_json(fingerprint_payload, 16000),
                "candidate": "是" if calls else "否",
                "reject_reason": "" if calls else "该 process-thread 没有具体 PyTorch cpu_op/namespace slice",
                "_counter": counter,
            }
        )
    return inventory, warnings


def weighted_jaccard(left: Counter[Any], right: Counter[Any]) -> float:
    keys = set(left) | set(right)
    denominator = sum(max(left.get(key, 0), right.get(key, 0)) for key in keys)
    if not denominator:
        return 0.0
    numerator = sum(min(left.get(key, 0), right.get(key, 0)) for key in keys)
    return numerator / denominator


def seeded_lane_hash(seed: int, role: str, row: dict[str, Any]) -> str:
    """Primary semantic hash; deliberately excludes volatile raw PID/TID."""

    return stable_hash(
        SELECTION_ALGORITHM,
        seed,
        role,
        row.get("semantic_lane_key", ""),
        row.get("operator_fingerprint", ""),
    )


def seeded_lane_order(seed: int, role: str, row: dict[str, Any]) -> tuple[str, str]:
    # Raw IDs are used only as an exact-trace tie-break for otherwise
    # indistinguishable semantic lanes; they never choose the semantic group.
    return (
        seeded_lane_hash(seed, role, row),
        stable_hash(SELECTION_ALGORITHM, seed, role, "tie", row.get("pid", ""), row.get("tid", "")),
    )


def semantic_key_is_informative(row: dict[str, Any]) -> bool:
    return bool(row.get("normalized_process_name") or row.get("normalized_thread_name"))


def pair_alignment_components(
    real: dict[str, Any], sim: dict[str, Any]
) -> tuple[float, float, float, float]:
    real_process = str(real.get("normalized_process_name", ""))
    real_thread = str(real.get("normalized_thread_name", ""))
    process_match = 1.0 if real_process and sim.get("normalized_process_name") == real_process else 0.0
    thread_match = 1.0 if real_thread and sim.get("normalized_thread_name") == real_thread else 0.0
    fingerprint = weighted_jaccard(real["_counter"], sim["_counter"])
    total = 0.2 * process_match + 0.3 * thread_match + 0.5 * fingerprint
    return total, process_match, thread_match, fingerprint


def seeded_pair_order(
    seed: int, role: str, real: dict[str, Any], sim: dict[str, Any]
) -> tuple[str, str]:
    primary = stable_hash(
        SELECTION_ALGORITHM,
        seed,
        role,
        real.get("semantic_lane_key", ""),
        real.get("operator_fingerprint", ""),
        sim.get("semantic_lane_key", ""),
        sim.get("operator_fingerprint", ""),
    )
    tie = stable_hash(
        SELECTION_ALGORITHM,
        seed,
        role,
        "tie",
        real.get("pid", ""),
        real.get("tid", ""),
        sim.get("pid", ""),
        sim.get("tid", ""),
    )
    return primary, tie


def explicit_lane(
    candidates: list[dict[str, Any]], pid: str | None, tid: str | None, role: str
) -> dict[str, Any] | None:
    if pid is None and tid is None:
        return None
    if pid is None or tid is None:
        raise ValueError(f"{role}显式线程必须同时提供 pid 和 tid")
    wanted = (canonical_id(pid), canonical_id(tid))
    matches = [row for row in candidates if (row["pid"], row["tid"]) == wanted]
    if not matches:
        raise ValueError(f"{role}未找到 pid={wanted[0]},tid={wanted[1]} 的 PyTorch operator 线程")
    return matches[0]


def choose_thread_pair(
    real_inventory: list[dict[str, Any]],
    sim_inventory: list[dict[str, Any]],
    seed: int,
    real_pid: str | None = None,
    real_tid: str | None = None,
    sim_pid: str | None = None,
    sim_tid: str | None = None,
) -> tuple[dict[str, Any], dict[str, Any], dict[str, Any]]:
    real_candidates = [row for row in real_inventory if row["candidate"] == "是"]
    sim_candidates = [row for row in sim_inventory if row["candidate"] == "是"]
    if not real_candidates:
        raise ValueError("真机 trace 中没有包含具体 PyTorch operator 的 process-thread")
    if not sim_candidates:
        raise ValueError("仿真 trace 中没有包含具体 PyTorch operator 的 process-thread")

    selected_real = explicit_lane(real_candidates, real_pid, real_tid, "真机")
    selected_sim = explicit_lane(sim_candidates, sim_pid, sim_tid, "仿真")
    real_method = "explicit_pid_tid" if selected_real is not None else ""
    sim_method = "explicit_pid_tid" if selected_sim is not None else ""
    common_semantic_group = ""
    common_semantic_group_selection_hash = ""
    selection_audit_steps: list[dict[str, Any]] = []
    if selected_real is not None:
        selection_audit_steps.append(
            {"stage": "real", "role": "explicit_pid_tid", "sort_key": f"{selected_real['pid']}|{selected_real['tid']}"}
        )
    if selected_sim is not None:
        selection_audit_steps.append(
            {"stage": "sim", "role": "explicit_pid_tid", "sort_key": f"{selected_sim['pid']}|{selected_sim['tid']}"}
        )

    # With no explicit lane, choose randomly *within the common semantic
    # process-thread universe*. This prevents a valid common main thread from
    # being hidden by a random unrelated background thread.
    if selected_real is None and selected_sim is None:
        real_keys = {
            str(row["semantic_lane_key"])
            for row in real_candidates
            if semantic_key_is_informative(row)
        }
        sim_keys = {
            str(row["semantic_lane_key"])
            for row in sim_candidates
            if semantic_key_is_informative(row)
        }
        common_keys = sorted(real_keys & sim_keys)
        if common_keys:
            common_semantic_group = min(
                common_keys,
                key=lambda key: stable_hash(SELECTION_ALGORITHM, seed, "common-semantic-group", key),
            )
            common_semantic_group_selection_hash = stable_hash(
                SELECTION_ALGORITHM, seed, "common-semantic-group", common_semantic_group
            )
            selection_audit_steps.append(
                {
                    "stage": "common_semantic_group",
                    "role": "common-semantic-group",
                    "sort_key": common_semantic_group_selection_hash,
                    "selected": common_semantic_group,
                }
            )
            real_group = [row for row in real_candidates if row["semantic_lane_key"] == common_semantic_group]
            sim_group = [row for row in sim_candidates if row["semantic_lane_key"] == common_semantic_group]
            pairs = [(real_row, sim_row) for real_row in real_group for sim_row in sim_group]
            best_similarity = max(
                weighted_jaccard(real_row["_counter"], sim_row["_counter"])
                for real_row, sim_row in pairs
            )
            tied_pairs = [
                (real_row, sim_row)
                for real_row, sim_row in pairs
                if abs(weighted_jaccard(real_row["_counter"], sim_row["_counter"]) - best_similarity)
                <= 1e-12
            ]
            selected_real, selected_sim = min(
                tied_pairs,
                key=lambda pair: seeded_pair_order(seed, "common-group-pair", pair[0], pair[1]),
            )
            pair_order = seeded_pair_order(seed, "common-group-pair", selected_real, selected_sim)
            selection_audit_steps.append(
                {
                    "stage": "common_group_pair",
                    "role": "common-group-pair",
                    "sort_key_primary": pair_order[0],
                    "sort_key_tie": pair_order[1],
                }
            )
            real_method = "sha256_common_semantic_group_then_fingerprint"
            sim_method = "sha256_common_semantic_group_then_fingerprint"
        else:
            selected_real = min(
                real_candidates, key=lambda row: seeded_lane_order(seed, "real-fallback", row)
            )
            real_order = seeded_lane_order(seed, "real-fallback", selected_real)
            selection_audit_steps.append(
                {
                    "stage": "real_fallback",
                    "role": "real-fallback",
                    "sort_key_primary": real_order[0],
                    "sort_key_tie": real_order[1],
                }
            )
            real_method = "sha256_seeded_real_first_no_common_semantic_group"

    # One explicit side acts as the anchor. Otherwise this is the documented
    # real-first fallback used only when there was no common semantic group.
    if selected_real is None:
        if selected_sim is None:
            raise RuntimeError("内部错误：线程选择缺少真机与仿真 anchor")
        scored_real = [
            (pair_alignment_components(real_row, selected_sim)[0], real_row)
            for real_row in real_candidates
        ]
        best_total = max(score for score, _ in scored_real)
        tied_real = [row for score, row in scored_real if abs(score - best_total) <= 1e-12]
        selected_real = min(
            tied_real,
            key=lambda row: seeded_pair_order(seed, "real-align-to-explicit-sim", row, selected_sim),
        )
        real_pair_order = seeded_pair_order(seed, "real-align-to-explicit-sim", selected_real, selected_sim)
        selection_audit_steps.append(
            {
                "stage": "real_align_to_sim",
                "role": "real-align-to-explicit-sim",
                "sort_key_primary": real_pair_order[0],
                "sort_key_tie": real_pair_order[1],
            }
        )
        real_method = "normalized_names_plus_operator_fingerprint_to_explicit_sim"

    if selected_sim is None:
        scored_sim = [
            (pair_alignment_components(selected_real, sim_row)[0], sim_row)
            for sim_row in sim_candidates
        ]
        best_total = max(score for score, _ in scored_sim)
        tied_sim = [row for score, row in scored_sim if abs(score - best_total) <= 1e-12]
        selected_sim = min(
            tied_sim,
            key=lambda row: seeded_pair_order(seed, "sim-align-to-real", selected_real, row),
        )
        sim_pair_order = seeded_pair_order(seed, "sim-align-to-real", selected_real, selected_sim)
        selection_audit_steps.append(
            {
                "stage": "sim_align_to_real",
                "role": "sim-align-to-real",
                "sort_key_primary": sim_pair_order[0],
                "sort_key_tie": sim_pair_order[1],
            }
        )
        sim_method = "normalized_names_plus_operator_fingerprint"

    process_match = bool(
        selected_real["normalized_process_name"]
        and selected_real["normalized_process_name"] == selected_sim["normalized_process_name"]
    )
    thread_match = bool(
        selected_real["normalized_thread_name"]
        and selected_real["normalized_thread_name"] == selected_sim["normalized_thread_name"]
    )
    fingerprint_similarity = weighted_jaccard(selected_real["_counter"], selected_sim["_counter"])
    alignment_score = 0.2 * process_match + 0.3 * thread_match + 0.5 * fingerprint_similarity
    if process_match and thread_match and fingerprint_similarity >= 0.5:
        confidence = "高"
    elif thread_match or fingerprint_similarity >= 0.5:
        confidence = "中"
    else:
        confidence = "低"
    alignment = {
        "selection_algorithm": SELECTION_ALGORITHM,
        "seed": seed,
        "real_selection_method": real_method,
        "sim_selection_method": sim_method,
        "common_semantic_group": common_semantic_group,
        "common_semantic_group_selection_hash": common_semantic_group_selection_hash,
        "selection_audit_steps": selection_audit_steps,
        "selected_pair_fingerprint": stable_hash(
            SELECTION_ALGORITHM,
            selected_real.get("semantic_lane_key", ""),
            selected_real.get("operator_fingerprint", ""),
            selected_sim.get("semantic_lane_key", ""),
            selected_sim.get("operator_fingerprint", ""),
        ),
        "process_name_match": "是" if process_match else "否",
        "thread_name_match": "是" if thread_match else "否",
        "operator_fingerprint_weighted_jaccard": round(fingerprint_similarity, 9),
        "alignment_score": round(alignment_score, 9),
        "alignment_confidence": confidence,
        "timing_warning": "低置信线程对齐不可用于严格逐线程时间保真度结论" if confidence == "低" else "",
    }
    return selected_real, selected_sim, alignment


def extract_selected_thread(
    path: Path,
    environment: str,
    selected: dict[str, Any],
) -> tuple[list[dict[str, Any]], list[str]]:
    wanted = (str(selected["pid"]), str(selected["tid"]))
    begin_stack: list[tuple[dict[str, Any], int]] = []
    rows: list[dict[str, Any]] = []
    warnings: list[str] = []
    warning_overflow = 0
    last_timestamp: float | None = None

    def warn(message: str) -> None:
        nonlocal warning_overflow
        if len(warnings) < MAX_WARNINGS:
            warnings.append(message)
        else:
            warning_overflow += 1

    def retain(row: dict[str, Any] | None, error: str) -> None:
        if row is None:
            if error:
                warn(error)
            return
        if not row["is_pytorch_operator"]:
            return
        row["process_name"] = selected["process_name"]
        row["thread_name"] = selected["thread_name"]
        row.pop("is_pytorch_operator", None)
        rows.append(row)

    for index, event in enumerate(iter_trace_events(path)):
        if lane_key(event) != wanted:
            continue
        ph = clean_text(event.get("ph"), 8)
        if "args" in event and not isinstance(event.get("args"), dict):
            warn(
                f"选中线程 traceEvents[{index}] ph={ph or '<missing>'} 的 args 不是 object；按空 args 处理"
            )
        if ph in {"X", "B", "E"}:
            timestamp = finite_number(event.get("ts"))
            if timestamp is not None:
                if last_timestamp is not None and timestamp < last_timestamp:
                    warn(
                        f"选中线程 traceEvents[{index}] ts={timestamp} 小于上一文件序事件 "
                        f"ts={last_timestamp}；保留原始顺序并标记非单调"
                    )
                last_timestamp = timestamp
        if ph == "X":
            row, error = build_slice(event, environment, path, index, None, "X")
            retain(row, error)
        elif ph == "B":
            begin_stack.append((event, index))
        elif ph == "E":
            if not begin_stack:
                warn(f"选中线程 traceEvents[{index}] 孤立 E event")
                continue
            begin, begin_index = begin_stack.pop()
            begin = dict(begin)
            begin["_paired_end_ts"] = event.get("ts")
            begin["_paired_end_args"] = event_args(event)
            row, error = build_slice(begin, environment, path, begin_index, index, "B/E")
            retain(row, error)

    if begin_stack:
        warn(f"选中线程有 {len(begin_stack)} 个未闭合 B event；已排除")
    if warning_overflow:
        warnings.append(f"另有 {warning_overflow} 条重复/额外选中线程告警未展开")
    assign_nesting_and_self_time(rows)
    return rows, warnings


def intervals_overlap(left: dict[str, Any], right: dict[str, Any]) -> bool:
    return float(left["start_us"]) < float(right["end_us"]) and float(right["start_us"]) < float(left["end_us"])


def strictly_contains(parent: dict[str, Any], child: dict[str, Any]) -> bool:
    parent_start = float(parent["start_us"])
    parent_end = float(parent["end_us"])
    child_start = float(child["start_us"])
    child_end = float(child["end_us"])
    if parent_start > child_start or parent_end < child_end:
        return False
    if parent_start < child_start or parent_end > child_end:
        return True
    # Equal-boundary X slices do not encode nesting and must stay ambiguous.
    # For B/E slices, event-stack order supplies the missing structural fact.
    if parent.get("ph_original") != "B/E" or child.get("ph_original") != "B/E":
        return False
    try:
        return (
            int(parent["source_event_index"]) < int(child["source_event_index"])
            and int(parent["source_end_event_index"]) > int(child["source_end_event_index"])
        )
    except (TypeError, ValueError):
        return False


def union_length(intervals: list[tuple[float, float]], lower: float, upper: float) -> float:
    clipped = sorted((max(lower, start), min(upper, end)) for start, end in intervals if end > lower and start < upper)
    total = 0.0
    current_start: float | None = None
    current_end: float | None = None
    for start, end in clipped:
        if end <= start:
            continue
        if current_start is None:
            current_start, current_end = start, end
        elif start <= float(current_end):
            current_end = max(float(current_end), end)
        else:
            total += float(current_end) - float(current_start)
            current_start, current_end = start, end
    if current_start is not None:
        total += float(current_end) - float(current_start)
    return total


def assign_nesting_and_self_time(rows: list[dict[str, Any]]) -> None:
    rows.sort(
        key=lambda row: (
            float(row["start_us"]),
            -float(row["duration_us"]),
            int(row["source_event_index"]),
        )
    )
    active: list[dict[str, Any]] = []
    children: dict[str, list[dict[str, Any]]] = defaultdict(list)
    for ordinal, row in enumerate(rows, start=1):
        row["event_ordinal"] = ordinal
        active = [item for item in active if float(item["end_us"]) > float(row["start_us"])]
        containers = [item for item in active if strictly_contains(item, row)]
        crossings = [item for item in active if intervals_overlap(item, row) and not strictly_contains(item, row)]
        if containers:
            parent = min(containers, key=lambda item: (float(item["duration_us"]), -int(item["source_event_index"])))
            row["parent_event_id"] = parent["event_id"]
            row["parent_operator"] = parent["operator"]
            row["depth"] = int(parent["depth"]) + 1
            row["nesting_status"] = "nested" if not crossings else "nested_with_crossing_overlap"
            children[parent["event_id"]].append(row)
        else:
            row["depth"] = 0
            row["nesting_status"] = "crossing_overlap" if crossings else "root"
        active.append(row)

    for row in rows:
        child_intervals = [
            (float(child["start_us"]), float(child["end_us"]))
            for child in children.get(str(row["event_id"]), [])
        ]
        covered = union_length(child_intervals, float(row["start_us"]), float(row["end_us"]))
        row["self_duration_us"] = round(max(0.0, float(row["duration_us"]) - covered), 9)
        for field in ("start_us", "duration_us", "end_us"):
            row[field] = round(float(row[field]), 9)


def summarize_events(rows: list[dict[str, Any]]) -> list[dict[str, Any]]:
    grouped: dict[tuple[str, str, str], list[dict[str, Any]]] = defaultdict(list)
    for row in rows:
        grouped[
            (
                str(row["operator"]),
                str(row["input_shapes"]),
                str(row["output_shapes"]),
            )
        ].append(row)
    output: list[dict[str, Any]] = []
    for (operator, input_shape, output_shape), values in grouped.items():
        durations = [float(row["duration_us"]) for row in values]
        self_durations = [float(row["self_duration_us"]) for row in values]
        stack_values = [str(row["call_stack"]) for row in values if row.get("call_stack")]
        output_evidence = sorted(
            {str(row["output_shape_evidence"]) for row in values if row.get("output_shape_evidence")}
        )
        output_statuses = Counter(str(row["output_shape_status"]) for row in values)
        output.append(
            {
                "environment": values[0]["environment"],
                "pid": values[0]["pid"],
                "tid": values[0]["tid"],
                "process_name": values[0]["process_name"],
                "thread_name": values[0]["thread_name"],
                "operator": operator,
                "operator_namespace": values[0]["operator_namespace"],
                "input_shapes": input_shape,
                "output_shapes": output_shape,
                "output_shape_status_counts": compact_json(dict(sorted(output_statuses.items()))),
                "output_shape_evidence": compact_json(output_evidence, 16000),
                "calls": len(values),
                "inclusive_us_total": round(sum(durations), 9),
                "inclusive_us_avg": round(sum(durations) / len(values), 9),
                "inclusive_us_max": round(max(durations), 9),
                "self_us_total": round(sum(self_durations), 9),
                "self_us_avg": round(sum(self_durations) / len(values), 9),
                "self_us_max": round(max(self_durations), 9),
                "first_start_us": min(float(row["start_us"]) for row in values),
                "last_end_us": max(float(row["end_us"]) for row in values),
                "stack_coverage_percent": round(100.0 * len(stack_values) / len(values), 3),
                "call_stack_sample": stack_values[0] if stack_values else "",
                "event_ids": compact_json([row["event_id"] for row in values], 16000),
            }
        )
    return sorted(output, key=lambda row: (float(row["self_us_total"]), float(row["inclusive_us_total"])), reverse=True)


def ratio(real: float | None, sim: float | None) -> tuple[Any, Any, Any]:
    if real is None or sim is None:
        return "不可计算", "不可计算", "不可计算"
    delta = sim - real
    if real == 0:
        return round(delta, 9), "不可计算（真机为0）", "不可计算（真机为0）"
    return round(delta, 9), round(sim / real, 9), round(100.0 * delta / real, 6)


def compare_summaries(real: list[dict[str, Any]], sim: list[dict[str, Any]]) -> list[dict[str, Any]]:
    left = {
        (str(row["operator"]), str(row["input_shapes"]), str(row["output_shapes"])): row
        for row in real
    }
    right = {
        (str(row["operator"]), str(row["input_shapes"]), str(row["output_shapes"])): row
        for row in sim
    }
    output: list[dict[str, Any]] = []
    metrics = [
        "calls",
        "inclusive_us_total",
        "inclusive_us_avg",
        "inclusive_us_max",
        "self_us_total",
        "self_us_avg",
        "self_us_max",
    ]
    for key in sorted(set(left) | set(right)):
        real_row = left.get(key)
        sim_row = right.get(key)
        row: dict[str, Any] = {
            "operator": key[0],
            "input_shapes": key[1],
            "output_shapes": key[2],
            "presence": "两侧存在" if real_row and sim_row else ("仅真机" if real_row else "仅仿真"),
            "real_output_shape_status_counts": real_row.get("output_shape_status_counts", "{}") if real_row else "{}",
            "sim_output_shape_status_counts": sim_row.get("output_shape_status_counts", "{}") if sim_row else "{}",
            "real_output_shape_evidence": real_row.get("output_shape_evidence", "[]") if real_row else "[]",
            "sim_output_shape_evidence": sim_row.get("output_shape_evidence", "[]") if sim_row else "[]",
            "real_call_stack_sample": real_row.get("call_stack_sample", "") if real_row else "",
            "sim_call_stack_sample": sim_row.get("call_stack_sample", "") if sim_row else "",
            "real_event_ids": real_row.get("event_ids", "[]") if real_row else "[]",
            "sim_event_ids": sim_row.get("event_ids", "[]") if sim_row else "[]",
        }
        for metric in metrics:
            real_value = finite_number(real_row.get(metric)) if real_row else None
            sim_value = finite_number(sim_row.get(metric)) if sim_row else None
            delta, quotient, percent = ratio(real_value, sim_value)
            row[f"real_{metric}"] = "缺失" if real_value is None else real_value
            row[f"sim_{metric}"] = "缺失" if sim_value is None else sim_value
            row[f"{metric}_sim_minus_real"] = delta
            row[f"{metric}_sim_over_real"] = quotient
            row[f"{metric}_delta_percent"] = percent
        output.append(row)
    return sorted(
        output,
        key=lambda row: max(
            finite_number(row.get("real_self_us_total")) or 0.0,
            finite_number(row.get("sim_self_us_total")) or 0.0,
        ),
        reverse=True,
    )


def sequence_runs(rows: list[dict[str, Any]]) -> list[dict[str, Any]]:
    result: list[dict[str, Any]] = []
    for row in sorted(rows, key=lambda item: int(item["event_ordinal"])):
        key = f"{row['operator']}\x1e{row['input_shapes']}\x1e{row['output_shapes']}"
        if result and result[-1]["key"] == key:
            result[-1]["end_ordinal"] = row["event_ordinal"]
            result[-1]["calls"] += 1
            result[-1]["end_us"] = max(float(result[-1]["end_us"]), float(row["end_us"]))
        else:
            result.append(
                {
                    "key": key,
                    "operator": row["operator"],
                    "input_shapes": row["input_shapes"],
                    "output_shapes": row["output_shapes"],
                    "start_ordinal": row["event_ordinal"],
                    "end_ordinal": row["event_ordinal"],
                    "calls": 1,
                    "start_us": row["start_us"],
                    "end_us": row["end_us"],
                }
            )
    return result


def sequence_diff(real_events: list[dict[str, Any]], sim_events: list[dict[str, Any]]) -> tuple[list[dict[str, Any]], str]:
    real = sequence_runs(real_events)
    sim = sequence_runs(sim_events)
    mode = "rle_sequence_matcher"
    if len(real) > MAX_SEQUENCE_RUNS or len(sim) > MAX_SEQUENCE_RUNS:
        mode = "rle_ordinal_fallback_due_to_size"
        opcodes = [("replace", 0, len(real), 0, len(sim))]
    else:
        matcher = difflib.SequenceMatcher(
            a=[row["key"] for row in real],
            b=[row["key"] for row in sim],
            autojunk=False,
        )
        opcodes = matcher.get_opcodes()
    output: list[dict[str, Any]] = []
    diff_index = 0
    for tag, i1, i2, j1, j2 in opcodes:
        size = max(i2 - i1, j2 - j1)
        for offset in range(size):
            left = real[i1 + offset] if i1 + offset < i2 else None
            right = sim[j1 + offset] if j1 + offset < j2 else None
            diff_index += 1
            output.append(
                {
                    "diff_index": diff_index,
                    "match_type": tag,
                    "real_run_index": "" if left is None else i1 + offset + 1,
                    "real_operator": "" if left is None else left["operator"],
                    "real_input_shapes": "" if left is None else left["input_shapes"],
                    "real_output_shapes": "" if left is None else left["output_shapes"],
                    "real_calls_in_run": 0 if left is None else left["calls"],
                    "real_start_ordinal": "" if left is None else left["start_ordinal"],
                    "real_end_ordinal": "" if left is None else left["end_ordinal"],
                    "sim_run_index": "" if right is None else j1 + offset + 1,
                    "sim_operator": "" if right is None else right["operator"],
                    "sim_input_shapes": "" if right is None else right["input_shapes"],
                    "sim_output_shapes": "" if right is None else right["output_shapes"],
                    "sim_calls_in_run": 0 if right is None else right["calls"],
                    "sim_start_ordinal": "" if right is None else right["start_ordinal"],
                    "sim_end_ordinal": "" if right is None else right["end_ordinal"],
                }
            )
    return output, mode


def add_segment_to_bins(
    accumulator: dict[tuple[int, str, str, str], float],
    start: float,
    end: float,
    lane_start: float,
    lane_end: float,
    bins: int,
    operator: str,
    input_shape: str,
    output_shape: str,
) -> None:
    if end <= start or lane_end <= lane_start:
        return
    width = (lane_end - lane_start) / bins
    cursor = max(start, lane_start)
    final = min(end, lane_end)
    while cursor < final:
        index = min(bins - 1, max(0, int((cursor - lane_start) / width)))
        boundary = lane_start + (index + 1) * width
        segment_end = min(final, boundary)
        if segment_end <= cursor:
            break
        accumulator[(index, operator, input_shape, output_shape)] += segment_end - cursor
        cursor = segment_end


def build_heatmap(rows: list[dict[str, Any]], bins: int) -> list[dict[str, Any]]:
    environment = str(rows[0]["environment"]) if rows else ""
    if not rows:
        return []
    lane_start = min(float(row["start_us"]) for row in rows)
    lane_end = max(float(row["end_us"]) for row in rows)
    if lane_end <= lane_start:
        lane_end = lane_start + 1.0
    width = (lane_end - lane_start) / bins

    points: dict[float, dict[str, list[int]]] = defaultdict(lambda: {"start": [], "end": []})
    for index, row in enumerate(rows):
        if float(row["duration_us"]) <= 0:
            continue
        points[float(row["start_us"])]["start"].append(index)
        points[float(row["end_us"])]["end"].append(index)
    active: set[int] = set()
    heap: list[tuple[int, float, float, int, int]] = []
    deepest: dict[tuple[int, str, str, str], float] = defaultdict(float)
    inclusive: dict[tuple[int, str, str, str], float] = defaultdict(float)
    previous: float | None = None

    def selected_index() -> int | None:
        while heap and heap[0][4] not in active:
            heapq.heappop(heap)
        return heap[0][4] if heap else None

    for timestamp in sorted(points):
        if previous is not None and timestamp > previous:
            selected_index_value = selected_index()
            if selected_index_value is None:
                operator, input_shape, output_shape = "<未归属>", "", ""
            else:
                selected_row = rows[selected_index_value]
                operator = str(selected_row["operator"])
                input_shape = str(selected_row["input_shapes"])
                output_shape = str(selected_row["output_shapes"])
            add_segment_to_bins(
                deepest,
                previous,
                timestamp,
                lane_start,
                lane_end,
                bins,
                operator,
                input_shape,
                output_shape,
            )
        for index in points[timestamp]["end"]:
            active.discard(index)
        for index in points[timestamp]["start"]:
            active.add(index)
            row = rows[index]
            heapq.heappush(
                heap,
                (
                    -int(row["depth"]),
                    float(row["duration_us"]),
                    -float(row["start_us"]),
                    int(row["source_event_index"]),
                    index,
                ),
            )
        previous = timestamp

    calls: Counter[tuple[int, str, str, str]] = Counter()
    for row in rows:
        start = max(lane_start, float(row["start_us"]))
        end = min(lane_end, float(row["end_us"]))
        if end <= start:
            continue
        add_segment_to_bins(
            inclusive,
            start,
            end,
            lane_start,
            lane_end,
            bins,
            str(row["operator"]),
            str(row["input_shapes"]),
            str(row["output_shapes"]),
        )
        first = min(bins - 1, max(0, int((start - lane_start) / width)))
        last_probe = math.nextafter(end, -math.inf)
        last = min(bins - 1, max(0, int((last_probe - lane_start) / width)))
        for index in range(first, last + 1):
            calls[
                (
                    index,
                    str(row["operator"]),
                    str(row["input_shapes"]),
                    str(row["output_shapes"]),
                )
            ] += 1

    crossing = any("crossing" in str(row["nesting_status"]) for row in rows)
    keys_by_bin: dict[int, set[tuple[int, str, str, str]]] = defaultdict(set)
    for key in set(deepest) | set(inclusive) | set(calls):
        keys_by_bin[key[0]].add(key)
    output: list[dict[str, Any]] = []
    for index in range(bins):
        bin_start = lane_start + index * width
        bin_end = lane_end if index == bins - 1 else lane_start + (index + 1) * width
        bin_duration = bin_end - bin_start
        entries = [(key, deepest.get(key, 0.0)) for key in sorted(keys_by_bin.get(index, set()))]
        assigned = sum(duration for _, duration in entries)
        if assigned < bin_duration - 1e-9:
            key = (index, "<未归属>", "", "")
            entries.append((key, bin_duration - assigned))
        # Floating point noise must never make one bin exceed 100%.
        scale = min(1.0, bin_duration / assigned) if assigned > bin_duration and assigned > 0 else 1.0
        adjusted = [(key, max(0.0, duration * scale)) for key, duration in entries]
        dominant_key = max(adjusted, key=lambda item: item[1])[0] if adjusted else None
        ordered_entries = sorted(adjusted, key=lambda item: item[1], reverse=True)
        remaining_percent = 100.0
        for key, duration in ordered_entries:
            _, operator, input_shape, output_shape = key
            raw_share = 100.0 * duration / bin_duration if bin_duration > 0 else 0.0
            # Round sequentially against a remaining budget so serialized rows
            # can never add up to more than 100%, even through decimal noise.
            share = min(remaining_percent, round(min(100.0, max(0.0, raw_share)), 6))
            share = max(0.0, share)
            remaining_percent = max(0.0, round(remaining_percent - share, 6))
            output.append(
                {
                    "environment": environment,
                    "bin_index": index,
                    "normalized_start": round(index / bins, 9),
                    "normalized_end": round((index + 1) / bins, 9),
                    "bin_start_us": round(bin_start, 9),
                    "bin_end_us": round(bin_end, 9),
                    "bin_duration_us": round(bin_duration, 9),
                    "operator": operator,
                    "input_shapes": input_shape,
                    "output_shapes": output_shape,
                    "call_count_overlapping": calls.get(key, 0),
                    "inclusive_overlap_us": round(inclusive.get(key, 0.0), 9),
                    "deepest_exclusive_us": round(duration, 9),
                    "exclusive_us": round(duration, 9),
                    "share_of_bin_percent": share,
                    "share_of_bin": share,
                    "is_dominant": "是" if key == dominant_key else "否",
                    "nesting_status": "含交叉区间；deepest tie-break 已记录" if crossing else "规范/可嵌套",
                }
            )
    return output


def public_inventory(rows: list[dict[str, Any]]) -> list[dict[str, Any]]:
    return [{key: value for key, value in row.items() if not key.startswith("_")} for row in rows]


def write_csv(path: Path, rows: Iterable[dict[str, Any]], fields: list[str] | None = None) -> None:
    materialized = list(rows)
    path.parent.mkdir(parents=True, exist_ok=True)
    if fields is None:
        fields = []
        seen: set[str] = set()
        for row in materialized:
            for key in row:
                if key not in seen:
                    seen.add(key)
                    fields.append(key)
        if not fields:
            fields = THREAD_ARTIFACT_FIELDS.get(path.stem, ["message"])
    with path.open("w", newline="", encoding="utf-8-sig") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields, extrasaction="ignore")
        writer.writeheader()
        writer.writerows(materialized)


def write_json(path: Path, value: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8") as handle:
        json.dump(value, handle, ensure_ascii=False, indent=2)


def selection_rows(
    real: dict[str, Any], sim: dict[str, Any], alignment: dict[str, Any]
) -> list[dict[str, Any]]:
    output = []
    for row, role in ((real, "real/reference/真机"), (sim, "sim/candidate/仿真")):
        output.append(
            {
                "environment": role,
                "pid": row["pid"],
                "tid": row["tid"],
                "process_name": row["process_name"],
                "thread_name": row["thread_name"],
                "normalized_process_name": row["normalized_process_name"],
                "normalized_thread_name": row["normalized_thread_name"],
                "pytorch_operator_calls": row["pytorch_operator_calls"],
                "distinct_pytorch_operator_signatures": row["distinct_pytorch_operator_signatures"],
                "operator_fingerprint": row["operator_fingerprint"],
                "selection_algorithm": alignment["selection_algorithm"],
                "seed": alignment["seed"],
                "selection_method": alignment["real_selection_method"] if role.startswith("real") else alignment["sim_selection_method"],
                "selection_audit_steps": compact_json(alignment["selection_audit_steps"], 16000),
                "selected_pair_fingerprint": alignment["selected_pair_fingerprint"],
                "alignment_score": alignment["alignment_score"],
                "alignment_confidence": alignment["alignment_confidence"],
                "process_name_match": alignment["process_name_match"],
                "thread_name_match": alignment["thread_name_match"],
                "operator_fingerprint_weighted_jaccard": alignment["operator_fingerprint_weighted_jaccard"],
                "timing_warning": alignment["timing_warning"],
            }
        )
    return output


def html_heatmap_table(environment: str, heatmap: list[dict[str, Any]], max_operators: int = 40) -> str:
    rows = [row for row in heatmap if row["environment"] == environment]
    if not rows:
        return "<p>没有可渲染的 operator 事件。</p>"
    bins = 1 + max(int(row["bin_index"]) for row in rows)
    totals: Counter[tuple[str, str, str]] = Counter()
    values: dict[tuple[str, str, str, int], float] = defaultdict(float)
    calls: Counter[tuple[str, str, str, int]] = Counter()
    for row in rows:
        op_key = (
            str(row["operator"]),
            str(row["input_shapes"]),
            str(row["output_shapes"]),
        )
        duration = float(row["deepest_exclusive_us"])
        totals[op_key] += duration
        key = (*op_key, int(row["bin_index"]))
        values[key] += float(row["share_of_bin_percent"])
        calls[key] += int(row["call_count_overlapping"])
    ordered = [key for key, _ in totals.most_common(max_operators)]
    header = "".join(f"<th title='归一化时间桶 {index}'>B{index}</th>" for index in range(bins))
    body = []
    for operator, input_shape, output_shape in ordered:
        cells = []
        for index in range(bins):
            share = min(100.0, values.get((operator, input_shape, output_shape, index), 0.0))
            alpha = 0.04 + 0.86 * share / 100.0
            label = (
                f"{operator}；input={input_shape}；output={output_shape}；bin={index}；"
                f"deepest/exclusive={share:.3f}%；overlap calls="
                f"{calls.get((operator, input_shape, output_shape, index), 0)}"
            )
            visible = f"{share:.0f}" if share >= 5 else ""
            cells.append(
                f"<td style='background:rgba(239,108,64,{alpha:.3f})' title='{html.escape(label, quote=True)}' "
                f"aria-label='{html.escape(label, quote=True)}' data-share='{share:.6f}'>{visible}</td>"
            )
        body.append(
            "<tr><th class='op' title='{}'>{}<small>{}</small></th>{}</tr>".format(
                html.escape(f"input={input_shape}; output={output_shape}", quote=True),
                html.escape(operator),
                html.escape(f"输入：{input_shape}；输出：{output_shape}"),
                "".join(cells),
            )
        )
    return f"<div class='scroll'><table class='heatmap'><thead><tr><th>Operator / Input / Output Shape</th>{header}</tr></thead><tbody>{''.join(body)}</tbody></table></div>"


def summary_html_table(environment: str, summaries: list[dict[str, Any]]) -> str:
    rows = [row for row in summaries if row["environment"] == environment][:20]
    body = "".join(
        "<tr><td>{}</td><td class='mono'>{}</td><td class='mono'>{}</td><td>{}</td><td>{:.3f}</td><td>{:.3f}</td></tr>".format(
            html.escape(str(row["operator"])),
            html.escape(str(row["input_shapes"])),
            html.escape(str(row["output_shapes"])),
            row["calls"],
            float(row["self_us_total"]),
            float(row["inclusive_us_total"]),
        )
        for row in rows
    )
    return (
        "<table class='summary'><thead><tr><th>Operator</th><th>Input Shape</th><th>Output Shape</th><th>Calls</th>"
        "<th>Self μs</th><th>Inclusive μs</th></tr></thead><tbody>" + body + "</tbody></table>"
    )


def build_html(
    selections: list[dict[str, Any]], summaries: list[dict[str, Any]], heatmap: list[dict[str, Any]]
) -> str:
    selection_body = "".join(
        "<tr><td>{}</td><td>{}/{}</td><td>{}</td><td>{}</td><td>{}</td><td>{:.4f}</td></tr>".format(
            html.escape(str(row["environment"])),
            html.escape(str(row["pid"])),
            html.escape(str(row["tid"])),
            html.escape(str(row["process_name"] or "未知")),
            html.escape(str(row["thread_name"] or "未知")),
            html.escape(str(row["alignment_confidence"])),
            float(row["alignment_score"]),
        )
        for row in selections
    )
    sections = []
    for environment, title in (("real/reference/真机", "真机 / reference"), ("sim/candidate/仿真", "仿真 / candidate")):
        sections.append(
            f"<section><h2>{title}</h2><p>颜色表示每个归一化时间桶中由最深层 PyTorch operator 占用的 exclusive 比例；"
            "同一时间段只归属一个 operator，因此单个 bin 的总占用不超过 100%。</p>"
            f"{html_heatmap_table(environment, heatmap)}<h3>Operator 汇总（按 Self 时间）</h3>"
            f"{summary_html_table(environment, summaries)}</section>"
        )
    return f"""<!doctype html>
<html lang="zh-CN"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>单 Rank / Process-Thread PyTorch Operator 热力图</title>
<style>
:root{{--bg:#0d1117;--panel:#161b22;--fg:#e6edf3;--muted:#9da7b3;--line:#30363d;--accent:#ef6c40}}
*{{box-sizing:border-box}} body{{margin:0;background:var(--bg);color:var(--fg);font:14px/1.5 system-ui,-apple-system,"Segoe UI",sans-serif}}
main{{max-width:1600px;margin:auto;padding:24px}} h1,h2,h3{{font-weight:650}} p{{color:var(--muted)}} section{{margin:24px 0;padding:18px;background:var(--panel);border:1px solid var(--line);border-radius:10px}}
table{{border-collapse:collapse;width:100%}} th,td{{border:1px solid var(--line);padding:5px 7px;text-align:right}} th{{background:#21262d}} .op{{position:sticky;left:0;z-index:2;min-width:260px;text-align:left}} .op small{{display:block;color:var(--muted);max-width:420px;overflow:hidden;text-overflow:ellipsis}}
.scroll{{overflow:auto;max-height:760px}} .heatmap td{{min-width:31px;height:25px;text-align:center;font-size:10px}} .summary td:first-child,.summary td:nth-child(2){{text-align:left}} .mono{{font-family:ui-monospace,SFMono-Regular,Consolas,monospace;max-width:520px;overflow-wrap:anywhere}}
.note{{padding:10px;border-left:3px solid var(--accent);background:#211713}}
</style></head><body><main>
<h1>单 Rank / Process-Thread PyTorch Operator 热力图</h1>
<p class="note">方向固定为：差值 = 仿真 - 真机；比率 = 仿真 / 真机。PyTorch 输出 Shape 仅采用 operator args 的直接证据；缺失保持未知，且不从 kernel 猜测。</p>
<section><h2>被选线程与对齐</h2><table><thead><tr><th>环境</th><th>PID/TID</th><th>Process</th><th>Thread</th><th>对齐置信度</th><th>Score</th></tr></thead><tbody>{selection_body}</tbody></table></section>
{''.join(sections)}
</main></body></html>"""


def analyze_pair(
    real_trace: Path,
    sim_trace: Path,
    output: Path,
    seed: int,
    heatmap_bins: int,
    real_pid: str | None = None,
    real_tid: str | None = None,
    sim_pid: str | None = None,
    sim_tid: str | None = None,
) -> dict[str, Any]:
    real_inventory, real_scan_warnings = scan_trace(real_trace, "real/reference/真机")
    sim_inventory, sim_scan_warnings = scan_trace(sim_trace, "sim/candidate/仿真")
    real_candidate_count = sum(row["candidate"] == "是" for row in real_inventory)
    sim_candidate_count = sum(row["candidate"] == "是" for row in sim_inventory)
    if not real_candidate_count or not sim_candidate_count:
        missing_sides = []
        if not real_candidate_count:
            missing_sides.append("真机")
        if not sim_candidate_count:
            missing_sides.append("仿真")
        reason = "、".join(missing_sides) + " trace 没有具体 PyTorch operator process-thread 候选"
        output.mkdir(parents=True, exist_ok=True)
        artifacts: dict[str, Any] = {
            "trace_thread_inventory": public_inventory(real_inventory) + public_inventory(sim_inventory),
            "selected_thread_pair": [],
            "selected_thread_operator_events": [],
            "selected_thread_operator_summary": [],
            "selected_thread_operator_comparison": [],
            "selected_thread_sequence_diff": [],
            "selected_thread_operator_heatmap": [],
        }
        for name, value in artifacts.items():
            write_csv(output / f"{name}.csv", value, THREAD_ARTIFACT_FIELDS[name])
            write_json(output / f"{name}.json", value)
        (output / "operator_heatmap.html").write_text(
            build_html([], [], []), encoding="utf-8"
        )
        manifest = {
            "schema_version": SCHEMA_VERSION,
            "status": "受限",
            "language": "zh-CN",
            "roles": {"real": "reference/真机", "sim": "candidate/仿真"},
            "difference_direction": "sim - real",
            "ratio_direction": "sim / real",
            "real_trace": str(real_trace.resolve()),
            "sim_trace": str(sim_trace.resolve()),
            "real_trace_sha256": file_sha256(real_trace),
            "sim_trace_sha256": file_sha256(sim_trace),
            "selection": {
                "selection_algorithm": SELECTION_ALGORITHM,
                "seed": seed,
                "real_candidate_count": real_candidate_count,
                "sim_candidate_count": sim_candidate_count,
                "alignment_confidence": "unaligned",
            },
            "reason": reason,
            "impact": "线程算子序列、热力图、逐线程源码映射和 Perfetto 视觉复核均不可执行；缺失不等于零事件",
            "heatmap_bins": heatmap_bins,
            "warnings": {"real_scan": real_scan_warnings, "sim_scan": sim_scan_warnings},
            "counts": {name: len(value) for name, value in artifacts.items()},
            "output_shape_policy": "无所选 PyTorch 线程；不从 kernel 反推输出 Shape",
            "self_time_policy": "无所选 PyTorch 线程；不生成伪造时间值",
        }
        write_json(output / "trace_thread_analysis_manifest.json", manifest)
        return manifest
    selected_real, selected_sim, alignment = choose_thread_pair(
        real_inventory,
        sim_inventory,
        seed,
        real_pid,
        real_tid,
        sim_pid,
        sim_tid,
    )
    real_events, real_extract_warnings = extract_selected_thread(
        real_trace, "real/reference/真机", selected_real
    )
    sim_events, sim_extract_warnings = extract_selected_thread(
        sim_trace, "sim/candidate/仿真", selected_sim
    )
    real_summary = summarize_events(real_events)
    sim_summary = summarize_events(sim_events)
    comparison = compare_summaries(real_summary, sim_summary)
    diff, sequence_mode = sequence_diff(real_events, sim_events)
    heatmap = build_heatmap(real_events, heatmap_bins) + build_heatmap(sim_events, heatmap_bins)
    inventory = public_inventory(real_inventory) + public_inventory(sim_inventory)
    selections = selection_rows(selected_real, selected_sim, alignment)
    events = real_events + sim_events
    summaries = real_summary + sim_summary

    output.mkdir(parents=True, exist_ok=True)
    artifacts: dict[str, Any] = {
        "trace_thread_inventory": inventory,
        "selected_thread_pair": selections,
        "selected_thread_operator_events": events,
        "selected_thread_operator_summary": summaries,
        "selected_thread_operator_comparison": comparison,
        "selected_thread_sequence_diff": diff,
        "selected_thread_operator_heatmap": heatmap,
    }
    for name, value in artifacts.items():
        write_csv(output / f"{name}.csv", value)
        write_json(output / f"{name}.json", value)
    (output / "operator_heatmap.html").write_text(
        build_html(selections, summaries, heatmap), encoding="utf-8"
    )

    manifest = {
        "schema_version": SCHEMA_VERSION,
        "status": "完成",
        "language": "zh-CN",
        "roles": {"real": "reference/真机", "sim": "candidate/仿真"},
        "difference_direction": "sim - real",
        "ratio_direction": "sim / real",
        "time_unit": "trace JSON ts/dur 原始 Chrome trace 微秒；未按 displayTimeUnit 重缩放",
        "real_trace": str(real_trace.resolve()),
        "sim_trace": str(sim_trace.resolve()),
        "real_trace_sha256": file_sha256(real_trace),
        "sim_trace_sha256": file_sha256(sim_trace),
        "selection": alignment,
        "sequence_diff_mode": sequence_mode,
        "heatmap_bins": heatmap_bins,
        "warnings": {
            "real_scan": real_scan_warnings,
            "sim_scan": sim_scan_warnings,
            "real_extract": real_extract_warnings,
            "sim_extract": sim_extract_warnings,
        },
        "counts": {name: len(value) for name, value in artifacts.items()},
        "output_shape_policy": (
            "只采用 operator X/B/E 事件 args 中 Output Dims/Output Shapes/Output Shape "
            "（含大小写、空格、下划线等常见键变体）的直接证据；B/E 两端冲突时保留并标明冲突；"
            f"无直接证据时为：{UNKNOWN_OUTPUT_SHAPE}；不从 kernel 反推"
        ),
        "self_time_policy": "self_duration_us 仅扣除嵌套的已确认 PyTorch operator；是 PyTorch-exclusive，不是全线程所有 slice 的通用 CPU Self",
    }
    write_json(output / "trace_thread_analysis_manifest.json", manifest)
    return manifest


def file_sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def selftest_check(condition: bool, message: str) -> None:
    if not condition:
        raise AssertionError(message)


def run_self_test() -> int:
    with tempfile.TemporaryDirectory(prefix="trace-thread-selftest-") as temporary:
        root = Path(temporary)
        real_trace = root / "real.json"
        sim_trace = root / "sim.json"
        output = root / "out"
        real_events = [
            {"ph": "B", "cat": "user_annotation", "name": "model.forward", "pid": 100, "tid": 101, "ts": 0},
            {"ph": "X", "cat": "cpu_op", "name": "aten::matmul", "pid": 100, "tid": 101, "ts": 1, "dur": 7, "args": {"Input Dims": [[2, 4], [4, 8]], "oUtPuT_sHaPeS": "[[2, 8]]", "Input type": ["float", "float"], "Call stack": "model.py:10"}},
            {"ph": "X", "cat": "cpu_op", "name": "aten::relu", "pid": 100, "tid": 101, "ts": 2, "dur": 2, "args": {"Input Dims": [[2, 8]], "Output Shape": [[2, 8]]}},
            {"ph": "E", "pid": 100, "tid": 101, "ts": 10},
            {"ph": "X", "cat": "kernel", "name": "aten::not_a_cpu_op", "pid": 100, "tid": 101, "ts": 3, "dur": 1},
            {"ph": "X", "cat": "cpu_op", "name": "aten::add", "pid": 100, "tid": 102, "ts": 1, "dur": 1},
            {"ph": "X", "cat": "user_annotation", "name": "idle", "pid": 100, "tid": 103, "ts": 1, "dur": 1},
            {"ph": "M", "name": "process_name", "pid": 100, "args": {"name": "python rank worker"}},
            {"ph": "M", "name": "thread_name", "pid": 100, "tid": 101, "args": {"name": "thread 100 (python)"}},
            {"ph": "M", "name": "thread_name", "pid": 100, "tid": 102, "args": {"name": "background"}},
            {"ph": "M", "name": "thread_name", "pid": 100, "tid": 103, "args": {"name": "non-pytorch"}},
        ]
        sim_events = [
            {},  # Chrome traces occasionally contain an empty placeholder.
            {"ph": "M", "name": "process_name", "pid": 200, "args": {"name": "python rank worker"}},
            {"ph": "M", "name": "thread_name", "pid": 200, "tid": 201, "args": {"name": "thread 999 (python)"}},
            {"ph": "B", "cat": "cpu_op", "name": "aten::matmul", "pid": 200, "tid": 201, "ts": 20, "args": {"Input Dims": [[2, 4], [4, 8]]}},
            {"ph": "X", "cat": "cpu_op", "name": "aten::relu", "pid": 200, "tid": 201, "ts": 22, "dur": 3, "args": {"Input Dims": [[2, 8]]}},
            {"ph": "E", "pid": 200, "tid": 201, "ts": 29, "args": {"output shape": [[2, 8]]}},
            {"ph": "B", "cat": "cpu_op", "name": "aten::shape_conflict", "pid": 200, "tid": 201, "ts": 30, "args": {"Output Dims": [[1, 2]]}},
            {"ph": "E", "pid": 200, "tid": 201, "ts": 31, "args": {"Output Shape": [[1, 3]]}},
            {"ph": "X", "cat": "python_function", "name": "aten::excluded_scope", "pid": 200, "tid": 201, "ts": 21, "dur": 1},
        ]
        real_trace.write_text(
            json.dumps({"displayTimeUnit": "ms", "traceEvents": real_events}, ensure_ascii=False),
            encoding="utf-8",
        )
        # Exercise the alternative top-level array form.
        sim_trace.write_text(json.dumps(sim_events, ensure_ascii=False), encoding="utf-8")
        real_inventory, _ = scan_trace(real_trace, "real/reference/真机")
        sim_inventory, _ = scan_trace(sim_trace, "sim/candidate/仿真")
        non_candidate = next(row for row in real_inventory if row["tid"] == "103")
        selftest_check(non_candidate["pytorch_operator_calls"] == 0, "无 PyTorch 线程调用数应为 0")
        selftest_check(
            all(
                isinstance(non_candidate[field], str)
                for field in (
                    "shape_coverage_percent",
                    "output_shape_coverage_percent",
                    "stack_coverage_percent",
                )
            ),
            "无 PyTorch 算子时的 coverage 不得伪造为 0%",
        )
        auto_real_1, auto_sim_1, auto_alignment_1 = choose_thread_pair(
            real_inventory, sim_inventory, seed=17
        )
        auto_real_2, auto_sim_2, auto_alignment_2 = choose_thread_pair(
            real_inventory, sim_inventory, seed=17
        )
        selftest_check(
            (auto_real_1["pid"], auto_real_1["tid"]) == (auto_real_2["pid"], auto_real_2["tid"]),
            "同 seed 的真机线程选择不稳定",
        )
        selftest_check(
            (auto_sim_1["pid"], auto_sim_1["tid"]) == (auto_sim_2["pid"], auto_sim_2["tid"]),
            "同 seed 的仿真线程选择不稳定",
        )
        selftest_check(auto_alignment_1 == auto_alignment_2, "同 seed 的线程对齐审计结果不稳定")
        if (auto_real_1["pid"], auto_real_1["tid"]) == ("100", "101"):
            selftest_check(
                (auto_sim_1["pid"], auto_sim_1["tid"]) == ("200", "201"),
                "共同语义线程没有对齐到仿真候选",
            )
            selftest_check(auto_alignment_1["thread_name_match"] == "是", "线程名对齐状态错误")
        manifest = analyze_pair(
            real_trace,
            sim_trace,
            output,
            seed=0,
            heatmap_bins=8,
            real_pid="100",
            real_tid="101",
            sim_pid="200",
            sim_tid="201",
        )
        events = json.loads((output / "selected_thread_operator_events.json").read_text(encoding="utf-8"))
        names = {(row["environment"], row["operator"]) for row in events}
        selftest_check(("real/reference/真机", "aten::matmul") in names, "真机 matmul 丢失")
        selftest_check(("real/reference/真机", "aten::relu") in names, "真机 relu 丢失")
        selftest_check(("sim/candidate/仿真", "aten::matmul") in names, "仿真 matmul 丢失")
        sim_matmul = next(
            row
            for row in events
            if row["environment"] == "sim/candidate/仿真" and row["operator"] == "aten::matmul"
        )
        selftest_check(sim_matmul["source_event_index"] == 3, "B/E 起始事件索引错误")
        real_matmul = next(
            row
            for row in events
            if row["environment"] == "real/reference/真机" and row["operator"] == "aten::matmul"
        )
        selftest_check(real_matmul["output_shapes"] == "[[2,8]]", "X event 输出 Shape 未规范化保留")
        selftest_check(real_matmul["output_shape_status"] == "直接证据", "X event 输出 Shape 状态错误")
        selftest_check(sim_matmul["output_shapes"] == "[[2,8]]", "B/E 的 E.args 输出 Shape 未保留")
        selftest_check("E.args" in sim_matmul["output_shape_evidence"], "B/E 输出 Shape 缺少端点证据")
        conflict = next(row for row in events if row["operator"] == "aten::shape_conflict")
        selftest_check(conflict["output_shape_status"] == "直接证据冲突", "B/E 输出 Shape 冲突未标明")
        selftest_check("[[1,2]]" in conflict["output_shapes"] and "[[1,3]]" in conflict["output_shapes"], "B/E 冲突未保留两端 Shape")
        signature_probe = [dict(real_matmul), dict(real_matmul)]
        signature_probe[1]["event_id"] = "different-output"
        signature_probe[1]["output_shapes"] = "[[2,9]]"
        selftest_check(
            len(summarize_events(signature_probe)) == 2,
            "operator+input+output Shape 聚合签名没有区分不同输出",
        )
        selftest_check(all("not_a_cpu_op" not in row["operator"] for row in events), "kernel 被误纳入")
        selftest_check(all("excluded_scope" not in row["operator"] for row in events), "scope 被误纳入")
        summaries = json.loads((output / "selected_thread_operator_summary.json").read_text(encoding="utf-8"))
        comparisons = json.loads((output / "selected_thread_operator_comparison.json").read_text(encoding="utf-8"))
        sequence = json.loads((output / "selected_thread_sequence_diff.json").read_text(encoding="utf-8"))
        selftest_check(
            any(row["operator"] == "aten::matmul" and row["output_shapes"] == "[[2,8]]" for row in summaries),
            "summary 未保留输出 Shape",
        )
        selftest_check(
            any(row["operator"] == "aten::matmul" and row["output_shapes"] == "[[2,8]]" for row in comparisons),
            "comparison 未按输出 Shape 对齐",
        )
        selftest_check(
            any(row.get("real_output_shapes") == "[[2,8]]" or row.get("sim_output_shapes") == "[[2,8]]" for row in sequence),
            "sequence 未保留输出 Shape",
        )
        heatmap = json.loads((output / "selected_thread_operator_heatmap.json").read_text(encoding="utf-8"))
        selftest_check(
            any(row["operator"] == "aten::matmul" and row["output_shapes"] == "[[2,8]]" for row in heatmap),
            "heatmap 未保留输出 Shape",
        )
        totals: Counter[tuple[str, int]] = Counter()
        for row in heatmap:
            totals[(row["environment"], int(row["bin_index"]))] += float(row["share_of_bin_percent"])
            selftest_check(float(row["share_of_bin_percent"]) <= 100.000001, "单热力图 cell 超过 100%")
        selftest_check(bool(totals) and all(total <= 100.0001 for total in totals.values()), "热力图 bin 总和超过 100%")
        required = [
            "trace_thread_inventory.csv",
            "selected_thread_pair.json",
            "selected_thread_operator_comparison.csv",
            "selected_thread_sequence_diff.json",
            "operator_heatmap.html",
            "trace_thread_analysis_manifest.json",
        ]
        selftest_check(all((output / name).is_file() for name in required), "线程分析产物不完整")
        selftest_check(manifest["counts"]["selected_thread_operator_events"] >= 4, "线程事件数异常")
        selftest_check(bool(auto_alignment_1["selection_audit_steps"]), "线程选择缺少实际排序审计键")
        selftest_check(ratio(0.0, 0.0)[1] == "不可计算（真机为0）", "0/0 ratio 不应伪造为 1")

        bad_trace = root / "bad-skipped-value.json"
        bad_trace.write_text('{"bad":[1 2],"traceEvents":[]}', encoding="utf-8")
        rejected_bad_json = False
        try:
            list(iter_trace_events(bad_trace))
        except (ValueError, json.JSONDecodeError):
            rejected_bad_json = True
        selftest_check(rejected_bad_json, "被跳过的顶层 metadata 仍必须接受严格 JSON 校验")

        equal_boundary = [
            {
                "environment": "real/reference/真机", "event_id": "equal-a", "source_event_index": 1,
                "source_end_event_index": "", "ph_original": "X", "start_us": 0.0, "duration_us": 10.0,
                "end_us": 10.0, "operator": "aten::a", "input_shapes": "[]", "depth": 0,
                "parent_event_id": "", "parent_operator": "", "nesting_status": "未计算", "self_duration_us": 10.0,
            },
            {
                "environment": "real/reference/真机", "event_id": "equal-b", "source_event_index": 2,
                "source_end_event_index": "", "ph_original": "X", "start_us": 0.0, "duration_us": 10.0,
                "end_us": 10.0, "operator": "aten::b", "input_shapes": "[]", "depth": 0,
                "parent_event_id": "", "parent_operator": "", "nesting_status": "未计算", "self_duration_us": 10.0,
            },
        ]
        assign_nesting_and_self_time(equal_boundary)
        selftest_check(
            all(float(row["self_duration_us"]) == 10.0 for row in equal_boundary),
            "相同边界 X slice 不得伪造成父子关系",
        )

        fully_covered = [
            {
                "environment": "real/reference/真机", "event_id": "outer", "source_event_index": 1,
                "source_end_event_index": "", "ph_original": "X", "start_us": 0.0, "duration_us": 10.0,
                "end_us": 10.0, "operator": "aten::outer", "input_shapes": "[]", "output_shapes": "[]", "depth": 0,
                "parent_event_id": "", "parent_operator": "", "nesting_status": "未计算", "self_duration_us": 10.0,
            },
            {
                "environment": "real/reference/真机", "event_id": "child-1", "source_event_index": 2,
                "source_end_event_index": "", "ph_original": "X", "start_us": 0.0, "duration_us": 5.0,
                "end_us": 5.0, "operator": "aten::child1", "input_shapes": "[]", "output_shapes": "[]", "depth": 0,
                "parent_event_id": "", "parent_operator": "", "nesting_status": "未计算", "self_duration_us": 5.0,
            },
            {
                "environment": "real/reference/真机", "event_id": "child-2", "source_event_index": 3,
                "source_end_event_index": "", "ph_original": "X", "start_us": 5.0, "duration_us": 5.0,
                "end_us": 10.0, "operator": "aten::child2", "input_shapes": "[]", "output_shapes": "[]", "depth": 0,
                "parent_event_id": "", "parent_operator": "", "nesting_status": "未计算", "self_duration_us": 5.0,
            },
        ]
        assign_nesting_and_self_time(fully_covered)
        covered_heatmap = build_heatmap(fully_covered, 2)
        outer_rows = [row for row in covered_heatmap if row["operator"] == "aten::outer"]
        selftest_check(bool(outer_rows), "exclusive=0 的外层 operator 仍应保留 heatmap/calls 行")
        selftest_check(
            all(float(row["deepest_exclusive_us"]) == 0.0 and float(row["inclusive_overlap_us"]) > 0 for row in outer_rows),
            "外层 operator 的 inclusive/deepest 字段错误",
        )
    print("自测通过：流式 array/object、X、B/E、M、筛选、对齐和 deepest/exclusive 热力图均有效。")
    return 0


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--real-trace", type=Path, help="真机/reference 的 trace_view.json")
    parser.add_argument("--sim-trace", type=Path, help="仿真/candidate 的 trace_view.json")
    parser.add_argument("--output", type=Path, help="输出目录，不修改输入 trace")
    parser.add_argument("--seed", type=int, default=0, help="可复现线程选择 seed，默认 0")
    parser.add_argument("--real-pid", help="可选：显式选择真机 PID；须与 --real-tid 同时使用")
    parser.add_argument("--real-tid", help="可选：显式选择真机 TID；须与 --real-pid 同时使用")
    parser.add_argument("--sim-pid", help="可选：显式选择仿真 PID；须与 --sim-tid 同时使用")
    parser.add_argument("--sim-tid", help="可选：显式选择仿真 TID；须与 --sim-pid 同时使用")
    parser.add_argument("--heatmap-bins", type=int, default=64, help="归一化热力图时间桶数量，默认 64")
    parser.add_argument("--self-test", action="store_true", help="运行内置合成 trace 自测后退出")
    return parser


def main(argv: list[str] | None = None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)
    if args.self_test:
        return run_self_test()
    missing = [name for name in ("real_trace", "sim_trace", "output") if getattr(args, name) is None]
    if missing:
        parser.error("正常分析必须提供 --real-trace、--sim-trace 和 --output")
    for role, path in (("真机", args.real_trace), ("仿真", args.sim_trace)):
        if not path.is_file():
            parser.error(f"{role} trace 文件不存在：{path}")
    if not 1 <= args.heatmap_bins <= 500:
        parser.error("--heatmap-bins 必须在 1..500 之间")
    for role, pid, tid in (
        ("真机", args.real_pid, args.real_tid),
        ("仿真", args.sim_pid, args.sim_tid),
    ):
        if (pid is None) != (tid is None):
            parser.error(f"{role}必须同时提供 PID 和 TID")
    try:
        manifest = analyze_pair(
            args.real_trace.resolve(),
            args.sim_trace.resolve(),
            args.output.resolve(),
            args.seed,
            args.heatmap_bins,
            args.real_pid,
            args.real_tid,
            args.sim_pid,
            args.sim_tid,
        )
    except (OSError, ValueError, json.JSONDecodeError) as exc:
        parser.error(f"分析失败：{type(exc).__name__}: {exc}")
    status = str(manifest.get("status", "未知"))
    print(f"{status}：{args.output.resolve()}")
    if status == "完成":
        print(f"线程对齐置信度：{manifest['selection']['alignment_confidence']}")
        print(f"请查看：{args.output.resolve() / 'operator_heatmap.html'}")
    else:
        print(f"原因：{manifest.get('reason', '未知')}")
        print(f"影响：{manifest.get('impact', '未知')}")
        print(f"候选清单：{args.output.resolve() / 'trace_thread_inventory.csv'}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

from __future__ import annotations

import importlib.util
import os
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path
from unittest import mock


SCRIPT = Path(__file__).resolve().parents[1] / "scripts" / "analyze_control_flow.py"
SPEC = importlib.util.spec_from_file_location("analyze_control_flow_security", SCRIPT)
assert SPEC and SPEC.loader
ANALYZER = importlib.util.module_from_spec(SPEC)
sys.modules[SPEC.name] = ANALYZER
SPEC.loader.exec_module(ANALYZER)


class AnalyzeControlFlowGitSecurityTests(unittest.TestCase):
    @staticmethod
    def _git(trusted: Path, repo: Path, *arguments: str) -> str:
        completed = subprocess.run(
            [str(trusted), "-C", str(repo), *arguments],
            capture_output=True,
            text=True,
            encoding="utf-8",
            errors="replace",
            check=True,
            shell=False,
        )
        return completed.stdout.strip()

    def test_resolver_ignores_cwd_work_root_and_relative_path_entries(self) -> None:
        trusted = ANALYZER.resolve_git_executable(forbidden_roots=[Path.cwd()])
        with self.assertRaises(ValueError):
            ANALYZER.resolve_git_executable("git", forbidden_roots=[Path.cwd()])
        with tempfile.TemporaryDirectory() as temp:
            work_root = Path(temp)
            fake_bin = work_root / "bin"
            fake_bin.mkdir()
            fake = fake_bin / ("git.exe" if os.name == "nt" else "git")
            fake.write_text("malicious placeholder\n", encoding="utf-8")
            if os.name != "nt":
                fake.chmod(0o755)
            environment = {
                "PATH": os.pathsep.join([".", str(fake_bin), str(trusted.parent)])
            }
            resolved = ANALYZER.resolve_git_executable(
                forbidden_roots=[work_root], environ=environment
            )
            self.assertEqual(resolved, trusted)
            with self.assertRaises(ValueError):
                ANALYZER.resolve_git_executable(
                    fake, forbidden_roots=[work_root], environ=environment
                )

    def test_git_metadata_never_executes_an_untrusted_local_git(self) -> None:
        with tempfile.TemporaryDirectory() as temp:
            work_root = Path(temp)
            repo = work_root / "repo"
            (repo / ".git").mkdir(parents=True)
            marker = work_root / "executed.txt"
            fake = work_root / ("git.exe" if os.name == "nt" else "git")
            fake.write_text(
                "#!/bin/sh\nprintf executed > %s\n" % marker.as_posix(),
                encoding="utf-8",
            )
            if os.name != "nt":
                fake.chmod(0o755)
            with mock.patch.dict(os.environ, {"PATH": str(work_root)}, clear=False):
                metadata = ANALYZER.git_metadata(
                    repo, "", "", forbidden_roots=[work_root]
                )
            self.assertEqual(metadata["git_executable_status"], "unavailable")
            self.assertFalse(marker.exists())

    def test_git_probe_disables_repository_execution_surfaces(self) -> None:
        trusted = ANALYZER.resolve_git_executable(forbidden_roots=[Path.cwd()])
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            repo = root / "repo"
            (repo / ".git" / "info").mkdir(parents=True)
            outputs = iter(
                [
                    "a" * 40,
                    "b" * 40,
                    "",
                    "https://example.invalid/acme/model.git",
                ]
            )

            def fake_run(command: list[str], **kwargs: object) -> subprocess.CompletedProcess[str]:
                return subprocess.CompletedProcess(command, 0, next(outputs), "")

            with mock.patch.dict(
                os.environ,
                {
                    "GIT_CONFIG_COUNT": "1",
                    "GIT_CONFIG_KEY_0": "core.fsmonitor",
                    "GIT_CONFIG_VALUE_0": "malicious-command",
                    "GIT_EXEC_PATH": str(root / "fake-exec-path"),
                    "SSH_ASKPASS": str(root / "malicious-askpass"),
                },
            ), mock.patch.object(
                ANALYZER.subprocess, "run", side_effect=fake_run
            ) as runner:
                metadata = ANALYZER.git_metadata(
                    repo,
                    "",
                    "",
                    git_executable=trusted,
                    forbidden_roots=[root],
                )

            self.assertEqual(metadata["worktree_dirty"], "no", metadata)
            self.assertEqual(metadata["binding_status"], "verified", metadata)
            self.assertEqual(metadata["git_executable_status"], "trusted-absolute")
            self.assertEqual(runner.call_count, 4)
            for call in runner.call_args_list:
                command = call.args[0]
                kwargs = call.kwargs
                self.assertTrue(Path(command[0]).is_absolute())
                self.assertEqual(Path(command[0]).resolve(), trusted)
                self.assertIn("core.fsmonitor=false", command)
                self.assertIn("credential.helper=", command)
                self.assertTrue(any(item.startswith("core.hooksPath=") for item in command))
                self.assertFalse(kwargs["shell"])
                environment = kwargs["env"]
                self.assertEqual(environment["GIT_CONFIG_NOSYSTEM"], "1")
                self.assertEqual(environment["GIT_CONFIG_GLOBAL"], os.devnull)
                self.assertEqual(environment["GIT_TERMINAL_PROMPT"], "0")
                self.assertEqual(environment["GIT_LFS_SKIP_SMUDGE"], "1")
                self.assertEqual(environment["GIT_OPTIONAL_LOCKS"], "0")
                self.assertNotIn("GIT_CONFIG_COUNT", environment)
                self.assertNotIn("GIT_CONFIG_KEY_0", environment)
                self.assertNotIn("GIT_CONFIG_VALUE_0", environment)
                self.assertNotIn("GIT_EXEC_PATH", environment)
                self.assertNotIn("SSH_ASKPASS", environment)

    def test_repository_configured_fsmonitor_is_not_executed(self) -> None:
        trusted = ANALYZER.resolve_git_executable(forbidden_roots=[Path.cwd()])
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            repo = root / "repo"
            repo.mkdir()
            self._git(trusted, repo, "init", "--quiet")
            self._git(trusted, repo, "config", "user.name", "Security Test")
            self._git(
                trusted, repo, "config", "user.email", "security@example.invalid"
            )
            self._git(trusted, repo, "config", "core.autocrlf", "false")
            (repo / "model.py").write_text("VALUE = 1\n", encoding="utf-8")
            self._git(trusted, repo, "add", "model.py")
            self._git(trusted, repo, "commit", "--quiet", "-m", "fixture")
            marker = root / "fsmonitor-executed.txt"
            if os.name == "nt":
                monitor = root / "malicious-fsmonitor.cmd"
                monitor.write_text(
                    f"@echo executed>{marker}\r\n@exit /b 0\r\n", encoding="utf-8"
                )
            else:
                monitor = root / "malicious-fsmonitor"
                monitor.write_text(
                    f"#!/bin/sh\nprintf executed > '{marker}'\n", encoding="utf-8"
                )
                monitor.chmod(0o755)
            self._git(trusted, repo, "config", "core.fsmonitor", str(monitor))

            metadata = ANALYZER.git_metadata(
                repo,
                "",
                "",
                git_executable=trusted,
                forbidden_roots=[root],
            )
            self.assertFalse(marker.exists())
            self.assertEqual(metadata["worktree_dirty"], "no", metadata)
            self.assertEqual(metadata["binding_status"], "verified", metadata)


if __name__ == "__main__":
    unittest.main()

from __future__ import annotations

import importlib.util
import hashlib
import json
import os
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path
from unittest import mock


SCRIPT = Path(__file__).resolve().parents[1] / "scripts" / "profiling_alignment.py"
SPEC = importlib.util.spec_from_file_location("profiling_alignment_under_test", SCRIPT)
assert SPEC is not None and SPEC.loader is not None
MODULE = importlib.util.module_from_spec(SPEC)
sys.modules[SPEC.name] = MODULE
SPEC.loader.exec_module(MODULE)


def argument(command: list[str], name: str) -> str:
    return command[command.index(name) + 1]


def script_name(command: list[str]) -> str:
    index = 2 if len(command) >= 3 and command[1] == "-I" else 1
    return Path(command[index]).name


class ProfilingAlignmentTests(unittest.TestCase):
    def setUp(self) -> None:
        self.temporary = tempfile.TemporaryDirectory(prefix="profiling-orchestrator-test-")
        self.root = Path(self.temporary.name).resolve()
        self.work = self.root / "work"
        self.work.mkdir()
        self.model = self.work / "MindSpeed"
        self.pytorch = self.work / "torch"
        self.torch_npu = self.work / "torch_npu"
        self.real = self.work / "real-profiling"
        self.sim = self.work / "sim-profiling"
        for directory in (self.model, self.pytorch, self.torch_npu, self.real, self.sim):
            directory.mkdir()
        (self.model / "launch").mkdir()
        self.entry = self.model / "launch" / "train.sh"
        self.entry.write_text("#!/bin/sh\npython pretrain.py\n", encoding="utf-8")
        self.output = self.work / "result"
        self.spec_path = self.work / "alignment-run.json"
        self.invocations: list[list[str]] = []

    def tearDown(self) -> None:
        self.temporary.cleanup()

    def raw_spec(self, **updates: object) -> dict[str, object]:
        payload: dict[str, object] = {
            "schema_version": 1,
            "work_root": str(self.work),
            "source_roots": {
                "model": {"path": "MindSpeed"},
                "pytorch": "torch",
                "torch_npu": {"path": "torch_npu"},
            },
            "entry_sh": "launch/train.sh",
            "profiles": {"real": "real-profiling", "sim": "sim-profiling"},
            "output_root": "result",
            "perfetto_online_authorized": False,
        }
        payload.update(updates)
        return payload

    def write_spec(self, payload: dict[str, object] | None = None) -> Path:
        self.spec_path.write_text(
            json.dumps(payload or self.raw_spec(), ensure_ascii=False, indent=2),
            encoding="utf-8",
        )
        return self.spec_path

    def normalized(self, payload: dict[str, object] | None = None) -> tuple[dict, str]:
        self.write_spec(payload)
        return MODULE.read_and_normalize_spec(self.spec_path)

    def fake_invoke(self, command, cwd, env=None):  # noqa: ANN001
        command = list(command)
        self.invocations.append(command)
        name = script_name(command)
        if name == "runtime_doctor.py":
            output = Path(argument(command, "--output-root")) / "evidence" / "runtime"
            output.mkdir(parents=True, exist_ok=True)
            (output / "runtime_doctor.json").write_text(
                json.dumps({"schema_version": 1, "status": "ready", "blocking_checks": []}),
                encoding="utf-8",
            )
            return MODULE.Invocation(0, "runtime ready", "")
        if name == "preflight_ascend_profiles.py":
            output = Path(argument(command, "--output"))
            output.mkdir(parents=True, exist_ok=True)
            (output / "collection_contract.json").write_text(
                json.dumps({"schema_version": 1, "status": "complete"}), encoding="utf-8"
            )
            (output / "collection_contract.csv").write_text("status\ncomplete\n", encoding="utf-8")
            return MODULE.Invocation(0, "preflight complete", "")
        if name == "align_profiles.py":
            output = Path(argument(command, "--output"))
            output.mkdir(parents=True, exist_ok=True)
            for artifact_name in (
                "canonical_events.csv",
                "rank_pairs.csv",
                "thread_pairs.csv",
                "event_alignment.csv",
                "unpaired_ranks.csv",
                "host_device_links.csv",
            ):
                (output / artifact_name).write_text("id\n", encoding="utf-8")
            (output / "divergence_windows.jsonl").write_text("", encoding="utf-8")
            (output / "analysis_manifest.json").write_text(
                json.dumps({"schema_version": 3, "status": "complete"}), encoding="utf-8"
            )
            return MODULE.Invocation(0, "alignment complete", "")
        if name == "resolve_source_entrypoints.py":
            output = Path(argument(command, "--output"))
            output.mkdir(parents=True, exist_ok=True)
            (output / "source_entrypoint_summary.json").write_text(
                json.dumps(
                    {
                        "schema_version": 1,
                        "partial": False,
                        "counts": {"launch_candidates": 1},
                        "repository_code_executed": False,
                    }
                ),
                encoding="utf-8",
            )
            return MODULE.Invocation(0, "entrypoint complete", "")
        if name == "render_python_guard_snapshots.py":
            output = Path(argument(command, "--output"))
            output.mkdir(parents=True, exist_ok=True)
            (output / "python_guard_snapshots.json").write_text(
                json.dumps({"schema_version": 2, "snapshot_count": 1}), encoding="utf-8"
            )
            (output / "python_guard_snapshots.md").write_text("# snapshot\n", encoding="utf-8")
            (output / "python_guard_snapshots.html").write_text("<html></html>\n", encoding="utf-8")
            (output / "python_guard_snapshots.csv").write_text("evidence_id\ne-1\n", encoding="utf-8")
            return MODULE.Invocation(0, "snapshots complete", "")
        if name == "render_perfetto_batch.py":
            output = Path(argument(command, "--output"))
            output.mkdir(parents=True, exist_ok=True)
            jobs = output / "jobs"
            jobs.mkdir(exist_ok=True)
            (jobs / "rank-0.html").write_text("<html>rank 0</html>\n", encoding="utf-8")
            (output / "perfetto_batch_manifest.csv").write_text(
                "rank_pair_id,environment\n", encoding="utf-8"
            )
            if "--online-authorized" in command:
                job_output = output / "perfetto" / "rank-0000" / "real" / "batch_000"
                job_output.mkdir(parents=True)
                for artifact_name, value in (
                    ("perfetto_ui_frame.html", "<html>review</html>\n"),
                    ("perfetto_ui_text.txt", "operator rows\n"),
                    ("perfetto_browser.log", "offline before trace post\n"),
                ):
                    (job_output / artifact_name).write_text(value, encoding="utf-8")
                run_id = "00000000-0000-4000-8000-000000000001"
                trace_sha = "a" * 64
                renderer_manifest = job_output / "perfetto_manifest.json"
                renderer_manifest.write_text(
                    json.dumps(
                        {
                            "schema_version": 3,
                            "status": "success",
                            "run_id": run_id,
                            "trace": {"sha256": trace_sha},
                            "sql": {
                                "query_results": [
                                    {
                                        "query_id": "structural_sequence",
                                        "completed": True,
                                        "row_count": 1,
                                        "error": None,
                                    }
                                ]
                            },
                        }
                    ),
                    encoding="utf-8",
                )
                job = {
                    "rank_pair_id": "rank-0000",
                    "environment": "real",
                    "output_dir": str(job_output),
                    "manifest_path": str(renderer_manifest),
                    "planned_status": "ready",
                    "run_status": "success",
                    "return_code": 0,
                    "auto_artifact_gate": "auto-artifacts-ready",
                    "lane_batch_union_complete": True,
                    "expected_trace_sha256": trace_sha,
                    "renderer_run_id": run_id,
                }
                (output / "perfetto_batch_manifest.csv").write_text(
                    "rank_pair_id,environment\nrank-0000,real\n", encoding="utf-8"
                )
                (output / "perfetto_batch_manifest.json").write_text(
                    json.dumps(
                        {
                            "schema_version": 2,
                            "status": "complete",
                            "online_authorized": True,
                            "screenshot_requested": False,
                            "jobs": [job],
                        }
                    ),
                    encoding="utf-8",
                )
                return MODULE.Invocation(0, "perfetto rendered", "")
            (output / "perfetto_batch_manifest.json").write_text(
                json.dumps({"schema_version": 2, "status": "partial", "jobs": []}),
                encoding="utf-8",
            )
            (output / "perfetto_content_review.json").write_text(
                json.dumps(
                    {
                        "schema_version": 1,
                        "status": "not-executed",
                        "reason": "not authorized",
                    }
                ),
                encoding="utf-8",
            )
            return MODULE.Invocation(1, "perfetto not executed", "")
        if name == "build_alignment_report.py":
            report = Path(argument(command, "--output"))
            report.parent.mkdir(parents=True, exist_ok=True)
            report.write_text("# Profiling Alignment Report\n", encoding="utf-8")
            return MODULE.Invocation(0, "report complete", "")
        if name == "validate_alignment_report.py":
            output = Path(argument(command, "--output"))
            output.mkdir(parents=True, exist_ok=True)
            (output / "report_validation.json").write_text(
                json.dumps(
                    {
                        "schema_version": 1,
                        "status": "pass",
                        "blocking_error_count": 0,
                        "warning_count": 0,
                    }
                ),
                encoding="utf-8",
            )
            (output / "report_validation.csv").write_text("severity\n", encoding="utf-8")
            return MODULE.Invocation(0, "validator pass", "")
        self.fail(f"unexpected child script: {name}")

    def write_external_source_analysis(self, component: str = "torch_npu") -> None:
        spec, _ = MODULE.read_and_normalize_spec(self.spec_path)
        paths = MODULE.paths_for(spec)
        contract = MODULE._source_contract_path(paths, component)
        if not contract.is_file():
            MODULE.atomic_write_json(
                contract,
                MODULE.build_run_contract(
                    spec, self.spec_path, analyzed_component=component
                ),
            )
        contract_sha = hashlib.sha256(contract.read_bytes()).hexdigest()
        source = self.output / "evidence" / "source-causality"
        source.mkdir(parents=True, exist_ok=True)
        repo_root = Path(spec["source_roots"][component]["path"])
        tracked_source = repo_root / "tracked_guard.py"
        if not tracked_source.is_file():
            tracked_source.write_text(
                "def route(flag):\n    if flag:\n        return 1\n    return 0\n",
                encoding="utf-8",
            )
        tracked_text = tracked_source.read_text(encoding="utf-8-sig", errors="strict")
        tracked_sha = hashlib.sha256(tracked_text.encode("utf-8")).hexdigest()
        integrity = {}
        for name in MODULE.SOURCE_ANALYSIS_ARTIFACTS:
            path = source / name
            if name == "control_flow_guard_candidates.csv":
                payload = b"evidence_id,candidate_rank\ne-1,1\n"
            elif name == "source_evidence.csv":
                payload = (
                    "evidence_id,environment,repository,commit,path,line_start,line_end,"
                    "symbol,evidence_kind,content_sha256,permalink\n"
                    f"source-test,source,,,tracked_guard.py,1,4,<module>,"
                    f"python-ast-parsed,{tracked_sha},\n"
                ).encode("utf-8")
            elif name.endswith(".csv"):
                payload = b"id\n"
            else:
                payload = b""
            path.write_bytes(payload)
            integrity[name] = {
                "sha256": hashlib.sha256(payload).hexdigest(),
                "bytes": len(payload),
                "nonempty": bool(payload),
            }
        (source / "source_analysis_manifest.json").write_text(
            json.dumps(
                {
                    "schema_version": 4,
                    "status": "complete",
                    "source_component": component,
                    "run_comparability": {"sha256": contract_sha},
                    "artifacts": list(MODULE.SOURCE_ANALYSIS_ARTIFACTS),
                    "artifact_integrity": integrity,
                }
            ),
            encoding="utf-8",
        )

    def complete_perfetto_review(self) -> Path:
        review_dir = self.output / "evidence" / "perfetto-review"
        template = json.loads(
            (review_dir / "perfetto_content_review.template.json").read_text(
                encoding="utf-8"
            )
        )
        template["status"] = "complete"
        template["observations"] = ["all listed HTML/text/SQL/log artifacts reviewed"]
        for job in template["reviewed_jobs"]:
            job["status"] = "complete"
            job["observations"] = ["operator route and query rows reviewed"]
        output = review_dir / "perfetto_content_review.json"
        output.write_text(json.dumps(template), encoding="utf-8")
        return output

    def test_normalize_required_paths_and_legacy_perfetto_flag(self) -> None:
        spec, digest = self.normalized()
        self.assertEqual(spec["entry_sh"], ["launch/train.sh"])
        self.assertEqual(spec["source_roots"]["torch_npu"]["path"], str(self.torch_npu))
        self.assertFalse(spec["perfetto"]["online_authorized"])
        self.assertEqual(len(digest), 64)
        self.assertEqual(spec["runtime"]["python"], str(Path(sys.executable).resolve()))
        self.assertTrue(Path(spec["runtime"]["git"]).is_absolute())
        self.assertFalse(MODULE.is_within(Path(spec["runtime"]["git"]), self.work))
        self.assertEqual(spec["perfetto"]["node"], "")
        custom, _ = self.normalized(
            self.raw_spec(
                perfetto={
                    "online_authorized": False,
                    "degraded_reason": "audit offline",
                }
            )
        )
        self.assertIn("not authorized", custom["perfetto"]["degraded_reason"])

    def test_spec_hash_is_independent_of_json_format_and_key_order(self) -> None:
        raw = self.raw_spec()
        _, first = self.normalized(raw)
        reordered = dict(reversed(list(raw.items())))
        _, second = self.normalized(reordered)
        self.assertEqual(first, second)

    def test_rejects_conflicting_perfetto_flags_and_unsafe_output(self) -> None:
        raw = self.raw_spec(
            perfetto_online_authorized=False,
            perfetto={"online_authorized": True},
        )
        with self.assertRaisesRegex(MODULE.SpecError, "authorization fields conflict"):
            self.normalized(raw)
        unsafe = self.raw_spec(output_root="MindSpeed/out")
        with self.assertRaisesRegex(MODULE.SpecError, "disjoint"):
            self.normalized(unsafe)

    def test_source_owner_validation(self) -> None:
        raw = self.raw_spec(
            source_owner={
                "component": "torch-npu",
                "runtime_binding": "unverified",
                "include_python": ["torch_npu/fsdp/patch.py"],
            }
        )
        spec, _ = self.normalized(raw)
        self.assertEqual(spec["source_owner"]["component"], "torch_npu")
        raw["source_owner"]["include_python"] = ["../escape.py"]  # type: ignore[index]
        with self.assertRaisesRegex(MODULE.SpecError, "repo-relative"):
            self.normalized(raw)

    def test_run_contract_is_partial_and_versions_are_ignored(self) -> None:
        raw = self.raw_spec(
            source_owner="torch_npu",
            runtime={
                "real": {"workload": "Qwen3VL", "pytorch_version": "2.x"},
                "sim": {"workload": "Qwen3VL", "pytorch_version": "different"},
            },
        )
        spec, _ = self.normalized(raw)
        contract = MODULE.build_run_contract(spec, self.spec_path)
        self.assertEqual(contract["status"], "partial")
        self.assertEqual(contract["real"]["analyzed_source"]["status"], "unknown")
        self.assertEqual(contract["real"]["pytorch_version"]["status"], "ignored")
        self.assertEqual(
            contract["source_roots"]["torch_npu"]["role"],
            "reference-source-baseline",
        )
        self.assertFalse(contract["policy"]["repository_code_executed"])

    def test_status_before_run_is_read_only_and_has_absolute_command(self) -> None:
        self.write_spec()
        payload, code = MODULE.status_payload(self.spec_path)
        self.assertEqual(code, 0)
        self.assertEqual(payload["status"], "not-started")
        self.assertIn(str(SCRIPT), payload["next_command"])
        self.assertFalse((self.output / "evidence").exists())

    def test_nonempty_output_without_state_is_refused(self) -> None:
        self.write_spec()
        self.output.mkdir()
        (self.output / "foreign.txt").write_text("not this run", encoding="utf-8")
        with self.assertRaisesRegex(MODULE.PipelineError, "non-empty"):
            MODULE.run_pipeline(self.spec_path)
        payload, code = MODULE.status_payload(self.spec_path)
        self.assertEqual((payload["status"], code), ("foreign-output", 2))

    def test_public_cli_validate_and_status_subcommands(self) -> None:
        self.write_spec()
        for subcommand, expected in (("validate-spec", "valid"), ("status", "not-started")):
            completed = subprocess.run(
                [sys.executable, "-I", str(SCRIPT), subcommand, "--spec", str(self.spec_path)],
                capture_output=True,
                text=True,
                check=False,
            )
            self.assertEqual(completed.returncode, 0, completed.stderr)
            self.assertEqual(json.loads(completed.stdout)["status"], expected)

    def test_lock_is_exclusive_and_removed(self) -> None:
        lock = self.work / "lock" / "run.lock"
        with MODULE.pipeline_lock(lock, "a" * 64):
            self.assertTrue(lock.is_file())
            with self.assertRaisesRegex(MODULE.PipelineError, "already exists"):
                with MODULE.pipeline_lock(lock, "a" * 64):
                    pass
        self.assertFalse(lock.exists())

    def test_first_run_stops_at_needs_agent_without_executing_entry_sh(self) -> None:
        self.write_spec()
        with mock.patch.object(MODULE, "_invoke", side_effect=self.fake_invoke):
            state, code = MODULE.run_pipeline(self.spec_path)
        self.assertEqual(code, 3)
        self.assertEqual(state["status"], "needs-agent")
        self.assertEqual(state["stages"]["source_causality"]["status"], "needs-agent")
        self.assertEqual(state["stages"]["perfetto"]["status"], "pending")
        align_hashes = state["stages"]["align"]["artifact_hashes"]
        self.assertTrue(
            {
                "evidence/alignment/analysis_manifest.json",
                "evidence/alignment/canonical_events.csv",
                "evidence/alignment/rank_pairs.csv",
                "evidence/alignment/thread_pairs.csv",
                "evidence/alignment/divergence_windows.jsonl",
                "evidence/alignment/event_alignment.csv",
                "evidence/alignment/unpaired_ranks.csv",
            }.issubset(align_hashes)
        )
        self.assertFalse((self.output / "profiling_alignment_report.md").exists())
        invoked_names = {script_name(command) for command in self.invocations}
        self.assertNotIn("train.sh", invoked_names)
        self.assertNotIn("analyze_control_flow.py", invoked_names)
        checkpoint = json.loads(
            (self.output / "evidence" / "pipeline" / "source-causality-checkpoint.json").read_text(
                encoding="utf-8"
            )
        )
        self.assertEqual(set(checkpoint["next_commands_by_owner"]), {"model", "pytorch", "torch_npu"})
        self.assertEqual(set(checkpoint["next_argv_by_owner"]), {"model", "pytorch", "torch_npu"})
        for command in checkpoint["next_commands_by_owner"].values():
            self.assertIn(str((SCRIPT.parent / "analyze_control_flow.py").resolve()), command)
        for component, command in checkpoint["next_commands_by_owner"].items():
            self.assertIn(
                str(
                    self.output
                    / "evidence"
                    / "pipeline"
                    / "source-contracts"
                    / f"{component}.json"
                ),
                command,
            )
            self.assertEqual(
                checkpoint["next_argv_by_owner"][component][1], "-I"
            )
            argv = checkpoint["next_argv_by_owner"][component]
            self.assertEqual(
                Path(argument(argv, "--git-executable")),
                Path(state["normalized_spec"]["runtime"]["git"]),
            )
        root_entries = {path.name for path in self.output.iterdir()}
        self.assertEqual(root_entries, {"evidence"})
        pipeline = self.output / "evidence" / "pipeline"
        self.assertTrue((pipeline / "run-state.json").is_file())
        self.assertFalse((pipeline / "run.lock").exists())
        self.assertEqual(list(pipeline.glob("*.tmp")), [])

    def test_resume_infers_owner_from_manifest_builds_snapshots_and_validates(self) -> None:
        self.write_spec()
        with mock.patch.object(MODULE, "_invoke", side_effect=self.fake_invoke):
            first, first_code = MODULE.run_pipeline(self.spec_path)
        self.assertEqual((first["status"], first_code), ("needs-agent", 3))
        self.write_external_source_analysis("torch_npu")
        self.invocations.clear()
        with mock.patch.object(MODULE, "_invoke", side_effect=self.fake_invoke):
            final, final_code = MODULE.run_pipeline(self.spec_path, resume=True)
        self.assertEqual(final_code, 0)
        self.assertEqual(final["status"], "complete")
        self.assertEqual(final["stages"]["source_causality"]["status"], "complete")
        self.assertEqual(final["stages"]["perfetto"]["status"], "degraded")
        self.assertEqual(final["stages"]["validator"]["status"], "complete")
        snapshot_command = next(
            command
            for command in self.invocations
            if script_name(command) == "render_python_guard_snapshots.py"
        )
        self.assertEqual(Path(argument(snapshot_command, "--repo-root")), self.torch_npu)
        perfetto_command = next(
            command for command in self.invocations if script_name(command) == "render_perfetto_batch.py"
        )
        self.assertIn("--degraded-reason", perfetto_command)
        self.assertNotIn("--online-authorized", perfetto_command)
        report_command = next(
            command for command in self.invocations if script_name(command) == "build_alignment_report.py"
        )
        self.assertIn("--source-causality-dir", report_command)
        self.assertTrue((self.output / "profiling_alignment_report.md").is_file())
        self.assertEqual(
            {path.name for path in self.output.iterdir()},
            {"evidence", "profiling_alignment_report.md"},
        )
        selected_contract = json.loads(
            (self.output / "evidence" / "run_comparability_contract.json").read_text(
                encoding="utf-8"
            )
        )
        self.assertEqual(
            selected_contract["real"]["analyzed_source"]["component"], "torch_npu"
        )
        self.invocations.clear()
        with mock.patch.object(MODULE, "_invoke", side_effect=self.fake_invoke):
            stable, stable_code = MODULE.run_pipeline(self.spec_path, resume=True)
        self.assertEqual((stable["status"], stable_code), ("complete", 0))
        self.assertEqual(self.invocations, [])
        status, status_code = MODULE.status_payload(self.spec_path)
        self.assertEqual((status["status"], status_code), ("complete", 0))
        self.assertEqual(status["stale_stages"], [])
        with mock.patch.object(MODULE, "_invoke", side_effect=self.fake_invoke):
            forced, forced_code = MODULE.run_pipeline(
                self.spec_path, resume=True, force_stages=["perfetto"]
            )
        self.assertEqual((forced["status"], forced_code), ("complete", 0))
        self.assertEqual(
            [script_name(command) for command in self.invocations],
            [
                "render_perfetto_batch.py",
                "build_alignment_report.py",
                "validate_alignment_report.py",
            ],
        )
        self.invocations.clear()
        with mock.patch.object(MODULE, "_invoke", side_effect=self.fake_invoke):
            rebuilt, rebuilt_code = MODULE.run_pipeline(
                self.spec_path, from_stage="report"
            )
        self.assertEqual((rebuilt["status"], rebuilt_code), ("complete", 0))
        self.assertEqual(
            [script_name(command) for command in self.invocations],
            ["build_alignment_report.py", "validate_alignment_report.py"],
        )

    def test_authorized_perfetto_forwards_explicit_playwright_root(self) -> None:
        playwright = self.root / "trusted-node-modules"
        playwright.mkdir()
        raw = self.raw_spec(
            perfetto={
                "online_authorized": True,
                # The orchestrator validates provenance, while the child test is
                # mocked; any trusted absolute executable exercises forwarding.
                "node": str(Path(sys.executable).resolve()),
                "playwright_node_modules": str(playwright),
                "browser": str(Path(sys.executable).resolve()),
                "screenshot": True,
            }
        )
        raw.pop("perfetto_online_authorized")
        self.write_spec(raw)
        with mock.patch.object(MODULE, "_invoke", side_effect=self.fake_invoke):
            first, first_code = MODULE.run_pipeline(self.spec_path)
        self.assertEqual((first["status"], first_code), ("needs-agent", 3))
        self.write_external_source_analysis("model")
        self.invocations.clear()
        with mock.patch.object(MODULE, "_invoke", side_effect=self.fake_invoke):
            state, code = MODULE.run_pipeline(self.spec_path, resume=True)
        self.assertEqual((state["status"], code), ("needs-agent", 3))
        self.assertEqual(state["stages"]["perfetto"]["status"], "needs-agent")
        command = next(
            item for item in self.invocations if script_name(item) == "render_perfetto_batch.py"
        )
        self.assertIn("--online-authorized", command)
        self.assertIn("--screenshot", command)
        self.assertTrue(Path(argument(command, "--node")).is_absolute())
        self.assertTrue(Path(argument(command, "--browser")).is_absolute())
        self.assertEqual(
            Path(argument(command, "--playwright-node-modules")), playwright
        )
        checkpoint = json.loads(
            (
                self.output
                / "evidence"
                / "pipeline"
                / "perfetto-content-review-checkpoint.json"
            ).read_text(encoding="utf-8")
        )
        self.assertFalse(checkpoint["renderer_will_run_on_resume"])
        self.assertEqual(len(checkpoint["jobs"]), 1)
        self.assertTrue(checkpoint["jobs"][0]["html_path"])
        self.assertEqual(checkpoint["jobs"][0]["sql_json_pointer"], "/sql")
        review_path = self.complete_perfetto_review()
        invalid = json.loads(review_path.read_text(encoding="utf-8"))
        invalid["reviewed_jobs"] = []
        review_path.write_text(json.dumps(invalid), encoding="utf-8")
        self.invocations.clear()
        with mock.patch.object(MODULE, "_invoke", side_effect=self.fake_invoke):
            invalid_state, invalid_code = MODULE.run_pipeline(
                self.spec_path, resume=True
            )
        self.assertEqual((invalid_state["status"], invalid_code), ("needs-agent", 3))
        self.assertNotIn(
            "render_perfetto_batch.py",
            [script_name(item) for item in self.invocations],
        )
        status, status_code = MODULE.status_payload(self.spec_path)
        self.assertEqual((status["status"], status_code), ("needs-agent", 0))
        self.assertIn("every job", status["review_operation"].casefold())

        self.complete_perfetto_review()
        self.invocations.clear()
        with mock.patch.object(MODULE, "_invoke", side_effect=self.fake_invoke):
            completed, completed_code = MODULE.run_pipeline(self.spec_path, resume=True)
        self.assertEqual((completed["status"], completed_code), ("complete", 0))
        self.assertNotIn(
            "render_perfetto_batch.py",
            [script_name(item) for item in self.invocations],
        )
        html = Path(checkpoint["jobs"][0]["html_path"])
        html.write_text("tampered after review\n", encoding="utf-8")
        stale, stale_code = MODULE.status_payload(self.spec_path)
        self.assertEqual((stale["status"], stale_code), ("stale", 1))
        self.invocations.clear()
        with mock.patch.object(MODULE, "_invoke", side_effect=self.fake_invoke):
            refused, refused_code = MODULE.run_pipeline(self.spec_path, resume=True)
        self.assertEqual((refused["status"], refused_code), ("needs-agent", 3))
        self.assertIn("changed or a job is missing", refused["stages"]["perfetto"]["reason"])
        self.assertNotIn(
            "render_perfetto_batch.py",
            [script_name(item) for item in self.invocations],
        )

    def test_manifest_owner_conflict_remains_needs_agent(self) -> None:
        self.write_spec(self.raw_spec(source_owner="model"))
        with mock.patch.object(MODULE, "_invoke", side_effect=self.fake_invoke):
            first, _ = MODULE.run_pipeline(self.spec_path)
        self.assertEqual(first["status"], "needs-agent")
        self.write_external_source_analysis("torch_npu")
        self.invocations.clear()
        with mock.patch.object(MODULE, "_invoke", side_effect=self.fake_invoke):
            second, code = MODULE.run_pipeline(self.spec_path, resume=True)
        self.assertEqual(code, 3)
        self.assertEqual(second["stages"]["source_causality"]["status"], "needs-agent")
        self.assertIn("conflict", second["stages"]["source_causality"]["reason"])
        self.assertFalse(
            any(script_name(command) == "render_python_guard_snapshots.py" for command in self.invocations)
        )

    def test_manifest_contract_hash_mismatch_remains_needs_agent(self) -> None:
        self.write_spec()
        with mock.patch.object(MODULE, "_invoke", side_effect=self.fake_invoke):
            first, _ = MODULE.run_pipeline(self.spec_path)
        self.assertEqual(first["status"], "needs-agent")
        self.write_external_source_analysis("pytorch")
        manifest_path = (
            self.output / "evidence" / "source-causality" / "source_analysis_manifest.json"
        )
        manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
        manifest["run_comparability"]["sha256"] = "0" * 64
        manifest_path.write_text(json.dumps(manifest), encoding="utf-8")
        self.invocations.clear()
        with mock.patch.object(MODULE, "_invoke", side_effect=self.fake_invoke):
            second, code = MODULE.run_pipeline(self.spec_path, resume=True)
        self.assertEqual(code, 3)
        self.assertEqual(second["stages"]["source_causality"]["status"], "needs-agent")
        self.assertIn("SHA", second["stages"]["source_causality"]["reason"])
        self.assertFalse(
            any(
                script_name(command) == "render_python_guard_snapshots.py"
                for command in self.invocations
            )
        )

    def test_source_and_snapshot_tampering_cannot_reuse_complete_state(self) -> None:
        self.write_spec()
        with mock.patch.object(MODULE, "_invoke", side_effect=self.fake_invoke):
            MODULE.run_pipeline(self.spec_path)
        self.write_external_source_analysis("torch_npu")
        with mock.patch.object(MODULE, "_invoke", side_effect=self.fake_invoke):
            final, code = MODULE.run_pipeline(self.spec_path, resume=True)
        self.assertEqual((final["status"], code), ("complete", 0))

        source_evidence = (
            self.output / "evidence" / "source-causality" / "source_evidence.csv"
        )
        source_evidence.write_text("tampered\n", encoding="utf-8")
        status, status_code = MODULE.status_payload(self.spec_path)
        self.assertEqual((status["status"], status_code), ("stale", 1))
        self.assertIn("source_causality", status["stale_stages"])
        with mock.patch.object(MODULE, "_invoke", side_effect=self.fake_invoke):
            blocked, blocked_code = MODULE.run_pipeline(self.spec_path, resume=True)
        self.assertEqual((blocked["status"], blocked_code), ("needs-agent", 3))

        self.write_external_source_analysis("torch_npu")
        with mock.patch.object(MODULE, "_invoke", side_effect=self.fake_invoke):
            restored, restored_code = MODULE.run_pipeline(self.spec_path, resume=True)
        self.assertEqual((restored["status"], restored_code), ("complete", 0))
        snapshot_md = (
            self.output
            / "evidence"
            / "python-guard-snapshots"
            / "python_guard_snapshots.md"
        )
        snapshot_md.write_text("tampered snapshot\n", encoding="utf-8")
        with mock.patch.object(MODULE, "_invoke", side_effect=self.fake_invoke):
            snapshot_blocked, snapshot_code = MODULE.run_pipeline(
                self.spec_path, resume=True
            )
        self.assertEqual(
            (snapshot_blocked["status"], snapshot_code), ("complete", 0)
        )
        self.assertIn(
            "deterministically rebuilt",
            snapshot_blocked["stages"]["source_causality"]["reason"],
        )
        self.assertEqual(snapshot_md.read_text(encoding="utf-8"), "# snapshot\n")

    def test_analyzed_python_change_invalidates_source_even_if_entrypoint_output_is_same(self) -> None:
        self.write_spec()
        with mock.patch.object(MODULE, "_invoke", side_effect=self.fake_invoke):
            MODULE.run_pipeline(self.spec_path)
        self.write_external_source_analysis("model")
        with mock.patch.object(MODULE, "_invoke", side_effect=self.fake_invoke):
            complete, complete_code = MODULE.run_pipeline(self.spec_path, resume=True)
        self.assertEqual((complete["status"], complete_code), ("complete", 0))

        tracked = self.model / "tracked_guard.py"
        tracked.write_text(
            tracked.read_text(encoding="utf-8") + "\n# changed after AST analysis\n",
            encoding="utf-8",
        )
        status, status_code = MODULE.status_payload(self.spec_path)
        self.assertEqual((status["status"], status_code), ("stale", 1))
        self.assertIn("source_causality", status["stale_stages"])

        self.invocations.clear()
        with mock.patch.object(MODULE, "_invoke", side_effect=self.fake_invoke):
            blocked, blocked_code = MODULE.run_pipeline(self.spec_path, resume=True)
        self.assertEqual((blocked["status"], blocked_code), ("needs-agent", 3))
        self.assertIn(
            "AST source content changed: tracked_guard.py",
            blocked["stages"]["source_causality"]["reason"],
        )
        invoked = [script_name(item) for item in self.invocations]
        self.assertIn("resolve_source_entrypoints.py", invoked)
        self.assertNotIn("render_python_guard_snapshots.py", invoked)

    def test_git_head_ref_change_invalidates_completed_source_binding(self) -> None:
        git = self.torch_npu / ".git"
        ref = git / "refs" / "heads" / "main"
        ref.parent.mkdir(parents=True)
        (git / "HEAD").write_text("ref: refs/heads/main\n", encoding="utf-8")
        (git / "index").write_bytes(b"index-v1")
        ref.write_text("1" * 40 + "\n", encoding="utf-8")
        self.write_spec()
        with mock.patch.object(MODULE, "_invoke", side_effect=self.fake_invoke):
            MODULE.run_pipeline(self.spec_path)
        self.write_external_source_analysis("torch_npu")
        with mock.patch.object(MODULE, "_invoke", side_effect=self.fake_invoke):
            complete, complete_code = MODULE.run_pipeline(self.spec_path, resume=True)
        self.assertEqual((complete["status"], complete_code), ("complete", 0))

        ref.write_text("2" * 40 + "\n", encoding="utf-8")
        status, status_code = MODULE.status_payload(self.spec_path)
        self.assertEqual((status["status"], status_code), ("stale", 1))
        self.assertIn("source_causality", status["stale_stages"])
        with mock.patch.object(MODULE, "_invoke", side_effect=self.fake_invoke):
            blocked, blocked_code = MODULE.run_pipeline(self.spec_path, resume=True)
        self.assertEqual((blocked["status"], blocked_code), ("needs-agent", 3))
        self.assertIn(
            "source-causality inputs changed",
            blocked["stages"]["source_causality"]["reason"],
        )

    def test_recursive_inventory_changes_when_nested_trace_changes(self) -> None:
        nested = self.real / "rank_0"
        nested.mkdir()
        trace = nested / "trace_view.json"
        trace.write_text("[]", encoding="utf-8")
        before = MODULE._directory_inventory(self.real)
        trace.write_text("[{}]", encoding="utf-8")
        after = MODULE._directory_inventory(self.real)
        self.assertNotEqual(before["sha256"], after["sha256"])

    def test_child_environment_isolated_and_script_allowlisted(self) -> None:
        command = MODULE.python_command("align_profiles.py", "--help")
        self.assertEqual(command[1], "-I")
        with self.assertRaisesRegex(MODULE.PipelineError, "allowlisted"):
            MODULE.sibling_script("train.sh")
        captured = {}

        def fake_subprocess(command, **kwargs):  # noqa: ANN001
            captured.update(kwargs)
            return mock.Mock(returncode=0, stdout="", stderr="")

        env = os.environ.copy()
        env["PYTHONPATH"] = "unsafe"
        env["PYTHONHOME"] = "unsafe"
        env["NODE_OPTIONS"] = "--require=work-root/evil.js"
        env["NODE_PATH"] = "work-root/node_modules"
        with mock.patch.object(MODULE.subprocess, "run", side_effect=fake_subprocess):
            MODULE._invoke(command, self.work, env)
        child_env = captured["env"]
        self.assertNotIn("PYTHONPATH", child_env)
        self.assertNotIn("PYTHONHOME", child_env)
        self.assertNotIn("NODE_OPTIONS", child_env)
        self.assertNotIn("NODE_PATH", child_env)
        self.assertEqual(child_env["PYTHONNOUSERSITE"], "1")
        self.assertEqual(child_env["PYTHONDONTWRITEBYTECODE"], "1")
        displayed = MODULE.command_display(["python", "path/with$(x);&name.py"])
        if os.name == "nt":
            self.assertEqual(displayed, "& 'python' 'path/with$(x);&name.py'")
        else:
            self.assertIn("'path/with$(x);&name.py'", displayed)

    def test_trusted_git_and_node_skip_work_root_path_hijacks(self) -> None:
        malicious = self.work / "bin"
        trusted = self.root / "trusted-bin"
        malicious.mkdir()
        trusted.mkdir()
        if os.name == "nt":
            names = ("git.cmd", "node.cmd", "browser.cmd")
            body = "@exit /b 0\n"
        else:
            names = ("git", "node", "browser")
            body = "#!/bin/sh\nexit 0\n"
        for directory in (malicious, trusted):
            for name in names:
                executable = directory / name
                executable.write_text(body, encoding="utf-8")
                if os.name != "nt":
                    executable.chmod(0o755)
        playwright = self.root / "node-modules"
        playwright.mkdir()
        raw = self.raw_spec(
            runtime={"git": "git"},
            perfetto={
                "online_authorized": True,
                "node": "node",
                "browser": "browser",
                "playwright_node_modules": str(playwright),
            },
        )
        raw.pop("perfetto_online_authorized")
        path = os.pathsep.join((str(malicious), str(trusted)))
        with mock.patch.dict(os.environ, {"PATH": path}, clear=False):
            spec, _ = self.normalized(raw)
        expected_git = trusted / names[0]
        expected_node = trusted / names[1]
        expected_browser = trusted / names[2]
        self.assertEqual(Path(spec["runtime"]["git"]), expected_git.resolve())
        self.assertEqual(Path(spec["perfetto"]["node"]), expected_node.resolve())
        self.assertEqual(Path(spec["perfetto"]["browser"]), expected_browser.resolve())

        raw["runtime"] = {"git": str(malicious / names[0])}
        with self.assertRaisesRegex(MODULE.SpecError, "outside all analysis"):
            self.normalized(raw)
        raw["runtime"] = {"git": str(expected_git)}
        raw["perfetto"]["browser"] = str(malicious / names[2])  # type: ignore[index]
        with self.assertRaisesRegex(MODULE.SpecError, "outside all analysis"):
            self.normalized(raw)

    def test_online_perfetto_rejects_dependency_root_inside_work_root(self) -> None:
        modules = self.work / "node-modules"
        modules.mkdir()
        raw = self.raw_spec(
            perfetto={
                "online_authorized": True,
                "node": str(Path(sys.executable).resolve()),
                "playwright_node_modules": str(modules),
            }
        )
        raw.pop("perfetto_online_authorized")
        with self.assertRaisesRegex(MODULE.SpecError, "outside all analysis"):
            self.normalized(raw)

    def test_online_perfetto_requires_explicit_trusted_browser(self) -> None:
        playwright = self.root / "trusted-online-modules"
        playwright.mkdir()
        raw = self.raw_spec(
            perfetto={
                "online_authorized": True,
                "node": str(Path(sys.executable).resolve()),
                "playwright_node_modules": str(playwright),
            }
        )
        raw.pop("perfetto_online_authorized")
        with self.assertRaisesRegex(MODULE.SpecError, "perfetto.browser is required"):
            self.normalized(raw)

    def test_runtime_blocking_checks_stop_before_profile_parsing(self) -> None:
        self.write_spec()

        def blocked_runtime(command, cwd, env=None):  # noqa: ANN001
            if script_name(list(command)) == "runtime_doctor.py":
                output = Path(argument(list(command), "--output-root")) / "evidence" / "runtime"
                output.mkdir(parents=True, exist_ok=True)
                (output / "runtime_doctor.json").write_text(
                    json.dumps(
                        {
                            "schema_version": 1,
                            "status": "blocked",
                            "blocking_checks": ["git"],
                        }
                    ),
                    encoding="utf-8",
                )
                self.invocations.append(list(command))
                return MODULE.Invocation(1, "", "git unavailable")
            return self.fake_invoke(command, cwd, env)

        with mock.patch.object(MODULE, "_invoke", side_effect=blocked_runtime):
            with self.assertRaisesRegex(MODULE.PipelineError, "blocking prerequisites"):
                MODULE.run_pipeline(self.spec_path)
        state = json.loads(
            (self.output / "evidence" / "pipeline" / "run-state.json").read_text(
                encoding="utf-8"
            )
        )
        self.assertEqual(state["stages"]["runtime"]["status"], "failed")
        self.assertNotIn(
            "preflight_ascend_profiles.py",
            [script_name(item) for item in self.invocations],
        )

    def test_profile_inventory_rejects_nested_link_or_reparse(self) -> None:
        nested = self.real / "rank_0"
        nested.mkdir()
        trace = nested / "trace_view.json"
        trace.write_text("[]", encoding="utf-8")
        original = MODULE._is_link_or_reparse

        def classify(path):  # noqa: ANN001
            return Path(path) == trace or original(Path(path))

        with mock.patch.object(MODULE, "_is_link_or_reparse", side_effect=classify):
            with self.assertRaisesRegex(MODULE.PipelineError, "symlink/reparse"):
                MODULE._directory_inventory(self.real, reject_links=True)

    def test_untracked_files_make_terminal_stage_stale(self) -> None:
        self.write_spec()
        with mock.patch.object(MODULE, "_invoke", side_effect=self.fake_invoke):
            MODULE.run_pipeline(self.spec_path)
        self.write_external_source_analysis("torch_npu")
        with mock.patch.object(MODULE, "_invoke", side_effect=self.fake_invoke):
            final, code = MODULE.run_pipeline(self.spec_path, resume=True)
        self.assertEqual((final["status"], code), ("complete", 0))
        extra = self.output / "evidence" / "report-validation" / "stale.csv"
        extra.write_text("stale\n", encoding="utf-8")
        status, status_code = MODULE.status_payload(self.spec_path)
        self.assertEqual((status["status"], status_code), ("stale", 1))
        self.assertIn("validator", status["stale_stages"])

    def test_perfetto_child_artifact_tamper_is_stale_and_rerun(self) -> None:
        self.write_spec()
        with mock.patch.object(MODULE, "_invoke", side_effect=self.fake_invoke):
            MODULE.run_pipeline(self.spec_path)
        self.write_external_source_analysis("torch_npu")
        with mock.patch.object(MODULE, "_invoke", side_effect=self.fake_invoke):
            final, code = MODULE.run_pipeline(self.spec_path, resume=True)
        self.assertEqual((final["status"], code), ("complete", 0))
        child = self.output / "evidence" / "perfetto-review" / "jobs" / "rank-0.html"
        child.write_text("tampered\n", encoding="utf-8")
        status, status_code = MODULE.status_payload(self.spec_path)
        self.assertEqual((status["status"], status_code), ("stale", 1))
        self.assertIn("perfetto", status["stale_stages"])
        self.invocations.clear()
        with mock.patch.object(MODULE, "_invoke", side_effect=self.fake_invoke):
            repaired, repaired_code = MODULE.run_pipeline(self.spec_path, resume=True)
        self.assertEqual((repaired["status"], repaired_code), ("complete", 0))
        self.assertIn(
            "render_perfetto_batch.py",
            [script_name(command) for command in self.invocations],
        )


if __name__ == "__main__":
    unittest.main()

from __future__ import annotations

import contextlib
import hashlib
import importlib.util
import io
import json
import os
import shutil
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path
from unittest import mock


ROOT = Path(__file__).resolve().parents[1]


def load_module(name: str, path: Path):
    spec = importlib.util.spec_from_file_location(name, path)
    assert spec and spec.loader
    module = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = module
    spec.loader.exec_module(module)
    return module


DOCTOR = load_module("runtime_doctor_tested", ROOT / "scripts" / "runtime_doctor.py")
BATCH = load_module("render_perfetto_batch_tested", ROOT / "scripts" / "render_perfetto_batch.py")
RENDERER = ROOT / "scripts" / "render_perfetto_trace.mjs"


def make_node_modules(root: Path) -> Path:
    modules = root / "trusted" / "node_modules"
    package = modules / "playwright-core"
    package.mkdir(parents=True)
    (package / "package.json").write_text(
        json.dumps({"name": "playwright-core", "version": "1.2.3"}), encoding="utf-8"
    )
    return modules.resolve()


def make_alignment(root: Path) -> Path:
    alignment = root / "alignment"
    lane_dir = alignment / "perfetto_inputs" / "rank-0000"
    lane_dir.mkdir(parents=True)
    trace = root / "trace_view.json"
    trace.write_text("[]", encoding="utf-8")
    trace_sha = hashlib.sha256(b"[]").hexdigest()
    BATCH.write_csv(
        alignment / "rank_pairs.csv",
        [
            {
                "rank_pair_id": "rank-0000",
                "real_trace_path": str(trace),
                "sim_trace_path": str(trace),
                "real_trace_sha256": trace_sha,
                "sim_trace_sha256": trace_sha,
            }
        ],
    )
    lane = {
        "schema_version": 1,
        "lanes": [{"pid": 1, "tid": 2, "renderer_compatible": True, "lane_id": "main"}],
    }
    BATCH.write_json(lane_dir / "real_host_lanes.json", lane)
    BATCH.write_json(lane_dir / "sim_host_lanes.json", lane)
    return alignment


class RuntimeDoctorTests(unittest.TestCase):
    def test_bare_program_never_resolves_from_work_root(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory).resolve()
            suffix = ".cmd" if os.name == "nt" else ""
            local_program = root / f"git{suffix}"
            local_program.write_text("echo must-not-run\n", encoding="utf-8")
            if os.name != "nt":
                local_program.chmod(0o755)
            previous = Path.cwd()
            try:
                os.chdir(root)
                with mock.patch.dict(
                    os.environ,
                    {
                        "PATH": str(root),
                        "PATHEXT": ".COM;.EXE;.BAT;.CMD",
                    },
                    clear=False,
                ):
                    self.assertIsNone(DOCTOR._resolve_program("git"))
                    self.assertIsNone(DOCTOR._resolve_program(f".{os.sep}git{suffix}"))
                    self.assertIsNone(DOCTOR._resolve_program(str(local_program)))
            finally:
                os.chdir(previous)

    def test_command_probe_removes_all_ambient_node_variables(self) -> None:
        completed = subprocess.CompletedProcess(
            [], 0, stdout="runtime 1.0\n", stderr=""
        )
        with mock.patch.dict(
            os.environ,
            {
                "NODE_OPTIONS": "--require=work-root/evil.js",
                "NODE_PATH": "work-root/node_modules",
                "NODE_EXTRA_CA_CERTS": "work-root/cert.pem",
            },
            clear=False,
        ), mock.patch.object(
            DOCTOR.subprocess, "run", return_value=completed
        ) as run:
            result = DOCTOR.check_command("node", str(Path(sys.executable).resolve()))
        self.assertEqual(result["status"], "pass")
        probe_environment = run.call_args.kwargs["env"]
        self.assertFalse(
            any(name.upper().startswith("NODE_") for name in probe_environment)
        )

    def test_offline_run_spec_does_not_require_perfetto_runtime(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            output_root = root / "result"
            spec = root / "alignment-run.json"
            spec.write_text(
                json.dumps(
                    {
                        "schema_version": 1,
                        "work_root": str(root),
                        "profiles": {"real": "real", "sim": "sim"},
                        "output_root": str(output_root),
                        "perfetto": {"online_authorized": False},
                    }
                ),
                encoding="utf-8",
            )
            stdout = io.StringIO()
            with contextlib.redirect_stdout(stdout):
                return_code = DOCTOR.main(
                    [
                        "--spec",
                        str(spec),
                        "--node",
                        "definitely-missing-node",
                        "--git",
                        sys.executable,
                        "--min-free-gib",
                        "0",
                    ]
                )
            self.assertEqual(return_code, 0, stdout.getvalue())
            report = json.loads(stdout.getvalue())
            self.assertEqual(report["status"], "ready")
            self.assertFalse(report["perfetto_online_authorized"])
            self.assertEqual(report["blocking_checks"], [])
            self.assertEqual(
                set(report["optional_unavailable_checks"]),
                {"node", "playwright_node_modules", "browser"},
            )

    def test_run_spec_ready_and_fixed_json_artifact(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            modules = make_node_modules(root)
            output_root = root / "result"
            spec = root / "alignment-run.json"
            spec.write_text(
                json.dumps(
                    {
                        "schema_version": 1,
                        "work_root": str(root),
                        "source_roots": {
                            "model": {"path": str(root / "MindSpeed")},
                            "pytorch": str(root / "torch"),
                            "torch_npu": {"path": str(root / "torch_npu")},
                        },
                        "entry_sh": ["train.sh"],
                        "profiles": {"real": "real", "sim": "sim"},
                        "output_root": str(output_root),
                        "perfetto": {
                            "node": sys.executable,
                            "playwright_node_modules": str(modules),
                            "browser": sys.executable,
                        },
                    }
                ),
                encoding="utf-8",
            )
            stdout = io.StringIO()
            with contextlib.redirect_stdout(stdout):
                return_code = DOCTOR.main(
                    ["--spec", str(spec), "--git", sys.executable, "--min-free-gib", "0"]
                )
            self.assertEqual(return_code, 0, stdout.getvalue())
            console_report = json.loads(stdout.getvalue())
            report_path = output_root / "evidence" / "runtime" / "runtime_doctor.json"
            self.assertTrue(report_path.is_file())
            file_report = json.loads(report_path.read_text(encoding="utf-8"))
            self.assertEqual(console_report, file_report)
            self.assertEqual(file_report["status"], "ready")
            self.assertTrue(file_report["offline"])
            self.assertFalse(file_report["network_access_performed"])
            self.assertFalse(file_report["install_performed"])
            self.assertEqual(file_report["blocking_checks"], [])
            self.assertEqual(
                file_report["checks"]["playwright_node_modules"]["resolved"], str(modules)
            )

    def test_standalone_missing_perfetto_paths_is_blocked_but_reported(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            output_root = Path(directory) / "output"
            stdout = io.StringIO()
            with contextlib.redirect_stdout(stdout):
                return_code = DOCTOR.main(
                    [
                        "--output-root",
                        str(output_root),
                        "--node",
                        sys.executable,
                        "--git",
                        sys.executable,
                        "--min-free-gib",
                        "0",
                    ]
                )
            self.assertEqual(return_code, 1)
            report = json.loads(stdout.getvalue())
            self.assertEqual(report["status"], "blocked")
            self.assertIn("playwright_node_modules", report["blocking_checks"])
            self.assertIn("browser", report["blocking_checks"])
            self.assertTrue(
                (output_root / "evidence" / "runtime" / "runtime_doctor.json").is_file()
            )

    def test_playwright_root_must_be_explicit_absolute_directory(self) -> None:
        result = DOCTOR.check_playwright_node_modules("relative/node_modules")
        self.assertEqual(result["status"], "blocked")
        self.assertIn("absolute", result["reason"])

    def test_output_check_does_not_create_probe(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            target = Path(directory) / "not-created-yet"
            result = DOCTOR.check_output(target, 0)
            self.assertEqual(result["status"], "pass")
            self.assertFalse(target.exists())
            self.assertIn("no probe file", result["write_probe"])


class PerfettoDependencyPortabilityTests(unittest.TestCase):
    def test_cli_root_precedes_environment_and_environment_is_fallback(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            explicit = make_node_modules(root / "explicit")
            fallback = make_node_modules(root / "fallback")
            resolved, source = BATCH.resolve_playwright_node_modules(
                str(explicit), {BATCH.PLAYWRIGHT_NODE_MODULES_ENV: str(fallback)}
            )
            self.assertEqual(resolved, str(explicit))
            self.assertEqual(source, "--playwright-node-modules")
            resolved, source = BATCH.resolve_playwright_node_modules(
                "", {BATCH.PLAYWRIGHT_NODE_MODULES_ENV: str(fallback)}
            )
            self.assertEqual(resolved, str(fallback))
            self.assertEqual(source, BATCH.PLAYWRIGHT_NODE_MODULES_ENV)

    def test_relative_or_package_less_root_is_rejected(self) -> None:
        with self.assertRaisesRegex(ValueError, "absolute"):
            BATCH.resolve_playwright_node_modules("relative/node_modules", {})
        with tempfile.TemporaryDirectory() as directory:
            with self.assertRaisesRegex(ValueError, "neither playwright-core nor playwright"):
                BATCH.resolve_playwright_node_modules(str(Path(directory).resolve()), {})

    def test_batch_forwards_trusted_root_and_removes_node_path(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            modules = make_node_modules(root)
            alignment = make_alignment(root)
            node = root / ("node.exe" if os.name == "nt" else "node")
            node.write_bytes(b"")
            browser = root / ("browser.exe" if os.name == "nt" else "browser")
            browser.write_bytes(b"")
            if os.name != "nt":
                node.chmod(0o700)
                browser.chmod(0o700)
            fake_result = subprocess.CompletedProcess([], 1, stdout="", stderr="expected")
            with mock.patch.dict(
                os.environ,
                {
                    "NODE_PATH": str(root / "untrusted"),
                    "NODE_OPTIONS": f"--require={root / 'evil.js'}",
                    BATCH.PLAYWRIGHT_NODE_MODULES_ENV: "stale",
                },
                clear=False,
            ), mock.patch.object(BATCH.subprocess, "run", return_value=fake_result) as run:
                manifest = BATCH.run_batch(
                    alignment,
                    root / "output",
                    RENDERER,
                    str(node.resolve()),
                    str(browser.resolve()),
                    str(modules),
                    5_000,
                    False,
                    128,
                    False,
                    "",
                    True,
                )
            self.assertEqual(run.call_count, 2)
            command = run.call_args_list[0].args[0]
            child_environment = run.call_args_list[0].kwargs["env"]
            option_index = command.index("--playwright-node-modules")
            self.assertEqual(command[option_index + 1], str(modules))
            self.assertEqual(command[0], str(node.resolve()))
            self.assertEqual(command[command.index("--browser") + 1], str(browser.resolve()))
            self.assertIn("--online-authorized", command)
            self.assertEqual(
                child_environment[BATCH.PLAYWRIGHT_NODE_MODULES_ENV], str(modules)
            )
            self.assertNotIn("NODE_PATH", child_environment)
            self.assertNotIn("NODE_OPTIONS", child_environment)
            self.assertFalse(
                any(name.upper().startswith("NODE_") for name in child_environment)
            )
            self.assertEqual(manifest["playwright_node_modules"], str(modules))
            self.assertEqual(
                manifest["playwright_node_modules_source"], "--playwright-node-modules"
            )

    def test_online_batch_rejects_bare_node_before_starting_child(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            modules = make_node_modules(root)
            with mock.patch.object(BATCH.subprocess, "run") as run:
                with self.assertRaisesRegex(ValueError, "absolute executable"):
                    BATCH.run_batch(
                        make_alignment(root),
                        root / "output",
                        RENDERER,
                        "node",
                        "",
                        str(modules),
                        5_000,
                        False,
                        128,
                        False,
                        "",
                        True,
                    )
            run.assert_not_called()

    def test_unauthorized_default_stays_not_executed_without_dependencies(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            manifest = BATCH.run_batch(
                make_alignment(root),
                root / "output",
                RENDERER,
                "node",
                "",
                "",
                5_000,
                False,
                128,
                False,
                "",
                False,
            )
            self.assertEqual(manifest["status"], "partial")
            self.assertFalse(manifest["online_authorized"])
            self.assertEqual(manifest["execution_mode"], "not-executed")
            self.assertTrue(manifest["execution_block_reason"])
            self.assertTrue(
                all(row["run_status"] == "not-executed" for row in manifest["jobs"])
            )

    def test_unauthorized_ignores_invalid_ambient_playwright_root(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            with mock.patch.dict(
                os.environ,
                {BATCH.PLAYWRIGHT_NODE_MODULES_ENV: "relative-and-invalid"},
                clear=False,
            ):
                manifest = BATCH.run_batch(
                    make_alignment(root),
                    root / "output",
                    RENDERER,
                    "node",
                    "",
                    "",
                    5_000,
                    False,
                    128,
                    False,
                    "",
                    False,
                )
            self.assertEqual(manifest["execution_mode"], "not-executed")
            self.assertEqual(manifest["playwright_node_modules_source"], "not-required")

    def test_unauthorized_cli_records_evidence_and_returns_success(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            output = root / "output"
            stdout = io.StringIO()
            with contextlib.redirect_stdout(stdout):
                return_code = BATCH.main(
                    [
                        "--alignment-output",
                        str(make_alignment(root)),
                        "--output",
                        str(output),
                    ]
                )
            self.assertEqual(return_code, 0, stdout.getvalue())
            review = json.loads(
                (output / "perfetto_content_review.json").read_text(encoding="utf-8")
            )
            self.assertEqual(review["status"], "not-executed")

    def test_node_renderer_help_and_syntax(self) -> None:
        node = shutil.which("node")
        if not node:
            self.skipTest("Node.js is unavailable")
        checked = subprocess.run(
            [node, "--check", str(RENDERER)], capture_output=True, text=True, check=False
        )
        self.assertEqual(checked.returncode, 0, checked.stderr)
        helped = subprocess.run(
            [node, str(RENDERER), "--help"], capture_output=True, text=True, check=False
        )
        self.assertEqual(helped.returncode, 0, helped.stderr)
        self.assertIn("--playwright-node-modules", helped.stdout)
        self.assertIn("--online-authorized", helped.stdout)
        denied = subprocess.run(
            [node, str(RENDERER)], capture_output=True, text=True, check=False
        )
        self.assertNotEqual(denied.returncode, 0)
        self.assertIn("not authorized", denied.stderr)
        source = RENDERER.read_text(encoding="utf-8")
        self.assertNotIn("npm install", source)
        self.assertNotIn("codex-host", source)
        self.assertNotIn("CODEX_QUERY_AUDIT", source)


if __name__ == "__main__":
    unittest.main()

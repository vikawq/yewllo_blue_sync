from __future__ import annotations

import contextlib
import importlib.util
import io
import json
import os
import subprocess
import sys
import tempfile
import threading
import unittest
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from unittest import mock
from urllib.parse import urlsplit


SCRIPT = Path(__file__).resolve().parents[1] / "scripts" / "prepare_source_checkout.py"
SPEC = importlib.util.spec_from_file_location("prepare_source_checkout", SCRIPT)
assert SPEC and SPEC.loader
CHECKOUT = importlib.util.module_from_spec(SPEC)
sys.modules[SPEC.name] = CHECKOUT
SPEC.loader.exec_module(CHECKOUT)


def run_command(args: list[str], *, cwd: Path | None = None) -> str:
    result = subprocess.run(
        args,
        cwd=cwd,
        capture_output=True,
        text=True,
        encoding="utf-8",
        errors="replace",
        check=False,
    )
    if result.returncode != 0:
        raise AssertionError(
            f"command failed ({result.returncode}): {args!r}\nstdout={result.stdout}\nstderr={result.stderr}"
        )
    return result.stdout.strip()


def make_git_http_handler(git_root: Path) -> type[BaseHTTPRequestHandler]:
    class GitHttpHandler(BaseHTTPRequestHandler):
        server_version = "LocalGitHTTP/1.0"

        def do_GET(self) -> None:  # noqa: N802
            self._serve_git()

        def do_POST(self) -> None:  # noqa: N802
            self._serve_git()

        def do_HEAD(self) -> None:  # noqa: N802
            self._serve_git(head_only=True)

        def _serve_git(self, *, head_only: bool = False) -> None:
            parsed = urlsplit(self.path)
            content_length = int(self.headers.get("Content-Length", "0") or 0)
            request_body = self.rfile.read(content_length) if content_length else b""
            env = os.environ.copy()
            env.update(
                {
                    "GIT_PROJECT_ROOT": str(git_root),
                    "GIT_HTTP_EXPORT_ALL": "1",
                    "PATH_INFO": parsed.path,
                    "QUERY_STRING": parsed.query,
                    "REQUEST_METHOD": self.command,
                    "CONTENT_TYPE": self.headers.get("Content-Type", ""),
                    "CONTENT_LENGTH": str(content_length),
                    "REMOTE_ADDR": self.client_address[0],
                    "REMOTE_USER": "",
                    "SERVER_NAME": self.server.server_address[0],
                    "SERVER_PORT": str(self.server.server_address[1]),
                    "SERVER_PROTOCOL": self.request_version,
                    "HTTP_GIT_PROTOCOL": self.headers.get("Git-Protocol", ""),
                }
            )
            result = subprocess.run(
                ["git", "http-backend"],
                input=request_body,
                capture_output=True,
                env=env,
                check=False,
            )
            if result.returncode != 0:
                self.send_error(500, result.stderr.decode("utf-8", errors="replace")[:200])
                return
            raw = result.stdout
            marker = b"\r\n\r\n"
            if marker in raw:
                header_blob, response_body = raw.split(marker, 1)
            elif b"\n\n" in raw:
                header_blob, response_body = raw.split(b"\n\n", 1)
            else:
                self.send_error(500, "git http-backend emitted no CGI headers")
                return
            status = 200
            headers: list[tuple[str, str]] = []
            for raw_line in header_blob.replace(b"\r", b"").split(b"\n"):
                if not raw_line:
                    continue
                key, separator, value = raw_line.decode("iso-8859-1").partition(":")
                if not separator:
                    continue
                if key.lower() == "status":
                    status = int(value.strip().split(" ", 1)[0])
                else:
                    headers.append((key.strip(), value.strip()))
            self.send_response(status)
            for key, value in headers:
                self.send_header(key, value)
            self.end_headers()
            if not head_only:
                self.wfile.write(response_body)

        def log_message(self, _format: str, *_args: object) -> None:
            return

    return GitHttpHandler


class LocalGitOrigin:
    def __init__(self) -> None:
        self.temporary = tempfile.TemporaryDirectory()
        self.root = Path(self.temporary.name)
        self.work = self.root / "work"
        self.http_root = self.root / "http"
        self.bare = self.http_root / "origin.git"
        self.http_root.mkdir(parents=True)

        run_command(["git", "init", str(self.work)])
        run_command(["git", "config", "user.name", "Checkout Test"], cwd=self.work)
        run_command(["git", "config", "user.email", "checkout@example.invalid"], cwd=self.work)
        run_command(["git", "checkout", "-b", "main"], cwd=self.work)
        (self.work / "src").mkdir()
        (self.work / "src" / "model.py").write_text("VALUE = 1\n", encoding="utf-8")
        (self.work / "launch.sh").write_text("python src/model.py\n", encoding="utf-8")
        run_command(["git", "add", "src/model.py", "launch.sh"], cwd=self.work)
        run_command(["git", "commit", "-m", "first"], cwd=self.work)
        self.first_commit = run_command(["git", "rev-parse", "HEAD"], cwd=self.work)
        (self.work / "src" / "model.py").write_text("VALUE = 2\n", encoding="utf-8")
        run_command(["git", "add", "src/model.py"], cwd=self.work)
        run_command(["git", "commit", "-m", "second"], cwd=self.work)
        self.second_commit = run_command(["git", "rev-parse", "HEAD"], cwd=self.work)

        run_command(["git", "clone", "--bare", str(self.work), str(self.bare)])
        run_command(["git", "symbolic-ref", "HEAD", "refs/heads/main"], cwd=self.bare)
        run_command(["git", "config", "uploadpack.allowFilter", "true"], cwd=self.bare)
        run_command(["git", "config", "uploadpack.allowAnySHA1InWant", "true"], cwd=self.bare)

        handler = make_git_http_handler(self.http_root)
        self.server = ThreadingHTTPServer(("127.0.0.1", 0), handler)
        self.thread = threading.Thread(target=self.server.serve_forever, daemon=True)
        self.thread.start()
        host, port = self.server.server_address[:2]
        self.url = f"http://{host}:{port}/origin.git"

    def close(self) -> None:
        self.server.shutdown()
        self.server.server_close()
        self.thread.join(timeout=5)
        self.temporary.cleanup()


class PrepareSourceCheckoutTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls) -> None:
        cls.origin = LocalGitOrigin()

    @classmethod
    def tearDownClass(cls) -> None:
        cls.origin.close()

    def call_main(self, args: list[str]) -> tuple[int, str, str]:
        stdout = io.StringIO()
        stderr = io.StringIO()
        with contextlib.redirect_stdout(stdout), contextlib.redirect_stderr(stderr):
            code = CHECKOUT.main(args)
        return code, stdout.getvalue(), stderr.getvalue()

    def test_blob_url_parser_for_supported_providers(self) -> None:
        cases = [
            (
                "https://github.com/acme/model/blob/main/src/model.py#L7",
                "https://github.com/acme/model.git",
                "main",
                "src/model.py",
            ),
            (
                "https://gitcode.com/acme/model/blob/release/launch.sh",
                "https://gitcode.com/acme/model.git",
                "release",
                "launch.sh",
            ),
            (
                "https://gitlab.com/group/sub/model/-/blob/v1/src/model.py?plain=1",
                "https://gitlab.com/group/sub/model.git",
                "v1",
                "src/model.py",
            ),
        ]
        for source, repository, ref, entry in cases:
            with self.subTest(source=source):
                parsed = CHECKOUT.parse_source_url(source)
                self.assertEqual(parsed.repository_url, repository)
                self.assertEqual(parsed.url_ref, ref)
                self.assertEqual(parsed.entry_path, entry)
                self.assertEqual(parsed.kind, "file")

    def test_fixed_commit_creates_clean_detached_checkout(self) -> None:
        trusted_git = CHECKOUT.resolve_git_executable(forbidden_roots=[Path.cwd()])
        with tempfile.TemporaryDirectory() as temp:
            output = Path(temp) / "checkout"
            output.mkdir()
            code, stdout, stderr = self.call_main(
                [
                    "--source-url",
                    self.origin.url,
                    "--output",
                    str(output),
                    "--commit",
                    self.origin.first_commit,
                    "--entry",
                    "src/model.py",
                    "--git-executable",
                    str(trusted_git),
                    "--work-root",
                    str(Path(temp)),
                ]
            )
            self.assertEqual(code, 0, stderr)
            emitted = json.loads(stdout)
            manifest = json.loads((output / "source_checkout_manifest.json").read_text(encoding="utf-8"))
            self.assertEqual(emitted, manifest)
            self.assertEqual(manifest["status"], "complete")
            self.assertEqual(manifest["binding_status"], "verified")
            self.assertEqual(manifest["resolved_head"], self.origin.first_commit)
            self.assertEqual(manifest["entry"], "src/model.py")
            self.assertTrue(manifest["entry_exists"])
            self.assertTrue(manifest["worktree_clean"])
            self.assertFalse(manifest["repository_code_executed"])
            self.assertEqual(Path(manifest["git_executable"]).resolve(), trusted_git)
            self.assertEqual(manifest["safety_policy"]["git_fsmonitor"],
                             "disabled-via-command-line-core.fsmonitor=false")
            self.assertEqual((output / "src" / "model.py").read_text(encoding="utf-8"), "VALUE = 1\n")
            self.assertEqual(run_command(["git", "rev-parse", "HEAD"], cwd=output), self.origin.first_commit)
            self.assertEqual(run_command(["git", "status", "--porcelain"], cwd=output), "")
            self.assertEqual(run_command(["git", "rev-parse", "--abbrev-ref", "HEAD"], cwd=output), "HEAD")

    def test_missing_commit_is_partial_and_unverified(self) -> None:
        with tempfile.TemporaryDirectory() as temp:
            output = Path(temp) / "checkout"
            code, _stdout, stderr = self.call_main(
                ["--source-url", self.origin.url, "--output", str(output), "--entry", "launch.sh"]
            )
            self.assertEqual(code, 0, stderr)
            manifest = json.loads((output / "source_checkout_manifest.json").read_text(encoding="utf-8"))
            self.assertEqual(manifest["status"], "partial")
            self.assertEqual(manifest["binding_status"], "unverified")
            self.assertIsNone(manifest["requested_commit"])
            self.assertEqual(manifest["resolved_head"], self.origin.second_commit)
            self.assertEqual(run_command(["git", "status", "--porcelain"], cwd=output), "")

    def test_malicious_or_non_git_urls_fail_closed(self) -> None:
        bad_urls = [
            "file:///tmp/origin.git",
            "ssh://git@example.invalid/acme/model.git",
            "https://user:pass@github.com/acme/model.git",
            "https://github.com/acme/model.git?access_token=secret",
            "https://example.invalid/not-a-git-page",
        ]
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            for index, source_url in enumerate(bad_urls):
                output = root / f"checkout-{index}"
                with self.subTest(source_url=source_url):
                    code, _stdout, _stderr = self.call_main(
                        ["--source-url", source_url, "--output", str(output)]
                    )
                    self.assertEqual(code, 2)
                    self.assertFalse((output / "source_checkout_manifest.json").exists())

    def test_existing_nonempty_output_is_preserved(self) -> None:
        with tempfile.TemporaryDirectory() as temp:
            output = Path(temp) / "checkout"
            output.mkdir()
            marker = output / "keep.txt"
            marker.write_text("keep\n", encoding="utf-8")
            code, _stdout, _stderr = self.call_main(
                ["--source-url", self.origin.url, "--output", str(output)]
            )
            self.assertEqual(code, 2)
            self.assertEqual(marker.read_text(encoding="utf-8"), "keep\n")
            self.assertEqual(list(output.iterdir()), [marker])

    def test_entry_traversal_fails_before_clone(self) -> None:
        with tempfile.TemporaryDirectory() as temp:
            output = Path(temp) / "checkout"
            code, _stdout, stderr = self.call_main(
                [
                    "--source-url",
                    self.origin.url,
                    "--output",
                    str(output),
                    "--entry",
                    "../outside.py",
                ]
            )
            self.assertEqual(code, 2)
            self.assertIn("entry", stderr)
            self.assertFalse(output.exists())

    def test_git_resolution_skips_work_root_and_relative_path_entries(self) -> None:
        trusted = CHECKOUT.resolve_git_executable(
            forbidden_roots=[Path.cwd()]
        )
        with self.assertRaises(CHECKOUT.SourceCheckoutError):
            CHECKOUT.resolve_git_executable("git", forbidden_roots=[Path.cwd()])
        with tempfile.TemporaryDirectory() as temp:
            work_root = Path(temp)
            fake_bin = work_root / "bin"
            fake_bin.mkdir()
            fake = fake_bin / ("git.exe" if os.name == "nt" else "git")
            fake.write_text("malicious placeholder\n", encoding="utf-8")
            if os.name != "nt":
                fake.chmod(0o755)
            environment = {
                "PATH": os.pathsep.join(
                    [".", str(fake_bin), str(trusted.parent)]
                )
            }
            resolved = CHECKOUT.resolve_git_executable(
                forbidden_roots=[work_root], environ=environment
            )
            self.assertEqual(resolved, trusted)
            with self.assertRaises(CHECKOUT.SourceCheckoutError):
                CHECKOUT.resolve_git_executable(
                    fake, forbidden_roots=[work_root], environ=environment
                )

    def test_all_git_subprocesses_use_absolute_hardened_argv_and_environment(self) -> None:
        trusted = CHECKOUT.resolve_git_executable(forbidden_roots=[Path.cwd()])
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            hooks = root / "hooks"
            hooks.mkdir()
            with mock.patch.dict(
                os.environ,
                {
                    "GIT_CONFIG_COUNT": "1",
                    "GIT_CONFIG_KEY_0": "core.fsmonitor",
                    "GIT_CONFIG_VALUE_0": "malicious-command",
                    "GIT_EXEC_PATH": str(root / "fake-exec-path"),
                    "SSH_ASKPASS": str(root / "malicious-askpass"),
                },
            ), mock.patch.object(CHECKOUT.subprocess, "run") as runner:
                runner.return_value = subprocess.CompletedProcess([], 0, "", "")
                CHECKOUT.run_git(
                    ["status", "--porcelain"],
                    git_executable=trusted,
                    hooks_dir=hooks,
                    cwd=root,
                )
            args, kwargs = runner.call_args
            command = args[0]
            self.assertTrue(Path(command[0]).is_absolute())
            self.assertEqual(Path(command[0]).resolve(), trusted)
            self.assertIn("core.fsmonitor=false", command)
            self.assertIn("credential.helper=", command)
            self.assertTrue(any(item.startswith("core.hooksPath=") for item in command))
            self.assertFalse(kwargs["shell"])
            environment = kwargs["env"]
            self.assertEqual(environment["GIT_CONFIG_NOSYSTEM"], "1")
            self.assertEqual(environment["GIT_CONFIG_GLOBAL"], os.devnull)
            self.assertEqual(environment["GIT_TERMINAL_PROMPT"], "0")
            self.assertEqual(environment["GIT_LFS_SKIP_SMUDGE"], "1")
            self.assertEqual(environment["GIT_OPTIONAL_LOCKS"], "0")
            self.assertNotIn("GIT_CONFIG_COUNT", environment)
            self.assertNotIn("GIT_CONFIG_KEY_0", environment)
            self.assertNotIn("GIT_CONFIG_VALUE_0", environment)
            self.assertNotIn("GIT_EXEC_PATH", environment)
            self.assertNotIn("SSH_ASKPASS", environment)


if __name__ == "__main__":
    unittest.main()

from __future__ import annotations

import re
import unittest
from pathlib import Path


SKILL_ROOT = Path(__file__).resolve().parents[1]
SKILL_MD = SKILL_ROOT / "SKILL.md"


class ClaudeSkillContractTests(unittest.TestCase):
    def test_skill_is_concise_and_uses_only_portable_frontmatter(self) -> None:
        text = SKILL_MD.read_text(encoding="utf-8")
        self.assertLessEqual(len(text.splitlines()), 170)
        match = re.match(r"\A---\n(.*?)\n---\n", text, flags=re.DOTALL)
        self.assertIsNotNone(match)
        keys = {
            line.split(":", 1)[0].strip()
            for line in match.group(1).splitlines()
            if line.strip() and not line.lstrip().startswith("#")
        }
        self.assertEqual(keys, {"name", "description"})

    def test_bundled_scripts_are_addressed_from_claude_skill_dir(self) -> None:
        text = SKILL_MD.read_text(encoding="utf-8")
        self.assertIn("${CLAUDE_SKILL_DIR}", text)
        self.assertNotRegex(text, r"(?m)^\s*python(?:3)?\s+scripts[/\\]")
        # A lone PowerShell backtick at end-of-line is a shell-specific
        # continuation. Markdown's closing triple-backtick fence is fine.
        self.assertIsNone(re.search(r"(?m)(?<!`)`[ \t]*$", text))

        for path in sorted((SKILL_ROOT / "references").glob("*.md")):
            reference = path.read_text(encoding="utf-8")
            self.assertNotRegex(
                reference,
                r"(?m)^\s*python(?:3)?\s+scripts[/\\]",
                msg=f"relative bundled-script command remains in {path.name}",
            )
            self.assertNotRegex(
                reference,
                r"(?m)(?<!`)`[ \t]*$",
                msg=f"PowerShell-only continuation remains in {path.name}",
            )

    def test_default_workflow_never_pre_authorizes_perfetto_network(self) -> None:
        text = SKILL_MD.read_text(encoding="utf-8")
        self.assertNotIn("workspace dependency discovery", text)
        self.assertNotIn("Codex/受信运行时", text)
        command_lines = [
            line.strip()
            for line in text.splitlines()
            if "profiling_alignment.py" in line
        ]
        self.assertTrue(command_lines)
        self.assertTrue(all("--online-authorized" not in line for line in command_lines))

        combined_references = "\n".join(
            path.read_text(encoding="utf-8")
            for path in sorted((SKILL_ROOT / "references").glob("*.md"))
        )
        self.assertNotIn("workspace dependency discovery", combined_references)
        self.assertNotIn("Codex/受信运行时", combined_references)

    def test_claude_entrypoint_resources_exist(self) -> None:
        expected = [
            "scripts/profiling_alignment.py",
            "scripts/runtime_doctor.py",
            "references/run-spec.md",
            "references/alignment-playbook.md",
            "references/report-contract.md",
            "references/source-causality.md",
            "references/perfetto-review.md",
        ]
        missing = [item for item in expected if not (SKILL_ROOT / item).is_file()]
        self.assertEqual(missing, [])


if __name__ == "__main__":
    unittest.main()

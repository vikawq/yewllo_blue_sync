#!/usr/bin/env node

import {createHash, randomUUID} from 'node:crypto';
import {createReadStream} from 'node:fs';
import {access, mkdir, readFile, realpath, rm, stat, writeFile} from 'node:fs/promises';
import {createServer} from 'node:http';
import {basename, delimiter, dirname, isAbsolute, relative, resolve, sep} from 'node:path';
import {createRequire} from 'node:module';

const DEFAULT_UI_URL = 'https://ui.perfetto.dev/';
const PERFETTO_UI_ORIGIN = 'https://ui.perfetto.dev';
const TRUSTED_NODE_MODULES_ENV = 'PERFETTO_PLAYWRIGHT_NODE_MODULES';
const DEFAULT_TIMEOUT_MS = 180_000;
const ARTIFACT_NAMES = {
  screenshot: 'perfetto_ui.png',
  frameHtml: 'perfetto_ui_frame.html',
  text: 'perfetto_ui_text.txt',
  browserLog: 'perfetto_browser.log',
  manifest: 'perfetto_manifest.json',
};
let preparedOutputDirForFallback = null;

function usage() {
  return `Usage:
  node render_perfetto_trace.mjs \\
    --trace <trace_view.json> --output <directory> \\
    --pid <process-id> --tid <thread-id> \\
    [--process-name <name>] [--thread-name <name>] \\
    [--ui-url <url>] [--browser <executable>] \
    [--playwright-node-modules <absolute-node_modules>] [--timeout-ms <milliseconds>]

Alternative multi-lane form: replace --pid/--tid with --lane-file <host_lanes.json>.
Add --screenshot only when Canvas color/width/geometry must be reviewed.

Required:
  --online-authorized
                Explicitly authorize loading official UI code from ${PERFETTO_UI_ORIGIN}.
  --trace       Local Chrome/Perfetto trace JSON file.
  --output      Directory for rendered HTML/text, log, manifest, and optional screenshot.
  --lane-file   JSON emitted by align_profiles.py; queries every compatible Host lane.
  --pid/--tid   Single-lane fallback when --lane-file is omitted.

Optional:
  --process-name  Additional exact process-name constraint in PerfettoSQL.
  --thread-name   Additional exact thread-name constraint in PerfettoSQL.
  --ui-url        Optional URL whose origin must be exactly ${PERFETTO_UI_ORIGIN};
                  it is canonicalized to ${DEFAULT_UI_URL}.
  --browser       Absolute Chrome/Edge executable; auto-detected when omitted.
  --playwright-node-modules
                  Explicit trusted absolute node_modules root. This takes precedence
                  over ${TRUSTED_NODE_MODULES_ENV}; no NODE_PATH or CWD lookup occurs.
  --timeout-ms    Overall UI load/render timeout (default: ${DEFAULT_TIMEOUT_MS}).
  --screenshot    Also save a Canvas screenshot. HTML/text/SQL review does not require it.

Dependency:
  Prefer --playwright-node-modules. ${TRUSTED_NODE_MODULES_ENV} is an explicit fallback.
`;
}

function parseArgs(argv) {
  const options = {};
  const valueOptions = new Set([
    '--trace', '--output', '--lane-file', '--pid', '--tid', '--process-name', '--thread-name',
    '--ui-url', '--browser', '--playwright-node-modules', '--timeout-ms',
  ]);
  for (let index = 0; index < argv.length; index += 1) {
    const arg = argv[index];
    if (arg === '--help' || arg === '-h') {
      options.help = true;
      continue;
    }
    if (arg === '--screenshot') {
      options.screenshot = true;
      continue;
    }
    if (arg === '--online-authorized') {
      options.online_authorized = true;
      continue;
    }
    if (!valueOptions.has(arg)) throw new Error(`Unknown argument: ${arg}`);
    if (index + 1 >= argv.length || argv[index + 1].startsWith('--')) {
      throw new Error(`Missing value for ${arg}`);
    }
    const key = arg.slice(2).replaceAll('-', '_');
    options[key] = argv[index + 1];
    index += 1;
  }
  return options;
}

function required(options, key) {
  const value = options[key];
  if (value === undefined || value === '') throw new Error(`Missing required --${key.replaceAll('_', '-')}`);
  return value;
}

function parseNonNegativeInteger(value, label) {
  if (!/^\d+$/.test(String(value))) throw new Error(`${label} must be a non-negative integer: ${value}`);
  const parsed = Number(value);
  if (!Number.isSafeInteger(parsed)) throw new Error(`${label} is outside JavaScript's safe integer range: ${value}`);
  return parsed;
}

function validateOptionalName(value, label) {
  if (value === undefined) return undefined;
  if (value.includes('\0')) throw new Error(`${label} cannot contain a NUL byte`);
  if (value.length > 512) throw new Error(`${label} is too long (maximum 512 characters)`);
  return value;
}

async function loadLanes(options) {
  if (!options.lane_file) {
    const pid = parseNonNegativeInteger(required(options, 'pid'), '--pid');
    const tid = parseNonNegativeInteger(required(options, 'tid'), '--tid');
    return [{
      pid,
      tid,
      process_name: validateOptionalName(options.process_name, '--process-name') ?? null,
      thread_name: validateOptionalName(options.thread_name, '--thread-name') ?? null,
      lane_id: `pid=${pid}:tid=${tid}`,
    }];
  }
  if (options.pid !== undefined || options.tid !== undefined) {
    throw new Error('--lane-file cannot be combined with --pid/--tid');
  }
  const lanePath = resolve(options.lane_file);
  const parsed = JSON.parse(await readFile(lanePath, 'utf8'));
  if (!parsed || !Array.isArray(parsed.lanes)) {
    throw new Error('--lane-file must contain a JSON object with a lanes array');
  }
  const lanes = [];
  const skipped = [];
  const seen = new Set();
  for (const [index, lane] of parsed.lanes.entries()) {
    if (lane?.renderer_compatible === false) {
      skipped.push({index, reason: 'renderer_compatible=false', lane_id: lane?.lane_id ?? null});
      continue;
    }
    try {
      const pid = parseNonNegativeInteger(String(lane?.pid ?? ''), `lanes[${index}].pid`);
      const tid = parseNonNegativeInteger(String(lane?.tid ?? ''), `lanes[${index}].tid`);
      const key = `${pid}/${tid}`;
      if (seen.has(key)) continue;
      seen.add(key);
      lanes.push({
        pid,
        tid,
        process_name: validateOptionalName(lane?.process_name ?? undefined, `lanes[${index}].process_name`) ?? null,
        thread_name: validateOptionalName(lane?.thread_name ?? undefined, `lanes[${index}].thread_name`) ?? null,
        lane_id: validateOptionalName(lane?.lane_id ?? key, `lanes[${index}].lane_id`) ?? key,
      });
    } catch (error) {
      skipped.push({index, reason: error.message, lane_id: lane?.lane_id ?? null});
    }
  }
  if (!lanes.length) throw new Error('--lane-file has no compatible numeric PID/TID Host lanes');
  if (lanes.length > 128) {
    throw new Error('--lane-file has more than 128 compatible lanes; split it into deterministic batches');
  }
  lanes.skipped = skipped;
  lanes.source_path = lanePath;
  return lanes;
}

function normalizeUiUrl(value) {
  const parsed = new URL(value || DEFAULT_UI_URL);
  if (parsed.username || parsed.password) throw new Error('--ui-url must not contain credentials');
  if (parsed.origin !== PERFETTO_UI_ORIGIN) {
    throw new Error(`--ui-url origin must be exactly ${PERFETTO_UI_ORIGIN}`);
  }
  return DEFAULT_UI_URL;
}

function sqlLiteral(value) {
  return `'${String(value).replaceAll("'", "''")}'`;
}

function htmlEscape(value) {
  return String(value)
    .replaceAll('&', '&amp;')
    .replaceAll('<', '&lt;')
    .replaceAll('>', '&gt;')
    .replaceAll('"', '&quot;')
    .replaceAll("'", '&#39;');
}

async function exists(path) {
  try {
    await access(path);
    return true;
  } catch {
    return false;
  }
}

async function sha256File(path) {
  const hash = createHash('sha256');
  for await (const chunk of createReadStream(path)) hash.update(chunk);
  return hash.digest('hex');
}

function pathIsWithin(parentPath, childPath) {
  const childRelative = relative(parentPath, childPath);
  return childRelative === '' || (
    childRelative !== '..'
    && !childRelative.startsWith(`..${sep}`)
    && !isAbsolute(childRelative)
  );
}

function pathsOverlap(firstPath, secondPath) {
  return pathIsWithin(firstPath, secondPath) || pathIsWithin(secondPath, firstPath);
}

async function canonicalizeProspectivePath(inputPath) {
  let cursor = resolve(inputPath);
  const missingParts = [];
  while (true) {
    try {
      const existing = await realpath(cursor);
      return resolve(existing, ...missingParts);
    } catch (error) {
      if (!['ENOENT', 'ENOTDIR'].includes(error?.code)) throw error;
      const parent = dirname(cursor);
      if (parent === cursor) return resolve(inputPath);
      missingParts.unshift(basename(cursor));
      cursor = parent;
    }
  }
}

async function validateTraceOutputIsolation(tracePath, outputDir) {
  const fixedPaths = Object.values(ARTIFACT_NAMES).map((name) => resolve(outputDir, name));
  const candidates = [{label: '--output', path: outputDir}].concat(
    fixedPaths.map((path) => ({label: 'fixed artifact', path})),
  );
  const canonicalTrace = await canonicalizeProspectivePath(tracePath);
  for (const candidate of candidates) {
    if (pathsOverlap(tracePath, candidate.path)) {
      throw new Error(
        `Unsafe path overlap: --trace (${tracePath}) and ${candidate.label} (${candidate.path}) ` +
        'must not be equal or contain one another',
      );
    }
    const canonicalCandidate = await canonicalizeProspectivePath(candidate.path);
    if (pathsOverlap(canonicalTrace, canonicalCandidate)) {
      throw new Error(
        `Unsafe canonical path overlap: --trace (${canonicalTrace}) and ${candidate.label} ` +
        `(${canonicalCandidate}) must not be equal or contain one another`,
      );
    }
  }
}

async function prepareOutputDirectory(traceValue, outputValue) {
  const tracePath = resolve(traceValue);
  const outputDir = resolve(outputValue);
  const traceDetails = await stat(tracePath);
  if (!traceDetails.isFile()) throw new Error(`--trace is not a file: ${tracePath}`);
  await validateTraceOutputIsolation(tracePath, outputDir);
  await mkdir(outputDir, {recursive: true});
  await clearFixedArtifacts(outputDir);
  return {tracePath, traceDetails, outputDir};
}

function buildSql({lanes}) {
  const identity = lanes.map(({pid, tid}) => `(p.pid = ${pid} AND t.tid = ${tid})`);
  const lowerName = "lower(COALESCE(s.name, ''))";
  const lowerCategory = "lower(COALESCE(s.category, ''))";
  const compactCategory = `replace(replace(${lowerCategory}, ' ', ''), char(9), '')`;
  const wrappedCategory = `(',' || ${compactCategory} || ',')`;
  const isCpuOp = `(
        ${wrappedCategory} GLOB '*,cpu_op,*'
        OR ${wrappedCategory} GLOB '*,*.cpu_op,*'
      )`;
  const knownNamespace = [
    'aten', 'prims', 'torch', 'torch_npu', 'npu', 'quantized', 'c10d', 'distributed',
  ].map((namespace) => `${lowerName} GLOB '${namespace}::*'`).join('\n        OR ');
  const forbiddenCategory = [
    'kernel', 'cann', 'runtime', 'driver', 'acl', 'hccl', 'memcpy',
    'python_function', 'user_annotation',
  ].map((part) => `${lowerCategory} GLOB '*${part}*'`).join('\n        OR ');
  const structuralScope = `(
        ${lowerName} GLOB '*profiler*step*'
        OR ${lowerName} GLOB '*pytorch*profiler*'
        OR ${lowerName} GLOB 'autograd::*'
        OR ${lowerName} GLOB 'python::*'
        OR ${lowerName} GLOB 'python *'
        OR ${lowerName} GLOB 'module::*'
        OR ${lowerName} GLOB 'module *'
        OR ${lowerName} = 'forward'
        OR ${lowerName} GLOB 'forward#*'
        OR ${lowerName} GLOB 'forward(*'
        OR ${lowerName} GLOB '*.forward'
        OR ${lowerName} GLOB '*.forward#*'
        OR ${lowerName} GLOB '*.forward(*'
        OR ${lowerName} GLOB '*#forward'
        OR ${lowerName} GLOB '*#forward#*'
        OR ${lowerName} GLOB '*#forward(*'
        OR ${lowerName} GLOB 'optimizer.*'
      )`;
  const deviceName = `(
        ${lowerName} GLOB 'cann*'
        OR ${lowerName} GLOB 'acl*'
        OR ${lowerName} GLOB 'rt*'
        OR ${lowerName} GLOB 'hccl*'
      )`;
  const operatorPredicate = `(
      (
        ${knownNamespace}
        OR (${isCpuOp} AND (instr(s.name, '::') > 1 OR ${lowerName} = 'record_param_comms'))
      )
      AND NOT (${forbiddenCategory})
      AND NOT ${structuralScope}
      AND NOT ${deviceName}
    )`;
  const fromBase = `
    FROM slice s
    JOIN thread_track tt ON s.track_id = tt.id
    JOIN thread t ON tt.utid = t.utid
    JOIN process p ON t.upid = p.upid
    JOIN track tr ON s.track_id = tr.id
    WHERE (${identity.join('\n        OR ')})
      AND s.dur >= 0`;
  const operatorFromAndWhere = `${fromBase}
      AND ${operatorPredicate}`;
  const hostLaunchPredicate = `(
        ${lowerCategory} GLOB '*runtime*'
        OR ${lowerCategory} GLOB '*cann*'
        OR ${lowerCategory} GLOB '*acl*'
        OR ${lowerName} GLOB 'acl*'
        OR ${lowerName} GLOB 'rt*'
        OR ${lowerName} GLOB '*launch*kernel*'
      )`;
  return {
    debugTrack: `
      SELECT s.ts AS ts, s.dur AS dur, s.name AS name
      ${operatorFromAndWhere}
      ORDER BY s.ts`,
    structuralSequence: `
      SELECT 'profiling-alignment-host-structural-v3' AS query_id,
             ROW_NUMBER() OVER (
               PARTITION BY p.pid, t.tid
               ORDER BY s.ts, s.depth, s.id
             ) - 1 AS event_ordinal,
             p.pid AS pid,
             t.tid AS tid,
             COALESCE(p.name, '') AS process_name,
             COALESCE(t.name, '') AS thread_name,
             s.track_id AS track_id,
             COALESCE(tr.name, '') AS track_name,
             s.parent_id AS parent_slice_id,
             s.depth AS nesting_depth,
             COALESCE(s.category, '') AS category,
             s.name AS operator
      ${operatorFromAndWhere}
      ORDER BY p.pid, t.tid, s.ts, s.depth, s.id`,
    operatorCounts: `
      SELECT 'profiling-alignment-host-operator-counts-v3' AS query_id,
             p.pid AS pid,
             t.tid AS tid,
             COALESCE(p.name, '') AS process_name,
             COALESCE(t.name, '') AS thread_name,
             s.track_id AS track_id,
             COALESCE(tr.name, '') AS track_name,
             s.name AS operator,
             COUNT(*) AS calls
      ${operatorFromAndWhere}
      GROUP BY p.pid, t.tid, p.name, t.name, s.track_id, tr.name, s.name
      ORDER BY p.pid, t.tid, s.track_id, s.name`,
    trackInventory: `
      SELECT 'profiling-alignment-host-track-inventory-v3' AS query_id,
             p.pid AS pid,
             t.tid AS tid,
             s.track_id AS track_id,
             COALESCE(tr.name, '') AS track_name,
             COUNT(*) AS selected_event_rows
      ${operatorFromAndWhere}
      GROUP BY p.pid, t.tid, s.track_id, tr.name
      ORDER BY p.pid, t.tid, s.track_id`,
    hostLaunchCounts: `
      SELECT 'profiling-alignment-host-launch-context-v3' AS query_id,
             p.pid AS pid,
             t.tid AS tid,
             s.track_id AS track_id,
             COALESCE(tr.name, '') AS track_name,
             COALESCE(s.category, '') AS category,
             s.name AS launch_or_runtime_event,
             COUNT(*) AS calls
      ${fromBase}
        AND ${hostLaunchPredicate}
      GROUP BY p.pid, t.tid, s.track_id, tr.name, s.category, s.name
      ORDER BY p.pid, t.tid, s.track_id, s.category, s.name`,
    completenessSummary: `
      SELECT 'profiling-alignment-host-completeness-v3' AS query_id,
             COUNT(*) AS selected_event_rows,
             COUNT(DISTINCT CAST(p.pid AS TEXT) || '/' || CAST(t.tid AS TEXT)) AS selected_lane_rows,
             COUNT(DISTINCT s.track_id) AS selected_track_rows,
             0 AS sql_row_limit,
             0 AS truncated
      ${operatorFromAndWhere}`,
  };
}

function gridRowsToObjects(rows) {
  if (!Array.isArray(rows) || rows.length < 2) return [];
  const headers = rows[0].map((value) => String(value).trim());
  return rows.slice(1).map((row) => Object.fromEntries(
    headers.map((header, index) => [header, String(row[index] ?? '').trim()]),
  ));
}

async function captureQueryResult(perfettoFrame, definition, timeoutMs) {
  const result = {
    query_id: definition.id,
    title: definition.title,
    completed: false,
    row_count: null,
    error: null,
    visible_grid_rows: [],
  };
  try {
    const tab = perfettoFrame.locator('.pf-drawer-panel__tab').filter({hasText: definition.title}).first();
    await tab.waitFor({state: 'visible', timeout: timeoutMs});
    await tab.click({timeout: timeoutMs});
    await perfettoFrame.waitForFunction(
      ({title}) => {
        const activeTitle = document.querySelector(
          '.pf-drawer-panel__tab--active .pf-drawer-panel__tab-title',
        )?.textContent || '';
        if (!activeTitle.includes(title)) return false;
        const text = document.querySelector('.pf-drawer-panel__drawer')?.textContent || '';
        return /Returned\s+\d+\s+rows/i.test(text)
          || /(?:SQL|query|trace processor)[^\n]{0,80}(?:error|failed)/i.test(text);
      },
      {title: definition.title},
      {timeout: timeoutMs},
    );
    const drawer = perfettoFrame.locator('.pf-drawer-panel__drawer');
    const text = await drawer.innerText();
    const returned = text.match(/Returned\s+(\d+)\s+rows/i);
    const queryError = text.match(/(?:SQL|query|trace processor)[^\n]{0,160}(?:error|failed)[^\n]*/i);
    result.row_count = returned ? Number(returned[1]) : null;
    result.error = queryError ? queryError[0].trim() : null;
    const tables = drawer.locator('[role="table"]');
    if (await tables.count()) {
      result.visible_grid_rows = await tables.last().locator('[role="row"]').evaluateAll(
        (rows) => rows.map((row) => Array.from(row.querySelectorAll('[role="columnheader"], [role="cell"]'))
          .map((cell) => (
            cell.querySelector('.pf-grid-cell__content, .pf-grid-header-cell__title-wrapper')?.textContent || ''
          ).trim())),
      );
    }
    result.completed = result.row_count !== null && result.error === null;
  } catch (error) {
    result.error = `${error?.name || 'Error'}: ${error?.message || error}`;
  }
  return result;
}

function jsonForInlineScript(value) {
  return JSON.stringify(value).replaceAll('<', '\\u003c');
}

function buildHostHtml(config) {
  return `<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <title>Local Perfetto trace renderer</title>
  <style>
    html, body { margin: 0; height: 100%; overflow: hidden; }
    #status { box-sizing: border-box; height: 28px; padding: 5px 8px; font: 13px/18px sans-serif; }
    #perfetto { display: block; width: 100%; height: calc(100% - 28px); border: 0; }
  </style>
</head>
<body>
  <div id="status">waiting-for-perfetto</div>
  <iframe id="perfetto" title="Perfetto UI"></iframe>
  <script type="module">
    const config = ${jsonForInlineScript(config)};
    const iframe = document.querySelector('#perfetto');
    const status = document.querySelector('#status');
    const commands = [
      {id: 'dev.perfetto.CollapseTracksByRegex', args: ['.*']},
      {id: 'dev.perfetto.AddDebugSliceTrack', args: [config.debugTrackSql, config.debugTrackTitle]},
      ...config.queryDefinitions.map((query) => (
        {id: 'dev.perfetto.RunQueryAndShowTab', args: [query.sql, query.title]}
      )),
    ];
    const route = new URLSearchParams({
      mode: 'embedded',
      pid: String(config.lanes[0].pid),
      tid: String(config.lanes[0].tid),
      startupCommands: JSON.stringify(commands),
    });
    iframe.src = config.uiUrl + '#!/?' + route.toString();
    let handshakeAccepted = false;
    const ping = setInterval(() => iframe.contentWindow.postMessage('PING', config.uiOrigin), 100);
    const handshakeTimeout = setTimeout(() => {
      clearInterval(ping);
      status.textContent = 'error: timeout waiting for Perfetto PONG';
    }, config.timeoutMs);
    window.addEventListener('message', async function onMessage(event) {
      if (handshakeAccepted || event.origin !== config.uiOrigin ||
          event.source !== iframe.contentWindow || event.data !== 'PONG') return;
      handshakeAccepted = true;
      clearInterval(ping);
      clearTimeout(handshakeTimeout);
      status.textContent = 'perfetto-ready';
      try {
        const response = await fetch(config.traceRoute, {cache: 'no-store'});
        if (!response.ok) throw new Error('trace fetch failed: HTTP ' + response.status);
        const buffer = await response.arrayBuffer();
        const offline = await window[config.offlineBinding]({traceBytes: buffer.byteLength});
        if (!offline?.offline) throw new Error('browser context did not confirm offline mode');
        iframe.contentWindow.postMessage({perfetto: {
          buffer,
          title: config.traceTitle,
          fileName: config.fileName,
          localOnly: true,
          keepApiOpen: false,
        }}, config.uiOrigin);
        status.textContent = 'trace-posted offline-before-post=true lanes=' + config.lanes.length +
          ' bytes=' + buffer.byteLength;
      } catch (error) {
        status.textContent = 'error: ' + (error?.stack || error);
      }
    });
  </script>
</body>
</html>`;
}

async function loadPlaywright(explicitRoot) {
  const attempts = [];
  const rawValue = explicitRoot || process.env[TRUSTED_NODE_MODULES_ENV];
  const configuredSource = explicitRoot ? '--playwright-node-modules' : TRUSTED_NODE_MODULES_ENV;
  if (!rawValue) {
    throw new Error(
      '--playwright-node-modules must name an explicit trusted node_modules root; ' +
      `${TRUSTED_NODE_MODULES_ENV} is accepted only as a fallback`,
    );
  }
  const roots = [];
  for (const rawRoot of rawValue.split(delimiter).filter(Boolean)) {
    if (!isAbsolute(rawRoot)) {
      attempts.push(`${configuredSource}: ignored non-absolute dependency root ${rawRoot}`);
      continue;
    }
    roots.push({path: resolve(rawRoot), source: configuredSource});
  }
  const seenRoots = new Set();
  const scriptRequire = createRequire(import.meta.url);
  for (const root of roots) {
    const key = process.platform === 'win32' ? root.path.toLowerCase() : root.path;
    if (seenRoots.has(key)) continue;
    seenRoots.add(key);
    for (const packageName of ['playwright-core', 'playwright']) {
      const packageDir = resolve(root.path, packageName);
      try {
        if (!(await exists(resolve(packageDir, 'package.json')))) {
          attempts.push(`${packageName} in ${root.source} (${root.path}): package.json not found`);
          continue;
        }
        const module = scriptRequire(packageDir);
        if (module.chromium) {
          return {chromium: module.chromium, packageName, dependencyRoot: root.path, dependencySource: root.source};
        }
        attempts.push(`${packageName} in ${root.source} (${root.path}): chromium export not found`);
      } catch (error) {
        attempts.push(`${packageName} in ${root.source} (${root.path}): ${error.code || error.message}`);
      }
    }
  }
  throw new Error(
    'Playwright is unavailable in explicitly configured trusted dependency roots. Set ' +
    '--playwright-node-modules to an absolute trusted node_modules directory. ' +
    `${TRUSTED_NODE_MODULES_ENV} remains an explicit fallback. ` +
    `Resolution attempts: ${attempts.join('; ')}`,
  );
}

async function detectBrowser(explicitPath) {
  if (explicitPath) {
    if (!isAbsolute(explicitPath)) {
      throw new Error('--browser must be an absolute executable path');
    }
    const path = await realpath(explicitPath);
    const metadata = await stat(path);
    if (!metadata.isFile()) throw new Error(`Browser executable is not a file: ${path}`);
    return path;
  }
  const candidates = process.platform === 'win32'
    ? [
        'C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe',
        'C:\\Program Files (x86)\\Google\\Chrome\\Application\\chrome.exe',
        'C:\\Program Files\\Microsoft\\Edge\\Application\\msedge.exe',
        'C:\\Program Files (x86)\\Microsoft\\Edge\\Application\\msedge.exe',
      ]
    : process.platform === 'darwin'
      ? [
          '/Applications/Google Chrome.app/Contents/MacOS/Google Chrome',
          '/Applications/Microsoft Edge.app/Contents/MacOS/Microsoft Edge',
          '/Applications/Chromium.app/Contents/MacOS/Chromium',
        ]
      : ['/usr/bin/google-chrome', '/usr/bin/chromium', '/usr/bin/chromium-browser'];
  for (const candidate of candidates.filter(Boolean)) {
    if (await exists(candidate)) return candidate;
  }
  throw new Error('No Chrome/Edge executable was auto-detected; pass --browser <executable>');
}

async function closeServer(server) {
  if (!server?.listening) return;
  await new Promise((resolveClose) => server.close(resolveClose));
}

async function artifactInventory(outputDir) {
  const result = {};
  for (const [kind, name] of Object.entries(ARTIFACT_NAMES)) {
    const path = resolve(outputDir, name);
    try {
      const details = await stat(path);
      result[kind] = {
        path,
        exists: true,
        bytes: details.size,
        modified_at: details.mtime.toISOString(),
        modified_at_ms: details.mtimeMs,
      };
    } catch {
      result[kind] = {path, exists: false, bytes: 0};
    }
  }
  return result;
}

async function clearFixedArtifacts(outputDir) {
  for (const name of Object.values(ARTIFACT_NAMES)) {
    await rm(resolve(outputDir, name), {force: true});
  }
}

async function writeFailurePlaceholder(outputDir, error) {
  const message = `Perfetto rendering failed\n${error.stack || error.message || error}\n`;
  const textPath = resolve(outputDir, ARTIFACT_NAMES.text);
  const htmlPath = resolve(outputDir, ARTIFACT_NAMES.frameHtml);
  await writeFile(textPath, message, 'utf8');
  await writeFile(htmlPath, `<!doctype html><meta charset="utf-8"><pre>${htmlEscape(message)}</pre>`, 'utf8');
}

async function run(options) {
  if (options.online_authorized !== true) {
    throw new Error(
      `Online Perfetto access was not authorized; pass --online-authorized to load ${PERFETTO_UI_ORIGIN}`,
    );
  }
  const prepared = await prepareOutputDirectory(
    required(options, 'trace'),
    required(options, 'output'),
  );
  const {tracePath, traceDetails, outputDir} = prepared;
  preparedOutputDirForFallback = outputDir;
  const startedAt = new Date();
  const runId = randomUUID();
  const manifest = {
    schema_version: 3,
    run_id: runId,
    status: 'running',
    started_at: startedAt.toISOString(),
    finished_at: null,
    elapsed_ms: null,
    selection: null,
    trace: null,
    perfetto: null,
    browser: null,
    sql: null,
    rendered: null,
    artifacts: null,
    error: null,
  };
  const logs = [];
  let server;
  let browser;
  let page;
  let perfettoFrame;
  let runError;
  const networkIsolation = {
    service_workers: 'playwright-block-plus-compatible-register-stub',
    service_worker_count_after_render: null,
    service_worker_guard_visible_in_perfetto_frame: null,
    offline_requested_at: null,
    offline_active_at: null,
    offline_before_trace_post: false,
    post_offline_request_count: 0,
    post_offline_response_count: 0,
    post_offline_successful_response_count: 0,
    post_offline_request_urls: [],
    post_offline_response_urls: [],
    post_offline_responses: [],
  };

  try {
    const lanes = await loadLanes(options);
    const timeoutMs = options.timeout_ms === undefined
      ? DEFAULT_TIMEOUT_MS
      : parseNonNegativeInteger(options.timeout_ms, '--timeout-ms');
    if (timeoutMs < 1_000) throw new Error('--timeout-ms must be at least 1000');
    const uiUrl = normalizeUiUrl(options.ui_url || DEFAULT_UI_URL);
    const browserPath = await detectBrowser(options.browser);
    const sql = buildSql({lanes});
    const debugTrackTitle = `PyTorch Host 算子轨道 lanes=${lanes.length}`;
    const operatorCountsTitle = `PyTorch Host 算子调用数 lanes=${lanes.length}`;
    const structuralSequenceTitle = `PyTorch Host 算子结构序列 lanes=${lanes.length}`;
    const titleSuffix = `${runId.slice(0, 8)} lanes=${lanes.length}`;
    const queryDefinitions = [
      {id: 'operator_counts', title: operatorCountsTitle, sql: sql.operatorCounts},
      {id: 'track_inventory', title: `profiling-alignment Host track inventory ${titleSuffix}`, sql: sql.trackInventory},
      {id: 'host_launch_context', title: `profiling-alignment Host launch context ${titleSuffix}`, sql: sql.hostLaunchCounts},
      {id: 'structural_sequence', title: structuralSequenceTitle, sql: sql.structuralSequence},
      {id: 'completeness_summary', title: `profiling-alignment Host completeness ${titleSuffix}`, sql: sql.completenessSummary},
    ];
    const completenessSummaryTitle = queryDefinitions.find(({id}) => id === 'completeness_summary').title;
    const traceToken = randomUUID();
    const offlineBinding = `__profilingAlignmentPerfettoSetOffline_${traceToken.replaceAll('-', '')}`;
    const traceRoute = `/trace/${traceToken}`;
    const traceTitle = `PyTorch structural trace lanes=${lanes.length}`;

    manifest.selection = {
      lanes,
      lane_file: lanes.source_path ?? null,
      skipped_lanes: lanes.skipped ?? [],
      domain: 'host',
      review_scope: 'host-framework-and-launch-context-only',
      device_evidence: 'local-parser-only',
    };
    manifest.trace = {
      path: tracePath,
      file_name: basename(tracePath),
      bytes: traceDetails.size,
      sha256: await sha256File(tracePath),
    };
    manifest.perfetto = {
      ui_url: uiUrl,
      ui_origin: PERFETTO_UI_ORIGIN,
      embedded: true,
      local_only: true,
      message_origin_enforced: true,
      post_message_target_origin: PERFETTO_UI_ORIGIN,
      ui_loaded_at: new Date().toISOString(),
      network_isolation: networkIsolation,
    };
    manifest.sql = {
      debug_track_internal_render_only: sql.debugTrack,
      structural_sequence: sql.structuralSequence,
      operator_counts: sql.operatorCounts,
      track_inventory: sql.trackInventory,
      host_launch_context: sql.hostLaunchCounts,
      completeness_summary: sql.completenessSummary,
      result_queries: queryDefinitions.map(({id, title}) => ({id, title})),
      query_results: null,
      completeness: null,
      global_row_limit: null,
      duration_metrics_emitted: false,
      performance_interpretation_allowed: false,
      evidence_scope: 'Host framework operators and Host launch/runtime context are auxiliary cross-checks; Device evidence remains local-parser-only',
    };

    const hostHtml = buildHostHtml({
      uiUrl,
      uiOrigin: PERFETTO_UI_ORIGIN,
      traceRoute,
      offlineBinding,
      traceTitle,
      fileName: basename(tracePath),
      lanes,
      timeoutMs,
      debugTrackSql: sql.debugTrack,
      debugTrackTitle,
      queryDefinitions,
    });
    server = createServer((request, response) => {
      const pathname = new URL(request.url || '/', 'http://127.0.0.1').pathname;
      response.setHeader('Cache-Control', 'no-store');
      if (pathname === traceRoute) {
        response.statusCode = 200;
        response.setHeader('Content-Type', 'application/json');
        response.setHeader('Content-Length', String(traceDetails.size));
        const stream = createReadStream(tracePath);
        stream.on('error', (error) => {
          logs.push(`[host:trace-error] ${error.stack || error}`);
          if (!response.headersSent) response.statusCode = 500;
          response.destroy(error);
        });
        stream.pipe(response);
        return;
      }
      if (pathname === '/favicon.ico') {
        response.statusCode = 204;
        response.end();
        return;
      }
      response.statusCode = 200;
      response.setHeader('Content-Type', 'text/html; charset=utf-8');
      response.end(hostHtml);
    });
    server.on('clientError', (error, socket) => {
      logs.push(`[host:client-error] ${error.stack || error}`);
      socket.end('HTTP/1.1 400 Bad Request\r\n\r\n');
    });
    await new Promise((resolveListen, rejectListen) => {
      server.once('error', rejectListen);
      server.listen(0, '127.0.0.1', resolveListen);
    });
    const address = server.address();
    const hostUrl = `http://127.0.0.1:${address.port}/`;

    const playwright = await loadPlaywright(options.playwright_node_modules);
    browser = await playwright.chromium.launch({headless: true, executablePath: browserPath});
    manifest.browser = {
      automation_package: playwright.packageName,
      dependency_root: playwright.dependencyRoot,
      dependency_source: playwright.dependencySource,
      executable: browserPath,
      version: browser.version(),
      headless: true,
    };
    const context = await browser.newContext({
      viewport: {width: 1600, height: 1000},
      serviceWorkers: 'block',
    });
    // Perfetto expects register() to resolve to a registration-like object.
    // Provide that compatibility surface while Playwright blocks actual
    // Service Worker creation as a second, browser-level boundary.
    await context.addInitScript(() => {
      const container = navigator.serviceWorker;
      if (!container) return;
      const registration = {
        installing: null,
        waiting: null,
        active: null,
        scope: `${location.origin}/`,
        updateViaCache: 'none',
        onupdatefound: null,
        addEventListener() {},
        removeEventListener() {},
        dispatchEvent() { return true; },
        update() { return Promise.resolve(); },
        unregister() { return Promise.resolve(true); },
      };
      Object.defineProperties(container, {
        register: {value: async () => registration, configurable: false, writable: false},
        getRegistration: {value: async () => undefined, configurable: false, writable: false},
        getRegistrations: {value: async () => [], configurable: false, writable: false},
      });
      Object.defineProperty(globalThis, '__profilingAlignmentServiceWorkerBlocked', {
        value: true,
        configurable: false,
        writable: false,
      });
    });
    page = await context.newPage();
    await page.exposeBinding(offlineBinding, async ({frame}, request) => {
      if (frame !== page.mainFrame()) {
        throw new Error('offline transition may only be requested by the localhost main frame');
      }
      if (Number(request?.traceBytes) !== traceDetails.size) {
        throw new Error('offline transition trace byte count mismatch');
      }
      if (!networkIsolation.offline_active_at) {
        networkIsolation.offline_requested_at = new Date().toISOString();
        await context.setOffline(true);
        networkIsolation.offline_active_at = new Date().toISOString();
      }
      networkIsolation.offline_before_trace_post = true;
      return {offline: true, activatedAt: networkIsolation.offline_active_at};
    });
    page.on('console', (message) => logs.push(`[console:${message.type()}] ${message.text()}`));
    page.on('pageerror', (error) => logs.push(`[pageerror] ${error.stack || error}`));
    page.on('requestfailed', (request) => {
      logs.push(`[requestfailed] ${request.url()} :: ${request.failure()?.errorText || 'unknown'}`);
    });
    page.on('request', (request) => {
      if (networkIsolation.offline_active_at) {
        networkIsolation.post_offline_request_count += 1;
        if (networkIsolation.post_offline_request_urls.length < 200) {
          networkIsolation.post_offline_request_urls.push(request.url());
        }
      }
    });
    page.on('response', (response) => {
      if (networkIsolation.offline_active_at) {
        networkIsolation.post_offline_response_count += 1;
        if (response.ok()) networkIsolation.post_offline_successful_response_count += 1;
        if (networkIsolation.post_offline_response_urls.length < 200) {
          networkIsolation.post_offline_response_urls.push(response.url());
        }
        if (networkIsolation.post_offline_responses.length < 200) {
          networkIsolation.post_offline_responses.push({
            url: response.url(),
            status: response.status(),
            successful: response.ok(),
            from_service_worker: response.fromServiceWorker(),
          });
        }
      }
    });
    const deadline = Date.now() + timeoutMs;
    const remaining = () => {
      const value = deadline - Date.now();
      if (value <= 0) throw new Error(`Timed out after ${timeoutMs}ms while rendering Perfetto`);
      return value;
    };
    await page.goto(hostUrl, {waitUntil: 'domcontentloaded', timeout: remaining()});
    await page.waitForFunction(
      () => document.querySelector('#status')?.textContent?.startsWith('trace-posted'),
      undefined,
      {timeout: remaining()},
    );
    const iframeElement = await page.$('#perfetto');
    perfettoFrame = await iframeElement?.contentFrame();
    if (!perfettoFrame) throw new Error('Perfetto iframe was not created');
    await perfettoFrame.waitForFunction(
      ({title}) => {
        const text = document.body?.innerText || '';
        return text.includes(title) && /Returned\s+\d+\s+rows/.test(text);
      },
      {title: completenessSummaryTitle},
      {timeout: remaining()},
    );
    await page.waitForTimeout(Math.min(1500, remaining()));

    const queryResults = [];
    for (const definition of queryDefinitions) {
      queryResults.push(await captureQueryResult(
        perfettoFrame,
        definition,
        Math.max(1000, Math.min(remaining(), 30_000)),
      ));
    }
    const byQueryId = Object.fromEntries(queryResults.map((result) => [result.query_id, result]));
    const completenessRows = gridRowsToObjects(
      byQueryId.completeness_summary?.visible_grid_rows || [],
    );
    const completenessRow = completenessRows[0] || {};
    const parseCount = (name) => {
      const value = Number(completenessRow[name]);
      return Number.isSafeInteger(value) && value >= 0 ? value : null;
    };
    const selectedEventRows = parseCount('selected_event_rows');
    const selectedLaneRows = parseCount('selected_lane_rows');
    const selectedTrackRows = parseCount('selected_track_rows');
    const structuralEmittedRows = byQueryId.structural_sequence?.row_count ?? null;
    const trackInventoryRows = byQueryId.track_inventory?.row_count ?? null;
    const queryErrors = queryResults
      .filter((result) => !result.completed)
      .map(({query_id, error}) => ({query_id, error: error || 'query did not report a completed row count'}));
    const completeness = {
      all_queries_completed_without_error: queryErrors.length === 0,
      selected_event_rows: selectedEventRows,
      structural_emitted_rows: structuralEmittedRows,
      structural_sequence_complete: selectedEventRows !== null && structuralEmittedRows === selectedEventRows,
      selected_lane_rows: selectedLaneRows,
      requested_lane_rows: lanes.length,
      selected_lane_coverage_complete: selectedLaneRows === lanes.length,
      selected_track_rows: selectedTrackRows,
      track_inventory_emitted_rows: trackInventoryRows,
      track_inventory_complete: selectedTrackRows !== null && trackInventoryRows === selectedTrackRows,
      sql_row_limit: null,
      truncated: completenessRow.truncated !== '0',
      query_errors: queryErrors,
    };
    completeness.complete = completeness.all_queries_completed_without_error
      && completeness.structural_sequence_complete
      && completeness.selected_lane_coverage_complete
      && completeness.track_inventory_complete
      && completeness.truncated === false;
    manifest.sql.query_results = queryResults;
    manifest.sql.completeness = completeness;

    networkIsolation.service_worker_count_after_render = context.serviceWorkers().length;
    networkIsolation.service_worker_guard_visible_in_perfetto_frame = await perfettoFrame.evaluate(
      () => globalThis.__profilingAlignmentServiceWorkerBlocked === true,
    );

    const frameHtml = await perfettoFrame.content();
    const bodyText = await perfettoFrame.locator('body').innerText();
    const bodyTextWithAudit = `${bodyText}\n\nPROFILING_ALIGNMENT_QUERY_AUDIT\n${JSON.stringify({
      run_id: runId,
      query_results: queryResults.map(({query_id, title, completed, row_count, error}) => (
        {query_id, title, completed, row_count, error}
      )),
      completeness,
    }, null, 2)}\n`;
    await writeFile(resolve(outputDir, ARTIFACT_NAMES.frameHtml), frameHtml, 'utf8');
    await writeFile(resolve(outputDir, ARTIFACT_NAMES.text), bodyTextWithAudit, 'utf8');
    if (options.screenshot) {
      await page.screenshot({path: resolve(outputDir, ARTIFACT_NAMES.screenshot), fullPage: false});
    } else {
      await rm(resolve(outputDir, ARTIFACT_NAMES.screenshot), {force: true});
    }
    manifest.rendered = {
      host_url: hostUrl,
      iframe_url: perfettoFrame.url(),
      frame_title: await perfettoFrame.title(),
      ui_version: await perfettoFrame.locator('body').getAttribute('data-perfetto_version'),
      body_text_characters: bodyTextWithAudit.length,
      canvas_count: await perfettoFrame.locator('canvas').count(),
      visible_query_grid_rows: byQueryId.completeness_summary?.visible_grid_rows || [],
      screenshot_requested: options.screenshot === true,
      review_boundary: 'Perfetto is an auxiliary Host framework/launch cross-check. Device evidence remains local-parser-only. HTML/text/SQL supports structure review; Canvas color/width/geometry requires --screenshot and image review',
    };
    if (!completeness.complete) {
      throw new Error(`Perfetto query completeness gate failed: ${JSON.stringify(completeness)}`);
    }
    manifest.status = 'success';
  } catch (error) {
    runError = error instanceof Error ? error : new Error(String(error));
    manifest.status = 'failure';
    manifest.error = {name: runError.name, message: runError.message, stack: runError.stack};
    logs.push(`[fatal] ${runError.stack || runError}`);
    await rm(resolve(outputDir, ARTIFACT_NAMES.screenshot), {force: true});
    await rm(resolve(outputDir, ARTIFACT_NAMES.browserLog), {force: true});
    if (!manifest.rendered) await writeFailurePlaceholder(outputDir, runError);
  } finally {
    if (browser) {
      try {
        await browser.close();
      } catch (error) {
        logs.push(`[browser-close-error] ${error.stack || error}`);
      }
    }
    if (server) {
      try {
        await closeServer(server);
      } catch (error) {
        logs.push(`[server-close-error] ${error.stack || error}`);
      }
    }
    await writeFile(resolve(outputDir, ARTIFACT_NAMES.browserLog), `${logs.join('\n')}\n`, 'utf8');
    manifest.finished_at = new Date().toISOString();
    manifest.elapsed_ms = Date.now() - startedAt.getTime();
    manifest.artifacts = await artifactInventory(outputDir);
    manifest.artifacts.manifest = {
      path: resolve(outputDir, ARTIFACT_NAMES.manifest),
      exists: true,
      bytes: null,
    };
    await writeFile(resolve(outputDir, ARTIFACT_NAMES.manifest), `${JSON.stringify(manifest, null, 2)}\n`, 'utf8');
  }
  return {manifest, error: runError};
}

let manifestWritten = false;
try {
  const argv = process.argv.slice(2);
  const options = parseArgs(argv);
  if (options.help) {
    console.log(usage());
  } else {
    const result = await run(options);
    manifestWritten = true;
    if (result.error) throw result.error;
    const manifest = result.manifest;
    console.log(JSON.stringify({
      status: manifest.status,
      screenshot: manifest.artifacts.screenshot.exists ? manifest.artifacts.screenshot.path : null,
      frame_html: manifest.artifacts.frameHtml.path,
      text: manifest.artifacts.text.path,
      manifest: resolve(required(options, 'output'), ARTIFACT_NAMES.manifest),
    }, null, 2));
  }
} catch (error) {
  const failure = error instanceof Error ? error : new Error(String(error));
  if (!manifestWritten && preparedOutputDirForFallback) {
    try {
      const outputDir = preparedOutputDirForFallback;
      await clearFixedArtifacts(outputDir);
      const manifestPath = resolve(outputDir, ARTIFACT_NAMES.manifest);
      await writeFailurePlaceholder(outputDir, failure);
      await writeFile(resolve(outputDir, ARTIFACT_NAMES.browserLog), `[fatal] ${failure.stack || failure}\n`, 'utf8');
      const artifacts = await artifactInventory(outputDir);
      artifacts.manifest = {path: manifestPath, exists: true, bytes: null};
      await writeFile(manifestPath, `${JSON.stringify({
        schema_version: 3,
        run_id: randomUUID(),
        status: 'failure',
        started_at: new Date().toISOString(),
        finished_at: new Date().toISOString(),
        error: {name: failure.name, message: failure.message, stack: failure.stack},
        artifacts,
      }, null, 2)}\n`, 'utf8');
    } catch (manifestError) {
      console.error(`Additionally failed to write failure manifest: ${manifestError.stack || manifestError}`);
    }
  }
  console.error(`Perfetto rendering failed: ${failure.message}`);
  process.exitCode = 1;
}

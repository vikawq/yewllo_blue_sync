#!/usr/bin/env python3
"""Deterministic, resumable orchestrator for profiling alignment.

The orchestrator only executes sibling analysis utilities.  It never executes,
sources, imports, or compiles the user's shell/Python/model repositories.  Raw
profiling and source trees are read-only inputs; every intentional write is
below ``output_root``.
"""

from __future__ import annotations

import argparse
import csv
import hashlib
import json
import os
import shlex
import subprocess
import sys
import tempfile
from contextlib import contextmanager
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Iterable, Mapping, Sequence


SPEC_SCHEMA_VERSION = 1
STATE_SCHEMA_VERSION = 1
ORCHESTRATOR_VERSION = "1.0.0"
STAGES = (
    "runtime",
    "preflight",
    "align",
    "entrypoint",
    "run_contract",
    "source_causality",
    "perfetto",
    "report",
    "validator",
)
TERMINAL_STAGE_STATUSES = {"complete", "degraded"}
SOURCE_COMPONENTS = ("model", "pytorch", "torch_npu")
SOURCE_ANALYSIS_ARTIFACTS = (
    "control_flow_guard_candidates.csv",
    "control_flow_evidence.jsonl",
    "predicate_tensor_evidence.csv",
    "event_source_map.csv",
    "branch_device_evidence.csv",
    "source_evidence.csv",
    "source_entrypoint_chain.csv",
    "source_analysis_issues.csv",
)
SOURCE_BINDINGS = {"verified", "user-declared", "unverified", "conflict"}
SAFE_SIBLING_SCRIPTS = {
    "runtime_doctor.py",
    "preflight_ascend_profiles.py",
    "align_profiles.py",
    "resolve_source_entrypoints.py",
    "analyze_control_flow.py",
    "render_python_guard_snapshots.py",
    "render_perfetto_batch.py",
    "build_alignment_report.py",
    "validate_alignment_report.py",
}


class SpecError(ValueError):
    """The run-spec is missing, ambiguous, or unsafe."""


class PipelineError(RuntimeError):
    """A deterministic pipeline stage could not finish."""


@dataclass(frozen=True)
class Invocation:
    returncode: int
    stdout: str
    stderr: str


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")


def canonical_bytes(value: Any) -> bytes:
    return json.dumps(
        value, ensure_ascii=False, sort_keys=True, separators=(",", ":")
    ).encode("utf-8")


def sha256_value(value: Any) -> str:
    return hashlib.sha256(canonical_bytes(value)).hexdigest()


def sha256_file(path: Path) -> dict[str, Any]:
    digest = hashlib.sha256()
    size = 0
    with path.open("rb") as handle:
        while True:
            block = handle.read(1024 * 1024)
            if not block:
                break
            size += len(block)
            digest.update(block)
    return {"sha256": digest.hexdigest(), "bytes": size}


def atomic_write_json(path: Path, payload: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary: str | None = None
    try:
        with tempfile.NamedTemporaryFile(
            "w",
            encoding="utf-8",
            newline="\n",
            dir=path.parent,
            prefix=f".{path.name}.",
            suffix=".tmp",
            delete=False,
        ) as handle:
            temporary = handle.name
            json.dump(payload, handle, ensure_ascii=False, indent=2, sort_keys=True)
            handle.write("\n")
            handle.flush()
            os.fsync(handle.fileno())
        os.replace(temporary, path)
        temporary = None
    finally:
        if temporary:
            try:
                Path(temporary).unlink()
            except OSError:
                pass


def load_json(path: Path) -> Any:
    with path.open("r", encoding="utf-8-sig") as handle:
        return json.load(handle)


def is_within(path: Path, root: Path) -> bool:
    try:
        path.relative_to(root)
        return True
    except ValueError:
        return False


def _required_text(container: Mapping[str, Any], key: str) -> str:
    value = container.get(key)
    if not isinstance(value, str) or not value.strip():
        raise SpecError(f"{key} must be a non-empty string")
    return value.strip()


def _resolve_from(raw: str, base: Path, label: str, *, must_exist: bool) -> Path:
    candidate = Path(raw).expanduser()
    if not candidate.is_absolute():
        candidate = base / candidate
    try:
        return candidate.resolve(strict=must_exist)
    except OSError as error:
        raise SpecError(f"{label} cannot be resolved: {candidate}: {error}") from error


def _inside_any(path: Path, roots: Sequence[Path]) -> bool:
    return any(is_within(path, root) for root in roots)


def resolve_trusted_executable(
    requested: str,
    *,
    forbidden_roots: Sequence[Path],
    label: str,
) -> Path:
    """Resolve an executable without current-directory or relative-PATH lookup."""
    requested = requested.strip()
    if not requested:
        raise SpecError(f"{label} must be a non-empty executable name or absolute path")
    candidate = Path(requested).expanduser()
    if candidate.is_absolute():
        resolved = candidate.resolve(strict=False)
        if (
            not resolved.is_file()
            or _inside_any(resolved, forbidden_roots)
            or (os.name != "nt" and not os.access(resolved, os.X_OK))
        ):
            raise SpecError(
                f"{label} must be an existing executable outside all analysis input/output roots"
            )
        return resolved
    # Path("./git").parent is also '.', so explicitly reject separators.  A
    # bare name is the only form allowed to consult PATH.
    if candidate.parent != Path(".") or "/" in requested or "\\" in requested:
        raise SpecError(f"{label} must be a bare PATH name or an absolute path")
    if os.name == "nt" and not candidate.suffix:
        extensions = [
            item
            for item in os.environ.get("PATHEXT", ".COM;.EXE;.BAT;.CMD").split(";")
            if item
        ]
        names = [requested + extension.lower() for extension in extensions]
    else:
        names = [requested]
    for raw_directory in os.environ.get("PATH", "").split(os.pathsep):
        expanded = os.path.expandvars(raw_directory.strip().strip('"'))
        if not expanded:
            continue
        directory = Path(expanded).expanduser()
        if not directory.is_absolute():
            continue
        try:
            directory = directory.resolve(strict=True)
        except OSError:
            continue
        if _inside_any(directory, forbidden_roots):
            continue
        for name in names:
            executable = directory / name
            if executable.is_file() and (os.name == "nt" or os.access(executable, os.X_OK)):
                return executable.resolve()
    raise SpecError(f"{label} was not found on trusted absolute PATH entries")


def _normalize_source_root(value: Any, component: str, work_root: Path) -> Path:
    if isinstance(value, str):
        raw = value
    elif isinstance(value, Mapping):
        raw = _required_text(value, "path")
    else:
        raise SpecError(f"source_roots.{component} must be a string or object with path")
    path = _resolve_from(raw, work_root, f"source_roots.{component}.path", must_exist=True)
    if not path.is_dir():
        raise SpecError(f"source_roots.{component}.path is not a directory: {path}")
    if not is_within(path, work_root):
        raise SpecError(f"source_roots.{component}.path must be below work_root: {path}")
    return path


def _normalize_source_owner(value: Any) -> dict[str, Any] | None:
    if value is None:
        return None
    if isinstance(value, str):
        value = {"component": value}
    if not isinstance(value, Mapping):
        raise SpecError("source_owner must be a component string or object")
    component = _required_text(value, "component").casefold().replace("-", "_")
    aliases = {"mindspeed": "model", "torch": "pytorch", "torchnpu": "torch_npu"}
    component = aliases.get(component, component)
    if component not in SOURCE_COMPONENTS:
        raise SpecError("source_owner.component must be model, pytorch, or torch_npu")
    binding = str(value.get("runtime_binding", "unverified")).strip()
    if binding not in SOURCE_BINDINGS:
        raise SpecError(
            "source_owner.runtime_binding must be verified, user-declared, "
            "unverified, or conflict"
        )
    include_python = value.get("include_python", [])
    if isinstance(include_python, str):
        include_python = [include_python]
    if not isinstance(include_python, list) or not all(
        isinstance(item, str) and item.strip() for item in include_python
    ):
        raise SpecError("source_owner.include_python must be a string list")
    for item in include_python:
        path = Path(item)
        if path.is_absolute() or ".." in path.parts or path.suffix.casefold() != ".py":
            raise SpecError(
                "source_owner.include_python entries must be repo-relative .py paths"
            )
    normalized = {
        "component": component,
        "runtime_binding": binding,
        "repository_url": str(value.get("repository_url", "")).strip(),
        "commit": str(value.get("commit", "")).strip(),
        "include_python": [item.strip().replace("\\", "/") for item in include_python],
    }
    return normalized


def _normalize_runtime(value: Any) -> dict[str, Any]:
    if value is None:
        value = {}
    if not isinstance(value, Mapping):
        raise SpecError("runtime must be an object")
    heatmap = value.get("heatmap_bins", 64)
    timeout = value.get("perfetto_timeout_ms", 180000)
    lanes = value.get("max_lanes_per_job", 128)
    for label, number, low, high in (
        ("runtime.heatmap_bins", heatmap, 4, 512),
        ("runtime.perfetto_timeout_ms", timeout, 1000, 3_600_000),
        ("runtime.max_lanes_per_job", lanes, 1, 128),
    ):
        if isinstance(number, bool) or not isinstance(number, int) or not low <= number <= high:
            raise SpecError(f"{label} must be an integer in {low}..{high}")
    real = value.get("real", {})
    sim = value.get("sim", {})
    if not isinstance(real, Mapping) or not isinstance(sim, Mapping):
        raise SpecError("runtime.real and runtime.sim must be objects")
    return {
        "python_requested": str(value.get("python", "")).strip(),
        "python": str(Path(sys.executable).resolve()),
        "git_requested": str(value.get("git", "git")).strip() or "git",
        "heatmap_bins": heatmap,
        "perfetto_timeout_ms": timeout,
        "max_lanes_per_job": lanes,
        "real": dict(real),
        "sim": dict(sim),
    }


def normalize_spec(raw: Any, spec_path: Path) -> dict[str, Any]:
    if not isinstance(raw, Mapping):
        raise SpecError("run-spec must contain a JSON object")
    version = raw.get("schema_version")
    if version != SPEC_SCHEMA_VERSION:
        raise SpecError(f"schema_version must be integer {SPEC_SCHEMA_VERSION}")
    work_raw = _required_text(raw, "work_root")
    work_base = spec_path.resolve().parent
    work_root = _resolve_from(work_raw, work_base, "work_root", must_exist=True)
    if not work_root.is_dir():
        raise SpecError(f"work_root is not a directory: {work_root}")

    source_values = raw.get("source_roots")
    if not isinstance(source_values, Mapping):
        raise SpecError("source_roots must be an object")
    source_roots = {
        component: _normalize_source_root(source_values.get(component), component, work_root)
        for component in SOURCE_COMPONENTS
    }
    if len(set(source_roots.values())) != len(SOURCE_COMPONENTS):
        raise SpecError("model, pytorch, and torch_npu source roots must be distinct")

    profile_values = raw.get("profiles")
    if not isinstance(profile_values, Mapping):
        raise SpecError("profiles must be an object")
    profiles: dict[str, Path] = {}
    for side in ("real", "sim"):
        text = _required_text(profile_values, side)
        path = _resolve_from(text, work_root, f"profiles.{side}", must_exist=True)
        if not path.is_dir():
            raise SpecError(f"profiles.{side} is not a directory: {path}")
        if not is_within(path, work_root):
            raise SpecError(f"profiles.{side} must be below work_root: {path}")
        profiles[side] = path
    if profiles["real"] == profiles["sim"]:
        raise SpecError("profiles.real and profiles.sim must differ")

    output_text = _required_text(raw, "output_root")
    output_root = _resolve_from(output_text, work_root, "output_root", must_exist=False)
    for label, input_root in [
        *((f"source_roots.{key}", value) for key, value in source_roots.items()),
        *((f"profiles.{key}", value) for key, value in profiles.items()),
    ]:
        if is_within(output_root, input_root) or is_within(input_root, output_root):
            raise SpecError(f"output_root must be disjoint from {label}: {input_root}")
    if not is_within(output_root, work_root):
        raise SpecError("output_root must be below work_root")

    entry_value = raw.get("entry_sh")
    if isinstance(entry_value, str):
        entries = [entry_value]
    elif isinstance(entry_value, list):
        entries = entry_value
    else:
        raise SpecError("entry_sh must be a string or string list")
    if not entries or not all(isinstance(item, str) and item.strip() for item in entries):
        raise SpecError("entry_sh must contain at least one non-empty path")
    normalized_entries: list[str] = []
    model_root = source_roots["model"]
    for index, item in enumerate(entries):
        entry = Path(item.strip()).expanduser()
        candidates = [entry] if entry.is_absolute() else [model_root / entry, work_root / entry]
        resolved = next((path.resolve() for path in candidates if path.is_file()), None)
        if resolved is None:
            raise SpecError(f"entry_sh[{index}] does not exist: {item}")
        if not is_within(resolved, model_root):
            raise SpecError(f"entry_sh[{index}] must be below source_roots.model: {resolved}")
        if resolved.suffix.casefold() != ".sh":
            raise SpecError(f"entry_sh[{index}] must be a .sh file: {resolved}")
        relative = resolved.relative_to(model_root).as_posix()
        if relative not in normalized_entries:
            normalized_entries.append(relative)

    perfetto_value = raw.get("perfetto", {})
    if perfetto_value is None:
        perfetto_value = {}
    if not isinstance(perfetto_value, Mapping):
        raise SpecError("perfetto must be an object")
    nested_authorized = perfetto_value.get("online_authorized")
    legacy_authorized = raw.get("perfetto_online_authorized")
    if nested_authorized is not None and not isinstance(nested_authorized, bool):
        raise SpecError("perfetto.online_authorized must be boolean")
    if legacy_authorized is not None and not isinstance(legacy_authorized, bool):
        raise SpecError("perfetto_online_authorized must be boolean")
    if (
        nested_authorized is not None
        and legacy_authorized is not None
        and nested_authorized != legacy_authorized
    ):
        raise SpecError("perfetto authorization fields conflict")
    online_authorized = bool(
        nested_authorized if nested_authorized is not None else legacy_authorized
    )
    screenshot = perfetto_value.get("screenshot", False)
    if not isinstance(screenshot, bool):
        raise SpecError("perfetto.screenshot must be boolean")
    forbidden_roots = [work_root, *source_roots.values(), *profiles.values(), output_root]
    runtime = _normalize_runtime(raw.get("runtime"))
    runtime["git"] = str(
        resolve_trusted_executable(
            runtime["git_requested"],
            forbidden_roots=forbidden_roots,
            label="runtime.git",
        )
    )

    node_requested = str(perfetto_value.get("node", "node")).strip() or "node"
    node = ""
    if online_authorized:
        node = str(
            resolve_trusted_executable(
                node_requested,
                forbidden_roots=forbidden_roots,
                label="perfetto.node",
            )
        )

    browser_requested = str(perfetto_value.get("browser", "")).strip()
    browser = ""
    if online_authorized and browser_requested:
        browser = str(
            resolve_trusted_executable(
                browser_requested,
                forbidden_roots=forbidden_roots,
                label="perfetto.browser",
            )
        )

    playwright_raw = str(perfetto_value.get("playwright_node_modules", "")).strip()
    playwright_root = ""
    if playwright_raw:
        if online_authorized and not Path(playwright_raw).expanduser().is_absolute():
            raise SpecError(
                "perfetto.playwright_node_modules must be absolute when online review is authorized"
            )
        playwright_path = _resolve_from(
            playwright_raw,
            work_root,
            "perfetto.playwright_node_modules",
            must_exist=True,
        )
        if not playwright_path.is_dir():
            raise SpecError(
                f"perfetto.playwright_node_modules is not a directory: {playwright_path}"
            )
        if online_authorized and _inside_any(playwright_path, forbidden_roots):
            raise SpecError(
                "perfetto.playwright_node_modules must be outside all analysis input/output roots"
            )
        playwright_root = str(playwright_path)
    if online_authorized and not browser:
        raise SpecError(
            "perfetto.browser is required for online review and must resolve to an "
            "explicit trusted executable outside work_root"
        )
    degraded_reason = str(
        perfetto_value.get(
            "degraded_reason",
            "online Perfetto review was not authorized by the run-spec",
        )
    ).strip()
    if not online_authorized and degraded_reason:
        degraded_reason = (
            "online Perfetto review was not authorized; " + degraded_reason
        )
    perfetto = {
        "online_authorized": online_authorized,
        "node_requested": node_requested,
        "node": node,
        "playwright_node_modules": playwright_root,
        "browser_requested": browser_requested,
        "browser": browser,
        "screenshot": screenshot,
        "degraded_reason": degraded_reason,
    }
    if not online_authorized and not perfetto["degraded_reason"]:
        raise SpecError("perfetto.degraded_reason is required when online access is disabled")

    normalized = {
        "schema_version": SPEC_SCHEMA_VERSION,
        "work_root": str(work_root),
        "source_roots": {
            key: {"path": str(value)} for key, value in source_roots.items()
        },
        "entry_sh": normalized_entries,
        "profiles": {key: str(value) for key, value in profiles.items()},
        "output_root": str(output_root),
        "perfetto": perfetto,
        "source_owner": _normalize_source_owner(raw.get("source_owner")),
        "runtime": runtime,
    }
    return normalized


def read_and_normalize_spec(spec_path: Path) -> tuple[dict[str, Any], str]:
    try:
        resolved = spec_path.expanduser().resolve(strict=True)
    except OSError as error:
        raise SpecError(f"spec cannot be resolved: {spec_path}: {error}") from error
    if not resolved.is_file():
        raise SpecError(f"spec is not a file: {resolved}")
    try:
        raw = load_json(resolved)
    except json.JSONDecodeError as error:
        raise SpecError(f"spec is not valid JSON: {error}") from error
    normalized = normalize_spec(raw, resolved)
    return normalized, sha256_value(normalized)


def paths_for(spec: Mapping[str, Any]) -> dict[str, Path]:
    output = Path(str(spec["output_root"]))
    evidence = output / "evidence"
    return {
        "output": output,
        "evidence": evidence,
        "state": evidence / "pipeline" / "run-state.json",
        "lock": evidence / "pipeline" / "run.lock",
        "runtime": evidence / "runtime",
        "preflight": evidence / "preflight",
        "alignment": evidence / "alignment",
        "entrypoint": evidence / "source-entrypoints",
        "contract": evidence / "run_comparability_contract.json",
        "source_contracts": evidence / "pipeline" / "source-contracts",
        "source": evidence / "source-causality",
        "snapshots": evidence / "python-guard-snapshots",
        "source_checkpoint": evidence / "pipeline" / "source-causality-checkpoint.json",
        "perfetto": evidence / "perfetto-review",
        "perfetto_checkpoint": evidence / "pipeline" / "perfetto-content-review-checkpoint.json",
        "perfetto_template": evidence / "perfetto-review" / "perfetto_content_review.template.json",
        "report": output / "profiling_alignment_report.md",
        "validation": evidence / "report-validation",
    }


def _new_stage() -> dict[str, Any]:
    return {
        "status": "pending",
        "attempts": 0,
        "input_hash": "",
        "artifact_hashes": {},
        "command": [],
        "command_display": "",
        "reason": "",
        "next_command": "",
        "next_argv": [],
    }


def new_state(spec_path: Path, spec: Mapping[str, Any], spec_hash: str) -> dict[str, Any]:
    now = utc_now()
    return {
        "schema_version": STATE_SCHEMA_VERSION,
        "orchestrator_version": ORCHESTRATOR_VERSION,
        "spec_path": str(spec_path.resolve()),
        "spec_hash": spec_hash,
        "normalized_spec": spec,
        "status": "not-started",
        "current_stage": None,
        "created_at": now,
        "updated_at": now,
        "repository_code_executed": False,
        "stages": {stage: _new_stage() for stage in STAGES},
    }


def load_state(path: Path) -> dict[str, Any] | None:
    if not path.is_file():
        return None
    state = load_json(path)
    if not isinstance(state, dict) or state.get("schema_version") != STATE_SCHEMA_VERSION:
        raise PipelineError(f"unsupported or invalid run-state: {path}")
    stages = state.get("stages")
    if not isinstance(stages, dict) or any(stage not in stages for stage in STAGES):
        raise PipelineError(f"run-state has an incomplete stage table: {path}")
    return state


def save_state(path: Path, state: dict[str, Any]) -> None:
    state["updated_at"] = utc_now()
    state["repository_code_executed"] = False
    atomic_write_json(path, state)


@contextmanager
def pipeline_lock(path: Path, spec_hash: str) -> Iterable[None]:
    """Fail closed when another process owns the same output pipeline."""
    path.parent.mkdir(parents=True, exist_ok=True)
    flags = os.O_CREAT | os.O_EXCL | os.O_WRONLY
    try:
        descriptor = os.open(path, flags, 0o600)
    except FileExistsError as error:
        raise PipelineError(
            f"pipeline lock already exists: {path}; inspect the owning process and remove it manually only if stale"
        ) from error
    try:
        payload = canonical_bytes(
            {"pid": os.getpid(), "spec_hash": spec_hash, "started_at": utc_now()}
        ) + b"\n"
        os.write(descriptor, payload)
        os.fsync(descriptor)
        os.close(descriptor)
        descriptor = -1
        yield
    finally:
        if descriptor >= 0:
            os.close(descriptor)
        try:
            path.unlink()
        except FileNotFoundError:
            pass


def command_display(command: Sequence[str]) -> str:
    if os.name == "nt":
        # list2cmdline targets CreateProcess argv parsing, not PowerShell. Use
        # literal single-quoted arguments so $, ;, &, and subexpressions in
        # otherwise valid paths/URLs cannot become shell syntax.
        quoted = ["'" + argument.replace("'", "''") + "'" for argument in command]
        return "& " + " ".join(quoted)
    return shlex.join(command)


def sibling_script(name: str) -> Path:
    if name not in SAFE_SIBLING_SCRIPTS:
        raise PipelineError(f"refusing to execute a non-allowlisted script: {name}")
    path = Path(__file__).resolve().with_name(name)
    if not path.is_file():
        raise PipelineError(f"required sibling script is missing: {path}")
    return path


def python_command(script_name: str, *arguments: str) -> list[str]:
    return [
        str(Path(sys.executable).resolve()),
        "-I",
        str(sibling_script(script_name)),
        *arguments,
    ]


def self_command(*arguments: str) -> list[str]:
    """Build a display/re-entry command without adding self to the child allowlist."""
    return [
        str(Path(sys.executable).resolve()),
        "-I",
        str(Path(__file__).resolve()),
        *arguments,
    ]


def _invoke(command: Sequence[str], cwd: Path, env: Mapping[str, str] | None = None) -> Invocation:
    if len(command) < 2:
        raise PipelineError("internal command is incomplete")
    script_index = 2 if len(command) >= 3 and command[1] == "-I" else 1
    script = Path(command[script_index]).resolve()
    if script.parent != Path(__file__).resolve().parent or script.name not in SAFE_SIBLING_SCRIPTS:
        raise PipelineError(f"refusing to execute a non-sibling analysis script: {script}")
    child_env = dict(os.environ if env is None else env)
    child_env.pop("PYTHONPATH", None)
    child_env.pop("PYTHONHOME", None)
    for name in list(child_env):
        if name.upper().startswith("NODE_"):
            child_env.pop(name, None)
    for name in list(child_env):
        if name.upper().startswith("NODE_"):
            child_env.pop(name, None)
    child_env.update(
        {
            "PYTHONNOUSERSITE": "1",
            "PYTHONDONTWRITEBYTECODE": "1",
            "PYTHONSAFEPATH": "1",
        }
    )
    completed = subprocess.run(
        list(command),
        cwd=cwd,
        env=child_env,
        capture_output=True,
        text=True,
        check=False,
    )
    return Invocation(completed.returncode, completed.stdout, completed.stderr)


def _tail(text: str, limit: int = 16_000) -> str:
    return text[-limit:]


def artifact_hashes(output_root: Path, paths: Iterable[Path]) -> dict[str, Any]:
    result: dict[str, Any] = {}
    for path in paths:
        resolved = path.resolve(strict=False)
        if not resolved.is_file():
            continue
        try:
            key = resolved.relative_to(output_root).as_posix()
        except ValueError:
            raise PipelineError(f"stage artifact escaped output_root: {resolved}")
        result[key] = sha256_file(resolved)
    return result


def artifacts_intact(output_root: Path, expected: Mapping[str, Any]) -> bool:
    if not expected:
        return False
    for relative, metadata in expected.items():
        path = output_root / relative
        if not path.is_file() or sha256_file(path) != metadata:
            return False
    return True


def output_layout_intact(paths: Mapping[str, Path]) -> bool:
    output = paths["output"]
    if not output.exists():
        return True
    for child in output.iterdir():
        if (
            child == paths["evidence"]
            and child.is_dir()
            and not _is_link_or_reparse(child)
        ):
            continue
        if (
            child == paths["report"]
            and child.is_file()
            and not _is_link_or_reparse(child)
        ):
            continue
        return False
    return True


def stage_artifacts_intact(
    stage: str,
    output_root: Path,
    paths: Mapping[str, Path],
    expected: Mapping[str, Any],
    *,
    allowed_untracked: Sequence[Path] = (),
) -> bool:
    if not artifacts_intact(output_root, expected) or not output_layout_intact(paths):
        return False
    scopes: tuple[Path, ...] = ()
    if stage == "source_causality":
        scopes = (paths["source"], paths["snapshots"])
    elif stage == "perfetto":
        scopes = (paths["perfetto"],)
    elif stage == "validator":
        scopes = (paths["validation"],)
    allowed = {
        path.resolve(strict=False).relative_to(output_root.resolve()).as_posix()
        for path in allowed_untracked
    }
    for scope in scopes:
        prefix = scope.resolve(strict=False).relative_to(output_root.resolve()).as_posix() + "/"
        recorded = {name for name in expected if name.startswith(prefix)}
        actual: set[str] = set()
        for path in files_under(scope):
            try:
                actual.add(path.resolve().relative_to(output_root.resolve()).as_posix())
            except (OSError, ValueError):
                return False
        if actual != recorded | {name for name in allowed if name.startswith(prefix)}:
            return False
    return True


def files_under(root: Path) -> list[Path]:
    if not root.is_dir():
        return []
    return sorted(
        (path for path in root.rglob("*") if path.is_file()),
        key=lambda path: path.relative_to(root).as_posix(),
    )


def _path_fingerprint(path: Path) -> dict[str, Any]:
    try:
        stat = path.stat()
        return {
            "path": str(path),
            "exists": True,
            "kind": "dir" if path.is_dir() else "file",
            "size": stat.st_size,
            "mtime_ns": stat.st_mtime_ns,
        }
    except OSError:
        return {"path": str(path), "exists": False}


def _is_link_or_reparse(path: Path) -> bool:
    try:
        details = path.lstat()
    except OSError:
        return False
    reparse = bool(getattr(details, "st_file_attributes", 0) & 0x400)
    return path.is_symlink() or reparse


def _directory_inventory(path: Path, *, reject_links: bool = False) -> dict[str, Any]:
    """Hash a recursive metadata inventory without reading large trace bytes."""
    key = str(path.resolve(strict=False))
    digest = hashlib.sha256()
    file_count = 0
    directory_count = 0
    total_bytes = 0
    if not path.is_dir():
        return _path_fingerprint(path)
    if reject_links and _is_link_or_reparse(path):
        raise PipelineError(f"profiling root must not be a symlink/reparse point: {path}")
    for current, directory_names, file_names in os.walk(path, followlinks=False):
        directory_names.sort()
        file_names.sort()
        current_path = Path(current)
        if reject_links:
            for name in (*directory_names, *file_names):
                item = current_path / name
                if _is_link_or_reparse(item):
                    raise PipelineError(
                        f"profiling input contains a symlink/reparse point: {item}"
                    )
        directory_count += 1
        for name in file_names:
            item = current_path / name
            relative = item.relative_to(path).as_posix()
            try:
                stat = item.stat(follow_symlinks=False)
                record = f"{relative}\0{stat.st_size}\0{stat.st_mtime_ns}\0{stat.st_mode}\n"
                total_bytes += stat.st_size
            except OSError as error:
                record = f"{relative}\0ERROR\0{type(error).__name__}\n"
            digest.update(record.encode("utf-8", errors="surrogatepass"))
            file_count += 1
    result = {
        "path": key,
        "exists": True,
        "kind": "directory-inventory",
        "sha256": digest.hexdigest(),
        "file_count": file_count,
        "directory_count": directory_count,
        "total_bytes": total_bytes,
    }
    return result


def _path_without_links(root: Path, relative: Path) -> tuple[Path | None, str]:
    if relative.is_absolute() or ".." in relative.parts or not relative.parts:
        return None, "path is not a safe repository-relative path"
    current = root
    for part in relative.parts:
        current = current / part
        if _is_link_or_reparse(current):
            return None, f"path component is a symlink/reparse point: {current}"
    try:
        resolved = current.resolve(strict=True)
    except OSError as error:
        return None, f"path cannot be resolved: {error}"
    if not is_within(resolved, root.resolve()):
        return None, "path escaped repository root"
    return resolved, ""


def _small_git_fingerprint(repo_root: Path) -> list[dict[str, Any]]:
    git_root = repo_root / ".git"
    records: list[dict[str, Any]] = []
    if not git_root.exists() and not git_root.is_symlink():
        return [{"path": ".git", "status": "absent"}]
    if _is_link_or_reparse(git_root):
        return [{"path": ".git", "status": "invalid-link-or-reparse"}]
    if git_root.is_file():
        metadata = sha256_file(git_root)
        return [{"path": ".git", "status": "gitdir-file-not-followed", **metadata}]
    if not git_root.is_dir():
        return [{"path": ".git", "status": "invalid-kind"}]
    names = [Path("HEAD"), Path("index"), Path("packed-refs")]
    head = git_root / "HEAD"
    if head.is_file() and not _is_link_or_reparse(head):
        try:
            head_text = head.read_text(encoding="utf-8", errors="strict").strip()
        except (OSError, UnicodeError):
            head_text = ""
        if head_text.startswith("ref:"):
            ref = Path(head_text.partition(":")[2].strip())
            if not ref.is_absolute() and ".." not in ref.parts:
                names.append(ref)
    seen: set[str] = set()
    for relative in names:
        key = relative.as_posix()
        if key in seen:
            continue
        seen.add(key)
        candidate = git_root / relative
        if not candidate.exists() and not candidate.is_symlink():
            records.append({"path": f".git/{key}", "status": "absent"})
            continue
        path, error = _path_without_links(git_root, relative)
        if path is None:
            records.append({"path": f".git/{key}", "status": "invalid", "reason": error})
            continue
        if not path.is_file():
            records.append({"path": f".git/{key}", "status": "not-file"})
            continue
        size = path.stat().st_size
        if size > 16 * 1024 * 1024:
            records.append({"path": f".git/{key}", "status": "too-large", "bytes": size})
            continue
        records.append({"path": f".git/{key}", "status": "hashed", **sha256_file(path)})
    return records


def _source_repository_fingerprint(
    spec: Mapping[str, Any], paths: Mapping[str, Path]
) -> dict[str, Any]:
    manifest_path = paths["source"] / "source_analysis_manifest.json"
    evidence_path = paths["source"] / "source_evidence.csv"
    if not manifest_path.is_file() or not evidence_path.is_file():
        return {"status": "not-available", "reason": "source analysis is not present"}
    try:
        manifest = load_json(manifest_path)
        raw_component = str(manifest.get("source_component", "")).casefold().replace("-", "_")
        component = {"mindspeed": "model", "torch": "pytorch", "torchnpu": "torch_npu"}.get(
            raw_component, raw_component
        )
        if component not in SOURCE_COMPONENTS:
            raise ValueError("invalid source_component")
        repo_root = Path(spec["source_roots"][component]["path"]).resolve(strict=True)
        with evidence_path.open(
            "r", newline="", encoding="utf-8-sig", errors="strict"
        ) as handle:
            rows = list(csv.DictReader(handle))
    except (OSError, UnicodeError, ValueError, json.JSONDecodeError, csv.Error) as error:
        return {"status": "invalid", "reason": f"source binding cannot be read: {error}"}
    expected_by_path: dict[str, str] = {}
    issues: list[str] = []
    for row in rows:
        if str(row.get("evidence_kind", "")) != "python-ast-parsed":
            continue
        relative_text = str(row.get("path", "")).strip().replace("\\", "/")
        expected = str(row.get("content_sha256", "")).strip().casefold()
        if (
            not relative_text
            or len(expected) != 64
            or any(character not in "0123456789abcdef" for character in expected)
        ):
            issues.append(f"invalid AST source binding row: {relative_text or '<empty>'}")
            continue
        previous = expected_by_path.setdefault(relative_text, expected)
        if previous != expected:
            issues.append(f"conflicting expected content SHA: {relative_text}")
    file_records: list[dict[str, Any]] = []
    for relative_text, expected in sorted(expected_by_path.items()):
        relative = Path(relative_text)
        resolved, error = _path_without_links(repo_root, relative)
        record: dict[str, Any] = {"path": relative_text, "expected_sha256": expected}
        if resolved is None or resolved.suffix.casefold() != ".py":
            record.update(
                {
                    "status": "invalid",
                    "reason": error or "AST source binding path is not a Python file",
                }
            )
            issues.append(f"invalid AST source path: {relative_text}")
        else:
            try:
                source = resolved.read_text(encoding="utf-8-sig", errors="strict")
                actual = hashlib.sha256(source.encode("utf-8")).hexdigest()
                record.update(
                    {
                        "status": "match" if actual == expected else "mismatch",
                        "actual_sha256": actual,
                        "bytes": resolved.stat().st_size,
                    }
                )
                if actual != expected:
                    issues.append(f"AST source content changed: {relative_text}")
            except (OSError, UnicodeError) as read_error:
                record.update({"status": "invalid", "reason": str(read_error)})
                issues.append(f"AST source cannot be read: {relative_text}")
        file_records.append(record)
    if not expected_by_path:
        issues.append("source_evidence.csv contains no python-ast-parsed source bindings")
    return {
        "status": "valid" if not issues else "invalid",
        "component": component,
        "repo_root": str(repo_root),
        "ast_files": file_records,
        "git_control_files": _small_git_fingerprint(repo_root),
        "issues": issues,
    }


def stage_input_hash(
    stage: str, spec: Mapping[str, Any], spec_hash: str, state: Mapping[str, Any], paths: Mapping[str, Path]
) -> str:
    index = STAGES.index(stage)
    upstream = {
        name: state["stages"][name].get("artifact_hashes", {}) for name in STAGES[:index]
    }
    direct: list[dict[str, Any]] = []
    if stage in {"preflight", "align"}:
        direct.extend(
            _directory_inventory(Path(spec["profiles"][side]), reject_links=True)
            for side in ("real", "sim")
        )
    if stage == "entrypoint":
        model = Path(spec["source_roots"]["model"]["path"])
        direct.append(_directory_inventory(model))
        direct.extend(_path_fingerprint(model / entry) for entry in spec["entry_sh"])
    if stage == "source_causality":
        direct.extend(
            _path_fingerprint(path)
            for path in (
                paths["source"] / "source_analysis_manifest.json",
                *(paths["source"] / name for name in SOURCE_ANALYSIS_ARTIFACTS),
            )
        )
        direct.append(_source_repository_fingerprint(spec, paths))
    return sha256_value(
        {
            "stage": stage,
            "spec_hash": spec_hash,
            "upstream_artifacts": upstream,
            "direct_inputs": direct,
        }
    )


def overall_status(state: Mapping[str, Any]) -> str:
    statuses = [state["stages"][stage].get("status") for stage in STAGES]
    if "failed" in statuses:
        return "failed"
    if "running" in statuses:
        return "running"
    if "needs-agent" in statuses:
        return "needs-agent"
    if any(status == "pending" for status in statuses):
        return "partial"
    validator = state["stages"]["validator"].get("status")
    if validator != "complete":
        return "partial"
    # A degraded auxiliary stage remains fully visible in the stage table but
    # does not defeat a formally validated report.  Typical examples are an
    # explicitly unauthorized Perfetto review and unknown run-contract facts.
    return "complete"


def _stage_start(
    state_path: Path,
    state: dict[str, Any],
    stage: str,
    input_hash: str,
    command: Sequence[str] | None = None,
) -> None:
    row = state["stages"][stage]
    row.update(
        {
            "status": "running",
            "attempts": int(row.get("attempts", 0)) + 1,
            "input_hash": input_hash,
            "artifact_hashes": {},
            "started_at": utc_now(),
            "finished_at": None,
            "command": list(command or []),
            "command_display": command_display(command or []) if command else "",
            "reason": "",
            "next_command": "",
            "next_argv": [],
            "stdout_tail": "",
            "stderr_tail": "",
            "exit_code": None,
        }
    )
    state["current_stage"] = stage
    state["status"] = "running"
    save_state(state_path, state)


def _stage_finish(
    state_path: Path,
    state: dict[str, Any],
    stage: str,
    status: str,
    output_root: Path,
    artifacts: Iterable[Path],
    *,
    reason: str = "",
    invocation: Invocation | None = None,
    next_command: Sequence[str] | str | None = None,
    extra: Mapping[str, Any] | None = None,
) -> None:
    row = state["stages"][stage]
    row.update(
        {
            "status": status,
            "artifact_hashes": artifact_hashes(output_root, artifacts),
            "finished_at": utc_now(),
            "reason": reason,
        }
    )
    if invocation is not None:
        row["exit_code"] = invocation.returncode
        row["stdout_tail"] = _tail(invocation.stdout)
        row["stderr_tail"] = _tail(invocation.stderr)
    if next_command:
        row["next_command"] = (
            next_command if isinstance(next_command, str) else command_display(next_command)
        )
    if extra:
        row.update(extra)
    state["current_stage"] = None
    state["status"] = overall_status(state)
    save_state(state_path, state)


def _fact(value: Any, side: str, field: str, spec_path: Path) -> dict[str, Any]:
    if value is None or value == "":
        return {
            "value": None,
            "status": "unknown",
            "evidence": f"not supplied in {spec_path.name}#runtime.{side}.{field}",
        }
    if isinstance(value, Mapping):
        declared_value = value.get("value")
        declared_evidence = str(value.get("evidence", "")).strip()
    else:
        declared_value = value
        declared_evidence = ""
    return {
        "value": declared_value,
        "status": "user-declared",
        "evidence": declared_evidence
        or f"user-declared in {spec_path.name}#runtime.{side}.{field}",
    }


def build_run_contract(
    spec: Mapping[str, Any],
    spec_path: Path,
    *,
    analyzed_component: str | None = None,
) -> dict[str, Any]:
    owner = spec.get("source_owner") or {}
    owner_component = owner.get("component", "") if isinstance(owner, Mapping) else ""
    component = analyzed_component or owner_component
    owner_matches = bool(component and component == owner_component)
    source_fact = {
        "component": component,
        "repository": (
            owner.get("repository_url", "")
            if isinstance(owner, Mapping) and owner_matches
            else ""
        ),
        "commit": (
            owner.get("commit", "") if isinstance(owner, Mapping) and owner_matches else ""
        ),
        "tree_hash": "",
        "build_id": "",
        "status": "unknown",
        "evidence": (
            "source_owner selects an analysis checkout only; no runtime-to-checkout binding "
            "was established"
        ),
    }
    runtime = spec["runtime"]
    fields = (
        "model_code",
        "workload",
        "phase",
        "profiler_schedule",
        "torch_npu_version",
        "cann_version",
    )
    sides: dict[str, Any] = {}
    for side in ("real", "sim"):
        declared = runtime.get(side, {})
        sides[side] = {field: _fact(declared.get(field), side, field, spec_path) for field in fields}
        sides[side]["analyzed_source"] = dict(source_fact)
        sides[side]["python_version"] = {
            "value": "ignored-by-policy",
            "status": "ignored",
            "evidence": "Python version differences are informational and excluded from fidelity conclusions",
        }
        sides[side]["pytorch_version"] = {
            "value": "ignored-by-policy",
            "status": "ignored",
            "evidence": "PyTorch version differences are informational and excluded from fidelity conclusions",
        }
    source_roots = {}
    for component_name in SOURCE_COMPONENTS:
        source_roots[component_name] = {
            "path": spec["source_roots"][component_name]["path"],
            "role": (
                "model-entry" if component_name == "model" else "reference-source-baseline"
            ),
            "binding_side": "shared" if component_name == "model" else "real/reference",
            "status": "path-verified",
            "evidence": "normalized run-spec path exists; runtime version binding remains unverified",
        }
    comparisons = {field: "unknown" for field in ("analyzed_source", *fields)}
    comparisons.update({"python_version": "ignored", "pytorch_version": "ignored"})
    return {
        "schema_version": 1,
        "status": "partial",
        "generated_by": f"profiling_alignment.py/{ORCHESTRATOR_VERSION}",
        "source_roots": source_roots,
        **sides,
        "comparisons": comparisons,
        "policy": {
            "reference_environment": "real/reference",
            "python_version_comparison": "ignored",
            "pytorch_version_comparison": "ignored",
            "unknown_is_not_equal": True,
            "repository_code_executed": False,
        },
    }


def _source_contract_path(paths: Mapping[str, Path], component: str) -> Path:
    if component not in SOURCE_COMPONENTS:
        raise PipelineError(f"invalid source contract component: {component}")
    return paths["source_contracts"] / f"{component}.json"


def _source_analyze_command(spec: Mapping[str, Any], paths: Mapping[str, Path], component: str) -> list[str]:
    owner = spec.get("source_owner") or {}
    root = spec["source_roots"][component]["path"]
    contract_path = (
        paths["contract"]
        if owner and owner.get("component") == component
        else _source_contract_path(paths, component)
    )
    command = python_command(
        "analyze_control_flow.py",
        "--repo-root",
        root,
        "--alignment-output",
        str(paths["alignment"]),
        "--output",
        str(paths["source"]),
        "--source-analysis-dir",
        str(paths["entrypoint"]),
        "--runtime-binding",
        str(owner.get("runtime_binding", "unverified")),
        "--run-contract",
        str(contract_path),
        "--git-executable",
        str(spec["runtime"]["git"]),
    )
    for entry in spec["entry_sh"]:
        command.extend(["--entry", entry])
    for path in owner.get("include_python", []):
        command.extend(["--include-python", path])
    if owner.get("repository_url"):
        command.extend(["--repository-url", owner["repository_url"]])
    if owner.get("commit"):
        command.extend(["--commit", owner["commit"]])
    return command


def _snapshot_command(
    spec: Mapping[str, Any],
    paths: Mapping[str, Path],
    component: str,
    *,
    output: Path | None = None,
) -> list[str]:
    return python_command(
        "render_python_guard_snapshots.py",
        "--repo-root",
        spec["source_roots"][component]["path"],
        "--source-causality-dir",
        str(paths["source"]),
        "--output",
        str(output or paths["snapshots"]),
    )


def _source_component_from_manifest(path: Path) -> str:
    try:
        manifest = load_json(path)
    except (OSError, json.JSONDecodeError) as error:
        raise PipelineError(f"source manifest cannot be read: {path}: {error}") from error
    raw = str(manifest.get("source_component", "")).strip().casefold().replace("-", "_")
    aliases = {"mindspeed": "model", "torch": "pytorch", "torchnpu": "torch_npu"}
    component = aliases.get(raw, raw)
    if component not in SOURCE_COMPONENTS:
        raise PipelineError(
            f"source manifest has no canonical source_component: {raw or '<empty>'}"
        )
    return component


def _source_manifest_contract_sha256(path: Path) -> str:
    try:
        manifest = load_json(path)
    except (OSError, json.JSONDecodeError) as error:
        raise PipelineError(f"source manifest cannot be read: {path}: {error}") from error
    direct = str(manifest.get("run_contract_sha256", "")).strip().casefold()
    nested = manifest.get("run_comparability")
    nested_sha = (
        str(nested.get("sha256", "")).strip().casefold()
        if isinstance(nested, Mapping)
        else ""
    )
    digest = direct or nested_sha
    if len(digest) != 64 or any(character not in "0123456789abcdef" for character in digest):
        raise PipelineError("source manifest has no valid run-contract SHA-256")
    return digest


def _validated_source_artifacts(source_manifest: Path) -> list[Path]:
    try:
        manifest = load_json(source_manifest)
    except (OSError, json.JSONDecodeError) as error:
        raise PipelineError(f"source manifest cannot be read: {source_manifest}: {error}") from error
    declared = manifest.get("artifacts")
    if (
        not isinstance(declared, list)
        or len(declared) != len(SOURCE_ANALYSIS_ARTIFACTS)
        or not all(isinstance(name, str) for name in declared)
        or set(declared) != set(SOURCE_ANALYSIS_ARTIFACTS)
    ):
        raise PipelineError(
            "source manifest artifacts must exactly declare the complete analyzer evidence set"
        )
    integrity = manifest.get("artifact_integrity")
    if not isinstance(integrity, Mapping):
        raise PipelineError("source manifest artifact_integrity is missing")
    if set(integrity) != set(SOURCE_ANALYSIS_ARTIFACTS):
        raise PipelineError(
            "source manifest artifact_integrity must exactly cover the analyzer evidence set"
        )
    source_root = source_manifest.parent
    source_files = files_under(source_root)
    if any(_is_link_or_reparse(path) for path in source_files):
        raise PipelineError("source-causality evidence must not contain links/reparse points")
    actual_names = {path.relative_to(source_root).as_posix() for path in source_files}
    expected_names = {"source_analysis_manifest.json", *SOURCE_ANALYSIS_ARTIFACTS}
    if actual_names != expected_names:
        raise PipelineError(
            "source-causality directory contains missing or unmanifested files"
        )
    artifacts: list[Path] = []
    for name in SOURCE_ANALYSIS_ARTIFACTS:
        path = source_root / name
        entry = integrity.get(name)
        if not path.is_file() or not isinstance(entry, Mapping):
            raise PipelineError(f"source evidence artifact is missing from disk/manifest: {name}")
        actual = sha256_file(path)
        expected_sha = str(entry.get("sha256", "")).strip().casefold()
        expected_bytes = entry.get("bytes")
        if expected_sha != actual["sha256"] or expected_bytes != actual["bytes"]:
            raise PipelineError(f"source evidence artifact integrity mismatch: {name}")
        artifacts.append(path)
    return artifacts


def _bind_owner_contract_from_manifest(
    spec: Mapping[str, Any],
    paths: Mapping[str, Path],
    state: dict[str, Any],
    component: str,
    source_manifest: Path,
) -> None:
    """Bind the exact owner contract used by the external source analysis.

    When ``source_owner`` was omitted from the initial spec, the needs-agent
    checkpoint offers one command per canonical owner. Each command consumes a
    different immutable candidate contract. The selected analyzer records that
    contract's SHA in its manifest; only that exact candidate may be promoted to
    the main contract consumed by snapshots, the report, and the validator.
    """
    declared_owner = spec.get("source_owner") or {}
    candidate_path = (
        paths["contract"]
        if declared_owner and declared_owner.get("component") == component
        else _source_contract_path(paths, component)
    )
    if not candidate_path.is_file():
        raise PipelineError(f"owner-specific run contract is missing: {candidate_path}")
    expected_sha = sha256_file(candidate_path)["sha256"]
    manifest_sha = _source_manifest_contract_sha256(source_manifest)
    if manifest_sha != expected_sha:
        raise PipelineError(
            "source manifest run-contract SHA does not match the selected owner contract"
        )
    if sha256_file(paths["contract"])["sha256"] != expected_sha:
        atomic_write_json(paths["contract"], load_json(candidate_path))
    contract_artifacts = [paths["contract"]] + [
        _source_contract_path(paths, owner) for owner in SOURCE_COMPONENTS
    ]
    missing = [str(path) for path in contract_artifacts if not path.is_file()]
    if missing:
        raise PipelineError(
            f"run_contract required artifacts are missing: {', '.join(missing)}"
        )
    contract_stage = state["stages"]["run_contract"]
    contract_stage["artifact_hashes"] = artifact_hashes(
        Path(spec["output_root"]), contract_artifacts
    )
    contract_stage["selected_source_component"] = component
    contract_stage["reason"] = (
        f"owner-specific contract selected from source manifest: {component}; "
        "runtime/source equality remains evidence-gated"
    )


def _perfetto_job_key(job: Mapping[str, Any]) -> tuple[str, str, str]:
    output_text = str(job.get("output_dir", ""))
    batch = str(job.get("batch", "") or (Path(output_text).name if output_text else ""))
    return (
        str(job.get("rank_pair_id", "")),
        str(job.get("environment", "")),
        batch,
    )


def _perfetto_child(root: Path, raw: Any, label: str) -> Path:
    text = str(raw or "").strip()
    if not text:
        raise PipelineError(f"{label} path is empty")
    candidate = Path(text).expanduser()
    if not candidate.is_absolute():
        candidate = root / candidate
    try:
        resolved = candidate.resolve(strict=True)
    except OSError as error:
        raise PipelineError(f"{label} cannot be resolved: {candidate}: {error}") from error
    if not is_within(resolved, root.resolve()):
        raise PipelineError(f"{label} escaped perfetto-review: {resolved}")
    return resolved


def _perfetto_artifact_paths(
    review_root: Path, batch: Mapping[str, Any], job: Mapping[str, Any]
) -> tuple[Path, dict[str, Path]]:
    output_dir = _perfetto_child(review_root, job.get("output_dir"), "job output_dir")
    if not output_dir.is_dir():
        raise PipelineError(f"job output_dir is not a directory: {output_dir}")
    renderer_manifest = _perfetto_child(
        review_root, job.get("manifest_path"), "renderer manifest"
    )
    artifacts = {
        "manifest": renderer_manifest,
        "html": output_dir / "perfetto_ui_frame.html",
        "text": output_dir / "perfetto_ui_text.txt",
        "browser-log": output_dir / "perfetto_browser.log",
    }
    if batch.get("screenshot_requested") is True:
        artifacts["screenshot"] = output_dir / "perfetto_ui.png"
    for kind, path in artifacts.items():
        if not path.is_file() or path.stat().st_size <= 0:
            raise PipelineError(f"Perfetto {kind} artifact is missing or empty: {path}")
    return renderer_manifest, artifacts


def _build_perfetto_review_template(
    review_root: Path, batch_path: Path
) -> tuple[dict[str, Any], list[dict[str, Any]]]:
    try:
        batch = load_json(batch_path)
    except (OSError, json.JSONDecodeError) as error:
        raise PipelineError(f"Perfetto batch manifest cannot be read: {error}") from error
    if not isinstance(batch, Mapping):
        raise PipelineError("Perfetto batch manifest root is not an object")
    jobs = batch.get("jobs")
    if batch.get("status") != "complete" or not isinstance(jobs, list) or not jobs:
        raise PipelineError("online Perfetto batch is not complete or has no jobs")
    rows: list[dict[str, Any]] = []
    checkpoint_jobs: list[dict[str, Any]] = []
    seen: set[tuple[str, str, str]] = set()
    for raw_job in jobs:
        if not isinstance(raw_job, Mapping):
            raise PipelineError("Perfetto batch contains a non-object job")
        key = _perfetto_job_key(raw_job)
        if not all(key) or key in seen:
            raise PipelineError(f"Perfetto batch has an invalid/duplicate job key: {key}")
        seen.add(key)
        if not all(
            (
                raw_job.get("planned_status") == "ready",
                raw_job.get("run_status") == "success",
                raw_job.get("auto_artifact_gate") == "auto-artifacts-ready",
                raw_job.get("lane_batch_union_complete") is True,
            )
        ):
            raise PipelineError(f"Perfetto job did not pass automatic gates: {key}")
        renderer_manifest, artifact_paths = _perfetto_artifact_paths(
            review_root, batch, raw_job
        )
        try:
            renderer = load_json(renderer_manifest)
        except (OSError, json.JSONDecodeError) as error:
            raise PipelineError(f"renderer manifest cannot be read for {key}: {error}") from error
        if not isinstance(renderer, Mapping):
            raise PipelineError(f"renderer manifest root is not an object for {key}")
        run_id = str(renderer.get("run_id", ""))
        trace_sha = str((renderer.get("trace") or {}).get("sha256", "")).casefold()
        if renderer.get("status") != "success" or not run_id:
            raise PipelineError(f"renderer manifest is not successful for {key}")
        renderer_sql = renderer.get("sql")
        if not isinstance(renderer_sql, Mapping):
            raise PipelineError(f"renderer manifest /sql is not an object for {key}")
        if trace_sha != str(raw_job.get("expected_trace_sha256", "")).casefold():
            raise PipelineError(f"renderer/job trace SHA mismatch for {key}")
        artifact_rows = [
            {"kind": kind, **sha256_file(path), "path": str(path.resolve())}
            for kind, path in artifact_paths.items()
        ]
        row = {
            "rank_pair_id": key[0],
            "environment": key[1],
            "batch": key[2],
            "status": "pending-review",
            "batch_job_sha256": sha256_value(raw_job),
            "renderer_run_id": run_id,
            "renderer_manifest_sha256": sha256_file(renderer_manifest)["sha256"],
            "trace_sha256": trace_sha,
            "artifacts": artifact_rows,
            "sql_path": str(renderer_manifest.resolve()),
            "sql_json_pointer": "/sql",
            "sql_query_ids": [
                str(item.get("query_id", ""))
                for item in (renderer_sql.get("query_results") or [])
                if isinstance(item, Mapping)
            ],
            "observations": [],
        }
        rows.append(row)
        checkpoint_jobs.append(
            {
                "job_key": list(key),
                "batch_job_sha256": row["batch_job_sha256"],
                "renderer_run_id": run_id,
                "renderer_manifest_sha256": row["renderer_manifest_sha256"],
                "trace_sha256": trace_sha,
                "html_path": next(
                    item["path"] for item in artifact_rows if item["kind"] == "html"
                ),
                "text_path": next(
                    item["path"] for item in artifact_rows if item["kind"] == "text"
                ),
                "sql_path": str(renderer_manifest.resolve()),
                "sql_json_pointer": "/sql",
                "browser_log_path": next(
                    item["path"]
                    for item in artifact_rows
                    if item["kind"] == "browser-log"
                ),
                "manifest_path": str(renderer_manifest.resolve()),
                "screenshot_path": next(
                    (
                        item["path"]
                        for item in artifact_rows
                        if item["kind"] == "screenshot"
                    ),
                    "",
                ),
            }
        )
    template = {
        "schema_version": 1,
        "status": "pending-review",
        "batch_manifest_sha256": sha256_file(batch_path)["sha256"],
        "review_methods": ["manifest", "html", "text", "sql", "browser-log"],
        "reviewed_jobs": rows,
        "observations": [],
        "screenshot_reviewed": False,
        "canvas_claims_made": False,
        "instructions": [
            "Read every listed manifest, HTML, text, embedded /sql result, and browser log.",
            "Copy this file to perfetto_content_review.json only after review.",
            "Set root and every job status to complete and write non-empty observations.",
            "Do not change hashes, paths, run_id, trace SHA, or batch identity.",
        ],
    }
    return template, checkpoint_jobs


def _validate_perfetto_content_review(
    review_root: Path, batch_path: Path, content_path: Path
) -> tuple[bool, str]:
    try:
        batch = load_json(batch_path)
        content = load_json(content_path)
    except (OSError, json.JSONDecodeError) as error:
        return False, f"content review cannot be read: {error}"
    if not isinstance(batch, Mapping) or not isinstance(content, Mapping):
        return False, "batch/content review roots must be JSON objects"
    jobs = batch.get("jobs")
    reviewed_jobs = content.get("reviewed_jobs")
    observations = content.get("observations")
    methods = {str(item).casefold() for item in content.get("review_methods", [])}
    root_checks = (
        batch.get("status") == "complete",
        content.get("schema_version") == 1,
        content.get("status") == "complete",
        content.get("batch_manifest_sha256") == sha256_file(batch_path)["sha256"],
        {"manifest", "html", "text", "sql", "browser-log"}.issubset(methods),
        isinstance(observations, list) and bool(observations),
        content.get("canvas_claims_made") is False
        or content.get("screenshot_reviewed") is True,
        isinstance(jobs, list) and bool(jobs),
        isinstance(reviewed_jobs, list),
    )
    if not all(root_checks):
        return False, "content review root status/hash/method/observation gate failed"
    assert isinstance(jobs, list) and isinstance(reviewed_jobs, list)
    expected: dict[tuple[str, str, str], Mapping[str, Any]] = {}
    for job in jobs:
        if not isinstance(job, Mapping):
            return False, "batch contains a non-object job"
        key = _perfetto_job_key(job)
        if not all(key) or key in expected:
            return False, f"batch has an invalid/duplicate job key: {key}"
        expected[key] = job
    actual: dict[tuple[str, str, str], Mapping[str, Any]] = {}
    for row in reviewed_jobs:
        if not isinstance(row, Mapping):
            return False, "content review contains a non-object job"
        key = _perfetto_job_key(row)
        if not all(key) or key in actual:
            return False, f"content review has an invalid/duplicate job key: {key}"
        actual[key] = row
    if set(actual) != set(expected) or len(actual) != len(reviewed_jobs):
        return False, "content review does not cover every batch job exactly once"
    for key, job in expected.items():
        row = actual[key]
        try:
            renderer_manifest, artifact_paths = _perfetto_artifact_paths(
                review_root, batch, job
            )
            renderer = load_json(renderer_manifest)
        except (PipelineError, OSError, json.JSONDecodeError) as error:
            return False, str(error)
        if not isinstance(renderer, Mapping):
            return False, f"renderer manifest root is not an object for {key}"
        renderer_sql = renderer.get("sql")
        if not isinstance(renderer_sql, Mapping):
            return False, f"renderer manifest /sql is not an object for {key}"
        renderer_query_ids = [
            str(item.get("query_id", ""))
            for item in (renderer_sql.get("query_results") or [])
            if isinstance(item, Mapping)
        ]
        expected_trace_sha = str(job.get("expected_trace_sha256", "")).casefold()
        renderer_trace_sha = str((renderer.get("trace") or {}).get("sha256", "")).casefold()
        job_observations = row.get("observations")
        try:
            review_sql_path = _perfetto_child(
                review_root, row.get("sql_path"), "review SQL path"
            )
        except PipelineError as error:
            return False, str(error)
        if not all(
            (
                row.get("status") == "complete",
                row.get("batch_job_sha256") == sha256_value(job),
                row.get("renderer_run_id") == renderer.get("run_id"),
                row.get("renderer_manifest_sha256")
                == sha256_file(renderer_manifest)["sha256"],
                row.get("trace_sha256") == expected_trace_sha == renderer_trace_sha,
                review_sql_path == renderer_manifest,
                row.get("sql_json_pointer") == "/sql",
                row.get("sql_query_ids") == renderer_query_ids,
                isinstance(job_observations, list) and bool(job_observations),
            )
        ):
            return False, f"content review identity/hash/observation gate failed for {key}"
        artifact_rows = row.get("artifacts")
        if not isinstance(artifact_rows, list):
            return False, f"content review artifacts are missing for {key}"
        by_kind: dict[str, Mapping[str, Any]] = {}
        for artifact in artifact_rows:
            if not isinstance(artifact, Mapping):
                return False, f"content review has a non-object artifact for {key}"
            kind = str(artifact.get("kind", ""))
            if not kind or kind in by_kind:
                return False, f"content review has duplicate/empty artifact kind for {key}"
            by_kind[kind] = artifact
        if set(by_kind) != set(artifact_paths):
            return False, f"content review artifact set is incomplete for {key}"
        for kind, path in artifact_paths.items():
            entry = by_kind[kind]
            metadata = sha256_file(path)
            try:
                recorded_path = _perfetto_child(
                    review_root, entry.get("path"), f"review {kind} path"
                )
            except PipelineError as error:
                return False, str(error)
            if not all(
                (
                    recorded_path == path.resolve(),
                    entry.get("bytes") == metadata["bytes"],
                    str(entry.get("sha256", "")).casefold() == metadata["sha256"],
                )
            ):
                return False, f"content review artifact hash/path mismatch for {key}/{kind}"
    return True, ""


def _run_command_stage(
    state_path: Path,
    state: dict[str, Any],
    stage: str,
    input_hash: str,
    command: list[str],
    spec: Mapping[str, Any],
    artifacts: Sequence[Path],
    *,
    accepted_codes: set[int] = {0},
    env: Mapping[str, str] | None = None,
) -> Invocation:
    _stage_start(state_path, state, stage, input_hash, command)
    invocation = _invoke(command, Path(spec["work_root"]), env)
    if invocation.returncode not in accepted_codes:
        _stage_finish(
            state_path,
            state,
            stage,
            "failed",
            Path(spec["output_root"]),
            artifacts,
            reason=f"command returned {invocation.returncode}",
            invocation=invocation,
        )
        raise PipelineError(
            f"{stage} failed with exit code {invocation.returncode}: {_tail(invocation.stderr, 2000)}"
        )
    missing = [str(path) for path in artifacts if not path.is_file()]
    if missing:
        _stage_finish(
            state_path,
            state,
            stage,
            "failed",
            Path(spec["output_root"]),
            artifacts,
            reason=f"required artifacts are missing: {', '.join(missing)}",
            invocation=invocation,
        )
        raise PipelineError(
            f"{stage} did not create required artifacts: {', '.join(missing)}"
        )
    return invocation


def run_stage(
    stage: str,
    spec: dict[str, Any],
    spec_path: Path,
    spec_hash: str,
    state: dict[str, Any],
    state_path: Path,
    paths: dict[str, Path],
    input_hash: str,
) -> None:
    output_root = paths["output"]
    if stage == "runtime":
        artifact = paths["runtime"] / "runtime_doctor.json"
        command = python_command(
            "runtime_doctor.py",
            "--spec", str(spec_path.resolve()),
            "--output-root", str(output_root),
            "--git", str(spec["runtime"]["git"]),
        )
        if spec["perfetto"]["online_authorized"]:
            command.extend(["--node", str(spec["perfetto"]["node"])])
            if spec["perfetto"]["browser"]:
                command.extend(["--browser", str(spec["perfetto"]["browser"])])
            if spec["perfetto"]["playwright_node_modules"]:
                command.extend(
                    [
                        "--playwright-node-modules",
                        str(spec["perfetto"]["playwright_node_modules"]),
                    ]
                )
        invocation = _run_command_stage(
            state_path, state, stage, input_hash, command, spec, [artifact], accepted_codes={0, 1}
        )
        payload = load_json(artifact) if artifact.is_file() else {}
        blocking_checks = payload.get("blocking_checks")
        blocked = (
            invocation.returncode != 0
            or payload.get("status") == "blocked"
            or (isinstance(blocking_checks, list) and bool(blocking_checks))
        )
        if blocked:
            _stage_finish(
                state_path,
                state,
                stage,
                "failed",
                output_root,
                [artifact],
                reason=f"runtime doctor blocking checks: {blocking_checks or ['status']}",
                invocation=invocation,
            )
            raise PipelineError("runtime doctor reported blocking prerequisites")
        status = "complete" if payload.get("status") == "ready" else "degraded"
        _stage_finish(
            state_path,
            state,
            stage,
            status,
            output_root,
            [artifact],
            reason="" if status == "complete" else "runtime doctor reported optional or blocking prerequisites",
            invocation=invocation,
        )
        return

    if stage == "preflight":
        artifacts = [
            paths["preflight"] / "collection_contract.json",
            paths["preflight"] / "collection_contract.csv",
        ]
        command = python_command(
            "preflight_ascend_profiles.py",
            "--real", spec["profiles"]["real"],
            "--sim", spec["profiles"]["sim"],
            "--output", str(paths["preflight"]),
        )
        invocation = _run_command_stage(
            state_path, state, stage, input_hash, command, spec, artifacts
        )
        payload = load_json(artifacts[0])
        status = "complete" if payload.get("status") == "complete" else "degraded"
        if payload.get("status") == "unsupported":
            status = "failed"
        stage_artifacts = files_under(paths["preflight"])
        _stage_finish(
            state_path, state, stage, status, output_root, stage_artifacts,
            reason="" if status == "complete" else f"preflight status={payload.get('status', 'unknown')}",
            invocation=invocation,
        )
        if payload.get("status") == "unsupported":
            raise PipelineError("profiling format is unsupported; alignment was not attempted")
        return

    if stage == "align":
        artifacts = [
            paths["alignment"] / name
            for name in (
                "analysis_manifest.json",
                "canonical_events.csv",
                "rank_pairs.csv",
                "thread_pairs.csv",
                "divergence_windows.jsonl",
                "event_alignment.csv",
                "unpaired_ranks.csv",
                "host_device_links.csv",
            )
        ]
        manifest = artifacts[0]
        command = python_command(
            "align_profiles.py",
            "--real", spec["profiles"]["real"],
            "--sim", spec["profiles"]["sim"],
            "--output", str(paths["alignment"]),
            "--heatmap-bins", str(spec["runtime"]["heatmap_bins"]),
        )
        invocation = _run_command_stage(
            state_path, state, stage, input_hash, command, spec, artifacts
        )
        payload = load_json(manifest)
        status = "complete" if payload.get("status") == "complete" else "degraded"
        stage_artifacts = files_under(paths["alignment"])
        _stage_finish(
            state_path, state, stage, status, output_root, stage_artifacts,
            reason="" if status == "complete" else f"alignment status={payload.get('status', 'unknown')}",
            invocation=invocation,
        )
        return

    if stage == "entrypoint":
        summary = paths["entrypoint"] / "source_entrypoint_summary.json"
        command = python_command(
            "resolve_source_entrypoints.py",
            "--repo-root", spec["source_roots"]["model"]["path"],
            "--output", str(paths["entrypoint"]),
            "--environment", "shared-model-entry",
        )
        for entry in spec["entry_sh"]:
            command.extend(["--entry", entry])
        invocation = _run_command_stage(
            state_path, state, stage, input_hash, command, spec, [summary]
        )
        payload = load_json(summary)
        degraded = bool(payload.get("partial")) or not payload.get("counts", {}).get("launch_candidates")
        stage_artifacts = files_under(paths["entrypoint"])
        _stage_finish(
            state_path, state, stage, "degraded" if degraded else "complete", output_root,
            stage_artifacts,
            reason="static entrypoint resolution is partial" if degraded else "",
            invocation=invocation,
        )
        return

    if stage == "run_contract":
        _stage_start(state_path, state, stage, input_hash)
        contract = build_run_contract(spec, spec_path)
        atomic_write_json(paths["contract"], contract)
        contract_artifacts = [paths["contract"]]
        for component in SOURCE_COMPONENTS:
            owner_contract = _source_contract_path(paths, component)
            atomic_write_json(
                owner_contract,
                build_run_contract(spec, spec_path, analyzed_component=component),
            )
            contract_artifacts.append(owner_contract)
        _stage_finish(
            state_path, state, stage, "degraded", output_root, contract_artifacts,
            reason=(
                "contract is schema-valid but runtime/source bindings remain unknown or "
                "user-declared; owner-specific candidates are available for needs-agent review"
            ),
        )
        return

    if stage == "source_causality":
        previous_source_row = state["stages"][stage]
        source_inputs_changed = (
            previous_source_row.get("status") in TERMINAL_STAGE_STATUSES
            and bool(previous_source_row.get("input_hash"))
            and previous_source_row.get("input_hash") != input_hash
        )
        owner = spec.get("source_owner")
        source_manifest = paths["source"] / "source_analysis_manifest.json"
        candidates = paths["source"] / "control_flow_guard_candidates.csv"
        snapshot_artifacts = [
            paths["snapshots"] / name
            for name in (
                "python_guard_snapshots.json",
                "python_guard_snapshots.md",
                "python_guard_snapshots.html",
                "python_guard_snapshots.csv",
            )
        ]
        snapshots_ready = all(path.is_file() for path in snapshot_artifacts)
        manifest_component: str | None = None
        manifest_error = ""
        contract_bound = False
        source_evidence_artifacts: list[Path] = []
        source_integrity_ready = False
        if source_manifest.is_file():
            try:
                manifest_component = _source_component_from_manifest(source_manifest)
                source_evidence_artifacts = _validated_source_artifacts(source_manifest)
                source_integrity_ready = True
            except PipelineError as error:
                manifest_error = str(error)
        repository_binding = _source_repository_fingerprint(spec, paths)
        if source_integrity_ready and repository_binding.get("status") != "valid":
            source_integrity_ready = False
            manifest_error = (
                "analyzed source checkout no longer matches source_evidence.csv: "
                + "; ".join(repository_binding.get("issues", []))
            )
        if source_integrity_ready and source_inputs_changed:
            source_integrity_ready = False
            manifest_error = (
                "source-causality inputs changed after the completed AST/snapshot binding; "
                "rerun the recorded owner-specific source analysis before resume"
            )
        owner_conflict = bool(
            owner and manifest_component and owner["component"] != manifest_component
        )
        if manifest_component and not owner_conflict:
            try:
                _bind_owner_contract_from_manifest(
                    spec, paths, state, manifest_component, source_manifest
                )
                contract_bound = True
                input_hash = stage_input_hash(
                    stage, spec, spec_hash, state, paths
                )
            except PipelineError as error:
                manifest_error = str(error)
        if (
            manifest_component
            and not owner_conflict
            and contract_bound
            and source_integrity_ready
            and not snapshots_ready
        ):
            command = _snapshot_command(spec, paths, manifest_component)
            _stage_start(state_path, state, stage, input_hash, command)
            invocation = _invoke(command, Path(spec["work_root"]))
            if invocation.returncode == 0 and all(path.is_file() for path in snapshot_artifacts):
                _stage_finish(
                    state_path, state, stage, "complete", output_root,
                    [source_manifest, *source_evidence_artifacts, *snapshot_artifacts],
                    invocation=invocation,
                )
                return
            _stage_finish(
                state_path, state, stage, "needs-agent", output_root,
                [source_manifest, *source_evidence_artifacts, paths["source_checkpoint"]],
                reason="source analysis exists but guard snapshots could not be generated",
                invocation=invocation, next_command=command,
            )
            return
        if (
            manifest_component
            and not owner_conflict
            and contract_bound
            and source_integrity_ready
            and snapshots_ready
        ):
            with tempfile.TemporaryDirectory(
                prefix="snapshot-verify-", dir=paths["state"].parent
            ) as temporary:
                verification_output = Path(temporary)
                command = _snapshot_command(
                    spec, paths, manifest_component, output=verification_output
                )
                _stage_start(state_path, state, stage, input_hash, command)
                invocation = _invoke(command, Path(spec["work_root"]))
                verification_artifacts = [
                    verification_output / path.name for path in snapshot_artifacts
                ]
                rebuilt_valid = (
                    invocation.returncode == 0
                    and all(path.is_file() for path in verification_artifacts)
                    and {
                        path.relative_to(verification_output).as_posix()
                        for path in files_under(verification_output)
                    }
                    == {path.name for path in verification_artifacts}
                )
                bundle_matches = rebuilt_valid and all(
                        sha256_file(existing) == sha256_file(rebuilt)
                        for existing, rebuilt in zip(
                            snapshot_artifacts, verification_artifacts, strict=True
                        )
                )
                existing_names = {
                    path.relative_to(paths["snapshots"]).as_posix()
                    for path in files_under(paths["snapshots"])
                }
                expected_names = {path.name for path in snapshot_artifacts}
                unmanifested_snapshot_files = existing_names - expected_names
                repaired = False
                if rebuilt_valid and not bundle_matches and not unmanifested_snapshot_files:
                    # Every rebuilt file has passed the complete temporary-bundle
                    # gate. os.replace gives an atomic replacement per artifact;
                    # an interrupted multi-file repair is safely repeated on resume.
                    for existing, rebuilt in zip(
                        snapshot_artifacts, verification_artifacts, strict=True
                    ):
                        os.replace(rebuilt, existing)
                    repaired = True
            if bundle_matches or repaired:
                _stage_finish(
                    state_path, state, stage, "complete", output_root,
                    [source_manifest, *source_evidence_artifacts, *snapshot_artifacts],
                    reason=(
                        "tampered/stale Python snapshot bundle was deterministically rebuilt "
                        "and atomically replaced"
                        if repaired
                        else ""
                    ),
                    invocation=invocation,
                )
            else:
                _stage_finish(
                    state_path, state, stage, "needs-agent", output_root,
                    [source_manifest, *source_evidence_artifacts, *snapshot_artifacts],
                    reason=(
                        "python-guard-snapshots contains unmanifested files; automatic repair "
                        "was refused"
                        if unmanifested_snapshot_files
                        else "temporary Python snapshot rebuild failed validation"
                    ),
                    invocation=invocation,
                )
            return

        commands = {
            component: _source_analyze_command(spec, paths, component)
            for component in SOURCE_COMPONENTS
        }
        selected = commands[owner["component"]] if owner else None
        checkpoint = {
            "schema_version": 1,
            "status": "needs-agent",
            "reason": (
                f"source owner conflict: spec={owner['component']}, manifest={manifest_component}"
                if owner_conflict
                else manifest_error or (
                    "source causality must be reviewed against one canonical owner; no source "
                    "analysis was fabricated"
                )
            ),
            "source_owner": owner,
            "next_command": command_display(selected) if selected else "",
            "next_argv": list(selected) if selected else [],
            "next_commands_by_owner": {
                component: command_display(command) for component, command in commands.items()
            },
            "next_argv_by_owner": {
                component: list(command) for component, command in commands.items()
            },
            "resume_command": command_display(
                self_command("run", "--spec", str(spec_path.resolve()), "--resume")
            ),
            "resume_argv": self_command(
                "run", "--spec", str(spec_path.resolve()), "--resume"
            ),
            "repository_code_executed": False,
        }
        _stage_start(state_path, state, stage, input_hash)
        atomic_write_json(paths["source_checkpoint"], checkpoint)
        if owner_conflict or manifest_error:
            reason = checkpoint["reason"]
        elif owner:
            reason = "run the recorded source analysis command, review its owner/candidates, then resume"
        else:
            reason = (
                "choose and run one next_commands_by_owner command; its canonical source manifest "
                "determines the owner; then resume without editing the run-spec"
            )
        _stage_finish(
            state_path, state, stage, "needs-agent", output_root, [paths["source_checkpoint"]],
            reason=reason, next_command=selected or "",
            extra={
                "next_commands_by_owner": checkpoint["next_commands_by_owner"],
                "next_argv_by_owner": checkpoint["next_argv_by_owner"],
                "next_argv": checkpoint["next_argv"],
            },
        )
        return

    if stage == "perfetto":
        batch_path = paths["perfetto"] / "perfetto_batch_manifest.json"
        batch_csv = paths["perfetto"] / "perfetto_batch_manifest.csv"
        content_path = paths["perfetto"] / "perfetto_content_review.json"
        perfetto = spec["perfetto"]
        row = state["stages"][stage]
        review_only = (
            perfetto["online_authorized"]
            and batch_path.is_file()
            and row.get("status") in {"needs-agent", "complete"}
            and row.get("input_hash") == input_hash
            and bool(row.get("artifact_hashes"))
        )
        if review_only:
            # A normal resume may add only perfetto_content_review.json.  Every
            # renderer/template/checkpoint byte recorded at the first pause must
            # remain unchanged.  Re-rendering is reserved for --force-stage.
            if not stage_artifacts_intact(
                stage,
                output_root,
                paths,
                row.get("artifact_hashes", {}),
                allowed_untracked=(content_path,) if content_path.is_file() else (),
            ):
                row.update(
                    {
                        "status": "needs-agent",
                        "reason": (
                            "Perfetto renderer/checkpoint artifacts changed or a job is missing; "
                            "review reuse was refused. Inspect evidence or explicitly force the "
                            "perfetto stage to render a new hash-bound batch."
                        ),
                        "finished_at": utc_now(),
                    }
                )
                state["current_stage"] = None
                state["status"] = overall_status(state)
                save_state(state_path, state)
                return
            valid, review_error = _validate_perfetto_content_review(
                paths["perfetto"], batch_path, content_path
            )
            if valid:
                _stage_start(state_path, state, stage, input_hash)
                _stage_finish(
                    state_path,
                    state,
                    stage,
                    "complete",
                    output_root,
                    [*files_under(paths["perfetto"]), paths["perfetto_checkpoint"]],
                    reason="hash-bound content review completed for every Perfetto job",
                )
                return
            row.update(
                {
                    "status": "needs-agent",
                    "reason": f"Perfetto content review is missing or invalid: {review_error}",
                    "review_template": str(paths["perfetto_template"]),
                    "review_output": str(content_path),
                    "review_operation": (
                        "inspect every job artifact listed in the checkpoint/template; copy the "
                        "template to perfetto_content_review.json, set root and job statuses to "
                        "complete, and add non-empty root/per-job observations without changing "
                        "paths, run IDs, or hashes; then resume"
                    ),
                    "resume_command": command_display(
                        self_command("run", "--spec", str(spec_path.resolve()), "--resume")
                    ),
                    "resume_argv": self_command(
                        "run", "--spec", str(spec_path.resolve()), "--resume"
                    ),
                    "finished_at": utc_now(),
                }
            )
            state["current_stage"] = None
            state["status"] = overall_status(state)
            save_state(state_path, state)
            return

        command = python_command(
            "render_perfetto_batch.py",
            "--alignment-output", str(paths["alignment"]),
            "--output", str(paths["perfetto"]),
            "--timeout-ms", str(spec["runtime"]["perfetto_timeout_ms"]),
            "--max-lanes-per-job", str(spec["runtime"]["max_lanes_per_job"]),
        )
        if perfetto["node"]:
            command.extend(["--node", perfetto["node"]])
        if perfetto["browser"]:
            command.extend(["--browser", perfetto["browser"]])
        if perfetto["playwright_node_modules"]:
            command.extend(
                ["--playwright-node-modules", perfetto["playwright_node_modules"]]
            )
        if perfetto["screenshot"]:
            command.append("--screenshot")
        if perfetto["online_authorized"]:
            command.append("--online-authorized")
        else:
            command.extend(["--degraded-reason", perfetto["degraded_reason"]])
        environment = os.environ.copy()
        if perfetto["playwright_node_modules"]:
            environment["PERFETTO_PLAYWRIGHT_NODE_MODULES"] = perfetto["playwright_node_modules"]
        required_artifacts = [batch_path, batch_csv]
        if not perfetto["online_authorized"]:
            required_artifacts.append(content_path)
        invocation = _run_command_stage(
            state_path, state, stage, input_hash, command, spec, required_artifacts,
            accepted_codes={0, 1}, env=environment,
        )
        payload = load_json(batch_path) if batch_path.is_file() else {}
        complete = invocation.returncode == 0 and payload.get("status") == "complete"
        if perfetto["online_authorized"] and complete:
            template, checkpoint_jobs = _build_perfetto_review_template(
                paths["perfetto"], batch_path
            )
            atomic_write_json(paths["perfetto_template"], template)
            resume_argv = self_command(
                "run", "--spec", str(spec_path.resolve()), "--resume"
            )
            checkpoint = {
                "schema_version": 1,
                "status": "needs-agent",
                "batch_manifest_path": str(batch_path.resolve()),
                "batch_manifest_sha256": template["batch_manifest_sha256"],
                "review_template": str(paths["perfetto_template"].resolve()),
                "review_output": str(content_path.resolve(strict=False)),
                "review_operation": (
                    "Read every job's renderer manifest, HTML, text, embedded /sql results, "
                    "and browser log. Copy the template to perfetto_content_review.json, set "
                    "root and each job status to complete, add non-empty root/per-job "
                    "observations, preserve all identities/hashes, then run resume_argv."
                ),
                "jobs": checkpoint_jobs,
                "resume_command": command_display(resume_argv),
                "resume_argv": resume_argv,
                "renderer_will_run_on_resume": False,
            }
            atomic_write_json(paths["perfetto_checkpoint"], checkpoint)
            _stage_finish(
                state_path,
                state,
                stage,
                "needs-agent",
                output_root,
                [*files_under(paths["perfetto"]), paths["perfetto_checkpoint"]],
                reason=(
                    "authorized renderer passed automatic gates; content review of every "
                    "hash-bound job is required before report generation"
                ),
                invocation=invocation,
                extra={
                    "review_template": checkpoint["review_template"],
                    "review_output": checkpoint["review_output"],
                    "review_operation": checkpoint["review_operation"],
                    "resume_command": checkpoint["resume_command"],
                    "resume_argv": checkpoint["resume_argv"],
                    "review_checkpoint": str(paths["perfetto_checkpoint"]),
                },
            )
            return
        if perfetto["online_authorized"] and not content_path.is_file():
            raise PipelineError(
                "partial online Perfetto run did not create perfetto_content_review.json"
            )
        stage_artifacts = files_under(paths["perfetto"])
        _stage_finish(
            state_path, state, stage, "degraded", output_root,
            stage_artifacts,
            reason=(
                "standard not-executed evidence recorded because online Perfetto was not authorized"
                if not perfetto["online_authorized"]
                else "authorized Perfetto review was partial"
            ),
            invocation=invocation,
        )
        return

    source_ready = state["stages"]["source_causality"].get("status") == "complete"
    if stage == "report":
        command = python_command(
            "build_alignment_report.py",
            "--alignment-output", str(paths["alignment"]),
            "--output", str(paths["report"]),
            "--preflight-dir", str(paths["preflight"]),
            "--run-contract", str(paths["contract"]),
            "--perfetto-review-dir", str(paths["perfetto"]),
        )
        if source_ready:
            command.extend(
                [
                    "--source-causality-dir", str(paths["source"]),
                    "--python-snapshots-dir", str(paths["snapshots"]),
                ]
            )
        invocation = _run_command_stage(
            state_path, state, stage, input_hash, command, spec, [paths["report"]]
        )
        _stage_finish(
            state_path, state, stage, "complete", output_root, [paths["report"]], invocation=invocation
        )
        return

    if stage == "validator":
        validation_json = paths["validation"] / "report_validation.json"
        validation_csv = paths["validation"] / "report_validation.csv"
        command = python_command(
            "validate_alignment_report.py",
            "--report", str(paths["report"]),
            "--alignment-output", str(paths["alignment"]),
            "--run-contract", str(paths["contract"]),
            "--perfetto-review-dir", str(paths["perfetto"]),
            "--output", str(paths["validation"]),
        )
        if source_ready:
            command.extend(
                [
                    "--source-causality-dir", str(paths["source"]),
                    "--python-snapshots-dir", str(paths["snapshots"]),
                ]
            )
        invocation = _run_command_stage(
            state_path, state, stage, input_hash, command, spec,
            [validation_json, validation_csv], accepted_codes={0, 2},
        )
        payload = load_json(validation_json) if validation_json.is_file() else {}
        passed = invocation.returncode == 0 and payload.get("status") == "pass"
        stage_artifacts = files_under(paths["validation"])
        _stage_finish(
            state_path, state, stage, "complete" if passed else "failed", output_root,
            stage_artifacts,
            reason="" if passed else "formal report validator did not pass",
            invocation=invocation,
        )
        if not passed:
            raise PipelineError("formal report validator did not pass")
        return

    raise PipelineError(f"unknown stage: {stage}")


def _reset_from(state: dict[str, Any], stage: str) -> None:
    start = STAGES.index(stage)
    for name in STAGES[start:]:
        attempts = state["stages"][name].get("attempts", 0)
        state["stages"][name] = _new_stage()
        state["stages"][name]["attempts"] = attempts


def _reset_after(state: dict[str, Any], stage: str) -> None:
    index = STAGES.index(stage) + 1
    if index < len(STAGES):
        _reset_from(state, STAGES[index])


def _run_pipeline_unlocked(
    spec_path: Path,
    *,
    resume: bool = False,
    from_stage: str | None = None,
    force_stages: Sequence[str] = (),
) -> tuple[dict[str, Any], int]:
    spec, spec_hash = read_and_normalize_spec(spec_path)
    paths = paths_for(spec)
    paths["state"].parent.mkdir(parents=True, exist_ok=True)
    state = load_state(paths["state"])
    if state is None:
        state = new_state(spec_path, spec, spec_hash)
        save_state(paths["state"], state)
    else:
        if state.get("spec_hash") != spec_hash:
            raise PipelineError(
                "run-state belongs to a different normalized spec; use a new output_root"
            )
        if not (resume or from_stage or force_stages):
            raise PipelineError("run-state already exists; pass --resume, --from-stage, or --force-stage")
        if not output_layout_intact(paths):
            raise PipelineError(
                "output_root contains entries outside the allowed evidence/report layout"
            )

    if from_stage:
        _reset_from(state, from_stage)
    if force_stages:
        earliest = min(STAGES.index(stage) for stage in force_stages)
        _reset_from(state, STAGES[earliest])
    save_state(paths["state"], state)

    for stage in STAGES:
        row = state["stages"][stage]
        input_hash = stage_input_hash(stage, spec, spec_hash, state, paths)
        should_force = stage in force_stages
        can_skip = (
            not should_force
            and row.get("status") in TERMINAL_STAGE_STATUSES
            and row.get("input_hash") == input_hash
            and stage_artifacts_intact(
                stage, paths["output"], paths, row.get("artifact_hashes", {})
            )
        )
        if can_skip:
            continue
        # Once an upstream stage is being re-evaluated, no downstream terminal
        # state remains authoritative. In particular, an old validator failure
        # must not mask a fresh upstream needs-agent checkpoint.
        _reset_after(state, stage)
        save_state(paths["state"], state)
        # A needs-agent source stage is always re-evaluated on resume so newly
        # generated source evidence can be detected and snapshots can be built.
        try:
            run_stage(stage, spec, spec_path.resolve(), spec_hash, state, paths["state"], paths, input_hash)
        except PipelineError:
            state["status"] = overall_status(state)
            save_state(paths["state"], state)
            raise
        if state["stages"][stage].get("status") == "needs-agent":
            break

    state["status"] = overall_status(state)
    state["current_stage"] = None
    save_state(paths["state"], state)
    return state, 3 if state["status"] == "needs-agent" else (2 if state["status"] == "failed" else 0)


def run_pipeline(
    spec_path: Path,
    *,
    resume: bool = False,
    from_stage: str | None = None,
    force_stages: Sequence[str] = (),
) -> tuple[dict[str, Any], int]:
    spec, spec_hash = read_and_normalize_spec(spec_path)
    paths = paths_for(spec)
    if not paths["state"].is_file() and paths["output"].exists():
        existing = list(paths["output"].iterdir())
        if existing:
            raise PipelineError(
                "output_root is non-empty but has no trusted run-state; use a new empty output_root"
            )
    lock = paths["lock"]
    with pipeline_lock(lock, spec_hash):
        return _run_pipeline_unlocked(
            spec_path,
            resume=resume,
            from_stage=from_stage,
            force_stages=force_stages,
        )


def status_payload(spec_path: Path) -> tuple[dict[str, Any], int]:
    spec, spec_hash = read_and_normalize_spec(spec_path)
    paths = paths_for(spec)
    state = load_state(paths["state"])
    run_command = command_display(
        self_command("run", "--spec", str(spec_path.resolve()), "--resume")
    )
    if state is None:
        foreign_output = (
            paths["output"].is_dir() and any(paths["output"].iterdir())
        )
        if foreign_output:
            return {
                "status": "foreign-output",
                "spec_hash": spec_hash,
                "state_path": str(paths["state"]),
                "next_action": "use a new empty output_root; existing evidence has no trusted run-state",
            }, 2
        return {
            "status": "not-started",
            "spec_hash": spec_hash,
            "state_path": str(paths["state"]),
            "next_command": command_display(
                self_command("run", "--spec", str(spec_path.resolve()))
            ),
        }, 0
    if state.get("spec_hash") != spec_hash:
        return {
            "status": "spec-mismatch",
            "state_path": str(paths["state"]),
            "state_spec_hash": state.get("spec_hash"),
            "current_spec_hash": spec_hash,
            "next_action": "use a new output_root; mixed-run reuse is refused",
        }, 2
    stage_rows: dict[str, Any] = {}
    stale_stages: list[str] = [] if output_layout_intact(paths) else ["output-layout"]
    for stage in STAGES:
        row = state["stages"][stage]
        terminal = row.get("status") in TERMINAL_STAGE_STATUSES or row.get("status") == "complete"
        artifact_ok = (
            stage_artifacts_intact(
                stage, paths["output"], paths, row.get("artifact_hashes", {})
            )
            if terminal
            else None
        )
        current_input_hash = stage_input_hash(stage, spec, spec_hash, state, paths)
        input_ok = row.get("input_hash") == current_input_hash if terminal else None
        if terminal and (artifact_ok is False or input_ok is False):
            stale_stages.append(stage)
        stage_rows[stage] = {
            "status": row.get("status"),
            "reason": row.get("reason", ""),
            "attempts": row.get("attempts", 0),
            "artifacts_intact": artifact_ok,
            "inputs_current": input_ok,
        }
    reported_status = "stale" if stale_stages else overall_status(state)
    payload = {
        "status": reported_status,
        "spec_hash": spec_hash,
        "state_path": str(paths["state"]),
        "report": str(paths["report"]),
        "stages": stage_rows,
        "stale_stages": stale_stages,
        "next_command": run_command,
        "repository_code_executed": False,
    }
    source = state["stages"]["source_causality"]
    if source.get("status") == "needs-agent":
        payload["next_command"] = source.get("next_command", "")
        payload["next_argv"] = source.get("next_argv", [])
        payload["next_commands_by_owner"] = source.get("next_commands_by_owner", {})
        payload["next_argv_by_owner"] = source.get("next_argv_by_owner", {})
        payload["resume_command"] = run_command
    perfetto = state["stages"]["perfetto"]
    if perfetto.get("status") == "needs-agent":
        payload["next_command"] = ""
        payload["next_argv"] = []
        payload["review_checkpoint"] = perfetto.get("review_checkpoint", "")
        payload["review_template"] = perfetto.get("review_template", "")
        payload["review_output"] = perfetto.get("review_output", "")
        payload["review_operation"] = perfetto.get("review_operation", "")
        payload["resume_command"] = perfetto.get("resume_command", run_command)
        payload["resume_argv"] = perfetto.get("resume_argv", [])
    return payload, 1 if stale_stages else 0


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description=__doc__)
    subparsers = parser.add_subparsers(dest="command", required=True)
    for name in ("validate-spec", "status"):
        child = subparsers.add_parser(name)
        child.add_argument("--spec", required=True, type=Path)
    run = subparsers.add_parser("run")
    run.add_argument("--spec", required=True, type=Path)
    run.add_argument("--resume", action="store_true")
    run.add_argument("--from-stage", choices=STAGES)
    run.add_argument("--force-stage", choices=STAGES, action="append", default=[])
    return parser


def main(argv: Sequence[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    try:
        if args.command == "validate-spec":
            normalized, spec_hash = read_and_normalize_spec(args.spec)
            print(
                json.dumps(
                    {"status": "valid", "spec_hash": spec_hash, "normalized_spec": normalized},
                    ensure_ascii=False,
                    indent=2,
                )
            )
            return 0
        if args.command == "status":
            payload, code = status_payload(args.spec)
            print(json.dumps(payload, ensure_ascii=False, indent=2))
            return code
        state, code = run_pipeline(
            args.spec,
            resume=args.resume,
            from_stage=args.from_stage,
            force_stages=args.force_stage,
        )
        print(
            json.dumps(
                {
                    "status": state["status"],
                    "spec_hash": state["spec_hash"],
                    "state_path": str(paths_for(state["normalized_spec"])["state"]),
                    "report": str(paths_for(state["normalized_spec"])["report"]),
                    "repository_code_executed": False,
                },
                ensure_ascii=False,
                indent=2,
            )
        )
        return code
    except (OSError, SpecError, PipelineError, json.JSONDecodeError, csv.Error) as error:
        print(f"error: {error}", file=sys.stderr)
        return 2


if __name__ == "__main__":
    raise SystemExit(main())

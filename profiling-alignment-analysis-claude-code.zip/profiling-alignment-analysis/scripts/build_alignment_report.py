#!/usr/bin/env python3
"""Build one deterministic, evidence-rich Chinese profiling alignment report.

The builder is intentionally a compiler, not another profiler parser.  It reads the
bounded structural artifacts produced by the other skill scripts, streams only a small
context window from ``event_alignment.csv``, and never loads ``canonical_events.csv``.
It writes exactly one Markdown file and leaves every input artifact untouched.
"""

from __future__ import annotations

import argparse
import csv
import hashlib
import html
import importlib.util
import json
import os
import re
import subprocess
import sys
import tempfile
import unicodedata
from collections import Counter, defaultdict, deque
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Iterable, Iterator, Sequence


SCHEMA_VERSION = 1
REPORT_NAME = "profiling_alignment_report.md"
CONTEXT_RADIUS = 3
LAYER_ORDER = {"framework_op": 0, "host_launch": 1, "device_task": 2}
SIDE_LABELS = {
    "real": "真机",
    "reference": "真机",
    "real/reference/真机": "真机",
    "sim": "仿真",
    "candidate": "仿真",
    "sim/candidate/仿真": "仿真",
}
PROMOTED_STRENGTHS = {"强关联控制流分叉", "已证实控制流分叉"}
SOURCE_FILES = (
    "control_flow_guard_candidates.csv",
    "control_flow_evidence.jsonl",
    "predicate_tensor_evidence.csv",
    "event_source_map.csv",
    "branch_device_evidence.csv",
    "source_evidence.csv",
    "source_entrypoint_chain.csv",
    "source_analysis_issues.csv",
)
ALIGNMENT_FILES = (
    "analysis_manifest.json",
    "rank_pairs.csv",
    "unpaired_ranks.csv",
    "thread_pairs.csv",
    "event_alignment.csv",
    "divergence_windows.jsonl",
    "host_device_links.csv",
    "operator_details_rank_coverage.csv",
    "parser_warnings.csv",
)


class ReportBuildError(ValueError):
    """Raised when an evidence or output-safety gate fails closed."""


@dataclass(frozen=True)
class EvidenceEntry:
    path: str
    role: str
    bytes: int
    sha256: str


class EvidenceLedger:
    def __init__(self) -> None:
        self._entries: dict[str, EvidenceEntry] = {}

    @staticmethod
    def _measure(path: Path) -> tuple[int, str]:
        digest = hashlib.sha256()
        size = 0
        with path.open("rb") as handle:
            while True:
                chunk = handle.read(1024 * 1024)
                if not chunk:
                    break
                size += len(chunk)
                digest.update(chunk)
        return size, digest.hexdigest()

    def record(self, path: Path, role: str) -> None:
        resolved = path.resolve(strict=True)
        key = str(resolved)
        size, digest = self._measure(resolved)
        existing = self._entries.get(key)
        if existing and (existing.bytes != size or existing.sha256 != digest):
            raise ReportBuildError(f"evidence changed while report was built: {resolved}")
        if existing:
            roles = sorted(set(existing.role.split("; ")) | {role})
            self._entries[key] = EvidenceEntry(key, "; ".join(roles), size, digest)
        else:
            self._entries[key] = EvidenceEntry(key, role, size, digest)

    def read_bytes(self, path: Path, role: str) -> bytes:
        """Read a bounded artifact while preserving the change-during-build gate."""
        self.record(path, role)
        raw = path.resolve(strict=True).read_bytes()
        self.record(path, role)
        return raw

    def entries(self) -> list[EvidenceEntry]:
        return [self._entries[key] for key in sorted(self._entries, key=str.casefold)]


@dataclass
class SourceBundle:
    owner: str
    directory: Path
    candidates: list[dict[str, str]]
    evidence: list[dict[str, Any]]
    predicates: list[dict[str, str]]
    event_source: list[dict[str, str]]
    branch_device: list[dict[str, str]]
    source_evidence: list[dict[str, str]]
    entrypoint_chain: list[dict[str, str]]
    issues: list[dict[str, str]]
    manifest: dict[str, Any]


@dataclass
class SnapshotBundle:
    owner: str
    directory: Path
    document: dict[str, Any]
    blocks: dict[str, str]


def _sha256_bytes(raw: bytes) -> str:
    return hashlib.sha256(raw).hexdigest()


def _safe_decode(raw: bytes, path: Path) -> str:
    try:
        return raw.decode("utf-8-sig")
    except UnicodeDecodeError as error:
        raise ReportBuildError(f"evidence is not valid UTF-8: {path}: {error}") from error


def _read_json(path: Path, ledger: EvidenceLedger, role: str) -> dict[str, Any]:
    raw = ledger.read_bytes(path, role)
    try:
        value = json.loads(_safe_decode(raw, path))
    except json.JSONDecodeError as error:
        raise ReportBuildError(f"invalid JSON evidence: {path}: {error}") from error
    if not isinstance(value, dict):
        raise ReportBuildError(f"JSON evidence root must be an object: {path}")
    return value


def _read_csv(path: Path, ledger: EvidenceLedger, role: str) -> list[dict[str, str]]:
    ledger.record(path, role)
    try:
        with path.open("r", encoding="utf-8-sig", newline="") as handle:
            reader = csv.DictReader(handle)
            if reader.fieldnames is None:
                raise ReportBuildError(f"CSV evidence has no header: {path}")
            rows = [dict(row) for row in reader]
    except (UnicodeDecodeError, csv.Error) as error:
        raise ReportBuildError(f"invalid CSV evidence: {path}: {error}") from error
    ledger.record(path, role)
    return rows


def _iter_csv(path: Path, ledger: EvidenceLedger, role: str) -> Iterator[dict[str, str]]:
    ledger.record(path, role)
    try:
        with path.open("r", encoding="utf-8-sig", newline="") as handle:
            reader = csv.DictReader(handle)
            if reader.fieldnames is None:
                raise ReportBuildError(f"CSV evidence has no header: {path}")
            for row in reader:
                yield dict(row)
    except (UnicodeDecodeError, csv.Error) as error:
        raise ReportBuildError(f"invalid CSV evidence: {path}: {error}") from error
    finally:
        ledger.record(path, role)


def _read_jsonl(path: Path, ledger: EvidenceLedger, role: str) -> list[dict[str, Any]]:
    ledger.record(path, role)
    rows: list[dict[str, Any]] = []
    try:
        with path.open("r", encoding="utf-8-sig") as handle:
            for line_number, line in enumerate(handle, 1):
                if not line.strip():
                    continue
                try:
                    row = json.loads(line)
                except json.JSONDecodeError as error:
                    raise ReportBuildError(
                        f"invalid JSONL evidence: {path}:{line_number}: {error}"
                    ) from error
                if not isinstance(row, dict):
                    raise ReportBuildError(f"JSONL row must be an object: {path}:{line_number}")
                rows.append(row)
    except UnicodeDecodeError as error:
        raise ReportBuildError(f"evidence is not valid UTF-8: {path}: {error}") from error
    ledger.record(path, role)
    return rows


def _optional_csv(path: Path, ledger: EvidenceLedger, role: str) -> list[dict[str, str]]:
    return _read_csv(path, ledger, role) if path.is_file() else []


def _optional_jsonl(path: Path, ledger: EvidenceLedger, role: str) -> list[dict[str, Any]]:
    return _read_jsonl(path, ledger, role) if path.is_file() else []


def _optional_json(path: Path, ledger: EvidenceLedger, role: str) -> dict[str, Any]:
    return _read_json(path, ledger, role) if path.is_file() else {}


def _is_within(path: Path, root: Path) -> bool:
    try:
        path.resolve().relative_to(root.resolve())
        return True
    except (OSError, ValueError):
        return False


def _is_reparse(path: Path) -> bool:
    if path.is_symlink():
        return True
    attributes = getattr(path.stat(follow_symlinks=False), "st_file_attributes", 0)
    flag = getattr(os, "FILE_ATTRIBUTE_REPARSE_POINT", 0x400)
    return bool(attributes & flag)


def _validate_output(alignment_output: Path, output: Path) -> tuple[Path, Path]:
    alignment = alignment_output.resolve(strict=True)
    if not alignment.is_dir():
        raise ReportBuildError(f"--alignment-output is not a directory: {alignment}")
    if _is_reparse(alignment):
        raise ReportBuildError("--alignment-output must not be a symlink/reparse point")
    requested = output.expanduser()
    if requested.name != REPORT_NAME or requested.suffix.casefold() != ".md":
        raise ReportBuildError(f"--output must be named exactly {REPORT_NAME}")
    parent = requested.parent.resolve(strict=True)
    if alignment.parent.name.casefold() != "evidence":
        raise ReportBuildError(
            "--alignment-output must use <output-root>/evidence/alignment layout"
        )
    report_root = alignment.parent.parent.resolve(strict=True)
    if parent != report_root:
        raise ReportBuildError(
            "--output must be <output-root>/profiling_alignment_report.md, outside evidence/alignment"
        )
    resolved = parent / requested.name
    if resolved.exists() and (_is_reparse(resolved) or not resolved.is_file()):
        raise ReportBuildError("existing --output must be a regular non-reparse file")
    for name in ALIGNMENT_FILES:
        if resolved == (alignment / name).resolve():
            raise ReportBuildError("--output collides with an alignment evidence artifact")
    return alignment, resolved


def _validate_optional_directory(path: Path | None, label: str) -> Path | None:
    if path is None:
        return None
    resolved = path.resolve(strict=True)
    if not resolved.is_dir():
        raise ReportBuildError(f"{label} is not a directory: {resolved}")
    return resolved


def _owner_label(root: Path, directory: Path) -> str:
    relative = directory.resolve().relative_to(root.resolve()).as_posix()
    return root.name if relative == "." else relative


def _canonical_owner(value: Any) -> str:
    normalized = str(value or "").strip().casefold().replace("-", "_")
    if normalized in {"model", "mindspeed", "mind_speed", "model_code"}:
        return "model"
    if normalized in {"pytorch", "torch", "pytorch_core"}:
        return "pytorch"
    if normalized in {"torch_npu", "torchnpu"}:
        return "torch_npu"
    if normalized == "dependency" or normalized.startswith("dependency:"):
        return normalized
    return normalized


def _display_owner(value: Any) -> str:
    canonical = _canonical_owner(value)
    return {"model": "MindSpeed", "pytorch": "torch", "torch_npu": "torch_npu"}.get(
        canonical, canonical or "unknown"
    )


def _discover_anchor_directories(root: Path, anchor: str) -> list[Path]:
    direct = root / anchor
    if direct.is_file():
        return [root.resolve(strict=True)]
    nested = sorted(
        {str(path.parent.resolve(strict=True)) for path in root.rglob(anchor) if path.is_file()},
        key=str.casefold,
    )
    if nested:
        raise ReportBuildError(
            f"{anchor} must be in one flat primary-owner directory; nested/multi-owner "
            f"inputs are not accepted by the formal validator: {nested}"
        )
    return []


def _load_source_bundles(
    root: Path | None, ledger: EvidenceLedger
) -> tuple[list[SourceBundle], dict[str, tuple[str, dict[str, str]]]]:
    if root is None:
        return [], {}
    directories = _discover_anchor_directories(root, "control_flow_guard_candidates.csv")
    if not directories:
        raise ReportBuildError(
            f"no control_flow_guard_candidates.csv found under --source-causality-dir: {root}"
        )
    seen: dict[str, tuple[str, dict[str, str]]] = {}
    bundles: list[SourceBundle] = []
    for directory in directories:
        provisional_owner = _owner_label(root, directory)
        candidates = _read_csv(
            directory / "control_flow_guard_candidates.csv", ledger,
            f"源码因果候选/{provisional_owner}",
        )
        manifest = _optional_json(
            directory / "source_analysis_manifest.json", ledger,
            f"源码分析 manifest/{provisional_owner}",
        )
        declared_components = {
            _canonical_owner(value)
            for value in (
                manifest.get("source_component"),
                *(row.get("source_component") for row in candidates),
            )
            if _canonical_owner(value)
        }
        if len(declared_components) > 1:
            raise ReportBuildError(
                f"source owner component conflict in flat primary directory: "
                f"{sorted(declared_components)}"
            )
        owner = _display_owner(
            next(iter(declared_components), provisional_owner)
        )
        for row in candidates:
            evidence_id = str(row.get("evidence_id", "")).strip()
            if not evidence_id:
                raise ReportBuildError(f"empty evidence_id in source owner {owner}")
            if evidence_id in seen:
                previous_owner = seen[evidence_id][0]
                raise ReportBuildError(
                    f"duplicate evidence_id across source owners: {evidence_id}: "
                    f"{previous_owner} and {owner}"
                )
            seen[evidence_id] = (owner, row)
        bundles.append(
            SourceBundle(
                owner=owner,
                directory=directory,
                candidates=candidates,
                evidence=_optional_jsonl(
                    directory / "control_flow_evidence.jsonl", ledger,
                    f"源码因果详证/{owner}",
                ),
                predicates=_optional_csv(
                    directory / "predicate_tensor_evidence.csv", ledger,
                    f"predicate tensor/{owner}",
                ),
                event_source=_optional_csv(
                    directory / "event_source_map.csv", ledger,
                    f"算子源码映射/{owner}",
                ),
                branch_device=_optional_csv(
                    directory / "branch_device_evidence.csv", ledger,
                    f"分支 Device 证据/{owner}",
                ),
                source_evidence=_optional_csv(
                    directory / "source_evidence.csv", ledger,
                    f"源码行证据/{owner}",
                ),
                entrypoint_chain=_optional_csv(
                    directory / "source_entrypoint_chain.csv", ledger,
                    f"源码入口链/{owner}",
                ),
                issues=_optional_csv(
                    directory / "source_analysis_issues.csv", ledger,
                    f"源码分析问题/{owner}",
                ),
                manifest=manifest,
            )
        )
    return bundles, seen


DETAILS_PATTERN = re.compile(r"<details open>\r?\n.*?\r?\n</details>", re.DOTALL)


def _load_snapshot_bundles(
    root: Path | None, ledger: EvidenceLedger
) -> tuple[list[SnapshotBundle], dict[str, tuple[str, str]]]:
    if root is None:
        return [], {}
    directories = _discover_anchor_directories(root, "python_guard_snapshots.json")
    if not directories:
        raise ReportBuildError(
            f"no python_guard_snapshots.json found under --python-snapshots-dir: {root}"
        )
    seen: dict[str, tuple[str, str]] = {}
    bundles: list[SnapshotBundle] = []
    for directory in directories:
        provisional_owner = _owner_label(root, directory)
        document = _read_json(
            directory / "python_guard_snapshots.json", ledger,
            f"Python 快照 JSON/{provisional_owner}",
        )
        snapshots = document.get("snapshots", [])
        if not isinstance(snapshots, list):
            raise ReportBuildError(
                f"snapshots must be an array for owner {provisional_owner}"
            )
        declared_components = {
            _canonical_owner(row.get("source_component"))
            for row in snapshots if isinstance(row, dict) and row.get("source_component")
        }
        if len(declared_components) > 1:
            raise ReportBuildError(
                f"snapshot owner component conflict in flat primary directory: "
                f"{sorted(declared_components)}"
            )
        owner = _display_owner(next(iter(declared_components), provisional_owner))
        markdown_path = directory / "python_guard_snapshots.md"
        if not markdown_path.is_file():
            raise ReportBuildError(f"snapshot Markdown is missing for owner {owner}")
        markdown = _safe_decode(
            ledger.read_bytes(markdown_path, f"Python 快照 Markdown/{owner}"), markdown_path
        )
        blocks = DETAILS_PATTERN.findall(markdown)
        if len(blocks) != len(snapshots):
            raise ReportBuildError(
                f"snapshot JSON/Markdown block count mismatch for owner {owner}: "
                f"{len(snapshots)} vs {len(blocks)}"
            )
        by_id: dict[str, str] = {}
        for snapshot, block in zip(snapshots, blocks):
            if not isinstance(snapshot, dict):
                raise ReportBuildError(f"snapshot entry must be an object for owner {owner}")
            evidence_id = str(snapshot.get("evidence_id", "")).strip()
            if not evidence_id:
                raise ReportBuildError(f"empty snapshot evidence_id for owner {owner}")
            escaped_id = html.escape(evidence_id, quote=True)
            if escaped_id not in block:
                raise ReportBuildError(
                    f"snapshot block does not bind its evidence_id for owner {owner}: {evidence_id}"
                )
            if evidence_id in seen:
                previous_owner = seen[evidence_id][0]
                raise ReportBuildError(
                    f"duplicate evidence_id across snapshot owners: {evidence_id}: "
                    f"{previous_owner} and {owner}"
                )
            seen[evidence_id] = (owner, block)
            by_id[evidence_id] = block
        bundles.append(SnapshotBundle(owner, directory, document, by_id))
    return bundles, seen


def _collect_alignment_context(
    path: Path,
    ledger: EvidenceLedger,
    thread_ids: set[str],
    radius: int = CONTEXT_RADIUS,
) -> dict[str, list[dict[str, str]]]:
    """Stream a bounded context around each lane's first marked divergence."""
    before: dict[str, deque[dict[str, str]]] = {
        key: deque(maxlen=radius) for key in thread_ids
    }
    captured: dict[str, list[dict[str, str]]] = {}
    remaining: dict[str, int] = {}
    for row in _iter_csv(path, ledger, "受控 event alignment 上下文"):
        key = str(row.get("thread_pair_id", ""))
        if key not in thread_ids:
            continue
        if key in captured:
            if remaining.get(key, 0) > 0:
                captured[key].append(row)
                remaining[key] -= 1
            continue
        if str(row.get("first_divergence", "")).strip() in {"是", "yes", "true", "1"}:
            captured[key] = [*before[key], row]
            remaining[key] = radius
        else:
            before[key].append(row)
    return captured


def _jsonish(value: Any, default: Any = None) -> Any:
    if isinstance(value, (dict, list, tuple, bool, int, float)):
        return value
    text = str(value or "").strip()
    if not text:
        return default
    try:
        return json.loads(text)
    except json.JSONDecodeError:
        return text


def _compact(value: Any) -> str:
    if value in (None, "", [], {}):
        return "未知"
    if isinstance(value, Path):
        return str(value)
    if isinstance(value, str):
        return value
    try:
        return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"))
    except TypeError:
        return str(value)


def _side_label(value: Any) -> str:
    text = str(value or "")
    return SIDE_LABELS.get(text, SIDE_LABELS.get(text.casefold(), text or "未知"))


def _rank_sort(value: Any) -> tuple[int, str]:
    text = str(value or "")
    match = re.search(r"-?(\d+)", text)
    return (int(match.group(1)) if match else 10**12, text)


def _row_sort(row: dict[str, Any]) -> tuple[Any, ...]:
    return (
        _rank_sort(row.get("rank_pair_id") or row.get("rank")),
        LAYER_ORDER.get(str(row.get("semantic_layer", "")), 99),
        str(row.get("thread_pair_id", "")),
        str(row.get("alignment_column", "")),
        str(row.get("evidence_id", "")),
    )


def _fact_value(contract: dict[str, Any], side: str, field: str) -> str:
    side_value = contract.get(side, {})
    if not isinstance(side_value, dict):
        return "未知"
    raw = side_value.get(field)
    if not isinstance(raw, dict):
        return _compact(raw)
    if field == "analyzed_source":
        component = raw.get("component") or "未知组件"
        repository = raw.get("repository") or "未知仓库"
        commit = raw.get("commit") or "未知 commit"
        tree = raw.get("tree_hash") or "未知 tree"
        status = raw.get("status") or "unknown"
        return f"{component}; {repository}@{commit}; tree={tree}; status={status}"
    value = raw.get("value")
    status = raw.get("status") or "unknown"
    evidence = raw.get("evidence") or ""
    text = f"{_compact(value)}; status={status}"
    return f"{text}; evidence={evidence}" if evidence else text


def _safe_visible(value: Any) -> str:
    text = _compact(value)
    text = text.replace("\r\n", " ⏎ ").replace("\n", " ⏎ ").replace("\r", " ⏎ ")
    for character in text:
        code = ord(character)
        if character == "\t" or code == 0x7F or (code < 0x20 and character not in "\n\r"):
            raise ReportBuildError(f"forbidden control character in evidence cell: U+{code:04X}")
        if unicodedata.category(character) == "Cf":
            raise ReportBuildError(f"forbidden Unicode format character in evidence cell: U+{code:04X}")
    # Evidence prose is Markdown, not a trusted HTML channel. Snapshot <details>
    # blocks bypass this helper and are verified byte-for-byte separately.
    return text.replace("<", "&lt;").replace(">", "&gt;")


def _cell(value: Any) -> str:
    text = _safe_visible(value)
    return text.replace("|", "\\|").replace("<", "&lt;").replace(">", "&gt;")


def _add_table(
    lines: list[str], headers: Sequence[str], rows: Iterable[Sequence[Any]],
    empty_message: str = "无可观测记录",
) -> None:
    materialized = list(rows)
    lines.append("| " + " | ".join(_cell(value) for value in headers) + " |")
    lines.append("|" + "|".join("---" for _ in headers) + "|")
    if materialized:
        for row in materialized:
            values = list(row)
            if len(values) != len(headers):
                raise ReportBuildError("internal report table column mismatch")
            lines.append("| " + " | ".join(_cell(value) for value in values) + " |")
    else:
        lines.append("| " + _cell(empty_message) + " | " + " | ".join("—" for _ in headers[1:]) + " |")
    lines.append("")


def _parse_run(value: Any) -> dict[str, Any]:
    parsed = _jsonish(value, {})
    return parsed if isinstance(parsed, dict) else {}


def _format_run(run: dict[str, Any]) -> str:
    if not run:
        return "无"
    selected = {
        "operator": run.get("operator") or run.get("canonical_op") or "未知",
        "calls": run.get("calls", ""),
        "input_shapes": run.get("input_shapes", ""),
        "output_shapes": run.get("output_shapes", ""),
        "depth": run.get("depth", ""),
        "event_ids": run.get("event_ids", []),
    }
    return _compact({key: value for key, value in selected.items() if value not in ("", [], None)})


def _format_anchor(value: Any) -> str:
    parsed = _jsonish(value, {})
    if not isinstance(parsed, dict):
        return _compact(parsed)
    if "real" in parsed or "sim" in parsed:
        return f"真机={_format_run(_parse_run(parsed.get('real')))}; 仿真={_format_run(_parse_run(parsed.get('sim')))}"
    return _format_run(parsed)


def _alignment_boundaries(row: dict[str, Any]) -> str:
    value = row.get("alignment_boundaries", {})
    parsed = _jsonish(value, {})
    if not isinstance(parsed, dict):
        return _compact(parsed)
    labels = {"op": "op-only", "metadata": "op+metadata", "tree": "tree-aware"}
    return "; ".join(
        f"{labels[key]}={_compact(parsed.get(key))}" for key in ("op", "metadata", "tree")
    )


def _lane_allowed(row: dict[str, Any]) -> str:
    status = str(row.get("status", ""))
    confidence = str(row.get("confidence", ""))
    if status == "matched" and confidence in {"高", "high"}:
        return "允许严格逐 lane 结构结论"
    if status in {"matched", "matched-degraded"}:
        return "仅允许降级结构观察；控制流须另过源码门禁"
    return "不允许逐 lane 因果结论"


def _candidate_missing(candidate: dict[str, str]) -> list[str]:
    value = _jsonish(candidate.get("minimal_missing_evidence", ""), [])
    if isinstance(value, list):
        return [str(item) for item in value if str(item).strip()]
    return [str(value)] if value else []


def render_rank_narrative(
    row: dict[str, Any], pair_threads: Sequence[dict[str, Any]],
    pair_divergences: Sequence[dict[str, Any]],
) -> str:
    """Deterministically explain one Rank pair beyond its inventory row."""
    status_counts = Counter(str(item.get("status", "unknown")) for item in pair_threads)
    comparable_count = sum(
        count for status, count in status_counts.items()
        if status in {"matched", "matched-degraded"}
    )
    limited_count = len(pair_threads) - comparable_count
    limitation = (
        "存在 ambiguous、单侧或降级 lane。"
        if limited_count
        else "全部可观测 lane 均已有显式配对。"
    )
    causal_boundary = (
        "因果门禁：这些受限 lane 只报告覆盖事实，不参与控制流因果升级。"
        if limited_count
        else "因果门禁：仍须逐 lane 使用独立首分叉证据，不能用 Rank 总量替代。"
    )
    return (
        f"Rank 覆盖解释 rank_pair_id={_safe_visible(row.get('rank_pair_id'))}：真机 Rank "
        f"`{_safe_visible(row.get('real_rank'))}`（trace SHA `{_safe_visible(row.get('real_trace_sha256'))}`）"
        f"与仿真 Rank `{_safe_visible(row.get('sim_rank'))}`（trace SHA `{_safe_visible(row.get('sim_trace_sha256'))}`）"
        f"按同号身份进行比较；拓扑门禁为 `{_safe_visible(row.get('topology_compatible'))}`，"
        f"pair status=`{_safe_visible(row.get('status'))}`，解析状态为 "
        f"real=`{_safe_visible(row.get('real_parse_status'))}`、sim=`{_safe_visible(row.get('sim_parse_status'))}`。"
        f"本 Rank 观测到 framework_op 真/仿 `{_safe_visible(row.get('real_framework_lanes', 0))}/"
        f"{_safe_visible(row.get('sim_framework_lanes', 0))}`、host_launch 真/仿 "
        f"`{_safe_visible(row.get('real_host_launch_lanes', 0))}/{_safe_visible(row.get('sim_host_launch_lanes', 0))}`、"
        f"device_task 真/仿 `{_safe_visible(row.get('real_device_lanes', 0))}/"
        f"{_safe_visible(row.get('sim_device_lanes', 0))}`；lane 状态计数为 `{_safe_visible(dict(status_counts))}`，"
        f"结构首分叉 `{len(pair_divergences)}` 个。结论边界：{limitation}"
        f"\n\n{causal_boundary}"
    )


def render_divergence_narrative(divergence: dict[str, Any]) -> str:
    """Deterministically explain one lane-local structural divergence."""
    return (
        f"分叉解释 divergence_id={_safe_visible(divergence.get('divergence_id'))}：在 rank_pair_id="
        f"{_safe_visible(divergence.get('rank_pair_id'))}、thread_pair_id="
        f"{_safe_visible(divergence.get('thread_pair_id'))}、domain={_safe_visible(divergence.get('domain'))}、"
        f"semantic_layer={_safe_visible(divergence.get('semantic_layer'))} 上，最后共同 anchor 为 "
        f"`{_safe_visible(_format_anchor(divergence.get('last_common_anchor')))}`；真机首差异算子为 "
        f"`{_safe_visible(divergence.get('real_operators'))}`，仿真首差异算子为 "
        f"`{_safe_visible(divergence.get('sim_operators'))}`，下一共同 anchor 为 "
        f"`{_safe_visible(_format_anchor(divergence.get('next_common_anchor')))}`。三视图边界状态为 "
        f"boundary_stability=`{_safe_visible(divergence.get('boundary_stability'))}`，"
        f"anchors_before=`{_safe_visible(divergence.get('anchors_before'))}`、"
        f"anchors_after=`{_safe_visible(divergence.get('anchors_after'))}`。"
        "这是一条逐 Rank、逐 lane 的算子路线结构事实；只有边界、源码和运行时 predicate 门禁同时成立时，"
        "它才可升级为 Python 控制流因果，否则保持结构差异或静态导航。"
    )


def render_candidate_narrative(candidate: dict[str, Any]) -> str:
    """Deterministically explain the single promoted candidate for a divergence."""
    return (
        f"源码因果解释 evidence_id={_safe_visible(candidate.get('evidence_id'))}、divergence_id="
        f"{_safe_visible(candidate.get('divergence_id'))}：在 rank_pair_id="
        f"{_safe_visible(candidate.get('rank_pair_id'))}、thread_pair_id="
        f"{_safe_visible(candidate.get('thread_pair_id'))} 的首选候选中，源码 "
        f"`{_safe_visible(candidate.get('repository'))}@{_safe_visible(candidate.get('commit'))}` 的 Python 位置 "
        f"`{_safe_visible(candidate.get('guard_path'))}:{_safe_visible(candidate.get('guard_lines'))}`、symbol "
        f"`{_safe_visible(candidate.get('guard_symbol'))}` 含 predicate "
        f"`{_safe_visible(candidate.get('predicate_text'))}`。真机观测对应候选 arm "
        f"`{_safe_visible(candidate.get('real_arm'))}` 与算子 "
        f"`{_safe_visible(candidate.get('real_operators'))}`；仿真观测对应候选 arm "
        f"`{_safe_visible(candidate.get('sim_arm'))}` 与算子 "
        f"`{_safe_visible(candidate.get('sim_operators'))}`。结论强度为 "
        f"`{_safe_visible(candidate.get('strength'))}`，runtime_binding="
        f"`{_safe_visible(candidate.get('runtime_binding'))}`、analyzed_source_gate="
        f"`{_safe_visible(candidate.get('analyzed_source_gate_passed'))}`、dependency_source_gate="
        f"`{_safe_visible(candidate.get('dependency_source_gate_passed'))}`。当前最小缺证为 "
        f"`{_safe_visible(candidate.get('minimal_missing_evidence'))}`；若源码仅绑定真机 reference，"
        "则这里的仿真 arm 只是算子路线到同一 AST 的候选映射，不得表述为仿真实际执行了该份源码。"
    )


def _top_candidate_pairs(
    candidates: list[tuple[str, dict[str, str]]],
) -> list[tuple[str, dict[str, str]]]:
    """Select exactly the candidate scope used by the formal report validator."""
    ordered = sorted(
        candidates,
        key=lambda item: (
            str(item[1].get("divergence_id", "")),
            _rank_sort(item[1].get("candidate_rank", "")),
            item[0].casefold(),
            str(item[1].get("evidence_id", "")),
        ),
    )
    selected: dict[str, tuple[str, dict[str, str]]] = {}
    for owner, row in ordered:
        divergence_id = str(row.get("divergence_id", "")).strip()
        if divergence_id and divergence_id not in selected:
            selected[divergence_id] = (owner, row)
    return [selected[key] for key in sorted(selected, key=str.casefold)]


def _validate_final_text(text: str, snapshot_blocks: Iterable[str]) -> None:
    if "<!--" in text or "-->" in text:
        raise ReportBuildError("generated report contains an HTML comment")
    for index, character in enumerate(text):
        code = ord(character)
        if character == "\n":
            continue
        if character == "\r" and index + 1 < len(text) and text[index + 1] == "\n":
            continue
        if code < 0x20 or code == 0x7F:
            raise ReportBuildError(f"generated report contains forbidden C0/DEL U+{code:04X}")
        if unicodedata.category(character) == "Cf":
            raise ReportBuildError(f"generated report contains forbidden Unicode format U+{code:04X}")
    prose = text
    for block in snapshot_blocks:
        if block not in prose:
            raise ReportBuildError("an expected Python snapshot block was not embedded exactly")
        prose = prose.replace(block, "")
    if re.search(r"<\s*/?\s*[a-z][^>]*>", prose, re.IGNORECASE):
        raise ReportBuildError("generated prose contains raw HTML outside verified snapshots")


def _atomic_write(path: Path, text: str) -> None:
    raw = text.encode("utf-8")
    temporary: Path | None = None
    try:
        with tempfile.NamedTemporaryFile(
            mode="wb", prefix=f".{path.name}.", suffix=".tmp", dir=path.parent,
            delete=False,
        ) as handle:
            handle.write(raw)
            handle.flush()
            os.fsync(handle.fileno())
            temporary = Path(handle.name)
        os.replace(temporary, path)
    except OSError:
        if temporary is not None:
            try:
                temporary.unlink(missing_ok=True)
            except OSError:
                pass
        raise


def _load_alignment(alignment: Path, ledger: EvidenceLedger) -> dict[str, Any]:
    missing = [name for name in ALIGNMENT_FILES if not (alignment / name).is_file()]
    if missing:
        raise ReportBuildError(f"alignment evidence is incomplete: {missing}")
    manifest = _read_json(alignment / "analysis_manifest.json", ledger, "对齐 manifest")
    if manifest.get("duration_metrics_emitted") is not False:
        raise ReportBuildError("analysis_manifest.json does not prove the no-time-metrics gate")
    rank_pairs = _read_csv(alignment / "rank_pairs.csv", ledger, "Rank 配对")
    thread_pairs = _read_csv(alignment / "thread_pairs.csv", ledger, "lane 配对")
    divergences = _read_jsonl(
        alignment / "divergence_windows.jsonl", ledger, "首分叉窗口"
    )
    contexts = _collect_alignment_context(
        alignment / "event_alignment.csv", ledger,
        {str(row.get("thread_pair_id", "")) for row in divergences},
    )
    return {
        "manifest": manifest,
        "rank_pairs": rank_pairs,
        "unpaired": _read_csv(alignment / "unpaired_ranks.csv", ledger, "未配对 Rank"),
        "threads": thread_pairs,
        "divergences": divergences,
        "contexts": contexts,
        "links": _read_csv(alignment / "host_device_links.csv", ledger, "Host 到 Device 关联"),
        "coverage": _read_csv(
            alignment / "operator_details_rank_coverage.csv", ledger,
            "operator_details Rank 覆盖",
        ),
        "warnings": _read_csv(alignment / "parser_warnings.csv", ledger, "解析告警"),
    }


def _perfetto_data(root: Path | None, ledger: EvidenceLedger) -> dict[str, Any]:
    if root is None:
        return {"status": "not-executed", "reason": "未提供 --perfetto-review-dir", "jobs": [], "content": {}}
    required = (
        root / "perfetto_batch_manifest.json",
        root / "perfetto_content_review.json",
    )
    missing = [str(path) for path in required if not path.is_file()]
    if missing:
        raise ReportBuildError(f"Perfetto review evidence is incomplete: {missing}")
    batch = _read_json(required[0], ledger, "Perfetto batch manifest")
    content = _read_json(required[1], ledger, "Perfetto 内容复核")
    if (root / "perfetto_batch_manifest.csv").is_file():
        _read_csv(root / "perfetto_batch_manifest.csv", ledger, "Perfetto batch CSV")
    status = str(content.get("status") or batch.get("status") or "partial")
    reason = str(content.get("reason") or batch.get("execution_block_reason") or "")
    return {
        "status": status,
        "reason": reason,
        "jobs": batch.get("jobs", []) if isinstance(batch.get("jobs"), list) else [],
        "lane_union": batch.get("lane_batch_union", []),
        "content": content,
        "batch": batch,
    }


def _preflight_data(root: Path | None, ledger: EvidenceLedger) -> dict[str, Any]:
    if root is None:
        return {}
    path = root / "collection_contract.json"
    if not path.is_file():
        raise ReportBuildError(f"preflight evidence is missing: {path}")
    value = _read_json(path, ledger, "Ascend 采集预检")
    if (root / "collection_contract.csv").is_file():
        _read_csv(root / "collection_contract.csv", ledger, "Ascend 采集预检 CSV")
    return value


def _run_contract_data(path: Path | None, ledger: EvidenceLedger) -> dict[str, Any]:
    if path is None:
        return {}
    resolved = path.resolve(strict=True)
    if not resolved.is_file():
        raise ReportBuildError(f"run contract is not a file: {resolved}")
    return _read_json(resolved, ledger, "运行可比性契约")


def _compose_report(
    alignment_root: Path,
    data: dict[str, Any],
    preflight: dict[str, Any],
    run_contract: dict[str, Any],
    source_bundles: list[SourceBundle],
    source_index: dict[str, tuple[str, dict[str, str]]],
    snapshot_bundles: list[SnapshotBundle],
    snapshot_index: dict[str, tuple[str, str]],
    perfetto: dict[str, Any],
    ledger: EvidenceLedger,
) -> str:
    manifest = data["manifest"]
    rank_pairs = sorted(data["rank_pairs"], key=_row_sort)
    unpaired = sorted(data["unpaired"], key=_row_sort)
    threads = sorted(data["threads"], key=_row_sort)
    divergences = sorted(data["divergences"], key=_row_sort)
    links = sorted(data["links"], key=_row_sort)
    coverage = sorted(data["coverage"], key=_row_sort)
    warnings = sorted(data["warnings"], key=_row_sort)
    all_candidates = [
        (bundle.owner, row) for bundle in source_bundles for row in bundle.candidates
    ]
    primary_candidates = _top_candidate_pairs(all_candidates)
    primary_evidence_ids = {
        str(row.get("evidence_id", ""))
        for _owner, row in primary_candidates
        if row.get("evidence_id")
    }
    promoted = [
        (owner, row) for owner, row in primary_candidates
        if row.get("strength") in PROMOTED_STRENGTHS
    ]
    missing_snapshots = sorted(
        row.get("evidence_id", "") for _owner, row in promoted
        if row.get("evidence_id", "") not in snapshot_index
    )
    if missing_snapshots:
        raise ReportBuildError(
            f"promoted candidates have no exact Python snapshot: {missing_snapshots}"
        )

    divergence_by_thread = {
        str(row.get("thread_pair_id", "")): row for row in divergences
    }
    divergence_by_rank: dict[str, Counter[str]] = defaultdict(Counter)
    for row in divergences:
        divergence_by_rank[str(row.get("rank_pair_id", ""))][
            str(row.get("semantic_layer", "unknown"))
        ] += 1
    lane_counts: Counter[tuple[str, str]] = Counter(
        (str(row.get("semantic_layer", "")), str(row.get("status", ""))) for row in threads
    )
    strength_counts = Counter(
        row.get("strength", "未知") for _owner, row in primary_candidates
    )
    top_divergences = sorted(
        divergences,
        key=lambda row: (
            LAYER_ORDER.get(str(row.get("semantic_layer", "")), 99),
            0 if row.get("boundary_stability") == "stable" else 1,
            _row_sort(row),
        ),
    )[:5]

    lines: list[str] = [
        "# Profiling Alignment 大型证据报告：真机 vs 仿真",
        "",
        "reference = 真机",
        "",
        "candidate = 仿真",
        "",
        "本报告只分析算子结构、顺序、嵌套、Shape 与控制流；不分析耗时或性能。",
        "",
        "ts/dur 仅在解析器内部用于排序、B/E 配对、嵌套和 direct flow 端点恢复。",
        "",
        "本报告由结构化证据确定性汇编，可独立阅读；CSV/JSONL 是逐行追溯附件，不是正文替代品。",
        "",
        "## 1. 执行摘要",
        "",
    ]

    _add_table(
        lines,
        ["项目", "真机（reference）", "仿真（candidate）", "证据状态"],
        [
            ("Profiling 根目录", manifest.get("real_root", "未知"), manifest.get("sim_root", "未知"), manifest.get("status", "未知")),
            ("模型代码", _fact_value(run_contract, "real", "model_code"), _fact_value(run_contract, "sim", "model_code"), "以运行契约为准"),
            ("实际分析源码", _fact_value(run_contract, "real", "analyzed_source"), _fact_value(run_contract, "sim", "analyzed_source"), "按 owner 分别绑定"),
            ("workload", _fact_value(run_contract, "real", "workload"), _fact_value(run_contract, "sim", "workload"), "结构可比性字段"),
            ("phase", _fact_value(run_contract, "real", "phase"), _fact_value(run_contract, "sim", "phase"), "结构可比性字段"),
            ("Profiler schedule", _fact_value(run_contract, "real", "profiler_schedule"), _fact_value(run_contract, "sim", "profiler_schedule"), "窗口边界门禁"),
            ("torch_npu", _fact_value(run_contract, "real", "torch_npu_version"), _fact_value(run_contract, "sim", "torch_npu_version"), "依赖源码需另行绑定"),
            ("CANN", _fact_value(run_contract, "real", "cann_version"), _fact_value(run_contract, "sim", "cann_version"), "backend 观察字段"),
        ],
    )

    lines.extend(["### 1.1 源码 owner 身份", ""])
    owner_rows = []
    for bundle in source_bundles:
        repositories = sorted({str(row.get("repository", "")) for row in bundle.candidates if row.get("repository")})
        commits = sorted({str(row.get("commit", "")) for row in bundle.candidates if row.get("commit")})
        indexed = bundle.manifest.get("indexed_source_snapshot", {}) if isinstance(bundle.manifest.get("indexed_source_snapshot"), dict) else {}
        owner_key = bundle.owner.replace("\\", "/").split("/")[-1].casefold()
        role = "reference baseline" if owner_key in {"torch", "torch_npu"} else "模型/训练框架源码"
        owner_rows.append(
            (
                bundle.owner,
                bundle.manifest.get("repo_root") or "未知",
                bundle.directory,
                repositories or [bundle.manifest.get("repository") or "未知"],
                commits or [bundle.manifest.get("resolved_commit") or indexed.get("head_commit") or "未知"],
                indexed.get("tree_hash") or "未知",
                role,
            )
        )
    _add_table(
        lines,
        ["owner", "本地源码根", "证据根", "repository", "commit", "tree", "分析角色"],
        owner_rows,
        empty_message="未提供 MindSpeed/torch/torch_npu 源码因果 owner",
    )
    source_roots = run_contract.get("source_roots", {})
    if not isinstance(source_roots, dict):
        source_roots = {}
    lines.extend(["### 1.1.1 当前工作目录的三份本地源码", ""])
    source_root_rows = []
    for component, display in (
        ("model", "MindSpeed"), ("pytorch", "torch"), ("torch_npu", "torch_npu")
    ):
        entry = source_roots.get(component, {})
        if not isinstance(entry, dict):
            entry = {}
        source_root_rows.append(
            (
                display,
                entry.get("path") or "未知",
                entry.get("role") or (
                    "模型/训练入口" if component == "model" else "真机 reference 源码基线"
                ),
                entry.get("binding_side") or (
                    "shared/model" if component == "model" else "real/reference"
                ),
                entry.get("status") or "unknown",
                entry.get("evidence") or "运行契约未提供",
            )
        )
    _add_table(
        lines,
        ["组件", "本地 checkout 根", "角色", "绑定侧", "状态", "证据"],
        source_root_rows,
    )

    if preflight:
        preflight_rows = []
        for side_key in ("real", "sim"):
            side = preflight.get(side_key, {}) if isinstance(preflight.get(side_key), dict) else {}
            contracts = side.get("contracts", []) if isinstance(side.get("contracts"), list) else []
            formats = sorted({str(row.get("profile_format", "未知")) for row in contracts if isinstance(row, dict)})
            rank_conflicts = sum(bool(row.get("rank_conflict")) for row in contracts if isinstance(row, dict))
            preflight_rows.append(
                (_side_label(side_key), side.get("root", "未知"), side.get("status", "未知"), formats or ["未知"], len(contracts), rank_conflicts)
            )
        lines.extend(["### 1.2 Ascend 采集格式门禁", ""])
        _add_table(
            lines,
            ["环境", "根目录", "状态", "格式", "采集单元", "Rank 冲突数"],
            preflight_rows,
        )
    else:
        lines.extend(["### 1.2 Ascend 采集格式门禁", "", "预检目录未提供，采集格式状态为未知；结构结果仍以下方 manifest 门禁为准。", ""])

    lines.extend(["### 1.3 Rank、lane 与分叉总览", ""])
    _add_table(
        lines,
        ["范围", "值"],
        [
            ("真机 Rank", manifest.get("real_rank_ids", [])),
            ("仿真 Rank", manifest.get("sim_rank_ids", [])),
            ("实际比较的同号 Rank", manifest.get("compared_rank_ids", [])),
            ("未配对 Rank", manifest.get("unpaired_rank_ids", [])),
            ("Rank 配对规则", manifest.get("rank_pair_rule", "未知")),
            ("lane 总数", len(threads)),
            ("首分叉窗口总数", len(divergences)),
            ("Host→Device 关联行", len(links)),
        ],
    )
    _add_table(
        lines,
        ["语义层", "matched", "matched-degraded", "ambiguous", "real-only", "sim-only", "其它"],
        [
            (
                layer,
                lane_counts[(layer, "matched")],
                lane_counts[(layer, "matched-degraded")],
                lane_counts[(layer, "ambiguous")],
                lane_counts[(layer, "real-only")],
                lane_counts[(layer, "sim-only")],
                sum(count for (row_layer, status), count in lane_counts.items() if row_layer == layer and status not in {"matched", "matched-degraded", "ambiguous", "real-only", "sim-only"}),
            )
            for layer in ("framework_op", "host_launch", "device_task")
        ],
    )
    _add_table(
        lines,
        ["Rank pair", "framework_op 分叉", "host_launch 分叉", "device_task 分叉", "独立证据"],
        [
            (
                row.get("rank_pair_id"),
                divergence_by_rank[row.get("rank_pair_id", "")]["framework_op"],
                divergence_by_rank[row.get("rank_pair_id", "")]["host_launch"],
                divergence_by_rank[row.get("rank_pair_id", "")]["device_task"],
                ", ".join(
                    f"divergence_id={item.get('divergence_id')}"
                    for item in divergences if item.get("rank_pair_id") == row.get("rank_pair_id")
                ) or "exact/no divergence",
            )
            for row in rank_pairs
        ],
    )

    lines.extend(["### 1.4 最重要的稳定结构分叉", ""])
    _add_table(
        lines,
        ["优先级", "分叉", "Rank/lane", "层", "真机路线", "仿真路线", "边界", "代码证据"],
        [
            (
                index,
                f"divergence_id={row.get('divergence_id')}",
                f"{row.get('rank_pair_id')} / {row.get('thread_pair_id')}",
                row.get("semantic_layer"),
                row.get("real_operators", []),
                row.get("sim_operators", []),
                f"boundary_stability={row.get('boundary_stability')}; anchors_before={row.get('anchors_before')}; anchors_after={row.get('anchors_after')}",
                ", ".join(
                    f"evidence_id={candidate.get('evidence_id')} ({candidate.get('strength')})"
                    for _owner, candidate in primary_candidates
                    if candidate.get("divergence_id") == row.get("divergence_id")
                ) or "尚无 Python guard 绑定",
            )
            for index, row in enumerate(top_divergences, 1)
        ],
    )
    _add_table(
        lines,
        ["结论等级", "数量", "evidence_id"],
        [
            (level, strength_counts[level], ", ".join(
                f"evidence_id={row.get('evidence_id')}"
                for _owner, row in primary_candidates
                if row.get("strength") == level
            ) or "无")
            for level in ("已证实控制流分叉", "强关联控制流分叉", "静态候选")
        ] + [
            ("仿真计算错误已证实", 0, "当前证据无法判定/未证实；不能从 Shape 或下游算子反推 predicate operand 值"),
            ("未知", sum(1 for row in divergences if not any(candidate.get("divergence_id") == row.get("divergence_id") for _owner, candidate in all_candidates)), "尚未绑定 AST guard 的分叉数"),
        ],
    )

    missing_actions: list[str] = []
    for _owner, candidate in primary_candidates:
        missing_actions.extend(_candidate_missing(candidate))
    if not any(str(row.get("causal_eligible", "")).strip() in {"是", "yes", "true", "1"} for row in links):
        missing_actions.append("补采唯一 direct flow/correlation，使 Host 与 Device 端点可直接关联")
    if not missing_actions:
        missing_actions = [
            "在最高价值 guard 记录两侧 predicate result 与直接 operand value",
            "固定同一输入、权重、seed、配置和源码快照执行最小 A/B",
            "复核首分叉后算子序列是否在下一共同 anchor 重新汇合",
        ]
    unique_actions = list(dict.fromkeys(missing_actions))[:3]
    lines.extend(["### 1.5 最小验证动作", ""])
    for index, action in enumerate(unique_actions, 1):
        lines.append(f"{index}. {_safe_visible(action)}")
    lines.append("")

    lines.extend(["## 2. Rank 与 Thread 覆盖", ""])
    _add_table(
        lines,
        ["Rank pair", "真机 Rank/trace SHA", "仿真 Rank/trace SHA", "真机拓扑", "仿真拓扑", "拓扑门禁", "Framework 真/仿", "Launch 真/仿", "Device 真/仿", "解析状态", "结论"],
        [
            (
                row.get("rank_pair_id"),
                f"{row.get('real_rank')} / {row.get('real_trace_sha256')}",
                f"{row.get('sim_rank')} / {row.get('sim_trace_sha256')}",
                row.get("real_topology", "未知"),
                row.get("sim_topology", "未知"),
                row.get("topology_compatible", "未知"),
                f"{row.get('real_framework_lanes', 0)}/{row.get('sim_framework_lanes', 0)}",
                f"{row.get('real_host_launch_lanes', 0)}/{row.get('sim_host_launch_lanes', 0)}",
                f"{row.get('real_device_lanes', 0)}/{row.get('sim_device_lanes', 0)}",
                f"real={row.get('real_parse_status')}; sim={row.get('sim_parse_status')}",
                row.get("status"),
            )
            for row in rank_pairs
        ],
    )
    for row in rank_pairs:
        pair_id = str(row.get("rank_pair_id", ""))
        pair_threads = [item for item in threads if item.get("rank_pair_id") == pair_id]
        pair_divergences = [item for item in divergences if item.get("rank_pair_id") == pair_id]
        lines.extend([render_rank_narrative(row, pair_threads, pair_divergences), ""])
    lines.extend(["### 2.1 未配对或身份冲突 Rank", ""])
    _add_table(
        lines,
        ["环境", "Rank", "路径", "身份状态", "原因"],
        [
            (row.get("environment"), row.get("rank"), row.get("path"), row.get("identity_status", "未知"), row.get("reason"))
            for row in unpaired
        ],
    )

    lines.extend(["### 2.2 全量 lane 清单", "", "PID/TID/stream 只在各自环境内有意义；跨环境配对依据语义指纹，ambiguous 与单侧 lane 未被强配。", ""])
    _add_table(
        lines,
        ["Rank", "lane/thread_pair_id", "Domain", "Semantic layer", "真机 lane", "仿真 lane", "方法", "Score/Margin", "置信度", "状态", "首分叉", "允许结论"],
        [
            (
                f"rank_pair_id={row.get('rank_pair_id')}", f"thread_pair_id={row.get('thread_pair_id') or '缺失'}", f"domain={row.get('domain')}", f"semantic_layer={row.get('semantic_layer')}",
                f"真机 lane={row.get('real_lane_id') or '缺失'}", f"仿真 lane={row.get('sim_lane_id') or '缺失'}",
                row.get("match_method"), f"{row.get('score')}/{row.get('margin')}",
                row.get("confidence"), f"status={row.get('status')}",
                f"divergence_id={divergence_by_thread[row.get('thread_pair_id', '')].get('divergence_id')}" if row.get("thread_pair_id", "") in divergence_by_thread else "exact/no divergence 或不可配对",
                _lane_allowed(row),
            )
            for row in threads
        ],
    )

    lines.extend(["## 3. Host 算子序列与首次分叉", "", "本节完整展开 framework Host 与 Host launch，并保留 Device 首分叉行用于三层路线对照。", ""])
    for layer, title in (
        ("framework_op", "Framework Host 算子"),
        ("host_launch", "Host launch bridge"),
        ("device_task", "NPU Device task"),
    ):
        lines.extend([f"### 3.{LAYER_ORDER[layer] + 1} {title}", ""])
        layer_threads = [row for row in threads if row.get("semantic_layer") == layer and row.get("status") in {"matched", "matched-degraded"}]
        rows = []
        for thread in layer_threads:
            divergence = divergence_by_thread.get(thread.get("thread_pair_id", ""))
            if divergence is None:
                rows.append((thread.get("rank_pair_id"), thread.get("thread_pair_id"), f"domain={thread.get('domain')}; semantic_layer={thread.get('semantic_layer')}", "exact/no divergence", "—", "—", "—", "—", "—", "无首差异"))
            else:
                rows.append(
                    (
                        divergence.get("rank_pair_id"), divergence.get("thread_pair_id"),
                        f"domain={divergence.get('domain')}; semantic_layer={divergence.get('semantic_layer')}",
                        f"divergence_id={divergence.get('divergence_id')}",
                        f"最后共同 anchor={_format_anchor(divergence.get('last_common_anchor'))}",
                        f"真机 operator={divergence.get('real_operators')}; calls={divergence.get('real_run_calls')}; Shape={divergence.get('real_shapes')}",
                        f"仿真 operator={divergence.get('sim_operators')}; calls={divergence.get('sim_run_calls')}; Shape={divergence.get('sim_shapes')}",
                        f"下一共同 anchor={_format_anchor(divergence.get('next_common_anchor'))}",
                        f"boundary_stability={divergence.get('boundary_stability')}; {_alignment_boundaries(divergence)}",
                        f"anchors_before={divergence.get('anchors_before')}; anchors_after={divergence.get('anchors_after')}; gate={divergence.get('anchor_gate_passed')}; repeated={divergence.get('repeated_anchor_ambiguous')}; nesting={divergence.get('nesting_gate_passed')}; earlier={divergence.get('earlier_unresolved')}",
                    )
                )
        _add_table(
            lines,
            ["Rank", "lane", "Domain/layer", "分叉", "最后共同 anchor", "真机首差异/Shape/calls", "仿真首差异/Shape/calls", "下一共同 anchor", "三视图边界", "门禁/歧义"],
            rows,
        )

    lines.extend(["### 3.4 每个首分叉的受控对齐上下文", "", "以下只展开 `event_alignment.csv` 中每个首分叉前后各三列；未复制长 equal 前缀，也未读取 `canonical_events.csv` 全量。", ""])
    for index, divergence in enumerate(divergences, 1):
        divergence_id = str(divergence.get("divergence_id", ""))
        thread_id = str(divergence.get("thread_pair_id", ""))
        lines.extend([
            f"#### 3.4.{index} divergence_id={_safe_visible(divergence_id)}",
            "",
            f"divergence_id={_safe_visible(divergence_id)}；证据位置：Rank `{_safe_visible(divergence.get('rank_pair_id'))}`，lane `{_safe_visible(thread_id)}`，层 `{_safe_visible(divergence.get('semantic_layer'))}`。boundary_stability=`{_safe_visible(divergence.get('boundary_stability'))}`；anchors_before=`{_safe_visible(divergence.get('anchors_before'))}`；anchors_after=`{_safe_visible(divergence.get('anchors_after'))}`；{_safe_visible(_alignment_boundaries(divergence))}。",
            "",
            f"最后共同 anchor：{_safe_visible(_format_anchor(divergence.get('last_common_anchor')))}",
            "",
            f"真机首差异：{_safe_visible(_format_run(_parse_run(divergence.get('first_real_event'))))}",
            "",
            f"仿真首差异：{_safe_visible(_format_run(_parse_run(divergence.get('first_sim_event'))))}",
            "",
            f"下一共同 anchor：{_safe_visible(_format_anchor(divergence.get('next_common_anchor')))}",
            "",
            render_divergence_narrative(divergence),
            "",
        ])
        context = data["contexts"].get(thread_id, [])
        _add_table(
            lines,
            ["alignment_column", "relation", "first", "真机 operator/calls", "仿真 operator/calls", "真机 event IDs", "仿真 event IDs"],
            [
                (
                    row.get("alignment_column"), row.get("relation"), row.get("first_divergence"),
                    f"{row.get('real_operator') or '—'} / {row.get('real_run_calls') or '—'}",
                    f"{row.get('sim_operator') or '—'} / {row.get('sim_run_calls') or '—'}",
                    row.get("real_event_ids") or "—", row.get("sim_event_ids") or "—",
                )
                for row in context
            ],
            empty_message="该 lane 缺少受控 event_alignment 上下文",
        )
        alternatives = divergence.get("alternative_explanations", [])
        if not isinstance(alternatives, list):
            alternatives = [alternatives]
        lines.append("替代解释：" + "；".join(_safe_visible(item) for item in alternatives if item) + "。")
        lines.append("")

    lines.extend(["## 4. Device 序列与 Host→Device", ""])
    eligible = [
        row for row in links
        if str(row.get("causal_eligible", "")).strip().casefold() in {"是", "yes", "true", "1"}
        and row.get("link_status") in {"direct-id", "direct-flow"}
    ]
    if not eligible:
        lines.extend(["Host 与 Device 差异尚未形成直接因果边；下表中的降级或歧义关联只用于导航，不按空间邻近补链。", ""])
    _add_table(
        lines,
        ["环境/Rank", "Host event/layer/lane", "Device event/lane", "类型/namespace", "端点匹配", "ID hash", "Link 状态", "Causal eligible", "证据 IDs"],
        [
            (
                f"{_side_label(row.get('environment'))}/{row.get('rank')}",
                f"{row.get('host_event_id')} / {row.get('host_semantic_layer')} / {row.get('host_lane_id')}",
                f"{row.get('device_event_id')} / {row.get('device_lane_id')}",
                f"{row.get('correlation_type')} / {row.get('correlation_namespace')}",
                row.get("endpoint_match"), row.get("correlation_id_hash"),
                row.get("link_status"), row.get("causal_eligible"), row.get("evidence_ids"),
            )
            for row in links
        ],
    )
    lines.extend(["### 4.1 Host launch lane 作为 bridge 的覆盖", ""])
    _add_table(
        lines,
        ["Rank", "lane", "真机 lane", "仿真 lane", "状态", "首分叉"],
        [
            (
                row.get("rank_pair_id"), row.get("thread_pair_id"), row.get("real_lane_id"),
                row.get("sim_lane_id"), row.get("status"),
                f"divergence_id={divergence_by_thread[row.get('thread_pair_id', '')].get('divergence_id')}" if row.get("thread_pair_id", "") in divergence_by_thread else "exact/no divergence",
            )
            for row in threads if row.get("semantic_layer") == "host_launch"
        ],
    )

    lines.extend(["## 5. 控制流与代码证据", ""])
    if not source_bundles:
        lines.extend(["未提供源码因果目录，算子路线尚未绑定到 Python `if/elif/else`。", ""])
    for bundle_index, bundle in enumerate(source_bundles, 1):
        lines.extend([f"### 5.{bundle_index} 源码 owner：{_safe_visible(bundle.owner)}", "", f"证据目录：`{_safe_visible(bundle.directory)}`", ""])
        lines.append("入口链：")
        lines.append("")
        _add_table(
            lines,
            ["类型", "source", "target", "状态", "证据"],
            [
                (row.get("chain_kind"), row.get("source"), row.get("target"), row.get("status"), row.get("evidence"))
                for row in bundle.entrypoint_chain
            ],
        )
        lines.append(
            "Guard 候选全量表（每个 divergence 仅 candidate_rank 最小者可晋级；其余只作静态导航）："
        )
        lines.append("")
        _add_table(
            lines,
            ["evidence_id/Rank/lane", "divergence_id", "guard_id + predicate", "Repo@commit", "Python path/symbol/lines", "真机 arm+算子", "仿真 arm+算子", "边界/lane/anchor 门禁", "runtime/source 门禁", "强度", "最小缺证"],
            [
                (
                    f"evidence_id={row.get('evidence_id')} / {row.get('rank_pair_id')} / {row.get('thread_pair_id')}",
                    f"divergence_id={row.get('divergence_id')}",
                    f"{row.get('guard_id')} / {row.get('predicate_text')}",
                    f"{row.get('repository')}@{row.get('commit')}",
                    f"{row.get('guard_path')}:{row.get('guard_lines')} / {row.get('guard_symbol')}",
                    f"{row.get('real_arm')} [{row.get('real_arm_lines')}] / {row.get('real_operators')}",
                    f"{row.get('sim_arm')} [{row.get('sim_arm_lines')}] / {row.get('sim_operators')}",
                    f"boundary={row.get('boundary_stability')}; lane_status={row.get('lane_match_status')}; lane_confidence={row.get('lane_match_confidence')}; anchors_before={row.get('anchors_before')}; anchors_after={row.get('anchors_after')}; repeated={row.get('repeated_anchor_ambiguous')}",
                    f"runtime={row.get('runtime_binding')}; predicate={row.get('predicate_real_result')} vs {row.get('predicate_sim_result')}; operand={row.get('direct_operand_values_observed')}; analyzed_source={row.get('analyzed_source_gate_passed')}; dependency={row.get('dependency_source_gate_passed')}",
                    (
                        row.get("strength")
                        if str(row.get("evidence_id", "")) in primary_evidence_ids
                        else "未晋级静态备选"
                    ),
                    row.get("minimal_missing_evidence"),
                )
                for row in sorted(bundle.candidates, key=_row_sort)
            ],
        )
        for row in sorted(bundle.candidates, key=_row_sort):
            evidence_id = str(row.get("evidence_id", ""))
            if evidence_id not in primary_evidence_ids:
                continue
            lines.extend([render_candidate_narrative(row), ""])
        lines.append("Predicate tensor 与 producer：")
        lines.append("")
        candidate_by_id = {row.get("evidence_id", ""): row for row in bundle.candidates}
        _add_table(
            lines,
            ["evidence_id/guard", "Operand", "类型", "真机直接值/result", "仿真直接值/result", "静态 producer", "状态", "缺失补证"],
            [
                (
                    f"evidence_id={row.get('evidence_id')} / {row.get('guard_id')}",
                    row.get("operand_expr"), row.get("operand_kind"),
                    candidate_by_id.get(row.get("evidence_id", ""), {}).get("real_operand_values") or "未知",
                    candidate_by_id.get(row.get("evidence_id", ""), {}).get("sim_operand_values") or "未知",
                    f"{row.get('producer_path')}:{row.get('producer_line_start')} / {row.get('producer_expression')}",
                    f"producer={row.get('producer_status')}; runtime={row.get('runtime_value_status')}",
                    "记录同一 guard 的 predicate result、operand value 与 producer event ID" if row.get("runtime_value_status") != "direct" else "已具直接值；仍需语义 oracle 才能判定计算错误",
                )
                for row in sorted(bundle.predicates, key=_row_sort)
            ],
        )
        lines.append("Branch-exclusive Host 算子到 Device 的直接证据：")
        lines.append("")
        _add_table(
            lines,
            ["divergence/Rank/lane", "环境", "Host event", "Device event/operator", "stream/task", "link", "Causal eligible", "证据 IDs"],
            [
                (
                    f"divergence_id={row.get('divergence_id')} / {row.get('rank_pair_id')} / {row.get('thread_pair_id')}",
                    _side_label(row.get("environment")), row.get("host_event_id"),
                    f"{row.get('device_event_id')} / {row.get('device_operator')}",
                    f"{row.get('device_stream_id')} / {row.get('device_task_id')} / {row.get('device_task_type')}",
                    f"{row.get('link_status')} / {row.get('link_namespace')} / {row.get('endpoint_match')}",
                    row.get("causal_eligible"), row.get("link_evidence_ids"),
                )
                for row in sorted(bundle.branch_device, key=_row_sort)
            ],
        )
        lines.append("算子到 Python callsite 映射：")
        lines.append("")
        _add_table(
            lines,
            ["evidence_id", "环境/Rank/lane", "operator", "Python callsite", "symbol", "置信度"],
            [
                (
                    f"evidence_id={row.get('evidence_id')}",
                    f"{_side_label(row.get('environment'))}/{row.get('rank_pair_id')}/{row.get('thread_pair_id')}",
                    row.get("operator"),
                    f"{row.get('path')}:{row.get('line_start')}-{row.get('line_end')} / {row.get('source_call')}",
                    row.get("symbol"), row.get("confidence"),
                )
                for row in sorted(bundle.event_source, key=_row_sort)
            ],
        )

    lines.extend(["### 5.90 带原始行号的 Python HTML 代码快照", "", "以下静态代码快照块逐字来自各 owner 的 `python_guard_snapshots.md`；汇编器未修改路径、commit/tree、行号、arm 标记、源码文本或哈希。", ""])
    embedded_blocks: list[str] = []
    for bundle in snapshot_bundles:
        selected_ids = sorted(set(bundle.blocks) & primary_evidence_ids)
        if not selected_ids:
            continue
        lines.extend([f"#### 5.90.{len(embedded_blocks) + 1} 快照 owner：{_safe_visible(bundle.owner)}", ""])
        for evidence_id in selected_ids:
            block = bundle.blocks[evidence_id]
            lines.append(block)
            lines.append("")
            embedded_blocks.append(block)
    if not embedded_blocks:
        lines.extend(["未提供可验证的 Python guard 快照；任何代码级候选不得升级为强关联或已证实。", ""])

    lines.extend(["## 6. Predicate tensor 与 producer", "", "下表跨 owner 汇总 predicate operand、直接值状态和最近静态 producer；直接 Shape 不是直接 tensor value。", ""])
    aggregate_predicates = []
    for bundle in source_bundles:
        candidate_by_id = {row.get("evidence_id", ""): row for row in bundle.candidates}
        for row in bundle.predicates:
            candidate = candidate_by_id.get(row.get("evidence_id", ""), {})
            aggregate_predicates.append(
                (
                    bundle.owner,
                    f"evidence_id={row.get('evidence_id')} / {row.get('guard_id')}",
                    row.get("operand_expr"), row.get("operand_kind"),
                    candidate.get("real_operand_values") or "未知",
                    candidate.get("sim_operand_values") or "未知",
                    f"{row.get('producer_path')}:{row.get('producer_line_start')} / {row.get('producer_expression')}",
                    f"producer={row.get('producer_status')}; runtime={row.get('runtime_value_status')}",
                    "记录 predicate result、operand value、producer event ID 与语义 oracle" if row.get("runtime_value_status") != "direct" else "仍需语义 oracle 与可重复 A/B",
                )
            )
    _add_table(
        lines,
        ["owner", "evidence_id/guard", "Operand", "类型", "真机直接值/result", "仿真直接值/result", "静态 producer", "证据状态", "缺失补证"],
        aggregate_predicates,
    )

    lines.extend(["## 7. Perfetto 内容复核", ""])
    perfetto_status = str(perfetto.get("status", "not-executed"))
    if perfetto_status == "complete":
        lines.append("Perfetto 内容复核已完成：manifest/HTML/text/SQL/browser log 均已读取，并以本地结构解析为主证据。")
    elif perfetto_status == "not-executed":
        lines.append(f"Perfetto 内容复核未执行：{_safe_visible(perfetto.get('reason') or '未满足在线授权、浏览器或自动化条件')}。")
    else:
        lines.append(f"Perfetto 内容复核部分完成：status={_safe_visible(perfetto_status)}；未完成部分不作页面或 SQL 一致性结论。")
    lines.append("")
    content = perfetto.get("content", {}) if isinstance(perfetto.get("content"), dict) else {}
    reviewed_jobs = content.get("reviewed_jobs", []) if isinstance(content.get("reviewed_jobs"), list) else []
    reviewed_by_key = {
        (str(row.get("rank_pair_id", "")), str(row.get("environment", "")), str(row.get("batch", "") or Path(str(row.get("output_dir", ""))).name)): row
        for row in reviewed_jobs if isinstance(row, dict)
    }
    perfetto_rows = []
    for job in perfetto.get("jobs", []):
        if not isinstance(job, dict):
            continue
        batch_name = Path(str(job.get("output_dir", ""))).name if job.get("output_dir") else ""
        review = reviewed_by_key.get((str(job.get("rank_pair_id", "")), str(job.get("environment", "")), batch_name), {})
        gate_details = _jsonish(job.get("gate_details", ""), {})
        gates = gate_details.get("gates", {}) if isinstance(gate_details, dict) else {}
        lane_keys = _jsonish(job.get("batch_lane_keys_json", ""), [])
        perfetto_rows.append(
            (
                job.get("rank_pair_id"), _side_label(job.get("environment")), batch_name or "—",
                job.get("trace_sha256") or job.get("expected_trace_sha256") or "未知",
                len(lane_keys) if isinstance(lane_keys, list) else "未知",
                f"run={job.get('run_status')}; auto={job.get('auto_artifact_gate')}; union={job.get('lane_batch_union_complete', '未知')}",
                _compact({key: value for key, value in gates.items() if key in {"official_origin", "local_only", "offline_before_post", "service_worker_guard", "sql_complete"}}),
                review.get("status") or job.get("content_review_status") or "未知",
                "是" if content.get("screenshot_reviewed") is True else "否",
                "已按截图复核" if content.get("canvas_claims_made") is True else "未评价",
            )
        )
    _add_table(
        lines,
        ["Rank", "环境", "batch", "Trace SHA", "Host lane 数", "自动/union 门禁", "Offline/SW/localOnly/SQL", "内容复核", "Screenshot 已看", "Canvas 结论"],
        perfetto_rows,
    )
    observations = content.get("observations", []) if isinstance(content.get("observations"), list) else []
    if observations:
        lines.append("内容观察：")
        lines.append("")
        for observation in observations:
            lines.append(f"- {_safe_visible(observation)}")
        lines.append("")

    lines.extend(["## 8. 结论强度与替代解释", ""])
    _add_table(
        lines,
        ["owner", "evidence_id", "divergence_id", "Python guard", "运行路线证据", "强度", "替代解释", "最小补证"],
        [
            (
                owner, f"evidence_id={row.get('evidence_id')}", f"divergence_id={row.get('divergence_id')}",
                f"{row.get('guard_path')}:{row.get('guard_lines')} / {row.get('guard_id')} / {row.get('predicate_text')}",
                f"真机 {row.get('real_arm')} {row.get('real_operators')}；仿真 {row.get('sim_arm')} {row.get('sim_operators')}",
                row.get("strength"),
                "采集窗口；输入/Shape；lane 错配；backend lowering；图捕获；instrumentation；源码绑定冲突",
                row.get("minimal_missing_evidence"),
            )
            for owner, row in sorted(
                primary_candidates, key=lambda item: (_row_sort(item[1]), item[0])
            )
        ],
    )
    if not primary_candidates:
        lines.extend(["当前只有结构分叉事实，尚无可审计 Python guard；代码级原因保持未知。", ""])
    lines.extend([
        "仿真 tensor 计算错误当前证据无法判定/未证实。只有两侧同输入、权重、seed、配置、源码和 Rank 状态一致，并取得直接 predicate operand 值、最早 producer、语义 oracle 与可重复 A/B 后，才允许升级。",
        "",
        "## 9. 最小验证动作",
        "",
    ])
    actions = list(dict.fromkeys(missing_actions))
    for index, action in enumerate(actions[:10], 1):
        lines.append(f"{index}. {_safe_visible(action)}")
    lines.append("")

    lines.extend(["## 10. 附录与证据可追溯性", "", "### 10.1 Rank 级 operator_details 覆盖", "", "`operator_details` 缺少 pid/tid 时仅作为 Rank 级覆盖，不冒充 Thread 序列。下表完整汇编可观测覆盖行。", ""])
    _add_table(
        lines,
        ["环境", "Rank", "scope", "operator", "Input Shape", "Output Shape", "calls/source row", "call stack", "来源"],
        [
            (
                _side_label(row.get("environment")), row.get("rank"), row.get("coverage_scope"),
                row.get("canonical_op") or row.get("raw_name"), row.get("input_shapes"),
                row.get("output_shapes"), row.get("calls") or row.get("source_row"),
                row.get("call_stack"), row.get("source"),
            )
            for row in coverage
        ],
    )
    lines.extend(["### 10.2 解析告警", ""])
    _add_table(
        lines,
        ["环境", "Rank", "来源", "告警"],
        [(row.get("environment"), row.get("rank"), row.get("source"), row.get("warning")) for row in warnings],
    )
    source_issues = [
        (bundle.owner, row) for bundle in source_bundles for row in bundle.issues
    ]
    lines.extend(["### 10.3 源码分析问题", ""])
    _add_table(
        lines,
        ["owner", "path", "issue", "detail", "impact"],
        [(owner, row.get("path"), row.get("issue"), row.get("detail"), row.get("impact")) for owner, row in source_issues],
    )
    lines.extend(["### 10.4 证据文件、schema 与哈希", ""])
    _add_table(
        lines,
        ["角色", "绝对路径", "bytes", "SHA-256"],
        [(entry.role, entry.path, entry.bytes, entry.sha256) for entry in ledger.entries()],
    )
    _add_table(
        lines,
        ["组件", "schema", "algorithm/status"],
        [
            ("报告汇编器", SCHEMA_VERSION, "deterministic-single-markdown-v1"),
            ("结构对齐", manifest.get("schema_version", "未知"), manifest.get("algorithm_version", "未知")),
            ("Ascend 预检", preflight.get("schema_version", "未提供") if preflight else "未提供", preflight.get("status", "未知") if preflight else "未知"),
        ] + [
            (f"源码因果/{bundle.owner}", bundle.manifest.get("schema_version", "未知"), bundle.manifest.get("algorithm_version") or bundle.manifest.get("status") or "未知")
            for bundle in source_bundles
        ],
    )
    lines.extend([
        f"结构序位热力图附件：`{_safe_visible(alignment_root / 'structural_heatmap.html')}`。其横轴是 lane 内 event ordinal，不是时间轴。",
        "",
        "原始 Profiling、MindSpeed/torch/torch_npu checkout 与远端仓库均未被本汇编器修改；本命令只写当前主报告。",
        "",
    ])
    text = "\n".join(lines)
    _validate_final_text(text, embedded_blocks)
    return text


def compile_report(
    alignment_output: Path,
    *,
    preflight_dir: Path | None = None,
    run_contract: Path | None = None,
    source_causality_dir: Path | None = None,
    python_snapshots_dir: Path | None = None,
    perfetto_review_dir: Path | None = None,
) -> dict[str, Any]:
    alignment = alignment_output.resolve(strict=True)
    if not alignment.is_dir() or _is_reparse(alignment):
        raise ReportBuildError("--alignment-output must be a regular non-reparse directory")
    preflight_root = _validate_optional_directory(preflight_dir, "--preflight-dir")
    source_root = _validate_optional_directory(source_causality_dir, "--source-causality-dir")
    snapshot_root = _validate_optional_directory(python_snapshots_dir, "--python-snapshots-dir")
    perfetto_root = _validate_optional_directory(perfetto_review_dir, "--perfetto-review-dir")
    ledger = EvidenceLedger()
    alignment_data = _load_alignment(alignment, ledger)
    preflight = _preflight_data(preflight_root, ledger)
    contract = _run_contract_data(run_contract, ledger)
    source_bundles, source_index = _load_source_bundles(source_root, ledger)
    snapshot_bundles, snapshot_index = _load_snapshot_bundles(snapshot_root, ledger)
    perfetto = _perfetto_data(perfetto_root, ledger)
    report = _compose_report(
        alignment,
        alignment_data,
        preflight,
        contract,
        source_bundles,
        source_index,
        snapshot_bundles,
        snapshot_index,
        perfetto,
        ledger,
    )
    return {
        "schema_version": SCHEMA_VERSION,
        "status": "complete",
        "text": report,
        "bytes": len(report.encode("utf-8")),
        "sha256": hashlib.sha256(report.encode("utf-8")).hexdigest(),
        "rank_count": len(alignment_data["rank_pairs"]),
        "lane_count": len(alignment_data["threads"]),
        "divergence_count": len(alignment_data["divergences"]),
        "source_owner_count": len(source_bundles),
        "snapshot_owner_count": len(snapshot_bundles),
        "artifact_count": 1,
    }


def build_report(
    alignment_output: Path,
    output: Path,
    *,
    preflight_dir: Path | None = None,
    run_contract: Path | None = None,
    source_causality_dir: Path | None = None,
    python_snapshots_dir: Path | None = None,
    perfetto_review_dir: Path | None = None,
) -> dict[str, Any]:
    alignment, output_path = _validate_output(alignment_output, output)
    preflight_root = _validate_optional_directory(preflight_dir, "--preflight-dir")
    source_root = _validate_optional_directory(source_causality_dir, "--source-causality-dir")
    snapshot_root = _validate_optional_directory(python_snapshots_dir, "--python-snapshots-dir")
    perfetto_root = _validate_optional_directory(perfetto_review_dir, "--perfetto-review-dir")
    for root, label in (
        (preflight_root, "preflight"),
        (source_root, "source-causality"),
        (snapshot_root, "python-snapshots"),
        (perfetto_root, "perfetto-review"),
    ):
        if root is not None and _is_within(output_path, root):
            raise ReportBuildError(f"--output must not be inside {label} evidence directory")
    compiled = compile_report(
        alignment,
        preflight_dir=preflight_root,
        run_contract=run_contract,
        source_causality_dir=source_root,
        python_snapshots_dir=snapshot_root,
        perfetto_review_dir=perfetto_root,
    )
    report = str(compiled.pop("text"))
    _atomic_write(output_path, report)
    return {
        **compiled,
        "output": str(output_path),
    }


def _write_fixture_csv(path: Path, rows: list[dict[str, Any]], fields: Sequence[str]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(fields), lineterminator="\n")
        writer.writeheader()
        writer.writerows(rows)


def _write_self_test_fixture(root: Path) -> dict[str, Path]:
    report_root = root / "report-output"
    alignment = report_root / "evidence" / "alignment"
    alignment.mkdir(parents=True)
    (alignment / "analysis_manifest.json").write_text(
        json.dumps(
            {
                "schema_version": 3,
                "algorithm_version": "fixture-alignment",
                "status": "complete",
                "real_root": str(root / "real"),
                "sim_root": str(root / "sim"),
                "real_rank_ids": [0],
                "sim_rank_ids": [0],
                "compared_rank_ids": [0],
                "unpaired_rank_ids": [],
                "rank_pair_rule": "sorted intersection of exact global rank IDs",
                "duration_metrics_emitted": False,
            },
            ensure_ascii=False,
        ),
        encoding="utf-8",
    )
    rank_fields = [
        "rank_pair_id", "real_rank", "sim_rank", "real_trace_path", "sim_trace_path",
        "real_trace_sha256", "sim_trace_sha256", "real_topology", "sim_topology",
        "topology_compatible", "real_framework_lanes", "sim_framework_lanes",
        "real_host_launch_lanes", "sim_host_launch_lanes", "real_device_lanes",
        "sim_device_lanes", "real_parse_status", "sim_parse_status", "status",
    ]
    _write_fixture_csv(
        alignment / "rank_pairs.csv",
        [{
            "rank_pair_id": "rank-0000", "real_rank": 0, "sim_rank": 0,
            "real_trace_path": "real/trace_view.json", "sim_trace_path": "sim/trace_view.json",
            "real_trace_sha256": "a" * 64, "sim_trace_sha256": "b" * 64,
            "real_topology": "dp=0", "sim_topology": "dp=0", "topology_compatible": "是",
            "real_framework_lanes": 1, "sim_framework_lanes": 1,
            "real_host_launch_lanes": 1, "sim_host_launch_lanes": 1,
            "real_device_lanes": 1, "sim_device_lanes": 1,
            "real_parse_status": "success", "sim_parse_status": "success", "status": "ready",
        }],
        rank_fields,
    )
    _write_fixture_csv(
        alignment / "unpaired_ranks.csv", [],
        ["environment", "rank", "path", "identity_status", "reason"],
    )
    thread_fields = [
        "rank_pair_id", "thread_pair_id", "domain", "semantic_layer", "real_lane_id",
        "sim_lane_id", "match_method", "score", "margin", "confidence", "status",
    ]
    thread_rows = [
        {"rank_pair_id": "rank-0000", "thread_pair_id": "lane-fw", "domain": "host", "semantic_layer": "framework_op", "real_lane_id": "real-fw", "sim_lane_id": "sim-fw", "match_method": "name", "score": "1", "margin": "1", "confidence": "高", "status": "matched"},
        {"rank_pair_id": "rank-0000", "thread_pair_id": "lane-launch", "domain": "host", "semantic_layer": "host_launch", "real_lane_id": "real-launch", "sim_lane_id": "sim-launch", "match_method": "fingerprint", "score": "0.9", "margin": "0.2", "confidence": "高", "status": "matched"},
        {"rank_pair_id": "rank-0000", "thread_pair_id": "lane-device", "domain": "device", "semantic_layer": "device_task", "real_lane_id": "stream-7", "sim_lane_id": "stream-3", "match_method": "fingerprint", "score": "0.9", "margin": "0.2", "confidence": "高", "status": "matched"},
    ]
    _write_fixture_csv(alignment / "thread_pairs.csv", thread_rows, thread_fields)
    align_fields = [
        "rank_pair_id", "domain", "semantic_layer", "thread_pair_id", "alignment_column",
        "real_event_ids", "sim_event_ids", "real_operator", "sim_operator",
        "real_run_calls", "sim_run_calls", "relation", "first_divergence",
    ]
    align_rows = []
    for lane, domain, layer, real_op, sim_op in (
        ("lane-fw", "host", "framework_op", "aten::copy_", "aten::empty"),
        ("lane-launch", "host", "host_launch", "aclnnForeachCopy", "aclrtMemcpy"),
        ("lane-device", "device", "device_task", "ForeachCopy", "Memcpy"),
    ):
        for column in range(5):
            first = column == 2
            align_rows.append({
                "rank_pair_id": "rank-0000", "domain": domain, "semantic_layer": layer,
                "thread_pair_id": lane, "alignment_column": column,
                "real_event_ids": f'["{lane}-r{column}"]', "sim_event_ids": f'["{lane}-s{column}"]',
                "real_operator": real_op if first else f"common::{column}",
                "sim_operator": sim_op if first else f"common::{column}",
                "real_run_calls": 1, "sim_run_calls": 1,
                "relation": "substitute" if first else "exact",
                "first_divergence": "是" if first else "否",
            })
    _write_fixture_csv(alignment / "event_alignment.csv", align_rows, align_fields)
    divergence_rows = []
    for lane, domain, layer, real_op, sim_op, suffix in (
        ("lane-fw", "host", "framework_op", "aten::copy_", "aten::empty", "fw"),
        ("lane-launch", "host", "host_launch", "aclnnForeachCopy", "aclrtMemcpy", "launch"),
        ("lane-device", "device", "device_task", "ForeachCopy", "Memcpy", "device"),
    ):
        run_real = {"operator": real_op, "calls": 1, "event_ids": [f"{lane}-r2"], "input_shapes": "[2,2]"}
        run_sim = {"operator": sim_op, "calls": 1, "event_ids": [f"{lane}-s2"], "input_shapes": "[2,2]"}
        divergence_rows.append({
            "divergence_id": f"div-{suffix}", "rank_pair_id": "rank-0000", "domain": domain,
            "semantic_layer": layer, "thread_pair_id": lane, "lane_match_status": "matched",
            "lane_match_confidence": "high", "anchors_before": 3, "anchors_after": 3,
            "anchor_gate_passed": True, "nesting_gate_passed": True,
            "last_common_anchor": json.dumps({"real": {"operator": "common::1", "calls": 1}, "sim": {"operator": "common::1", "calls": 1}}, ensure_ascii=False),
            "first_real_event": json.dumps(run_real, ensure_ascii=False),
            "first_sim_event": json.dumps(run_sim, ensure_ascii=False),
            "next_common_anchor": json.dumps({"real": {"operator": "common::3", "calls": 1}, "sim": {"operator": "common::3", "calls": 1}}, ensure_ascii=False),
            "real_operators": [real_op], "sim_operators": [sim_op], "real_run_calls": [1],
            "sim_run_calls": [1], "real_shapes": [["[2,2]", ""]], "sim_shapes": [["[2,2]", ""]],
            "alignment_boundaries": {"op": [2, 2], "metadata": [2, 2], "tree": [2, 2]},
            "boundary_stability": "stable", "repeated_anchor_ambiguous": False,
            "earlier_unresolved": "否", "alternative_explanations": ["backend lowering 差异"],
        })
    (alignment / "divergence_windows.jsonl").write_text(
        "".join(json.dumps(row, ensure_ascii=False, sort_keys=True) + "\n" for row in divergence_rows),
        encoding="utf-8",
    )
    _write_fixture_csv(
        alignment / "host_device_links.csv",
        [{
            "environment": "real/reference/真机", "rank": 0, "host_event_id": "lane-fw-r2",
            "device_event_id": "lane-device-r2", "host_lane_id": "real-fw", "device_lane_id": "stream-7",
            "host_semantic_layer": "framework_op", "device_semantic_layer": "device_task",
            "correlation_type": "chrome-flow", "correlation_namespace": "HostToDevice",
            "correlation_id_hash": "flowhash", "link_status": "direct-flow", "endpoint_match": "unique",
            "causal_eligible": "是", "evidence_ids": '["lane-fw-r2","lane-device-r2"]',
        }],
        ["environment", "rank", "host_event_id", "device_event_id", "host_lane_id", "device_lane_id", "host_semantic_layer", "device_semantic_layer", "correlation_type", "correlation_namespace", "correlation_id_hash", "link_status", "endpoint_match", "causal_eligible", "evidence_ids"],
    )
    _write_fixture_csv(
        alignment / "operator_details_rank_coverage.csv",
        [{"environment": "real/reference/真机", "rank": 0, "coverage_scope": "rank-only", "source": "operator_details.csv", "source_row": 1, "raw_name": "aten::copy_", "canonical_op": "aten::copy_", "input_shapes": "[2,2]", "output_shapes": "[2,2]", "call_stack": "model.py:4"}],
        ["environment", "rank", "coverage_scope", "source", "source_row", "raw_name", "canonical_op", "input_shapes", "output_shapes", "call_stack"],
    )
    _write_fixture_csv(
        alignment / "parser_warnings.csv", [], ["environment", "rank", "source", "warning"]
    )
    # A sentinel row lets tests prove the builder does not copy the full canonical event table.
    _write_fixture_csv(
        alignment / "canonical_events.csv",
        [{
            "environment": "real/reference/真机", "rank": 0, "domain": "host",
            "semantic_layer": "framework_op", "lane_id": "real-fw",
            "event_id": "canonical-sentinel-not-for-report", "canonical_op": "aten::sentinel",
            "timestamps_exposed": "否",
        }],
        ["environment", "rank", "domain", "semantic_layer", "lane_id", "event_id", "canonical_op", "timestamps_exposed"],
    )
    (alignment / "structural_heatmap.html").write_text("fixture", encoding="utf-8")
    manifest_path = alignment / "analysis_manifest.json"
    manifest_payload = json.loads(manifest_path.read_text(encoding="utf-8"))
    manifest_artifacts = [
        "rank_pairs.csv", "unpaired_ranks.csv", "thread_pairs.csv",
        "canonical_events.csv", "event_alignment.csv", "divergence_windows.jsonl",
        "host_device_links.csv",
    ]
    manifest_payload["artifacts"] = manifest_artifacts
    manifest_payload["artifact_integrity"] = {}
    for artifact_name in manifest_artifacts:
        artifact_raw = (alignment / artifact_name).read_bytes()
        manifest_payload["artifact_integrity"][artifact_name] = {
            "sha256": _sha256_bytes(artifact_raw),
            "bytes": len(artifact_raw),
            "nonempty": bool(artifact_raw),
        }
    manifest_path.write_text(
        json.dumps(manifest_payload, ensure_ascii=False), encoding="utf-8"
    )

    preflight = report_root / "evidence" / "preflight"
    preflight.mkdir()
    (preflight / "collection_contract.json").write_text(
        json.dumps({
            "schema_version": 1, "status": "complete",
            "real": {"root": "real", "status": "complete", "contracts": [{"profile_format": "torchnpu_integrated_text", "rank_conflict": False}]},
            "sim": {"root": "sim", "status": "complete", "contracts": [{"profile_format": "torchnpu_integrated_text", "rank_conflict": False}]},
        }, ensure_ascii=False), encoding="utf-8"
    )
    _write_fixture_csv(preflight / "collection_contract.csv", [], ["environment", "status"])

    repo = root / "MindSpeed"
    repo.mkdir()
    (repo / "model.py").write_text(
        "def forward(flag, x):\n"
        "    use_new_path = flag\n"
        "    if use_new_path:\n"
        "        return copy_(x)\n"
        "    else:\n"
        "        return empty(x)\n",
        encoding="utf-8",
    )

    def fixture_git(*arguments: str) -> str:
        completed = subprocess.run(
            ["git", "-c", "core.hooksPath=NUL", "-c", "commit.gpgsign=false", *arguments],
            cwd=repo, check=True, capture_output=True, text=True,
            env={
                **os.environ,
                "GIT_CONFIG_NOSYSTEM": "1",
                "GIT_TERMINAL_PROMPT": "0",
                "GIT_AUTHOR_NAME": "fixture",
                "GIT_AUTHOR_EMAIL": "fixture@example.invalid",
                "GIT_COMMITTER_NAME": "fixture",
                "GIT_COMMITTER_EMAIL": "fixture@example.invalid",
            },
        )
        return completed.stdout.strip()

    fixture_git("init", "--quiet")
    fixture_git("add", "--", "model.py")
    fixture_git("commit", "--quiet", "-m", "fixture")
    fixture_commit = fixture_git("rev-parse", "HEAD")
    fixture_tree = fixture_git("rev-parse", "HEAD^{tree}")
    fixture_repository = "https://example.invalid/mindspeed"

    contract = alignment / "run_comparability_contract.json"
    fact = lambda value: {"value": value, "status": "verified", "evidence": "fixture"}
    source_fact = {
        "component": "model", "repository": fixture_repository,
        "commit": fixture_commit, "tree_hash": fixture_tree, "build_id": "fixture",
        "status": "verified", "evidence": "fixture",
    }
    contract.write_text(json.dumps({
        "source_roots": {
            "model": {"path": str(repo.resolve()), "role": "model-entry", "binding_side": "shared", "status": "verified", "evidence": "fixture"},
            "pytorch": {"path": "C:/fixture/torch", "role": "reference-baseline", "binding_side": "real/reference", "status": "verified", "evidence": "fixture"},
            "torch_npu": {"path": "C:/fixture/torch_npu", "role": "reference-baseline", "binding_side": "real/reference", "status": "verified", "evidence": "fixture"},
        },
        "real": {"model_code": fact("Qwen"), "analyzed_source": source_fact, "workload": fact("train"), "phase": fact("forward"), "profiler_schedule": fact("active=1"), "torch_npu_version": fact("2.7.1.post7"), "cann_version": fact("9.1.0"), "pytorch_version": fact("ignored-real-version")},
        "sim": {"model_code": fact("Qwen"), "analyzed_source": source_fact, "workload": fact("train"), "phase": fact("forward"), "profiler_schedule": fact("active=1"), "torch_npu_version": fact("2.7.1.dev"), "cann_version": fact("9.1.0"), "pytorch_version": fact("ignored-sim-version")},
        "comparisons": {"analyzed_source": "equal", "model_code": "equal"},
    }, ensure_ascii=False), encoding="utf-8")
    contract_sha256 = hashlib.sha256(contract.read_bytes()).hexdigest()

    source_root = report_root / "evidence" / "source-causality"
    snapshot_root = report_root / "evidence" / "python-guard-snapshots"
    for owner, evidence_id, guard_path, predicate in (
        ("MindSpeed", "evidence-ms", "model.py", "use_new_path"),
    ):
        source_dir = source_root
        source_dir.mkdir(parents=True)
        candidate = {
            "evidence_id": evidence_id, "candidate_rank": 1, "divergence_id": "div-fw",
            "rank_pair_id": "rank-0000", "thread_pair_id": "lane-fw", "semantic_layer": "framework_op",
            "guard_id": f"guard-{owner}", "guard_path": guard_path, "guard_symbol": "forward",
            "guard_lines": "3-6", "guard_kind": "if", "predicate_text": predicate,
            "predicate_ast_hash": hashlib.sha256(predicate.encode("utf-8")).hexdigest(),
            "real_arm": "if-body",
            "real_arm_lines": "[4,4]", "sim_arm": "else", "sim_arm_lines": "[6,6]",
            "real_operators": '["aten::copy_"]', "sim_operators": '["aten::empty"]',
            "boundary_stability": "stable", "lane_match_status": "matched", "lane_match_confidence": "high",
            "anchors_before": 3, "anchors_after": 3, "repeated_anchor_ambiguous": "否",
            "lane_high_confidence": "是", "anchor_gate_passed": "是",
            "nesting_gate_passed": "是", "stack_binding_level": 1,
            "real_stack_binding_level": 1, "sim_stack_binding_level": 1,
            "entrypoint_binding_level": 1,
            "branch_fingerprint": json.dumps({
                "real_operators": ["aten::copy_"], "sim_operators": ["aten::empty"],
                "coverage": 1.0, "precision": 1.0, "contradictions": [],
            }, ensure_ascii=False, separators=(",", ":")),
            "runtime_binding": "verified", "predicate_real_result": "true", "predicate_sim_result": "false",
            "predicate_results_opposite": "是", "direct_operand_values_observed": "是",
            "real_operand_values": '["1"]', "sim_operand_values": '["0"]',
            "analyzed_source_gate_passed": "是", "dependency_source_gate_passed": "是",
            "source_component": "model", "run_contract_sha256": contract_sha256,
            "indexed_head_commit": fixture_commit, "indexed_tree_hash": fixture_tree,
            "source_scan_complete": "是", "strength": "强关联控制流分叉",
            "repository": fixture_repository, "commit": fixture_commit,
            "minimal_missing_evidence": '["语义 oracle"]',
        }
        _write_fixture_csv(source_dir / "control_flow_guard_candidates.csv", [candidate], list(candidate))
        (source_dir / "control_flow_evidence.jsonl").write_text(json.dumps({"evidence_id": evidence_id}, ensure_ascii=False) + "\n", encoding="utf-8")
        _write_fixture_csv(source_dir / "predicate_tensor_evidence.csv", [{"evidence_id": evidence_id, "guard_id": f"guard-{owner}", "operand_expr": predicate, "operand_kind": "name", "producer_path": guard_path, "producer_line_start": 2, "producer_expression": f"{predicate} = flag", "producer_status": "static", "runtime_value_status": "direct"}], ["evidence_id", "guard_id", "operand_expr", "operand_kind", "producer_path", "producer_line_start", "producer_expression", "producer_status", "runtime_value_status"])
        _write_fixture_csv(source_dir / "event_source_map.csv", [{"evidence_id": evidence_id, "environment": "real", "rank_pair_id": "rank-0000", "thread_pair_id": "lane-fw", "operator": "aten::copy_", "source_call": "copy_", "path": guard_path, "line_start": 4, "line_end": 4, "symbol": "forward", "confidence": "高"}], ["evidence_id", "environment", "rank_pair_id", "thread_pair_id", "operator", "source_call", "path", "line_start", "line_end", "symbol", "confidence"])
        _write_fixture_csv(source_dir / "branch_device_evidence.csv", [{"divergence_id": "div-fw", "rank_pair_id": "rank-0000", "thread_pair_id": "lane-fw", "environment": "real", "host_event_id": "lane-fw-r2", "device_event_id": "lane-device-r2", "device_operator": "ForeachCopy", "device_stream_id": 7, "device_task_id": 1, "device_task_type": "AI_CORE", "link_status": "direct-flow", "link_namespace": "HostToDevice", "endpoint_match": "unique", "causal_eligible": "是", "link_evidence_ids": '["lane-fw-r2"]'}], ["divergence_id", "rank_pair_id", "thread_pair_id", "environment", "host_event_id", "device_event_id", "device_operator", "device_stream_id", "device_task_id", "device_task_type", "link_status", "link_namespace", "endpoint_match", "causal_eligible", "link_evidence_ids"])
        _write_fixture_csv(source_dir / "source_evidence.csv", [], ["evidence_id", "path"])
        _write_fixture_csv(source_dir / "source_entrypoint_chain.csv", [{"chain_kind": "shell-launch-edge", "source": "train.sh", "target": "pretrain.py", "status": "resolved", "evidence": "static"}], ["chain_kind", "source", "target", "status", "evidence"])
        _write_fixture_csv(source_dir / "source_analysis_issues.csv", [], ["path", "issue", "detail", "impact"])
        source_artifacts = [
            "control_flow_guard_candidates.csv", "control_flow_evidence.jsonl",
            "predicate_tensor_evidence.csv", "event_source_map.csv",
            "branch_device_evidence.csv", "source_evidence.csv",
            "source_entrypoint_chain.csv", "source_analysis_issues.csv",
        ]
        source_integrity = {}
        for artifact_name in source_artifacts:
            raw = (source_dir / artifact_name).read_bytes()
            source_integrity[artifact_name] = {
                "sha256": hashlib.sha256(raw).hexdigest(),
                "bytes": len(raw), "nonempty": bool(raw),
            }
        (source_dir / "source_analysis_manifest.json").write_text(
            json.dumps({
                "schema_version": 4, "algorithm_version": "fixture-source",
                "status": "complete", "promotion_status": "eligible",
                "source_component": "model", "repo_root": str(repo.resolve()),
                "repository": fixture_repository, "resolved_commit": fixture_commit,
                "indexed_source_snapshot": {
                    "binding_status": "verified", "is_git_repository": True,
                    "worktree_dirty": "no", "head_commit": fixture_commit,
                    "resolved_commit": fixture_commit, "tree_hash": fixture_tree,
                    "remote": fixture_repository,
                },
                "source_scan": {"truncated": False},
                "run_comparability": {
                    "sha256": contract_sha256,
                    "status": "complete", "analyzed_source_gate_passed": True,
                    "fields": {
                        "analyzed_source": {
                            "real": source_fact, "sim": source_fact,
                            "comparison": "verified-equal",
                        }
                    },
                },
                "artifacts": source_artifacts, "artifact_integrity": source_integrity,
            }, ensure_ascii=False),
            encoding="utf-8",
        )

        snapshot_module_name = "_profiling_alignment_snapshot_renderer_fixture"
        snapshot_script = Path(__file__).with_name("render_python_guard_snapshots.py")
        snapshot_spec = importlib.util.spec_from_file_location(snapshot_module_name, snapshot_script)
        if snapshot_spec is None or snapshot_spec.loader is None:
            raise AssertionError("cannot load snapshot renderer fixture")
        snapshot_module = importlib.util.module_from_spec(snapshot_spec)
        sys.modules[snapshot_module_name] = snapshot_module
        try:
            snapshot_spec.loader.exec_module(snapshot_module)
            snapshot_module.render_python_guard_snapshots(
                repo, source_dir, snapshot_root, context_lines=1
            )
        finally:
            sys.modules.pop(snapshot_module_name, None)

    perfetto = report_root / "evidence" / "perfetto-review"
    perfetto.mkdir()
    jobs = [{"rank_pair_id": "rank-0000", "environment": side, "planned_status": "ready", "run_status": "not-executed", "content_review_status": "not-executed", "expected_trace_sha256": ("a" if side == "real" else "b") * 64, "batch_lane_keys_json": '["lane-fw"]', "output_dir": ""} for side in ("real", "sim")]
    (perfetto / "perfetto_batch_manifest.json").write_text(json.dumps({"schema_version": 2, "status": "partial", "execution_block_reason": "data policy did not authorize online Perfetto", "jobs": jobs}, ensure_ascii=False), encoding="utf-8")
    _write_fixture_csv(perfetto / "perfetto_batch_manifest.csv", jobs, list(jobs[0]))
    (perfetto / "perfetto_content_review.json").write_text(json.dumps({"schema_version": 1, "status": "not-executed", "reason": "data policy did not authorize online Perfetto", "reviewed_artifacts": [], "reviewed_jobs": [{"rank_pair_id": "rank-0000", "environment": side, "status": "not-executed"} for side in ("real", "sim")], "canvas_review": "not-executed"}, ensure_ascii=False), encoding="utf-8")
    return {
        "alignment": alignment,
        "output": report_root / REPORT_NAME,
        "preflight": preflight,
        "contract": contract,
        "source": source_root,
        "snapshots": snapshot_root,
        "perfetto": perfetto,
    }


def _assert_formal_validator_passes(paths: dict[str, Path]) -> None:
    """Run the sibling public validator against a source-neutral fixture report."""
    validator_path = Path(__file__).with_name("validate_alignment_report.py")
    if not validator_path.is_file():
        raise AssertionError(f"formal validator is missing: {validator_path}")
    module_name = "_profiling_alignment_report_validator_selftest"
    spec = importlib.util.spec_from_file_location(module_name, validator_path)
    if spec is None or spec.loader is None:
        raise AssertionError(f"cannot load formal validator: {validator_path}")
    module = importlib.util.module_from_spec(spec)
    sys.modules[module_name] = module
    try:
        spec.loader.exec_module(module)
        payload = module.validate(
            paths["output"], paths["alignment"], None, paths["contract"],
            None, paths["perfetto"],
        )
    finally:
        sys.modules.pop(module_name, None)
    if payload.get("status") != "pass":
        failures = [
            f"{item.get('code')}: {item.get('message')}"
            for item in payload.get("findings", [])
            if item.get("severity") == "error"
        ]
        raise AssertionError(
            "formal validator rejected builder self-test report:\n" + "\n".join(failures)
        )


def run_self_test() -> int:
    with tempfile.TemporaryDirectory(prefix="profiling-report-builder-selftest-") as directory:
        paths = _write_self_test_fixture(Path(directory))
        result = build_report(
            paths["alignment"], paths["output"],
            preflight_dir=paths["preflight"], run_contract=paths["contract"],
            source_causality_dir=paths["source"], python_snapshots_dir=paths["snapshots"],
            perfetto_review_dir=paths["perfetto"],
        )
        first = paths["output"].read_bytes()
        result_again = build_report(
            paths["alignment"], paths["output"],
            preflight_dir=paths["preflight"], run_contract=paths["contract"],
            source_causality_dir=paths["source"], python_snapshots_dir=paths["snapshots"],
            perfetto_review_dir=paths["perfetto"],
        )
        second = paths["output"].read_bytes()
        text = second.decode("utf-8")
        assert first == second
        assert result["artifact_count"] == result_again["artifact_count"] == 1
        assert all(token in text for token in (
            "## 2. Rank 与 Thread 覆盖", "### 2.2 全量 lane 清单",
            "## 3. Host 算子序列与首次分叉", "## 4. Device 序列与 Host→Device",
            "## 5. 控制流与代码证据", "## 6. Predicate tensor 与 producer",
            "## 7. Perfetto 内容复核", "## 8. 结论强度与替代解释",
            "## 9. 最小验证动作", "## 10. 附录与证据可追溯性",
            "real-fw", "stream-7", "divergence_id=div-fw",
            "alignment_column", "HostToDevice", "guard-MindSpeed",
            "<details open>", "### 10.1 Rank 级 operator_details 覆盖",
        ))
        assert "duration" not in text.casefold()
        assert "ignored-real-version" not in text and "ignored-sim-version" not in text
        try:
            build_report(paths["alignment"], paths["alignment"] / "wrong.md")
        except ReportBuildError:
            pass
        else:
            raise AssertionError("unsafe output filename was accepted")
        # Validate a second, source-neutral build to lock the report's
        # rank/lane/divergence, Perfetto, section, thickness, and no-duration
        # contracts to the formal validator's public API.
        build_report(
            paths["alignment"], paths["output"],
            preflight_dir=paths["preflight"], run_contract=paths["contract"],
            perfetto_review_dir=paths["perfetto"],
        )
        _assert_formal_validator_passes(paths)
    print("self-test: ok")
    return 0


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--alignment-output", type=Path, help="align_profiles.py evidence directory")
    parser.add_argument("--output", type=Path, help=f"exact output path named {REPORT_NAME}")
    parser.add_argument("--preflight-dir", type=Path, help="optional preflight evidence directory")
    parser.add_argument("--run-contract", type=Path, help="optional run_comparability_contract.json")
    parser.add_argument(
        "--source-causality-dir", type=Path,
        help="optional flat source-causality directory for the single promoted owner",
    )
    parser.add_argument(
        "--python-snapshots-dir", type=Path,
        help="optional flat Python snapshot bundle for the same single promoted owner",
    )
    parser.add_argument("--perfetto-review-dir", type=Path, help="optional Perfetto batch/content review directory")
    parser.add_argument("--self-test", action="store_true", help="run a deterministic synthetic fixture")
    return parser


def main(argv: Sequence[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    if args.self_test:
        return run_self_test()
    if args.alignment_output is None or args.output is None:
        print("build failed: --alignment-output and --output are required", file=os.sys.stderr)
        return 2
    try:
        result = build_report(
            args.alignment_output,
            args.output,
            preflight_dir=args.preflight_dir,
            run_contract=args.run_contract,
            source_causality_dir=args.source_causality_dir,
            python_snapshots_dir=args.python_snapshots_dir,
            perfetto_review_dir=args.perfetto_review_dir,
        )
    except (OSError, ReportBuildError, json.JSONDecodeError, csv.Error) as error:
        print(f"build failed: {error}", file=os.sys.stderr)
        return 2
    print(json.dumps(result, ensure_ascii=False, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

#!/usr/bin/env python3
"""Offline runtime preflight for profiling-alignment-analysis.

The doctor performs only local version, path, permission, and free-space checks.  It
never downloads or installs dependencies and never contacts Perfetto.  Its sole
intentional write is the fixed JSON artifact under the configured output root.
"""

from __future__ import annotations

import argparse
import json
import os
import shutil
import subprocess
import sys
import tempfile
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Mapping, Sequence


REPORT_RELATIVE_PATH = Path("evidence") / "runtime" / "runtime_doctor.json"
PLAYWRIGHT_PACKAGES = ("playwright-core", "playwright")
MINIMUM_PYTHON = (3, 10)


@dataclass(frozen=True)
class DoctorConfig:
    output_root: Path | None
    node: str
    git: str
    playwright_node_modules: str
    browser: str
    min_free_bytes: int
    spec_path: Path | None = None
    perfetto_online_authorized: bool | None = None


def _mapping(value: Any) -> Mapping[str, Any]:
    return value if isinstance(value, Mapping) else {}


def _nonempty(*values: Any, default: str = "") -> str:
    for value in values:
        if isinstance(value, str) and value.strip():
            return value.strip()
    return default


def _load_spec(path: Path | None) -> dict[str, Any]:
    if path is None:
        return {}
    with path.open("r", encoding="utf-8-sig") as handle:
        value = json.load(handle)
    if not isinstance(value, dict):
        raise ValueError("--spec must contain a JSON object")
    return value


def _output_root_from_spec(spec: Mapping[str, Any], spec_path: Path | None) -> Path | None:
    raw = spec.get("output_root")
    if not isinstance(raw, str) or not raw.strip():
        return None
    path = Path(raw).expanduser()
    if path.is_absolute():
        return path
    work_root_raw = spec.get("work_root")
    if isinstance(work_root_raw, str) and work_root_raw.strip():
        work_root = Path(work_root_raw).expanduser()
        if not work_root.is_absolute() and spec_path is not None:
            work_root = spec_path.parent / work_root
        return work_root / path
    return (spec_path.parent if spec_path is not None else Path.cwd()) / path


def config_from_args(args: argparse.Namespace) -> DoctorConfig:
    spec_path = args.spec.expanduser().resolve() if args.spec else None
    spec = _load_spec(spec_path)
    perfetto = _mapping(spec.get("perfetto"))
    output_root = args.output_root
    if output_root is None:
        output_root = _output_root_from_spec(spec, spec_path)
    if output_root is not None:
        output_root = output_root.expanduser().resolve(strict=False)
    min_free_gib = args.min_free_gib
    authorization_value = perfetto.get("online_authorized")
    if authorization_value is None:
        authorization_value = spec.get("perfetto_online_authorized")
    perfetto_online_authorized = (
        authorization_value if isinstance(authorization_value, bool) else None
    )
    return DoctorConfig(
        output_root=output_root,
        node=_nonempty(args.node, perfetto.get("node"), default="node"),
        git=_nonempty(args.git, spec.get("git"), default="git"),
        playwright_node_modules=_nonempty(
            args.playwright_node_modules,
            perfetto.get("playwright_node_modules"),
        ),
        browser=_nonempty(args.browser, perfetto.get("browser")),
        min_free_bytes=max(0, int(min_free_gib * 1024**3)),
        spec_path=spec_path,
        perfetto_online_authorized=perfetto_online_authorized,
    )


def _resolve_program(requested: str) -> str | None:
    candidate = Path(requested).expanduser()
    current = Path.cwd().resolve(strict=False)
    if candidate.is_absolute():
        resolved = candidate.resolve(strict=False)
        try:
            resolved.relative_to(current)
            return None
        except ValueError:
            return str(resolved) if resolved.is_file() else None
    # A path containing a directory is only accepted when it is explicit and
    # absolute. In particular, never execute ``./git``, ``tools/node``, or a
    # work-root wrapper while claiming repository code was not executed.
    if candidate.parent != Path("."):
        return None

    path_entries = os.environ.get("PATH", "").split(os.pathsep)
    names: list[str]
    if os.name == "nt" and not candidate.suffix:
        extensions = [
            extension
            for extension in os.environ.get("PATHEXT", ".COM;.EXE;.BAT;.CMD").split(";")
            if extension
        ]
        names = [requested + extension.lower() for extension in extensions]
    else:
        names = [requested]
    for raw_entry in path_entries:
        expanded = os.path.expandvars(raw_entry.strip().strip('"'))
        if not expanded:
            continue
        directory = Path(expanded).expanduser()
        if not directory.is_absolute():
            continue
        try:
            resolved_directory = directory.resolve(strict=True)
        except OSError:
            continue
        try:
            resolved_directory.relative_to(current)
            # Bare-name discovery must never trust the user workload tree. A
            # deliberate tool inside it can still be used via an explicit
            # absolute run-spec path, which remains auditable.
            continue
        except ValueError:
            pass
        for name in names:
            executable = resolved_directory / name
            if not executable.is_file():
                continue
            if os.name != "nt" and not os.access(executable, os.X_OK):
                continue
            return str(executable.resolve())
    return None


def check_command(name: str, requested: str) -> dict[str, Any]:
    resolved = _resolve_program(requested)
    result: dict[str, Any] = {
        "status": "blocked",
        "requested": requested,
        "resolved": resolved,
        "probe": ["--version"],
    }
    if not resolved:
        result["reason"] = f"{name} executable was not found"
        return result
    try:
        probe_environment = os.environ.copy()
        for variable in list(probe_environment):
            if variable.upper().startswith("NODE_"):
                probe_environment.pop(variable, None)
        completed = subprocess.run(
            [resolved, "--version"],
            capture_output=True,
            text=True,
            timeout=5,
            check=False,
            env=probe_environment,
        )
    except (OSError, subprocess.SubprocessError) as error:
        result["reason"] = f"{type(error).__name__}: {error}"
        return result
    output = (completed.stdout or completed.stderr).strip().splitlines()
    result.update(
        {
            "return_code": completed.returncode,
            "version_output": output[0] if output else "",
        }
    )
    if completed.returncode == 0:
        result["status"] = "pass"
    else:
        result["reason"] = f"{name} --version returned {completed.returncode}"
    return result


def check_python() -> dict[str, Any]:
    detected = tuple(sys.version_info[:3])
    passed = detected >= MINIMUM_PYTHON
    return {
        "status": "pass" if passed else "blocked",
        "required": ">=3.10",
        "detected": ".".join(map(str, detected)),
        "executable": str(Path(sys.executable).resolve()),
        **({} if passed else {"reason": "Python 3.10 or newer is required"}),
    }


def check_playwright_node_modules(raw_path: str) -> dict[str, Any]:
    result: dict[str, Any] = {
        "status": "blocked",
        "requested": raw_path,
        "source": "explicit-argument-or-run-spec",
        "packages": [],
    }
    if not raw_path:
        result["reason"] = "an explicit playwright_node_modules path is required"
        return result
    path = Path(raw_path).expanduser()
    if not path.is_absolute():
        result["reason"] = "playwright_node_modules must be an absolute path"
        return result
    try:
        resolved = path.resolve(strict=True)
    except OSError as error:
        result["reason"] = f"playwright_node_modules cannot be resolved: {error}"
        return result
    result["resolved"] = str(resolved)
    if not resolved.is_dir():
        result["reason"] = "playwright_node_modules is not a directory"
        return result
    packages: list[dict[str, Any]] = []
    for package_name in PLAYWRIGHT_PACKAGES:
        package_json = resolved / package_name / "package.json"
        if not package_json.is_file():
            continue
        record: dict[str, Any] = {
            "name": package_name,
            "package_json": str(package_json),
        }
        try:
            metadata = json.loads(package_json.read_text(encoding="utf-8-sig"))
            record["version"] = metadata.get("version") if isinstance(metadata, dict) else None
            record["valid_package_json"] = isinstance(metadata, dict)
        except (OSError, json.JSONDecodeError) as error:
            record["valid_package_json"] = False
            record["error"] = f"{type(error).__name__}: {error}"
        packages.append(record)
    result["packages"] = packages
    if any(package.get("valid_package_json") for package in packages):
        result["status"] = "pass"
        result["validation_scope"] = (
            "local package metadata; the renderer validates the chromium export at execution time"
        )
    else:
        result["reason"] = "neither playwright-core nor playwright has a valid package.json"
    return result


def check_browser(raw_path: str) -> dict[str, Any]:
    result: dict[str, Any] = {
        "status": "blocked",
        "requested": raw_path,
        "source": "explicit-argument-or-run-spec",
    }
    if not raw_path:
        result["reason"] = "an explicit browser executable path is required"
        return result
    path = Path(raw_path).expanduser()
    if not path.is_absolute():
        result["reason"] = "browser must be an absolute path"
        return result
    try:
        resolved = path.resolve(strict=True)
    except OSError as error:
        result["reason"] = f"browser cannot be resolved: {error}"
        return result
    result["resolved"] = str(resolved)
    result["is_file"] = resolved.is_file()
    result["executable"] = os.access(resolved, os.X_OK)
    if resolved.is_file() and (os.name == "nt" or result["executable"]):
        result["status"] = "pass"
    else:
        result["reason"] = "browser path is not an executable file"
    return result


def _nearest_existing_directory(path: Path) -> Path | None:
    current = path
    while True:
        if current.exists():
            return current if current.is_dir() else None
        if current.parent == current:
            return None
        current = current.parent


def check_output(output_root: Path | None, min_free_bytes: int) -> dict[str, Any]:
    result: dict[str, Any] = {
        "status": "blocked",
        "requested": str(output_root) if output_root else "",
        "minimum_free_bytes": min_free_bytes,
        "write_probe": "permission-only; no probe file is created",
    }
    if output_root is None:
        result["reason"] = "output_root is required"
        return result
    resolved = output_root.resolve(strict=False)
    result["resolved"] = str(resolved)
    if resolved.exists() and not resolved.is_dir():
        result["reason"] = "output_root exists but is not a directory"
        return result
    basis = resolved if resolved.is_dir() else _nearest_existing_directory(resolved)
    if basis is None:
        result["reason"] = "no existing output ancestor is available"
        return result
    writable = os.access(basis, os.W_OK)
    try:
        usage = shutil.disk_usage(basis)
    except OSError as error:
        result["reason"] = f"disk usage check failed: {error}"
        return result
    result.update(
        {
            "permission_basis": str(basis.resolve()),
            "permission_inferred_for_missing_output": not resolved.exists(),
            "writable": writable,
            "disk_total_bytes": usage.total,
            "disk_used_bytes": usage.used,
            "disk_free_bytes": usage.free,
            "enough_free_space": usage.free >= min_free_bytes,
            "report_path": str((resolved / REPORT_RELATIVE_PATH).resolve(strict=False)),
        }
    )
    if writable and usage.free >= min_free_bytes:
        result["status"] = "pass"
    elif not writable:
        result["reason"] = "output_root or its nearest existing ancestor is not writable"
    else:
        result["reason"] = "available disk space is below the configured minimum"
    return result


def collect_report(config: DoctorConfig) -> dict[str, Any]:
    checks = {
        "python": check_python(),
        "git": check_command("Git", config.git),
        "node": check_command("Node.js", config.node),
        "playwright_node_modules": check_playwright_node_modules(
            config.playwright_node_modules
        ),
        "browser": check_browser(config.browser),
        "output": check_output(config.output_root, config.min_free_bytes),
    }
    perfetto_only_checks = {"node", "playwright_node_modules", "browser"}
    for name, value in checks.items():
        value["required"] = not (
            config.perfetto_online_authorized is False and name in perfetto_only_checks
        )
    blocking = [
        name
        for name, value in checks.items()
        if value.get("required") and value.get("status") != "pass"
    ]
    optional_unavailable = [
        name
        for name, value in checks.items()
        if not value.get("required") and value.get("status") != "pass"
    ]
    report_path = (
        config.output_root / REPORT_RELATIVE_PATH if config.output_root is not None else None
    )
    return {
        "schema_version": 1,
        "status": "ready" if not blocking else "blocked",
        "offline": True,
        "network_access_performed": False,
        "install_performed": False,
        "perfetto_online_authorized": config.perfetto_online_authorized,
        "side_effect_policy": "only runtime_doctor.json is written under output_root",
        "spec_path": str(config.spec_path) if config.spec_path else None,
        "report_path": str(report_path.resolve(strict=False)) if report_path else None,
        "checks": checks,
        "blocking_checks": blocking,
        "optional_unavailable_checks": optional_unavailable,
    }


def write_report(report: Mapping[str, Any], output_root: Path | None) -> Path | None:
    if output_root is None:
        return None
    target = (output_root / REPORT_RELATIVE_PATH).resolve(strict=False)
    target.parent.mkdir(parents=True, exist_ok=True)
    payload = json.dumps(report, ensure_ascii=False, indent=2) + "\n"
    temporary_name: str | None = None
    try:
        with tempfile.NamedTemporaryFile(
            "w", encoding="utf-8", newline="\n", dir=target.parent,
            prefix=f".{target.name}.", suffix=".tmp", delete=False,
        ) as handle:
            temporary_name = handle.name
            handle.write(payload)
        os.replace(temporary_name, target)
        temporary_name = None
    finally:
        if temporary_name:
            try:
                Path(temporary_name).unlink()
            except OSError:
                pass
    return target


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--spec", type=Path, help="optional profiling alignment run-spec JSON")
    parser.add_argument("--output-root", type=Path)
    parser.add_argument("--node", default=None)
    parser.add_argument("--git", default=None)
    parser.add_argument("--playwright-node-modules", default=None)
    parser.add_argument("--browser", default=None)
    parser.add_argument("--min-free-gib", type=float, default=1.0)
    return parser


def main(argv: Sequence[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    if args.min_free_gib < 0:
        raise SystemExit("--min-free-gib must be non-negative")
    try:
        config = config_from_args(args)
        report = collect_report(config)
    except (OSError, ValueError, json.JSONDecodeError) as error:
        report = {
            "schema_version": 1,
            "status": "blocked",
            "offline": True,
            "network_access_performed": False,
            "install_performed": False,
            "blocking_checks": ["configuration"],
            "configuration_error": f"{type(error).__name__}: {error}",
        }
        config = DoctorConfig(None, "node", "git", "", "", 0)
    if report.get("checks", {}).get("output", {}).get("status") == "pass":
        try:
            write_report(report, config.output_root)
        except OSError as error:
            report["status"] = "blocked"
            report.setdefault("blocking_checks", []).append("report_write")
            report["report_write_error"] = f"{type(error).__name__}: {error}"
    print(json.dumps(report, ensure_ascii=False, indent=2))
    return 0 if report.get("status") == "ready" else 1


if __name__ == "__main__":
    raise SystemExit(main())

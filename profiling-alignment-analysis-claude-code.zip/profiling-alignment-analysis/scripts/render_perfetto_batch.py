#!/usr/bin/env python3
"""Load every paired-rank trace into Perfetto UI and record auditable batch status.

Only an explicit --online-authorized flag permits the Node renderer to obtain official UI
code online. It then switches the browser context offline before posting local trace bytes
into UI memory. This wrapper is sequential by default to bound memory. It never creates a
Share link and does not treat screenshots as a content-review requirement. Perfetto is an
auxiliary Host framework/launch cross-check; Device evidence remains local-parser-only.
"""

from __future__ import annotations

import argparse
import csv
import hashlib
import json
import os
import subprocess
import sys
import tempfile
import time
from datetime import datetime, timezone
from pathlib import Path
from typing import Any
from uuid import UUID


PLAYWRIGHT_NODE_MODULES_ENV = "PERFETTO_PLAYWRIGHT_NODE_MODULES"
PLAYWRIGHT_PACKAGES = ("playwright-core", "playwright")


def read_csv(path: Path) -> list[dict[str, str]]:
    with path.open("r", newline="", encoding="utf-8-sig", errors="replace") as handle:
        return list(csv.DictReader(handle))


def write_csv(path: Path, rows: list[dict[str, Any]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    fields: list[str] = []
    seen = set()
    for row in rows:
        for key in row:
            if key not in seen:
                seen.add(key)
                fields.append(key)
    if not fields:
        fields = ["message"]
    with path.open("w", newline="", encoding="utf-8-sig") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields, extrasaction="ignore")
        writer.writeheader()
        writer.writerows(rows)


def write_json(path: Path, value: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8") as handle:
        json.dump(value, handle, ensure_ascii=False, indent=2)


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def sha256_json(value: Any) -> str:
    encoded = json.dumps(
        value, ensure_ascii=False, sort_keys=True, separators=(",", ":")
    ).encode("utf-8")
    return hashlib.sha256(encoded).hexdigest()


def artifact_record(path: Path) -> dict[str, Any]:
    resolved = path.resolve(strict=True)
    details = resolved.stat()
    if not resolved.is_file() or details.st_size <= 0:
        raise ValueError(f"review artifact is missing or empty: {resolved}")
    return {
        "path": str(resolved),
        "bytes": details.st_size,
        "sha256": sha256_file(resolved),
    }


def build_content_review_template(
    output: Path, manifest: dict[str, Any]
) -> dict[str, Any]:
    """Build a non-claiming, hash-bound template for the human/agent review.

    The template is deliberately not named ``perfetto_content_review.json`` and
    cannot satisfy the delivery validator.  A reviewer must inspect every listed
    artifact, copy the template to that canonical name, replace pending statuses,
    and write observations.  SQL is embedded below ``/sql`` in each renderer
    manifest, so its path is recorded separately without inventing a SQL file.
    """
    batch_path = output / "perfetto_batch_manifest.json"
    reviewed_jobs: list[dict[str, Any]] = []
    for job in manifest.get("jobs", []):
        if not isinstance(job, dict):
            continue
        job_output = Path(str(job.get("output_dir", ""))).resolve(strict=True)
        renderer_manifest = Path(str(job.get("manifest_path", ""))).resolve(strict=True)
        renderer_value = json.loads(renderer_manifest.read_text(encoding="utf-8-sig"))
        if not isinstance(renderer_value, dict):
            raise ValueError(f"renderer manifest root is not an object: {renderer_manifest}")
        renderer_sql = renderer_value.get("sql")
        if not isinstance(renderer_sql, dict):
            raise ValueError(f"renderer manifest /sql is not an object: {renderer_manifest}")
        artifact_paths = {
            "manifest": renderer_manifest,
            "html": job_output / "perfetto_ui_frame.html",
            "text": job_output / "perfetto_ui_text.txt",
            "browser-log": job_output / "perfetto_browser.log",
        }
        if manifest.get("screenshot_requested") is True:
            artifact_paths["screenshot"] = job_output / "perfetto_ui.png"
        reviewed_jobs.append(
            {
                "rank_pair_id": str(job.get("rank_pair_id", "")),
                "environment": str(job.get("environment", "")),
                "batch": job_output.name,
                "status": "pending-review",
                "batch_job_sha256": sha256_json(job),
                "renderer_run_id": str(renderer_value.get("run_id", "")),
                "renderer_manifest_sha256": sha256_file(renderer_manifest),
                "trace_sha256": str(
                    (renderer_value.get("trace") or {}).get("sha256", "")
                ),
                "artifacts": [
                    {"kind": kind, **artifact_record(path)}
                    for kind, path in artifact_paths.items()
                ],
                "sql_path": str(renderer_manifest),
                "sql_json_pointer": "/sql",
                "sql_query_ids": [
                    str(row.get("query_id", ""))
                    for row in (renderer_sql.get("query_results") or [])
                    if isinstance(row, dict)
                ],
                "observations": [],
            }
        )
    return {
        "schema_version": 1,
        "status": "pending-review",
        "batch_manifest_sha256": sha256_file(batch_path),
        "review_methods": ["manifest", "html", "text", "sql", "browser-log"],
        "reviewed_jobs": reviewed_jobs,
        "observations": [],
        "screenshot_reviewed": False,
        "canvas_claims_made": False,
        "instructions": [
            "Read every listed manifest, HTML, text, embedded /sql result, and browser log.",
            "Copy this file to perfetto_content_review.json only after review.",
            "Set root and every job status to complete and record non-empty observations.",
            "Do not change any hash, path, run_id, batch identity, or artifact inventory.",
        ],
    }


def resolve_playwright_node_modules(
    explicit: str, environ: dict[str, str] | None = None,
) -> tuple[str, str]:
    """Return trusted absolute node_modules roots and their configuration source.

    The CLI value is intentionally singular.  The legacy environment fallback may
    contain multiple roots separated with os.pathsep.  Relative paths, implicit CWD
    lookup, NODE_PATH, and package installation are never used.
    """

    environment = os.environ if environ is None else environ
    raw_value = explicit.strip()
    source = "--playwright-node-modules"
    raw_roots: list[str]
    if raw_value:
        raw_roots = [raw_value]
    else:
        source = PLAYWRIGHT_NODE_MODULES_ENV
        raw_roots = [
            value for value in environment.get(PLAYWRIGHT_NODE_MODULES_ENV, "").split(os.pathsep)
            if value
        ]
    if not raw_roots:
        return "", "not-configured"

    normalized: list[str] = []
    seen: set[str] = set()
    for raw_root in raw_roots:
        candidate = Path(raw_root).expanduser()
        if not candidate.is_absolute():
            raise ValueError(
                f"{source} must contain absolute trusted node_modules paths: {raw_root!r}"
            )
        try:
            root = candidate.resolve(strict=True)
        except OSError as error:
            raise ValueError(f"{source} path cannot be resolved: {raw_root!r}: {error}") from error
        if not root.is_dir():
            raise ValueError(f"{source} path is not a directory: {root}")
        if not any((root / package / "package.json").is_file() for package in PLAYWRIGHT_PACKAGES):
            raise ValueError(
                f"{source} path contains neither playwright-core nor playwright: {root}"
            )
        key = str(root).lower() if os.name == "nt" else str(root)
        if key not in seen:
            seen.add(key)
            normalized.append(str(root))
    return os.pathsep.join(normalized), source


def resolve_online_executable(raw_value: str, label: str) -> str:
    """Require an explicit absolute executable for an online renderer job."""
    candidate = Path(raw_value).expanduser()
    if not candidate.is_absolute():
        raise ValueError(f"{label} must be an absolute executable path")
    try:
        resolved = candidate.resolve(strict=True)
    except OSError as error:
        raise ValueError(f"{label} executable cannot be resolved: {error}") from error
    if not resolved.is_file():
        raise ValueError(f"{label} executable is not a file: {resolved}")
    if os.name != "nt" and not os.access(resolved, os.X_OK):
        raise ValueError(f"{label} executable is not executable: {resolved}")
    return str(resolved)


def parse_utc_timestamp(value: Any) -> float | None:
    if not isinstance(value, str) or not value:
        return None
    try:
        parsed = datetime.fromisoformat(value.replace("Z", "+00:00"))
    except ValueError:
        return None
    if parsed.tzinfo is None:
        parsed = parsed.replace(tzinfo=timezone.utc)
    return parsed.timestamp()


def valid_run_id(value: Any) -> bool:
    try:
        UUID(str(value))
    except (ValueError, TypeError, AttributeError):
        return False
    return True


def lane_key(lane: dict[str, Any]) -> str:
    values = []
    for field in ("pid", "tid"):
        raw = lane.get(field)
        if isinstance(raw, bool) or not str(raw).isdigit():
            raise ValueError(f"lane {field} is not a non-negative integer: {raw!r}")
        value = int(str(raw))
        if value > 2**53 - 1:
            raise ValueError(f"lane {field} exceeds JavaScript safe integer range: {raw!r}")
        values.append(value)
    return f"{values[0]}/{values[1]}"


def lane_batches(
    source: Path, staging: Path, max_lanes: int,
) -> tuple[list[dict[str, Any]], list[str]]:
    value = json.loads(source.read_text(encoding="utf-8-sig"))
    lanes = value.get("lanes") if isinstance(value, dict) else None
    if not isinstance(lanes, list):
        raise ValueError(f"lane file 缺少 lanes 数组：{source}")
    compatible = [lane for lane in lanes if lane.get("renderer_compatible") is not False]
    if not compatible:
        return [], []
    keys = [lane_key(lane) for lane in compatible]
    if len(keys) != len(set(keys)):
        raise ValueError(f"lane file contains duplicate numeric PID/TID lanes: {source}")
    batches: list[dict[str, Any]] = []
    for start in range(0, len(compatible), max_lanes):
        batch = compatible[start : start + max_lanes]
        batch_keys = keys[start : start + len(batch)]
        path = staging / f"lanes_{start:04d}_{start + len(batch) - 1:04d}.json"
        write_json(path, {"schema_version": 1, "domain": "host", "lanes": batch,
                          "source_lane_file": str(source.resolve()),
                          "source_lane_keys": keys, "batch_lane_keys": batch_keys})
        batches.append({"path": path, "first": start, "last": start + len(batch) - 1,
                        "lane_keys": batch_keys})
    return batches, keys


def review_gate(
    manifest: dict[str, Any], job: dict[str, Any], invoked_at_ns: int,
    previous_run_id: str, screenshot_requested: bool,
) -> tuple[str, dict[str, Any]]:
    perfetto = manifest.get("perfetto") or {}
    network = perfetto.get("network_isolation") or {}
    sql = manifest.get("sql") or {}
    completeness = sql.get("completeness") or {}
    selection = manifest.get("selection") or {}
    expected_sha = job.get("expected_trace_sha256", "")
    trace_path = Path(job["trace_path"])
    actual_sha = sha256_file(trace_path) if trace_path.is_file() else ""
    manifest_sha = (manifest.get("trace") or {}).get("sha256", "")
    expected_lane_keys = json.loads(job.get("batch_lane_keys_json") or "[]")
    actual_lane_keys: list[str] = []
    lane_error = ""
    try:
        actual_lane_keys = [lane_key(lane) for lane in selection.get("lanes") or []]
    except (TypeError, ValueError) as error:
        lane_error = str(error)

    output_dir = Path(job["output_dir"])
    required_artifacts = {
        "frame_html": output_dir / "perfetto_ui_frame.html",
        "text": output_dir / "perfetto_ui_text.txt",
        "browser_log": output_dir / "perfetto_browser.log",
        "manifest": output_dir / "perfetto_manifest.json",
    }
    if screenshot_requested:
        required_artifacts["screenshot"] = output_dir / "perfetto_ui.png"
    artifact_audit: dict[str, Any] = {}
    artifact_nonempty = True
    artifact_fresh = True
    freshness_floor_ns = invoked_at_ns - 2_000_000_000
    for name, path in required_artifacts.items():
        try:
            details = path.stat()
            record = {"path": str(path.resolve()), "exists": True, "bytes": details.st_size,
                      "mtime_ns": details.st_mtime_ns}
            artifact_nonempty = artifact_nonempty and path.is_file() and details.st_size > 0
            artifact_fresh = artifact_fresh and details.st_mtime_ns >= freshness_floor_ns
        except OSError as error:
            record = {"path": str(path), "exists": False, "bytes": 0, "error": str(error)}
            artifact_nonempty = False
            artifact_fresh = False
        artifact_audit[name] = record

    started_at = parse_utc_timestamp(manifest.get("started_at"))
    run_id = str(manifest.get("run_id") or "")
    query_results = sql.get("query_results") or []
    query_rows_and_errors_complete = bool(query_results) and all(
        result.get("completed") is True
        and isinstance(result.get("row_count"), int)
        and result.get("row_count") >= 0
        and not result.get("error")
        for result in query_results
    )
    gates = {
        "status_success": manifest.get("status") == "success",
        "fresh_valid_run_id": valid_run_id(run_id) and run_id != previous_run_id,
        "manifest_started_for_this_invocation": (
            started_at is not None and started_at >= invoked_at_ns / 1_000_000_000 - 5
        ),
        "official_origin": perfetto.get("ui_origin") == "https://ui.perfetto.dev",
        "local_only": perfetto.get("local_only") is True,
        "offline_before_trace_post": network.get("offline_before_trace_post") is True,
        "post_offline_successful_response_zero": (
            network.get("post_offline_successful_response_count") == 0
        ),
        "service_worker_zero": network.get("service_worker_count_after_render") == 0,
        "service_worker_guard": network.get("service_worker_guard_visible_in_perfetto_frame") is True,
        "rank_pairs_expected_sha_present": len(expected_sha) == 64,
        "actual_trace_sha_matches_rank_pairs": bool(expected_sha) and actual_sha == expected_sha,
        "renderer_trace_sha_matches_rank_pairs": bool(expected_sha) and manifest_sha == expected_sha,
        "host_only_selection": selection.get("domain") == "host",
        "device_evidence_local_parser_only": selection.get("device_evidence") == "local-parser-only",
        "lane_batch_exact": not lane_error and actual_lane_keys == expected_lane_keys,
        "renderer_skipped_no_lane": not (selection.get("skipped_lanes") or []),
        "query_rows_and_errors_complete": query_rows_and_errors_complete,
        "sql_completeness_complete": completeness.get("complete") is True,
        "sql_not_truncated": completeness.get("truncated") is False,
        "sql_global_row_limit_absent": sql.get("global_row_limit") is None,
        "duration_metrics_emitted_false": sql.get("duration_metrics_emitted") is False,
        "required_artifacts_nonempty": artifact_nonempty,
        "required_artifacts_fresh": artifact_fresh,
    }
    details = {
        "gates": gates,
        "facts": {
            "run_id": run_id,
            "previous_run_id": previous_run_id,
            "expected_trace_sha256": expected_sha,
            "actual_trace_sha256": actual_sha,
            "renderer_trace_sha256": manifest_sha,
            "expected_lane_keys": expected_lane_keys,
            "actual_lane_keys": actual_lane_keys,
            "lane_error": lane_error,
            "query_results": [
                {key: result.get(key) for key in ("query_id", "completed", "row_count", "error")}
                for result in query_results
            ],
            "sql_completeness": completeness,
            "post_offline_successful_response_count": network.get(
                "post_offline_successful_response_count"
            ),
            "artifacts": artifact_audit,
        },
    }
    return ("auto-artifacts-ready" if all(gates.values()) else "gate-failed", details)


def plan_jobs(alignment_output: Path, batch_output: Path, max_lanes: int) -> list[dict[str, Any]]:
    jobs = []
    rank_pairs = read_csv(alignment_output / "rank_pairs.csv")
    for pair in rank_pairs:
        pair_id = pair["rank_pair_id"]
        for side, trace_field, trace_sha_field, lane_name in (
            ("real", "real_trace_path", "real_trace_sha256", "real_host_lanes.json"),
            ("sim", "sim_trace_path", "sim_trace_sha256", "sim_host_lanes.json"),
        ):
            trace = Path(pair.get(trace_field, ""))
            expected_sha = pair.get(trace_sha_field, "").strip().lower()
            lane_source = alignment_output / "perfetto_inputs" / pair_id / lane_name
            if not trace.is_file() or not lane_source.is_file():
                jobs.append(
                    {"rank_pair_id": pair_id, "environment": side, "trace_path": str(trace),
                     "lane_source": str(lane_source), "lane_batch": "", "output_dir": "",
                     "expected_trace_sha256": expected_sha,
                     "source_lane_keys_json": "[]", "batch_lane_keys_json": "[]",
                     "planned_status": "skipped", "reason": "trace 或 Host lane 文件缺失"}
                )
                continue
            if len(expected_sha) != 64 or any(character not in "0123456789abcdef" for character in expected_sha):
                jobs.append(
                    {"rank_pair_id": pair_id, "environment": side, "trace_path": str(trace.resolve()),
                     "lane_source": str(lane_source.resolve()), "lane_batch": "", "output_dir": "",
                     "expected_trace_sha256": expected_sha,
                     "source_lane_keys_json": "[]", "batch_lane_keys_json": "[]",
                     "planned_status": "skipped", "reason": "rank_pairs.csv expected trace SHA-256 is missing or invalid"}
                )
                continue
            staging = batch_output / "lane_batches" / pair_id / side
            try:
                batches, source_lane_keys = lane_batches(lane_source, staging, max_lanes)
            except (OSError, ValueError, json.JSONDecodeError) as error:
                jobs.append(
                    {"rank_pair_id": pair_id, "environment": side, "trace_path": str(trace.resolve()),
                     "lane_source": str(lane_source.resolve()), "lane_batch": "", "output_dir": "",
                     "expected_trace_sha256": expected_sha,
                     "source_lane_keys_json": "[]", "batch_lane_keys_json": "[]",
                     "planned_status": "skipped", "reason": f"invalid Host lane file: {error}"}
                )
                continue
            if not batches:
                jobs.append(
                    {"rank_pair_id": pair_id, "environment": side, "trace_path": str(trace),
                     "lane_source": str(lane_source), "lane_batch": "", "output_dir": "",
                     "expected_trace_sha256": expected_sha,
                     "source_lane_keys_json": json.dumps(source_lane_keys), "batch_lane_keys_json": "[]",
                     "planned_status": "skipped", "reason": "没有 renderer-compatible Host lane"}
                )
            for batch_index, batch in enumerate(batches):
                output_dir = batch_output / "perfetto" / pair_id / side / f"batch_{batch_index:03d}"
                jobs.append(
                    {"rank_pair_id": pair_id, "environment": side, "trace_path": str(trace.resolve()),
                     "lane_source": str(lane_source.resolve()),
                     "lane_batch": str(batch["path"].resolve()),
                     "lane_first": batch["first"], "lane_last": batch["last"],
                     "output_dir": str(output_dir.resolve()),
                     "expected_trace_sha256": expected_sha,
                     "source_lane_keys_json": json.dumps(source_lane_keys),
                     "batch_lane_keys_json": json.dumps(batch["lane_keys"]),
                     "planned_status": "ready", "reason": ""}
                )
    return jobs


def apply_lane_union_gates(rows: list[dict[str, Any]]) -> list[dict[str, Any]]:
    groups: dict[tuple[str, str], list[dict[str, Any]]] = {}
    for row in rows:
        key = (str(row.get("rank_pair_id", "")), str(row.get("environment", "")))
        groups.setdefault(key, []).append(row)
    summaries: list[dict[str, Any]] = []
    for (pair_id, environment), group in sorted(groups.items()):
        source_sets = []
        planned_keys: list[str] = []
        actual_keys: list[str] = []
        for row in group:
            source_sets.append(json.loads(row.get("source_lane_keys_json") or "[]"))
            planned_keys.extend(json.loads(row.get("batch_lane_keys_json") or "[]"))
            try:
                gate_details = json.loads(row.get("gate_details") or "{}")
            except json.JSONDecodeError:
                gate_details = {}
            actual_keys.extend(((gate_details.get("facts") or {}).get("actual_lane_keys") or []))
        nonempty_source_sets = [keys for keys in source_sets if keys]
        expected_keys = nonempty_source_sets[0] if nonempty_source_sets else []
        source_consistent = bool(nonempty_source_sets) and all(
            keys == expected_keys for keys in nonempty_source_sets
        )
        planned_no_duplicates = len(planned_keys) == len(set(planned_keys))
        actual_no_duplicates = len(actual_keys) == len(set(actual_keys))
        all_jobs_ready_and_gated = bool(group) and all(
            row.get("planned_status") == "ready"
            and row.get("run_status") == "success"
            and row.get("auto_artifact_gate") == "auto-artifacts-ready"
            for row in group
        )
        complete = (
            bool(expected_keys)
            and source_consistent
            and planned_no_duplicates
            and actual_no_duplicates
            and set(planned_keys) == set(expected_keys)
            and set(actual_keys) == set(expected_keys)
            and all_jobs_ready_and_gated
        )
        summary = {
            "rank_pair_id": pair_id,
            "environment": environment,
            "complete": complete,
            "source_consistent": source_consistent,
            "expected_lane_keys": expected_keys,
            "planned_lane_keys": planned_keys,
            "actual_lane_keys": actual_keys,
            "planned_no_duplicates": planned_no_duplicates,
            "actual_no_duplicates": actual_no_duplicates,
            "all_jobs_ready_and_gated": all_jobs_ready_and_gated,
        }
        summaries.append(summary)
        encoded = json.dumps(summary, ensure_ascii=False, separators=(",", ":"))
        for row in group:
            row["lane_batch_union_complete"] = complete
            row["lane_batch_union_details"] = encoded
    return summaries


def run_batch(
    alignment_output: Path, output: Path, renderer: Path, node: str, browser: str,
    playwright_node_modules: str, timeout_ms: int, screenshot: bool, max_lanes: int, plan_only: bool,
    degraded_reason: str, online_authorized: bool,
) -> dict[str, Any]:
    alignment_output = alignment_output.resolve()
    output = output.resolve()
    renderer = renderer.resolve()
    if not renderer.is_file():
        raise ValueError(f"renderer 不存在：{renderer}")
    output.mkdir(parents=True, exist_ok=True)
    jobs = plan_jobs(alignment_output, output, max_lanes)
    execution_block_reason = degraded_reason
    if not execution_block_reason and not plan_only and not online_authorized:
        execution_block_reason = (
            "online Perfetto review was not authorized; pass --online-authorized to allow "
            "loading https://ui.perfetto.dev/"
        )
    # Offline/degraded and plan-only runs must not inspect an ambient dependency
    # path. A stale host environment cannot prevent standard not-executed evidence.
    trusted_node_modules = ""
    trusted_node = ""
    trusted_browser = ""
    dependency_source = "not-required"
    if not execution_block_reason and not plan_only and online_authorized:
        trusted_node = resolve_online_executable(node, "--node")
        if not browser.strip():
            raise ValueError(
                "--browser is required for online review and must be an explicit absolute executable"
            )
        trusted_browser = resolve_online_executable(browser, "--browser")
        trusted_node_modules, dependency_source = resolve_playwright_node_modules(
            playwright_node_modules
        )
    if (
        not execution_block_reason
        and not plan_only
        and online_authorized
        and not trusted_node_modules
    ):
        execution_block_reason = (
            "Playwright dependency root is not configured; pass an absolute "
            "--playwright-node-modules path"
        )
    if not execution_block_reason and not plan_only and online_authorized:
        # A fresh renderer run invalidates any review bound to an older batch.
        # Only explicit/forced rendering reaches this branch; ordinary resume is
        # handled by the orchestrator without invoking this script again.
        for name in (
            "perfetto_content_review.json",
            "perfetto_content_review.template.json",
        ):
            try:
                (output / name).unlink()
            except FileNotFoundError:
                pass
    rows: list[dict[str, Any]] = []
    for job in jobs:
        row = dict(job)
        row.update({"run_status": "not-run", "return_code": "", "manifest_path": "",
                    "auto_artifact_gate": "not-run", "gate_details": "",
                    "content_review_status": "pending-agent-review", "error": ""})
        if plan_only:
            rows.append(row)
            continue
        if execution_block_reason:
            row["run_status"] = "not-executed"
            row["content_review_status"] = "not-executed"
            row["error"] = execution_block_reason
            rows.append(row)
            continue
        if job["planned_status"] != "ready":
            rows.append(row)
            continue
        try:
            preflight_sha = sha256_file(Path(job["trace_path"]))
        except OSError as error:
            row["run_status"] = "failure"
            row["auto_artifact_gate"] = "preflight-failed"
            row["error"] = f"trace SHA-256 preflight failed: {error}"
            rows.append(row)
            continue
        row["preflight_trace_sha256"] = preflight_sha
        if preflight_sha != job.get("expected_trace_sha256"):
            row["run_status"] = "failure"
            row["auto_artifact_gate"] = "preflight-failed"
            row["error"] = "trace SHA-256 does not match rank_pairs.csv; online load was blocked"
            rows.append(row)
            continue
        manifest_path = Path(job["output_dir"]) / "perfetto_manifest.json"
        previous_run_id = ""
        if manifest_path.is_file():
            try:
                previous = json.loads(manifest_path.read_text(encoding="utf-8"))
                previous_run_id = str(previous.get("run_id") or "")
            except (OSError, json.JSONDecodeError):
                previous_run_id = "invalid-previous-manifest"
        invoked_at_ns = time.time_ns()
        row["invoked_at"] = datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")
        row["previous_run_id"] = previous_run_id
        command = [
            trusted_node, str(renderer), "--trace", job["trace_path"], "--output", job["output_dir"],
            "--lane-file", job["lane_batch"], "--timeout-ms", str(timeout_ms),
            "--online-authorized",
        ]
        if trusted_node_modules:
            command.extend(["--playwright-node-modules", trusted_node_modules])
        command.extend(["--browser", trusted_browser])
        if screenshot:
            command.append("--screenshot")
        try:
            child_environment = os.environ.copy()
            for name in list(child_environment):
                if name.upper().startswith("NODE_"):
                    child_environment.pop(name, None)
            if trusted_node_modules:
                child_environment[PLAYWRIGHT_NODE_MODULES_ENV] = trusted_node_modules
            else:
                child_environment.pop(PLAYWRIGHT_NODE_MODULES_ENV, None)
            completed = subprocess.run(
                command, capture_output=True, text=True, timeout=max(60, timeout_ms // 1000 + 60),
                env=child_environment, check=False,
            )
            row["return_code"] = completed.returncode
            row["run_status"] = "success" if completed.returncode == 0 else "failure"
            row["stdout_tail"] = completed.stdout[-4000:]
            row["stderr_tail"] = completed.stderr[-4000:]
        except (OSError, subprocess.SubprocessError) as error:
            row["run_status"] = "failure"
            row["error"] = f"{type(error).__name__}: {error}"
        row["manifest_path"] = str(manifest_path)
        if manifest_path.is_file():
            try:
                manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
                gate, gate_details = review_gate(
                    manifest, job, invoked_at_ns, previous_run_id, screenshot,
                )
                row["auto_artifact_gate"] = gate
                row["gate_details"] = json.dumps(
                    gate_details, ensure_ascii=False, separators=(",", ":"),
                )
                row["renderer_run_id"] = manifest.get("run_id", "")
                row["trace_sha256"] = (manifest.get("trace") or {}).get("sha256", "")
                row["screenshot_present"] = bool(
                    ((manifest.get("artifacts") or {}).get("screenshot") or {}).get("exists")
                )
            except (OSError, ValueError, json.JSONDecodeError) as error:
                row["auto_artifact_gate"] = "manifest-invalid"
                row["error"] = f"{type(error).__name__}: {error}"
        else:
            row["auto_artifact_gate"] = "manifest-missing"
            row["error"] = row["error"] or "renderer did not create perfetto_manifest.json"
        rows.append(row)
        write_csv(output / "perfetto_batch_manifest.csv", rows)
        write_json(output / "perfetto_batch_manifest.json", {"jobs": rows})
    lane_union_summaries = apply_lane_union_gates(rows)
    status = "complete" if rows and all(
        row.get("planned_status") == "ready"
        and row.get("run_status") == "success"
        and row.get("auto_artifact_gate") == "auto-artifacts-ready"
        and row.get("lane_batch_union_complete") is True
        for row in rows
    ) else "partial"
    manifest = {
        "schema_version": 2, "status": status, "alignment_output": str(alignment_output),
        "output": str(output), "renderer": str(renderer), "jobs": rows,
        "execution_mode": (
            "plan-only" if plan_only else "not-executed" if execution_block_reason else "online"
        ),
        "screenshot_requested": screenshot, "max_lanes_per_job": max_lanes,
        "playwright_node_modules": trusted_node_modules,
        "playwright_node_modules_source": dependency_source,
        "node_executable": trusted_node,
        "browser_executable": trusted_browser,
        "online_authorized": online_authorized,
        "execution_block_reason": execution_block_reason,
        "lane_batch_union": lane_union_summaries,
        "privacy_boundary": (
            "No network access occurs unless --online-authorized is explicit. With authorization, official UI "
            "code is fetched online; trace bytes are posted only after browser offline mode and Service Worker "
            "blocking. localOnly alone is not the privacy gate."
        ),
        "review_boundary": (
            "Perfetto is an auxiliary Host framework/launch review only; Device evidence remains local-parser-only. "
            "auto-artifacts-ready is not content review. An agent must read HTML/text/SQL and record observations; "
            "Canvas geometry requires an explicitly requested and actually inspected screenshot."
        ),
        "device_evidence": "local-parser-only",
        "duration_metrics_emitted": False,
    }
    write_csv(output / "perfetto_batch_manifest.csv", rows)
    write_json(output / "perfetto_batch_manifest.json", manifest)
    if execution_block_reason:
        write_json(
            output / "perfetto_content_review.json",
            {
                "schema_version": 1,
                "status": "not-executed",
                "reason": execution_block_reason,
                "reviewed_artifacts": [],
                "reviewed_jobs": [
                    {
                        "rank_pair_id": row.get("rank_pair_id", ""),
                        "environment": row.get("environment", ""),
                        "status": "not-executed",
                    }
                    for row in rows
                ],
                "canvas_review": "not-executed",
                "allowed_claims": ["Perfetto 内容复核未执行"],
                "prohibited_claims": [
                    "页面已成功加载 trace",
                    "Perfetto SQL 或 DOM 与本地解析结果一致",
                    "Canvas 热力图几何或颜色已复核",
                ],
            },
        )
    elif status == "complete":
        write_json(
            output / "perfetto_content_review.template.json",
            build_content_review_template(output, manifest),
        )
    else:
        # The renderer ran but did not pass every automatic gate.  This is not a
        # successful content review and must never be upgraded by a template.
        write_json(
            output / "perfetto_content_review.json",
            {
                "schema_version": 1,
                "status": "partial",
                "batch_manifest_sha256": sha256_file(
                    output / "perfetto_batch_manifest.json"
                ),
                "review_methods": [],
                "reviewed_jobs": [],
                "observations": [
                    "online renderer did not pass every automatic artifact/lane gate"
                ],
                "screenshot_reviewed": False,
                "canvas_claims_made": False,
            },
        )
    return manifest


def run_self_test(renderer: Path) -> int:
    with tempfile.TemporaryDirectory(prefix="perfetto-batch-selftest-") as directory:
        root = Path(directory)
        alignment, output = root / "alignment", root / "output"
        lane_dir = alignment / "perfetto_inputs" / "rank-0000"
        lane_dir.mkdir(parents=True)
        trace = root / "trace.json"
        trace.write_text("[]", encoding="utf-8")
        trace_sha = sha256_file(trace)
        write_csv(
            alignment / "rank_pairs.csv",
            [{"rank_pair_id": "rank-0000", "real_trace_path": str(trace),
              "sim_trace_path": str(trace), "real_trace_sha256": trace_sha,
              "sim_trace_sha256": trace_sha}],
        )
        lane = {"schema_version": 1, "lanes": [
            {"pid": 1, "tid": 2, "renderer_compatible": True, "lane_id": "a"},
            {"pid": "opaque", "tid": 3, "renderer_compatible": False, "lane_id": "b"},
        ]}
        write_json(lane_dir / "real_host_lanes.json", lane)
        write_json(lane_dir / "sim_host_lanes.json", lane)
        manifest = run_batch(
            alignment, output, renderer, "node", "", "", 5000, False, 128, True, "", False,
        )
        ready = [row for row in manifest["jobs"] if row["planned_status"] == "ready"]
        assert len(ready) == 2
        assert manifest["status"] == "partial"
        assert all(row["run_status"] == "not-run" for row in ready)
        assert all(json.loads(row["source_lane_keys_json"]) == ["1/2"] for row in ready)
        assert manifest["duration_metrics_emitted"] is False
        unauthorized = run_batch(
            alignment, root / "unauthorized", renderer, "node", "", "", 5000,
            False, 128, False, "", False,
        )
        assert unauthorized["status"] == "partial"
        assert unauthorized["online_authorized"] is False
        assert all(row["run_status"] == "not-executed" for row in unauthorized["jobs"])
        try:
            run_batch(
                alignment,
                root / "relative-browser",
                renderer,
                str(Path(sys.executable).resolve()),
                "browser-from-cwd",
                "",
                5000,
                False,
                128,
                False,
                "",
                True,
            )
        except ValueError as error:
            assert "--browser must be an absolute" in str(error)
        else:
            raise AssertionError("online batch accepted a relative browser executable")

        fake_output = root / "fake-render"
        fake_output.mkdir()
        invoked_at_ns = time.time_ns()
        for name in ("perfetto_ui_frame.html", "perfetto_ui_text.txt", "perfetto_browser.log"):
            (fake_output / name).write_text("evidence", encoding="utf-8")
        fake_manifest = {
            "schema_version": 3,
            "run_id": "00000000-0000-4000-8000-000000000001",
            "status": "success",
            "started_at": datetime.now(timezone.utc).isoformat().replace("+00:00", "Z"),
            "trace": {"sha256": trace_sha},
            "selection": {"domain": "host", "device_evidence": "local-parser-only",
                          "lanes": [{"pid": 1, "tid": 2}], "skipped_lanes": []},
            "perfetto": {"ui_origin": "https://ui.perfetto.dev", "local_only": True,
                         "network_isolation": {"offline_before_trace_post": True,
                                               "post_offline_successful_response_count": 0,
                                               "service_worker_count_after_render": 0,
                                               "service_worker_guard_visible_in_perfetto_frame": True}},
            "sql": {"duration_metrics_emitted": False, "global_row_limit": None,
                    "query_results": [{"query_id": "structural_sequence", "completed": True,
                                       "row_count": 1, "error": None}],
                    "completeness": {"complete": True, "truncated": False}},
        }
        write_json(fake_output / "perfetto_manifest.json", fake_manifest)
        fake_job = {"trace_path": str(trace), "output_dir": str(fake_output),
                    "expected_trace_sha256": trace_sha, "batch_lane_keys_json": '["1/2"]'}
        gate, details = review_gate(fake_manifest, fake_job, invoked_at_ns, "", False)
        assert gate == "auto-artifacts-ready", details
    print("self-test: ok")
    return 0


def build_parser() -> argparse.ArgumentParser:
    default_renderer = Path(__file__).with_name("render_perfetto_trace.mjs")
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--alignment-output", type=Path)
    parser.add_argument("--output", type=Path)
    parser.add_argument("--renderer", type=Path, default=default_renderer)
    parser.add_argument("--node", default="node")
    parser.add_argument("--browser", default="")
    parser.add_argument(
        "--playwright-node-modules",
        default="",
        help=(
            "absolute trusted node_modules root containing playwright-core or playwright; "
            f"{PLAYWRIGHT_NODE_MODULES_ENV} is used only when this option is omitted"
        ),
    )
    parser.add_argument("--timeout-ms", type=int, default=180000)
    parser.add_argument("--max-lanes-per-job", type=int, default=128)
    parser.add_argument("--screenshot", action="store_true")
    parser.add_argument("--plan-only", action="store_true")
    parser.add_argument(
        "--online-authorized",
        action="store_true",
        help="explicitly authorize loading official UI code from https://ui.perfetto.dev/",
    )
    parser.add_argument(
        "--degraded-reason",
        default="",
        help="不启动浏览器；写出标准 not-executed Perfetto 复核记录及原因",
    )
    parser.add_argument("--self-test", action="store_true")
    return parser


def main(argv: list[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    if args.self_test:
        return run_self_test(args.renderer)
    if not args.alignment_output or not args.output:
        raise SystemExit("--alignment-output 和 --output 均为必需参数")
    if not 1 <= args.max_lanes_per_job <= 128:
        raise SystemExit("--max-lanes-per-job 必须在 1..128")
    manifest = run_batch(
        args.alignment_output, args.output, args.renderer, args.node, args.browser,
        args.playwright_node_modules, args.timeout_ms, args.screenshot,
        args.max_lanes_per_job, args.plan_only,
        args.degraded_reason.strip(), args.online_authorized,
    )
    print(json.dumps(manifest, ensure_ascii=False, indent=2))
    intentional_not_executed = (
        manifest.get("execution_mode") == "not-executed"
        and bool(manifest.get("jobs"))
        and all(row.get("run_status") == "not-executed" for row in manifest["jobs"])
    )
    return 0 if manifest["status"] == "complete" or intentional_not_executed else 1


if __name__ == "__main__":
    raise SystemExit(main())

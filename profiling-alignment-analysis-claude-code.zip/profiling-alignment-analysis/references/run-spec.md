# Claude Code 运行契约与可恢复入口

## 1. 目的

`alignment-run.json` 是整个分析的唯一输入契约。它把当前目录中的 MindSpeed、torch、torch_npu、真机 Profiling、仿真 Profiling、模型 `.sh` 入口和输出根显式绑定，避免代理按目录名猜测。

推荐把文件写到 `<work-root>/alignment-run.json`，作为用户提供给流水线的输入配置；它不属于分析交付。源码与 Profiling 只读，流水线只写 `output_root`。

## 2. 最小完整示例

```json
{
  "schema_version": 1,
  "work_root": "D:/work/qwen3vl-alignment",
  "source_roots": {
    "model": {"path": "MindSpeed"},
    "pytorch": {"path": "torch"},
    "torch_npu": {"path": "torch_npu"}
  },
  "entry_sh": [
    "examples/qwen3vl/finetune_qwen3vl_8B.sh"
  ],
  "profiles": {
    "real": "real-profiling",
    "sim": "simulation-profiling"
  },
  "output_root": "output",
  "perfetto": {
    "online_authorized": false,
    "node": "",
    "playwright_node_modules": "",
    "browser": "",
    "screenshot": false,
    "degraded_reason": "online authorization not provided"
  }
}
```

相对路径一律相对 `work_root` 解析。`source_roots.model` 的人类可读名称是 MindSpeed；`pytorch` 对应 torch；`torch_npu` 对应 torch_npu。`entry_sh` 可为字符串或字符串数组，每项必须相对 MindSpeed 根，不能相对当前 shell 目录，也不能越界。

`profiles.real` 固定为真机 reference，`profiles.sim` 固定为仿真 candidate。两者角色不明确时停止并询问，不得从路径名、事件数量或时间戳推断。

`output_root` 必须与三个源码根、两个 Profiling 根互不包含。已有源码 checkout 一律只读复用；单份 torch/torch_npu 默认是真机 reference 基线，不代表仿真运行绑定。

`perfetto.online_authorized` 默认必须为 `false`。此时流水线生成标准 `not-executed` evidence，并继续完成本地结构分析。只有用户明确授权在线数据处理后才能改为 `true`；详见 [perfetto-review.md](perfetto-review.md)。

在线值为 `true` 时，`perfetto.node`、`perfetto.browser` 和 `perfetto.playwright_node_modules` 三项都必须是位于 work-root、源码、Profiling 与输出根之外的绝对路径。首次自动渲染通过后流水线会停在 `needs-agent`，要求逐 job 阅读 manifest、HTML、text、SQL 与 browser log；完成 hash 绑定的内容复核后再用同一条 `--resume` 命令继续，resume 不会重新渲染 trace。

可选顶层 `source_owner` 用于在已有明确证据时锁定首要 guard owner，取值只能是 `model`、`pytorch` 或 `torch_npu`。可选 `runtime` 用于保存 workload、phase、Profiler schedule、并行拓扑、源码/build 绑定和 runtime guard 值；未提供项写 `unknown`，不得猜测。Python 解释器和已安装 PyTorch 包版本即使记录，也固定为 informational，不参与结构或强度门禁。

## 3. 默认命令

正常运行只使用：

```text
python "${CLAUDE_SKILL_DIR}/scripts/profiling_alignment.py" run --spec "<absolute-work-root>/alignment-run.json" --resume
```

流水线阶段为：runtime preflight、Ascend preflight、alignment、MindSpeed entrypoint、run contract、source causality、Perfetto status、report、validator。每个已完成阶段都在 `output_root/evidence/pipeline/run-state.json` 中记录输入/产物身份；相同 spec 重跑时复用通过门禁的阶段。

若 source owner、stack 路径或 guard 输入不足，流水线应返回 `needs-agent`，而不是伪造成功。读取状态中的 `next_action`，完成其指定的只读源码定位或证据补充后，再运行同一条 `--resume` 命令。

## 4. 状态与故障定位命令

以下命令只用于验证 run-spec、读取状态或精确重试，不是默认分析流程：

```text
python "${CLAUDE_SKILL_DIR}/scripts/profiling_alignment.py" validate-spec --spec "<absolute-work-root>/alignment-run.json"
python "${CLAUDE_SKILL_DIR}/scripts/profiling_alignment.py" status --spec "<absolute-work-root>/alignment-run.json"
python "${CLAUDE_SKILL_DIR}/scripts/profiling_alignment.py" run --spec "<absolute-work-root>/alignment-run.json" --resume
python "${CLAUDE_SKILL_DIR}/scripts/profiling_alignment.py" run --spec "<absolute-work-root>/alignment-run.json" --from-stage source_causality
python "${CLAUDE_SKILL_DIR}/scripts/profiling_alignment.py" run --spec "<absolute-work-root>/alignment-run.json" --force-stage report
```

只允许对已查明原因的单个 stage 使用 `--from-stage` 或 `--force-stage`。不得以它们绕过 preflight、source binding 或 validator。

## 5. 手工流水线（仅排查 orchestrator）

只有在 orchestrator 自身报错且需要确认具体脚本边界时，才逐一运行下列命令。所有路径必须来自已经验证的 run-spec；不要改写源码或 Profiling。

```text
python "${CLAUDE_SKILL_DIR}/scripts/preflight_ascend_profiles.py" --real "<real>" --sim "<sim>" --output "<output>/evidence/preflight"
python "${CLAUDE_SKILL_DIR}/scripts/align_profiles.py" --real "<real>" --sim "<sim>" --output "<output>/evidence/alignment" --heatmap-bins 64
python "${CLAUDE_SKILL_DIR}/scripts/resolve_source_entrypoints.py" --repo-root "<MindSpeed>" --entry "<MindSpeed-relative-entry.sh>" --output "<output>/evidence/source-entrypoints" --environment shared
python "${CLAUDE_SKILL_DIR}/scripts/analyze_control_flow.py" --repo-root "<selected-owner-root>" --alignment-output "<output>/evidence/alignment" --source-analysis-dir "<output>/evidence/source-entrypoints" --run-contract "<output>/evidence/run_comparability_contract.json" --output "<output>/evidence/source-causality"
python "${CLAUDE_SKILL_DIR}/scripts/render_python_guard_snapshots.py" --repo-root "<selected-owner-root>" --source-causality-dir "<output>/evidence/source-causality" --output "<output>/evidence/python-guard-snapshots"
python "${CLAUDE_SKILL_DIR}/scripts/build_alignment_report.py" --alignment-output "<output>/evidence/alignment" --preflight-dir "<output>/evidence/preflight" --run-contract "<output>/evidence/run_comparability_contract.json" --source-causality-dir "<output>/evidence/source-causality" --python-snapshots-dir "<output>/evidence/python-guard-snapshots" --perfetto-review-dir "<output>/evidence/perfetto-review" --output "<output>/profiling_alignment_report.md"
python "${CLAUDE_SKILL_DIR}/scripts/validate_alignment_report.py" --report "<output>/profiling_alignment_report.md" --alignment-output "<output>/evidence/alignment" --source-causality-dir "<output>/evidence/source-causality" --run-contract "<output>/evidence/run_comparability_contract.json" --python-snapshots-dir "<output>/evidence/python-guard-snapshots" --perfetto-review-dir "<output>/evidence/perfetto-review" --output "<output>/evidence/report-validation"
```

手工执行后仍必须回到 orchestrator 更新状态并运行 validator；一组散落 CSV/JSON 不是交付。

## 6. 完成条件

完成时至少存在：

```text
<output>/profiling_alignment_report.md
<output>/evidence/pipeline/run-state.json
<output>/evidence/run_comparability_contract.json
<output>/evidence/report-validation/report_validation.json
```

只在 `report_validation.json` 为 pass 且 blocking error 为 0 时交付主报告。任何 `partial`、`needs-agent` 或失败 stage 都必须在报告中降级并给出具体缺失证据，不能用 Outputs/Recommendations 列表替代分析正文。

# Claude Code 推荐 Prompt

## 最简模板

在同时包含源码和两侧 Profiling 的工作目录启动 Claude Code，然后使用：

```text
/profiling-alignment-analysis

请分析当前目录中的真机与仿真 Ascend Profiling：

工作根：<当前目录绝对路径>
MindSpeed 源码根：MindSpeed
torch 源码根：torch
torch_npu 源码根：torch_npu
真机 Profiling（reference）：real-profiling
仿真 Profiling（candidate）：simulation-profiling
输出根：output
模型入口（相对 MindSpeed 源码根）：examples/qwen3vl/finetune_qwen3vl_8B.sh
在线 Perfetto 授权：否

只分析算子结构、顺序、嵌套、Shape、序位热力图和控制流，不分析耗时或性能。逐同号 Rank、逐 Host thread、逐 Device stream 对齐。最终只把一份大型中文 profiling_alignment_report.md 作为主交付；关键分叉必须对应到 Python if/elif/else，并在 Markdown 内嵌带原始行号的 HTML 代码快照。CSV/JSON/辅助 HTML 只放在 output/evidence/。
```

有多个入口时逐行给出，或在 run-spec 的 `entry_sh` 中使用数组。相对入口只能从 MindSpeed 根解析，不能相对当前 shell 目录，也不能指向 torch/torch_npu。

## 建议补充的信息

以下内容有助于提高结论强度，但缺失时不阻塞本地结构提取；无法证明的字段必须写 `unknown`：

```text
模型/权重/配置：<标识或文件>
Workload 与阶段：<train/prefill/decode、batch、输入、数据集等>
Profiler schedule/窗口：<wait/warmup/active/repeat、step/request>
Profiler 配置：<CPU/NPU activities、record_shapes、with_stack、profiler level>
并行拓扑：<world size、DP/TP/EP/PP/CP/DCP>
MindSpeed commit/tree：<如有>
torch commit/tree：<如有，单份 checkout 默认为真机 reference 基线>
torch_npu commit/tree/build：<如有，guard 属于 torch_npu 时是关键证据>
真机/仿真运行绑定证据：<profiler metadata、log 或 build ID>
runtime guard operand：<可选 CSV/JSONL>
明确 Thread 映射：<可选，每 Rank 的 real pid/tid -> sim pid/tid 与依据>
```

不要求填写或对齐 Python 解释器版本、已安装 PyTorch 包版本。即使它们出现在 metadata 中，也只能标为 informational，不得作为默认根因、证据降级理由或修复建议。

## 路径与身份约束

推荐目录：

```text
<work-root>/
  alignment-run.json
  MindSpeed/
  torch/
  torch_npu/
  real-profiling/
  simulation-profiling/
  output/
    profiling_alignment_report.md
    evidence/
```

六个角色必须显式写出并解析为互不覆盖的绝对路径。公共目录只是路径容器，不是 Rank 或真机/仿真身份证据。如果用户只给两个 Profiling 目录却没有明确角色，只询问角色，不运行比较。

已有本地 MindSpeed、torch、torch_npu checkout 时直接只读使用，不再 clone。只有候选 guard 所属源码缺失且用户提供 HTTPS Git URL 时，才用：

```text
python "${CLAUDE_SKILL_DIR}/scripts/prepare_source_checkout.py" --source-url "<https-repository-or-blob-url>" --commit "<full-commit>" --entry "<optional-repo-relative-entry>" --work-root "<work-root>" --output "<work-root>/source-checkouts/<component>"
```

不得执行仓库中的 Bash/Python/C++、Git hooks、submodule 或 LFS 内容。URL 源码必须先成为固定本地快照，才能作为 AST 与原始行号证据；网页代码片段只能导航，不能产生强结论。

单份 `torch/` 和 `torch_npu/` 仅绑定真机 reference。它们可以解释真机路线并定位候选，但不能证明仿真实际运行了相同源码。若要比较两侧源码，Prompt 还必须显式提供仿真侧 checkout 及 runtime/build evidence。

## run-spec

收到上述 Prompt 后，将路径和授权状态写为 `<work-root>/alignment-run.json`，字段与默认值见 [run-spec.md](run-spec.md)，然后运行：

```text
python "${CLAUDE_SKILL_DIR}/scripts/profiling_alignment.py" run --spec "<absolute-work-root>/alignment-run.json" --resume
```

不要让用户手工拼接整套脚本。只有 orchestrator 报错或 `needs-agent` 时，才按状态文件和 [run-spec.md](run-spec.md) 的排障段执行精确下一步。

## 用户交付语义

最终回答应直接链接或给出 `profiling_alignment_report.md`，并用一两句话概括最重要的、已通过门禁的 Python 控制流证据。不得用以下内容代替主报告：

- Key Finding + Outputs + Recommendations 三段式摘要；
- 大量 CSV/JSON 路径；
- “请打开 Perfetto/附件继续看”的操作指南；
- 只有 C++/CANN/TorchNPU lowering 代码、没有 Python guard 快照的结论。

主报告必须让读者在一个文件中看到逐 Rank/lane 分叉、对应 operator/Shape、MindSpeed 入口链、Python predicate/arms、原始行号代码、predicate producer、直接 Device 证据、替代解释和结论强度。

# Perfetto 官方 UI 内容复核

## 1. 默认状态

Perfetto 是可选交叉复核，不是本地结构分析的前置条件。run-spec 默认：

```json
{
  "perfetto": {
    "online_authorized": false,
    "node": "",
    "playwright_node_modules": "",
    "browser": "",
    "screenshot": false,
    "degraded_reason": "online authorization not provided"
  }
}
```

默认不得访问 `ui.perfetto.dev`。流水线必须为每个预期 Rank/side 写标准 `not-executed` 状态和具体 reason，再继续使用本地 Ascend-aware 流式 parser 完成全部结构分析。不得因为 Perfetto 未执行就把本地穷举解析称为 sampled，也不得伪称页面已经加载。

只有用户明确确认 trace 符合组织数据政策，并把 `online_authorized` 改为 `true` 后，才能进入在线分支。GitHub/GitCode 可达性与 Perfetto 授权是两个独立门禁。

## 2. 在线加载的准确语义

获得授权后，每个同号 Rank 的真机和仿真 `trace_view.json` 分别执行：

1. 浏览器联网加载 `https://ui.perfetto.dev/` 官方 UI 代码；
2. 本地 host page 把 trace 读入浏览器内存；
3. 校验 PING/PONG 的精确 `event.origin` 和 `event.source`；
4. 阻断 Service Worker，并在 browser context 切换 offline；
5. 只有 `offline_before_trace_post=true` 后，才以 `localOnly=true` 把 trace buffer 发给已加载 UI；
6. 不点击 Share、不生成 permalink、不使用 `url=` 让 UI 主动抓取 trace。

因此报告应写“联网加载官方 UI 后，在离线浏览器上下文中本地打开 trace”，而不是声称 trace 已上传并托管在 Perfetto 服务端。`localOnly` 不是唯一安全边界；网站仍可看到常规页面访问/IP 元数据。若组织政策禁止第三方网页代码接触 trace，保持 `not-executed`，或使用用户明确提供的固定自托管 UI/local trace processor。

Ascend Chrome Trace JSON 是 legacy/best-effort 输入。Perfetto 只复核 Host track、顺序、嵌套、operator、calls 和页面状态；本地 parser 与 integrated CSV/JSON 才是完整结构证据基准。

## 3. 执行与依赖

在线模式的 Node、浏览器和受信 Playwright `node_modules` 必须由 run-spec 显式提供为绝对路径，并且都位于 work-root、源码、Profiling 和输出根之外；不要扫描模型源码仓寻找依赖，也不要使用模型仓中的 `NODE_PATH`。流水线把经过门禁的路径传给 renderer。依赖缺失时写 `partial/not-executed`，不临时安装、不绕过数据政策。默认离线模式不解析也不要求这些依赖。

默认未授权状态只在排查 orchestrator 时手工生成：

```text
python "${CLAUDE_SKILL_DIR}/scripts/render_perfetto_batch.py" --alignment-output "<output>/evidence/alignment" --output "<output>/evidence/perfetto-review" --degraded-reason "online authorization not provided"
```

以下命令仅适用于 run-spec 已明确授权、依赖路径已验证的情况，不是默认复制命令：

```text
python "${CLAUDE_SKILL_DIR}/scripts/render_perfetto_batch.py" --alignment-output "<output>/evidence/alignment" --output "<output>/evidence/perfetto-review" --online-authorized --node "<absolute-trusted-node>" --browser "<absolute-trusted-browser>" --playwright-node-modules "<absolute-trusted-node_modules>"
```

默认串行处理大 trace。每个 Rank/side 使用独立 SHA-256、输出目录和 manifest，不把多 Rank 合并为一个 timeline。一个 Rank 内的 renderer-compatible `framework_op` 与 `host_launch` lanes 可以确定性分批，但 batch union 必须覆盖所有兼容 Host lanes。Device lanes 不得用 Host SQL 冒充复核。

只有 run-spec 的 `screenshot=true` 且确实需要评价 Canvas 颜色/轨道几何时才启用截图；截图不是内容复核门禁。未实际查看 PNG 时不得评价 Canvas。

## 4. 查询边界

公开 SQL 只允许查询：

- Host PID/TID/process/thread/track；
- lane 内 event ordinal 与 nesting depth；
- category/operator 与 calls。

ordinal 必须按 lane 分区，例如 `ROW_NUMBER() OVER (PARTITION BY pid,tid ORDER BY ts,depth,id)`。保留 `track_id/track_name/parent_id` 并检测 multi-track/overflow。分页时每 lane 记录 `total/emitted/truncated`；任何截断都使 job 为 partial。

内部可用 `ts/dur` 让 UI 绘制 slice，但禁止把它们写入公开数值表或报告。禁止按 duration 排热点、输出 total/avg/max/self duration、从 Canvas 条宽/面积/空白解释耗时、按时间最近关联 Host→Device。Device 顺序来自本地 trace parser 或 `kernel_details.csv`；跨层因果只接受唯一 direct flow/correlation。

## 5. 必须实际读取的内容

每个在线 job 产生：

```text
perfetto_ui_frame.html
perfetto_ui_text.txt
perfetto_browser.log
perfetto_manifest.json
perfetto_ui.png（仅截图模式）
```

代理必须实际读取 manifest 的 selection、trace hash、SQL、origin/localOnly/offline/Service Worker 门禁，读取 UI text 或静态 HTML，检查可见 query rows 与 browser log。HTML 只作静态 DOM/text 快照，不再次打开执行。Canvas 主体不会完整出现在 HTML 中，故完整 operator 序列仍以本地 `canonical_events.csv` 和 `event_alignment.csv` 为准。

| 证据 | 可以评价 | 不可以评价 |
|---|---|---|
| 本地 CSV/JSON | 完整顺序、Shape、首次差异、calls、flow | Canvas 视觉布局 |
| Perfetto HTML/text/SQL | 页面与查询状态、可见 operator/ordinal/calls | Canvas 色块、条宽、空白 |
| 实际查看 PNG | 可见颜色和轨道几何 | duration 或性能含义 |

## 6. 完成门禁

在线 job 只有同时满足以下条件才能是 success：

```text
online_authorized == true
ui_origin == https://ui.perfetto.dev
local_only == true
offline_before_trace_post == true
service_worker_count_after_render == 0
successful_responses_after_offline == 0
duration_metrics_emitted == false
trace SHA-256 == rank_pairs.csv 对应 trace
selection == 该 Rank/side lane batch
per-lane total == emitted and truncated == false
query error 为空且 row count 可核验
run_id/started_at 属于本次新运行
HTML/text/log/manifest 均存在且非空
```

自动渲染成功不等于内容复核完成。`perfetto_content_review.json` 必须绑定 batch manifest SHA，并逐 Rank/side/batch 记录 renderer run_id、review method，以及 manifest/HTML/text/browser-log 的绝对 path、bytes、SHA。分成多个 batch 时不得只登记 Rank/side 而遗漏 job。

validator 会从 `rank_pairs.csv` 重建预期 Rank/side，重算 trace 和 artifact SHA，复核 origin、offline、Service Worker、SQL 完整性、lane union、run_id 与逐 batch content review。报告状态必须与结构化状态一致：`complete`、`partial` 或 `not-executed` 不能互相冒充。

## 7. 失败与降级

- 无网络、浏览器、Playwright或依赖：写具体 degraded reason 和标准 not-executed/partial evidence，继续本地结构分析。
- 数据政策不允许：不请求绕过，保持 not-executed；可建议固定自托管 UI 或 local trace processor。
- UI 滚动更新导致自动化失败：保存 browser log、frame text 和 manifest；需要复现时使用用户提供的固定 build 并记录 hash。
- lane 太多：确定性分批，保持相同 Rank/side 与 trace SHA；batch union 必须完整。
- DOM 只显示部分行：不把可见行当完整数据；本地 parser 仍是基准。

Perfetto 的任何失败都不能成为忽略其它 Rank/thread/stream 的理由，也不能转换成耗时或性能结论。

---
name: profiling-alignment-analysis
description: Align real-machine and simulation Huawei Ascend TorchNPU integrated Profiler exports across every same-numbered Rank and operator-bearing Host thread/NPU stream without timing analysis. Trace stable operator-route divergences through a MindSpeed .sh launcher and local MindSpeed/torch/torch_npu sources to Python if/elif/else guards, predicate tensors/producers, and original-line-number HTML code snapshots. Produce one large self-contained Chinese Markdown report with machine evidence under evidence/. Use for Ascend real-vs-simulator control-flow alignment, divergent ordinal heatmaps, trace_view.json comparison, and code-backed explanations of simulator-induced route differences.
---

# 真机 / 仿真 Profiling 控制流对齐

固定 `reference=真机`、`candidate=仿真`。最终报告使用中文；算子名、代码符号、路径和 URL 保留原文。

## 输入约定

在包含本次分析全部材料的当前工作目录运行。典型布局：

```text
<work-root>/
  MindSpeed/                 # 模型与训练入口源码，只读
  torch/                     # PyTorch 源码，只读
  torch_npu/                 # TorchNPU 源码，只读
  real-profiling/            # 真机 reference
  simulation-profiling/      # 仿真 candidate
  output/                    # 唯一写入目录
```

Prompt 必须明确给出上述三个源码根、两侧 Profiling 根、输出根，以及相对 `MindSpeed/` 的一个或多个模型 `.sh` 入口；可直接采用 [references/prompt-template.md](references/prompt-template.md)。不得按目录枚举顺序猜 Rank，不得按名称、事件数或时间戳猜真机/仿真角色。入口只从 MindSpeed 根静态解析。

源码和原始 Profiling 全部只读；输出根不得位于其中任一目录内。不得执行 `.sh`、不得 import/运行模型源码、不得修改 checkout。已有本地 checkout 时直接使用；仅当所需 owner 源码缺失、用户给出 HTTPS Git 地址并授权创建 checkout 时，才用安全 checkout 工具克隆到与输出根并列的 `<work-root>/source-checkouts/<component>/`，再把它作为显式 source root。不得把 checkout 放进 `<output>/evidence/`。

运行配置使用 [references/run-spec.md](references/run-spec.md) 的 JSON 契约。至少先完整读取该文件以及 [references/alignment-playbook.md](references/alignment-playbook.md)、[references/source-causality.md](references/source-causality.md)、[references/report-contract.md](references/report-contract.md)。只有明确授权在线 Perfetto 时才读取 [references/perfetto-review.md](references/perfetto-review.md)。

## 默认执行

创建 `<work-root>/alignment-run.json` 后，只用单一可恢复入口启动：

```text
python "${CLAUDE_SKILL_DIR}/scripts/profiling_alignment.py" run --spec "<absolute-work-root>/alignment-run.json" --resume
```

流水线负责 runtime preflight、Ascend 格式预检、逐 Rank/lane 对齐、MindSpeed 入口解析、运行契约、源码因果、Perfetto 状态、报告汇编和最终验证。中断后继续使用同一条命令；不得手工跳过失败 stage。若状态为 `needs-agent`，读取状态文件给出的精确下一步，只对指定 source owner 补充源码因果，再恢复主入口。显式的排障命令仅见 [references/run-spec.md](references/run-spec.md)，不是默认流程。

## 不可违反的分析约束

- 比较 `sorted(real_global_rank_ids ∩ sim_global_rank_ids)` 的每个同号 Rank。真机 0–7、仿真 0–3 时只比较 0、1、2、3；不重编号、不平移、不抽样一个 Rank。
- 每个 Rank 分析全部含算子的 Host thread 和 Device stream。无法高置信匹配的 lane 标为 ambiguous/unmatched，不得强配。
- 固定三层语义：`framework_op`（PyTorch/custom Host op）、`host_launch`（CANN/AscendCL/GE/Runtime Host bridge）、`device_task`（Ascend kernel/HCCL/memcpy/task）。前两层都属于 Host。
- Host 主键为 `rank+semantic_layer+pid+tid+track`；Device 主键为 `rank+device+stream+track`。只有 namespace 正确且端点唯一的 direct flow/correlation 才建立 Host→Device 因果边；不得按时间最近补链。
- 只比较 operator presence、calls、顺序、嵌套、Shape/dtype/format、序位位置和控制路径。禁止输出或解释 duration、latency、self/total time、利用率、重叠、空闲、带宽、快慢或性能比率。
- 解析器可在内部用 `ts/dur` 配对事件、恢复顺序/嵌套/direct flow；这些时间值不得进入公开证据与报告。
- “热力图”只能是 lane 内归一化 event ordinal 的序位热力图，不是时间热力图；色块宽度、面积和空白没有性能含义。
- Shape、tensor identity 和 tensor value 必须区分。缺少直接 predicate operand value 时，不得声称仿真把 tensor 算错。
- 完整输入应是 TorchNPU integrated text export，具有 `trace_view.json` 及 integrated CSV/metadata。raw msprof、`analysis.db` only 或缺逐事件 trace 必须标记 `unsupported/partial`，不得解释为零算子。
- Rank 身份只接受 profiler metadata 或明确 Rank 目录标记；`directory order` 永远不是身份证据。跨 Rank 总 calls/总 kernel 只能说明 coverage，不能证明首次分叉或控制流因果。
- Python 解释器版本和已安装 PyTorch 包版本差异一律作为 informational 忽略，不参与结构可比性、结论强度或修复建议。真机是期望路线基线；guard 所属的实际 torch/torch_npu 源码与构建绑定仍是代码证据。

## 从算子路线到 Python 代码

对每个重大分叉建立以下闭环：

```text
Rank + Host Thread
  -> 最后共同 framework operator anchor
  -> 真机/仿真首个不同 operator + Shape
  -> runtime stack / MindSpeed launcher chain
  -> canonical source owner: model | pytorch | torch_npu
  -> Python AST guard_id + 原始 predicate + if/elif/else arm 行范围
  -> predicate operand 及最近静态/runtime producer
  -> 两侧 branch-exclusive Host operators
  -> 唯一 direct-linked Device kernels（若有）
```

只把 `framework_op` 的稳定首差异映射到 Python guard；`host_launch` 只作桥接。函数 stack 本身不是 guard，C/C++ 代码只能作 backend 导航，不能代替模型/Python 控制流证据。

候选 owner 必须与实际文件匹配：模型/训练逻辑用 `MindSpeed`，PyTorch/FSDP 核心用 `torch`，TorchNPU patch/lowering 用 `torch_npu`。单份 `torch/` 或 `torch_npu/` 默认只绑定真机 reference；没有仿真侧 checkout/build evidence 时不得伪称两侧源码一致。

结论强度仅使用：`已证实控制流分叉`、`强关联控制流分叉`、`静态候选`、`仿真计算错误已证实`。强结论必须通过 Rank/lane、三视图边界、前后 anchor、AST guard/arm、branch-exclusive operator、源码运行绑定和直接证据门禁。最后一级还必须具备同输入/权重/seed/config/code/rank state、直接 operand 值、最早 producer、语义 oracle 与可重复 A/B。

## 主报告硬要求

面向用户的唯一主交付是 `<output>/profiling_alignment_report.md`；CSV、JSON、JSONL 和辅助 HTML 只能放在 `<output>/evidence/`。

主报告必须是一份大型、自包含、实质性中文分析报告，而不是 Key Finding、产物目录或操作 guide。正文必须逐 Rank、逐 lane、逐重大 divergence 展开以下内容：覆盖与配对、序位热力图摘要、首差异上下文、Host→Device 证据、MindSpeed `.sh` 到 Python 的入口链、guard/predicate/producer、替代解释、结论强度和最小验证动作。

每个重大 guard 必须在主 Markdown 内直接嵌入快照工具生成的完整静态 HTML `<details open>...</details>` 片段，包含：

- repository/commit/tree/source SHA、相对文件路径和 Python symbol；
- guard、predicate 与每个 arm 的原始 1-based 行号；
- 逐行原始 Python 代码；
- 真机 arm、仿真 arm及对应 branch-exclusive operators。

不得手抄、改写或重新编号快照，不得以 C++ 代码段替代。关键事实不能要求读者另开 CSV/HTML 才能看到。

最终必须实际读取主报告、`evidence/pipeline/run-state.json` 和 `evidence/report-validation/report_validation.json`。只有验证状态为 pass、blocking error 为 0，且主报告没有 C0/Unicode format control、未验证 raw HTML 或时间性能结论时才能交付。

## Perfetto

默认 `perfetto.online_authorized=false`，状态必须为 `not-executed`；这不阻止本地流式 parser 完成结构分析。只有用户明确确认数据政策允许后才可启用官方在线 UI，而且仍不得点击 Share 或生成公开 trace 链接。默认不截图；未实际检查 PNG 时不得评价 Canvas。Perfetto 只是 Host track/顺序/嵌套的交叉复核，本地 Ascend-aware parser 才是完整结构证据基准。

## 交付前核对

- 所有同号 Rank 和全部 operator-bearing lane 均已登记；额外 Rank 明确 unpaired。
- Host/framework、Host/launch、Device/task 分层清楚；跨域结论都有唯一 direct flow/correlation。
- 每条强结论可回溯到 rank/thread/event/operator/Shape/guard/arm/source line，并在正文中包含同一 evidence_id 的 Python HTML 快照。
- 未因 Python/PyTorch 安装版本不同降级或建议对齐；未在无 operand value 时宣称仿真计算错误。
- 主报告包含分析正文而非附件索引；所有机器证据只在 `evidence/`。
- 原始 Profiling、MindSpeed、torch、torch_npu 和远端仓库均未被修改或执行。

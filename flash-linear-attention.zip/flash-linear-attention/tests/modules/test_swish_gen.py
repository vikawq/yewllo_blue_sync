# Copyright (c) 2023-2026, Songlin Yang, Yu Zhang, Zhiyuan Li
#
# This source code is licensed under the MIT license found in the
# LICENSE file in the root directory of this source tree.
# For a list of all contributors, visit:
#   https://github.com/fla-org/flash-linear-attention/graphs/contributors

"""Generalized tests for swish with CSV-driven parametrization.

Shape constraints (memory-safe):
- B (batch): 1..64
- T (seq_len): 1..8192 (mixed power-of-2 and non-power-of-2)
- D (hidden_dim): 16..4096
- dtype: float32, float16, bfloat16
- Max elements per shape: 8M (fwd+bwd)
- 700 test cases, read from CSV file
"""

import csv
import os
import random
import sys

import pytest
import torch
import torch.nn.functional as F

sys.path.append(os.path.join(os.path.dirname(__file__), "../.."))
from fla.modules.activations import swish
from fla.utils import assert_close, device

MAX_TOTAL_ELEMENTS = 8_000_000
NUM_CASES = 700

CSV_PATH = os.path.join(
    os.path.dirname(os.path.abspath(__file__)),
    "generalization_case_csv",
    "swish_params.csv",
)

B_VALUES = list(range(1, 65))
T_VALUES = [1, 2, 3, 4, 5, 7, 8, 16, 32, 64, 128, 256, 512, 1024, 2048, 4096, 8192,
            500, 1000, 2000, 4000, 6000, 7000, 7500, 384, 768, 1536, 3072, 6144]
D_VALUES = [16, 32, 48, 64, 96, 128, 192, 256, 384, 512, 768, 1024, 1536, 2048, 3072, 4096,
            1200, 600, 300, 150, 100, 50, 25]
DTYPE_NAMES = ["float32", "float16", "bfloat16"]

DTYPE_MAP = {
    "float32": torch.float32,
    "float16": torch.float16,
    "bfloat16": torch.bfloat16,
}


def _shape_fits(shape, max_elements):
    total = 1
    for d in shape:
        total *= d
        if total > max_elements:
            return False
    return True


def _fwdbwd_ratio(dtype):
    if dtype == torch.float32:
        return 1e-5
    if dtype == torch.float16:
        return 1e-2
    return 5e-2


def _generate_csv(csv_path, seed, max_elements, num_cases):
    if os.path.exists(csv_path):
        return

    rng = random.Random(seed)
    cases = set()
    attempts = 0
    max_attempts = num_cases * 200

    while len(cases) < num_cases and attempts < max_attempts:
        B = rng.choice(B_VALUES)
        T = rng.choice(T_VALUES)
        D = rng.choice(D_VALUES)
        dtype = rng.choice(DTYPE_NAMES)

        if not _shape_fits((B, T, D), max_elements):
            attempts += 1
            continue

        cases.add(f"{B},{T},{D},{dtype}")
        attempts += 1

    rows = sorted(cases)

    os.makedirs(os.path.dirname(csv_path), exist_ok=True)
    with open(csv_path, "w", newline="") as f:
        writer = csv.writer(f)
        writer.writerow(["B", "T", "D", "dtype"])
        for row in rows:
            f.write(row + "\n")

    print(f"Generated {len(rows)} swish cases -> {csv_path}")


def _load_cases(csv_path, max_elements):
    _generate_csv(csv_path, seed=137, max_elements=max_elements, num_cases=NUM_CASES)

    test_cases = []
    with open(csv_path, "r") as f:
        reader = csv.DictReader(f)
        for row in reader:
            B = int(row["B"])
            T = int(row["T"])
            D = int(row["D"])
            dtype = DTYPE_MAP[row["dtype"]]
            assert _shape_fits((B, T, D), max_elements), (
                f"Shape ({B},{T},{D}) exceeds max_elements={max_elements}"
            )
            test_cases.append((B, T, D, dtype))
    return test_cases


_FWD_BWD_CASES = _load_cases(CSV_PATH, MAX_TOTAL_ELEMENTS)


@pytest.mark.parametrize(
    ("B", "T", "D", "dtype"),
    [
        pytest.param(
            *test,
            id="B{}-T{}-D{}-{}".format(
                test[0], test[1], test[2], str(test[3]).split(".")[-1]
            ),
        )
        for test in _FWD_BWD_CASES
    ],
)
def test_swish(B, T, D, dtype):
    """Generalized swish forward+backward test with CSV-driven parametrization."""
    torch.manual_seed(42)
    x = torch.randn(B, T, D, dtype=dtype, device=device, requires_grad=True)
    y_ref = F.silu(x)
    y_tri = swish(x)

    g = torch.randn_like(y_ref)
    dx_ref = torch.autograd.grad(y_ref, x, g)[0]
    dx_tri = torch.autograd.grad(y_tri, x, g)[0]

    ratio = _fwdbwd_ratio(dtype)
    assert_close("swish fwd", y_ref, y_tri, ratio)
    assert_close("swish bwd", dx_ref, dx_tri, ratio)

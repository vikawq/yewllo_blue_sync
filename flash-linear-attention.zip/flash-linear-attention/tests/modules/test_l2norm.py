# Copyright (c) 2023-2026, Songlin Yang, Yu Zhang, Zhiyuan Li
#
# This source code is licensed under the MIT license found in the
# LICENSE file in the root directory of this source tree.
# For a list of all contributors, visit:
#   https://github.com/fla-org/flash-linear-attention/graphs/contributors

import pytest
import torch
import torch.nn.functional as F

from fla.modules.l2norm import l2_norm
from fla.utils import assert_close, device


def _get_device_type():
    if hasattr(torch, 'npu') and torch.npu.is_available():
        return 'npu'
    elif torch.cuda.is_available():
        return 'cuda'
    else:
        return 'cpu'


_device_type = _get_device_type()


def _profile(fn_triton):
    if _device_type == 'npu':
        import torch_npu
        experimental_config = torch_npu.profiler._ExperimentalConfig(
            aic_metrics=torch_npu.profiler.AiCMetrics.PipeUtilization,
            profiler_level=torch_npu.profiler.ProfilerLevel.Level1,
            l2_cache=False
        )
        with torch_npu.profiler.profile(
                activities=[torch_npu.profiler.ProfilerActivity.NPU],
                with_stack=False,
                record_shapes=False,
                profile_memory=False,
                schedule=torch_npu.profiler.schedule(wait=1, warmup=1, active=10, repeat=1, skip_first=1),
                experimental_config=experimental_config,
                on_trace_ready=torch_npu.profiler.tensorboard_trace_handler("./result_dir")
        ) as prof:
            for i in range(13):
                fn_triton()
                torch.npu.synchronize()
                prof.step()
    elif _device_type == 'cuda':
        with torch.profiler.profile(
                activities=[
                    torch.profiler.ProfilerActivity.CPU,
                    torch.profiler.ProfilerActivity.CUDA,
                ],
                with_stack=False,
                record_shapes=False,
                profile_memory=False,
                schedule=torch.profiler.schedule(wait=1, warmup=1, active=10, repeat=1, skip_first=1),
                on_trace_ready=torch.profiler.tensorboard_trace_handler("./result_dir")
        ) as prof:
            for i in range(13):
                fn_triton()
                torch.cuda.synchronize()
                prof.step()
        print("\n========== GPU 性能统计 ==========")
        print(prof.key_averages().table(sort_by="self_cuda_time_total", row_limit=10))
    else:
        pytest.skip("未检测到 GPU 或 NPU，跳过性能 profiling")
    print("性能 profiling 完成！")


@pytest.mark.parametrize(
    ('B', 'T', 'H', 'D', 'dtype'),
    [
        pytest.param(*test, id="B{}-T{}-H{}-D{}-{}".format(*test))
        for test in [
            (1, 512, 4, 768, torch.float),
            (2, 768, 4, 1024, torch.float),
            (2, 1024, 2, 1200, torch.float),
            (5, 1024, 6, 2048, torch.float),
            (4, 1024, 5, 1024, torch.float16),
            (4, 512, 4, 2560, torch.bfloat16),
            (3, 768, 4, 2048, torch.float16),
            (4, 640, 4, 3072, torch.bfloat16),
            (5, 512, 4, 2048, torch.bfloat16),
            (4, 512, 3, 4096, torch.bfloat16),
        ]
    ],
)
def test_l2norm(B: int, T: int, H: int, D: int, dtype: torch.dtype):
    torch.manual_seed(42)
    x = torch.randn(B, T, H, D, dtype=dtype).to(device).requires_grad_(True)
    x = x * 0.5 + 0.3

    ref = F.normalize(x, dim=-1, p=2)
    tri = l2_norm(x)
    ref_dx = torch.autograd.grad(ref.sum(), x)[0]
    tri_dx = torch.autograd.grad(tri.sum(), x)[0]

    assert_close('y', ref, tri, 0.005)
    assert_close('dx', ref_dx, tri_dx, 0.005)

    _profile(lambda: torch.autograd.grad(l2_norm(x).sum(), x))

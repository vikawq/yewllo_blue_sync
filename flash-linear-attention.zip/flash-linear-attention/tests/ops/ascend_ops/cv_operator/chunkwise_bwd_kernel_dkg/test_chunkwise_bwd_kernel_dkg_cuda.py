import os
import math
import torch
import triton
import triton.language as tl
from einops import reduce


def ceil_div(x: int, y: int) -> int:
    return math.ceil(x / y)


def ceil_log(x: int, b: int) -> int:
    return math.ceil(math.log(x, b))


@triton.jit
def exp(x):
    return tl.exp(x.to(tl.float32))


@triton.heuristics({"IS_VARLEN": lambda args: args["cu_seqlens"] is not None})
@triton.autotune(
    configs=[
        triton.Config({}, num_warps=num_warps, num_stages=num_stages)
        for num_warps in [4]
        for num_stages in [1, 2]
    ],
    key=["H", "K", "V"],
    restore_value=["dk", "dg", "dg_last"],
)
@triton.jit(do_not_specialize=["T"])
def chunkwise_bwd_kernel_dkg(
    dh,
    k,
    v,
    g,
    dg_last,
    dk,
    dg,
    cu_seqlens,
    T,
    H: tl.constexpr,
    K: tl.constexpr,
    V: tl.constexpr,
    L: tl.constexpr,
    BT: tl.constexpr,
    NT: tl.constexpr,
    IS_VARLEN: tl.constexpr,
):
    i_t, i_nh = tl.program_id(0), tl.program_id(1)
    i_n, i_h = i_nh // H, i_nh % H

    if IS_VARLEN:
        bos, eos = (
            tl.load(cu_seqlens + i_n).to(tl.int32),
            tl.load(cu_seqlens + i_n + 1).to(tl.int32),
        )
        T = eos - bos
    else:
        bos, eos = i_n * T, i_n * T + T

    o_i = tl.arange(0, BT)
    o_t = i_t * BT + o_i
    m_t = o_t < T

    p_dh = tl.make_block_ptr(
        dh + ((i_n * NT + i_t) * H + i_h) * K * V,
        (V, K),
        (1, V),
        (0, 0),
        (V, K),
        (0, 1),
    )
    p_g = tl.make_block_ptr(g + bos * H + i_h, (T,), (H,), (i_t * BT,), (BT,), (0,))
    p_k = tl.make_block_ptr(k + bos * K, (T, K), (K, 1), (i_t * BT, 0), (BT, K), (1, 0))
    p_v = tl.make_block_ptr(
        v + (bos * H + i_h) * V,
        (T, V),
        (H * V, 1),
        (i_t * BT, 0),
        (BT, V),
        (1, 0),
    )
    p_dk = tl.make_block_ptr(
        dk + (bos * H + i_h) * K, (T, K), (H * K, 1), (i_t * BT, 0), (BT, K), (1, 0),
    )
    p_dg = tl.make_block_ptr(dg + bos * H + i_h, (T,), (H,), (i_t * BT,), (BT,), (0,))

    b_dh = tl.load(p_dh, boundary_check=(0, 1))
    b_g = tl.load(p_g, boundary_check=(0,))
    b_v = tl.load(p_v, boundary_check=(0, 1))
    b_k = tl.load(p_k, boundary_check=(0, 1))
    last_idx = min((i_t + 1) * BT, T) - 1
    b_g_last = tl.load(g + bos * H + last_idx * H + i_h)
    p_dg_last = dg_last + i_n * NT * H + i_t * H + i_h
    b_dg_last = tl.load(p_dg_last)

    b_dg_last *= tl.exp(b_g_last)
    b_dk = tl.where(m_t, exp(b_g_last - b_g), 0)[:, None] * tl.dot(b_v, b_dh).to(b_v.dtype)
    b_dg = tl.load(p_dg, boundary_check=(0,))
    b_dg -= tl.sum(b_k * b_dk, axis=1)
    b_dg_last += tl.sum(b_dk * b_k)

    b_dg = tl.where(o_i < BT - 1, b_dg, b_dg + b_dg_last)

    tl.store(p_dg, b_dg, boundary_check=(0,))
    tl.store(p_dk, b_dk.to(p_dk.dtype.element_ty), boundary_check=(0, 1))


def test_chunkwise_bwd_kernel_dkg():
    B = 2
    T = 512
    G = 1
    K = 64
    H = 8
    V = 32
    L = 7
    BT = 32

    device = torch.device('cuda')
    dtype = torch.float32

    NT = ceil_div(T, BT)

    dh = torch.randn(B, NT, H, K, V, dtype=dtype, device=device)
    k = torch.randn(B, T, G, K, dtype=dtype, device=device)
    v = torch.randn(B, T, H, V, dtype=dtype, device=device)
    g = torch.randn(B, T, H, dtype=dtype, device=device)
    dg_last = torch.randn(B, NT, H, dtype=torch.float32, device=device)
    dk = torch.zeros(B, T, H, K, dtype=dtype, device=device)
    dg = torch.zeros(B, T, H, dtype=torch.float32, device=device)

    cu_seqlens = None

    save_dir = '/home/l00890003/codes/flash-linear-attention/xx/FLA/kernel_inputs_and_outputs_fp64/chunkwise_bwd_kernel_dkg'

    inputs_dict = {
        'dh': dh.cpu(),
        'k': k.cpu(),
        'v': v.cpu(),
        'g': g.cpu(),
        'dg_last': dg_last.cpu(),
        'dk': dk.cpu(),
        'dg': dg.cpu(),
        'cu_seqlens': cu_seqlens,
        'B': B,
        'T': T,
        'G': G,
        'K': K,
        'H': H,
        'V': V,
        'L': L,
        'BT': BT,
        'NT': NT,
    }
    torch.save(inputs_dict, os.path.join(save_dir, 'inputs.pt'))

    dh_clone = dh.clone()
    k_clone = k.clone()
    v_clone = v.clone()
    g_clone = g.clone()
    dg_last_clone = dg_last.clone()
    dk_clone = dk.clone()
    dg_clone = dg.clone()

    grid_t = (NT, B * H)

    chunkwise_bwd_kernel_dkg[grid_t](
        dh=dh_clone,
        k=k_clone,
        v=v_clone,
        g=g_clone,
        dg_last=dg_last_clone,
        dk=dk_clone,
        dg=dg_clone,
        cu_seqlens=cu_seqlens,
        T=T,
        H=H,
        K=K,
        V=V,
        L=L,
        BT=BT,
        NT=NT,
    )

    outputs_dict = {
        'dk': dk_clone.cpu(),
        'dg': dg_clone.cpu(),
    }

    dh_fp64 = dh.to(torch.float64)
    k_fp64 = k.to(torch.float64)
    v_fp64 = v.to(torch.float64)
    g_fp64 = g.to(torch.float64)
    dg_last_fp64 = dg_last.to(torch.float64)
    dk_fp64 = dk.to(torch.float64)
    dg_fp64 = dg.to(torch.float64)

    chunkwise_bwd_kernel_dkg[grid_t](
        dh=dh_fp64,
        k=k_fp64,
        v=v_fp64,
        g=g_fp64,
        dg_last=dg_last_fp64,
        dk=dk_fp64,
        dg=dg_fp64,
        cu_seqlens=cu_seqlens,
        T=T,
        H=H,
        K=K,
        V=V,
        L=L,
        BT=BT,
        NT=NT,
    )

    outputs_dict['dk_fp64'] = dk_fp64.cpu()
    outputs_dict['dg_fp64'] = dg_fp64.cpu()

    torch.save(outputs_dict, os.path.join(save_dir, 'outputs.pt'))

    print("Test completed for chunkwise_bwd_kernel_dkg, data saved.")


if __name__ == "__main__":
    test_chunkwise_bwd_kernel_dkg()

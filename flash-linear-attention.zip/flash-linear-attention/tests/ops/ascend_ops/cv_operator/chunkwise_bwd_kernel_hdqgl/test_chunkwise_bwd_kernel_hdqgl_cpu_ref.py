import math
import torch


def ceil_div(x, y):
    return math.ceil(x / y)


def chunkwise_bwd_kernel_hdqgl_ref(
    do, q, k, v, g, l, h_l, dq, dg, dl,
    cu_seqlens, ell, B, T, K, H, V, L, BT, NT
):
    num_intra_levels = math.ceil(math.log2(BT)) + 1

    for i_n in range(B):
        for i_h in range(H):
            b_h = torch.zeros(V, K, dtype=torch.float64)

            for i_t in range(ceil_div(T, BT)):
                t_start = i_t * BT
                t_end = min((i_t + 1) * BT, T)

                if i_t & (1 << ell):
                    b_do = do[i_n, t_start:t_end, i_h, :]
                    b_q = q[i_n, t_start:t_end, 0, :]
                    b_g_chunk = g[i_n, t_start:t_end, i_h]
                    b_l = l[i_n, t_start:t_end, i_h, num_intra_levels + ell]

                    b_dlq = torch.exp(b_g_chunk).unsqueeze(-1) * (b_do @ b_h)
                    b_dl_val = (b_dlq * b_q).sum(dim=1)
                    b_dg_val = b_l * b_dl_val

                    h_l[i_n, i_t, i_h] = b_h.T

                    dq[i_n, t_start:t_end, i_h, :] += b_l.unsqueeze(-1) * b_dlq
                    dl[i_n, t_start:t_end, i_h, num_intra_levels + ell] = b_dl_val
                    dg[i_n, t_start:t_end, i_h] += b_dg_val

                    if ((i_t + 1) & (1 << ell)) == 0:
                        b_h = torch.zeros(V, K, dtype=torch.float64)

                last_idx = min((i_t + 1) * BT, T) - 1
                b_g_last = g[i_n, last_idx, i_h]
                b_h = b_h * torch.exp(b_g_last)

                if (i_t & (1 << ell)) == 0:
                    b_k = k[i_n, t_start:t_end, 0, :]
                    b_v = v[i_n, t_start:t_end, i_h, :]
                    b_g_chunk = g[i_n, t_start:t_end, i_h]

                    b_k_scaled = b_k * torch.exp(b_g_last - b_g_chunk).unsqueeze(-1)
                    b_h = b_h + b_v.T @ b_k_scaled

    return dq, dg, dl, h_l


if __name__ == "__main__":
    ptfile_path = './test_chunkwise_bwd_kernel_hdqgl_cuda.pt'
    data = torch.load(ptfile_path, map_location=torch.device('cpu'), weights_only=False)

    input_data = data["input_data"]

    ell = input_data['ell']
    B = input_data['B']
    T = input_data['T']
    K = input_data['K']
    H = input_data['H']
    V = input_data['V']
    L = input_data['L']
    BT = input_data['BT']
    NT = input_data['NT']
    cu_seqlens = input_data['cu_seqlens']

    do = input_data['do'].double()
    q = input_data['q'].double()
    k = input_data['k'].double()
    v = input_data['v'].double()
    g = input_data['g'].double()
    l_input = input_data['l'].double()
    h_l = torch.zeros(B, NT, H, K, V, dtype=torch.float64)
    dq = input_data['dq'].double().clone()
    dg = input_data['dg'].double().clone()
    dl = input_data['dl'].double().clone()

    dq_ref, dg_ref, dl_ref, h_l_ref = chunkwise_bwd_kernel_hdqgl_ref(
        do, q, k, v, g, l_input, h_l, dq, dg, dl,
        cu_seqlens, ell, B, T, K, H, V, L, BT, NT
    )

    output = {
        'dq': dq_ref,
        'dg': dg_ref,
        'dl': dl_ref,
    }

    output_path = './test_chunkwise_bwd_kernel_hdqgl_cpu_ref.pt'
    torch.save(output, output_path)
    print(f"CPU reference saved to {output_path}")
    for k, v in output.items():
        print(f"  {k}: shape={v.shape}, dtype={v.dtype}")
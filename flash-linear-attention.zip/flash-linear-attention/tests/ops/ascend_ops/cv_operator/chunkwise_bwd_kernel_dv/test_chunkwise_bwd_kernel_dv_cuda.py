import os
import torch
import triton
import triton.language as tl
import math


def ceil_div(x: int, y: int) -> int:
    return math.ceil(x / y)


@triton.heuristics({"IS_VARLEN": lambda args: args["cu_seqlens"] is not None})
@triton.autotune(
    configs=[
        triton.Config({}, num_warps=num_warps, num_stages=num_stages)
        for num_warps in [4]
        for num_stages in [2, 3, 4]
    ],
    key=["H", "K", "V"],
    restore_value=["dv"],
)
@triton.jit(do_not_specialize=["T"])
def chunkwise_bwd_kernel_dv(
    dh,
    k,
    g,
    dv,
    T,
    cu_seqlens,
    H: tl.constexpr,
    K: tl.constexpr,
    V: tl.constexpr,
    L: tl.constexpr,
    BT: tl.constexpr,
    NT: tl.constexpr,
    IS_VARLEN: tl.constexpr,
):
    i_t, i_nh = tl.program_id(0), tl.program_id(1)
    i_n, i_h = i_nh // H, i_nh % H

    if IS_VARLEN:
        bos, eos = (
            tl.load(cu_seqlens + i_n).to(tl.int32),
            tl.load(cu_seqlens + i_n + 1).to(tl.int32),
        )
        T = eos - bos
    else:
        bos, eos = i_n * T, i_n * T + T

    o_t = i_t * BT + tl.arange(0, BT)
    m_t = o_t < T

    p_dh = tl.make_block_ptr(
        dh + ((i_n * NT + i_t) * H + i_h) * K * V,
        (K, V),
        (V, 1),
        (0, 0),
        (K, V),
        (1, 0),
    )
    p_g = tl.make_block_ptr(g + bos * H + i_h, (T,), (H,), (i_t * BT,), (BT,), (0,))
    p_k = tl.make_block_ptr(k + bos * K, (T, K), (K, 1), (i_t * BT, 0), (BT, K), (1, 0))
    p_dv = tl.make_block_ptr(
        dv + (bos * H + i_h) * V, (T, V), (H * V, 1), (i_t * BT, 0), (BT, V), (1, 0),
    )

    last_idx = min((i_t + 1) * BT, T) - 1
    b_g_last = tl.load(g + bos * H + last_idx * H + i_h)

    b_dh = tl.load(p_dh, boundary_check=(0, 1))
    b_g = tl.load(p_g, boundary_check=(0,))
    b_k = tl.load(p_k, boundary_check=(0, 1))
    b_dv = tl.where(m_t, tl.exp(-b_g + b_g_last), 0)[:, None] * tl.dot(b_k, b_dh).to(b_k.dtype)
    tl.store(p_dv, b_dv.to(p_dv.dtype.element_ty), boundary_check=(0, 1))


def test_chunkwise_bwd_kernel_dv():
    B = 2
    T = 1024
    H = 8
    K = 64
    V = 64
    L = 12
    BT = 64
    G = 1

    NT = ceil_div(T, BT)

    device = torch.device('cuda')

    dh = torch.randn(B, NT, H, K, V, dtype=torch.float32, device=device)
    k = torch.randn(B, T, G, K, dtype=torch.float32, device=device)
    g = torch.randn(B, T, H, dtype=torch.float32, device=device)
    dv = torch.zeros(B, T, H, V, dtype=torch.float32, device=device)

    save_dir = '/home/l00890003/codes/flash-linear-attention/xx/FLA/kernel_inputs_and_outputs_fp64/chunkwise_bwd_kernel_dv'

    inputs_dict = {
        'dh': dh.cpu(),
        'k': k.cpu(),
        'g': g.cpu(),
        'dv': dv.cpu(),
        'cu_seqlens': None,
        'B': B,
        'T': T,
        'H': H,
        'K': K,
        'V': V,
        'L': L,
        'BT': BT,
        'G': G,
        'NT': NT,
    }
    torch.save(inputs_dict, os.path.join(save_dir, 'inputs.pt'))

    dh_clone = dh.clone()
    k_clone = k.clone()
    g_clone = g.clone()
    dv_clone = dv.clone()

    grid = (NT, B * H)

    chunkwise_bwd_kernel_dv[grid](
        dh=dh_clone,
        k=k_clone,
        g=g_clone,
        dv=dv_clone,
        cu_seqlens=None,
        T=T,
        H=H,
        K=K,
        V=V,
        L=L,
        BT=BT,
        NT=NT,
    )

    outputs_dict = {
        'dv': dv_clone.cpu(),
    }

    dh_fp64 = dh.to(torch.float64)
    k_fp64 = k.to(torch.float64)
    g_fp64 = g.to(torch.float64)
    dv_fp64 = dv.to(torch.float64)

    chunkwise_bwd_kernel_dv[grid](
        dh=dh_fp64,
        k=k_fp64,
        g=g_fp64,
        dv=dv_fp64,
        cu_seqlens=None,
        T=T,
        H=H,
        K=K,
        V=V,
        L=L,
        BT=BT,
        NT=NT,
    )

    outputs_dict['dv_fp64'] = dv_fp64.cpu()

    torch.save(outputs_dict, os.path.join(save_dir, 'outputs.pt'))

    print("Test completed for chunkwise_bwd_kernel_dv, data saved.")


if __name__ == "__main__":
    test_chunkwise_bwd_kernel_dv()

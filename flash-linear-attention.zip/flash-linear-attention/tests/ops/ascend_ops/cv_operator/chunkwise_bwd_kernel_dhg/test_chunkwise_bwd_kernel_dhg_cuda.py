import math
import torch
import triton
import triton.language as tl
from einops import reduce
import os
os.environ["TRITON_F32_DEFAULT"] = "ieee"
def ceil_div(x: int, y: int) -> int:
    return math.ceil(x / y)


def ceil_log(x: int, b: int) -> int:
    return math.ceil(math.log(x, b))


BLOCK_K = 64


@triton.heuristics({"IS_VARLEN": lambda args: args["cu_seqlens"] is not None})
@triton.autotune(
    configs=[
        triton.Config({"BK": BK}, num_warps=num_warps, num_stages=num_stages)
        for BK in [32, 64, 128]
        for num_warps in [4]
        for num_stages in [2, 3, 4]
    ],
    key=["H", "K", "V"],
    restore_value=["dh", "dg_last"],
)
@triton.jit(do_not_specialize=["T"])
def chunkwise_bwd_kernel_dhg(
    do,
    q,
    g,
    l,
    h_l,
    dh,
    dg_last,
    ell,
    T,
    cu_seqlens,
    H: tl.constexpr,
    K: tl.constexpr,
    V: tl.constexpr,
    L: tl.constexpr,
    BT: tl.constexpr,
    BK: tl.constexpr,
    NT: tl.constexpr,
    IS_VARLEN: tl.constexpr,
):
    i_k = tl.program_id(0)
    i_nh = tl.program_id(1)
    i_n, i_h = i_nh // H, i_nh % H

    if IS_VARLEN:
        bos, eos = (
            tl.load(cu_seqlens + i_n).to(tl.int32),
            tl.load(cu_seqlens + i_n + 1).to(tl.int32),
        )
        T = eos - bos
    else:
        bos, eos = i_n * T, i_n * T + T

    b_dh = tl.zeros([BK, V], dtype=tl.float32)

    num_intra_levels = (tl.log2(float(BT))).to(tl.int32) + 1

    for i_t in range(tl.cdiv(T, BT) - 1, -1, -1):
        p_dh = tl.make_block_ptr(
            dh + ((i_n * NT + i_t) * H + i_h) * K * V,
            (K, V),
            (V, 1),
            (i_k * BK, 0),
            (BK, V),
            (1, 0),
        )
        b_dh_old = tl.load(p_dh, boundary_check=(0, 1))

        if (i_t & (1 << ell)) == 0:
            tl.store(
                p_dh, b_dh.to(p_dh.dtype.element_ty) + b_dh_old, boundary_check=(0, 1),
            )
            if i_t > 0 and ((i_t - 1) & (1 << ell)) > 0:
                b_dh = tl.zeros([BK, V], dtype=tl.float32)
        if i_t & (1 << ell):
            p_h = tl.make_block_ptr(
                h_l + ((i_n * NT + i_t) * H + i_h) * K * V,
                (K, V),
                (V, 1),
                (i_k * BK, 0),
                (BK, V),
                (1, 0),
            )

            b_h = tl.load(p_h, boundary_check=(0, 1))
            p_dg_last = dg_last + i_n * NT * H + i_t * H + i_h
            tl.atomic_add(p_dg_last, tl.sum(b_h * (b_dh + b_dh_old)))
        last_idx = min((i_t + 1) * BT, T) - 1
        b_g_last = tl.exp(tl.load(g + bos * H + last_idx * H + i_h))
        b_dh *= b_g_last
        if i_t & (1 << ell):
            p_g = tl.make_block_ptr(
                g + bos * H + i_h, (T,), (H,), (i_t * BT,), (BT,), (0,),
            )
            p_q = tl.make_block_ptr(
                q + bos * K, (K, T), (1, K), (i_k * BK, i_t * BT), (BK, BT), (0, 1),
            )
            p_do = tl.make_block_ptr(
                do + (bos * H + i_h) * V,
                (T, V),
                (H * V, 1),
                (i_t * BT, 0),
                (BT, V),
                (1, 0),
            )
            p_l = tl.make_block_ptr(
                l + (bos * H + i_h) * L + num_intra_levels + ell,
                (T,),
                (H * L,),
                (i_t * BT,),
                (BT,),
                (0,),
            )
            b_l = tl.load(p_l, boundary_check=(0,))
            b_g = tl.load(p_g, boundary_check=(0,))
            b_q = tl.load(p_q, boundary_check=(0, 1))
            b_q = (b_q * (tl.exp(b_g) * b_l)[None, :]).to(b_q.dtype)
            b_do = tl.load(p_do, boundary_check=(0, 1))

            b_s = tl.dot(b_q, b_do).to(b_q.dtype)
            b_dh += b_s

@triton.heuristics({"IS_VARLEN": lambda args: args["cu_seqlens"] is not None})
@triton.autotune(
    configs=[
        triton.Config({"BK": BK}, num_warps=num_warps, num_stages=num_stages)
        for BK in [32, 64, 128]
        for num_warps in [4]
        for num_stages in [2, 3, 4]
    ],
    key=["H", "K", "V"],
    restore_value=["dh", "dg_last"],
)
@triton.jit(do_not_specialize=["T"])
def chunkwise_bwd_kernel_dhg_fp64(
    do,
    q,
    g,
    l,
    h_l,
    dh,
    dg_last,
    ell,
    T,
    cu_seqlens,
    H: tl.constexpr,
    K: tl.constexpr,
    V: tl.constexpr,
    L: tl.constexpr,
    BT: tl.constexpr,
    BK: tl.constexpr,
    NT: tl.constexpr,
    IS_VARLEN: tl.constexpr,
):
    i_k = tl.program_id(0)
    i_nh = tl.program_id(1)
    i_n, i_h = i_nh // H, i_nh % H

    if IS_VARLEN:
        bos, eos = (
            tl.load(cu_seqlens + i_n).to(tl.int32),
            tl.load(cu_seqlens + i_n + 1).to(tl.int32),
        )
        T = eos - bos
    else:
        bos, eos = i_n * T, i_n * T + T

    b_dh = tl.zeros([BK, V], dtype=tl.float64)

    num_intra_levels = (tl.log2(float(BT))).to(tl.int32) + 1

    for i_t in range(tl.cdiv(T, BT) - 1, -1, -1):
        p_dh = tl.make_block_ptr(
            dh + ((i_n * NT + i_t) * H + i_h) * K * V,
            (K, V),
            (V, 1),
            (i_k * BK, 0),
            (BK, V),
            (1, 0),
        )
        b_dh_old = tl.load(p_dh, boundary_check=(0, 1))

        if (i_t & (1 << ell)) == 0:
            tl.store(
                p_dh, b_dh.to(p_dh.dtype.element_ty) + b_dh_old, boundary_check=(0, 1),
            )
            if i_t > 0 and ((i_t - 1) & (1 << ell)) > 0:
                b_dh = tl.zeros([BK, V], dtype=tl.float64)
        if i_t & (1 << ell):
            p_h = tl.make_block_ptr(
                h_l + ((i_n * NT + i_t) * H + i_h) * K * V,
                (K, V),
                (V, 1),
                (i_k * BK, 0),
                (BK, V),
                (1, 0),
            )

            b_h = tl.load(p_h, boundary_check=(0, 1))
            p_dg_last = dg_last + i_n * NT * H + i_t * H + i_h
            tl.atomic_add(p_dg_last, tl.sum(b_h * (b_dh + b_dh_old)))
        last_idx = min((i_t + 1) * BT, T) - 1
        b_g_last = tl.exp(tl.load(g + bos * H + last_idx * H + i_h))
        b_dh *= b_g_last
        if i_t & (1 << ell):
            p_g = tl.make_block_ptr(
                g + bos * H + i_h, (T,), (H,), (i_t * BT,), (BT,), (0,),
            )
            p_q = tl.make_block_ptr(
                q + bos * K, (K, T), (1, K), (i_k * BK, i_t * BT), (BK, BT), (0, 1),
            )
            p_do = tl.make_block_ptr(
                do + (bos * H + i_h) * V,
                (T, V),
                (H * V, 1),
                (i_t * BT, 0),
                (BT, V),
                (1, 0),
            )
            p_l = tl.make_block_ptr(
                l + (bos * H + i_h) * L + num_intra_levels + ell,
                (T,),
                (H * L,),
                (i_t * BT,),
                (BT,),
                (0,),
            )
            b_l = tl.load(p_l, boundary_check=(0,))
            b_g = tl.load(p_g, boundary_check=(0,))
            b_q = tl.load(p_q, boundary_check=(0, 1))
            b_q = (b_q * (tl.exp(b_g) * b_l)[None, :]).to(b_q.dtype)
            b_do = tl.load(p_do, boundary_check=(0, 1))

            b_s = tl.dot(b_q, b_do).to(b_q.dtype)
            b_dh += b_s

def test_chunkwise_bwd_kernel_dhg():
    B = 2
    T = 1024
    G = 1
    K = 128
    H = 8
    V = 64
    L = 7
    BT = 64

    device = torch.device('cuda')
    dtype = torch.float32

    NT = ceil_div(T, BT)

    do = torch.randn(B, T, H, V, dtype=dtype, device=device)
    q = torch.randn(B, T, G, K, dtype=dtype, device=device)
    g = torch.randn(B, T, H, dtype=dtype, device=device)
    l = torch.randn(B, T, H, L, dtype=dtype, device=device)
    h_l = torch.randn(B, NT, H, K, V, dtype=dtype, device=device)
    dh = torch.zeros(B, NT, H, K, V, dtype=dtype, device=device)
    dg_last = torch.zeros(B, NT, H, dtype=dtype, device=device)

    cu_seqlens = None

    ell = 0


    data = {}
    data['input_data'] = {}
    data['input_data']['do'] = do.cpu()
    data['input_data']['q'] = q.cpu()
    data['input_data']['g'] = g.cpu()
    data['input_data']['l'] = l.cpu()
    data['input_data']['h_l'] = h_l.cpu()
    data['input_data']['dh'] = dh.cpu()
    data['input_data']['dg_last'] = dg_last.cpu()
    data['input_data']['cu_seqlens'] = cu_seqlens
    data['input_data']['ell'] = ell
    data['input_data']['B'] = B
    data['input_data']['T'] = T
    data['input_data']['G'] = G
    data['input_data']['K'] = K
    data['input_data']['H'] = H
    data['input_data']['V'] = V
    data['input_data']['L'] = L
    data['input_data']['BT'] = BT
    data['input_data']['NT'] = NT

    def grid_f(meta):
        return (triton.cdiv(K, meta["BK"]), B * H)

    chunkwise_bwd_kernel_dhg[grid_f](
        do=do,
        q=q,
        g=g,
        l=l,
        h_l=h_l,
        dh=dh,
        dg_last=dg_last,
        cu_seqlens=cu_seqlens,
        ell=ell,
        T=T,
        H=H,
        K=K,
        V=V,
        L=L,
        BT=BT,
        NT=NT,
    )

    data['gpu_output'] = {}
    data['gpu_output']['dh'] = dh.cpu()
    data['gpu_output']['dg_last'] = dg_last.cpu()

    do_fp64 = do.to(torch.float64)
    q_fp64 = q.to(torch.float64)
    g_fp64 = g.to(torch.float64)
    l_fp64 = l.to(torch.float64)
    h_l_fp64 = h_l.to(torch.float64)
    dh_fp64 = dh.to(torch.float64)
    dg_last_fp64 = dg_last.to(torch.float64)

    chunkwise_bwd_kernel_dhg_fp64[grid_f](
        do=do_fp64,
        q=q_fp64,
        g=g_fp64,
        l=l_fp64,
        h_l=h_l_fp64,
        dh=dh_fp64,
        dg_last=dg_last_fp64,
        cu_seqlens=cu_seqlens,
        ell=ell,
        T=T,
        H=H,
        K=K,
        V=V,
        L=L,
        BT=BT,
        NT=NT,
    )
    data['gpu_output_fp64'] = {}
    data['gpu_output_fp64']['dh'] = dh_fp64.cpu()
    data['gpu_output_fp64']['dg_last'] = dg_last_fp64.cpu()

    torch.save(data, f'test_chunkwise_bwd_kernel_dhg_cuda.pt')

    print("Test completed for chunkwise_bwd_kernel_dhg, data saved.")


if __name__ == "__main__":
    test_chunkwise_bwd_kernel_dhg()

